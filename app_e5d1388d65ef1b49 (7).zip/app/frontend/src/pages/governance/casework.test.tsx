import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { CaseworkFromScan, CaseworkInbox, type Case } from "./casework";
import type { RiskRow, Scan } from "./api";
const api = vi.hoisted(() => vi.fn());
vi.mock("./api", async (original) => ({
  ...(await original<typeof import("./api")>()),
  workbenchApi: api,
}));
vi.mock("../../auth", () => ({ apiFetch: vi.fn() }));
const row = {
  id: "r1",
  program: "ET",
  member: {
    account_id: "7675782032500424721",
    account_name: "真实客户",
    region: "APAC",
  },
  ccr: 46,
  nfs: 60,
} as RiskRow;
const scan = {
  id: "s1",
  status: "ready",
  request: { start_date: "2026-10-01", end_date: "2026-10-15" },
} as Scan;
const initial: Case = {
  id: "TAP-case1",
  version: 1,
  kind: "customer",
  status: "open",
  owner: "owner",
  creator: "operator",
  reviewer: "operator",
  row,
  window: scan.request,
  created_at: "",
  updated_at: "",
  plan: "",
  note: "",
  fields: {},
  due_date: "",
  action_completed: false,
  education_completed: false,
  review_requested_by: "",
  closure_reason: "",
  history: [],
  rechecks: [],
};
const config = {
  actor: "owner",
  is_operator: false,
  notification_mode: "disabled",
  business_confirmed: false,
  version: "pilot",
  members: [
    { username: "owner", display_name: "负责人" },
    { username: "operator", display_name: "运营" },
  ],
  recipients: [],
  integration: {},
  workflow: {
    customer: [
      {
        id: "communicate",
        label: "客户沟通与整改",
        status: "processing",
        fields: [
          { key: "contact", label: "沟通对象", required: true },
          {
            key: "due_date",
            label: "承诺完成日期",
            type: "date",
            required: true,
          },
        ],
      },
      {
        id: "observe",
        label: "继续观察（旧配置）",
        status: "observing",
        fields: [{ key: "reason", label: "观察原因", required: true }],
      },
      { id: "tap_remove", label: "TAP移除", status: "processing", fields: [] },
      { id: "update_threshold", label: "更新阈值", status: "processing", fields: [] },
      { id: "continue_observe", label: "继续观察", status: "observing", fields: [] },
    ],
  },
};
beforeEach(() => {
  api.mockReset();
  api.mockImplementation(async (path: string, body?: any) => {
    if (path.endsWith("/casework/config")) return { data: config };
    if (path === "/api/workbench/cases" && body) return { data: initial };
    if (path.startsWith("/api/workbench/cases?") || path === "/api/workbench/cases")
      return {
        data: {
          cases: [initial],
          stats: { total: 1, action_completed: 0, risk_recovered: 0 },
          report_note: "过程与效果分开",
          case_scope: path.includes("case_scope=all") ? "all" : "current",
          active_window: { start_date: "2026-10-01", end_date: "2026-10-15" },
        },
      };
    if (path.endsWith("/commands"))
      return {
        data: {
          ...initial,
          version: 2,
          status: "processing",
          plan: body.plan,
          fields: body.fields,
        },
      };
    if (path.endsWith("/TAP-case1"))
      return { data: initial, notifications: [], permissions: { can_handle: true, can_review: false } };
    throw Error(path);
  });
});
afterEach(cleanup);
async function open() {
  render(<CaseworkFromScan row={row} scan={scan} />);
  fireEvent.click(screen.getByRole("button", { name: "打开共享处置" }));
  await screen.findByTestId("case-detail");
}
it("creates from the exact scan row and sends structured plan with revision and idempotency", async () => {
  await open();
  expect(api).toHaveBeenCalledWith("/api/workbench/cases", {
    scan_id: "s1",
    row_id: "r1",
  });
  fireEvent.change(screen.getByLabelText("沟通对象"), {
    target: { value: "广告主" },
  });
  fireEvent.change(screen.getByLabelText("承诺完成日期"), {
    target: { value: "2026-10-25" },
  });
  fireEvent.change(screen.getByLabelText("共享处理记录"), {
    target: { value: "核查后沟通" },
  });
  fireEvent.click(screen.getByRole("button", { name: "保存处置方案" }));
  await waitFor(() =>
    expect(api).toHaveBeenCalledWith(
      "/api/workbench/cases/TAP-case1/commands",
      expect.objectContaining({
        expected_version: 1,
        request_id: expect.any(String),
        operation: "plan",
        plan: "communicate",
        fields: { contact: "广告主", due_date: "2026-10-25" },
      }),
    ),
  );
  expect(
    await screen.findByText("已保存，飞书卡片如已发送将异步同步。"),
  ).toBeTruthy();
});
it("switches action-specific fields, review, notification and audit pages independently", async () => {
  await open();
  fireEvent.change(screen.getByLabelText("处置动作"), {
    target: { value: "observe" },
  });
  expect(screen.queryByLabelText("沟通对象")).toBeNull();
  expect(screen.getByLabelText("观察原因")).toBeTruthy();
  fireEvent.click(screen.getByRole("tab", { name: "复查与复核" }));
  expect(
    screen.getByRole("button", { name: "查询并保存真实复查" }),
  ).toBeTruthy();
  expect(screen.queryByLabelText("观察原因")).toBeNull();
  fireEvent.click(screen.getByRole("tab", { name: "责任分派与通知" }));
  expect(
    screen.getByRole("button", { name: "生成无发送预览" }),
  ).toBeTruthy();
  fireEvent.click(screen.getByRole("tab", { name: "操作记录" }));
  expect(screen.queryByRole("button", { name: "发送测试风险卡片" })).toBeNull();
});
it("shows backend validation failure without a false success", async () => {
  const base = api.getMockImplementation()!;
  api.mockImplementation(async (path: string, ...args: any[]) => {
    if (path.endsWith("/commands")) throw Error("请填写：沟通对象");
    return base(path, ...args);
  });
  await open();
  fireEvent.click(screen.getByRole("button", { name: "保存处置方案" }));
  expect(await screen.findByRole("alert")).toHaveProperty(
    "textContent",
    "请填写：沟通对象",
  );
  expect(screen.queryByText("已保存，飞书卡片如已发送将异步同步。")).toBeNull();
});
it("keeps completed actions and recovered risks as separate report counts", async () => {
  render(<CaseworkInbox reportOnly />);
  await screen.findByText("过程与效果分开");
  expect(screen.getByText("动作完成")).toBeTruthy();
  expect(screen.getByText("复查恢复并关闭")).toBeTruthy();
  expect(screen.queryByRole("button", { name: "处理事件" })).toBeNull();
});
it("does not let the submitting owner self-close in pending review", async () => {
  const base = api.getMockImplementation()!;
  api.mockImplementation(async (path: string, ...args: any[]) =>
    path.endsWith("/TAP-case1")
      ? {
          data: {
            ...initial,
            status: "pending_review",
            review_requested_by: "owner",
          },
          notifications: [],
          permissions: { can_handle: true, can_review: false },
        }
      : base(path, ...args),
  );
  await open();
  fireEvent.click(screen.getByRole("tab", { name: "复查与复核" }));
  expect(screen.getByRole("button", { name: "复核通过并关闭" })).toHaveProperty(
    "disabled",
    true,
  );
});

async function openTestNotification(previewReady=true, sendFails=false) {
 const base=api.getMockImplementation()!;
 api.mockImplementation(async(path:string,...args:any[])=>{
  if(path.endsWith("/casework/config")) return {data:{...config,notification_mode:"test",auto_send_enabled:false,recipients:[{id:"ou_test_person",type:"open_id",label:"指定测试人员"},{id:"oc_group",type:"chat_id",label:"不可选群聊"}]}};
  if(path.endsWith("/notification-preview")) return {data:{dry_run:true,will_send:false,notification_mode:"test",alert_id:initial.id,case_version:1,confirmation_token:previewReady?"opaque-preview-token":"",mapping_result:{status:previewReady?"matched":"blocked",reason:"checked"},bot_resolution:{status:previewReady?"resolved":"api_error"},actual_target:{status:previewReady?"ready_test_allowlist":"blocked",label:"指定测试人员",id_masked:"ou_***",test_recipient_replacement:true},notice:"测试预览"}};
  if(path.endsWith("/notify")) {if(sendFails)throw Error("映射已更新，请重新预览"); return {data:{...initial,version:2},deduplicated:false};}
  return base(path,...args);
 });
 await open();fireEvent.click(screen.getByRole("tab",{name:"责任分派与通知"}));
 fireEvent.change(screen.getByLabelText("测试模式实际目标（正式模式忽略）"),{target:{value:"ou_test_person"}});
}
it("requires a successful preview and explicit checkbox before queuing one test card",async()=>{
 await openTestNotification();
 expect(screen.queryByRole("option",{name:/不可选群聊/})).toBeNull();
 const send=screen.getByRole("button",{name:"确认发送单条测试卡片"});
 expect(send).toHaveProperty("disabled",true);
 fireEvent.click(screen.getByRole("button",{name:"生成无发送预览"}));await screen.findByTestId("notification-dry-run");
 expect(send).toHaveProperty("disabled",true);
 fireEvent.click(screen.getByRole("checkbox"));fireEvent.click(send);
 await waitFor(()=>expect(api).toHaveBeenCalledWith("/api/workbench/cases/TAP-case1/notify",{expected_version:1,mode:"test",recipient_id:"ou_test_person",preview_token:"opaque-preview-token"}));
 expect(await screen.findByText(/单条测试通知已入队；尚不代表发送成功/)).toBeTruthy();
 expect(screen.queryByText("通知已发送成功")).toBeNull();
});
it("does not allow sending if the original submitter mapping cannot be resolved",async()=>{
 await openTestNotification(false);
 fireEvent.click(screen.getByRole("button",{name:"生成无发送预览"}));await screen.findByTestId("notification-dry-run");
 expect(screen.getByRole("checkbox")).toHaveProperty("disabled",true);
 expect(screen.getByRole("button",{name:"确认发送单条测试卡片"})).toHaveProperty("disabled",true);
});
it("surfaces send rejection and clears the old confirmation instead of reporting success",async()=>{
 await openTestNotification(true,true);
 fireEvent.click(screen.getByRole("button",{name:"生成无发送预览"}));await screen.findByTestId("notification-dry-run");
 fireEvent.click(screen.getByRole("checkbox"));fireEvent.click(screen.getByRole("button",{name:"确认发送单条测试卡片"}));
 expect(await screen.findByRole("alert")).toHaveProperty("textContent","映射已更新，请重新预览");
 expect(screen.queryByTestId("notification-dry-run")).toBeNull();
 expect(screen.queryByText(/单条测试通知已入队；尚不代表发送成功/)).toBeNull();
});

it("defaults the inbox to the current window and exposes explicit history scope", async () => {
  render(<CaseworkInbox />);
  expect(await screen.findByText(/当前有效指标窗口 2026-10-01 至 2026-10-15/)).toBeTruthy();
  await waitFor(() =>
    expect(api).toHaveBeenCalledWith(expect.stringContaining("case_scope=current")),
  );
  fireEvent.change(screen.getByLabelText("台账事件范围"), {
    target: { value: "all" },
  });
  await waitFor(() =>
    expect(api).toHaveBeenCalledWith(expect.stringContaining("case_scope=all")),
  );
  expect(await screen.findByText(/全部历史事件（含旧试运行）/)).toBeTruthy();
});

it("RCA 仅推荐动作且动作下拉可覆盖，不默认客户教育", async () => {
  await open();
  const rca = screen.getByLabelText("RCA");
  const action = screen.getByLabelText("处置动作") as HTMLSelectElement;
  fireEvent.change(rca, { target: { value: "客户实锤违规" } });
  expect(action.value).toBe("tap_remove");
  fireEvent.change(action, { target: { value: "continue_observe" } });
  expect(action.value).toBe("continue_observe");
  expect(screen.queryByRole("option", { name: "客户教育" })).toBeNull();
  expect(screen.getByText("处理说明（选填）")).toBeTruthy();
});

it("compact submitter can override recommended action and uses original versioned command", async () => {
  const { CaseActions } = await import("./casework");
  render(<CaseActions id="TAP-case1" />);
  await screen.findByRole("button", {name:"确认动作完成并关闭"});
  expect(api.mock.calls.some(([,body])=>!!body)).toBe(false);
  expect(screen.queryByText("动作完成后提交复核")).toBeNull();
  fireEvent.change(screen.getByLabelText("RCA"), {target:{value:"客户实锤违规"}});
  expect((screen.getByLabelText("处置动作") as HTMLSelectElement).value).toBe("tap_remove");
  fireEvent.change(screen.getByLabelText("处置动作"), {target:{value:"continue_observe"}});
  fireEvent.click(screen.getByRole("button", {name:"确认动作完成并关闭"}));
  await waitFor(()=>expect(api).toHaveBeenCalledWith("/api/workbench/cases/TAP-case1/commands",expect.objectContaining({operation:"plan",expected_version:1,plan:"continue_observe",fields:{rca:"客户实锤违规"}})));
});

it("compact operator sees preview instead of submitter closure or role tabs", async () => {
  const original=api.getMockImplementation()!;
  api.mockImplementation(async(path:string,body?:unknown)=>path.endsWith("/casework/config") ? {data:{...config,is_operator:true,notification_mode:"test",recipients:[{id:"ou_test",type:"open_id",label:"测试人员"}]}} : original(path,body));
  const {CaseActions}=await import("./casework");
  render(<CaseActions id="TAP-case1" />);
  await screen.findByRole("button",{name:"生成无发送预览"});
  expect(screen.queryByRole("button",{name:"确认动作完成并关闭"})).toBeNull();
  expect(screen.queryByRole("tab",{name:"责任分派与通知"})).toBeNull();
  expect(api.mock.calls.some(([path])=>path.endsWith("/notify"))).toBe(false);
});
