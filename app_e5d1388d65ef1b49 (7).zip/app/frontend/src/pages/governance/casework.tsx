import { Alert, Button, Input, InputNumber, Modal, Radio, Select, Space, Switch, Table, Tag } from "@arco-design/web-react";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  workbenchBackfillsCreate,
  workbenchBackfillsList,
  workbenchIdentityMappingsByRecordIdEnabledUpdate,
  workbenchIdentityMappingsList,
  workbenchRiskPolicyList,
  workbenchRiskPolicyPreviewCreate,
  workbenchRiskPolicyRejudgementsList,
  workbenchRiskPolicyUpdate,
  workbenchRiskPolicyVersionsList,
} from "../../api/client.gen";
import { filterQuery, useSharedFilters } from "./shared-filters";
import { workbenchApi, fmt, type RiskRow, type Scan } from "./api";
import { ccr, nfs, revenue } from "./read-model";
import { ReportedReasonsView, reportedReasonGroups, type ReportedReasonGroup } from "./reported-reasons";
import "./casework.css";

type Field = { key: string; label: string; type?: string; required: boolean };
type Option = { id: string; label: string; status: string; fields: Field[] };
type Audit = {
  id: string;
  at: string;
  actor: string;
  source: string;
  operation: string;
  status: string;
  note: string;
  fields?: Record<string, string>;
  version: number;
};
export type Case = {
  id: string;
  version: number;
  kind: string;
  status: string;
  owner: string;
  creator: string;
  reviewer: string;
  row: RiskRow;
  window: Scan["request"];
  created_at: string;
  updated_at: string;
  plan: string;
  note: string;
  due_date: string;
  fields: Record<string, string>;
  action_completed: boolean;
  education_completed: boolean;
  review_requested_by: string;
  closure_reason: string;
  closed_at?: string;
  closed_by?: string;
  history: Audit[];
  rechecks: {
    at: string;
    start_date: string;
    end_date: string;
    ccr: number | null;
    nfs: number | null;
    level: string;
    status: string;
    comparability_note: string;
  }[];
};
type CaseConfig = {
  actor: string;
  is_operator: boolean;
  business_confirmed: boolean;
  version: string;
  workflow: Record<string, Option[]>;
  members: { username: string; display_name: string }[];
  recipients: { id: string; type: string; label: string }[];
  notification_mode: string;
  auto_send_enabled: boolean;
  integration: Record<string, unknown>;
};
type NotificationPreview = {
  dry_run: boolean;
  will_send: boolean;
  auto_send_enabled: boolean;
  notification_mode: string;
  alert_id: string;
  original_submitter: string;
  region: string;
  mapping_result: { status: string; reason: string; matched_alias?: string; email_masked?: string; sheet_revision?: string; record_id?: string; sheet_row?: number; record_version?: string };
  bot_resolution: { status: string; open_id_masked: string };
  actual_target: { status: string; type: string; id_masked: string; label: string; enterprise_email?: string; test_recipient_replacement: boolean };
  notice: string;
  case_version: number;
  preview_token?: string;
  confirmation_token: string;
  template_card?: Record<string, unknown>;
  confirmation_expires_in_seconds: number;
  presentation: {
    submitter: string; alert_type: string; alert_level: string; status: string; time_window: string; region: string; dimension_label: string; increase_label: string;
    account_id: string; account_name: string; advertiser_id: string; p0_ccr: number | null; p0_nfs: number | null; revenue: number | null;
    pre_ccr: number | null; post_ccr: number | null; ccr_growth_pct: number | null; comparison_reason: string;
    reported_reasons: ReportedReasonGroup[]; trigger_criteria: string[];
  };
};
type Notice = {
  id: string;
  kind: string;
  status: string;
  recipient: string;
  message_id: string;
  attempts: number;
  error: string;
  updated_at: string;
};
type Bundle = {
  cases: Case[];
  stats: Record<string, number>;
  as_of: string;
  report_note: string;
  case_scope?: "current" | "all";
  active_window?: { start_date: string; end_date: string };
};
export const caseLabels: Record<string, string> = {
  open: "待接单",
  processing: "处理中",
  observing: "持续观察",
  pending_approval: "待审批",
  pending_review: "待复核",
  closed: "已关闭",
};
const opLabels: Record<string, string> = {
  create: "建立事件",
  accept: "接受任务",
  assign: "责任分派",
  plan: "保存处置方案",
  complete: "提交动作完成",
  approve: "审批通过",
  return: "退回跟进",
  close: "复核关闭",
  reopen: "重新打开",
  recheck: "指标复查",
  notify: "申请通知",
};
const closureLabels: Record<string, string> = {
  risk_recovered: "真实复查达标，风险恢复",
  false_positive: "确认误报",
  not_applicable: "确认不适用",
  policy_exception: "有依据的政策例外",
};
export const rcaByPlan: Record<string, string> = {
  tap_remove: "客户实锤违规",
  update_threshold: "预警阈值问题",
  continue_observe: "无任何风险",
};
export const planByRca: Record<string, string> = {
  客户实锤违规: "tap_remove",
  预警阈值问题: "update_threshold",
  无任何风险: "continue_observe",
};
const requestId = () =>
  globalThis.crypto?.randomUUID?.() ||
  `web-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const errorText = (e: unknown) => (e instanceof Error ? e.message : "请求失败");

export function CaseworkInbox({
  reportOnly = false,
  onCasesChange,
  focusAlertId,
}: {
  focusAlertId?: string;
  reportOnly?: boolean;
  onCasesChange?: (cases: Case[]) => void;
}) {
  const { filters } = useSharedFilters();
  const [bundle, setBundle] = useState<Bundle>();
  const [config, setConfig] = useState<CaseConfig>();
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(
    () => new URLSearchParams(location.search).get("alert_id") || "",
  );
  const [query, setQuery] = useState(""),
    [settingsOpen, setSettingsOpen] = useState(false),
    [caseScope, setCaseScope] = useState<"current" | "all">("current");
  const refresh = useCallback(async () => {
    try {
      const queryValues = { ...filterQuery(filters), case_scope: caseScope };
      const queryString = new URLSearchParams(Object.entries(queryValues).map(([key, value]) => [key, String(value)])).toString();
      const res = await workbenchApi<{ data: Bundle }>(`/api/workbench/cases${queryString ? `?${queryString}` : ""}`);
      const data = res.data;
      setBundle(data);
      setError("");
      onCasesChange?.(data.cases);
    } catch (e) {
      setError(errorText(e));
    }
  }, [filters, caseScope, onCasesChange]);
  useEffect(() => {
    let mounted = true;
    void workbenchApi<{ data: CaseConfig }>("/api/workbench/casework/config")
      .then((r) => {
        if (mounted) setConfig(r.data);
      })
      .catch((e) => {
        if (mounted) setError(errorText(e));
      });
    void refresh();
    const t = setInterval(() => void refresh(), 5000);
    return () => {
      mounted = false;
      clearInterval(t);
    };
  }, [refresh]);
  useEffect(() => { if (focusAlertId) { setSelected(focusAlertId); setSettingsOpen(false); } }, [focusAlertId]);
  const visible = (bundle?.cases || []).filter((a) => {
    const haystack = `${a.id} ${a.row.member.account_name} ${a.row.member.account_id} ${a.row.member.advertiser_id} ${a.owner} ${a.row.member.region}`.toLowerCase();
    const localQuery = query.trim().toLowerCase();
    return !localQuery || haystack.includes(localQuery);
  });
  function download() {
    if (!bundle) return;
    const blob = new Blob([JSON.stringify(bundle, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "TAP_shared_case_report.json";
    link.click();
    URL.revokeObjectURL(url);
  }
  return (
    <section className="tg-card cw-inbox" data-testid="casework-inbox">
      <div className="tg-cardhead">
        <div>
          <h2>{reportOnly ? "预警处置过程报告" : "预警处置收件箱"}</h2>
          <p>{caseScope === "current" ? `当前有效指标窗口${bundle?.active_window?.start_date ? ` ${bundle.active_window.start_date} 至 ${bundle.active_window.end_date}` : ""}` : "全部历史事件（含旧试运行）"} · 每5秒同步</p>
        </div>
        <div className="tg-inline">
          {config?.is_operator && (
            <button className="tg-btn" onClick={() => location.assign(`${location.pathname}?view=analysis`)}>
              治理分析
            </button>
          )}
          {config?.is_operator && (
            <button className="tg-btn" onClick={() => setSettingsOpen((value) => !value)}>
              {settingsOpen ? "返回处置列表" : "管理设置"}
            </button>
          )}
          <button className="tg-btn" onClick={() => void refresh()}>
            刷新台账
          </button>
          {bundle && (
            <button className="tg-btn" onClick={download}>
              导出处置报告
            </button>
          )}
        </div>
      </div>
      {config?.is_operator && settingsOpen && <FeishuCredentialSettings />}
      {settingsOpen ? null : <>
      {error && (
        <p className="cw-error" role="alert">
          台账读取失败：{error}
        </p>
      )}
      <details className="ops-disclosure cw-statistics"><summary>台账统计与说明</summary><div className="cw-metrics">
        {[
          ["total", "预警事件"],
          ["pending_review", "待复核"],
          ["action_completed", "动作完成"],
          ["risk_recovered", "复查恢复并关闭"],
          ["overdue", "已逾期"],
          ["notification_sent", "通知已发送"],
        ].map(([k, label]) => (
          <div key={k}>
            <span>{label}</span>
            <strong>{bundle?.stats[k] ?? "—"}</strong>
          </div>
        ))}
      </div>
      <p className="tg-muted">
        {bundle?.report_note ||
          "处置数据尚未加载。动作完成与风险恢复分别统计。"}
      </p></details>
      {!reportOnly && (
        <>
          <details className="ops-disclosure cw-extra-filters"><summary>更多台账筛选</summary><div className="cw-filter">
            <label>
              事件范围
              <select aria-label="台账事件范围" value={caseScope} onChange={(e) => setCaseScope(e.target.value as "current" | "all")}>
                <option value="current">当前有效窗口</option>
                <option value="all">全部历史（含试运行）</option>
              </select>
            </label>
            <p className="tg-muted" style={{ padding: '8px 12px' }}>
              更多字段（等级、状态、产生日期、项目、区域、提报人）请使用页面顶部的「四页共享筛选」。
            </p>
            <label>
              局部查找
              <input
                placeholder="Alert ID / 负责人 / 区域"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </label>
          </div></details>
          <div className="cw-tablewrap">
            <table className="cw-table">
              <thead>
                <tr>
                  <th>Account / Advertiser 摘要</th>
                  <th>Tier / Region / Submitter</th>
                  <th>指标值 / 风险原因 / 窗口</th>
                  <th>负责人</th>
                  <th>处理阶段</th>
                  <th>截止日期</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((a) => (
                  <tr key={a.id}>
                    <td>
                      <strong>
                        {a.row.member.account_name ||
                          a.row.member.account_id ||
                          a.row.member.advertiser_id}
                      </strong>
                      <small>{a.id}</small>
                      <small>Account {a.row.member.account_id || "N/A"} · Advertiser {a.row.advertiser_count || 0} 个</small>
                      <small>{a.row.advertiser_top10?.[0]?.advertiser_id ? `Top: ${a.row.advertiser_top10[0].advertiser_id}` : "Advertiser 明细 N/A"}</small>
                    </td>
                    <td>
                      {a.row.member.tier || a.row.program} / {a.row.member.region || "N/A"}
                      <small>{a.row.member.submitter || "Submitter N/A"}</small>
                    </td>
                    <td>
                      CCR {fmt(a.row.ccr)} / NFS {fmt(a.row.nfs)} / Revenue {fmt(a.row.revenue)}
                      <small>{a.row.reasons?.join("；") || "风险原因 N/A"}</small>
                      <small>{a.window.start_date} 至 {a.window.end_date}</small>
                    </td>
                    <td>{a.owner}</td>
                    <td>
                      <span className="tg-badge">{caseLabels[a.status]}</span>
                    </td>
                    <td>{a.due_date || "待制定"}</td>
                    <td>
                      <button
                        className="tg-btn"
                        onClick={() => setSelected(a.id)}
                      >
                        处理事件
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {bundle && visible.length === 0 && (
              <p className="tg-empty">
                暂无符合条件的事件。真实扫描命中会进入台账，也可从客户详情加入。
              </p>
            )}
          </div>
        </>
      )}
      {selected && config && !reportOnly && (
        <div className="cw-detailbox">
          <div className="tg-cardhead">
            <h3>事件处理</h3>
            <button className="tg-btn" onClick={() => setSelected("")}>
              收起事件
            </button>
          </div>
          <CaseDetail
            id={selected}
            config={config}
            onSaved={() => void refresh()}
          />
        </div>
      )}
      </>}
    </section>
  );
}
export function CaseworkFromScan({ row, scan }: { row: RiskRow; scan?: Scan }) {
  const [id, setId] = useState(""),
    [config, setConfig] = useState<CaseConfig>(),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function open() {
    if (!scan) return;
    setBusy(true);
    setError("");
    try {
      const c = await workbenchApi<{ data: CaseConfig }>(
        "/api/workbench/casework/config",
      );
      const result = await workbenchApi<{ data: Case }>(
        "/api/workbench/cases",
        { scan_id: scan.id, row_id: row.id },
      );
      setConfig(c.data);
      setId(result.data.id);
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <section>
      <h3>预警处置与复核</h3>
      {error && (
        <p className="cw-error" role="alert">
          {error}
        </p>
      )}
      {!id && (
        <>
          <p>进入共享事件，分派负责人、制定动作、提交凭证、复查及复核关闭。</p>
          <button
            className="tg-btn primary"
            disabled={busy || !scan || scan.status === "running"}
            onClick={() => void open()}
          >
            {busy ? "打开中…" : "打开共享处置"}
          </button>
        </>
      )}
      {id && config && <CaseDetail id={id} config={config} />}
    </section>
  );
}
function NotificationPresentation({ preview }: { preview: NotificationPreview }) {
  const p = preview.presentation;
  if (!p) return null;
  return <div data-testid="notification-structured-content">
    <p>Submitter：{p.submitter || "—"}</p><p>Alert Type：{p.alert_type || "—"}</p><p>Alert Level：{p.alert_level || "—"}</p><p>Status：{p.status || "—"}</p>
    <p>Time Window：{p.time_window || "—"}</p><p>Region：{p.region || "—"}</p><p>Account ID / Account Name：{[p.account_id, p.account_name].filter(Boolean).join(" / ") || "—"}</p><p>Advertiser ID：{p.advertiser_id || "—"}</p>
    <p><strong>{p.dimension_label || "Account Level"}</strong></p><p>P0 CCR：{ccr(p.p0_ccr)} · P0 NFS：{nfs(p.p0_nfs)} · Revenue：{revenue(p.revenue)}</p>
    <p>Pre → Post P0 CCR：{ccr(p.pre_ccr)} → {ccr(p.post_ccr)} · {p.increase_label || "WoW CCR Increase"}：{p.ccr_growth_pct == null ? "—" : `${p.ccr_growth_pct.toFixed(2)}%`}</p>{p.comparison_reason && <p>{p.comparison_reason}</p>}
    <div><strong>Reported Reasons</strong><ReportedReasonsView groups={p.reported_reasons || []} /></div>
    <p><strong>Trigger Criteria</strong>：{p.trigger_criteria?.join("；") || "—"}</p>
  </div>;
}

function CaseDetail({
  id,
  config,
  onSaved,
  compact = false,
  showEvidence = true,
}: {
  id: string;
  config: CaseConfig;
  compact?: boolean;
  showEvidence?: boolean;
  onSaved?: () => void;
}) {
  const [a, setA] = useState<Case>(),
    [notices, setNotices] = useState<Notice[]>([]),
    [permissions, setPermissions] = useState({ can_handle: false, can_review: false }),
    [tab, setTab] = useState("plan");
  const [error, setError] = useState(""),
    [success, setSuccess] = useState(""),
    [preview, setPreview] = useState<NotificationPreview>(),
    [sendConfirmed, setSendConfirmed] = useState(false),
    [busy, setBusy] = useState(false);
  const [plan, setPlan] = useState(""),
    [fields, setFields] = useState<Record<string, string>>({}),
    [note, setNote] = useState(""),
    [baseVersion, setBaseVersion] = useState(0);
  const [owner, setOwner] = useState(""),
    [reviewer, setReviewer] = useState(""),
    [recipient, setRecipient] = useState(""),
    [notificationMode, setNotificationMode] = useState<"test" | "formal">(config.notification_mode === "formal" ? "formal" : "test"),
    [closure, setClosure] = useState("risk_recovered");
  const [start, setStart] = useState(""),
    [end, setEnd] = useState(""),
    [comparison, setComparison] = useState("");
  const savedCallback = useRef(onSaved); savedCallback.current = onSaved;
  const initDraft = useCallback(
    (c: Case) => {
      setBaseVersion(c.version);
      setPlan(c.plan || config.workflow[c.kind]?.[0]?.id || "");
      const selectedPlan = c.plan || "";
      setFields({ ...(c.fields || {}), ...(!c.fields?.rca && rcaByPlan[selectedPlan] ? { rca: rcaByPlan[selectedPlan] } : {}) });
      setNote(c.note || "");
      setOwner(c.owner);
      setReviewer(c.reviewer);
    },
    [config.workflow],
  );
  useEffect(() => {
    let alive = true;
    let initialized = false;
    let lastSnapshot = "";
    const refresh = async () => {
      try {
        const res = await workbenchApi<{ data: Case; notifications: Notice[]; permissions: { can_handle: boolean; can_review: boolean } }>(
          `/api/workbench/cases/${encodeURIComponent(id)}`,
        );
        if (!alive) return;
        const nextSnapshot = JSON.stringify([res.data.version, res.notifications || []]);
        if (lastSnapshot && lastSnapshot !== nextSnapshot) savedCallback.current?.();
        lastSnapshot = nextSnapshot;
        setA(res.data);
        setNotices(res.notifications || []);
        setPermissions(res.permissions || { can_handle: false, can_review: false });
        if (!initialized) {
          initDraft(res.data);
          initialized = true;
        }
      } catch (e) {
        if (alive) setError(errorText(e));
      }
    };
    void refresh();
    const t = setInterval(() => void refresh(), 5000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [id, initDraft]);
  async function command(operation: string) {
    if (!a) return;
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      const r = await workbenchApi<{ data: Case }>(
        `/api/workbench/cases/${a.id}/commands`,
        {
          expected_version: baseVersion,
          request_id: requestId(),
          operation,
          plan,
          note,
          fields,
          owner,
          reviewer,
          closure_reason: closure,
        },
      );
      setA(r.data);
      initDraft(r.data);
      setSuccess(operation === "plan" && r.data.status === "closed" ? "处置记录已原子保存，预警已直接关闭。" : "已保存，飞书卡片如已发送将异步同步。");
      onSaved?.();
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  async function loadNotificationPreview() {
    if (!a) return;
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      setPreview(undefined);
      setSendConfirmed(false);
      const r = await workbenchApi<{ data: NotificationPreview }>(`/api/workbench/cases/${encodeURIComponent(a.id)}/notification-preview`, {
        mode: notificationMode,
        recipient_id: recipient || undefined,
      });
      setPreview(r.data);
      setSuccess("无发送预览已更新：仅解析目标，本次不会发送任何消息。");
    } catch (e) {
      setPreview(undefined);
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  async function sendTestNotification() {
    if (!a || !preview || !sendConfirmed || !preview.confirmation_token) return;
    setBusy(true); setError(""); setSuccess("");
    try {
      const r = await workbenchApi<{data:Case;deduplicated:boolean;message:string}>(`/api/workbench/cases/${encodeURIComponent(a.id)}/notify`, {
        expected_version: preview.case_version,
        mode: preview.notification_mode,
        recipient_id: recipient,
        preview_token: preview.preview_token || preview.confirmation_token,
      });
      setA(r.data); initDraft(r.data);
      setPreview(undefined); setSendConfirmed(false);
      setSuccess(r.deduplicated ? "该通知已存在，未重复发送；请查看下方通知结果。" : `单条${preview.notification_mode === "formal" ? "正式" : "测试"}通知已入队；尚不代表发送成功，请等待下方返回 message_id。`);
      onSaved?.();
    } catch(e) { setError(errorText(e)); setPreview(undefined); setSendConfirmed(false); }
    finally { setBusy(false); }
  }
  async function recheck() {
    if (!a) return;
    setBusy(true);
    setError("");
    try {
      const r = await workbenchApi<{ data: Case }>(
        `/api/workbench/cases/${a.id}/rechecks`,
        {
          expected_version: baseVersion,
          start_date: start,
          end_date: end,
          comparability_note: comparison,
        },
      );
      setA(r.data);
      initDraft(r.data);
      setSuccess("复查记录已保存；请查看真实查询状态和指标。");
      onSaved?.();
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  if (!a) return <p>{error || "正在加载事件…"}</p>;
  const options = config.workflow[a.kind] || [],
    chosen = options.find((o) => o.id === plan);
  const canHandle = permissions.can_handle;
  const canReview = permissions.can_review;
  const stale = baseVersion !== a.version;
  const setField = (key: string, value: string) =>
    setFields((f) => ({ ...f, [key]: value }));
  const cmp = (a.row as RiskRow & { comparison?: { pre_ccr: number | null; post_ccr: number | null; ccr_growth_pct?: number | null; increase_fact?: { value?: number | null; status?: string; reason?: string }; status: string; missing_reason?: string } }).comparison;
  const notified = notices.some((n) => n.kind === "send" && n.status === "sent" && !!n.message_id);
  const showNotification = config.is_operator && !notified && a.status !== "closed";
  if (compact) return <section className="cw-detail cw-compact" data-testid="case-detail">
    <div className="ops-detail-section-head"><h3>{a.status === "closed" ? "已完成处置" : showNotification ? "确认通知提报人" : "提报人处理"}</h3><code>{a.id}</code></div>
    {showEvidence && <section><h2>{a.row.member.account_name || a.row.member.account_id || a.row.member.advertiser_id}</h2><p>{a.row.program} · {a.row.program === "THT" ? "Advertiser Level" : "Account Level"} · {a.row.member.region || "—"} · {a.window.start_date} 至 {a.window.end_date}</p><div className="ops-detail-metrics">{[["P0 CCR",fmt(a.row.ccr)],["P0 NFS",fmt(a.row.nfs)],["Revenue",fmt(a.row.revenue)],["Pre → Post P0 CCR",cmp ? `${fmt(cmp.pre_ccr)} → ${fmt(cmp.post_ccr)}` : "—"],[a.row.program === "ST" ? "QoQ CCR Increase" : "WoW CCR Increase",cmp?.status === "available" ? `${fmt(cmp.increase_fact?.value ?? cmp.ccr_growth_pct ?? null)}%` : `—${cmp?.missing_reason ? ` · ${cmp.missing_reason}` : ""}`]].map(([label,value]) => <div key={label}><span>{label}</span><b>{value}</b></div>)}</div><p>{a.row.reasons?.join("；")}</p><details><summary>高 CCR Adv Top10</summary>{(a.row.advertisers || a.row.advertiser_top10 || []).filter(x=>x.ccr!=null&&x.nfs!=null&&x.ccr>=0&&x.nfs>=0).sort((x,y)=>(y.ccr ?? 0)-(x.ccr ?? 0)).slice(0,10).map(x=><p key={x.advertiser_id}>{x.advertiser_id} · {x.advertiser_name || "—"} · CCR {fmt(x.ccr)} · NFS {fmt(x.nfs)} · Revenue {fmt(x.revenue)}</p>)}</details></section>}
    <p>原提报人 {a.row.member.submitter || "—"} · 当前负责人 {a.owner || "—"}</p>
    {error && <p role="alert" className="cw-error">{error}</p>}
    {success && <p role="status" className="cw-success">{success}</p>}
    {stale && <p className="cw-hint">事件已被更新，请先<button className="tg-btn" onClick={() => initDraft(a)}>载入最新记录</button></p>}
    {a.status === "closed" ? <div className="cw-audit"><b>{a.fields?.rca || "—"} · {options.find(o => o.id === a.plan)?.label || a.plan}</b><p>{a.note || "无补充说明"}</p><small>{a.closed_by || "—"} · {a.closed_at || "—"}</small></div> : showNotification ? <div className="cw-form">
          <h4>飞书通知无发送预览</h4>
          <label>
            预览与单条确认模式
            <select value={notificationMode} onChange={(e) => {setNotificationMode(e.target.value as "test" | "formal");setPreview(undefined);setSendConfirmed(false)}}>
              <option value="test">测试模式（仅白名单）</option>
              <option value="formal">正式模式（真实负责人，仅单条确认）</option>
            </select>
          </label>
          <label>
            测试模式实际目标（正式模式忽略）
            <select
              value={recipient}
              onChange={(e) => {setRecipient(e.target.value);setPreview(undefined);setSendConfirmed(false)}}
            >
              <option value="">请选择已配置的测试人员</option>
              {config.recipients.filter((r) => r.type === "open_id").map((r) => (
                <option key={r.type + r.id} value={r.id}>
                  {r.label} · {r.type}
                </option>
              ))}
            </select>
          </label>
          <button
            className="tg-btn primary"
            disabled={busy || (notificationMode === "test" && !recipient)}
            onClick={() => void loadNotificationPreview()}
          >
            {busy ? "正在刷新映射并解析…" : "生成无发送预览"}
          </button>
          <p className="tg-muted">
            通知模式：{notificationMode}；自动发送门禁：
            {config.auto_send_enabled ? "已开启" : "关闭"}。预览只刷新权威 Sheet、解析 Bot 域 open_id，不调用发送 API。
          </p>
          {preview && <div className="cw-audit" data-testid="notification-dry-run">
            <strong>{preview.alert_id} · {preview.mapping_result.status} · {preview.actual_target.status}</strong>
            <NotificationPresentation preview={preview} />
            <p>原提报人：{preview.original_submitter || "缺失"} · Region：{preview.region || "缺失"}</p>
            <p>精确匹配：{preview.mapping_result.matched_alias || "—"} · {preview.mapping_result.email_masked || "***"} · {preview.mapping_result.reason}</p>
            <p>Bot 解析：{preview.bot_resolution.status} · {preview.bot_resolution.open_id_masked || "***"}</p>
            <p>实际目标：{preview.actual_target.label || preview.actual_target.type || "无"} · {preview.actual_target.enterprise_email || "企业邮箱未提供"} · {preview.actual_target.id_masked || "***"}</p>
            <p>模式：{preview.notification_mode === "test" ? "测试（仅白名单）" : "正式（真实负责人）"} · 事件链接：<a href={`?view=tasks&alert_id=${encodeURIComponent(preview.alert_id)}`}>打开事件</a></p>
            <details><summary>完整消息内容</summary><pre>{JSON.stringify(preview.template_card || {}, null, 2)}</pre></details>
            <small>{preview.notice}<br/>Sheet revision {preview.mapping_result.sheet_revision || "—"} · row {preview.mapping_result.sheet_row || "—"} · version {preview.mapping_result.record_version || "—"}</small>
          </div>}
          <>
            <label><input type="checkbox" checked={sendConfirmed} onChange={e=>setSendConfirmed(e.target.checked)} disabled={!preview?.confirmation_token || preview.case_version!==a.version || busy}/>我确认{notificationMode === "test" ? "仅向上方测试白名单" : "仅向预览展示的真实负责人"}发送一条{notificationMode === "test" ? " TEST" : "正式"}风险卡片；失败后需重新预览并确认重试。</label>
            <button className="tg-btn primary" disabled={busy || !sendConfirmed || !preview?.confirmation_token || preview.case_version!==a.version || preview.actual_target.status!==(notificationMode === "test" ? "ready_test_allowlist" : "ready_formal")} onClick={()=>void sendTestNotification()}>确认发送单条{notificationMode === "test" ? "测试" : "正式"}卡片</button>
            <p className="tg-muted">预览有效期 10 分钟。提报人映射、事件或 Bot 配置变化时会阻止发送。正式批量与自动发送保持禁用；排队中、发送失败均不代表通知已送达。</p>
          </>
          <details>
            <summary>集成配置状态</summary>
            {Object.entries(config.integration)
              .filter(([k]) => k.endsWith("configured"))
              .map(([k, v]) => (
                <p key={k}>
                  {k}：{v ? "已配置" : "待配置"}
                </p>
              ))}
          </details>
          {notices.map((n) => (
            <div className="cw-audit" key={n.id}>
              <strong>
                {n.kind === "send" ? "发送" : "卡片同步"} · {n.status}
              </strong>
              <p>
                {n.recipient} · 尝试 {n.attempts} 次
              </p>
              <small>
                message_id: {n.message_id || "尚未返回"}
                <br />
                更新时间: {n.updated_at || "—"}
                <br />
                {n.error}
              </small>
            </div>
          ))}
</div> : <div className="cw-form">
          <label>
            RCA
            <select
              aria-label="RCA"
              value={fields.rca || ""}
              onChange={(e) => {
                const rca = e.target.value;
                setField("rca", rca);
                const recommended = planByRca[rca];
                if (recommended && options.some((option) => option.id === recommended)) setPlan(recommended);
              }}
            >
              <option value="">请选择 RCA</option>
              {Object.keys(planByRca).map((rca) => <option key={rca} value={rca}>{rca}</option>)}
            </select>
            <small className="tg-muted">选择后仅推荐默认动作；下方动作仍可修改。</small>
          </label>
          <label>
            实际动作
            <select
              aria-label="处置动作"
              value={plan}
              onChange={(e) => setPlan(e.target.value)}
            >
              {options.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.label}
                </option>
              ))}
            </select>
          </label>
          {chosen?.fields.filter((f) => f.key !== "rca").map((f) => (
            <label key={f.key}>
              {f.label}
              {f.required && " *"}
              <input
                aria-label={f.label}
                type={f.type === "date" ? "date" : "text"}
                disabled={f.key === "rca"}
                value={fields[f.key] || ""}
                onChange={(e) => setField(f.key, e.target.value)}
              />
            </label>
          ))}
          <label>
            处理说明（选填）
            <textarea
              aria-label="共享处理记录"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="可补充核查结论、实际动作与下一步"
            />
          </label>
          <div className="cw-buttons">
            <button
              className="tg-btn primary"
              disabled={busy || stale || !canHandle || !fields.rca || !plan || a.status === "closed"}
              onClick={() => void command("plan")}
            >
              确认动作完成并关闭
            </button>
          </div>
<p className="tg-muted">动作完成后直接关闭事件；关闭不等于 CCR/NFS 已改善，也不会自动执行 TAP 移除或修改阈值。</p></div>}
    <details><summary>事件记录（{a.history.length}）</summary>{[...a.history].reverse().map((ev,i) => <article className="cw-audit" key={ev.id || i}><b>{opLabels[ev.operation] || ev.operation}</b><p>{ev.actor} · {ev.at}</p><small>{ev.note}</small></article>)}</details>
  </section>;
  return (
    <div className="cw-detail" data-testid="case-detail">
      <div className="cw-summary">
        <div>
          <strong>{a.id}</strong>
          <span className="tg-badge">
            {caseLabels[a.status]} · v{a.version}
          </span>
        </div>
        <p>
          负责人 {a.owner} · 复核人 {a.reviewer || "待分派"}
        </p>
        <p>
          {a.row.program} / {a.row.member.region} · Account CCR {fmt(a.row.ccr)} / NFS{" "}
          {fmt(a.row.nfs)} / Revenue {fmt(a.row.revenue)} · {a.window.start_date} 至 {a.window.end_date}
        </p>
        <p>{a.row.account_ccr_status || a.row.aggregation_note}</p>
        {a.status === "closed" && <p>最终 RCA {a.fields?.rca || "—"} · 实际动作 {options.find((option) => option.id === a.plan)?.label || a.plan || "—"} · 处理人 {a.closed_by || "—"} · 完成时间 {a.closed_at || "—"}</p>}
      </div>
      <section className="cw-evidence" data-testid="advertiser-evidence">
        <h4>关联 Advertiser 风险明细（{a.row.advertiser_count || 0}）</h4>
        <div className="cw-tablewrap"><table className="cw-table"><thead><tr><th>Advertiser ID / Account ID</th><th>P0 CCR</th><th>P0 NFS</th><th>Revenue</th><th>Reported Reasons</th><th>Trigger Criteria</th></tr></thead><tbody>{(a.row.advertisers || []).map((item) => <tr key={`${item.account_id}-${item.advertiser_id}`}><td><strong>{item.advertiser_id || "—"}</strong><small>{item.account_id || "—"}</small></td><td>{ccr(item.ccr)}</td><td>{nfs(item.nfs)}</td><td>{revenue(item.revenue)}</td><td><ReportedReasonsView groups={reportedReasonGroups([item])} /></td><td>{item.reasons?.join("；") || "—"}</td></tr>)}</tbody></table>{!a.row.advertisers?.length && <p className="tg-empty">Advertiser 明细不可用；缺失值不补 0。</p>}</div>
      </section>
      {!config.business_confirmed && (
        <p className="cw-hint">
          试运行处置模板，待业务确认。移除审批仅记录申请与执行凭证，不自动改变TAP保护状态。
        </p>
      )}
      <div className="cw-tabs" role="tablist">
        {[
          ["plan", "核查与处置"],
          ["review", "复查与复核"],
          ["notify", "责任分派与通知"],
          ["history", "操作记录"],
        ].map(([key, label]) => (
          <button
            role="tab"
            aria-selected={tab === key}
            className={tab === key ? "active" : ""}
            key={key}
            onClick={() => setTab(key)}
          >
            {label}
          </button>
        ))}
      </div>
      {error && (
        <p className="cw-error" role="alert">
          {error}
        </p>
      )}
      {success && (
        <p className="cw-success" role="status">
          {success}
        </p>
      )}
      {stale && (
        <p className="cw-hint">
          其他入口已更新到 v{a.version}，当前表单基于 v{baseVersion}。
          <button
            className="tg-btn"
            onClick={() => {
              initDraft(a);
              setError("");
            }}
          >
            载入最新记录
          </button>
        </p>
      )}
      {tab === "plan" && (
        <div className="cw-form">
          <label>
            RCA
            <select
              aria-label="RCA"
              value={fields.rca || ""}
              onChange={(e) => {
                const rca = e.target.value;
                setField("rca", rca);
                const recommended = planByRca[rca];
                if (recommended && options.some((option) => option.id === recommended)) setPlan(recommended);
              }}
            >
              <option value="">请选择 RCA</option>
              {Object.keys(planByRca).map((rca) => <option key={rca} value={rca}>{rca}</option>)}
            </select>
            <small className="tg-muted">选择后仅推荐默认动作；下方动作仍可修改。</small>
          </label>
          <label>
            实际动作
            <select
              aria-label="处置动作"
              value={plan}
              onChange={(e) => setPlan(e.target.value)}
            >
              {options.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.label}
                </option>
              ))}
            </select>
          </label>
          {chosen?.fields.filter((f) => f.key !== "rca").map((f) => (
            <label key={f.key}>
              {f.label}
              {f.required && " *"}
              <input
                aria-label={f.label}
                type={f.type === "date" ? "date" : "text"}
                disabled={f.key === "rca"}
                value={fields[f.key] || ""}
                onChange={(e) => setField(f.key, e.target.value)}
              />
            </label>
          ))}
          <label>
            处理说明（选填）
            <textarea
              aria-label="共享处理记录"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="可补充核查结论、实际动作与下一步"
            />
          </label>
          <div className="cw-buttons">
            {a.status === "open" && (
              <button
                className="tg-btn"
                disabled={busy || stale || !canHandle}
                onClick={() => void command("accept")}
              >
                接受任务
              </button>
            )}
            <button
              className="tg-btn primary"
              disabled={busy || stale || !canHandle || a.status === "closed"}
              onClick={() => void command("plan")}
            >
              保存处置方案
            </button>
          </div>
          <hr />
          <h4>动作完成后提交复核</h4>
          <label>
            完成凭证 *
            <textarea
              aria-label="完成凭证"
              value={fields.evidence || ""}
              onChange={(e) => setField("evidence", e.target.value)}
              placeholder="沟通记录、整改证据、审批后的执行记录"
            />
          </label>
          <button
            className="tg-btn"
            disabled={
              busy ||
              stale ||
              !canHandle ||
              !["processing", "observing"].includes(a.status)
            }
            onClick={() => void command("complete")}
          >
            提交完成，等待复核
          </button>
          <p className="tg-muted">
            沟通完成：{a.education_completed ? "已记录" : "尚未记录"}
            ；动作完成：{a.action_completed ? "已记录" : "尚未记录"}；风险恢复：
            {a.closure_reason === "risk_recovered" ? "已复核确认" : "尚未确认"}
          </p>
        </div>
      )}
      {tab === "review" && (
        <div className="cw-form">
          <h4>独立窗口真实指标复查</h4>
          <div className="cw-grid">
            <label>
              复查开始
              <input
                aria-label="复查开始"
                type="date"
                value={start}
                onChange={(e) => setStart(e.target.value)}
              />
            </label>
            <label>
              复查结束
              <input
                aria-label="复查结束"
                type="date"
                value={end}
                onChange={(e) => setEnd(e.target.value)}
              />
            </label>
          </div>
          <label>
            窗口可比性说明
            <textarea
              value={comparison}
              onChange={(e) => setComparison(e.target.value)}
              placeholder="窗口为何能代表处置后的表现、数据延迟及样本差异"
            />
          </label>
          <button
            className="tg-btn"
            disabled={busy || stale || !canHandle || a.status === "closed"}
            onClick={() => void recheck()}
          >
            {busy ? "处理中…" : "查询并保存真实复查"}
          </button>
          <p className="tg-muted">
            用于确认恢复的复查需在原报警窗口结束后、处置发生后；仅使用已结束日期。复查不会自动关闭。
          </p>
          {a.rechecks.map((r, i) => (
            <div className="cw-audit" key={i}>
              <strong>
                {r.start_date} 至 {r.end_date} · {r.status}
              </strong>
              <p>
                CCR {fmt(r.ccr)} / NFS {fmt(r.nfs)} · {r.level}
              </p>
              <small>{r.comparability_note}</small>
            </div>
          ))}
          <hr />
          <h4>审批与结案</h4>
          <label>
            复核记录 *
            <textarea value={note} onChange={(e) => setNote(e.target.value)} />
          </label>
          <label>
            复核依据 *
            <textarea
              value={fields.evidence || ""}
              onChange={(e) => setField("evidence", e.target.value)}
            />
          </label>
          <label>
            关闭依据
            <select
              value={closure}
              onChange={(e) => setClosure(e.target.value)}
            >
              {Object.entries(closureLabels).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </label>
          <div className="cw-buttons">
            {a.status === "pending_approval" && (
              <button
                className="tg-btn"
                disabled={busy || stale || !config.is_operator}
                onClick={() => void command("approve")}
              >
                批准申请，待执行确认
              </button>
            )}
            {["pending_review", "pending_approval"].includes(a.status) && (
              <button
                className="tg-btn"
                disabled={busy || stale || !canReview}
                onClick={() => void command("return")}
              >
                退回继续跟进
              </button>
            )}
            {a.status === "pending_review" && (
              <button
                className="tg-btn primary"
                disabled={
                  busy ||
                  stale ||
                  !canReview ||
                  config.actor === a.review_requested_by
                }
                onClick={() => void command("close")}
              >
                复核通过并关闭
              </button>
            )}
            {a.status === "closed" && (
              <button
                className="tg-btn"
                disabled={busy || stale || !config.is_operator}
                onClick={() => void command("reopen")}
              >
                重新打开
              </button>
            )}
          </div>
          <p className="tg-muted">
            提交人与关闭复核人须为不同账号。关闭依据：
            {closureLabels[a.closure_reason] || "未关闭"}
          </p>
        </div>
      )}
      {tab === "notify" && (
        <div className="cw-form">
          <h4>责任分派</h4>
          <label>
            当前负责人
            <select value={owner} onChange={(e) => setOwner(e.target.value)}>
              {![...config.members.map((m) => m.username)].includes(owner) && (
                <option>{owner}</option>
              )}
              {config.members.map((m) => (
                <option key={m.username} value={m.username}>
                  {m.display_name || m.username}
                </option>
              ))}
            </select>
          </label>
          <label>
            复核人
            <select
              value={reviewer}
              onChange={(e) => setReviewer(e.target.value)}
            >
              <option value="">待分派</option>
              {config.members.map((m) => (
                <option key={m.username} value={m.username}>
                  {m.display_name || m.username}
                </option>
              ))}
            </select>
          </label>
          <label>
            分派说明
            <textarea value={note} onChange={(e) => setNote(e.target.value)} />
          </label>
          <button
            className="tg-btn"
            disabled={busy || stale || !config.is_operator}
            onClick={() => void command("assign")}
          >
            保存分派
          </button>
          <hr />
          <h4>飞书通知无发送预览</h4>
          <label>
            预览与单条确认模式
            <select value={notificationMode} onChange={(e) => {setNotificationMode(e.target.value as "test" | "formal");setPreview(undefined);setSendConfirmed(false)}}>
              <option value="test">测试模式（仅白名单）</option>
              <option value="formal">正式模式（真实负责人，仅单条确认）</option>
            </select>
          </label>
          <label>
            测试模式实际目标（正式模式忽略）
            <select
              value={recipient}
              onChange={(e) => {setRecipient(e.target.value);setPreview(undefined);setSendConfirmed(false)}}
            >
              <option value="">请选择已配置的测试人员</option>
              {config.recipients.filter((r) => r.type === "open_id").map((r) => (
                <option key={r.type + r.id} value={r.id}>
                  {r.label} · {r.type}
                </option>
              ))}
            </select>
          </label>
          <button
            className="tg-btn primary"
            disabled={busy || (notificationMode === "test" && !recipient)}
            onClick={() => void loadNotificationPreview()}
          >
            {busy ? "正在刷新映射并解析…" : "生成无发送预览"}
          </button>
          <p className="tg-muted">
            通知模式：{notificationMode}；自动发送门禁：
            {config.auto_send_enabled ? "已开启" : "关闭"}。预览只刷新权威 Sheet、解析 Bot 域 open_id，不调用发送 API。
          </p>
          {preview && <div className="cw-audit" data-testid="notification-dry-run">
            <strong>{preview.alert_id} · {preview.mapping_result.status} · {preview.actual_target.status}</strong>
            <NotificationPresentation preview={preview} />
            <p>原提报人：{preview.original_submitter || "缺失"} · Region：{preview.region || "缺失"}</p>
            <p>精确匹配：{preview.mapping_result.matched_alias || "—"} · {preview.mapping_result.email_masked || "***"} · {preview.mapping_result.reason}</p>
            <p>Bot 解析：{preview.bot_resolution.status} · {preview.bot_resolution.open_id_masked || "***"}</p>
            <p>实际目标：{preview.actual_target.label || preview.actual_target.type || "无"} · {preview.actual_target.enterprise_email || "企业邮箱未提供"} · {preview.actual_target.id_masked || "***"}</p>
            <p>模式：{preview.notification_mode === "test" ? "测试（仅白名单）" : "正式（真实负责人）"} · 事件链接：<a href={`?view=tasks&alert_id=${encodeURIComponent(preview.alert_id)}`}>打开事件</a></p>
            <details><summary>完整消息内容</summary><pre>{JSON.stringify(preview.template_card || {}, null, 2)}</pre></details>
            <small>{preview.notice}<br/>Sheet revision {preview.mapping_result.sheet_revision || "—"} · row {preview.mapping_result.sheet_row || "—"} · version {preview.mapping_result.record_version || "—"}</small>
          </div>}
          <>
            <label><input type="checkbox" checked={sendConfirmed} onChange={e=>setSendConfirmed(e.target.checked)} disabled={!preview?.confirmation_token || preview.case_version!==a.version || busy}/>我确认{notificationMode === "test" ? "仅向上方测试白名单" : "仅向预览展示的真实负责人"}发送一条{notificationMode === "test" ? " TEST" : "正式"}风险卡片；失败后需重新预览并确认重试。</label>
            <button className="tg-btn primary" disabled={busy || !sendConfirmed || !preview?.confirmation_token || preview.case_version!==a.version || preview.actual_target.status!==(notificationMode === "test" ? "ready_test_allowlist" : "ready_formal")} onClick={()=>void sendTestNotification()}>确认发送单条{notificationMode === "test" ? "测试" : "正式"}卡片</button>
            <p className="tg-muted">预览有效期 10 分钟。提报人映射、事件或 Bot 配置变化时会阻止发送。正式批量与自动发送保持禁用；排队中、发送失败均不代表通知已送达。</p>
          </>
          <details>
            <summary>集成配置状态</summary>
            {Object.entries(config.integration)
              .filter(([k]) => k.endsWith("configured"))
              .map(([k, v]) => (
                <p key={k}>
                  {k}：{v ? "已配置" : "待配置"}
                </p>
              ))}
          </details>
          {notices.map((n) => (
            <div className="cw-audit" key={n.id}>
              <strong>
                {n.kind === "send" ? "发送" : "卡片同步"} · {n.status}
              </strong>
              <p>
                {n.recipient} · 尝试 {n.attempts} 次
              </p>
              <small>
                message_id: {n.message_id || "尚未返回"}
                <br />
                更新时间: {n.updated_at || "—"}
                <br />
                {n.error}
              </small>
            </div>
          ))}
        </div>
      )}
      {tab === "history" && (
        <div>
          {[...a.history].reverse().map((ev, i) => (
            <div className="cw-audit" key={ev.id + i}>
              <strong>
                {opLabels[ev.operation] || ev.operation} →{" "}
                {caseLabels[ev.status]}
              </strong>
              <p>{ev.note}</p>
              {ev.fields &&
                Object.entries(ev.fields).map(([k, v]) => (
                  <small key={k}>
                    {options.flatMap((o) => o.fields).find((f) => f.key === k)
                      ?.label || k}
                    ：{v}
                    <br />
                  </small>
                ))}
              <small>
                {ev.actor} · {ev.source} · {ev.at} · v{ev.version}
              </small>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function FeishuCredentialSettings() {
  const [status, setStatus] = useState<any>();
  const [appId, setAppId] = useState("");
  const [secret, setSecret] = useState("");
  const [testEmail, setTestEmail] = useState("");
  const [testTarget, setTestTarget] = useState<any>();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const load = useCallback(() => workbenchApi<{data:any}>("/api/integrations/feishu/config-status").then(r=>setStatus(r.data)).catch(e=>setMessage(errorText(e))),[]);
  useEffect(()=>{void load()},[load]);
  async function save(){setBusy(true);setMessage("");try{const r=await workbenchApi<{data:any}>("/api/integrations/feishu/credentials",{app_id:appId,app_secret:secret});setStatus(r.data);setSecret("");setAppId("");setMessage("凭证验证并保存成功，后端已立即切换新配置。")}catch(e){setMessage(errorText(e))}finally{setBusy(false)}}
  async function saveTestRecipient(){setBusy(true);setMessage("");try{const r=await workbenchApi<{data:any}>("/api/integrations/feishu/test-recipient",{email:testEmail});setTestTarget(r.data);setTestEmail("");setMessage("已将账号加入测试白名单，通知模式保持 test；尚未发送消息。")}catch(e){setMessage(errorText(e))}finally{setBusy(false)}}
  return <section className="tg-card" data-testid="feishu-credential-settings">
    <div className="tg-cardhead"><div><h2>管理设置 · 通知集成 → 飞书 Bot</h2><p>凭证仅提交至后端验证；Secret 永不回显、预填或写入日志。</p></div></div>
    <div className="cw-metrics"><div><span>当前状态</span><strong>{status?.status==="configured"?"已配置":status?.status==="validation_failed"?"验证失败":"未配置"}</strong></div><div><span>当前 App ID</span><strong>{status?.app_id_masked||"—"}</strong></div><div><span>配置来源</span><strong>{status?.source||"—"}</strong></div><div><span>最近验证</span><strong>{status?.last_validated_at||"—"}</strong></div></div>
    {status?.environment_override&&<p className="cw-error">当前环境变量正在覆盖页面配置，系统已阻止保存，请先移除覆盖并重启。</p>}
    <div className="cw-fields"><label>新 App ID<input value={appId} onChange={e=>setAppId(e.target.value)} autoComplete="off" /></label><label>新 App Secret<input type="password" value={secret} onChange={e=>setSecret(e.target.value)} autoComplete="new-password" /></label></div>
    <button className="tg-btn tg-primary" disabled={busy||!appId.trim()||!secret.trim()||status?.environment_override} onClick={()=>void save()}>{busy?"正在验证…":"验证并保存"}</button>
    {message&&<p role="status">{message}</p>}<p>这里只验证应用凭证，不发送消息。凭证有效不代表人员查询权限、消息发送权限和接收人可用范围已验证。</p>
    <hr/><h3>多人测试通知白名单</h3><p>填写一个或多个测试人员的完整企业邮箱，可用逗号或换行分隔。系统逐个解析为当前 Bot 域的 open_id；只追加白名单，不允许群聊或真实 Submitter 回退。</p>
    <div className="cw-fields"><label>测试接收人企业邮箱<textarea value={testEmail} onChange={e=>setTestEmail(e.target.value)} autoComplete="off" placeholder="每行一个完整企业邮箱" /></label></div>
    <button className="tg-btn" disabled={busy||!testEmail.trim()||status?.status!=="configured"} onClick={()=>void saveTestRecipient()}>{busy?"正在解析…":"解析并加入测试白名单"}</button>
    {testTarget&&<div className="cw-metrics"><div><span>通知模式</span><strong>{testTarget.notification_mode}</strong></div><div><span>本次解析</span><strong>{testTarget.emails_masked?.join("、")||"—"}</strong></div><div><span>白名单人数</span><strong>{testTarget.recipient_count}</strong></div><div><span>群目标</span><strong>{testTarget.group_targets}</strong></div></div>}
    <IdentityMappingsSettings />
  </section>
}

type MappingRow = { record_id: string; region: string; business_name: string; aeolus_name: string; match_status: string; enabled: boolean; manual_disabled: boolean; email_masked: string; sheet_revision: string; sheet_row: number; record_version: string; override_note?: string };
function IdentityMappingsSettings() {
  const [rows, setRows] = useState<MappingRow[]>([]);
  const [source, setSource] = useState<Record<string, unknown>>({});
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    setBusy(true); setMessage("");
    try {
      const result = await workbenchIdentityMappingsList<{data:{mappings:MappingRow[];source:Record<string,unknown>;auto_send_enabled:boolean}}>();
      setRows(result.data.mappings); setSource(result.data.source);
    } catch (e) { setMessage(errorText(e)); } finally { setBusy(false); }
  }, []);
  async function toggle(row: MappingRow) {
    const note = row.enabled ? "运营在 App 中人工停用" : "运营在 App 中人工重新启用";
    setBusy(true); setMessage("");
    try {
      await workbenchIdentityMappingsByRecordIdEnabledUpdate(row.record_id, {enabled: !row.enabled, confirmation_note: note});
      await load();
      setMessage(row.enabled ? "已人工停用；后续 Sheet 同步不会自动重新启用。" : "已人工重新启用。仍需已确认状态和有效邮箱才可匹配。");
    } catch (e) { setMessage(errorText(e)); } finally { setBusy(false); }
  }
  return <div className="cw-form" data-testid="identity-mappings-settings">
    <hr/><div className="tg-cardhead"><div><h3>权威人员映射</h3><p>点击刷新会实时读取在线 Sheet；读取失败不会展示缓存为可发送依据。邮箱默认脱敏。</p></div><button className="tg-btn" disabled={busy} onClick={()=>void load()}>{busy?"刷新中…":"刷新在线映射"}</button></div>
    {message&&<p role="status">{message}</p>}
    <p className="tg-muted">Sheet {String(source.sheet_id||"e1e5ac")} · revision {String(source.revision||"—")} · 自动发送始终由独立门禁控制</p>
    <div className="cw-tablewrap"><table className="cw-table"><thead><tr><th>Region / 姓名</th><th>精确别名</th><th>邮箱</th><th>来源版本</th><th>状态</th><th>操作</th></tr></thead><tbody>{rows.map(row=><tr key={row.record_id}><td><strong>{row.region||"—"}</strong><small>{row.business_name||"—"}</small></td><td>{row.aeolus_name||"—"}</td><td>{row.email_masked}</td><td>r{row.sheet_revision} · row {row.sheet_row}<small>{row.record_version?.slice(0,8)}</small></td><td>{row.match_status} · {row.enabled?"启用":"停用"}{row.manual_disabled&&<small>人工 override</small>}</td><td><button className="tg-btn" disabled={busy} onClick={()=>void toggle(row)}>{row.enabled?"人工停用":"重新启用"}</button></td></tr>)}</tbody></table>{!busy&&rows.length===0&&<p className="tg-empty">尚未刷新在线映射。</p>}</div>
  </div>;
}

export function CaseActions({ id, onSaved, showEvidence = true }: { id: string; onSaved?: () => void; showEvidence?: boolean }) {
  const [config, setConfig] = useState<CaseConfig>();
  const [error, setError] = useState("");
  useEffect(() => {
    let active = true;
    workbenchApi<{data: CaseConfig}>("/api/workbench/casework/config").then(r => {if(active) setConfig(r.data)}).catch(e => {if(active) setError(errorText(e))});
    return () => {active=false};
  }, [id]);
  return error ? <p role="alert" className="cw-error">{error}</p> : config ? <CaseDetail key={id} id={id} config={config} compact showEvidence={showEvidence} onSaved={onSaved} /> : <p>正在读取事件配置…</p>;
}

type RiskCondition = { metric: "p0_ccr" | "p0_nfs" | "growth_pct" | "current_p0_ccr"; operator: ">" | ">=" | "<" | "<="; value: number };
type RiskRule = { id: string; name: string; program: string; kind: "absolute" | "growth" | "ranking"; match_mode?: "all" | "any"; conditions?: RiskCondition[]; ranking?: { top_n: number; positive_only: boolean }; risk_level: "watch" | "extreme"; scope: { tiers?: string[]; regions?: string[] }; enabled: boolean; _draft?: boolean };
type RiskPolicy = { version: number; version_label: string; config_hash: string; rules: RiskRule[]; is_operator: boolean; updated_by: string; updated_at: string; latest_rejudgement?: RejudgeTask };
type RejudgeTask = { id: string; status: string; progress: number; failure_reason?: string; created_at: string; program_results?: Record<string, { status: string; updated_rows: number; reason?: string }> };
type PolicyVersion = RiskPolicy & { change_note?: string };
type Impact = { before_matched: number; after_matched: number; added: number; removed: number; upgraded: number; downgraded: number; unavailable: number; insufficient: number; sample_ids?: string[] };
type PolicyPreview = { expected_version: number; draft_hash: string; preview_token: string; warnings: string[]; programs: Record<string, Impact>; total: Impact; source_batch_ids: string[]; data_freshness: Record<string, string>; partial: boolean; failure_reasons: string[] };

const fmtDate = (value?: string) => value ? new Date(value).toLocaleString("zh-CN", { hour12: false }) : "—";
const metricNames: Record<string, string> = { p0_ccr: "P0 CCR", p0_nfs: "P0 NFS", growth_pct: "正式增长率", current_p0_ccr: "当前 P0 CCR" };
const conditionLabel = (rule: RiskRule) => rule.kind === "ranking"
  ? `${rule.ranking?.positive_only ? "正增长" : "全部增长"} Top ${rule.ranking?.top_n ?? "—"}`
  : (rule.conditions || []).map(c => `${metricNames[c.metric] || c.metric} ${c.operator} ${c.value}${c.metric === "growth_pct" ? "%" : ""}`).join(rule.match_mode === "any" ? " 或 " : " 且 ");
const scopeLabel = (rule: RiskRule) => `${rule.scope.tiers?.length ? rule.scope.tiers.join("/") : "全部 Tier"} · ${rule.scope.regions?.length ? rule.scope.regions.join("/") : "全部 Region"}`;
const newRuleId = (kind: string, program: string, rules: RiskRule[]) => {
  const day = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  const base = `${kind}-${program.toLowerCase()}-${day}`;
  let seq = 1;
  while (rules.some(rule => rule.id === `${base}-${seq}`)) seq += 1;
  return `${base}-${seq}`;
};
const defaultConditions = (kind: RiskRule["kind"]): RiskCondition[] => kind === "absolute"
  ? [{ metric: "p0_ccr", operator: ">=", value: 3 }, { metric: "p0_nfs", operator: ">", value: 50 }]
  : [{ metric: "growth_pct", operator: ">", value: 100 }, { metric: "current_p0_ccr", operator: ">", value: 6 }];

function RuleEditor({ open, initial, existing, onCancel, onSave }: { open: boolean; initial?: RiskRule; existing: RiskRule[]; onCancel: () => void; onSave: (rule: RiskRule) => void }) {
  const [rule, setRule] = useState<RiskRule>();
  useEffect(() => { if (open) setRule(initial ? structuredClone(initial) : { id: "", name: "", program: "ALL", kind: "absolute", match_mode: "all", conditions: defaultConditions("absolute"), risk_level: "watch", scope: {}, enabled: true, _draft: true }); }, [open, initial]);
  if (!rule) return null;
  const metrics = rule.kind === "absolute" ? [{ value: "p0_ccr", label: "P0 CCR" }, { value: "p0_nfs", label: "P0 NFS" }] : [{ value: "growth_pct", label: "正式 CCR Increase（ET/THT 锚点前后各7日；ST 未配置）" }, { value: "current_p0_ccr", label: "当前 P0 CCR" }];
  const changeKind = (kind: RiskRule["kind"]) => setRule(old => old && ({ ...old, kind, match_mode: kind === "ranking" ? undefined : "all", conditions: kind === "ranking" ? [] : defaultConditions(kind), ranking: kind === "ranking" ? { top_n: 20, positive_only: true } : undefined }));
  const valid = rule.name.trim() && (rule.kind === "ranking" ? (rule.ranking?.top_n || 0) > 0 : (rule.conditions?.length || 0) > 0);
  return <Modal visible={open} title={initial ? "编辑规则草稿" : "新增阈值规则"} onCancel={onCancel} okText="保存到草稿" cancelText="取消" unmountOnExit onOk={() => {
    const id = rule.id || newRuleId(rule.kind, rule.program, existing);
    onSave({ ...rule, id, name: rule.name.trim(), _draft: initial?._draft ?? true });
  }} okButtonProps={{ disabled: !valid }}>
    <div className="risk-rule-form">
      <div className="risk-form-field"><span>模板</span><Select value={rule.kind} onChange={changeKind} options={[{ value: "absolute", label: "绝对值" }, { value: "growth", label: "增长" }, { value: "ranking", label: "排名" }]} /></div>
      <div className="risk-form-field"><span>规则名称</span><Input value={rule.name} onChange={name => setRule({ ...rule, name })} placeholder="例如：ET 绝对值观察线" /></div>
      <div className="risk-form-field"><span>Program</span><Select value={rule.program} onChange={program => setRule({ ...rule, program })} options={["ALL", "ET", "ST", "THT"].map(value => ({ value, label: value }))} /></div>
      <div className="risk-form-field"><span>Tier 范围</span><Input value={(rule.scope.tiers || []).join(",")} onChange={value => setRule({ ...rule, scope: { ...rule.scope, tiers: value.split(",").map(x => x.trim()).filter(Boolean) } })} placeholder="留空为全部；逗号分隔" /></div>
      <div className="risk-form-field"><span>Region 范围</span><Input value={(rule.scope.regions || []).join(",")} onChange={value => setRule({ ...rule, scope: { ...rule.scope, regions: value.split(",").map(x => x.trim()).filter(Boolean) } })} placeholder="留空为全部；逗号分隔" /></div>
      {rule.kind !== "ranking" && <div className="risk-form-field"><span>条件关系</span><Radio.Group type="button" value={rule.match_mode} onChange={match_mode => setRule({ ...rule, match_mode })}><Radio value="all">全部满足（AND）</Radio><Radio value="any">任一满足（OR）</Radio></Radio.Group></div>}
      {rule.kind === "ranking" ? <div className="risk-condition-row"><span>完整候选池正增长排名</span><InputNumber min={1} max={500} value={rule.ranking?.top_n} onChange={top_n => setRule({ ...rule, ranking: { top_n: Number(top_n), positive_only: true } })} prefix="Top" /></div> : <div className="risk-condition-list">
        {(rule.conditions || []).map((condition, index) => <div className="risk-condition-row" key={`${condition.metric}-${condition.operator}-${condition.value}`}>
          <Select value={condition.metric} options={metrics} onChange={metric => setRule({ ...rule, conditions: rule.conditions?.map((c, i) => i === index ? { ...c, metric } : c) })} />
          <Select value={condition.operator} options={[">", ">=", "<", "<="].map(value => ({ value, label: value }))} onChange={operator => setRule({ ...rule, conditions: rule.conditions?.map((c, i) => i === index ? { ...c, operator } : c) })} />
          <InputNumber min={0} value={condition.value} onChange={value => setRule({ ...rule, conditions: rule.conditions?.map((c, i) => i === index ? { ...c, value: Number(value) } : c) })} />
          <Button type="text" status="danger" disabled={(rule.conditions?.length || 0) <= 1} onClick={() => setRule({ ...rule, conditions: rule.conditions?.filter((_, i) => i !== index) })}>移除</Button>
        </div>)}
        <Button type="text" onClick={() => setRule({ ...rule, conditions: [...(rule.conditions || []), { ...defaultConditions(rule.kind)[0] }] })}>添加条件</Button>
      </div>}
      <div className="risk-form-field"><span>风险等级</span><Select value={rule.risk_level} onChange={risk_level => setRule({ ...rule, risk_level })} options={[{ value: "watch", label: "观察" }, { value: "extreme", label: "极高" }]} /></div>
      <div className="risk-form-field"><span>初始状态</span><Switch checked={rule.enabled} onChange={enabled => setRule({ ...rule, enabled })} checkedText="启用" uncheckedText="停用" /></div>
    </div>
  </Modal>;
}

function RiskPolicySettings() {
  const [policy, setPolicy] = useState<RiskPolicy>();
  const [rules, setRules] = useState<RiskRule[]>([]);
  const [tasks, setTasks] = useState<RejudgeTask[]>([]);
  const [versions, setVersions] = useState<PolicyVersion[]>([]);
  const [editing, setEditing] = useState<RiskRule | undefined>();
  const [editorOpen, setEditorOpen] = useState(false);
  const [preview, setPreview] = useState<PolicyPreview>();
  const [previewOpen, setPreviewOpen] = useState(false);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const load = useCallback(async () => {
    try {
      const [current, taskData, versionData] = await Promise.all([workbenchRiskPolicyList(), workbenchRiskPolicyRejudgementsList(), workbenchRiskPolicyVersionsList()]);
      const next = current.data as RiskPolicy;
      setPolicy(next); setRules(next.rules.map(rule => ({ ...rule, _draft: false }))); setTasks(taskData.data.tasks as RejudgeTask[]); setVersions(versionData.data.versions as PolicyVersion[]); setError("");
    } catch (e) { setError(errorText(e)); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => { if (!tasks.some(t => t.status === "pending" || t.status === "running")) return; const timer = window.setInterval(() => { void load(); }, 2000); return () => window.clearInterval(timer); }, [tasks, load]);
  const changeRules = (next: RiskRule[]) => { setRules(next); setPreview(undefined); setPreviewOpen(false); };
  const openNew = () => { setEditing(undefined); setEditorOpen(true); };
  const edit = (rule: RiskRule) => { setEditing(rule); setEditorOpen(true); };
  const copy = (rule: RiskRule) => { const duplicate = structuredClone(rule); duplicate.id = newRuleId(rule.kind, rule.program, rules); duplicate.name = `${rule.name} 副本`; duplicate._draft = true; changeRules([...rules, duplicate]); };
  const runPreview = async () => { if (!policy) return; setSaving(true); setError(""); try { const result = await workbenchRiskPolicyPreviewCreate({ expected_version: policy.version, rules: rules.map(({ _draft, ...rule }) => rule) }); setPreview(result.data as unknown as PolicyPreview); setPreviewOpen(true); } catch (e) { setError(errorText(e)); } finally { setSaving(false); } };
  const submit = async () => { if (!policy || !preview || !note.trim()) return; setSaving(true); setError(""); try { await workbenchRiskPolicyUpdate({ expected_version: policy.version, preview_token: preview.preview_token, request_id: requestId(), confirmation_note: note.trim(), rules: rules.map(({ _draft, ...rule }) => rule) }); setNote(""); setPreviewOpen(false); await load(); } catch (e) { setError(errorText(e)); setPreview(undefined); } finally { setSaving(false); } };
  if (!policy) return <section className="risk-policy-settings"><p>{error || "正在读取后端权威阈值…"}</p></section>;
  const latest = tasks[0] || policy.latest_rejudgement;
  const columns = [
    { title: "名称 / ID", dataIndex: "name", render: (_: unknown, rule: RiskRule) => <><strong>{rule.name}</strong><small>{rule.id}</small></> },
    { title: "Program / 类型", render: (_: unknown, rule: RiskRule) => <><Tag>{rule.program}</Tag><small>{rule.kind}{rule.kind !== "ranking" ? ` · ${rule.match_mode === "any" ? "任一" : "全部"}` : ""}</small></> },
    { title: "范围", render: (_: unknown, rule: RiskRule) => scopeLabel(rule) },
    { title: "条件", render: (_: unknown, rule: RiskRule) => conditionLabel(rule) },
    { title: "等级", render: (_: unknown, rule: RiskRule) => rule.risk_level === "extreme" ? "极高" : "观察" },
    { title: "状态", render: (_: unknown, rule: RiskRule) => <Switch size="small" checked={rule.enabled} disabled={!policy.is_operator} onChange={enabled => changeRules(rules.map(item => item.id === rule.id ? { ...item, enabled } : item))} checkedText="启用" uncheckedText="停用" /> },
    { title: "操作", render: (_: unknown, rule: RiskRule) => <Space size="mini"><Button size="mini" onClick={() => edit(rule)}>编辑</Button><Button size="mini" onClick={() => copy(rule)}>复制</Button>{rule._draft && <Button size="mini" status="danger" onClick={() => changeRules(rules.filter(item => item.id !== rule.id))}>删除草稿</Button>}</Space> },
  ];
  return <section className="risk-policy-settings" aria-label="阈值配置">
    <header><div><h4>阈值配置</h4><p>后端权威版本 {policy.version_label} · {policy.updated_by || "系统默认"} · {policy.updated_at ? fmtDate(policy.updated_at) : "默认种子"}</p></div><Space><span className="cw-badge">v{policy.version}</span>{policy.is_operator && <Button type="primary" onClick={openNew}>新增规则</Button>}</Space></header>
    {error && <Alert type="error" content={error} closable onClose={() => setError("")} />}
    <Table className="risk-policy-table" rowKey="id" columns={columns} data={rules} pagination={false} scroll={{ x: 980 }} />
    {policy.is_operator && <div className="risk-policy-submit"><p>所有编辑仅保存在本页草稿；已生效规则不可物理删除，只能停用。草稿变化后必须重新预览。</p><Button type="primary" loading={saving} onClick={() => void runPreview()}>预览影响并提交</Button></div>}
    <RuleEditor open={editorOpen} initial={editing} existing={rules} onCancel={() => setEditorOpen(false)} onSave={rule => { changeRules(editing ? rules.map(item => item.id === editing.id ? rule : item) : [...rules, rule]); setEditorOpen(false); }} />
    <Modal visible={previewOpen} title="影响预览与二次确认" okText="确认生效并自动重判" cancelText="返回修改" onCancel={() => setPreviewOpen(false)} onOk={() => void submit()} confirmLoading={saving} okButtonProps={{ disabled: !note.trim() || !preview }}>
      {preview && <div className="risk-preview"><p>数据批次：{preview.source_batch_ids.join("、") || "无可用批次"}</p>{preview.partial && <Alert type="warning" content={preview.failure_reasons.join("；")} />}{preview.warnings.map(warning => <Alert key={warning} type="warning" content={warning} />)}
        <Table rowKey="program" pagination={false} data={[...Object.entries(preview.programs).map(([program, impact]) => ({ program, ...impact })), { program: "总计", ...preview.total }]} columns={[{ title: "Program", dataIndex: "program" }, { title: "原命中", dataIndex: "before_matched" }, { title: "新命中", dataIndex: "after_matched" }, { title: "新增", dataIndex: "added" }, { title: "移除", dataIndex: "removed" }, { title: "升级", dataIndex: "upgraded" }, { title: "降级", dataIndex: "downgraded" }, { title: "不可用", dataIndex: "unavailable" }, { title: "不足", dataIndex: "insufficient" }]} scroll={{ x: 760 }} />
        <div className="risk-form-field"><span>变更说明</span><Input.TextArea value={note} maxLength={1000} showWordLimit onChange={setNote} placeholder="说明调整原因、预期影响与回滚判断" /></div><p>确认后仅基于持久化指标自动重判，不查询 Aeolus，不修改人工处置/归因/复核，不创建通知或 outbox。</p></div>}
    </Modal>
    <div className="risk-policy-status"><h5>自动重判</h5>{latest ? <><p><strong>{latest.status}</strong> · {latest.progress ?? 0}% · {fmtDate(latest.created_at)}</p>{latest.failure_reason && <p className="cw-error">{latest.failure_reason}</p>}<ul>{Object.entries(latest.program_results || {}).map(([program, result]) => <li key={program}>{program}：{result.status}，更新 {result.updated_rows || 0} 行{result.reason ? `；${result.reason}` : ""}</li>)}</ul></> : <p>暂无重判任务</p>}</div>
    <details><summary>版本审计（{versions.length}）</summary><ul className="risk-policy-audit">{versions.map(v => <li key={v.version}><strong>{v.version_label}</strong><span>{v.updated_by} · {fmtDate(v.updated_at)}</span><p>{v.change_note || "无变更说明"}</p></li>)}</ul></details>
  </section>;
}

type BackfillTask = { id: string; request_id: string; status: string; dry_run: boolean; checkpoint: number; progress: { total: number; done: number; updated: number; skipped: number; failed: number }; errors?: string[]; updated_at: string };

function EnrichmentBackfillSettings() {
  const [tasks, setTasks] = useState<BackfillTask[]>([]);
  const [program, setProgram] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const load = useCallback(async () => { try { const result = await workbenchBackfillsList(); setTasks(result.data.tasks as BackfillTask[]); setError(""); } catch (e) { setError(errorText(e)); } }, []);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => { if (!tasks.some(task => task.status === "queued" || task.status === "running")) return; const timer = window.setInterval(() => void load(), 2000); return () => window.clearInterval(timer); }, [tasks, load]);
  const run = async (dryRun: boolean) => { setLoading(true); setError(""); try { await workbenchBackfillsCreate({ request_id: requestId(), dry_run: dryRun, program: program || undefined }); await load(); } catch (e) { setError(errorText(e)); } finally { setLoading(false); } };
  return <section className="risk-policy-settings" aria-label="历史定向回填">
    <header><div><h4>历史定向回填</h4><p>仅检查已有当前周批次和历史 case 的缺失 enrichment；不会全量扫描 membership、创建 case 或发送通知。</p></div></header>
    {error && <Alert type="error" content={error} />}
    <Space><Select value={program} onChange={setProgram} style={{ width: 180 }} options={[{ value: "", label: "全部 Program" }, { value: "ET", label: "ET" }, { value: "THT", label: "THT" }, { value: "ST", label: "ST" }]} /><Button loading={loading} onClick={() => void run(true)}>Dry Run</Button><Button type="primary" loading={loading} onClick={() => void run(false)}>执行回填</Button></Space>
    <Table rowKey="id" pagination={false} data={tasks} columns={[{ title: "任务", dataIndex: "id" }, { title: "模式", render: (_: unknown, task: BackfillTask) => task.dry_run ? "Dry Run" : "执行" }, { title: "状态", dataIndex: "status" }, { title: "进度", render: (_: unknown, task: BackfillTask) => `${task.progress?.done || 0}/${task.progress?.total || 0}` }, { title: "更新 / 跳过 / 失败", render: (_: unknown, task: BackfillTask) => `${task.progress?.updated || 0} / ${task.progress?.skipped || 0} / ${task.progress?.failed || 0}` }]} scroll={{ x: 760 }} />
  </section>;
}

export function WorkbenchSettings() {
 const [operator, setOperator] = useState(false);
 const [open,setOpen] = useState(false);
 useEffect(() => {let active=true;workbenchApi<{data:CaseConfig}>("/api/workbench/casework/config").then(r=>{if(active)setOperator(r.data.is_operator)}).catch(()=>{});return()=>{active=false}},[]);
 return operator ? <details className="ops-disclosure" open={open} onToggle={e=>setOpen(e.currentTarget.open)}><summary>管理设置 · 阈值、回填、飞书 Bot 与人员映射</summary>{open && <><RiskPolicySettings /><EnrichmentBackfillSettings /><FeishuCredentialSettings /></>}</details> : null;
}
