import type { ReportedReason } from "./read-model";
import { ccr } from "./read-model";

export type ReportedReasonGroup = {
  advertiser_id?: string;
  reasons: ReportedReason[];
};

export function ReportedReasonsView({ groups }: { groups: ReportedReasonGroup[] }) {
  if (!groups.length) return <span>—</span>;
  return <div className="ops-reported-reasons">
    {groups.map((group, groupIndex) => <div key={`${group.advertiser_id || "unknown"}-${groupIndex}`}>
      {group.advertiser_id && <small>Advertiser {group.advertiser_id}</small>}
      {group.reasons.map((reason, index) => <details key={`${reason.original_label}-${index}`} title={reason.description}>
        <summary>{reason.rank ? `${reason.rank}. ` : ""}{reason.mapped_name || reason.display_name_en || "Unmapped Reason"}{reason.mapping_status === "pending_confirmation" ? " · Pending confirmation" : ""}{reason.p0_ccr != null ? ` · P0 CCR ${ccr(reason.p0_ccr)}` : " · P0 CCR NULL"}{reason.p0_nfs != null ? ` · P0 NFS ${reason.p0_nfs.toLocaleString("en-US")}` : ""}</summary>
        {!reason.ranking_available && <span>{reason.ranking_unavailable_reason || reason.source_reason || "Reason ranking unavailable"}</span>}
        {reason.sort_basis && <span>sort_basis: {reason.sort_basis}</span>}
        <span>{reason.description || "—"}</span><code>{reason.raw_path || reason.original_label || "—"}</code>
      </details>)}
    </div>)}
  </div>;
}

export const reportedReasonGroups = (items: Array<{ advertiser_id?: string; reported_reasons?: ReportedReason[] }> | undefined): ReportedReasonGroup[] =>
  (items || []).flatMap((item) => item.reported_reasons?.length
    ? [{ advertiser_id: item.advertiser_id, reasons: item.reported_reasons }]
    : []);
