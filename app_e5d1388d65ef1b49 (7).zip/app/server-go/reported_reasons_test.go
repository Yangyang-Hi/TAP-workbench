package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestReportedReasonMappingContract(t *testing.T) {
	raw, err := os.ReadFile(filepath.Join(pluginDir, "config", "reported_reason_mapping.json"))
	if err != nil {
		t.Fatal(err)
	}
	dict, err := parseReportedReasonDictionary(raw)
	if err != nil {
		t.Fatal(err)
	}
	if len(dict.ByKey) != 126 {
		t.Fatalf("mapping count = %d, want 126", len(dict.ByKey))
	}
	pending := 0
	for _, entry := range dict.ByKey {
		if entry.MappingStatus == "pending_confirmation" {
			pending++
		}
	}
	if pending == 0 {
		t.Fatal("expected at least one pending-confirmation mapping")
	}
}

func TestReportedReasonNormalizationCollision(t *testing.T) {
	entries := make([]reportedReasonMapping, 126)
	for i := range entries {
		entries[i] = reportedReasonMapping{OriginalLabel: strings.Repeat("x", i+1)}
	}
	entries[0].OriginalLabel = "a - b"
	entries[1].OriginalLabel = "a  -  b"
	raw, _ := json.Marshal(reportedReasonMappingFile{Version: reportedReasonMappingVersion, Entries: entries})
	if _, err := parseReportedReasonDictionary(raw); err == nil || !strings.Contains(err.Error(), "collision") {
		t.Fatalf("expected normalized-key collision, got %v", err)
	}
}

func TestReportedReasonUnknownEmptyAndRanking(t *testing.T) {
	dict := reportedReasonDictionary{ByKey: map[string]reportedReasonMapping{
		"known-a": {OriginalLabel: "known-a", DisplayNameEN: "A"},
		"known-b": {OriginalLabel: "known-b", DisplayNameEN: "B"},
		"known-c": {OriginalLabel: "known-c", DisplayNameEN: "C"},
		"known-d": {OriginalLabel: "known-d", DisplayNameEN: "D"},
	}}
	rows := []map[string]any{
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "semantics_label_tier_1_2_3_4": "known-b", "dynamic_p0_ccr": 2.0},
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "semantics_label_tier_1_2_3_4": "known-a", "dynamic_p0_ccr": 2.0},
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "semantics_label_tier_1_2_3_4": "known-c", "dynamic_p0_ccr": 1.0},
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "semantics_label_tier_1_2_3_4": "known-d", "dynamic_p0_ccr": 0.5},
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000002", "semantics_label_tier_1_2_3_4": "unknown", "dynamic_p0_ccr": nil},
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000003", "semantics_label_tier_1_2_3_4": "", "dynamic_p0_ccr": 9.0},
	}
	got := rankReportedReasons(dict, rows, true, "")
	ranked := got[wbPairKey{"7000000000000000001", "7100000000000000001"}]
	if len(ranked) != 3 || ranked[0].OriginalLabel != "known-a" || ranked[1].OriginalLabel != "known-b" || ranked[0].Rank == nil || *ranked[0].Rank != 1 {
		t.Fatalf("unexpected top3: %#v", ranked)
	}
	unknown := got[wbPairKey{"7000000000000000001", "7100000000000000002"}][0]
	if unknown.DisplayNameEN != "Unmapped Reason" || unknown.RankingAvailable || unknown.RankingUnavailable == "" {
		t.Fatalf("unexpected null/unmapped result: %#v", unknown)
	}
	empty := got[wbPairKey{"7000000000000000001", "7100000000000000003"}][0]
	if empty.DisplayNameEN != "No Semantic Label" {
		t.Fatalf("unexpected empty-label result: %#v", empty)
	}
}

func TestReportedReasonTruncationNeverRanks(t *testing.T) {
	rows := make([]map[string]any, 24)
	if complete, reason := reportedReasonRowsCompleteness(rows, true); complete || !strings.Contains(reason, "truncated") {
		t.Fatalf("complete=%v reason=%q", complete, reason)
	}
	if complete, reason := reportedReasonRowsCompleteness(rows, false); !complete || reason != "" {
		t.Fatalf("verified complete row set rejected: complete=%v reason=%q", complete, reason)
	}
}

func TestTHTReportedReasonKeyPreservesAdvertiserGrain(t *testing.T) {
	dict := reportedReasonDictionary{ByKey: map[string]reportedReasonMapping{"label": {OriginalLabel: "label", DisplayNameEN: "Label"}}}
	rows := []map[string]any{
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000004", "semantics_label_tier_1_2_3_4": "label", "dynamic_p0_ccr": 3.0},
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000005", "semantics_label_tier_1_2_3_4": "label", "dynamic_p0_ccr": 2.0},
	}
	got := rankReportedReasons(dict, rows, true, "")
	if len(got) != 2 || len(got[wbPairKey{"7000000000000000001", "7100000000000000004"}]) != 1 || len(got[wbPairKey{"7000000000000000001", "7100000000000000005"}]) != 1 {
		t.Fatalf("advertiser grain collapsed: %#v", got)
	}
}

func TestKnownEvidenceFixtureNullLabelCCRNeverFabricatesTop3(t *testing.T) {
	// Audited 2026-10-26 fixture only (not product data): RID 2942519 returned
	// 4,216 complete rows (limitReached=false) for this account. Its Top1 ADV had
	// overall P0 CCR 2890.173410404624 and P0 NFS 1. RID 3023305 returned exactly
	// Violence and Non-negative Feedback for that ADV, both with label CCR NULL.
	accountID := "7384382510245068801"
	advertiserID := "7655963361028571144"
	overallCCR, overallNFS := 2890.173410404624, float64(1)
	top := topAdvertisers([]wbAdvertiserEvidence{{AccountID: accountID, AdvertiserID: advertiserID, CCR: &overallCCR, NFS: &overallNFS, MetricStatus: "success"}}, 10)
	if len(top) != 1 || top[0].AdvertiserID != advertiserID || *top[0].CCR != overallCCR || *top[0].NFS != overallNFS {
		t.Fatalf("RID 2942519 complete fixture did not preserve Top1: %+v", top)
	}
	dict := reportedReasonDictionary{ByKey: map[string]reportedReasonMapping{
		"Violence":              {OriginalLabel: "Violence", DisplayNameEN: "Violence"},
		"Non-negative Feedback": {OriginalLabel: "Non-negative Feedback", DisplayNameEN: "Non-negative Feedback"},
	}}
	rows := []map[string]any{
		{"account_id": accountID, "advertiser_id": advertiserID, "semantics_label_tier_1_2_3_4": "Violence", "dynamic_p0_ccr": nil},
		{"account_id": accountID, "advertiser_id": advertiserID, "semantics_label_tier_1_2_3_4": "Non-negative Feedback", "dynamic_p0_ccr": nil},
	}
	reasons := rankReportedReasons(dict, rows, true, "")[wbPairKey{accountID, advertiserID}]
	if len(reasons) != 2 {
		t.Fatalf("expected both unranked original labels, got %+v", reasons)
	}
	for _, reason := range reasons {
		if reason.RankingAvailable || reason.Rank != nil || reason.P0CCR != nil || reason.RankingUnavailable != "label-level P0 CCR and P0 NFS are null or invalid" {
			t.Fatalf("null label CCR must remain unranked: %+v", reason)
		}
	}
}

func TestReportedReasonRankingUsesCCRWhenAnyPresentAndNFSFallbackOnlyWhenAllCCRNull(t *testing.T) {
	dict := reportedReasonDictionary{ByKey: map[string]reportedReasonMapping{
		"a": {OriginalLabel: "a", DisplayNameEN: "A"},
		"b": {OriginalLabel: "b", DisplayNameEN: "B"},
		"c": {OriginalLabel: "c", DisplayNameEN: "C"},
	}}
	key := wbPairKey{"7000000000000000001", "7100000000000000001"}
	withCCR := rankReportedReasons(dict, []map[string]any{
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "a", "dynamic_p0_ccr": nil, "p0_nfs": 100.0},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "b", "dynamic_p0_ccr": 2.0, "p0_nfs": 1.0},
	}, true, "")[key]
	if len(withCCR) != 2 || withCCR[0].OriginalLabel != "b" || withCCR[0].SortBasis != "p0_ccr_desc" || withCCR[1].P0CCR != nil {
		t.Fatalf("CCR ordering/null-last contract failed: %+v", withCCR)
	}
	fallback := rankReportedReasons(dict, []map[string]any{
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "a", "dynamic_p0_ccr": nil, "p0_nfs": 3.0},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "b", "dynamic_p0_ccr": nil, "p0_nfs": 9.0},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "c", "dynamic_p0_ccr": nil, "p0_nfs": 78.0},
	}, true, "")[key]
	if len(fallback) != 3 || fallback[0].OriginalLabel != "c" || fallback[1].OriginalLabel != "b" || fallback[0].SortBasis != "nfs_fallback_all_ccr_null" || fallback[0].RawPath != "c" || fallback[0].MappedName != "C" {
		t.Fatalf("NFS fallback/raw mapping contract failed: %+v", fallback)
	}
}
