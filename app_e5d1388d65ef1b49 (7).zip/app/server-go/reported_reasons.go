package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
)

const reportedReasonMappingVersion = "2026-10-26.v1"

var reasonSeparator = regexp.MustCompile(`\s+-\s+`)

type reportedReason struct {
	OriginalLabel      string   `json:"original_label"`
	RawPath            string   `json:"raw_path"`
	DisplayNameEN      string   `json:"display_name_en"`
	MappedName         string   `json:"mapped_name"`
	Description        string   `json:"description"`
	MappingStatus      string   `json:"mapping_status"`
	SourceStatus       string   `json:"source_status,omitempty"`
	SourceReason       string   `json:"source_reason,omitempty"`
	QueryStatus        string   `json:"query_status"`
	SortBasis          string   `json:"sort_basis,omitempty"`
	P0CCR              *float64 `json:"p0_ccr"`
	P0NFS              *float64 `json:"p0_nfs"`
	Rank               *int     `json:"rank"`
	RankingAvailable   bool     `json:"ranking_available"`
	RankingUnavailable string   `json:"ranking_unavailable_reason,omitempty"`
}

type reportedReasonMappingFile struct {
	Version string                  `json:"version"`
	Entries []reportedReasonMapping `json:"entries"`
}

type reportedReasonMapping struct {
	OriginalLabel string `json:"original_label"`
	DisplayNameEN string `json:"display_name_en"`
	Description   string `json:"description"`
	MappingStatus string `json:"mapping_status"`
}

type reportedReasonDictionary struct {
	Version string
	ByKey   map[string]reportedReasonMapping
}

func normalizeReportedReasonLabel(label string) string {
	parts := reasonSeparator.Split(label, -1)
	for i := range parts {
		parts[i] = strings.TrimSpace(parts[i])
	}
	return strings.Join(parts, " - ")
}

func parseReportedReasonDictionary(raw []byte) (reportedReasonDictionary, error) {
	var file reportedReasonMappingFile
	if err := json.Unmarshal(raw, &file); err != nil {
		return reportedReasonDictionary{}, err
	}
	if file.Version != reportedReasonMappingVersion {
		return reportedReasonDictionary{}, fmt.Errorf("unsupported reported reason mapping version %q", file.Version)
	}
	if len(file.Entries) != 126 {
		return reportedReasonDictionary{}, fmt.Errorf("reported reason mapping must contain 126 entries, got %d", len(file.Entries))
	}
	out := reportedReasonDictionary{Version: file.Version, ByKey: make(map[string]reportedReasonMapping, len(file.Entries))}
	for _, entry := range file.Entries {
		key := normalizeReportedReasonLabel(entry.OriginalLabel)
		if existing, ok := out.ByKey[key]; ok {
			return reportedReasonDictionary{}, fmt.Errorf("reported reason normalized-key collision: %q and %q", existing.OriginalLabel, entry.OriginalLabel)
		}
		out.ByKey[key] = entry
	}
	return out, nil
}

var (
	reportedReasonsOnce sync.Once
	reportedReasonsDict reportedReasonDictionary
	reportedReasonsErr  error
)

func loadReportedReasonDictionary() (reportedReasonDictionary, error) {
	reportedReasonsOnce.Do(func() {
		raw, err := os.ReadFile(filepath.Join(pluginDir, "config", "reported_reason_mapping.json"))
		if err != nil {
			reportedReasonsErr = err
			return
		}
		reportedReasonsDict, reportedReasonsErr = parseReportedReasonDictionary(raw)
	})
	return reportedReasonsDict, reportedReasonsErr
}

func mapReportedReason(dict reportedReasonDictionary, label string, ccr, nfs *float64) reportedReason {
	original := label
	if entry, ok := dict.ByKey[normalizeReportedReasonLabel(label)]; ok {
		return reportedReason{OriginalLabel: original, RawPath: original, DisplayNameEN: entry.DisplayNameEN, MappedName: entry.DisplayNameEN, Description: entry.Description, MappingStatus: entry.MappingStatus, SourceStatus: "verified", QueryStatus: "success", P0CCR: ccr, P0NFS: nfs}
	}
	return reportedReason{OriginalLabel: original, RawPath: original, DisplayNameEN: "Unmapped Reason", MappedName: "Unmapped Reason", Description: "原始标签尚未纳入固定映射，已保留供维护。", MappingStatus: "unmapped", SourceStatus: "verified", QueryStatus: "success", P0CCR: ccr, P0NFS: nfs}
}

func noSemanticLabelReason() reportedReason {
	return reportedReason{DisplayNameEN: "No Semantic Label", Description: "源标签数组为空；不等于无风险。", MappingStatus: "no_semantic_label"}
}

func unavailableReportedReason(reason string) reportedReason {
	if strings.TrimSpace(reason) == "" {
		reason = "pending_source: authoritative single-label CCR source is unavailable"
	}
	return reportedReason{DisplayNameEN: "Reported Reasons Unavailable", MappedName: "Reported Reasons Unavailable", Description: "原因级来源查询未成功；未生成 Top3。", MappingStatus: "unavailable", SourceStatus: metricFailed, QueryStatus: metricFailed, SourceReason: reason, RankingUnavailable: reason}
}

func rankReportedReasons(dict reportedReasonDictionary, rows []map[string]any, complete bool, unavailableReason string) map[wbPairKey][]reportedReason {
	grouped := map[wbPairKey][]reportedReason{}
	seenPairs := map[wbPairKey]bool{}
	for _, row := range rows {
		key := wbPairKey{strings.TrimSpace(asString(row["account_id"])), strings.TrimSpace(asString(row["advertiser_id"]))}
		if !validPair(key.AccountID, key.AdvertiserID) {
			continue
		}
		seenPairs[key] = true
		label := asString(row["semantics_label_tier_1_2_3_4"])
		if strings.TrimSpace(label) == "" {
			continue
		}
		ccr, ccrErr := strictWBMetric(row["dynamic_p0_ccr"])
		nfs, nfsErr := strictWBMetric(row["p0_nfs"])
		if ccrErr != nil || nfsErr != nil {
			failed := mapReportedReason(dict, label, nil, nil)
			failed.QueryStatus = metricFailed
			failed.SourceStatus = metricFailed
			failed.SourceReason = sanitizeLogText(fmt.Sprintf("field parse failed: ccr=%v nfs=%v", ccrErr, nfsErr))
			failed.RankingUnavailable = failed.SourceReason
			grouped[key] = append(grouped[key], failed)
			continue
		}
		grouped[key] = append(grouped[key], mapReportedReason(dict, label, ccr, nfs))
	}
	for key := range seenPairs {
		if len(grouped[key]) == 0 {
			grouped[key] = []reportedReason{noSemanticLabelReason()}
		}
	}
	for key, reasons := range grouped {
		if !complete {
			for i := range reasons {
				reasons[i].RankingAvailable = false
				reasons[i].RankingUnavailable = unavailableReason
			}
			grouped[key] = reasons
			continue
		}
		valid := reasons[:0]
		for _, reason := range reasons {
			if reason.QueryStatus == "success" {
				valid = append(valid, reason)
			}
		}
		if len(valid) == 0 {
			grouped[key] = reasons
			continue
		}
		hasCCR, hasNFS := false, false
		for _, reason := range valid {
			if reason.P0CCR != nil && !math.IsNaN(*reason.P0CCR) && !math.IsInf(*reason.P0CCR, 0) && *reason.P0CCR >= 0 {
				hasCCR = true
			}
			if reason.P0NFS != nil && !math.IsNaN(*reason.P0NFS) && !math.IsInf(*reason.P0NFS, 0) && *reason.P0NFS >= 0 {
				hasNFS = true
			}
		}
		if !hasCCR && !hasNFS {
			for i := range valid {
				valid[i].RankingUnavailable = "label-level P0 CCR and P0 NFS are null or invalid"
			}
			grouped[key] = valid
			continue
		}
		sortBasis := "p0_ccr_desc"
		if !hasCCR {
			sortBasis = "nfs_fallback_all_ccr_null"
		}
		sort.SliceStable(valid, func(i, j int) bool {
			if hasCCR {
				if valid[i].P0CCR == nil {
					return false
				}
				if valid[j].P0CCR == nil {
					return true
				}
				if *valid[i].P0CCR != *valid[j].P0CCR {
					return *valid[i].P0CCR > *valid[j].P0CCR
				}
			} else {
				if valid[i].P0NFS == nil {
					return false
				}
				if valid[j].P0NFS == nil {
					return true
				}
				if *valid[i].P0NFS != *valid[j].P0NFS {
					return *valid[i].P0NFS > *valid[j].P0NFS
				}
			}
			return valid[i].OriginalLabel < valid[j].OriginalLabel
		})
		if len(valid) > 3 {
			valid = valid[:3]
		}
		for i := range valid {
			rank := i + 1
			valid[i].Rank = &rank
			valid[i].RankingAvailable = true
			valid[i].SortBasis = sortBasis
		}
		grouped[key] = valid
	}
	return grouped
}

func attachReportedReasons(evidence map[string][]wbAdvertiserEvidence, rows []map[string]any, complete bool, reason string) error {
	dict, err := loadReportedReasonDictionary()
	if err != nil {
		return err
	}
	mapped := rankReportedReasons(dict, rows, complete, reason)
	for accountID, items := range evidence {
		for i := range items {
			key := wbPairKey{items[i].AccountID, items[i].AdvertiserID}
			items[i].ReportedReasons = mapped[key]
			if len(items[i].ReportedReasons) == 0 {
				items[i].ReportedReasons = []reportedReason{unavailableReportedReason(reason)}
			}
		}
		evidence[accountID] = items
	}
	return nil
}

func reportedReasonRowsCompleteness(rows []map[string]any, sourcePossiblyTruncated bool) (bool, string) {
	if sourcePossiblyTruncated {
		return false, "Reason ranking unavailable: RID 3023305 result was truncated"
	}
	if rows == nil {
		return false, "Reason ranking unavailable: label-level source returned no auditable row set"
	}
	return true, ""
}

var errReportedReasonCandidateSetIncomplete = errors.New("reported reason candidate set incomplete")
