package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"sort"
	"strings"
	"sync"
	"time"
)

const (
	// Comparisons are only fetched for rows that already matched an absolute risk
	// rule. 100 requests cover up to 50 risk advertisers (pre + post) without
	// spending the budget on thousands of non-risk THT members.
	wbComparisonRequestBudget = 100
	wbComparisonCacheTTL      = 30 * time.Minute
)

type wbComparisonCacheEntry struct {
	Metric    wbBatchMetric
	ExpiresAt time.Time
}

var wbComparisonCache = struct {
	sync.Mutex
	items map[string]wbComparisonCacheEntry
}{items: map[string]wbComparisonCacheEntry{}}

type wbComparisonWindow struct {
	PreStart, PreEnd   string
	PostStart, PostEnd string
	PreEndExclusive    string
	PostEndExclusive   string
	Complete           bool
}

func wbBuildComparisonWindow(program, anchor string, now time.Time) (wbComparisonWindow, error) {
	days := 7
	if strings.EqualFold(program, "ST") {
		days = 90
	}
	start, err := time.ParseInLocation("2006-01-02", dateOnly(anchor), cwLocation())
	if err != nil {
		reason := "missing_or_invalid_formal_anchor"
		if strings.EqualFold(program, "ET") {
			reason = "missing_or_invalid_create_time"
		} else if strings.EqualFold(program, "THT") {
			reason = "missing_or_invalid_protection_starttime"
		}
		return wbComparisonWindow{}, fmt.Errorf("%s", reason)
	}
	preStart := start.AddDate(0, 0, -days)
	postEnd := start.AddDate(0, 0, days)
	return wbComparisonWindow{
		PreStart: preStart.Format("2006-01-02"), PreEnd: start.AddDate(0, 0, -1).Format("2006-01-02"),
		PostStart: start.Format("2006-01-02"), PostEnd: postEnd.AddDate(0, 0, -1).Format("2006-01-02"),
		PreEndExclusive: start.Format("2006-01-02"), PostEndExclusive: postEnd.Format("2006-01-02"),
		Complete: !now.In(cwLocation()).Before(postEnd),
	}, nil
}

func wbComparisonCacheKey(source string, rid int, grain, idDimension string, ids []string, start, end string) string {
	normalizedIDs := uniqueNonEmpty(ids)
	sort.Strings(normalizedIDs)
	return strings.Join([]string{source, fmt.Sprintf("%d", rid), grain, idDimension, strings.Join(normalizedIDs, ","), start, end}, "|")
}

func wbCachedComparisonMetric(key string, now time.Time) (wbBatchMetric, bool) {
	wbComparisonCache.Lock()
	defer wbComparisonCache.Unlock()
	entry, ok := wbComparisonCache.items[key]
	if !ok || now.After(entry.ExpiresAt) {
		delete(wbComparisonCache.items, key)
		return wbBatchMetric{}, false
	}
	return entry.Metric, true
}

func wbStoreComparisonMetric(key string, metric wbBatchMetric, now time.Time) {
	wbComparisonCache.Lock()
	defer wbComparisonCache.Unlock()
	if len(wbComparisonCache.items) >= 10000 {
		for candidate, entry := range wbComparisonCache.items {
			if now.After(entry.ExpiresAt) {
				delete(wbComparisonCache.items, candidate)
			}
		}
	}
	wbComparisonCache.items[key] = wbComparisonCacheEntry{Metric: metric, ExpiresAt: now.Add(wbComparisonCacheTTL)}
}

func wbTHTComparisonMetric(ctx context.Context, request *http.Request, id, start, end string, now time.Time, budget *int) (wbBatchMetric, bool, error) {
	key := wbComparisonCacheKey("tht_current_ccr_nfs", 2942519, "account_advertiser_window", "advertiser_id", []string{id}, start, end)
	if metric, ok := wbCachedComparisonMetric(key, now); ok {
		return metric, true, nil
	}
	if *budget <= 0 {
		return wbBatchMetric{}, false, fmt.Errorf("comparison_query_budget_exceeded")
	}
	*budget--
	chunkCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
	defer cancel()
	metrics, err := wbQueryTHTBatch(chunkCtx, request, []string{id}, start, end)
	if err != nil {
		return wbBatchMetric{}, false, err
	}
	pairMetrics, ok := metrics[id]
	if !ok || len(pairMetrics) == 0 {
		return wbBatchMetric{}, false, fmt.Errorf("comparison_result_missing")
	}
	if len(pairMetrics) != 1 {
		return wbBatchMetric{}, false, fmt.Errorf("comparison_pair_ambiguous: advertiser_id %s returned %d account pairs", id, len(pairMetrics))
	}
	metric := pairMetrics[0]
	wbStoreComparisonMetric(key, metric, now)
	return metric, false, nil
}

func wbUnavailableComparison(program, anchor, reason string, now time.Time) wbComparison {
	comparison := wbComparisonResult(program, anchor, nil, nil, now)
	comparison.Status, comparison.MissingReason = metricFailed, reason
	comparison.PreCCRFact, comparison.PostCCRFact = failedMetricFact(reason), failedMetricFact(reason)
	wbFinalizeComparisonFacts(&comparison)
	return comparison
}

const wbNonRiskComparisonReason = "comparison_not_calculated_non_risk"

func wbMarkNonRiskComparison(row *wbRow, now time.Time) {
	row.Comparison = wbUnavailableComparison(row.Program, row.Member.Start, wbNonRiskComparisonReason, now)
	row.Comparison.Status = metricNotApplicable
	row.Comparison.PreCCRFact = metricFact{Status: metricNotApplicable, Reason: wbNonRiskComparisonReason}
	row.Comparison.PostCCRFact = metricFact{Status: metricNotApplicable, Reason: wbNonRiskComparisonReason}
	row.Comparison.IncreaseFact = metricFact{Status: metricNotApplicable, Reason: wbNonRiskComparisonReason}
	row.Comparison.WoWGrowthPct = nil
	row.Comparison.WoWStatus = "not_applicable"
	row.Comparison.WoWMissingReason = wbNonRiskComparisonReason
}

func wbApplyAccountComparisons(ctx context.Context, request *http.Request, rows []wbRow, now time.Time) []wbRow {
	out := append([]wbRow(nil), rows...)
	for i := range out {
		row := &out[i]
		if row.Program != "ET" && row.Program != "ST" {
			continue
		}
		if !wbMatched(*row) {
			wbMarkNonRiskComparison(row, now)
			continue
		}
		window, err := wbBuildComparisonWindow(row.Program, row.Member.Start, now)
		if err != nil {
			row.Comparison = wbUnavailableComparison(row.Program, row.Member.Start, err.Error(), now)
			continue
		}
		if !window.Complete {
			row.Comparison = wbComparisonResult(row.Program, row.Member.Start, nil, nil, now)
			row.Comparison.PreCCRFact = queryingMetricFact("Post 观察窗口尚未结束")
			row.Comparison.PostCCRFact = queryingMetricFact("Post 观察窗口尚未结束")
			wbFinalizeComparisonFacts(&row.Comparison)
			continue
		}
		id := strings.TrimSpace(row.Member.AccountID)
		if id == "" {
			row.Comparison = wbUnavailableComparison(row.Program, row.Member.Start, "missing_account_id", now)
			continue
		}
		source := "et_current_ccr_nfs"
		if row.Program == "ST" {
			source = "st_current_ccr_nfs"
		}
		query := func(start, end string) (wbBatchMetric, error) {
			queryCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
			defer cancel()
			metrics, queryErr := queryAccountCurrentBatch(queryCtx, request, []string{id}, start, end, source, row.Program)
			if queryErr != nil {
				return wbBatchMetric{}, queryErr
			}
			metric, ok := metrics[id]
			if !ok {
				return wbBatchMetric{}, fmt.Errorf("account_window_result_missing")
			}
			if metric.Status != "success" {
				return wbBatchMetric{}, fmt.Errorf("account_window_result_%s", metric.Status)
			}
			return metric, nil
		}
		pre, preErr := query(window.PreStart, window.PreEnd)
		post, postErr := query(window.PostStart, window.PostEnd)
		if preErr != nil || postErr != nil {
			row.Comparison = wbUnavailableComparison(row.Program, row.Member.Start, "account_comparison_source_error", now)
			row.Comparison.Source = map[string]any{"source": source, "grain": "account_window", "window_complete": true, "query_status": "failed", "query_error": sanitizeLogText(fmt.Sprintf("pre=%v; post=%v", preErr, postErr))}
			continue
		}
		row.Comparison = wbSuccessfulComparison(row.Program, row.Member.Start, pre.CCR, post.CCR, now)
		row.Comparison.PreNFS, row.Comparison.PostNFS = pre.NFS, post.NFS
		row.Comparison.PreRevenue, row.Comparison.PostRevenue = pre.Revenue, post.Revenue
		wbFinalizeComparison(&row.Comparison)
		row.Comparison.Source = map[string]any{"source": source, "grain": "account_window", "aggregation": "whole_window_source_metric_not_daily_average", "window_complete": true, "filters": map[string]any{"id_dimension": "account_id", "account_id": id, "pre": []string{window.PreStart, window.PreEnd}, "post": []string{window.PostStart, window.PostEnd}}, "request_ids": map[string]string{"pre": pre.RequestID, "post": post.RequestID}, "log_ids": map[string]string{"pre": pre.LogID, "post": post.LogID}, "query_status": "success"}
	}
	return out
}

func wbApplyAdvertiserComparisons(_ context.Context, _ *http.Request, rows []wbRow, _ time.Time) []wbRow {
	out := append([]wbRow(nil), rows...)
	// ET/ST Advertiser evidence is Current-only. There is no approved independent
	// Advertiser anchor/comparison contract, so never query or copy Account values.
	for i := range out {
		if out[i].Program == "THT" {
			continue
		}
		for j := range out[i].Advertisers {
			adv := &out[i].Advertisers[j]
			adv.PreCCR, adv.PostCCR, adv.CCRDelta, adv.ProtectionCCRGrowthPct = nil, nil, nil, nil
			adv.PreNFS, adv.PostNFS, adv.NFSDelta, adv.NFSGrowthPct = nil, nil, nil, nil
			adv.PreRevenue, adv.PostRevenue, adv.RevenueDelta, adv.RevenueGrowthPct = nil, nil, nil, nil
			adv.ComparisonStatus = metricNotConfigured
			adv.ComparisonReason = "advertiser_anchor_and_comparison_not_configured"
			adv.ComparisonSource = nil
		}
		out[i].AdvertiserTop10 = topAdvertisers(out[i].Advertisers, 10)
	}
	return out
}

// wbApplyLegacyAdvertiserComparisons is intentionally disconnected. It remains
// only so old persisted code references can be reviewed; no runtime path calls it.
func wbApplyLegacyAdvertiserComparisons(ctx context.Context, request *http.Request, rows []wbRow, now time.Time) []wbRow {
	out := append([]wbRow(nil), rows...)
	for i := range out {
		row := &out[i]
		if row.Program == "ST" {
			for j := range row.Advertisers {
				row.Advertisers[j].ComparisonStatus = "unavailable"
				row.Advertisers[j].ComparisonReason = "st_q3_end_date_business_definition_unconfirmed"
				row.Advertisers[j].ComparisonSource = map[string]any{"source": "advertiser_current_ccr_nfs", "rid": "2942519", "sid": "1139137", "grain": "account_advertiser_window", "status": "unavailable", "missing_reason": "st_q3_end_date_business_definition_unconfirmed"}
			}
			row.AdvertiserTop10 = topAdvertisers(row.Advertisers, 10)
			continue
		}
		if row.Program != "ET" || len(row.Advertisers) == 0 {
			continue
		}
		if !wbMatched(*row) {
			for j := range row.Advertisers {
				row.Advertisers[j].ComparisonStatus = "not_applicable"
				row.Advertisers[j].ComparisonReason = wbNonRiskComparisonReason
			}
			row.AdvertiserTop10 = topAdvertisers(row.Advertisers, 10)
			continue
		}
		window, err := wbBuildComparisonWindow(row.Program, row.Member.Start, now)
		if err != nil || !window.Complete {
			reason := "post_observation_window_not_complete"
			if err != nil {
				reason = err.Error()
			}
			for j := range row.Advertisers {
				row.Advertisers[j].ComparisonStatus, row.Advertisers[j].ComparisonReason = "unavailable", reason
			}
			row.AdvertiserTop10 = topAdvertisers(row.Advertisers, 10)
			continue
		}
		accountID := strings.TrimSpace(row.Member.AccountID)
		preRows, preErr := queryEvidenceRows(ctx, request, "weekly_pair_ccr_nfs", []string{accountID}, "account_id", window.PreStart, window.PreEnd)
		postRows, postErr := queryEvidenceRows(ctx, request, "weekly_pair_ccr_nfs", []string{accountID}, "account_id", window.PostStart, window.PostEnd)
		pre, post := map[wbPairKey]map[string]any{}, map[wbPairKey]map[string]any{}
		for _, raw := range preRows {
			pre[wbPairKey{strings.TrimSpace(asString(raw["account_id"])), strings.TrimSpace(asString(raw["advertiser_id"]))}] = raw
		}
		for _, raw := range postRows {
			post[wbPairKey{strings.TrimSpace(asString(raw["account_id"])), strings.TrimSpace(asString(raw["advertiser_id"]))}] = raw
		}
		for j := range row.Advertisers {
			adv := &row.Advertisers[j]
			key := wbPairKey{adv.AccountID, adv.AdvertiserID}
			if preErr != nil || postErr != nil {
				adv.ComparisonStatus, adv.ComparisonReason = "unavailable", "advertiser_comparison_source_error"
				continue
			}
			preRaw, preOK := pre[key]
			postRaw, postOK := post[key]
			if !preOK || !postOK {
				adv.ComparisonStatus, adv.ComparisonReason = "unavailable", "advertiser_pair_window_result_missing"
				continue
			}
			adv.PreCCR, _ = strictWBMetric(preRaw["dynamic_p0_ccr"])
			adv.PostCCR, _ = strictWBMetric(postRaw["dynamic_p0_ccr"])
			adv.PreNFS, _ = strictWBMetric(preRaw["p0_nfs"])
			adv.PostNFS, _ = strictWBMetric(postRaw["p0_nfs"])
			adv.CCRDelta, adv.ProtectionCCRGrowthPct = wbDeltaAndGrowth(adv.PreCCR, adv.PostCCR)
			adv.NFSDelta, adv.NFSGrowthPct = wbDeltaAndGrowth(adv.PreNFS, adv.PostNFS)
			adv.ComparisonStatus = "available"
			if adv.PreCCR == nil || adv.PostCCR == nil {
				adv.ComparisonStatus, adv.ComparisonReason = "unavailable", "advertiser_ccr_missing"
			} else if *adv.PreCCR == 0 {
				adv.ComparisonStatus, adv.ComparisonReason = "baseline_zero", "pre_ccr_is_zero"
			}
			adv.ComparisonSource = map[string]any{"source": "advertiser_current_ccr_nfs", "rid": "2942519", "sid": "1139137", "grain": "account_advertiser_window", "fixed_filters": []string{"is_online=1"}, "status": adv.ComparisonStatus, "pre_window": []string{window.PreStart, window.PreEnd}, "post_window": []string{window.PostStart, window.PostEnd}, "pre_trace": preRaw["_tap_trace"], "post_trace": postRaw["_tap_trace"]}
		}
		row.AdvertiserTop10 = topAdvertisers(row.Advertisers, 10)
	}
	return out
}

// wbApplyRealComparisons queries protection-relative comparison windows from governed sources.
func wbApplyRealComparisons(ctx context.Context, request *http.Request, rows []wbRow, now time.Time) []wbRow {
	out := wbApplyAccountComparisons(ctx, request, rows, now)
	out = wbApplyAdvertiserComparisons(ctx, request, out, now)
	type windowGroup struct {
		window  wbComparisonWindow
		indices []int
	}
	groups := map[string]*windowGroup{}
	for i := range out {
		row := &out[i]
		switch row.Program {
		case "ET", "ST":
			continue
		case "THT":
			if !wbMatched(*row) {
				wbMarkNonRiskComparison(row, now)
				for j := range row.Advertisers {
					row.Advertisers[j].ComparisonStatus = "not_applicable"
					row.Advertisers[j].ComparisonReason = wbNonRiskComparisonReason
				}
				row.AdvertiserTop10 = topAdvertisers(row.Advertisers, 10)
				continue
			}
			id := strings.TrimSpace(row.Member.AdvertiserID)
			window, err := wbBuildComparisonWindow(row.Program, row.Member.Start, now)
			if id == "" || err != nil {
				reason := "missing_advertiser_id"
				if err != nil {
					reason = err.Error()
				}
				row.Comparison = wbUnavailableComparison(row.Program, row.Member.Start, reason, now)
				row.Comparison.Source = map[string]any{"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "account_advertiser_window", "protection_record": row.Member.TicketID, "query_status": "not_eligible"}
				continue
			}
			if !window.Complete {
				row.Comparison = wbComparisonResult(row.Program, row.Member.Start, nil, nil, now)
				row.Comparison.PreCCRFact = queryingMetricFact("Post 观察窗口尚未结束")
				row.Comparison.PostCCRFact = queryingMetricFact("Post 观察窗口尚未结束")
				wbFinalizeComparisonFacts(&row.Comparison)
				row.Comparison.Source = map[string]any{"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "account_advertiser_window", "window_complete": false, "protection_record": row.Member.TicketID, "query_status": metricQuerying}
				continue
			}
			key := strings.Join([]string{window.PreStart, window.PreEnd, window.PostStart, window.PostEnd}, "|")
			if groups[key] == nil {
				groups[key] = &windowGroup{window: window}
			}
			groups[key].indices = append(groups[key].indices, i)
		}
	}

	for _, group := range groups {
		preMetrics, postMetrics := map[string]wbBatchMetric{}, map[string]wbBatchMetric{}
		failed := map[string]string{}
		for start := 0; start < len(group.indices); start += wbTHTMetricChunkSize {
			end := start + wbTHTMetricChunkSize
			if end > len(group.indices) {
				end = len(group.indices)
			}
			ids := make([]string, 0, end-start)
			for _, index := range group.indices[start:end] {
				ids = append(ids, strings.TrimSpace(out[index].Member.AdvertiserID))
			}
			query := func(startDate, endDate string) (map[string][]wbBatchMetric, error) {
				var lastErr error
				for attempt := 1; attempt <= 3; attempt++ {
					if err := ctx.Err(); err != nil {
						return nil, err
					}
					chunkCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
					metrics, err := wbQueryTHTBatch(chunkCtx, request, ids, startDate, endDate)
					cancel()
					if err == nil {
						return metrics, nil
					}
					lastErr = err
					if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) || ctx.Err() != nil {
						return nil, err
					}
					if attempt < 3 {
						timer := time.NewTimer(time.Duration(attempt*2) * time.Second)
						select {
						case <-ctx.Done():
							if !timer.Stop() {
								select {
								case <-timer.C:
								default:
								}
							}
							return nil, ctx.Err()
						case <-timer.C:
						}
					}
				}
				return nil, lastErr
			}
			pre, preErr := query(group.window.PreStart, group.window.PreEnd)
			post, postErr := query(group.window.PostStart, group.window.PostEnd)
			if preErr != nil || postErr != nil {
				reason := sanitizeLogText(fmt.Sprintf("pre=%v; post=%v", preErr, postErr))
				for _, id := range ids {
					failed[id] = reason
				}
				continue
			}
			for id, metrics := range pre {
				for _, metric := range metrics {
					preMetrics[thtPairKey(metric.AccountID, id)] = metric
				}
			}
			for id, metrics := range post {
				for _, metric := range metrics {
					postMetrics[thtPairKey(metric.AccountID, id)] = metric
				}
			}
		}

		for _, index := range group.indices {
			row := &out[index]
			id := strings.TrimSpace(row.Member.AdvertiserID)
			if reason := failed[id]; reason != "" {
				row.Comparison = wbUnavailableComparison(row.Program, row.Member.Start, "comparison_source_error", now)
				row.Comparison.Source = map[string]any{"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "account_advertiser_window", "window_complete": true, "protection_record": row.Member.TicketID, "query_status": "failed", "query_error": reason}
				continue
			}
			accountID := ""
			if len(row.Advertisers) == 1 {
				accountID = strings.TrimSpace(row.Advertisers[0].AccountID)
			}
			pairKey := thtPairKey(accountID, id)
			pre, preOK := preMetrics[pairKey]
			post, postOK := postMetrics[pairKey]
			if !preOK || !postOK {
				row.Comparison = wbUnavailableComparison(row.Program, row.Member.Start, "comparison_result_missing", now)
				row.Comparison.Source = map[string]any{"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "account_advertiser_window", "window_complete": true, "protection_record": row.Member.TicketID, "query_status": "failed"}
				continue
			}
			row.Comparison = wbSuccessfulComparison(row.Program, row.Member.Start, pre.CCR, post.CCR, now)
			row.Comparison.PreNFS, row.Comparison.PostNFS = pre.NFS, post.NFS
			wbFinalizeComparison(&row.Comparison)
			queryStatus := "success"
			if pre.CCR == nil || post.CCR == nil {
				queryStatus = metricSourceNull
			}
			row.Comparison.Source = map[string]any{
				"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "account_advertiser_window", "window_complete": true,
				"filters":     map[string]any{"id_dimension": "advertiser_id", "advertiser_id": id, "pre": []string{group.window.PreStart, group.window.PreEnd}, "post": []string{group.window.PostStart, group.window.PostEnd}},
				"request_ids": map[string]string{"pre": pre.RequestID, "post": post.RequestID}, "protection_record": row.Member.TicketID, "query_status": queryStatus,
			}
			for j := range row.Advertisers {
				if row.Advertisers[j].AdvertiserID != id {
					continue
				}
				row.Advertisers[j].PreCCR = row.Comparison.PreCCR
				row.Advertisers[j].PostCCR = row.Comparison.PostCCR
				row.Advertisers[j].CCRDelta = row.Comparison.CCRDelta
				row.Advertisers[j].CCRGrowthPct = row.Comparison.CCRGrowthPct
				row.Advertisers[j].PreNFS = row.Comparison.PreNFS
				row.Advertisers[j].PostNFS = row.Comparison.PostNFS
				row.Advertisers[j].NFSDelta = row.Comparison.NFSDelta
				row.Advertisers[j].NFSGrowthPct = row.Comparison.NFSGrowthPct
				row.Advertisers[j].ComparisonSource = row.Comparison.Source
				row.Advertisers[j].ComparisonStatus = row.Comparison.Status
				row.Advertisers[j].ComparisonReason = row.Comparison.MissingReason
			}
			row.AdvertiserTop10 = topAdvertisers(row.Advertisers, 10)
		}
	}
	return out
}
