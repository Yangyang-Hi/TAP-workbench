package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"
)

func TestComparisonContractStatuses(t *testing.T) {
	now := time.Date(2026, 10, 21, 12, 0, 0, 0, cwLocation())
	pre, post := 0.0, 5.0
	zero := wbComparisonResult("ET", "2026-10-01", &pre, &post, now)
	if zero.Status != "baseline_zero" || zero.CCRGrowthPct != nil {
		t.Fatalf("pre=0 must not produce growth: %+v", zero)
	}
	missing := wbComparisonResult("THT", "2026-10-01", nil, &post, now)
	if missing.Status != "unavailable" || missing.MissingReason != "pre_ccr_missing" {
		t.Fatalf("missing reason lost: %+v", missing)
	}
	incomplete := wbComparisonResult("ET", "2026-10-20", &post, &post, now)
	if incomplete.Status != "window_incomplete" || incomplete.CCRGrowthPct != nil {
		t.Fatalf("incomplete window computed: %+v", incomplete)
	}
	st := wbComparisonResult("ST", "2026-10-01", &post, &post, now)
	if st.Status != "unavailable" || st.MissingReason != "st_q3_end_date_business_definition_unconfirmed" || st.QoQGrowthPct != nil {
		t.Fatalf("ST unconfirmed business window must stay unavailable: %+v", st)
	}
	pre, post = 2, 3
	valid := wbComparisonResult("ET", "2026-10-01", &pre, &post, now)
	if valid.Status != "available" || valid.CCRGrowthPct == nil || *valid.CCRGrowthPct != 50 || valid.WoWGrowthPct != nil {
		t.Fatalf("growth formula mismatch: %+v", valid)
	}
}

func putReadModelCase(t *testing.T, item cwCase) {
	t.Helper()
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	raw, _ := json.Marshal(item)
	if _, err = db.Exec("INSERT INTO tap_cases(id,version,body) VALUES(?,?,?)", item.ID, item.Version, string(raw)); err != nil {
		t.Fatal(err)
	}
}

func readModelFixture(t *testing.T, count int) wbJob {
	t.Helper()
	wbTestEnv(t)
	job := wbJob{ID: "scan-week", BatchID: "TAP-WEEK-2026-10-12-2026-10-18", AsOf: "2026-10-19T01:00:00Z", RuleVersion: "rule-v1", Principal: wbSchedulerPrincipal, Status: "ready", Complete: true, Request: wbRequest{Program: "ET", Start: "2026-10-12", End: "2026-10-18"}}
	for i := 0; i < count; i++ {
		ccr := float64(100 - i)
		job.Rows = append(job.Rows, wbRow{ID: fmt.Sprintf("row-%02d", i), Program: "ET", Member: wbMember{AccountID: fmt.Sprintf("70000000000000000%02d", i), Name: fmt.Sprintf("Client %02d", i), Submitter: "Alice", Region: "APAC", Tier: "ET", Start: "2026-09-01"}, CCR: &ccr, NFS: f64(350), Level: "critical", Reasons: []string{"absolute"}})
	}
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	return job
}

func TestBatchesAndCustomReadAreRealAndSideEffectFree(t *testing.T) {
	wbTestEnv(t)
	r := httptest.NewRecorder()
	wbBatchesHandler(r, wbReq("reader"))
	if r.Code != 200 || !strings.Contains(r.Body.String(), `"status":"empty"`) || !strings.Contains(r.Body.String(), `"batches":[]`) {
		t.Fatal(r.Body.String())
	}
	job := readModelFixture(t, 1)
	path, _ := wbStatePath()
	before, _ := os.ReadFile(path)

	oldMembers, oldET, oldEvidence := wbLoadMembers, wbQueryETBatch, wbQueryPairEvidence
	defer func() { wbLoadMembers, wbQueryETBatch, wbQueryPairEvidence = oldMembers, oldET, oldEvidence }()
	wbLoadMembers = func(_ context.Context, _ *http.Request, q wbRequest, _ wbConfig) ([]wbMember, bool, error) {
		if q.Start != "2026-10-01" || q.End != "2026-10-07" || q.MemberEnd != q.End {
			t.Fatalf("custom dates not propagated: %+v", q)
		}
		return []wbMember{{AccountID: "7000000000000000001", Name: "Custom Client", Region: "APAC", Tier: "ET", Start: "2026-09-01"}}, true, nil
	}
	wbQueryETBatch = func(_ context.Context, _ *http.Request, ids []string, start, end string) (map[string]wbBatchMetric, error) {
		if len(ids) != 1 || start != "2026-10-01" || end != "2026-10-07" {
			t.Fatalf("wrong metric window: %v %s %s", ids, start, end)
		}
		return map[string]wbBatchMetric{ids[0]: {Status: "success", CCR: f64(50), NFS: f64(400), RevenueStatus: "no_data"}}, nil
	}
	wbQueryPairEvidence = func(context.Context, *http.Request, []wbMember, wbRequest, wbRule) (map[string][]wbAdvertiserEvidence, error) {
		return map[string][]wbAdvertiserEvidence{}, nil
	}

	custom := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=custom&program=ET&start_date=2026-10-01&end_date=2026-10-07", nil).WithContext(wbReq("reader").Context())
	out := httptest.NewRecorder()
	wbReadModelHandler(out, custom)
	after, _ := os.ReadFile(path)
	if out.Code != 200 || !strings.Contains(out.Body.String(), `"status":"available"`) || !strings.Contains(out.Body.String(), `"risk_customers":{"value":1`) || !strings.Contains(out.Body.String(), `"status":"not_applicable"`) || string(before) != string(after) {
		t.Fatalf("custom read mutated weekly state or returned wrong result: %s", out.Body.String())
	}
	b := httptest.NewRecorder()
	wbBatchesHandler(b, wbReq("reader"))
	if !strings.Contains(b.Body.String(), job.BatchID) || !strings.Contains(b.Body.String(), "2026-W42") {
		t.Fatal(b.Body.String())
	}
}

func TestWeeklyCardsUseFullSetAndSuccessfulNotificationDedupe(t *testing.T) {
	job := readModelFixture(t, 3)
	for i, row := range job.Rows {
		item := cwCase{ID: fmt.Sprintf("case-%d", i), Version: 1, Status: "open", ScanID: job.ID, Row: row, Window: job.Request, Fields: map[string]string{}}
		putReadModelCase(t, item)
	}
	db, _ := cwDB()
	now := cwNow()
	// Duplicate successes count once; failed and queued records never count as handled.
	for _, values := range [][4]string{{"sent-1", "case-1", "sent", "om1"}, {"sent-2", "case-1", "sent", "om2"}, {"failed", "case-2", "failed", ""}, {"queued", "case-2", "pending", ""}} {
		_, err := db.Exec("INSERT INTO tap_outbox(id,case_id,recipient,kind,status,message_id,created_at,updated_at) VALUES(?,?,?,'send',?,?,?,?)", values[0], values[1], "open_id:ou_fixture", values[2], values[3], now, now)
		if err != nil {
			t.Fatal(err)
		}
	}
	db.Close()
	req := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly&page=1&page_size=1", nil).WithContext(wbReq("reader").Context())
	rr := httptest.NewRecorder()
	wbReadModelHandler(rr, req)
	var body struct {
		Data struct {
			Cards      map[string]wbCardValue `json:"cards"`
			Rows       []wbReadRow            `json:"rows"`
			Pagination map[string]int         `json:"pagination"`
		} `json:"data"`
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	if rr.Code != 200 || len(body.Data.Rows) != 1 || body.Data.Pagination["total"] != 3 || *body.Data.Cards["queried_customers"].Value != 3 || *body.Data.Cards["handled"].Value != 1 || *body.Data.Cards["pending"].Value != 2 || body.Data.Cards["auto_alerted"].Value != nil {
		t.Fatalf("cards/pagination mismatch: %s", rr.Body.String())
	}
}

func TestOnlyMineRequiresUniqueVerifiedIdentityMapping(t *testing.T) {
	job := readModelFixture(t, 1)
	req := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly&only_mine=true", nil).WithContext(wbReq("alice").Context())
	blocked := httptest.NewRecorder()
	wbReadModelHandler(blocked, req)
	if blocked.Code != 422 {
		t.Fatalf("unmapped identity accepted: %s", blocked.Body.String())
	}
	db, _ := cwDB()
	_, err := db.Exec(`INSERT INTO tap_identity_mappings(record_id,business_name,email,aeolus_name,match_status,enabled,manual_disabled) VALUES('mine','Alice','alice@example.com','Alice Aeolus','已确认',1,0)`)
	db.Close()
	if err != nil {
		t.Fatal(err)
	}
	db, _ = cwDB()
	aliases, reason := wbReadIdentity(db, "alice")
	db.Close()
	if reason != "" || len(aliases) == 0 || !wbRowMatches(job.Rows[0], nil, map[string]string{"only_mine": "true"}, aliases, nil) {
		t.Fatalf("verified identity matching failed aliases=%#v reason=%s", aliases, reason)
	}
	reassigned := job.Rows[0]
	reassigned.Member.Submitter = "Other"
	if !wbRowMatches(reassigned, nil, map[string]string{"only_mine": "true"}, aliases, []cwNotice{{Kind: "send", TargetEmail: "alice@example.com"}}) {
		t.Fatal("actual verified recipient cannot find reassigned event")
	}
	ok := httptest.NewRecorder()
	wbReadModelHandler(ok, req)
	if ok.Code != 200 || !strings.Contains(ok.Body.String(), "700000000000000000") {
		t.Fatalf("verified mapping failed: %s", ok.Body.String())
	}
}

func TestGrowthTop20RanksFullSetBeforePagination(t *testing.T) {
	rows := make([]wbReadRow, 25)
	for i := range rows {
		value := float64(i + 1)
		rows[i] = wbReadRow{RowID: fmt.Sprint(i), Program: "ET", Tier: "ET", Region: "APAC", Comparison: wbComparison{Status: "available", CCRGrowthPct: &value}}
	}
	negative := -1.0
	rows = append(rows, wbReadRow{RowID: "negative", Tier: "ET", Region: "APAC", Comparison: wbComparison{Status: "available", CCRGrowthPct: &negative}})
	top := wbGrowthTop20(rows)[wbGrowthGroupKey("ET", "ET", "APAC")]
	if len(top) != 20 || *top[0].Comparison.CCRGrowthPct != 25 || *top[19].Comparison.CCRGrowthPct != 6 {
		t.Fatalf("full-set Top20 mismatch: %+v", top)
	}
}

func TestHistoricalRowsRemainCompatible(t *testing.T) {
	var old wbRow
	if err := json.Unmarshal([]byte(`{"id":"legacy","program":"ET","member":{"account_id":"7000000000000000001","protection_starttime":""},"ccr":12,"nfs":3,"level":"critical","reasons":["legacy"]}`), &old); err != nil {
		t.Fatal(err)
	}
	view := wbToReadRow(wbJob{ID: "old"}, old, nil, nil, time.Now())
	if view.RowID != "legacy" || view.Comparison.Status != "unavailable" || view.Comparison.MissingReason == "" {
		t.Fatalf("legacy row broken: %+v", view)
	}
}

func TestHistoricalTHTRevenueWithoutPersistedStatusIsUnknown(t *testing.T) {
	ccr, nfs := 12.0, 3.0
	legacy := wbRow{
		ID:      "legacy-tht",
		Program: "THT",
		Member:  wbMember{AdvertiserID: "7000000000000000001", Start: "2026-09-01"},
		Advertisers: []wbAdvertiserEvidence{{
			AdvertiserID: "7000000000000000001",
			CCR:          &ccr,
			NFS:          &nfs,
		}},
	}
	view := wbToReadRow(wbJob{ID: "old"}, legacy, nil, nil, time.Now())
	if len(view.AdvertiserTop10) != 1 {
		t.Fatalf("legacy advertiser missing: %+v", view)
	}
	advertiser := view.AdvertiserTop10[0]
	if advertiser.RevenueStatus != "unknown" || advertiser.RevenueError != "legacy_scan_revenue_status_not_persisted" {
		t.Fatalf("missing legacy status was misclassified: %+v", advertiser)
	}
	if advertiser.RevenueStatus == "source_error" || strings.Contains(advertiser.RevenueError, "147999") {
		t.Fatalf("legacy status fabricated an upstream error: %+v", advertiser)
	}
}

func TestWeeklyReadModelUsesPersistedFactsWithoutVQSOrWrites(t *testing.T) {
	wbTestEnv(t)
	ccr, nfs := 4.0, 60.0
	job := wbJob{ID: "tht-scan", BatchID: "TAP-WEEK-2026-10-12-2026-10-18", AsOf: "2026-10-21T10:00:00Z", Status: "ready", Complete: true, Request: wbRequest{Program: "THT", Start: "2026-10-12", End: "2026-10-18"}, Rows: []wbRow{
		{ID: "one", Program: "THT", Member: wbMember{AccountID: "same-account", AdvertiserID: "adv-1", Start: "2026-09-01"}, CCR: &ccr, NFS: &nfs},
		{ID: "two", Program: "THT", Member: wbMember{AccountID: "same-account", AdvertiserID: "adv-2", Start: "2026-09-01"}, CCR: &ccr, NFS: &nfs},
	}}
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	path, _ := wbStatePath()
	before, _ := os.ReadFile(path)
	originalQuery := wbQueryTHTBatch
	calls := 0
	wbQueryTHTBatch = func(context.Context, *http.Request, []string, string, string) (map[string][]wbBatchMetric, error) {
		calls++
		return nil, fmt.Errorf("read model must not query VQS")
	}
	defer func() { wbQueryTHTBatch = originalQuery }()

	req := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly", nil).WithContext(wbReq("reader").Context())
	rr := httptest.NewRecorder()
	wbReadModelHandler(rr, req)
	after, _ := os.ReadFile(path)
	var body struct {
		Data struct {
			Funnel      map[string]wbProgramFunnel `json:"funnel"`
			Pagination  map[string]int             `json:"pagination"`
			SideEffects bool                       `json:"side_effects"`
		} `json:"data"`
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	if rr.Code != 200 || calls != 0 || string(before) != string(after) || body.Data.SideEffects {
		t.Fatalf("GET caused query/write side effects: code=%d calls=%d side_effects=%t body=%s", rr.Code, calls, body.Data.SideEffects, rr.Body.String())
	}
	if body.Data.Pagination["total"] != 2 || *body.Data.Funnel["THT"].Watch.Value != 2 || *body.Data.Funnel["THT"].DistinctClients.Value != 2 {
		t.Fatalf("funnel/risk list do not share advertiser-distinct pool: %s", rr.Body.String())
	}
}

func TestReadModelBackfillsLatestPersistedSemanticsWithoutQuery(t *testing.T) {
	legacy := wbRow{Program: "THT", Member: wbMember{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001"}, Advertisers: []wbAdvertiserEvidence{{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001"}}}
	latest := wbJob{AsOf: "2026-10-23T05:00:00Z", Rows: []wbRow{{Advertisers: []wbAdvertiserEvidence{{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001", SemanticsLabel: "content_issues - sensitive_content - unsure_violence -", SemanticsStatus: "available"}}}}}
	index := wbLatestSemanticsEvidence(map[string][]wbJob{"latest": {latest}})
	got := wbBackfillSemantics(legacy, index)
	if len(got.Advertisers) != 1 || got.Advertisers[0].SemanticsLabel != "content_issues - sensitive_content - unsure_violence -" || got.Advertisers[0].SemanticsStatus != "backfilled_available" {
		t.Fatalf("latest persisted semantics not backfilled: %+v", got.Advertisers)
	}
	missing := wbBackfillSemantics(wbRow{Member: legacy.Member, Advertisers: []wbAdvertiserEvidence{{AdvertiserID: "999"}}}, index)
	if missing.Advertisers[0].SemanticsStatus != "legacy_not_captured" {
		t.Fatalf("legacy missing field not distinguished: %+v", missing.Advertisers[0])
	}
}

func TestRiskListDoesNotDereferenceMissingGrowthForDuplicateCustomer(t *testing.T) {
	growth := 50.0
	rows := []wbReadRow{
		{RowID: "same-event", Program: "ET", AccountID: "same", Tier: "ET", Region: "APAC", CCR: f64(4), NFS: f64(60)},
		{RowID: "same-event", Program: "ET", AccountID: "same", Tier: "ET", Region: "APAC", Comparison: wbComparison{Status: "available", CCRGrowthPct: &growth}},
	}
	if got := wbRiskList(rows, "combined"); len(got) == 0 {
		t.Fatal("expected at least one risk row")
	}
}
