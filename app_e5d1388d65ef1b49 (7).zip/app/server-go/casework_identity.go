package main

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/mail"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	cwMappingSheetToken = "J4H8swHMIh0le6tcJbjmNzWnytp"
	cwMappingSheetID    = "e1e5ac"
	cwMappingRange      = "e1e5ac!A:G (按工作表总行数分批读取)"
)

type cwIdentityMapping struct {
	RecordID          string `json:"record_id"`
	Region            string `json:"region"`
	BusinessName      string `json:"business_name"`
	Email             string `json:"email,omitempty"`
	AeolusName        string `json:"aeolus_name"`
	MatchStatus       string `json:"match_status"`
	MatchNote         string `json:"match_note"`
	VerifiedAt        string `json:"verified_at"`
	Enabled           bool   `json:"enabled"`
	ManualDisabled    bool   `json:"manual_disabled"`
	SheetToken        string `json:"sheet_token"`
	SheetID           string `json:"sheet_id"`
	SheetRevision     string `json:"sheet_revision"`
	SheetRow          int    `json:"sheet_row"`
	RecordVersion     string `json:"record_version"`
	SourceUpdatedAt   string `json:"source_updated_at"`
	SourceSyncedAt    string `json:"source_synced_at"`
	OverrideUpdatedAt string `json:"override_updated_at,omitempty"`
	OverrideBy        string `json:"override_by,omitempty"`
	OverrideNote      string `json:"override_note,omitempty"`
}

type cwMappingResolution struct {
	Status       string
	Reason       string
	Mapping      *cwIdentityMapping
	MatchedAlias string
}

type cwSheetSnapshot struct {
	Revision string
	Values   [][]string
}

var cwFetchMappingSheet = cwFetchMappingSheetLive
var cwResolveBotOpenID = cwResolveOpenID

func cwExactEmail(s string) (string, bool) {
	s = strings.ToLower(strings.TrimSpace(s))
	a, err := mail.ParseAddress(s)
	return s, err == nil && a.Address == s && strings.Contains(s, "@") && !strings.ContainsAny(s, " \t\r\n")
}

func cwNormalizeIdentity(s string) string {
	s = strings.TrimSpace(s)
	if strings.HasPrefix(s, "@") {
		s = strings.TrimSpace(strings.TrimPrefix(s, "@"))
	}
	return strings.ToLower(s)
}
func cwNormalizeRegion(s string) string { return strings.ToLower(strings.TrimSpace(s)) }

func cwMaskID(s string) string {
	s = strings.TrimSpace(s)
	if len(s) <= 8 {
		return "***"
	}
	return s[:4] + "***" + s[len(s)-4:]
}
func cwMaskEmail(s string) string {
	parts := strings.SplitN(s, "@", 2)
	if len(parts) != 2 {
		return "***"
	}
	local := "***"
	if len(parts[0]) > 2 {
		local = parts[0][:2] + "***"
	}
	return local + "@" + parts[1]
}
func cwIdentityFormat(s string) string {
	if strings.TrimSpace(s) == "" {
		return "missing"
	}
	if _, ok := cwExactEmail(s); ok {
		return "complete_email"
	}
	if strings.ContainsAny(s, "<>,;") {
		return "compound_or_ambiguous"
	}
	return "name_or_username"
}

func cwCell(row []string, i int) string {
	if i >= len(row) {
		return ""
	}
	return strings.TrimSpace(row[i])
}
func cwMappingID(region, business, email, aeolus string) string {
	h := sha256.Sum256([]byte(strings.Join([]string{cwNormalizeRegion(region), cwNormalizeIdentity(business), strings.ToLower(strings.TrimSpace(email)), cwNormalizeIdentity(aeolus)}, "\x00")))
	return "map_" + hex.EncodeToString(h[:12])
}
func cwSheetMappingID(row int) string {
	h := sha256.Sum256([]byte(cwMappingSheetToken + "\x00" + cwMappingSheetID + "\x00" + strconv.Itoa(row)))
	return "sheet_" + hex.EncodeToString(h[:12])
}
func cwRowVersion(row []string) string {
	h := sha256.Sum256([]byte(strings.Join(row, "\x00")))
	return hex.EncodeToString(h[:])
}

func cwFetchMappingSheetLive(ctx context.Context) (cwSheetSnapshot, error) {
	token, err := cwAccessToken(ctx)
	if err != nil {
		return cwSheetSnapshot{}, fmt.Errorf("mapping_refresh_failed: bot credentials: %w", err)
	}
	// Read the actual grid size. A fixed A1:G105 silently loses future members.
	meta, err := cwHTTP(ctx, http.MethodGet, "/open-apis/sheets/v3/spreadsheets/"+cwMappingSheetToken+"/sheets/query", token, nil)
	if err != nil {
		return cwSheetSnapshot{}, fmt.Errorf("mapping_refresh_failed: sheet metadata: %w", err)
	}
	data, _ := meta["data"].(map[string]any)
	sheets, _ := data["sheets"].([]any)
	rowCount := 0
	for _, v := range sheets {
		sheet, _ := v.(map[string]any)
		if asString(sheet["sheet_id"]) == cwMappingSheetID {
			grid, _ := sheet["grid_properties"].(map[string]any)
			rowCount = int(asInt64(grid["row_count"]))
		}
	}
	if rowCount < 1 || rowCount > 100000 {
		return cwSheetSnapshot{}, errors.New("mapping_refresh_failed: missing sheet or unsupported row count")
	}
	snapshot := cwSheetSnapshot{Values: make([][]string, rowCount)}
	for start := 1; start <= rowCount; start += 1000 {
		end := min(start+999, rowCount)
		sheetRange := fmt.Sprintf("%s!A%d:G%d", cwMappingSheetID, start, end)
		path := "/open-apis/sheets/v2/spreadsheets/" + cwMappingSheetToken + "/values/" + url.PathEscape(sheetRange)
		out, err := cwHTTP(ctx, http.MethodGet, path, token, nil)
		if err != nil {
			return cwSheetSnapshot{}, fmt.Errorf("mapping_refresh_failed: sheet read: %w", err)
		}
		data, _ := out["data"].(map[string]any)
		revision := strings.TrimSpace(cwParseRevision(data["revision"]))
		if revision == "" {
			revision = strings.TrimSpace(cwParseRevision(out["revision"]))
		}
		if revision == "" || (snapshot.Revision != "" && revision != snapshot.Revision) {
			return cwSheetSnapshot{}, errors.New("mapping_refresh_failed: missing revision or sheet changed during paged read")
		}
		snapshot.Revision = revision
		vr, _ := data["valueRange"].(map[string]any)
		if vr == nil {
			vr, _ = data["value_range"].(map[string]any)
		}
		raw, ok := vr["values"].([]any)
		if !ok || len(raw) > end-start+1 {
			return cwSheetSnapshot{}, errors.New("mapping_refresh_failed: invalid values array")
		}
		for i, item := range raw {
			cells, ok := item.([]any)
			if !ok {
				return cwSheetSnapshot{}, errors.New("mapping_refresh_failed: invalid sheet row")
			}
			row := make([]string, len(cells))
			for j, cell := range cells {
				row[j] = strings.TrimSpace(asString(cell))
			}
			snapshot.Values[start-1+i] = row
		}
	}
	return snapshot, nil
}

func cwSyncIdentityMappings(ctx context.Context, db *sql.DB) (string, error) {
	snapshot, err := cwFetchMappingSheet(ctx)
	if err != nil {
		return "", err
	}
	if len(snapshot.Values) < 1 || cwCell(snapshot.Values[0], 0) != "区域" || cwCell(snapshot.Values[0], 2) != "已确认企业邮箱" {
		return "", errors.New("mapping_refresh_failed: unexpected sheet headers")
	}
	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return "", err
	}
	defer tx.Rollback()
	now := cwNow()
	// Delete and repopulate in one transaction; second-resolution timestamps cannot
	// identify a sync generation when two refreshes occur within one second.
	disabled := map[string]cwIdentityMapping{}
	oldRows, err := tx.Query("SELECT "+cwMappingColumns+" FROM tap_identity_mappings WHERE sheet_token=? AND sheet_id=? AND manual_disabled=1", cwMappingSheetToken, cwMappingSheetID)
	if err != nil {
		return "", err
	}
	for oldRows.Next() {
		m, e := cwScanMapping(oldRows)
		if e != nil {
			oldRows.Close()
			return "", e
		}
		disabled[cwMappingID(m.Region, m.BusinessName, m.Email, m.AeolusName)] = m
	}
	oldErr := oldRows.Err()
	oldRows.Close()
	if oldErr != nil {
		return "", oldErr
	}
	if _, err = tx.Exec("DELETE FROM tap_identity_mappings WHERE sheet_token=? AND sheet_id=?", cwMappingSheetToken, cwMappingSheetID); err != nil {
		return "", err
	}
	for i, row := range snapshot.Values[1:] {
		if strings.TrimSpace(strings.Join(row, "")) == "" {
			continue
		}
		region, business, email, aeolus := cwCell(row, 0), cwCell(row, 1), strings.ToLower(cwCell(row, 2)), cwCell(row, 3)
		status, note, verified := cwCell(row, 4), cwCell(row, 5), cwCell(row, 6)
		id := cwSheetMappingID(i + 2)
		validEmail, emailOK := cwExactEmail(email)
		if emailOK {
			email = validEmail
		}
		defaultEnabled := status == "已确认" && emailOK
		_, err = tx.Exec(`INSERT INTO tap_identity_mappings(record_id,region,business_name,email,aeolus_name,match_status,match_note,verified_at,enabled,manual_disabled,sheet_token,sheet_id,sheet_revision,sheet_row,record_version,source_updated_at,source_synced_at)
			VALUES(?,?,?,?,?,?,?,?,?,0,?,?,?,?,?,?,?)
			ON CONFLICT(record_id) DO UPDATE SET region=excluded.region,business_name=excluded.business_name,email=excluded.email,aeolus_name=excluded.aeolus_name,match_status=excluded.match_status,match_note=excluded.match_note,verified_at=excluded.verified_at,enabled=CASE WHEN tap_identity_mappings.manual_disabled=1 THEN 0 ELSE excluded.enabled END,sheet_revision=excluded.sheet_revision,sheet_row=excluded.sheet_row,record_version=excluded.record_version,source_updated_at=excluded.source_updated_at,source_synced_at=excluded.source_synced_at`, id, region, business, email, aeolus, status, note, verified, defaultEnabled, cwMappingSheetToken, cwMappingSheetID, snapshot.Revision, i+2, cwRowVersion(row), verified, now)
		if err != nil {
			return "", err
		}
		// Keep an operator's disable against the same identity when rows are reordered.
		// Matching aliases also preserves disable if the person's email is corrected.
		var prior *cwIdentityMapping
		for _, d := range disabled {
			d := d
			if cwNormalizeRegion(d.Region) == cwNormalizeRegion(region) && cwNormalizeIdentity(d.BusinessName) == cwNormalizeIdentity(business) && cwNormalizeIdentity(d.AeolusName) == cwNormalizeIdentity(aeolus) {
				prior = &d
				break
			}
		}
		if prior != nil {
			if _, err = tx.Exec("UPDATE tap_identity_mappings SET enabled=0,manual_disabled=1,override_updated_at=?,override_by=?,override_note=? WHERE record_id=?", prior.OverrideUpdatedAt, prior.OverrideBy, prior.OverrideNote, id); err != nil {
				return "", err
			}
		}
	}
	if err = tx.Commit(); err != nil {
		return "", err
	}
	return snapshot.Revision, nil
}

func cwScanMapping(rows *sql.Rows) (cwIdentityMapping, error) {
	var m cwIdentityMapping
	var enabled, disabled int
	err := rows.Scan(&m.RecordID, &m.Region, &m.BusinessName, &m.Email, &m.AeolusName, &m.MatchStatus, &m.MatchNote, &m.VerifiedAt, &enabled, &disabled, &m.SheetToken, &m.SheetID, &m.SheetRevision, &m.SheetRow, &m.RecordVersion, &m.SourceUpdatedAt, &m.SourceSyncedAt, &m.OverrideUpdatedAt, &m.OverrideBy, &m.OverrideNote)
	m.Enabled, m.ManualDisabled = enabled == 1, disabled == 1
	return m, err
}

const cwMappingColumns = `record_id,region,business_name,email,aeolus_name,match_status,match_note,verified_at,enabled,manual_disabled,sheet_token,sheet_id,sheet_revision,sheet_row,record_version,source_updated_at,source_synced_at,override_updated_at,override_by,override_note`

func cwResolveMapping(db *sql.DB, submitter, region string) (cwMappingResolution, error) {
	name := cwNormalizeIdentity(submitter)
	if name == "" {
		return cwMappingResolution{Status: "pending", Reason: "missing_original_submitter"}, nil
	}
	rows, err := db.Query("SELECT "+cwMappingColumns+" FROM tap_identity_mappings WHERE lower(trim(business_name))=? OR lower(trim(aeolus_name))=?", name, name)
	if err != nil {
		return cwMappingResolution{}, err
	}
	defer rows.Close()
	all := []cwIdentityMapping{}
	for rows.Next() {
		m, e := cwScanMapping(rows)
		if e != nil {
			return cwMappingResolution{}, e
		}
		all = append(all, m)
	}
	if err = rows.Err(); err != nil {
		return cwMappingResolution{}, err
	}
	if len(all) == 0 {
		return cwMappingResolution{Status: "pending", Reason: "mapping_missing"}, nil
	}
	confirmed := []cwIdentityMapping{}
	for _, m := range all {
		if m.MatchStatus == "已确认" {
			confirmed = append(confirmed, m)
		}
	}
	if len(confirmed) == 0 {
		return cwMappingResolution{Status: "pending", Reason: "mapping_unconfirmed"}, nil
	}
	eligible := []cwIdentityMapping{}
	for _, m := range confirmed {
		if _, ok := cwExactEmail(m.Email); ok && m.Enabled && !m.ManualDisabled {
			eligible = append(eligible, m)
		}
	}
	if len(eligible) == 0 {
		for _, m := range confirmed {
			if _, ok := cwExactEmail(m.Email); !ok {
				return cwMappingResolution{Status: "blocked", Reason: "invalid_email", Mapping: &m}, nil
			}
		}
		return cwMappingResolution{Status: "blocked", Reason: "mapping_disabled", Mapping: &confirmed[0]}, nil
	}
	uniqueEmails := func(items []cwIdentityMapping) map[string]cwIdentityMapping {
		out := map[string]cwIdentityMapping{}
		for _, m := range items {
			out[strings.ToLower(m.Email)] = m
		}
		return out
	}
	chosen := uniqueEmails(eligible)
	if len(chosen) > 1 {
		regionMatches := []cwIdentityMapping{}
		for _, m := range eligible {
			if cwNormalizeRegion(m.Region) != "" && cwNormalizeRegion(m.Region) == cwNormalizeRegion(region) {
				regionMatches = append(regionMatches, m)
			}
		}
		chosen = uniqueEmails(regionMatches)
		if len(chosen) != 1 {
			return cwMappingResolution{Status: "conflict", Reason: "multiple_confirmed_emails_region_not_unique"}, nil
		}
	}
	var m cwIdentityMapping
	for _, item := range chosen {
		m = item
	}
	alias := m.BusinessName
	if cwNormalizeIdentity(m.AeolusName) == name {
		alias = m.AeolusName
	}
	return cwMappingResolution{Status: "matched", Reason: "confirmed_enabled_exact", Mapping: &m, MatchedAlias: alias}, nil
}

func cwResolveOpenID(ctx context.Context, email string) (string, string) {
	id, diagnostic := cwResolveOpenIDDiagnostic(ctx, email)
	cwRememberOpenIDDiagnostic(email, diagnostic)
	return id, diagnostic.Status
}

func cwMappingPublic(m cwIdentityMapping) map[string]any {
	return map[string]any{"record_id": m.RecordID, "region": m.Region, "business_name": m.BusinessName, "aeolus_name": m.AeolusName, "match_status": m.MatchStatus, "enabled": m.Enabled, "manual_disabled": m.ManualDisabled, "email_masked": cwMaskEmail(m.Email), "sheet_id": m.SheetID, "sheet_revision": m.SheetRevision, "sheet_row": m.SheetRow, "record_version": m.RecordVersion, "verified_at": m.VerifiedAt, "source_synced_at": m.SourceSyncedAt, "override_updated_at": m.OverrideUpdatedAt, "override_by": m.OverrideBy, "override_note": m.OverrideNote}
}

func cwMappingCacheState(db *sql.DB) (revision, syncedAt string, ageSeconds int64) {
	_ = db.QueryRow("SELECT COALESCE(MAX(sheet_revision),''),COALESCE(MAX(source_synced_at),'') FROM tap_identity_mappings").Scan(&revision, &syncedAt)
	if parsed, err := time.Parse(time.RFC3339, syncedAt); err == nil {
		ageSeconds = int64(max(0, int(time.Since(parsed).Seconds())))
	}
	return revision, syncedAt, ageSeconds
}

func cwIdentityMappingsHandler(w http.ResponseWriter, r *http.Request) {
	cfg, err := cwLoadConfig()
	if err != nil || !cwOperator(cfg, requestUsername(r)) {
		cwWriteError(w, cwErr(403, "仅运营可查看人员映射"))
		return
	}
	db, err := cwDB()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	defer db.Close()
	ctx, cancel := context.WithTimeout(r.Context(), 15*time.Second)
	defer cancel()
	revision, err := cwSyncIdentityMappings(ctx, db)
	sourceStatus, sourceError := "fresh", ""
	_, sourceSyncedAt, cacheAgeSeconds := cwMappingCacheState(db)
	if err != nil {
		logMsg("[casework] mapping_refresh_failed: "+err.Error(), "plugin")
		sourceStatus, sourceError = "stale", cwSafeAPIMessage(err.Error(), "")
		revision, sourceSyncedAt, cacheAgeSeconds = cwMappingCacheState(db)
	}
	rows, err := db.Query("SELECT " + cwMappingColumns + " FROM tap_identity_mappings ORDER BY sheet_row")
	if err != nil {
		cwWriteError(w, err)
		return
	}
	defer rows.Close()
	items := []map[string]any{}
	for rows.Next() {
		m, e := cwScanMapping(rows)
		if e != nil {
			cwWriteError(w, e)
			return
		}
		items = append(items, cwMappingPublic(m))
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"mappings": items, "source": map[string]any{"sheet_token": cwMappingSheetToken, "sheet_id": cwMappingSheetID, "revision": revision, "range": cwMappingRange, "status": sourceStatus, "source_error": sourceError, "source_synced_at": sourceSyncedAt, "cache_age_seconds": cacheAgeSeconds}, "auto_send_enabled": cfg.AutoSendEnabled}})
}

func cwIdentityMappingEnabledHandler(w http.ResponseWriter, r *http.Request) {
	cfg, err := cwLoadConfig()
	actor := requestUsername(r)
	if err != nil || !cwOperator(cfg, actor) {
		cwWriteError(w, cwErr(403, "仅运营可调整人员映射"))
		return
	}
	var in struct {
		Enabled          *bool  `json:"enabled"`
		ConfirmationNote string `json:"confirmation_note"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&in) != nil || in.Enabled == nil || strings.TrimSpace(in.ConfirmationNote) == "" {
		cwWriteError(w, cwErr(400, "必须提供 enabled 和确认说明"))
		return
	}
	db, err := cwDB()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	defer db.Close()
	now := cwNow()
	manualDisabled := 0
	if !*in.Enabled {
		manualDisabled = 1
	}
	result, err := db.Exec("UPDATE tap_identity_mappings SET enabled=?,manual_disabled=?,override_updated_at=?,override_by=?,override_note=? WHERE record_id=?", *in.Enabled, manualDisabled, now, actor, strings.TrimSpace(in.ConfirmationNote), r.PathValue("record_id"))
	if err != nil {
		cwWriteError(w, err)
		return
	}
	n, _ := result.RowsAffected()
	if n != 1 {
		cwWriteError(w, cwErr(404, "映射记录不存在"))
		return
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"record_id": r.PathValue("record_id"), "enabled": *in.Enabled, "manual_disabled": manualDisabled == 1, "updated_at": now}})
}

func cwNotificationPreviewHandler(w http.ResponseWriter, r *http.Request) {
	var in struct {
		RecipientID string `json:"recipient_id"`
		Mode        string `json:"mode"`
	}
	_ = json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&in)
	cfg, err := cwLoadConfig()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	mode := strings.TrimSpace(in.Mode)
	if mode == "" {
		mode = cfg.NotificationMode
	}
	if mode != "test" && mode != "formal" {
		cwWriteError(w, cwErr(400, "mode 必须为 test 或 formal"))
		return
	}
	// Preview is always a read-only operation. In particular, formal preview is
	// available while the service remains in test/disabled mode and while
	// auto_send_enabled is false; those gates apply to execution, not inspection.
	db, err := cwDB()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	defer db.Close()
	a, err := cwRead(db, r.PathValue("id"))
	if err != nil {
		cwWriteError(w, err)
		return
	}
	if !cwCanRead(cfg, a, requestUsername(r)) {
		cwWriteError(w, cwErr(403, "无预览权限"))
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
	defer cancel()
	revision, err := cwSyncIdentityMappings(ctx, db)
	mappingSourceStatus, mappingSourceError := "fresh", ""
	_, mappingSourceSyncedAt, mappingCacheAgeSeconds := cwMappingCacheState(db)
	if err != nil {
		mappingSourceStatus = "stale"
		mappingSourceError = cwSafeAPIMessage(err.Error(), "")
		revision, mappingSourceSyncedAt, mappingCacheAgeSeconds = cwMappingCacheState(db)
		if revision == "" && mode != "test" {
			writeJSON(w, 503, map[string]any{"error": "mapping_refresh_failed", "reason": "权威人员映射刷新失败且无最后有效缓存"})
			return
		}
	}
	resolution, err := cwResolveMapping(db, a.Row.Member.Submitter, a.Row.Member.Region)
	if err != nil {
		if mode != "test" {
			cwWriteError(w, err)
			return
		}
		resolution = cwMappingResolution{Status: "unavailable", Reason: "mapping_lookup_failed"}
	}
	openID, openStatus, email := "", "not_attempted", ""
	botDiagnostic := cwOpenIDDiagnostic{Stage: "not_attempted", Status: openStatus, AppIDFingerprint: cwAppIDFingerprint()}
	if resolution.Mapping != nil {
		email = resolution.Mapping.Email
	}
	// Formal mode remains fail-closed on the real submitter mapping and Bot-domain
	// resolution. Test mode deliberately does not resolve or target that person.
	if mode != "test" && resolution.Status == "matched" {
		openID, openStatus = cwResolveBotOpenID(ctx, email)
		botDiagnostic = cwReadOpenIDDiagnostic(email, openStatus)
		if openStatus != "resolved" {
			resolution.Status, resolution.Reason = "blocked", "open_id_resolution_failed"
		}
	}
	actualStatus, actualType, actualID, actualLabel, actualEmail := "blocked", "", "", "", ""
	replaced := false
	if mode == "test" {
		replaced = true
		for _, target := range cfg.TestRecipients {
			if target.ID == in.RecipientID && target.Type == "open_id" {
				actualStatus, actualType, actualID, actualLabel, actualEmail = "ready_test_allowlist", target.Type, target.ID, target.Label, target.Email
			}
		}
		if actualID == "" {
			actualStatus = "test_recipient_not_allowlisted"
		}
	} else if mode == "formal" && resolution.Status == "matched" && openStatus == "resolved" {
		actualStatus, actualType, actualID = "ready_formal", "open_id", openID
		if resolution.Mapping != nil {
			actualLabel, actualEmail = resolution.Mapping.BusinessName, resolution.Mapping.Email
		}
	}
	confirmationToken := ""
	ready := actualStatus == "ready_test_allowlist" || actualStatus == "ready_formal"
	if ready && cwCanHandle(cfg, a, requestUsername(r)) {
		mapping := cwIdentityMapping{}
		if resolution.Mapping != nil {
			mapping = *resolution.Mapping
		}
		card := cwNotificationCard(a, mode, actualLabel)
		cardJSON, _ := json.Marshal(card)
		stateJSON, _ := json.Marshal(a)
		confirmationToken, err = cwCreateNotificationPreviewSnapshot(db, a, cwNotificationConfirmation{AlertID: a.ID, Actor: requestUsername(r), CaseVersion: a.Version, Mode: mode, Recipient: actualID, RecipientEmail: actualEmail, RecipientName: actualLabel, Mapping: mapping, ResolvedOpenID: openID, Revision: revision, StateHash: cwPreviewHash(string(stateJSON)), TemplateHash: cwPreviewHash(string(cardJSON))})
		if err != nil {
			cwWriteError(w, err)
			return
		}
	}
	mapping := map[string]any{"status": resolution.Status, "reason": resolution.Reason, "matched_alias": resolution.MatchedAlias, "email_masked": cwMaskEmail(email), "sheet_revision": revision}
	if resolution.Mapping != nil {
		for k, v := range cwMappingPublic(*resolution.Mapping) {
			mapping[k] = v
		}
	}
	metricGrain := "account"
	if strings.EqualFold(a.Row.Program, "THT") {
		metricGrain = "advertiser"
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"dry_run": true, "will_send": false, "case_version": a.Version, "preview_token": confirmationToken, "confirmation_token": confirmationToken, "confirmation_expires_in_seconds": 600, "message_count": 0, "auto_send_enabled": cfg.AutoSendEnabled, "notification_mode": mode, "alert_id": a.ID, "original_submitter": a.Row.Member.Submitter, "region": a.Row.Member.Region, "metric_grain": metricGrain, "account_level_template": metricGrain == "account", "presentation": cwPresentation(a), "template_card": cwNotificationCard(a, mode, actualLabel), "deep_link": cwWorkbenchURL(a.ID), "mapping_result": mapping, "mapping_source": map[string]any{"status": mappingSourceStatus, "source_error": mappingSourceError, "revision": revision, "source_synced_at": mappingSourceSyncedAt, "cache_age_seconds": mappingCacheAgeSeconds}, "bot_resolution": map[string]any{"status": openStatus, "open_id_masked": cwMaskID(openID), "diagnostic": botDiagnostic}, "actual_target": map[string]any{"status": actualStatus, "type": actualType, "id_masked": cwMaskID(actualID), "label": actualLabel, "enterprise_email": actualEmail, "test_recipient_replacement": replaced}, "notice": func() string {
		if replaced {
			return "测试模式强制替换为指定白名单目标，不会发给真实提报人；本预览不会发送消息"
		}
		return "正式模式展示实际目标；本预览不会发送消息且自动发送门禁关闭"
	}()}})
}

// Kept for old ownership lookups; it never refreshes or authorizes notification sending.
func cwReadIdentityMapping(db *sql.DB, source string) (cwIdentityMapping, error) {
	rows, err := db.Query("SELECT "+cwMappingColumns+" FROM tap_identity_mappings WHERE lower(trim(business_name))=? LIMIT 1", cwNormalizeIdentity(source))
	if err != nil {
		return cwIdentityMapping{}, err
	}
	defer rows.Close()
	if !rows.Next() {
		return cwIdentityMapping{}, sql.ErrNoRows
	}
	return cwScanMapping(rows)
}

func cwIdentityMappingHandler(w http.ResponseWriter, r *http.Request) {
	cwWriteError(w, cwErr(410, "请使用权威 Sheet 同步与 enabled 管理接口"))
}

func cwParseRevision(v any) string {
	s := asString(v)
	if s != "" {
		return s
	}
	if n, ok := v.(float64); ok {
		return strconv.FormatInt(int64(n), 10)
	}
	return ""
}

type cwOpenIDDiagnostic struct {
	Stage             string `json:"stage"`
	Status            string `json:"status"`
	HTTPStatus        int    `json:"http_status,omitempty"`
	FeishuCode        string `json:"feishu_code,omitempty"`
	FeishuMessage     string `json:"feishu_message,omitempty"`
	AppIDFingerprint  string `json:"app_id_fingerprint,omitempty"`
	ResponseHasUserID bool   `json:"response_has_user_id"`
	ResponseHasOpenID bool   `json:"response_has_open_id"`
	CacheAgeSeconds   int64  `json:"cache_age_seconds,omitempty"`
	Cached            bool   `json:"cached"`
}

type cwOpenIDCacheEntry struct {
	OpenID     string
	Diagnostic cwOpenIDDiagnostic
	At         time.Time
}

var cwOpenIDCache = struct {
	sync.Mutex
	Items map[string]cwOpenIDCacheEntry
}{Items: map[string]cwOpenIDCacheEntry{}}

var cwOpenIDDiagnostics = struct {
	sync.Mutex
	Items map[string]cwOpenIDDiagnostic
}{Items: map[string]cwOpenIDDiagnostic{}}

func cwRememberOpenIDDiagnostic(email string, diagnostic cwOpenIDDiagnostic) {
	cwOpenIDDiagnostics.Lock()
	cwOpenIDDiagnostics.Items[strings.ToLower(strings.TrimSpace(email))] = diagnostic
	cwOpenIDDiagnostics.Unlock()
}

func cwReadOpenIDDiagnostic(email, fallback string) cwOpenIDDiagnostic {
	cwOpenIDDiagnostics.Lock()
	diagnostic, ok := cwOpenIDDiagnostics.Items[strings.ToLower(strings.TrimSpace(email))]
	cwOpenIDDiagnostics.Unlock()
	if ok {
		return diagnostic
	}
	return cwOpenIDDiagnostic{Stage: "batch_get_id", Status: fallback, AppIDFingerprint: cwAppIDFingerprint()}
}

func cwAppIDFingerprint() string {
	credentials, _, err := loadFeishuCredentials()
	if err != nil || credentials.AppID == "" {
		return "unavailable"
	}
	sum := sha256.Sum256([]byte(credentials.AppID))
	return hex.EncodeToString(sum[:6])
}

func cwClassifyOpenIDError(err error, diag *cwOpenIDDiagnostic) string {
	message := cwSafeAPIMessage(err.Error(), "")
	diag.FeishuMessage = message
	for _, field := range strings.FieldsFunc(message, func(r rune) bool { return r == ' ' || r == '=' || r == ':' || r == ',' }) {
		if field == "99991672" {
			diag.FeishuCode = field
			return "scope_missing"
		}
		if number, parseErr := strconv.ParseFloat(field, 64); parseErr == nil && int64(number) == 99991672 {
			diag.FeishuCode = "99991672"
			return "scope_missing"
		}
		if n, parseErr := strconv.Atoi(field); parseErr == nil && n >= 400 && n <= 599 && diag.HTTPStatus == 0 {
			diag.HTTPStatus = n
		}
	}
	if diag.HTTPStatus == http.StatusUnauthorized || diag.HTTPStatus == http.StatusForbidden {
		return "credential_app_mismatch"
	}
	return "response_parse_error"
}

func cwResolveOpenIDDiagnostic(ctx context.Context, email string) (string, cwOpenIDDiagnostic) {
	diag := cwOpenIDDiagnostic{Stage: "validate_email", Status: "email_invalid", AppIDFingerprint: cwAppIDFingerprint()}
	normalized, valid := cwExactEmail(email)
	if !valid {
		return "", diag
	}
	diag.Stage = "access_token"
	token, err := cwAccessToken(ctx)
	if err != nil {
		diag.Status = "credential_app_mismatch"
		diag.FeishuMessage = cwSafeAPIMessage(err.Error(), "")
		return "", diag
	}
	diag.Stage = "batch_get_id"
	out, err := cwHTTP(ctx, http.MethodPost, "/open-apis/contact/v3/users/batch_get_id?user_id_type=open_id", token, map[string]any{"emails": []string{normalized}})
	if err != nil {
		diag.Status = cwClassifyOpenIDError(err, &diag)
		return "", diag
	}
	diag.FeishuCode = strings.TrimSpace(asString(out["code"]))
	diag.FeishuMessage = cwSafeAPIMessage(asString(out["msg"]), token)
	data, dataOK := out["data"].(map[string]any)
	list, listOK := data["user_list"].([]any)
	if !dataOK || !listOK {
		diag.Status = "response_parse_error"
		return "", diag
	}
	if len(list) != 1 {
		diag.Status = "person_not_visible_or_out_of_scope"
		return "", diag
	}
	item, ok := list[0].(map[string]any)
	if !ok {
		diag.Status = "response_parse_error"
		return "", diag
	}
	if returnedEmail := strings.ToLower(strings.TrimSpace(asString(item["email"]))); returnedEmail != "" && returnedEmail != normalized {
		diag.Status = "response_parse_error"
		return "", diag
	}
	if strings.EqualFold(asString(item["status"]), "inactive") || strings.EqualFold(asString(item["active"]), "false") {
		diag.Status = "account_inactive"
		return "", diag
	}
	id := strings.TrimSpace(asString(item["user_id"]))
	diag.ResponseHasUserID = id != ""
	diag.ResponseHasOpenID = strings.HasPrefix(id, "ou_")
	if !diag.ResponseHasOpenID {
		diag.Status = "person_not_visible_or_out_of_scope"
		return "", diag
	}
	diag.Status = "resolved"
	cwOpenIDCache.Lock()
	cwOpenIDCache.Items[normalized] = cwOpenIDCacheEntry{OpenID: id, Diagnostic: diag, At: time.Now()}
	cwOpenIDCache.Unlock()
	return id, diag
}
