#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

PLUGIN_ROOT="$(cd ../.. && pwd)"
PREBUILT_BIN="$(pwd)/bin/server"
export PYTHONPATH="$PLUGIN_ROOT${PYTHONPATH:+:$PYTHONPATH}"
DEV_BIN="$PLUGIN_ROOT/.aime_build/bin/server"

BIN="$PREBUILT_BIN"
if [ -e "$DEV_BIN" ] || [ -L "$DEV_BIN" ]; then
  BIN="$DEV_BIN"
fi
if [ ! -f "$BIN" ] || [ ! -x "$BIN" ]; then
  echo "[start] ERROR: missing or non-executable artifact: $BIN" >&2
  echo "[start] Build source Apps with bash build.sh; reinstall an incomplete release package." >&2
  exit 1
fi

exec "$BIN"
