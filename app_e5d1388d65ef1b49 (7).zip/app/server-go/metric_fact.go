package main

import "strings"

const (
	metricAvailable     = "available"
	metricSourceNull    = "source_null"
	metricFailed        = "failed"
	metricNotConfigured = "not_configured"
	metricNotApplicable = "not_applicable"
	metricQuerying      = "querying"
)

type metricFact struct {
	Value  *float64 `json:"value"`
	Status string   `json:"status"`
	Reason string   `json:"reason,omitempty"`
}

func successfulMetricFact(value *float64) metricFact {
	if value == nil {
		return metricFact{Status: metricSourceNull, Reason: "源指标缺失"}
	}
	return metricFact{Value: value, Status: metricAvailable}
}

func failedMetricFact(reason string) metricFact {
	if strings.TrimSpace(reason) == "" {
		reason = "查询或字段解析失败"
	}
	return metricFact{Status: metricFailed, Reason: reason}
}

func queryingMetricFact(reason string) metricFact {
	if strings.TrimSpace(reason) == "" {
		reason = "查询未结束"
	}
	return metricFact{Status: metricQuerying, Reason: reason}
}

func legacyMetricFact(value *float64, status, reason string) metricFact {
	if value != nil {
		return metricFact{Value: value, Status: metricAvailable}
	}
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "success", metricSourceNull:
		return successfulMetricFact(nil)
	case metricQuerying, "window_incomplete", "pending", "running":
		return queryingMetricFact(reason)
	case metricNotConfigured, "unsupported":
		return metricFact{Status: metricNotConfigured, Reason: reason}
	case metricFailed, "error", "query_failed", "source_error":
		return failedMetricFact(reason)
	default:
		return failedMetricFact("旧批次未记录指标状态")
	}
}
