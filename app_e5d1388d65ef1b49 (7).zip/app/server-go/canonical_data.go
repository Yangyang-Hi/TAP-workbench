package main

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type filterRequest struct {
	StartDate   string `json:"start_date,omitempty"`
	EndDate     string `json:"end_date,omitempty"`
	Region      string `json:"region,omitempty"`
	ClientTier  string `json:"client_tier,omitempty"`
	ProgramType string `json:"program_type,omitempty"`
}

type sourceCapability struct {
	SupportsDate        bool              `json:"supportsDate"`
	SupportsRegion      bool              `json:"supportsRegion"`
	SupportsClientTier  bool              `json:"supportsClientTier"`
	SupportsProgramType bool              `json:"supportsProgramType"`
	SupportsClientLevel bool              `json:"supportsClientLevel"`
	Complete            bool              `json:"complete"`
	PossiblyTruncated   bool              `json:"possiblyTruncated"`
	SupportedDimensions []string          `json:"supportedDimensions"`
	MissingRequired     []string          `json:"missingRequiredFields"`
	Aggregation         map[string]string `json:"aggregation"`
	TimeSemantics       string            `json:"timeSemantics"`
}

type regionMapping struct {
	Raw, Canonical, Quota, Display string
	Active                         bool
}

func parseFilter(r interface{ FormValue(string) string }) filterRequest {
	return filterRequest{StartDate: r.FormValue("start_date"), EndDate: r.FormValue("end_date"), Region: r.FormValue("region"), ClientTier: r.FormValue("client_tier"), ProgramType: strings.ToUpper(r.FormValue("program_type"))}
}

func hasDimension(s sourceConfig, dimension string) bool {
	for _, d := range s.SupportedDimensions {
		if d == dimension {
			return true
		}
	}
	return false
}

func capabilityFor(name string, cfg sourceConfig, snap sourceSnapshot) sourceCapability {
	missing := []string{}
	rows, _ := snap.BusinessPayload["rows"].([]map[string]any)
	for field, spec := range cfg.Fields {
		mapped := strings.TrimSpace(spec.DimMetID) != "" || strings.TrimSpace(spec.SourceName) != ""
		if !mapped {
			for _, row := range rows {
				if value, exists := row[field]; exists && asString(value) != "" {
					mapped = true
					break
				}
			}
		}
		if !spec.Optional && !mapped {
			missing = append(missing, field)
		}
	}
	sort.Strings(missing)
	complete := snap.Complete
	truncated := snap.PossiblyTruncated
	if snap.Source == "" {
		complete = false
	}
	fieldAvailable := func(names ...string) bool {
		for _, field := range names {
			if spec, ok := cfg.Fields[field]; ok && (strings.TrimSpace(spec.DimMetID) != "" || strings.TrimSpace(spec.SourceName) != "") {
				return true
			}
			for _, row := range rows {
				if value, exists := row[field]; exists && asString(value) != "" && asString(value) != "UNKNOWN" {
					return true
				}
			}
		}
		return false
	}
	return sourceCapability{
		SupportsDate:        hasDimension(cfg, "date") && fieldAvailable("p_date", "create_date", "date"),
		SupportsRegion:      hasDimension(cfg, "region") && fieldAvailable("region"),
		SupportsClientTier:  hasDimension(cfg, "client_tier") && fieldAvailable("client_tier"),
		SupportsProgramType: hasDimension(cfg, "program_type") && fieldAvailable("program_type", "type_name", "protection_program_name"),
		SupportsClientLevel: cfg.Kind == "detail" && fieldAvailable("advertiser_id", "account_id"),
		Complete:            complete, PossiblyTruncated: truncated, SupportedDimensions: cfg.SupportedDimensions,
		MissingRequired: missing, Aggregation: cfg.Aggregation, TimeSemantics: cfg.TimeSemantics,
	}
}

func unsupportedFilters(f filterRequest, cap sourceCapability) []string {
	out := []string{}
	if (f.StartDate != "" || f.EndDate != "") && !cap.SupportsDate {
		out = append(out, "date")
	}
	if f.Region != "" && !cap.SupportsRegion {
		out = append(out, "region")
	}
	if f.ClientTier != "" && !cap.SupportsClientTier {
		out = append(out, "client_tier")
	}
	if f.ProgramType != "" && !cap.SupportsProgramType {
		out = append(out, "program_type")
	}
	return out
}

func resolveProgramType(row map[string]any) string {
	typeName := strings.TrimSpace(strings.ToLower(asString(row["type_name"])))
	program := strings.TrimSpace(strings.ToLower(asString(row["protection_program_name"])))
	if strings.Contains(typeName, "strategic trust") {
		return "ST"
	}
	if strings.Contains(typeName, "emerging trust") {
		return "ET"
	}
	if strings.Contains(typeName, "temporary high trust") || strings.Contains(program, "temporary high trust") || tokenContainsTHT(typeName) || tokenContainsTHT(program) {
		return "THT"
	}
	return "UNKNOWN"
}

func tokenContainsTHT(value string) bool {
	for _, token := range strings.FieldsFunc(strings.ToUpper(value), func(r rune) bool { return r < 'A' || r > 'Z' }) {
		if token == "THT" {
			return true
		}
	}
	return false
}

func loadRegionMappings() ([]regionMapping, error) {
	f, err := os.Open(filepath.Join(pluginDir, "config", "region_mapping.csv"))
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil || len(rows) == 0 {
		return nil, err
	}
	out := []regionMapping{}
	for _, row := range rows[1:] {
		if len(row) < 5 {
			continue
		}
		out = append(out, regionMapping{row[0], row[1], row[2], row[3], strings.EqualFold(row[4], "true")})
	}
	return out, nil
}

func canonicalRegion(raw string) (string, bool) {
	mappings, err := loadRegionMappings()
	if err != nil {
		return "Unknown / Unmapped", false
	}
	for _, m := range mappings {
		if m.Active && strings.EqualFold(strings.TrimSpace(raw), strings.TrimSpace(m.Raw)) {
			return m.Canonical, true
		}
	}
	return "Unknown / Unmapped", false
}

func normalizeDetailRow(row map[string]any) map[string]any {
	keys := []string{"date", "ticket_id", "ticket_count", "create_date", "p_date", "final_result", "submitter", "question_user_name", "account_id", "advertiser_id", "client_tier", "tier_v3_name", "region", "account_name", "type_name", "protection_program_name", "program_type", "protection_starttime", "protection_endtime", "effective_active", "expired", "over_14_days", "duration_days", "missing_time", "overview_revenue", "revenue", "p0_nfs", "dynamic_p0_ccr", "p0_ccr_num", "p1_ccr_num", "ccr_den", "p0_ccr", "p1_ccr", "approval_num", "approval_den", "audit_volume", "approval_rate"}
	out := map[string]any{}
	unmapped := []string{}
	for _, key := range keys {
		if value, ok := row[key]; ok && asString(value) != "" {
			out[key] = value
		} else {
			out[key] = nil
		}
	}
	if asString(out["date"]) == "" {
		if value := asString(out["p_date"]); value != "" {
			out["date"] = value
		} else if value := asString(out["create_date"]); value != "" {
			out["date"] = value
		}
	}
	// IDs must remain decimal strings. json.Number is intentionally stringified
	// before snapshots are persisted to avoid IEEE-754 precision loss.
	for _, key := range []string{"account_id", "advertiser_id", "ticket_id"} {
		if out[key] != nil {
			out[key] = asString(out[key])
		}
	}
	programType := strings.ToUpper(asString(row["program_type"]))
	if programType != "ST" && programType != "ET" && programType != "THT" {
		programType = resolveProgramType(row)
	}
	out["program_type"] = programType
	if tier := normalizeArrayScalar(asString(out["client_tier"])); tier != "" {
		labels := map[string]string{"building_trust": "Building Trust", "emerging_trust": "Emerging Trust", "high_trust": "High Trust", "strategic_trust": "Strategic Trust", "standard_trust": "Standard Trust"}
		if label := labels[strings.ToLower(tier)]; label != "" {
			out["client_tier"] = label
		} else {
			out["client_tier"] = tier
		}
	}
	idType := "account_id"
	if out["program_type"] == "THT" {
		idType = "advertiser_id"
	}
	out["client_id_type"] = idType
	out["client_id"] = out[idType]
	if raw := normalizeArrayScalar(asString(row["region"])); raw != "" {
		region, mapped := canonicalRegion(raw)
		out["region"] = region
		if !mapped {
			unmapped = append(unmapped, "region")
		}
	}
	out["unmapped"] = uniqueStrings(unmapped)
	return out
}

func uniqueStrings(in []string) []string {
	seen := map[string]bool{}
	out := []string{}
	for _, v := range in {
		if !seen[v] {
			seen[v] = true
			out = append(out, v)
		}
	}
	return out
}

func dateInRange(value, from, to string) bool {
	d, ok := parseDate(value)
	if !ok {
		return false
	}
	if from != "" {
		f, ok := parseDate(from)
		if !ok || d.Before(f) {
			return false
		}
	}
	if to != "" {
		t, ok := parseDate(to)
		if !ok || d.After(t.Add(24*time.Hour-time.Nanosecond)) {
			return false
		}
	}
	return true
}

func effectiveFilterForRows(f filterRequest, rows []map[string]any, dateKey string) (filterRequest, []string) {
	effective := f
	unsupported := []string{}
	hasValue := func(key string) bool {
		for _, row := range rows {
			if strings.TrimSpace(asString(row[key])) != "" {
				return true
			}
		}
		return false
	}
	if (f.StartDate != "" || f.EndDate != "") && !hasValue(dateKey) {
		effective.StartDate, effective.EndDate = "", ""
		unsupported = append(unsupported, "date")
	}
	if f.Region != "" && !hasValue("region") {
		effective.Region = ""
		unsupported = append(unsupported, "region")
	}
	if f.ClientTier != "" && !hasValue("client_tier") {
		effective.ClientTier = ""
		unsupported = append(unsupported, "client_tier")
	}
	if f.ProgramType != "" && !hasValue("program_type") {
		effective.ProgramType = ""
		unsupported = append(unsupported, "program_type")
	}
	return effective, unsupported
}

func applyFilters(rows []map[string]any, f filterRequest, dateKey string) []map[string]any {
	out := []map[string]any{}
	for _, row := range rows {
		if (f.StartDate != "" || f.EndDate != "") && !dateInRange(asString(row[dateKey]), f.StartDate, f.EndDate) {
			continue
		}
		if f.Region != "" && !strings.EqualFold(asString(row["region"]), f.Region) {
			continue
		}
		if f.ClientTier != "" && !strings.EqualFold(asString(row["client_tier"]), f.ClientTier) {
			continue
		}
		if f.ProgramType != "" && !strings.EqualFold(asString(row["program_type"]), f.ProgramType) {
			continue
		}
		out = append(out, row)
	}
	return out
}

func detailReady(rows []map[string]any, fields ...string) (bool, []string) {
	if len(rows) == 0 {
		return false, fields
	}
	missing := []string{}
	for _, field := range fields {
		found := false
		for _, row := range rows {
			if asString(row[field]) != "" && asString(row[field]) != "UNKNOWN" && asString(row[field]) != "Unknown / Unmapped" {
				found = true
				break
			}
		}
		if !found {
			missing = append(missing, field)
		}
	}
	return len(missing) == 0, missing
}

func calculateQuota(configRows, detailRows []map[string]any, partial bool) []map[string]any {
	out := []map[string]any{}
	// Normalize imported CSV values again at the aggregation boundary. This keeps
	// quota correct for snapshots created before canonical normalization existed.
	for _, row := range detailRows {
		if raw := normalizeArrayScalar(asString(row["region"])); raw != "" {
			if canonical, ok := canonicalRegion(raw); ok {
				row["region"] = canonical
			}
		}
		program := strings.ToUpper(strings.TrimSpace(asString(row["program_type"])))
		if program != "ST" && program != "ET" && program != "THT" {
			program = resolveProgramType(row)
		}
		row["program_type"] = program
	}
	ready, missing := detailReady(detailRows, "account_id", "create_date", "region", "program_type", "final_result")
	for _, q := range configRows {
		item := map[string]any{}
		for k, v := range q {
			item[k] = v
		}
		item["used_quota"], item["remaining_quota"], item["usage"] = nil, nil, nil
		item["provisional"] = true
		item["period_status"] = "pending_confirmation"
		item["status"] = "not_ready"
		item["reason"] = "Quota applicability period pending confirmation"
		item["missing_required_fields"] = missing
		if strings.EqualFold(asString(q["program_type"]), "THT") {
			item["total_quota"] = nil
			item["status"] = "not_applicable"
			item["reason"] = "THT Total Quota is not provided"
		} else if partial {
			item["status"] = "partial"
			item["display_mode"] = "observed_partial"
			item["value_semantics"] = "unavailable"
			item["reason"] = "Partial/truncated data is excluded from Quota Used"
			item["possiblyTruncated"] = true
			if ready {
				used := distinctCount(detailRows, "account_id", func(row map[string]any) bool {
					return isApproved(row) && dateInRange(asString(row["create_date"]), asString(q["effective_from"]), asString(q["effective_to"])) && strings.EqualFold(asString(row["region"]), asString(q["region"])) && strings.EqualFold(asString(row["program_type"]), asString(q["program_type"]))
				})
				if used > 0 {
					item["used_quota"] = used
					item["value_semantics"] = "observed_lower_bound"
					item["reason"] = "Observed Used covers verified rows only"
				}
			}
		} else if ready {
			used := distinctCount(detailRows, "account_id", func(row map[string]any) bool {
				return isApproved(row) && dateInRange(asString(row["create_date"]), asString(q["effective_from"]), asString(q["effective_to"])) && strings.EqualFold(asString(row["region"]), asString(q["region"])) && strings.EqualFold(asString(row["program_type"]), asString(q["program_type"]))
			})
			total, _ := number(q["total_quota"])
			item["used_quota"] = used
			remaining := total - float64(used)
			if remaining < 0 {
				remaining = 0
			}
			item["remaining_quota"] = remaining
			if total > 0 {
				item["usage"] = float64(used) / total
			}
			item["status"] = "ready"
			item["reason"] = ""
			item["metadata"] = map[string]any{"aggregation": "count_distinct_account_id", "approved_only": true, "matched_accounts": used}
		}
		out = append(out, item)
	}
	return out
}

func buildDataArchitecture(st snapshotState, cfg dataSourceConfig) map[string]any {
	sources := []map[string]any{}
	names := make([]string, 0, len(cfg.Sources))
	for name := range cfg.Sources {
		names = append(names, name)
	}
	sort.Strings(names)
	for _, name := range names {
		s := cfg.Sources[name]
		snap := st.Business[name]
		status := "not_ready"
		if snap.Source != "" {
			status = snap.Status
		}
		sources = append(sources, map[string]any{"source": name, "label": s.Label, "kind": s.Kind, "grain": s.Grain, "fields": sortedFieldNames(s.Fields), "capability": capabilityFor(name, s, snap), "rid": s.RID, "enabled": s.Enabled, "status": status, "last_sync": st.UpdatedAt[name], "rows": snap.RowCount, "used_by": s.Consumers})
	}
	return map[string]any{"pipeline": []string{"Aeolus Saved Report / Titan VQS query", "canonical field mapping and snapshot", "Go backend capability-aware filter and aggregation", "frontend consumes values plus status metadata"}, "sources": sources, "lineage": []map[string]any{{"metric": "Overview Ticket Volume", "source": "submission", "field": "ticket_count", "aggregation": "sum_pre_aggregated_count", "time_semantics": "create_date"}, {"metric": "Quota Used", "source": "submission_detail", "field": "ticket_id", "aggregation": "distinct_count", "conditions": "effective date + canonical_region + program_type"}, {"metric": "Approval Rate", "source": "approval", "aggregation": "pre_aggregated_latest; weighted only when numerator and denominator exist"}, {"metric": "P0 CCR / NFS", "source": "p0_risk", "aggregation": "source_defined", "time_semantics": "latest_snapshot"}}, "join_backbone": map[string]any{"keys": []string{"advertiser_id", "account_id", "date"}, "relationship": "1 advertiser_id -> N account_id", "client_count": "not_ready when advertiser_id is unmapped"}}
}

func sortedFieldNames(fields map[string]fieldConfig) []string {
	out := make([]string, 0, len(fields))
	for k := range fields {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func fetchAllRows(rows []map[string]any, snap sourceSnapshot) ([]map[string]any, sourceCapability) {
	cap := sourceCapability{Complete: snap.Complete, PossiblyTruncated: snap.PossiblyTruncated}
	if snap.Source == "" || snap.RowCount >= savedReportHardLimit {
		cap.Complete = false
		cap.PossiblyTruncated = snap.RowCount >= savedReportHardLimit
	}
	return rows, cap
}

func validateProgramType(value string) error {
	value = strings.ToUpper(value)
	if value != "" && value != "THT" && value != "ST" && value != "ET" {
		return fmt.Errorf("program_type must be THT, ST, or ET")
	}
	return nil
}

func enrichSubmissionDimensions(rows, accounts []map[string]any) {
	byAdvertiser := map[string]map[string]any{}
	for _, account := range accounts {
		id := asString(account["advertiser_id"])
		if id == "" {
			continue
		}
		byAdvertiser[id] = account
	}
	for _, row := range rows {
		account := byAdvertiser[asString(row["advertiser_id"])]
		if account == nil {
			continue
		}
		for _, key := range []string{"region", "client_tier"} {
			if asString(row[key]) == "" || asString(row[key]) == "Unknown / Unmapped" {
				row[key] = account[key]
			}
		}
		if asString(row["account_id"]) == "" {
			row["account_id"] = account["account_id"]
		}
	}
}

func normalizeArrayScalar(value string) string {
	value = strings.TrimSpace(value)
	if strings.HasPrefix(value, "[") {
		var values []string
		if json.Unmarshal([]byte(value), &values) == nil && len(values) > 0 {
			return strings.TrimSpace(values[0])
		}
	}
	return value
}
