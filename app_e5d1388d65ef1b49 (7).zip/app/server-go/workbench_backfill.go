package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

const (
	wbBackfillTable           = "tap_enrich_backfills"
	wbBackfillStartedAtField  = "started_at"
	wbBackfillModifiedAtField = "modified_at"
)

type wbBackfillRequest struct {
	RequestID string `json:"request_id"`
	DryRun    bool   `json:"dry_run"`
	Program   string `json:"program"`
	BatchID   string `json:"batch_id"`
	CaseID    string `json:"case_id"`
}

type wbBackfillProgress struct {
	Total   int `json:"total"`
	Done    int `json:"done"`
	Updated int `json:"updated"`
	Skipped int `json:"skipped"`
	Failed  int `json:"failed"`
}

type wbBackfillProgramResult struct {
	Status  string `json:"status"`
	Updated int    `json:"updated"`
	Skipped int    `json:"skipped"`
	Failed  int    `json:"failed"`
	Reason  string `json:"reason,omitempty"`
}

type wbBackfillTask struct {
	ID             string                             `json:"id"`
	RequestID      string                             `json:"request_id"`
	Fingerprint    string                             `json:"fingerprint"`
	DryRun         bool                               `json:"dry_run"`
	Program        string                             `json:"program,omitempty"`
	BatchID        string                             `json:"batch_id,omitempty"`
	CaseID         string                             `json:"case_id,omitempty"`
	Status         string                             `json:"status"`
	Checkpoint     int                                `json:"checkpoint"`
	LeaseOwner     string                             `json:"lease_owner,omitempty"`
	LeaseUntil     string                             `json:"lease_until,omitempty"`
	Progress       wbBackfillProgress                 `json:"progress"`
	ProgramResults map[string]wbBackfillProgramResult `json:"program_results"`
	Errors         []string                           `json:"errors"`
	CreatedBy      string                             `json:"created_by"`
	CreatedAt      string                             `json:"created_at"`
	UpdatedAt      string                             `json:"updated_at"`
}

type wbBackfillRepository interface {
	List(context.Context) ([]wbBackfillTask, error)
	Get(context.Context, string) (wbBackfillTask, error)
	Create(context.Context, wbBackfillTask) error
	Save(context.Context, wbBackfillTask) error
	ByFingerprint(context.Context, string) (wbBackfillTask, bool, error)
}

type wbMemoryBackfillRepository struct {
	mu    sync.Mutex
	items map[string]wbBackfillTask
}

func newWBMemoryBackfillRepository() *wbMemoryBackfillRepository {
	return &wbMemoryBackfillRepository{items: map[string]wbBackfillTask{}}
}
func (r *wbMemoryBackfillRepository) List(context.Context) ([]wbBackfillTask, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]wbBackfillTask, 0, len(r.items))
	for _, item := range r.items {
		out = append(out, item)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].CreatedAt > out[j].CreatedAt })
	return out, nil
}
func (r *wbMemoryBackfillRepository) Get(_ context.Context, id string) (wbBackfillTask, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	item, ok := r.items[id]
	if !ok {
		return item, errors.New("backfill_not_found")
	}
	return item, nil
}
func (r *wbMemoryBackfillRepository) Create(_ context.Context, item wbBackfillTask) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, ok := r.items[item.ID]; ok {
		return errors.New("backfill_exists")
	}
	r.items[item.ID] = item
	return nil
}
func (r *wbMemoryBackfillRepository) Save(_ context.Context, item wbBackfillTask) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.items[item.ID] = item
	return nil
}
func (r *wbMemoryBackfillRepository) ByFingerprint(_ context.Context, fp string) (wbBackfillTask, bool, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, item := range r.items {
		if item.Fingerprint == fp {
			return item, true, nil
		}
	}
	return wbBackfillTask{}, false, nil
}

type wbCloudBackfillRepository struct{ db *cloudStore }

func (r wbCloudBackfillRepository) query(ctx context.Context, body map[string]any) ([]map[string]any, error) {
	resp, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+wbBackfillTable+"/query", body)
	if err != nil {
		return nil, err
	}
	data, _ := resp["data"].(map[string]any)
	raw, _ := data["records"].([]any)
	out := make([]map[string]any, 0, len(raw))
	for _, value := range raw {
		if row, ok := toMap(value); ok {
			out = append(out, row)
		}
	}
	return out, nil
}
func wbBackfillFromCloud(row map[string]any) (wbBackfillTask, error) {
	var item wbBackfillTask
	raw, err := json.Marshal(row["body"])
	if err == nil {
		err = json.Unmarshal(raw, &item)
	}
	return item, err
}
func (r wbCloudBackfillRepository) List(ctx context.Context) ([]wbBackfillTask, error) {
	rows, err := r.query(ctx, map[string]any{"filters": []any{}, "limit": 100, "offset": 0, "sort": []any{map[string]any{"field": wbBackfillModifiedAtField, "direction": "desc"}}})
	if err != nil {
		return nil, err
	}
	out := []wbBackfillTask{}
	for _, row := range rows {
		item, e := wbBackfillFromCloud(row)
		if e == nil {
			out = append(out, item)
		}
	}
	return out, nil
}
func (r wbCloudBackfillRepository) Get(ctx context.Context, id string) (wbBackfillTask, error) {
	rows, err := r.query(ctx, map[string]any{"filters": []any{map[string]any{"field": "task_id", "operator": "eq", "value": id}}, "limit": 1})
	if err != nil {
		return wbBackfillTask{}, err
	}
	if len(rows) == 0 {
		return wbBackfillTask{}, errors.New("backfill_not_found")
	}
	return wbBackfillFromCloud(rows[0])
}
func wbBackfillCloudData(t wbBackfillTask) map[string]any {
	return map[string]any{"task_id": t.ID, "request_id": t.RequestID, "fingerprint": t.Fingerprint, "status": t.Status, "lease_owner": t.LeaseOwner, "lease_until": t.LeaseUntil, "checkpoint": t.Checkpoint, wbBackfillStartedAtField: t.CreatedAt, wbBackfillModifiedAtField: t.UpdatedAt, "body": t}
}
func (r wbCloudBackfillRepository) Create(ctx context.Context, t wbBackfillTask) error {
	_, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+wbBackfillTable+"/records", wbBackfillCloudData(t))
	return err
}
func (r wbCloudBackfillRepository) Save(ctx context.Context, t wbBackfillTask) error {
	body := map[string]any{"filter": map[string]any{"logic": "and", "conditions": []any{map[string]any{"field": "task_id", "operator": "eq", "value": t.ID}}}, "data": wbBackfillCloudData(t), "limit": 1}
	_, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+wbBackfillTable+"/records/update", body)
	return err
}
func (r wbCloudBackfillRepository) ByFingerprint(ctx context.Context, fp string) (wbBackfillTask, bool, error) {
	rows, err := r.query(ctx, map[string]any{"filters": []any{map[string]any{"field": "fingerprint", "operator": "eq", "value": fp}}, "limit": 1})
	if err != nil {
		return wbBackfillTask{}, false, err
	}
	if len(rows) == 0 {
		return wbBackfillTask{}, false, nil
	}
	item, err := wbBackfillFromCloud(rows[0])
	return item, err == nil, err
}

var wbBackfillRepoProvider = func() (wbBackfillRepository, error) {
	db, err := newCloudStore()
	if err != nil {
		return nil, err
	}
	return wbCloudBackfillRepository{db: db}, nil
}

func wbBackfillFingerprint(req wbBackfillRequest) string {
	payload, _ := json.Marshal([]any{strings.ToUpper(strings.TrimSpace(req.Program)), strings.TrimSpace(req.BatchID), strings.TrimSpace(req.CaseID), req.DryRun})
	sum := sha256.Sum256(payload)
	return hex.EncodeToString(sum[:])
}
func wbValidateBackfill(req *wbBackfillRequest) error {
	req.Program = strings.ToUpper(strings.TrimSpace(req.Program))
	if req.RequestID == "" {
		return errors.New("request_id_required")
	}
	if req.Program != "" && req.Program != "ET" && req.Program != "THT" && req.Program != "ST" {
		return errors.New("program_must_be_ET_THT_or_ST")
	}
	return nil
}
func wbWriteBackfillError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, map[string]any{"error": message})
}

func wbDecodeBackfillJSON(r *http.Request, value any) error {
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	return decoder.Decode(value)
}

func wbRequireOperator(w http.ResponseWriter, r *http.Request) bool {
	cfg, err := cwLoadConfig()
	if err != nil || !cwOperator(cfg, requestUsername(r)) {
		wbWriteBackfillError(w, 403, "operator_required")
		return false
	}
	return true
}
func wbBackfillID(r *http.Request) string {
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	for i, p := range parts {
		if p == "backfills" && i+1 < len(parts) {
			return parts[i+1]
		}
	}
	return ""
}

func wbBackfillTargets(req wbBackfillRequest) ([]string, error) {
	keys := []string{}
	state, err := wbReadDisk()
	if err != nil {
		return nil, err
	}
	selectedJobs := map[string]bool{}
	if req.BatchID != "" {
		for id, job := range state.Jobs {
			if job.BatchID == req.BatchID || job.ID == req.BatchID {
				selectedJobs[id] = true
			}
		}
	} else {
		latestByProgram := map[string]wbJob{}
		for _, job := range state.Jobs {
			program := strings.ToUpper(job.Request.Program)
			if req.Program != "" && program != req.Program {
				continue
			}
			previous, ok := latestByProgram[program]
			if !ok || job.AsOf+job.StartedAt > previous.AsOf+previous.StartedAt {
				latestByProgram[program] = job
			}
		}
		for _, job := range latestByProgram {
			selectedJobs[job.ID] = true
		}
	}
	for id, job := range state.Jobs {
		if !selectedJobs[id] {
			continue
		}
		for i, row := range job.Rows {
			if req.Program != "" && row.Program != req.Program {
				continue
			}
			if wbRowNeedsEnrichment(row) {
				keys = append(keys, fmt.Sprintf("job:%s:%d", id, i))
			}
		}
	}
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		return nil, err
	}
	cases, err := repo.listCases(context.Background())
	if err != nil {
		return nil, err
	}
	for _, item := range cases {
		if req.BatchID != "" && !selectedJobs[item.ScanID] {
			continue
		}
		if req.CaseID != "" && item.ID != req.CaseID {
			continue
		}
		if req.Program != "" && item.Row.Program != req.Program {
			continue
		}
		if wbRowNeedsEnrichment(item.Row) {
			keys = append(keys, "case:"+item.ID)
		}
	}
	sort.Strings(keys)
	return keys, nil
}
func wbRowNeedsEnrichment(row wbRow) bool {
	if row.Comparison.Status == "" || row.Comparison.Status == "unavailable" || len(row.AdvertiserTop10) == 0 {
		return true
	}
	for _, adv := range row.Advertisers {
		if adv.ComparisonStatus == "" || len(adv.ReportedReasons) == 0 {
			return true
		}
		for _, reason := range adv.ReportedReasons {
			if reason.SourceStatus == "" {
				return true
			}
		}
	}
	return false
}

func wbMergeEnrichment(dst *wbRow, src wbRow) bool {
	changed := false
	if dst.Comparison.Status == "" || dst.Comparison.Status == "unavailable" {
		dst.Comparison = src.Comparison
		changed = true
	}
	if len(dst.Advertisers) == 0 && len(src.Advertisers) > 0 {
		dst.Advertisers = src.Advertisers
		changed = true
	}
	if len(dst.AdvertiserTop10) == 0 && len(src.AdvertiserTop10) > 0 {
		dst.AdvertiserTop10 = src.AdvertiserTop10
		changed = true
	}
	for i := range dst.AdvertiserTop10 {
		for reasonIndex := range dst.AdvertiserTop10[i].ReportedReasons {
			reason := &dst.AdvertiserTop10[i].ReportedReasons[reasonIndex]
			if reason.SourceStatus == "" {
				reason.SourceStatus = "legacy_unverified"
				reason.SourceReason = "legacy reason source is outside the 2026-10-26 authoritative source list"
				reason.Rank = nil
				reason.RankingAvailable = false
				changed = true
			}
		}
	}
	for i := range dst.Advertisers {
		for reasonIndex := range dst.Advertisers[i].ReportedReasons {
			reason := &dst.Advertisers[i].ReportedReasons[reasonIndex]
			if reason.SourceStatus == "" {
				reason.SourceStatus = "legacy_unverified"
				reason.SourceReason = "legacy reason source is outside the 2026-10-26 authoritative source list"
				reason.Rank = nil
				reason.RankingAvailable = false
				changed = true
			}
		}
		for _, candidate := range src.Advertisers {
			if dst.Advertisers[i].AccountID != candidate.AccountID || dst.Advertisers[i].AdvertiserID != candidate.AdvertiserID {
				continue
			}
			if dst.Advertisers[i].ComparisonStatus == "" || dst.Advertisers[i].ComparisonStatus == "unavailable" {
				currentCCR, currentNFS, currentRevenue := dst.Advertisers[i].CCR, dst.Advertisers[i].NFS, dst.Advertisers[i].Revenue
				dst.Advertisers[i] = candidate
				if currentCCR != nil {
					dst.Advertisers[i].CCR = currentCCR
				}
				if currentNFS != nil {
					dst.Advertisers[i].NFS = currentNFS
				}
				if currentRevenue != nil {
					dst.Advertisers[i].Revenue = currentRevenue
				}
				changed = true
			}
			if len(dst.Advertisers[i].ReportedReasons) == 0 {
				dst.Advertisers[i].ReportedReasons = candidate.ReportedReasons
				changed = true
			}
		}
	}
	return changed
}

func wbRunBackfill(repo wbBackfillRepository, id string, request *http.Request) {
	ctx := context.Background()
	task, err := repo.Get(ctx, id)
	if err != nil || task.Status != "queued" {
		return
	}
	task.Status = "running"
	task.LeaseOwner = appInstanceID + ":" + uuid.NewString()
	task.LeaseUntil = time.Now().Add(2 * time.Minute).Format(time.RFC3339)
	task.UpdatedAt = time.Now().Format(time.RFC3339)
	if err = repo.Save(ctx, task); err != nil {
		return
	}
	targets, err := wbBackfillTargets(wbBackfillRequest{Program: task.Program, BatchID: task.BatchID, CaseID: task.CaseID})
	if err != nil {
		task.Status = "failed"
		task.Errors = append(task.Errors, sanitizeLogText(err.Error()))
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		_ = repo.Save(ctx, task)
		return
	}
	task.Progress.Total = len(targets)
	if task.DryRun {
		task.Status = "preview_ready"
		task.LeaseUntil = ""
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		_ = repo.Save(ctx, task)
		return
	}
	state, _ := wbReadDisk()
	caseRepo, _ := cwCaseworkRepositoryProvider()
	for index := task.Checkpoint; index < len(targets); index++ {
		key := targets[index]
		program := "unknown"
		updated := false
		var runErr error
		if strings.HasPrefix(key, "job:") {
			parts := strings.Split(key, ":")
			job := state.Jobs[parts[1]]
			var rowIndex int
			_, runErr = fmt.Sscanf(parts[2], "%d", &rowIndex)
			if runErr == nil && rowIndex < len(job.Rows) {
				program = job.Rows[rowIndex].Program
				enriched := wbApplyRealComparisons(ctx, request, []wbRow{job.Rows[rowIndex]}, time.Now())[0]
				updated = wbMergeEnrichment(&job.Rows[rowIndex], enriched)
				if updated {
					state.Jobs[job.ID] = job
					runErr = wbWriteDisk(state)
				}
			}
		}
		if strings.HasPrefix(key, "case:") {
			caseID := strings.TrimPrefix(key, "case:")
			var item cwCase
			item, runErr = caseRepo.caseByID(ctx, caseID)
			if runErr == nil {
				program = item.Row.Program
				enriched := wbApplyRealComparisons(ctx, request, []wbRow{item.Row}, time.Now())[0]
				updated = wbMergeEnrichment(&item.Row, enriched)
				if updated {
					previous := item.Version
					item.Version++
					item.UpdatedAt = time.Now().Format(time.RFC3339)
					runErr = caseRepo.saveCaseCAS(ctx, item, previous)
				}
			}
		}
		result := task.ProgramResults[program]
		if runErr != nil {
			task.Progress.Failed++
			result.Failed++
			result.Status = "partial"
			task.Errors = append(task.Errors, key+":"+sanitizeLogText(runErr.Error()))
		} else if updated {
			task.Progress.Updated++
			result.Updated++
			result.Status = "success"
		} else {
			task.Progress.Skipped++
			result.Skipped++
			result.Status = "skipped"
		}
		task.Progress.Done++
		task.Checkpoint = index + 1
		task.ProgramResults[program] = result
		task.LeaseUntil = time.Now().Add(2 * time.Minute).Format(time.RFC3339)
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		if err = repo.Save(ctx, task); err != nil {
			return
		}
	}
	task.Status = "completed"
	if task.Progress.Failed > 0 {
		task.Status = "completed_with_errors"
	}
	task.LeaseUntil = ""
	task.UpdatedAt = time.Now().Format(time.RFC3339)
	_ = repo.Save(ctx, task)
}

func wbMarkInterruptedBackfills() error {
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		return err
	}
	tasks, err := repo.List(context.Background())
	if err != nil {
		return err
	}
	for _, task := range tasks {
		if task.Status != "queued" && task.Status != "running" {
			continue
		}
		task.Status = "failed"
		task.LeaseOwner = ""
		task.LeaseUntil = ""
		task.Errors = append(task.Errors, "service_restarted_retry_from_checkpoint_required")
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		if err := repo.Save(context.Background(), task); err != nil {
			return err
		}
	}
	return nil
}

func wbBackfillsListHandler(w http.ResponseWriter, r *http.Request) {
	if !wbRequireOperator(w, r) {
		return
	}
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		wbWriteBackfillError(w, 503, err.Error())
		return
	}
	tasks, err := repo.List(r.Context())
	if err != nil {
		wbWriteBackfillError(w, 500, err.Error())
		return
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"tasks": tasks}})
}
func wbBackfillsCreateHandler(w http.ResponseWriter, r *http.Request) {
	if !wbRequireOperator(w, r) {
		return
	}
	var req wbBackfillRequest
	if err := wbDecodeBackfillJSON(r, &req); err != nil {
		wbWriteBackfillError(w, 400, "invalid_json")
		return
	}
	if err := wbValidateBackfill(&req); err != nil {
		wbWriteBackfillError(w, 400, err.Error())
		return
	}
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		wbWriteBackfillError(w, 503, err.Error())
		return
	}
	fp := wbBackfillFingerprint(req)
	if old, ok, e := repo.ByFingerprint(r.Context(), fp); e == nil && ok {
		writeJSON(w, 200, map[string]any{"data": old})
		return
	}
	now := time.Now().Format(time.RFC3339)
	task := wbBackfillTask{ID: "bf-" + uuid.NewString(), RequestID: req.RequestID, Fingerprint: fp, DryRun: req.DryRun, Program: req.Program, BatchID: req.BatchID, CaseID: req.CaseID, Status: "queued", ProgramResults: map[string]wbBackfillProgramResult{}, Errors: []string{}, CreatedBy: requestUsername(r), CreatedAt: now, UpdatedAt: now}
	if err = repo.Create(r.Context(), task); err != nil {
		wbWriteBackfillError(w, 500, err.Error())
		return
	}
	clone := r.Clone(context.Background())
	go wbRunBackfill(repo, task.ID, clone)
	writeJSON(w, http.StatusAccepted, map[string]any{"data": task})
}
func wbBackfillsGetHandler(w http.ResponseWriter, r *http.Request) {
	if !wbRequireOperator(w, r) {
		return
	}
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		wbWriteBackfillError(w, 503, err.Error())
		return
	}
	task, err := repo.Get(r.Context(), wbBackfillID(r))
	if err != nil {
		wbWriteBackfillError(w, 404, "backfill_not_found")
		return
	}
	writeJSON(w, 200, map[string]any{"data": task})
}
func wbBackfillsRetryHandler(w http.ResponseWriter, r *http.Request) {
	if !wbRequireOperator(w, r) {
		return
	}
	var body struct {
		RequestID string `json:"request_id"`
	}
	if wbDecodeBackfillJSON(r, &body) != nil || strings.TrimSpace(body.RequestID) == "" {
		wbWriteBackfillError(w, 400, "request_id_required")
		return
	}
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		wbWriteBackfillError(w, 503, err.Error())
		return
	}
	task, err := repo.Get(r.Context(), wbBackfillID(r))
	if err != nil {
		wbWriteBackfillError(w, 404, "backfill_not_found")
		return
	}
	if task.Status != "failed" && task.Status != "completed_with_errors" {
		wbWriteBackfillError(w, 409, "backfill_not_retryable")
		return
	}
	task.RequestID = body.RequestID
	task.Status = "queued"
	task.LeaseOwner = ""
	task.LeaseUntil = ""
	task.UpdatedAt = time.Now().Format(time.RFC3339)
	if err = repo.Save(r.Context(), task); err != nil {
		wbWriteBackfillError(w, 500, err.Error())
		return
	}
	clone := r.Clone(context.Background())
	go wbRunBackfill(repo, task.ID, clone)
	writeJSON(w, http.StatusAccepted, map[string]any{"data": task})
}
