/** Reading-only helper. No business requests, route changes, or form actions. */
export function installReadingAssist() {
  if (typeof window === "undefined" || document.getElementById("tap-back-top")) return;
  const button = document.createElement("button");
  button.id = "tap-back-top";
  button.type = "button";
  button.className = "tap-back-top";
  button.textContent = "↑";
  button.title = "返回顶部";
  button.setAttribute("aria-label", "返回页面顶部");
  button.hidden = true;
  const update = () => { button.hidden = window.scrollY < 700 || !document.querySelector(".ops-app, .cw-task-page"); };
  button.addEventListener("click", () => window.scrollTo({top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth"}));
  window.addEventListener("scroll", update, {passive: true});
  window.addEventListener("popstate", update);
  document.body.append(button);
  update();
}
if (typeof document !== "undefined") {
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", installReadingAssist, {once: true});
  else installReadingAssist();
}
