import ReactDOM from 'react-dom/client';
import { bootMonitor } from '@aime-plugin/browser-sdk/dynamic-ui';
import App from './App';
import { prefetchJwt } from './auth';
import './aime-element-picker';
import { initPageControl } from './page-control-runtime';
import './components/aime-message';
import './styles/global.css';
import './styles/tailwind.css';
import './ui/reading-assist';

// 最早启动应用加载监控（Slardar）：先于 React 挂载，让白屏检测覆盖 bundle 加载慢 /
// React 未挂载等最严重白屏。仅 Canvas App 生效，localhost 不采；采集口径固化在 SDK 内。
// 这是监控的唯一启动入口；不需要监控时删除本调用即可。
bootMonitor({
  appId: __APP_ID__,
  appVersion: __APP_VERSION__,
});

// 启动即预热鉴权链路，使鉴权 chunk 的下载与 React 启动并行。
prefetchJwt();

// 页面运行在 Aime Canvas iframe 中时，建立 page-control WebSocket 长链。
initPageControl();

const rootEl = document.getElementById('root');
if (rootEl) {
  const root = ReactDOM.createRoot(rootEl);
  root.render(<App />);
}
