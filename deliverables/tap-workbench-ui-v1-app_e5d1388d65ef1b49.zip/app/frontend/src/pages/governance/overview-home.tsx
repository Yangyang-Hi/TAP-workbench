import { Alert, Progress, Radio, Spin, Tag } from "@arco-design/web-react";
import { BarChart3, Database, Gauge, ShieldAlert, TrendingUp } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { overviewAccountsList, overviewGovernanceList, overviewMetricsByMetricGet, overviewQuotaList, unwrap } from "../../api/client.gen";
import type { ApiEnvelope } from "../../api/client.gen";
import type { ReadModel } from "./read-model";
import { Overview } from "./workbench-pages";
import { useSharedFilters } from "./shared-filters";
import "./overview-home.css";

type LoadState<T> = { loading: boolean; data?: T; error?: string };
type AccountData = { status: string; reason?: string; data_as_of?: string; region: string; tier_membership_total?: number | null; rows: { tier: string; account_count: number | null; account_share: number | null }[] };
type MetricData = { module: string; status: string; reason?: string; rows: Record<string, unknown>[]; summary: Record<string, number | null>; source: Record<string, unknown>; window: { start_date: string; end_date: string; region: string } };
type QuotaValue = { usage_count: number | null; quota: number | null; ratio: number | null; quarter_snapshot_count?: number | null; quarter_snapshot_status?: string; numerator_definition: string };
type QuotaPeriod = { quarter: string; status: string; reason?: string; usage_window: { start_date: string; end_date: string }; quota_period: { start_date: string; end_date: string }; numerator_definition: string; et?: QuotaValue; st?: QuotaValue; st_snapshot_at?: string };
type QuotaData = { status: string; quarters: QuotaPeriod[] };
type BatchWindow = { batch_id: string; program: string; start_date: string; end_date: string; coverage: string; evaluated_subjects: number; risk_subjects: number };
type GovernanceData = { status: string; reason?: string; alert_events: number; evaluated_subjects: number; risk_subjects: number; risk_share: number | null; risk_share_scope: string; top20_subjects: number; by_level: Record<string, number>; states: Record<string, number>; coverage: Record<string, string>; coverage_status: string; coverage_note: string; batch_windows: BatchWindow[] };

const numberText = (value: unknown, digits = 0) => typeof value === "number" && Number.isFinite(value) ? value.toLocaleString("zh-CN", { maximumFractionDigits: digits }) : "—";
const percentText = (value: unknown) => typeof value === "number" && Number.isFinite(value) ? `${numberText(value, 1)}%` : "—";
const ratioText = (value: unknown) => typeof value === "number" && Number.isFinite(value) ? percentText(value * 100) : "—";
const TIER_COLORS = ["#39ba88", "#548ff1", "#e3a450", "#9c7be9"];
function quarterToDate() { const now = new Date(); const end = now.toLocaleDateString("en-CA", { timeZone: "Asia/Shanghai" }); const month = Math.floor((Number(end.slice(5, 7)) - 1) / 3) * 3 + 1; return { start_date: `${end.slice(0, 4)}-${String(month).padStart(2, "0")}-01`, end_date: end, region: "Global", tiers: ["ST", "HT", "BT", "ET"] }; }
function TierDonut({ rows, valueKey, shareKey }: { rows: Record<string, unknown>[]; valueKey: string; shareKey: string }) { let cursor = 0; const stops = rows.map((row, index) => { const share = Math.max(0, Number(row[shareKey]) || 0); const start = cursor; cursor += share; return `${TIER_COLORS[index % TIER_COLORS.length]} ${start}% ${cursor}%`; }); const drawable = rows.length === 4 && cursor > 99.5 && cursor < 100.5; return <div className={`ovh-donut ${drawable ? "" : "is-empty"}`} style={drawable ? { background: `conic-gradient(${stops.join(",")})` } : undefined} role="img" aria-label={drawable ? `四 Tier 实际占比环图，总计 ${cursor.toFixed(1)}%` : "占比数据不完整，未绘制环图"}><span>{drawable ? numberText(rows.reduce((sum, row) => sum + (Number(row[valueKey]) || 0), 0)) : "N/A"}<small>四 Tier</small></span></div>; }
const sourceStatus = (data: { status: string; reason?: string }) => data.status === "available" ? (data.reason ? <Alert type="info" content={data.reason} /> : null) : <Alert type={data.status === "no_data" ? "info" : "warning"} content={data.reason || `来源状态：${data.status}`} />;
function StateBlock<T>({ state, children }: { state: LoadState<T>; children: (data: T) => React.ReactNode }) { if (state.loading) return <div className="ovh-state"><Spin /> 正在读取只读聚合…</div>; if (state.error) return <Alert type="error" content={`本模块读取失败：${state.error}`} />; if (!state.data) return <div className="ovh-state">未返回数据</div>; return <>{children(state.data)}</>; }
function Section({ icon, title, note, children }: { icon: React.ReactNode; title: string; note: string; children: React.ReactNode }) { return <section className="ovh-section"><header><span className="ovh-section-icon">{icon}</span><div><h3>{title}</h3><p>{note}</p></div></header>{children}</section>; }
function RateVolumeTrend({ state, title, source, rateKey, volumeKey, axisKey, ratio = false, note }: { state: LoadState<MetricData>; title: string; source: string; rateKey: string; volumeKey?: string; axisKey: string; ratio?: boolean; note: string }) {
  return <StateBlock state={state}>{(data) => {
    const axes = [...new Set(data.rows.map((row) => String(row[axisKey] ?? "")).filter(Boolean))];
    const tiers = [...new Set(data.rows.map((row) => String(row.tier ?? "")).filter(Boolean))];
    const series = tiers.length ? tiers : [""];
    const rates = data.rows.map((row) => Number(row[rateKey])).filter(Number.isFinite);
    const volumes = volumeKey ? data.rows.map((row) => Number(row[volumeKey])).filter(Number.isFinite) : [];
    const maxRate = Math.max(...rates, 1);
    const maxVolume = Math.max(...volumes, 1);
    const width = Math.max(640, axes.length * 92);
    const chartHeight = 210;
    const point = (row: Record<string, unknown>, tierIndex: number) => {
      const axisIndex = axes.indexOf(String(row[axisKey]));
      const x = 48 + axisIndex * ((width - 86) / Math.max(axes.length - 1, 1)) + (tierIndex - (series.length - 1) / 2) * 7;
      const rate = Number(row[rateKey]);
      return { x, y: 16 + (1 - rate / maxRate) * 142, rate };
    };
    return <article className="ovh-chart"><header><div><h4>{title}</h4><p>{source}</p></div><Tag color={data.status === "available" || data.status === "partial" ? "green" : "orange"}>{data.status}</Tag></header>{sourceStatus(data)}{data.rows.length > 0 ? <><div className="ovh-combo-scroll"><svg className="ovh-combo" viewBox={`0 0 ${width} ${chartHeight}`} role="img" aria-label={`${title}：${axisKey} 分类轴，CCR 折线与 NFS 柱`}>
      <line x1="40" y1="158" x2={width - 24} y2="158" className="ovh-axis" />
      {data.rows.map((row, index) => { const tierIndex = Math.max(0, series.indexOf(String(row.tier ?? ""))); const p = point(row, tierIndex); const volume = volumeKey ? Number(row[volumeKey]) : Number.NaN; const barHeight = Number.isFinite(volume) ? volume / maxVolume * 128 : 0; return Number.isFinite(volume) ? <rect key={`bar-${index}`} x={p.x - 5} y={158 - barHeight} width="10" height={barHeight} className="ovh-combo-bar"><title>{`${String(row[axisKey])}${row.tier ? ` · ${String(row.tier)}` : ""} · ${volumeKey} ${numberText(volume)}`}</title></rect> : null; })}
      {series.map((tier, tierIndex) => { const rows = data.rows.filter((row) => String(row.tier ?? "") === tier && Number.isFinite(Number(row[rateKey]))); const points = rows.map((row) => point(row, tierIndex)); return <g key={tier || "global"} className={`ovh-line-series is-${tierIndex % 4}`}><polyline points={points.map((p) => `${p.x},${p.y}`).join(" ")} />{points.map((p, index) => <circle key={`${tier}-${index}`} cx={p.x} cy={p.y} r="4"><title>{`${tier || "Global"} · ${ratio ? ratioText(p.rate) : numberText(p.rate, 3)}`}</title></circle>)}</g>; })}
      {axes.map((axis, index) => { const x = 48 + index * ((width - 86) / Math.max(axes.length - 1, 1)); return <text key={axis} x={x} y="181" textAnchor="middle">{axis}</text>; })}
    </svg></div><div className="ovh-legend"><span><i className="is-line" />{rateKey}{ratio ? "（源值 0–1，显示为百分比）" : data.source.metric_units && (data.source.metric_units as Record<string, string>)[rateKey] === "ppm" ? "（ppm）" : "（源值）"}</span>{volumeKey && <span><i className="is-bar" />{volumeKey}（count）</span>}{series.filter(Boolean).map((tier, index) => <span key={tier}><i className={`is-series is-${index % 4}`} />{tier}</span>)}</div></> : <div className="ovh-chart-empty">{data.reason || "源报表没有返回行；未补零"}</div>}<p className="ovh-meta">{note} · 过滤窗口 {data.window.start_date} 至 {data.window.end_date} · {data.window.region}；不在前端平均 CCR。</p></article>;
  }}</StateBlock>;
}

export function IntegratedOverview({ model }: { model: ReadModel }) {
  const { filters } = useSharedFilters();
  const initialScope = useMemo(quarterToDate, []);
  const [draftScope, setDraftScope] = useState(initialScope);
  const [window, setWindow] = useState(initialScope);
  const [accounts, setAccounts] = useState<LoadState<AccountData>>({ loading: true });
  const [summary, setSummary] = useState<LoadState<MetricData>>({ loading: true });
  const [revenueData, setRevenue] = useState<LoadState<MetricData>>({ loading: true });
  const [p0, setP0] = useState<LoadState<MetricData>>({ loading: true });
  const [p1, setP1] = useState<LoadState<MetricData>>({ loading: true });
  const [approvalSummary, setApprovalSummary] = useState<LoadState<MetricData>>({ loading: true });
  const [approvalWeekly, setApprovalWeekly] = useState<LoadState<MetricData>>({ loading: true });
  const [fdr, setFdr] = useState<LoadState<MetricData>>({ loading: true });
  const [overturned, setOverturned] = useState<LoadState<MetricData>>({ loading: true });
  const [regionTier, setRegionTier] = useState<LoadState<MetricData>>({ loading: true });
  const [quota, setQuota] = useState<LoadState<QuotaData>>({ loading: true });
  const [governance, setGovernance] = useState<LoadState<GovernanceData>>({ loading: true });
  const [trend, setTrend] = useState("p0p1");
  useEffect(() => {
    if (!window.start_date || !window.end_date) return;
    let active = true; const query = { start_date: window.start_date, end_date: window.end_date, region: window.region, tier: window.tiers.join(",") };
    const load = <T,>(setter: (value: LoadState<T>) => void, action: Promise<ApiEnvelope<T>>) => { setter({ loading: true }); action.then((response) => { if (active) setter({ loading: false, data: unwrap(response) }); }).catch((reason) => { if (active) setter({ loading: false, error: reason instanceof Error ? reason.message : "读取失败" }); }); };
    load(setAccounts, overviewAccountsList<ApiEnvelope<AccountData>>({ end_date: window.end_date, region: window.region }));
    [[setSummary, "business-summary"], [setRevenue, "revenue"], [setP0, "p0"], [setP1, "p1-weekly"], [setApprovalSummary, "approval-summary"], [setApprovalWeekly, "approval-weekly"], [setFdr, "fdr-weekly"], [setOverturned, "overturned-weekly"], [setRegionTier, "region-tier-accounts"]].forEach(([setter, metric]) => load(setter as (value: LoadState<MetricData>) => void, overviewMetricsByMetricGet<ApiEnvelope<MetricData>>(metric as string, query)));
    load(setQuota, overviewQuotaList<ApiEnvelope<QuotaData>>(query));
    load(setGovernance, overviewGovernanceList<ApiEnvelope<GovernanceData>>({ ...query, submitter: filters.submitter || undefined }));
    return () => { active = false; };
  }, [window.start_date, window.end_date, window.region, window.tiers.join(","), filters.submitter]);
  return <div className="ovh-root" data-testid="integrated-overview">
    <form className="ovh-filters" onSubmit={(event) => { event.preventDefault(); if (draftScope.start_date <= draftScope.end_date && draftScope.tiers.length) setWindow({ ...draftScope }); }}><label>开始日期<input type="date" value={draftScope.start_date} onChange={(event) => setDraftScope({ ...draftScope, start_date: event.target.value })} /></label><label>结束日期<input type="date" value={draftScope.end_date} onChange={(event) => setDraftScope({ ...draftScope, end_date: event.target.value })} /></label><label>Region<select value={draftScope.region} onChange={(event) => setDraftScope({ ...draftScope, region: event.target.value })}>{["Global", "APAC", "EUI", "LATAM", "METAP", "NA"].map((region) => <option key={region}>{region}</option>)}</select></label><fieldset><legend>业务 Tier（多选）</legend>{["ST", "HT", "BT", "ET"].map((tier) => <label key={tier}><input type="checkbox" checked={draftScope.tiers.includes(tier)} onChange={(event) => setDraftScope({ ...draftScope, tiers: event.target.checked ? [...draftScope.tiers, tier] : draftScope.tiers.filter((item) => item !== tier) })} />{tier}</label>)}</fieldset><button type="submit">应用筛选</button><small>默认北京时间本季度至今。P0 固定按 QTD 至 D-1 下推；Tier 对 P0 / Approval 仅作源过滤，返回不拆 Tier；P1 按 Region×Tier 展示。</small></form>
    <div className="ovh-scope"><b>数据总览 / Overview</b><span>业务日期 {window.start_date} 至 {window.end_date} · {window.region} · Tier {window.tiers.join(" / ")}</span><Tag color="green">只读 · 无业务写入</Tag></div>
    <Overview model={model} showQuota={false} />
    <Section icon={<BarChart3 size={17} />} title="业务表现" note="业务指标按所选范围查询；快照指标注明实际数据日期。">
      <div className="ovh-kpis ovh-kpis-four"><StateBlock state={summary}>{(data) => <><article><span>TAP Accounts · 区间去重</span><b>{numberText(data.summary.account_count)}</b><small>源端 COUNT DISTINCT</small></article><article><span>TAP Revenue</span><b>{numberText(data.summary.revenue, 2)}</b><small>RID 3057978 仅用于 Revenue 分布</small></article></>}</StateBlock><StateBlock state={p0}>{(data) => <><article><span>P0 CCR / NFS</span><b>{numberText(data.rows.length)}</b><small>Region 宽行 · CCR 源值直出</small></article><article><span>P0 时间口径</span><b>QTD → D-1</b><small>日期仅过滤，不作为输出轴</small></article></>}</StateBlock></div>
      <StateBlock state={approvalSummary}>{(data) => <><div className="ovh-approval-cards"><article><span>Approval / Banned</span><b>{numberText(data.rows.length)}</b><small>源季度行 · RID3061919</small></article><article><span>分组口径</span><b>Global / 过滤</b><small>Region / Tier 不伪装成输出分组</small></article></div>{sourceStatus(data)}</>}</StateBlock>
    </Section>
    <Section icon={<Database size={17} />} title="客户与营收分布" note="账户快照与区间营收分别展示，查看四 Tier 及区域分布。">
      <div className="ovh-two"><StateBlock state={accounts}>{(data) => <div className="ovh-panel"><div className="ovh-panel-title"><b>Account 数量与占比</b><span>Snapshot {data.data_as_of || "unavailable"}</span></div>{sourceStatus(data)}<div className="ovh-donut-row"><TierDonut rows={data.rows as unknown as Record<string, unknown>[]} valueKey="account_count" shareKey="account_share" /><div className="ovh-tier-list">{data.rows.map((row) => <div key={row.tier}><span>{row.tier}</span><b>{numberText(row.account_count)}</b><i><em style={{ width: `${Math.max(0, Math.min(row.account_share || 0, 100))}%` }} /></i><small>{percentText(row.account_share)}</small></div>)}</div></div><p className="ovh-meta">四 Tier 合计 {numberText(data.tier_membership_total)}；缺 Tier 时不绘制占比。</p></div>}</StateBlock><StateBlock state={revenueData}>{(data) => <div className="ovh-panel"><div className="ovh-panel-title"><b>Revenue 金额与占比</b><span>RID 3057978</span></div>{sourceStatus(data)}<div className="ovh-donut-row"><TierDonut rows={["ST", "HT", "BT", "ET"].map((tier) => data.rows.find((item) => item.tier === tier) || { tier })} valueKey="revenue" shareKey="share" /><div className="ovh-tier-list">{["ST", "HT", "BT", "ET"].map((tier) => { const row = data.rows.find((item) => item.tier === tier); return <div key={tier}><span>{tier}</span><b>{numberText(row?.revenue, 2)}</b><i><em style={{ width: `${Math.max(0, Math.min(Number(row?.share) || 0, 100))}%` }} /></i><small>{percentText(row?.share)}</small></div>; })}</div></div><p className="ovh-meta">区间合计 {numberText(data.summary.revenue, 2)} · 币种沿用源端。</p></div>}</StateBlock></div>
      <StateBlock state={regionTier}>{(data) => <div className="ovh-panel ovh-region-tier"><div className="ovh-panel-title"><b>Region × Tier Account / Revenue</b><span>RID 3057978 · 登录阻塞时 partial</span></div>{sourceStatus(data)}<div className="ovh-region-grid">{data.rows.map((row, index) => <div key={`${String(row.region)}-${String(row.tier)}-${index}`}><span>{String(row.region)}</span><b>{String(row.tier)}</b><em>{numberText(row.account_count)}</em></div>)}</div><p className="ovh-meta">展示源端 Region×Tier 行；不声称跨分片去重总数，不与 Revenue 拼接。</p></div>}</StateBlock>
    </Section>
    <Section icon={<TrendingUp size={17} />} title="业务质量分析" note="按指标查看各区域及周期表现。未返回的数据不以零代替。">
      <Radio.Group type="button" value={trend} onChange={setTrend} className="ovh-trend-tabs"><Radio value="p0p1">P0 / P1</Radio><Radio value="approval">Approval / Banned</Radio><Radio value="fdr">FDR / Overturned</Radio></Radio.Group>
      {trend === "p0p1" && <div className="ovh-two"><RateVolumeTrend state={p0} title="P0 CCR / NFS · 区域对比" source="RID3065818 / SID1139137 / TID336" rateKey="ccr" volumeKey="nfs" axisKey="region" note="x 轴为 Region；CCR 折线、NFS 柱；不是时间趋势；Tier 仅作源过滤" /><RateVolumeTrend state={p1} title="P1 CCR / NFS · 区域与 Tier" source="RID3058062 · 源报表无时间输出" rateKey="ccr" volumeKey="nfs" axisKey="region" note="x 轴为 Region，按 Tier 分系列；CCR（ppm）折线、NFS 柱；不是周趋势" /></div>}
      {trend === "approval" && <RateVolumeTrend state={approvalWeekly} title="Approval Rate / Banned · 季度表现" source="RID3061919 · year-quarter p_date" rateKey="approval_rate" volumeKey="banned" axisKey="quarter" ratio note="x 轴沿用源报表季度；Approval Rate 折线、banned 柱；Region / Tier 仅作源过滤" />}
      {trend === "fdr" && <div className="ovh-two"><RateVolumeTrend state={fdr} title="Ads FDR" source={window.region === "Global" ? "Global RID2883048" : "Region RID2883021"} rateKey="fdr" axisKey="week" note="周标签直接采用源字段" /><RateVolumeTrend state={overturned} title="Overturned Account Volume" source="RID2883046" rateKey="overturned" axisKey="week" note="保留源 no_data 语义；周标签直接采用源字段" /></div>}
    </Section>
    <Section icon={<Gauge size={17} />} title="配额使用情况" note="ET 展示区间使用量，ST 展示季度快照；两者分别注明时间口径。"><StateBlock state={quota}>{(data) => <div className="ovh-quarter-grid">{data.quarters.map((period) => <article key={period.quarter}><header><b>{period.quarter}</b><Tag color={period.status === "available" ? "green" : "orange"}>{period.status}</Tag></header><p>usage_window {period.usage_window.start_date} 至 {period.usage_window.end_date}</p><p>quota_period {period.quota_period.start_date} 至 {period.quota_period.end_date}</p>{period.reason ? <p className="ovh-note">{period.reason}</p> : <><div className="ovh-quota-row"><span>ET 区间使用量 / 季度配额：{numberText(period.et?.usage_count)} / {numberText(period.et?.quota)}</span><Progress percent={Math.max(0, Math.min(period.et?.ratio || 0, 100))} showText={false} /><small>ratio {percentText(period.et?.ratio)} · {period.et?.numerator_definition || period.numerator_definition}</small></div><div className="ovh-quota-row"><span>ST 季度快照：{numberText(period.st?.quarter_snapshot_count)}</span><small>状态 {period.st?.quarter_snapshot_status || "unavailable"} · 快照时间 {period.st_snapshot_at || "unavailable"}</small><small>所选区间 usage_count — · ratio —</small></div></>}</article>)}</div>}</StateBlock></Section>
    <Section icon={<ShieldAlert size={17} />} title="风险与处置概况" note="风险指标来自保存批次，处置状态展示最新进展。"><StateBlock state={governance}>{(data) => <>{data.reason && <Alert type="warning" content={data.reason} />}<div className="ovh-kpis ovh-risk-kpis">{[["已评估主体", data.evaluated_subjects], ["权威风险主体", data.risk_subjects], ["风险占比", percentText(data.risk_share)], ["CCR 增幅 Top20", data.top20_subjects], ["预警事件", data.alert_events], ["待处理 / 处理中 / 已关闭", `${data.states.pending || 0} / ${data.states.in_progress || 0} / ${data.states.closed || 0}`]].map(([label, value]) => <article key={String(label)}><span>{label}</span><b>{typeof value === "number" ? numberText(value) : value}</b></article>)}</div><div className="ovh-two"><div className="ovh-panel"><div className="ovh-panel-title"><b>风险等级</b><span>{data.risk_share_scope}</span></div>{Object.entries(data.by_level || {}).map(([key, value]) => <div className="ovh-bar" key={key}><span>{key}</span><i><em style={{ width: `${data.risk_subjects ? value / data.risk_subjects * 100 : 0}%` }} /></i><b>{value}</b></div>)}</div><div className="ovh-panel"><div className="ovh-panel-title"><b>扫描覆盖情况</b><Tag color={data.coverage_status === "complete" ? "green" : "orange"}>{data.coverage_status}</Tag></div>{Object.entries(data.coverage || {}).map(([key, value]) => <div className="ovh-coverage" key={key}><b>{key}</b><Tag>{value}</Tag></div>)}<p className="ovh-note">{data.coverage_note}</p>{(data.batch_windows || []).map((batch) => <p className="ovh-meta" key={`${batch.batch_id}-${batch.program}`}>{batch.program} 指标周 {batch.start_date} 至 {batch.end_date} · {batch.coverage} · 已评估 {numberText(batch.evaluated_subjects)} · 风险 {numberText(batch.risk_subjects)}</p>)}</div></div></>}</StateBlock></Section>
    <footer className="ovh-foot"><Database size={14} /> 数据不可用时会保留原因与当前查询范围，不以零值代替。</footer>
  </div>;
}
