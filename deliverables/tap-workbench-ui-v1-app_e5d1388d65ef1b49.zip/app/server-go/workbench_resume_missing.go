package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"
)

type wbResumeMissingInput struct {
	MaxChunks            int    `json:"max_chunks"`
	ResumeProgram        string `json:"resume_program"`
	IncludeEnrichment    bool   `json:"include_enrichment"`
	RetryAllowlistFailed bool   `json:"retry_allowlist_failed"`
}

type wbFieldClassification map[string]map[string]int

const wbResumeEnrichmentChunkSize = 25

func wbClassifyMetric(value *float64, status string) string {
	if value != nil {
		if *value == 0 {
			return "real_zero"
		}
		return metricAvailable
	}
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "success", "no_data", metricSourceNull:
		return metricSourceNull
	case "window_incomplete":
		return "window_incomplete"
	case metricMissingAnchor:
		return metricMissingAnchor
	case metricAmbiguousAnchor:
		return metricAmbiguousAnchor
	case metricFailed, "error", "query_failed", "source_error", "partial_rejected":
		return metricFailed
	case "", metricQuerying, "pending", "running", "not_queried":
		return "not_queried"
	default:
		return metricFailed
	}
}

func wbClassifyRows(rows []wbRow) wbFieldClassification {
	out := wbFieldClassification{}
	add := func(field, status string) {
		if out[field] == nil {
			out[field] = map[string]int{}
		}
		out[field][status]++
	}
	for _, row := range rows {
		add("current_ccr", wbClassifyMetric(row.CCR, row.MetricStatus))
		add("current_nfs", wbClassifyMetric(row.NFS, row.MetricStatus))
		revenueStatus, _ := wbRowRevenueState(row)
		add("current_revenue", wbClassifyMetric(row.Revenue, revenueStatus))
		add("pre_ccr", wbClassifyMetric(row.Comparison.PreCCR, row.Comparison.PreCCRFact.Status))
		if row.Comparison.Status == "window_incomplete" {
			add("post_ccr", "window_incomplete")
		} else {
			add("post_ccr", wbClassifyMetric(row.Comparison.PostCCR, row.Comparison.PostCCRFact.Status))
		}
		increaseStatus := row.Comparison.IncreaseFact.Status
		if row.Comparison.Status == "window_incomplete" {
			add("comparison_increase", "window_incomplete")
		} else {
			add("comparison_increase", wbClassifyMetric(row.Comparison.CCRGrowthPct, increaseStatus))
		}
		completedEnrichment := strings.TrimSpace(row.AggregationNote) != ""
		if strings.TrimSpace(row.Member.Name) != "" {
			add("account_name", metricAvailable)
		} else if completedEnrichment {
			add("account_name", metricSourceNull)
		} else {
			add("account_name", "not_queried")
		}
		if len(row.AdvertiserTop10) > 0 {
			add("advertiser_top10", metricAvailable)
		} else if len(row.Advertisers) > 0 {
			ccrState := wbClassifyMetric(row.CCR, row.MetricStatus)
			nfsState := wbClassifyMetric(row.NFS, row.MetricStatus)
			if ccrState == metricFailed || nfsState == metricFailed {
				add("advertiser_top10", metricFailed)
			} else if ccrState == "not_queried" || nfsState == "not_queried" {
				add("advertiser_top10", "not_queried")
			} else {
				// Pair mapping exists and Account Current completed, but no pair has
				// a displayable CCR. This is a terminal source NULL, not a query gap.
				add("advertiser_top10", metricSourceNull)
			}
		} else if completedEnrichment {
			add("advertiser_top10", "real_zero")
		} else {
			add("advertiser_top10", "not_queried")
		}
		reasonStatus, allowlistStatus := "not_queried", "not_queried"
		if completedEnrichment {
			reasonStatus, allowlistStatus = metricSourceNull, metricSourceNull
		}
		for _, item := range row.Advertisers {
			if item.ReportedReasonsStatus == metricFailed {
				reasonStatus = metricFailed
			} else if item.ReportedReasonsStatus == metricAvailable {
				if len(item.ReportedReasons) > 0 {
					reasonStatus = metricAvailable
				} else if reasonStatus != metricAvailable {
					reasonStatus = metricSourceNull
				}
			}
			if wbAllowlistNeedsRepair(item.AllowlistStatus) {
				allowlistStatus = metricFailed
			} else if item.AllowlistStatus != "" && !strings.EqualFold(item.AllowlistStatus, "unknown") {
				allowlistStatus = metricAvailable
			}
		}
		add("reported_reasons", reasonStatus)
		add("allowlist", allowlistStatus)
	}
	return out
}

func wbNeedsCurrentRepair(row wbRow) bool {
	statuses := []string{
		wbClassifyMetric(row.CCR, row.MetricStatus),
		wbClassifyMetric(row.NFS, row.MetricStatus),
	}
	revenueStatus, _ := wbRowRevenueState(row)
	statuses = append(statuses, wbClassifyMetric(row.Revenue, revenueStatus))
	for _, status := range statuses {
		if status == "not_queried" || status == metricFailed {
			return true
		}
	}
	return false
}

func wbMergeSnapshotFacts(state *wbDisk, target wbJob) (int, error) {
	path, err := wbStatePath()
	if err != nil {
		return 0, err
	}
	files, err := filepath.Glob(path + ".*")
	if err != nil {
		return 0, err
	}
	byKey := map[string]int{}
	for i, row := range target.Rows {
		byKey[wbFunnelRowKey(target.Request.Program, row)] = i
	}
	mergedFields := 0
	for _, name := range files {
		file, openErr := os.Open(name)
		if openErr != nil {
			continue
		}
		var snapshot wbDisk
		decodeErr := json.NewDecoder(file).Decode(&snapshot)
		_ = file.Close()
		if decodeErr != nil {
			continue
		}
		for _, job := range snapshot.Jobs {
			if job.BatchID != target.BatchID || !strings.EqualFold(job.Request.Program, target.Request.Program) {
				continue
			}
			for _, candidate := range job.Rows {
				index, ok := byKey[wbFunnelRowKey(target.Request.Program, candidate)]
				if !ok {
					continue
				}
				before, _ := json.Marshal(target.Rows[index])
				if strings.EqualFold(target.Request.Program, "ET") {
					var reasons []string
					target.Rows[index], reasons = wbMergePersistedETRow(target.Rows[index], candidate)
					for _, reason := range reasons {
						wbAppendMergeWarning(&target, reason, job.ID, candidate.Member.AccountID)
					}
				} else {
					target.Rows[index] = wbMergeRowBestFacts(target.Rows[index], candidate)
				}
				after, _ := json.Marshal(target.Rows[index])
				if string(before) != string(after) {
					mergedFields++
				}
			}
		}
	}
	state.Jobs[target.ID] = target
	return mergedFields, nil
}

var wbQueryAllowlistRows = func(ctx context.Context, request *http.Request, ids []string) ([]map[string]any, error) {
	return queryEvidenceRows(ctx, request, "advertiser_allowlist", ids, "advertiser_id", "", "")
}

var wbQueryAccountAllowlistRows = func(ctx context.Context, request *http.Request, ids []string) ([]map[string]any, error) {
	return queryEvidenceRows(ctx, request, "advertiser_allowlist", ids, "account_id", "", "")
}

func wbAllowlistNeedsRepair(status string) bool {
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "", "unknown", "query_failed", "not_queried", "matched_scope_unknown", "not_matched_scope_unknown", "n/a：tht 未使用 et/st bridge allowlist":
		return true
	default:
		return false
	}
}

func wbRetryFailedAllowlist(request *http.Request, jobID string, maxChunks int) (map[string]any, int) {
	if maxChunks < 0 {
		return map[string]any{"error": "max_chunks must be >= 0"}, http.StatusBadRequest
	}
	wbMu.Lock()
	state, err := wbReadDisk()
	if err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	job, ok := state.Jobs[jobID]
	if !ok {
		wbMu.Unlock()
		return map[string]any{"error": "scan not found"}, http.StatusNotFound
	}
	normalizedWindowReasons, cleanedSuccessEvidence := 0, 0
	for i := range job.Rows {
		for itemIndex := range job.Rows[i].Advertisers {
			item := &job.Rows[i].Advertisers[itemIndex]
			if !wbAllowlistNeedsRepair(item.AllowlistStatus) && item.AllowlistEvidence != nil {
				item.AllowlistEvidence = nil
				item.AllowlistError = ""
				cleanedSuccessEvidence++
			}
		}
		if job.Rows[i].Comparison.Status != "window_incomplete" {
			continue
		}
		facts := []*metricFact{&job.Rows[i].Comparison.PreCCRFact, &job.Rows[i].Comparison.PostCCRFact, &job.Rows[i].Comparison.IncreaseFact}
		for _, fact := range facts {
			if fact.Status == metricQuerying && fact.Reason != "Post 观察窗口尚未结束" {
				fact.Reason = "Post 观察窗口尚未结束"
				normalizedWindowReasons++
			}
		}
	}
	if normalizedWindowReasons > 0 || cleanedSuccessEvidence > 0 {
		state.Jobs[jobID] = job
		if err = wbWriteDisk(state); err != nil {
			wbMu.Unlock()
			return map[string]any{"error": err.Error()}, http.StatusInternalServerError
		}
	}
	wbMu.Unlock()

	failedAccounts := map[string]bool{}
	failedPairs, uniqueIDs := 0, map[string]bool{}
	for _, row := range job.Rows {
		for _, item := range row.Advertisers {
			if wbAllowlistNeedsRepair(item.AllowlistStatus) {
				failedAccounts[row.Member.AccountID] = true
				failedPairs++
				uniqueIDs[item.AdvertiserID] = true
			}
		}
	}
	ids := make([]string, 0, len(uniqueIDs))
	for id := range uniqueIDs {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	limit := len(ids)
	if maxChunks > 0 && maxChunks*wbEvidenceIDBatchSize < limit {
		limit = maxChunks * wbEvidenceIDBatchSize
	}
	ids = ids[:limit]

	processedIDs, resolvedPairs, failedAfter, normalizedMessages := 0, 0, failedPairs, 0
	for start := 0; start < len(ids); start += wbEvidenceIDBatchSize {
		end := start + wbEvidenceIDBatchSize
		if end > len(ids) {
			end = len(ids)
		}
		chunk := ids[start:end]
		allowRows, queryErr := wbQueryAllowlistRows(request.Context(), request, chunk)
		matched := wbAllowlistLabels(allowRows, "advertiser_id")
		attemptedAt := time.Now().UTC().Format(time.RFC3339)
		chunkSet := map[string]bool{}
		for _, id := range chunk {
			chunkSet[id] = true
		}

		wbMu.Lock()
		state, err = wbReadDisk()
		if err == nil {
			job = state.Jobs[jobID]
			for rowIndex := range job.Rows {
				update := func(items []wbAdvertiserEvidence) int {
					changed := 0
					for i := range items {
						if !wbAllowlistNeedsRepair(items[i].AllowlistStatus) || !chunkSet[items[i].AdvertiserID] {
							continue
						}
						if queryErr != nil {
							evidence := map[string]any{"source": "advertiser_allowlist", "id_dimension": "advertiser_id", "advertiser_ids": append([]string(nil), chunk...), "attempted_at": attemptedAt}
							items[i].AllowlistStatus = "Unknown"
							items[i].AllowlistEvidence = evidence
							items[i].AllowlistError = sanitizeLogText(queryErr.Error())
							evidence["error"] = items[i].AllowlistError
							continue
						}
						items[i].AllowlistEvidence = nil
						items[i].AllowlistError = ""
						items[i].AllowlistStatus = wbAllowlistDisplay(matched[items[i].AdvertiserID])
						changed++
					}
					return changed
				}
				resolvedPairs += update(job.Rows[rowIndex].Advertisers)
				_ = update(job.Rows[rowIndex].AdvertiserTop10)
				normalized := job.Rows[rowIndex].Message
				revenues := []*float64{job.Rows[rowIndex].Revenue}
				if len(job.Rows[rowIndex].AdvertiserTop10) > 0 {
					revenues = append(revenues, job.Rows[rowIndex].AdvertiserTop10[0].Revenue)
				}
				for _, revenue := range revenues {
					if revenue == nil {
						continue
					}
					compact := fmt.Sprintf("%g", *revenue)
					if strings.ContainsAny(compact, "eE") {
						normalized = strings.ReplaceAll(normalized, compact, wbRevenueMessageNumber(revenue))
					}
				}
				if normalized != job.Rows[rowIndex].Message {
					job.Rows[rowIndex].Message = normalized
					normalizedMessages++
				}
			}
			processedIDs += len(chunk)
			failedAfter = failedPairs - resolvedPairs
			job.Stage = fmt.Sprintf("allowlist_retry:%d/%d", processedIDs, len(ids))
			state.Jobs[jobID] = job
			err = wbWriteDisk(state)
		}
		wbMu.Unlock()
		if err != nil {
			return map[string]any{"error": err.Error(), "processed_advertiser_ids": processedIDs, "resolved_pairs": resolvedPairs}, http.StatusInternalServerError
		}
		if queryErr != nil {
			logMsg(fmt.Sprintf("[allowlist-retry] scan_id=%s advertiser_ids=%s error=%s", jobID, strings.Join(chunk, ","), sanitizeLogText(queryErr.Error())), "plugin")
		}
	}

	accountIDs := []string{}
	if !strings.EqualFold(job.Request.Program, "THT") {
		for _, row := range job.Rows {
			if wbAllowlistNeedsRepair(row.AllowlistStatus) && strings.TrimSpace(row.Member.AccountID) != "" {
				accountIDs = append(accountIDs, row.Member.AccountID)
			}
		}
	}
	accountIDs = uniqueNonEmpty(accountIDs)
	sort.Strings(accountIDs)
	if maxChunks > 0 && maxChunks*wbEvidenceIDBatchSize < len(accountIDs) {
		accountIDs = accountIDs[:maxChunks*wbEvidenceIDBatchSize]
	}
	resolvedAccounts := 0
	for start := 0; start < len(accountIDs); start += wbEvidenceIDBatchSize {
		end := start + wbEvidenceIDBatchSize
		if end > len(accountIDs) {
			end = len(accountIDs)
		}
		chunk := accountIDs[start:end]
		rows, accountErr := wbQueryAccountAllowlistRows(request.Context(), request, chunk)
		labels := wbAllowlistLabels(rows, "account_id")
		chunkSet := map[string]bool{}
		for _, id := range chunk {
			chunkSet[id] = true
		}
		wbMu.Lock()
		state, err = wbReadDisk()
		if err == nil {
			job = state.Jobs[jobID]
			for i := range job.Rows {
				if !chunkSet[job.Rows[i].Member.AccountID] || !wbAllowlistNeedsRepair(job.Rows[i].AllowlistStatus) {
					continue
				}
				if accountErr != nil {
					job.Rows[i].AllowlistStatus = "Unknown"
				} else {
					job.Rows[i].AllowlistStatus = wbAllowlistDisplay(labels[job.Rows[i].Member.AccountID])
					resolvedAccounts++
				}
			}
			state.Jobs[jobID] = job
			err = wbWriteDisk(state)
		}
		wbMu.Unlock()
		if err != nil {
			return map[string]any{"error": err.Error()}, http.StatusInternalServerError
		}
		if accountErr != nil {
			logMsg(fmt.Sprintf("[allowlist-retry] scan_id=%s account_ids=%s error=%s", jobID, strings.Join(chunk, ","), sanitizeLogText(accountErr.Error())), "plugin")
		}
	}

	remainingAccounts := map[string]bool{}
	for _, row := range job.Rows {
		for _, item := range row.Advertisers {
			if wbAllowlistNeedsRepair(item.AllowlistStatus) {
				remainingAccounts[row.Member.AccountID] = true
			}
		}
	}
	return map[string]any{
		"id": jobID, "status": job.Status, "stage": job.Stage,
		"target_accounts": len(failedAccounts), "target_pairs": failedPairs,
		"processed_advertiser_ids": processedIDs, "resolved_pairs": resolvedPairs, "resolved_accounts": resolvedAccounts,
		"normalized_revenue_messages": normalizedMessages, "normalized_window_reasons": normalizedWindowReasons, "cleaned_success_evidence": cleanedSuccessEvidence,
		"remaining_failed_accounts": len(remainingAccounts), "remaining_failed_pairs": failedAfter,
		"classification": wbClassifyRows(job.Rows),
		"side_effects":   map[string]any{"membership_scan": false, "new_task": false, "other_enrichment": false, "case": false, "notification": false},
	}, http.StatusOK
}

var wbQueryAdvertiserCurrentRows = func(ctx context.Context, request *http.Request, ids []string, start, end string) ([]map[string]any, error) {
	return queryEvidenceRows(ctx, request, "weekly_pair_ccr_nfs", ids, "advertiser_id", start, end)
}

func wbPairCurrentNeedsRepair(item wbAdvertiserEvidence) bool {
	status := strings.ToLower(strings.TrimSpace(asString(item.CurrentSource["status"])))
	return status == "" || status == metricSourceNull || status == "no_data" || status == metricFailed || status == "error" || status == "query_failed" || status == "source_error"
}

func wbClassifyPairFields(rows []wbRow) wbFieldClassification {
	out := wbFieldClassification{}
	add := func(field, status string) {
		if out[field] == nil {
			out[field] = map[string]int{}
		}
		out[field][status]++
	}
	for _, row := range rows {
		for _, item := range row.Advertisers {
			metricStatus := strings.ToLower(strings.TrimSpace(asString(item.CurrentSource["status"])))
			if metricStatus == "" {
				metricStatus = "not_queried"
			}
			add("ccr", wbClassifyMetric(item.CCR, metricStatus))
			add("nfs", wbClassifyMetric(item.NFS, metricStatus))
			add("revenue", wbClassifyMetric(item.Revenue, item.RevenueStatus))
			if strings.TrimSpace(item.AdvertiserName) != "" {
				add("names", metricAvailable)
			} else {
				add("names", metricSourceNull)
			}
			reasonStatus := strings.ToLower(strings.TrimSpace(item.ReportedReasonsStatus))
			if reasonStatus == "" {
				reasonStatus = "not_queried"
			}
			add("reasons", reasonStatus)
			allowlistStatus := strings.ToLower(strings.TrimSpace(item.AllowlistStatus))
			switch allowlistStatus {
			case "query_failed", metricFailed, "error", "source_error":
				add("allowlist", metricFailed)
			case "", "unknown":
				add("allowlist", "not_queried")
			default:
				add("allowlist", metricAvailable)
			}
		}
	}
	return out
}

func wbResumeAdvertiserCurrent(request *http.Request, jobID string, maxChunks int) (int, int, error) {
	return wbResumeAdvertiserCurrentProgram(request, jobID, maxChunks, "")
}

func wbResumeAdvertiserCurrentProgram(request *http.Request, jobID string, maxChunks int, program string) (int, int, error) {
	wbMu.Lock()
	state, err := wbReadDisk()
	if err != nil {
		wbMu.Unlock()
		return 0, 0, err
	}
	job, ok := state.Jobs[jobID]
	wbMu.Unlock()
	if !ok {
		return 0, 0, errors.New("scan not found")
	}

	targetIDs := map[string]bool{}
	for _, row := range job.Rows {
		if program != "" && !strings.EqualFold(row.Program, program) {
			continue
		}
		for _, item := range row.Advertisers {
			if wbPairCurrentNeedsRepair(item) {
				targetIDs[item.AdvertiserID] = true
			}
		}
	}
	ids := make([]string, 0, len(targetIDs))
	for id := range targetIDs {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	remaining := len(ids)
	if len(ids) == 0 {
		return 0, 0, nil
	}
	if maxChunks > 0 && maxChunks*wbEvidenceIDBatchSize < len(ids) {
		ids = ids[:maxChunks*wbEvidenceIDBatchSize]
	}

	queryRequest := request
	if auth := strings.TrimSpace(request.Header.Get("Authorization")); !strings.HasPrefix(strings.ToLower(auth), "byte-cloud-jwt ") {
		jwt, jwtErr := GetCloudJWT(request.Context(), true)
		if jwtErr != nil {
			return 0, remaining, fmt.Errorf("resolve enrichment Cloud JWT: %w", jwtErr)
		}
		queryRequest = request.Clone(request.Context())
		queryRequest.Header = request.Header.Clone()
		queryRequest.Header.Set("Authorization", "Byte-Cloud-JWT "+strings.TrimSpace(jwt))
	}

	processed := 0
	for start := 0; start < len(ids); start += wbEvidenceIDBatchSize {
		end := start + wbEvidenceIDBatchSize
		if end > len(ids) {
			end = len(ids)
		}
		chunk := ids[start:end]
		if start > 0 {
			select {
			case <-request.Context().Done():
				return processed, remaining - processed, request.Context().Err()
			case <-time.After(3 * time.Second):
			}
		}
		rows, queryErr := wbQueryAdvertiserCurrentRows(request.Context(), queryRequest, chunk, job.Request.Start, job.Request.End)
		chunkSet := map[string]bool{}
		for _, id := range chunk {
			chunkSet[id] = true
		}
		returned := map[wbPairKey]map[string]any{}
		if queryErr == nil {
			for _, raw := range rows {
				key := wbPairKey{AccountID: strings.TrimSpace(asString(raw["account_id"])), AdvertiserID: strings.TrimSpace(asString(raw["advertiser_id"]))}
				if !chunkSet[key.AdvertiserID] || !validPair(key.AccountID, key.AdvertiserID) {
					queryErr = fmt.Errorf("Advertiser Current returned invalid or unrequested pair account_id=%q advertiser_id=%q", key.AccountID, key.AdvertiserID)
					break
				}
				if _, duplicate := returned[key]; duplicate {
					queryErr = fmt.Errorf("Advertiser Current returned duplicate pair %s/%s", key.AccountID, key.AdvertiserID)
					break
				}
				returned[key] = raw
			}
		}
		attemptedAt := time.Now().UTC().Format(time.RFC3339)

		wbMu.Lock()
		state, err = wbReadDisk()
		if err == nil {
			job = state.Jobs[jobID]
			for rowIndex := range job.Rows {
				if program != "" && !strings.EqualFold(job.Rows[rowIndex].Program, program) {
					continue
				}
				for itemIndex := range job.Rows[rowIndex].Advertisers {
					item := &job.Rows[rowIndex].Advertisers[itemIndex]
					if !chunkSet[item.AdvertiserID] || !wbPairCurrentNeedsRepair(*item) {
						continue
					}
					if queryErr != nil {
						item.MetricStatus = metricFailed
						item.CurrentSource = map[string]any{"source": "advertiser_current_ccr_nfs", "rid": "2942519", "grain": "account_advertiser_window", "status": metricFailed, "advertiser_ids": append([]string(nil), chunk...), "attempted_at": attemptedAt, "error": sanitizeLogText(queryErr.Error())}
						if item.CCR == nil {
							item.CCRFact = failedMetricFact(sanitizeLogText(queryErr.Error()))
						}
						if item.NFS == nil {
							item.NFSFact = failedMetricFact(sanitizeLogText(queryErr.Error()))
						}
						continue
					}
					key := wbPairKey{AccountID: item.AccountID, AdvertiserID: item.AdvertiserID}
					raw, found := returned[key]
					status := metricSourceNull
					item.MetricStatus = "no_data"
					item.CCR, item.NFS = nil, nil
					item.CCRFact = metricFact{Status: metricSourceNull, Reason: "源指标缺失"}
					item.NFSFact = metricFact{Status: metricSourceNull, Reason: "源指标缺失"}
					var trace any
					if found {
						ccr, ccrErr := strictWBMetric(raw["dynamic_p0_ccr"])
						nfs, nfsErr := strictWBMetric(raw["p0_nfs"])
						if ccrErr != nil || nfsErr != nil {
							errText := fmt.Sprintf("invalid Advertiser Current metrics: ccr=%v nfs=%v", ccrErr, nfsErr)
							item.MetricStatus = metricFailed
							item.CurrentSource = map[string]any{"source": "advertiser_current_ccr_nfs", "rid": "2942519", "grain": "account_advertiser_window", "status": metricFailed, "attempted_at": attemptedAt, "error": errText, "trace": raw["_tap_trace"]}
							item.CCRFact, item.NFSFact = failedMetricFact(errText), failedMetricFact(errText)
							continue
						}
						item.CCR, item.NFS = ccr, nfs
						item.CCRFact, item.NFSFact = successfulMetricFact(ccr), successfulMetricFact(nfs)
						item.MetricStatus, status, trace = "success", "success", raw["_tap_trace"]
						item.SemanticsLabel, item.SemanticsStatus = semanticsLabelFact(raw)
						item.Level, item.Reasons = evaluateWBAbsolute(ccr, nfs, job.Rule)
					}
					item.CurrentSource = map[string]any{"source": "advertiser_current_ccr_nfs", "rid": "2942519", "sid": "1139137", "grain": "account_advertiser_window", "fixed_filters": []string{"is_online=1"}, "status": status, "attempted_at": attemptedAt, "trace": trace}
				}
				job.Rows[rowIndex].AdvertiserTop10 = topAdvertisers(job.Rows[rowIndex].Advertisers, 10)
				job.Rows[rowIndex].AdvertiserCount = len(job.Rows[rowIndex].Advertisers)
				job.Rows[rowIndex].Message = wbMessage(job.Rows[rowIndex], job.Request, job.Rule)
			}
			processed += len(chunk)
			remaining -= len(chunk)
			job.Stage = fmt.Sprintf("advertiser_current_resume:%d/%d", processed, len(ids))
			state.Jobs[jobID] = job
			err = wbWriteDisk(state)
		}
		wbMu.Unlock()
		if err != nil {
			return processed, remaining, err
		}
		if queryErr != nil {
			logMsg(fmt.Sprintf("[advertiser-current-resume] scan_id=%s advertiser_ids=%s error=%s", jobID, strings.Join(chunk, ","), sanitizeLogText(queryErr.Error())), "plugin")
		}
	}
	return processed, remaining, nil
}

func wbResumeAdvertiserCurrentOnly(request *http.Request, jobID string, maxChunks int, program string) (map[string]any, int) {
	program = strings.ToUpper(strings.TrimSpace(program))
	if program != "ET" && program != "ST" && program != "THT" {
		return map[string]any{"error": "advertiser current repair requires ET, ST, or THT"}, http.StatusBadRequest
	}
	processed, remaining, err := wbResumeAdvertiserCurrentProgram(request, jobID, maxChunks, program)
	if err != nil {
		return map[string]any{"error": err.Error(), "advertiser_current_processed": processed, "advertiser_current_remaining": remaining}, http.StatusBadGateway
	}
	wbMu.Lock()
	state, readErr := wbReadDisk()
	var job wbJob
	if readErr == nil {
		job = state.Jobs[jobID]
	}
	wbMu.Unlock()
	if readErr != nil {
		return map[string]any{"error": readErr.Error()}, http.StatusInternalServerError
	}
	return map[string]any{
		"id": jobID, "status": job.Status, "stage": job.Stage,
		"advertiser_current_processed": processed, "advertiser_current_remaining": remaining,
		"pair_classification": wbClassifyPairFields(job.Rows),
		"side_effects":        map[string]any{"membership_scan": false, "new_task": false, "case": false, "notification": false, "other_enrichment": false},
	}, http.StatusOK
}

func wbFinalizeTHTCheckpointJob(job *wbJob) {
	status := "ready"
	if !job.Complete {
		status = "partial"
	}
	for _, row := range job.Rows {
		if row.MetricStatus != "success" || row.CCR == nil || row.NFS == nil {
			status = "partial"
			break
		}
	}
	job.Status = status
	job.Stage = "finished"
	job.FinishedAt = time.Now().UTC().Format(time.RFC3339)
	wbOrder(job.Rows)
	funnel := wbBuildProgramFunnel(*job)
	job.Funnel = &funnel
}

func wbResumeTHTCheckpoint(request *http.Request, jobID string, maxChunks int) (map[string]any, int) {
	if maxChunks < 0 {
		return map[string]any{"error": "max_chunks must be >= 0"}, http.StatusBadRequest
	}
	started := time.Now()
	wbMu.Lock()
	state, err := wbReadDisk()
	if err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	job, ok := state.Jobs[jobID]
	wbMu.Unlock()
	if !ok {
		return map[string]any{"error": "scan not found"}, http.StatusNotFound
	}
	if !strings.EqualFold(job.Request.Program, "THT") {
		return map[string]any{"error": "THT checkpoint resume requires a THT scan"}, http.StatusBadRequest
	}
	if job.Status != "running" || job.Done > job.Members || job.Done < 0 {
		return map[string]any{"error": "THT scan is not at a resumable checkpoint"}, http.StatusConflict
	}
	if job.Done == job.Members {
		wbMu.Lock()
		state, err = wbReadDisk()
		if err == nil {
			job = state.Jobs[jobID]
			if job.Status == "running" && job.Done == job.Members {
				wbFinalizeTHTCheckpointJob(&job)
				state.Jobs[jobID] = job
				err = wbWriteDisk(state)
			}
		}
		wbMu.Unlock()
		if err != nil {
			return map[string]any{"error": err.Error()}, http.StatusInternalServerError
		}
		return map[string]any{"id": jobID, "status": job.Status, "stage": job.Stage, "processed_members": 0, "remaining_members": 0, "classification": wbClassifyRows(job.Rows), "side_effects": map[string]any{"membership_scan": false, "new_task": false, "case": false, "notification": false}}, http.StatusOK
	}
	config, err := loadWBConfig()
	if err != nil {
		return map[string]any{"error": err.Error()}, http.StatusServiceUnavailable
	}
	audit := &wbMembershipAudit{}
	ctx := context.WithValue(request.Context(), wbMembershipAuditContextKey{}, audit)
	queryRequest := request.Clone(ctx)
	members, complete, err := wbLoadMembers(ctx, queryRequest, job.Request, config)
	if err != nil {
		return map[string]any{"error": "reload THT membership: " + err.Error()}, http.StatusBadGateway
	}
	if len(members) != job.Members {
		return map[string]any{"error": fmt.Sprintf("THT membership changed since checkpoint: persisted=%d current=%d", job.Members, len(members))}, http.StatusConflict
	}
	completedIDs := map[string]bool{}
	for _, row := range job.Rows {
		completedIDs[strings.TrimSpace(row.Member.AdvertiserID)] = true
	}
	for _, member := range members[:job.Done] {
		if !completedIDs[strings.TrimSpace(member.AdvertiserID)] {
			return map[string]any{"error": "persisted checkpoint is not a continuous membership prefix"}, http.StatusConflict
		}
	}
	remainingBefore := len(members) - job.Done
	if remainingBefore == 0 {
		return map[string]any{"id": jobID, "status": job.Status, "stage": job.Stage, "processed_members": 0, "remaining_members": 0, "classification": wbClassifyRows(job.Rows), "side_effects": map[string]any{"membership_scan": false, "new_task": false, "case": false, "notification": false}}, http.StatusOK
	}
	// Only metadata is needed while querying the next shard. Do not retain the
	// full persisted state and checkpoint rows across multiple VQS responses.
	job.Rows = nil
	state = wbDisk{}
	runtime.GC()
	limit := remainingBefore
	if maxChunks > 0 && maxChunks*wbTHTResumeSliceSize < limit {
		limit = maxChunks * wbTHTResumeSliceSize
	}
	chunkMembers := append([]wbMember(nil), members[job.Done:job.Done+limit]...)
	ids := make([]string, 0, len(chunkMembers))
	for _, member := range chunkMembers {
		ids = append(ids, member.AdvertiserID)
	}
	metrics, err := wbQueryTHTBatch(ctx, queryRequest, ids, job.Request.Start, job.Request.End)
	if err != nil {
		return map[string]any{"error": err.Error(), "processed_members": 0, "remaining_members": remainingBefore}, http.StatusBadGateway
	}
	freshRows, err := wbRowsFromTHTBatch(chunkMembers, metrics, job.Request, job.Rule)
	if err != nil {
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	// The governed VQS response can be much larger than this checkpoint. Release it
	// before loading two protection-relative windows so the resumable path stays
	// below the service cgroup limit.
	metrics = nil
	runtime.GC()
	freshRows = wbApplyRealComparisons(ctx, queryRequest, freshRows, time.Now())
	for i := range freshRows {
		freshRows[i].Message = wbMessage(freshRows[i], job.Request, job.Rule)
	}

	saveStarted := time.Now()
	wbMu.Lock()
	state, err = wbReadDisk()
	if err == nil {
		job = state.Jobs[jobID]
		if job.Done+limit > job.Members {
			err = errors.New("checkpoint advanced concurrently")
		} else {
			job.Rows = append(job.Rows, freshRows...)
			job.Done += limit
			job.AsOf = time.Now().UTC().Format(time.RFC3339)
			job.Complete = complete
			job.Stage = fmt.Sprintf("tht_checkpoint:%d/%d", job.Done, job.Members)
			job.Matched = 0
			for _, row := range job.Rows {
				if wbMatched(row) {
					job.Matched++
				}
			}
			if job.Done == job.Members {
				wbFinalizeTHTCheckpointJob(&job)
			} else {
				funnel := wbBuildProgramFunnel(job)
				job.Funnel = &funnel
			}
			state.Jobs[jobID] = job
			err = wbWriteDisk(state)
		}
	}
	wbMu.Unlock()
	saveDuration := time.Since(saveStarted)
	if err != nil {
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	comparisonGroups := map[string]bool{}
	for _, row := range freshRows {
		if source := row.Comparison.Source; asString(source["query_status"]) == "success" || asString(source["query_status"]) == metricSourceNull {
			comparisonGroups[row.Comparison.PreStart+"|"+row.Comparison.PostStart] = true
		}
	}
	actualQueries := 4 + 2*len(comparisonGroups) // membership + current CCR/NFS + Revenue + Reasons + eligible Pre/Post groups
	remaining := job.Members - job.Done
	logMsg(fmt.Sprintf("[tht-checkpoint-resume] scan_id=%s processed_members=%d rows=%d done=%d remaining=%d aeolus_queries=%d save_ms=%d total_ms=%d", jobID, limit, len(freshRows), job.Done, remaining, actualQueries, saveDuration.Milliseconds(), time.Since(started).Milliseconds()), "plugin")
	return map[string]any{
		"id": jobID, "batch_id": job.BatchID, "status": job.Status, "stage": job.Stage,
		"checkpoint_before": job.Done - limit, "checkpoint_after": job.Done,
		"processed_members": limit, "persisted_rows": len(freshRows), "remaining_members": remaining,
		"classification": wbClassifyRows(freshRows), "all_classification": wbClassifyRows(job.Rows),
		"actual_aeolus_queries": actualQueries, "save_duration_ms": saveDuration.Milliseconds(), "duration_ms": time.Since(started).Milliseconds(),
		"membership":   map[string]any{"raw_rows": audit.RawRows, "business_rows": audit.BusinessRows, "complete": complete, "filters": []string{"type_name=Protection program", "protection_program_name=Temporary High Trust (THT) - Advertiser ID", "trim(final_result)=APPROVE"}},
		"side_effects": map[string]any{"membership_scan": true, "new_task": false, "pre_post_revenue": false, "case": false, "notification": false},
	}, http.StatusOK
}

func wbResumeMissingCurrent(request *http.Request, jobID string, maxChunks int, includeEnrichment bool) (map[string]any, int) {
	if maxChunks < 0 {
		return map[string]any{"error": "max_chunks must be >= 0"}, http.StatusBadRequest
	}
	wbMu.Lock()
	state, err := wbReadDisk()
	if err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	job, ok := state.Jobs[jobID]
	if !ok {
		wbMu.Unlock()
		return map[string]any{"error": "scan not found"}, http.StatusNotFound
	}
	if !strings.EqualFold(job.Request.Program, "ET") {
		wbMu.Unlock()
		return map[string]any{"error": "resume-missing is ET-only"}, http.StatusBadRequest
	}
	mergedSnapshots, err := wbMergeSnapshotFacts(&state, job)
	if err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	job = state.Jobs[jobID]
	before := wbClassifyRows(job.Rows)
	targets := make([]wbMember, 0)
	for _, row := range job.Rows {
		if wbNeedsCurrentRepair(row) {
			targets = append(targets, row.Member)
		}
	}
	sort.SliceStable(targets, func(i, j int) bool { return targets[i].AccountID < targets[j].AccountID })
	limit := len(targets)
	if maxChunks > 0 && maxChunks*wbETMetricChunkSize < limit {
		limit = maxChunks * wbETMetricChunkSize
	}
	targets = targets[:limit]
	job.Stage = fmt.Sprintf("repairing_current:%d/%d", 0, len(targets))
	state.Jobs[jobID] = job
	if err := wbWriteDisk(state); err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	wbMu.Unlock()

	pairProcessed, pairRemaining, pairErr := wbResumeAdvertiserCurrent(request, jobID, maxChunks)
	if pairErr != nil {
		return map[string]any{"error": pairErr.Error(), "processed": 0, "advertiser_current_processed": pairProcessed, "advertiser_current_remaining": pairRemaining}, http.StatusBadGateway
	}

	processed := 0
	for start := 0; start < len(targets); start += wbETMetricChunkSize {
		end := start + wbETMetricChunkSize
		if end > len(targets) {
			end = len(targets)
		}
		chunk := targets[start:end]
		ids := make([]string, 0, len(chunk))
		for _, member := range chunk {
			ids = append(ids, member.AccountID)
		}
		metrics, queryErr := wbQueryETBatch(request.Context(), request, ids, job.Request.Start, job.Request.End)
		if queryErr != nil {
			return map[string]any{"error": queryErr.Error(), "processed": processed, "remaining": len(targets) - processed}, http.StatusBadGateway
		}
		freshRows, rowsErr := wbRowsFromETBatch(chunk, metrics, job.Request, job.Rule)
		if rowsErr != nil {
			return map[string]any{"error": rowsErr.Error(), "processed": processed, "remaining": len(targets) - processed}, http.StatusInternalServerError
		}
		freshByKey := map[string]wbRow{}
		for _, row := range freshRows {
			freshByKey[wbFunnelRowKey("ET", row)] = row
		}
		wbMu.Lock()
		state, err = wbReadDisk()
		if err == nil {
			job = state.Jobs[jobID]
			for i, row := range job.Rows {
				if fresh, exists := freshByKey[wbFunnelRowKey("ET", row)]; exists {
					job.Rows[i] = wbMergeRowBestFacts(fresh, row)
				}
			}
			processed += len(chunk)
			job.Stage = fmt.Sprintf("repairing_current:%d/%d", processed, len(targets))
			state.Jobs[jobID] = job
			err = wbWriteDisk(state)
		}
		wbMu.Unlock()
		if err != nil {
			return map[string]any{"error": err.Error(), "processed": processed}, http.StatusInternalServerError
		}
	}

	enrichmentProcessed := 0
	if includeEnrichment {
		wbMu.Lock()
		state, err = wbReadDisk()
		if err == nil {
			job = state.Jobs[jobID]
		}
		wbMu.Unlock()
		if err != nil {
			return map[string]any{"error": err.Error(), "processed": processed}, http.StatusInternalServerError
		}
		enrichmentMembers := make([]wbMember, 0)
		for _, row := range job.Rows {
			if strings.TrimSpace(row.AggregationNote) == "" {
				enrichmentMembers = append(enrichmentMembers, row.Member)
			}
		}
		sort.SliceStable(enrichmentMembers, func(i, j int) bool { return enrichmentMembers[i].AccountID < enrichmentMembers[j].AccountID })
		if maxChunks > 0 && maxChunks*wbResumeEnrichmentChunkSize < len(enrichmentMembers) {
			enrichmentMembers = enrichmentMembers[:maxChunks*wbResumeEnrichmentChunkSize]
		}
		if len(enrichmentMembers) > 0 {
			evidence, evidenceErr := wbQueryPairEvidence(request.Context(), request, enrichmentMembers, job.Request, job.Rule)
			if evidenceErr != nil {
				return map[string]any{"error": evidenceErr.Error(), "processed": processed, "enrichment_processed": 0}, http.StatusBadGateway
			}
			freshRows := make([]wbRow, 0, len(enrichmentMembers))
			wanted := map[string]bool{}
			for _, member := range enrichmentMembers {
				wanted[member.AccountID] = true
			}
			for _, row := range job.Rows {
				if wanted[row.Member.AccountID] {
					freshRows = append(freshRows, row)
				}
			}
			freshRows = applyPairEvidence(freshRows, evidence, job.Request, job.Rule)
			freshByKey := map[string]wbRow{}
			for _, row := range freshRows {
				freshByKey[wbFunnelRowKey("ET", row)] = row
			}
			wbMu.Lock()
			state, err = wbReadDisk()
			if err == nil {
				job = state.Jobs[jobID]
				for i, row := range job.Rows {
					if fresh, exists := freshByKey[wbFunnelRowKey("ET", row)]; exists {
						job.Rows[i] = wbMergeRowBestFacts(fresh, row)
					}
				}
				enrichmentProcessed = len(enrichmentMembers)
				job.Stage = fmt.Sprintf("enrichment_repaired:%d", enrichmentProcessed)
				state.Jobs[jobID] = job
				err = wbWriteDisk(state)
			}
			wbMu.Unlock()
			if err != nil {
				return map[string]any{"error": err.Error(), "processed": processed, "enrichment_processed": enrichmentProcessed}, http.StatusInternalServerError
			}
		}
	}

	wbMu.Lock()
	state, err = wbReadDisk()
	if err == nil {
		job = state.Jobs[jobID]
		remaining := 0
		for _, row := range job.Rows {
			if wbNeedsCurrentRepair(row) {
				remaining++
			}
		}
		job.Done = len(job.Rows) - remaining
		if remaining == 0 && enrichmentProcessed == 0 && pairRemaining == 0 {
			job.Stage = "advertiser_current_repaired"
		} else if remaining == 0 && enrichmentProcessed > 0 {
			job.Stage = fmt.Sprintf("enrichment_repaired:%d", enrichmentProcessed)
		}
		state.Jobs[jobID] = job
		err = wbWriteDisk(state)
	}
	wbMu.Unlock()
	if err != nil {
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	after := wbClassifyRows(job.Rows)
	remaining := 0
	for _, row := range job.Rows {
		if wbNeedsCurrentRepair(row) {
			remaining++
		}
	}
	logMsg(fmt.Sprintf("[resume-missing] scan_id=%s merged_snapshots=%d processed=%d remaining=%d advertiser_current_processed=%d advertiser_current_remaining=%d", jobID, mergedSnapshots, processed, remaining, pairProcessed, pairRemaining), "plugin")
	return map[string]any{"id": jobID, "status": job.Status, "stage": job.Stage, "processed": processed, "remaining": remaining, "advertiser_current_processed": pairProcessed, "advertiser_current_remaining": pairRemaining, "enrichment_processed": enrichmentProcessed, "merged_snapshot_rows": mergedSnapshots, "classification_before": before, "classification": after, "pair_classification": wbClassifyPairFields(job.Rows), "side_effects": map[string]any{"membership_scan": false, "new_task": false, "account_query": processed > 0, "pre_post_revenue": false, "case": false, "notification": false}}, http.StatusOK
}

const wbSTResumeSliceSize = 10

func wbResumeSTCheckpoint(request *http.Request, jobID string, maxChunks int) (map[string]any, int) {
	if maxChunks < 0 {
		return map[string]any{"error": "max_chunks must be >= 0"}, http.StatusBadRequest
	}
	started := time.Now()
	wbMu.Lock()
	state, err := wbReadDisk()
	if err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	job, ok := state.Jobs[jobID]
	wbMu.Unlock()
	if !ok {
		return map[string]any{"error": "scan not found"}, http.StatusNotFound
	}
	if !strings.EqualFold(job.Request.Program, "THT") || job.Done != job.Members {
		return map[string]any{"error": "ST continuation requires the completed THT checkpoint job"}, http.StatusConflict
	}
	q := job.Request
	q.Program = "ST"
	members, complete, err := loadSTMembers(q)
	if err != nil {
		return map[string]any{"error": "load approved ST membership: " + err.Error()}, http.StatusBadGateway
	}
	existing := 0
	for _, row := range job.Rows {
		if strings.EqualFold(row.Program, "ST") {
			existing++
		}
	}
	if job.STDone == 0 && existing > 0 {
		job.STDone = existing
	}
	if job.STDone != existing || job.STDone > len(members) {
		return map[string]any{"error": fmt.Sprintf("ST checkpoint mismatch: persisted=%d rows=%d membership=%d", job.STDone, existing, len(members))}, http.StatusConflict
	}
	completed := map[string]bool{}
	for _, row := range job.Rows {
		if strings.EqualFold(row.Program, "ST") {
			completed[row.Member.Quarter+"|"+row.Member.AccountID] = true
		}
	}
	for _, member := range members[:job.STDone] {
		if !completed[member.Quarter+"|"+member.AccountID] {
			return map[string]any{"error": "persisted ST checkpoint is not a continuous approved-membership prefix"}, http.StatusConflict
		}
	}
	remainingBefore := len(members) - job.STDone
	if remainingBefore == 0 {
		return map[string]any{"id": jobID, "batch_id": job.BatchID, "status": job.Status, "stage": job.Stage, "st_checkpoint_before": job.STDone, "st_checkpoint_after": job.STDone, "processed_members": 0, "remaining_members": 0, "side_effects": map[string]any{"new_task": false, "new_event": false, "case": false, "notification": false}}, http.StatusOK
	}
	limit := remainingBefore
	if maxChunks > 0 && maxChunks*wbSTResumeSliceSize < limit {
		limit = maxChunks * wbSTResumeSliceSize
	}
	chunkMembers := append([]wbMember(nil), members[job.STDone:job.STDone+limit]...)
	ids := make([]string, 0, len(chunkMembers))
	for _, member := range chunkMembers {
		ids = append(ids, member.AccountID)
	}
	metrics, err := wbQuerySTBatch(request.Context(), request, ids, q.Start, q.End)
	if err != nil {
		return map[string]any{"error": err.Error(), "processed_members": 0, "remaining_members": remainingBefore}, http.StatusBadGateway
	}
	freshRows, err := wbRowsFromETBatch(chunkMembers, metrics, q, job.Rule)
	if err != nil {
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	pairEvidence, err := wbQueryPairEvidence(request.Context(), request, chunkMembers, q, job.Rule)
	if err != nil {
		return map[string]any{"error": "ST advertiser evidence: " + err.Error()}, http.StatusBadGateway
	}
	freshRows = applyPairEvidence(freshRows, pairEvidence, q, job.Rule)
	freshRows = wbApplyRealComparisons(request.Context(), request, freshRows, time.Now())
	for i := range freshRows {
		freshRows[i].Message = wbMessage(freshRows[i], q, job.Rule)
	}
	comparisonGroups := map[string]bool{}
	for _, row := range freshRows {
		comparisonGroups[row.Comparison.PreStart+"|"+row.Comparison.PostStart] = true
	}
	saveStarted := time.Now()
	wbMu.Lock()
	state, err = wbReadDisk()
	if err == nil {
		job = state.Jobs[jobID]
		if job.STDone != existing {
			err = errors.New("ST checkpoint advanced concurrently")
		} else {
			job.Rows = append(job.Rows, freshRows...)
			job.STMembers = len(members)
			job.STDone += limit
			job.AsOf = time.Now().UTC().Format(time.RFC3339)
			job.Stage = fmt.Sprintf("st_checkpoint:%d/%d", job.STDone, job.STMembers)
			job.Status = "partial"
			state.Jobs[jobID] = job
			err = wbWriteDisk(state)
		}
	}
	wbMu.Unlock()
	saveDuration := time.Since(saveStarted)
	if err != nil {
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	actualQueries := 2 + 6 + 2*len(comparisonGroups)
	remaining := job.STMembers - job.STDone
	logMsg(fmt.Sprintf("[st-checkpoint-resume] scan_id=%s processed_members=%d done=%d remaining=%d aeolus_queries=%d save_ms=%d total_ms=%d", jobID, limit, job.STDone, remaining, actualQueries, saveDuration.Milliseconds(), time.Since(started).Milliseconds()), "plugin")
	return map[string]any{
		"id": jobID, "batch_id": job.BatchID, "status": job.Status, "stage": job.Stage,
		"st_checkpoint_before": job.STDone - limit, "st_checkpoint_after": job.STDone, "st_member_count": job.STMembers,
		"processed_members": limit, "persisted_rows": len(freshRows), "remaining_members": remaining,
		"classification": wbClassifyRows(freshRows), "pair_classification": wbClassifyPairFields(freshRows),
		"actual_aeolus_queries": actualQueries, "save_duration_ms": saveDuration.Milliseconds(), "duration_ms": time.Since(started).Milliseconds(),
		"membership":   map[string]any{"approved_rows": len(members), "complete": complete, "sheet": stApprovedSheetName, "filter": "Approved ST Clients list; dedupe Account ID; Newly added=Q4, retained=Q3"},
		"side_effects": map[string]any{"membership_scan": false, "new_task": false, "new_event": false, "pre_post_revenue": false, "case": false, "notification": false},
	}, http.StatusOK
}

func wbResumeMissingHandler(w http.ResponseWriter, r *http.Request) {
	input := wbResumeMissingInput{MaxChunks: 1}
	if r.Body != nil {
		decoder := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20))
		if err := decoder.Decode(&input); err != nil && !errors.Is(err, io.EOF) {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": "invalid JSON body"})
			return
		}
	}
	var data map[string]any
	var status int
	if input.RetryAllowlistFailed {
		data, status = wbRetryFailedAllowlist(r, r.PathValue("id"), input.MaxChunks)
	} else if strings.EqualFold(strings.TrimSpace(input.ResumeProgram), wbGapRepairProgram) {
		data, status = wbResumeGapRepair(r, r.PathValue("id"), input.MaxChunks)
	} else if value := strings.ToUpper(strings.TrimSpace(input.ResumeProgram)); strings.HasPrefix(value, "ADVERTISER_CURRENT_") {
		data, status = wbResumeAdvertiserCurrentOnly(r, r.PathValue("id"), input.MaxChunks, strings.TrimPrefix(value, "ADVERTISER_CURRENT_"))
	} else if strings.EqualFold(strings.TrimSpace(input.ResumeProgram), "ST") {
		data, status = wbResumeSTCheckpoint(r, r.PathValue("id"), input.MaxChunks)
	} else {
		wbMu.Lock()
		state, readErr := wbReadDisk()
		job, found := state.Jobs[r.PathValue("id")]
		wbMu.Unlock()
		if readErr != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]any{"error": readErr.Error()})
			return
		}
		if !found {
			writeJSON(w, http.StatusNotFound, map[string]any{"error": "scan not found"})
			return
		}
		if strings.EqualFold(job.Request.Program, "THT") {
			data, status = wbResumeTHTCheckpoint(r, r.PathValue("id"), input.MaxChunks)
		} else {
			data, status = wbResumeMissingCurrent(r, r.PathValue("id"), input.MaxChunks, input.IncludeEnrichment)
		}
	}
	if status >= 400 {
		writeJSON(w, status, data)
		return
	}
	writeJSON(w, status, map[string]any{"data": data})
}
