// handler_submissions.go — submissions 资源的业务逻辑。
// 路由契约在 handler_submissions.gen.go（由 IDL 生成，勿改）；此文件由你填实现。
//
// stub 目前直接返回 IDL 里的 response，让契约先跑通；
// Agent B 请用真实 store 读写替换每个 handler 内部。
package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"
)

// submissionsList 处理 GET /api/submissions：查询最近成功快照中的提报数据
func submissionsList(w http.ResponseWriter, r *http.Request) {
	// TODO(Agent B): 替换为真实业务逻辑（读写 store、校验参数等）。
	writeJSON(w, http.StatusOK, map[string]any{
		"data":   []any{},
		"total":  0,
		"status": "unavailable",
		"reason": "pending source",
	})
}

// submissionsStatusList 处理 GET /api/submissions/status：查询提报数据质量与快照状态
func submissionsStatusList(w http.ResponseWriter, r *http.Request) {
	// TODO(Agent B): 替换为真实业务逻辑（读写 store、校验参数等）。
	writeJSON(w, http.StatusOK, map[string]any{
		"data": map[string]any{
			"status": "unavailable",
			"reason": "pending source",
		},
	})
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// submissionsQuotaList 处理 GET /api/submissions/quota：按季度和时间窗聚合 ET、THT、ST 提报及 Quota 使用率
func submissionQuotaData(r *http.Request) (map[string]any, int, error) {
	window, windowErr := resolveQuotaWindow(r.URL.Query(), time.Now())
	if windowErr != nil {
		return nil, http.StatusBadRequest, windowErr
	}
	quarter, start, end := window.Quarter, window.Start, window.End
	baseline, err := loadQuotaBaseline()
	if err != nil {
		logMsg("[submissionsQuota] quota baseline failed: "+err.Error(), "plugin")
		return nil, http.StatusInternalServerError, err
	}
	result := loadQuotaSources(r.Context(), r, quarter, start, end)
	program := strings.ToUpper(strings.TrimSpace(r.URL.Query().Get("program")))
	if program != "" && program != "ALL" && program != "ET" && program != "THT" && program != "ST" {
		return nil, http.StatusUnprocessableEntity, fmt.Errorf("program must be ET, THT or ST")
	}
	if program == "ET" {
		result.THT, result.ST = nil, nil
	} else if program == "THT" {
		result.ET, result.ST = nil, nil
	} else if program == "ST" {
		result.ET, result.THT = nil, nil
	}
	if result.Error != "" {
		logMsg("[submissionsQuota] "+result.Error, "plugin")
	}
	data := aggregateQuota(baseline, result, quarter)
	data["time"], data["side_effects"] = window, false
	cwDecorateQuotaRegionalPOCs(r.Context(), data)
	if r.URL.Query().Get("submitter") != "" || r.URL.Query().Get("advertiser_id") != "" {
		data["denominator_status"], data["denominator_reason"] = "not_applicable", "Quota denominator is not defined for submitter/advertiser filtered scope"
		if group, ok := data["global"].(map[string]any); ok {
			for _, p := range []string{"et", "st"} {
				if metric, ok := group[p].(map[string]any); ok {
					metric["quota"], metric["ratio"], metric["status"] = nil, nil, "not_applicable"
				}
			}
		}
		if regions, ok := data["regions"].([]map[string]any); ok {
			for _, region := range regions {
				for _, p := range []string{"et", "st"} {
					if metric, ok := region[p].(map[string]any); ok {
						metric["quota"], metric["ratio"], metric["status"] = nil, nil, "not_applicable"
					}
				}
			}
		}
	}
	return data, http.StatusOK, nil
}

func submissionsQuotaList(w http.ResponseWriter, r *http.Request) {
	data, status, err := submissionQuotaData(r)
	if err != nil {
		writeJSON(w, status, map[string]any{"error": err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"data": data})
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// submissionsStSnapshotsCreate 处理 POST /api/submissions/st-snapshots：使用当前用户 JWT 读取 ST 权威 Sheet，或保存由同一用户会话预读的权威快照。
func submissionsStSnapshotsCreate(w http.ResponseWriter, r *http.Request) {
	actor := currentUsername(r.Context())
	var input struct {
		Snapshots []stQuarterSnapshot `json:"snapshots"`
	}
	if r.Body != nil {
		if err := json.NewDecoder(r.Body).Decode(&input); err != nil && err.Error() != "EOF" {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": "invalid snapshot body: " + err.Error()})
			return
		}
	}
	var state stSnapshotState
	var err error
	if len(input.Snapshots) > 0 {
		state, err = saveSTSnapshots(input.Snapshots, actor)
	} else {
		state, err = syncSTSnapshotsFromLark(r.Context(), actor)
	}
	if err != nil {
		logMsg("[st-snapshot] user-context sync failed: "+err.Error(), "plugin")
		writeJSON(w, http.StatusBadGateway, map[string]any{"error": err.Error(), "data": map[string]any{"status": "failed", "snapshots": stSnapshotSummaries(state), "last_attempt": state.LastAttempt}})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"data": map[string]any{"status": "success", "snapshots": stSnapshotSummaries(state), "last_attempt": state.LastAttempt}})
}
