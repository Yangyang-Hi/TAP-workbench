package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

type wbRule struct {
	RiskPolicy        string  `json:"risk_policy,omitempty"`
	Enabled           bool    `json:"enabled"`
	BusinessConfirmed bool    `json:"business_confirmed"`
	Version           string  `json:"version"`
	WatchCCR          float64 `json:"watch_ccr_gte"`
	WatchNFS          float64 `json:"watch_nfs_gt"`
	CriticalCCR       float64 `json:"critical_ccr_gt"`
	CCRUnit           string  `json:"ccr_unit"`
}
type wbWeeklySchedulerConfig struct {
	Enabled           bool `json:"enabled"`
	Weekday           int  `json:"weekday"`
	Hour              int  `json:"hour"`
	Minute            int  `json:"minute"`
	DataReadyDelayMin int  `json:"data_ready_delay_minutes"`
	AutoSendEnabled   bool `json:"auto_send_enabled"`
}

type wbConfig struct {
	Version                     int                     `json:"version"`
	Timezone                    string                  `json:"timezone"`
	WeeklyScheduler             wbWeeklySchedulerConfig `json:"weekly_scheduler"`
	MembershipSource            string                  `json:"membership_source"`
	MembershipCompleteConfirmed bool                    `json:"membership_complete_confirmed"`
	MembershipMode              string                  `json:"membership_mode"`
	Concurrency                 int                     `json:"concurrency"`
	MaxClients                  int                     `json:"max_clients_per_scan"`
	ScanTimeout                 int                     `json:"scan_timeout_seconds"`
	ValidationIDs               []string                `json:"validation_account_ids"`
	Rules                       map[string]wbRule       `json:"rules"`
}
type wbRequest struct {
	Program     string `json:"program"`
	Region      string `json:"region"`
	Start       string `json:"start_date"`
	End         string `json:"end_date"`
	MemberStart string `json:"member_start_date"`
	MemberEnd   string `json:"member_end_date"`
	Force       bool   `json:"force"`
}
type wbTicket struct {
	TicketID                 string `json:"ticket_id"`
	AccountID                string `json:"account_id,omitempty"`
	AdvertiserID             string `json:"advertiser_id,omitempty"`
	Submitter                string `json:"submitter,omitempty"`
	Region                   string `json:"region,omitempty"`
	FinalResult              string `json:"final_result,omitempty"`
	Status                   string `json:"status,omitempty"`
	TypeName                 string `json:"type_name,omitempty"`
	CreateDate               string `json:"create_date,omitempty"`
	Start                    string `json:"protection_starttime,omitempty"`
	End                      string `json:"protection_endtime,omitempty"`
	ProtectionProgramName    string `json:"protection_program_name,omitempty"`
	ProtectionBusinessline   string `json:"protection_businessline,omitempty"`
	ProtectionEstimatedSpend string `json:"protection_estimated_spend,omitempty"`
}

type wbMember struct {
	AccountID                string     `json:"account_id"`
	AdvertiserID             string     `json:"advertiser_id"`
	Name                     string     `json:"account_name"`
	BrandName                string     `json:"brand_name,omitempty"`
	AdvertiserName           string     `json:"advertiser_name,omitempty"`
	Region                   string     `json:"region"`
	Submitter                string     `json:"submitter"`
	TicketID                 string     `json:"ticket_id"`
	Start                    string     `json:"protection_starttime"`
	End                      string     `json:"protection_endtime"`
	CreateDate               string     `json:"create_date"`
	Quarter                  string     `json:"quarter,omitempty"`
	EndorsementReason        string     `json:"endorsement_reason,omitempty"`
	ProtectionProgramName    string     `json:"protection_program_name,omitempty"`
	ProtectionBusinessline   string     `json:"protection_businessline,omitempty"`
	ProtectionEstimatedSpend string     `json:"protection_estimated_spend,omitempty"`
	ProtectionStatus         string     `json:"protection_status,omitempty"`
	Tier                     string     `json:"tier"`
	MetadataStatus           string     `json:"metadata_status"`
	LinkedAccountIDs         []string   `json:"linked_account_ids"`
	LinkedAdvertiserIDs      []string   `json:"linked_advertiser_ids"`
	Submitters               []string   `json:"submitters"`
	Tickets                  []wbTicket `json:"tickets"`
	MissingFields            []string   `json:"missing_fields"`
}
type wbRow struct {
	ID               string                 `json:"id"`
	Program          string                 `json:"program"`
	Member           wbMember               `json:"member"`
	CCR              *float64               `json:"ccr"`
	NFS              *float64               `json:"nfs"`
	Revenue          *float64               `json:"revenue"`
	Comparison       wbComparison           `json:"comparison"`
	AccountCCRStatus string                 `json:"account_ccr_status,omitempty"`
	AggregationNote  string                 `json:"aggregation_note,omitempty"`
	AdvertiserCount  int                    `json:"advertiser_count"`
	AdvertiserTop10  []wbAdvertiserEvidence `json:"advertiser_top10"`
	Advertisers      []wbAdvertiserEvidence `json:"advertisers"`
	MetricStatus     string                 `json:"metric_status"`
	Level            string                 `json:"level"`
	Reasons          []string               `json:"reasons"`
	AllowlistStatus  string                 `json:"allowlist_status"`
	DataStatus       string                 `json:"data_status"`
	Error            string                 `json:"error,omitempty"`
	Source           any                    `json:"source"`
	QueriedAt        string                 `json:"queried_at"`
	RequestID        string                 `json:"request_id,omitempty"`
	Message          string                 `json:"message"`
	RecipientStatus  string                 `json:"recipient_status"`
}
type wbJob struct {
	ID                     string           `json:"id"`
	BatchID                string           `json:"batch_id"`
	AsOf                   string           `json:"as_of"`
	RuleVersion            string           `json:"rule_version"`
	Principal              string           `json:"principal"`
	ScopeKey               string           `json:"scope_key"`
	Request                wbRequest        `json:"request"`
	Rule                   wbRule           `json:"rule"`
	Policy                 wbResolvedPolicy `json:"policy,omitempty"`
	Status                 string           `json:"status"`
	Stage                  string           `json:"stage"`
	StartedAt              string           `json:"started_at"`
	FinishedAt             string           `json:"finished_at"`
	Members                int              `json:"member_count"`
	STMembers              int              `json:"st_member_count,omitempty"`
	MembershipRawRows      *int             `json:"membership_raw_rows,omitempty"`
	MembershipBusinessRows *int             `json:"membership_business_rows,omitempty"`
	Funnel                 *wbProgramFunnel `json:"funnel,omitempty"`
	Done                   int              `json:"done"`
	STDone                 int              `json:"st_done,omitempty"`
	Rows                   []wbRow          `json:"rows"`
	Complete               bool             `json:"complete"`
	Warnings               []string         `json:"warnings"`
	Error                  string           `json:"error"`
	Matched                int              `json:"matched_total"`
	MembershipSource       string           `json:"membership_source"`
	RankBy                 string           `json:"rank_by"`
}
type wbAction struct {
	AlertID   string    `json:"alert_id"`
	ScanID    string    `json:"scan_id"`
	Principal string    `json:"principal"`
	Status    string    `json:"status"`
	Cause     string    `json:"cause"`
	Note      string    `json:"note"`
	UpdatedAt string    `json:"updated_at"`
	History   []wbEvent `json:"history"`
}
type wbEvent struct {
	Time   string `json:"time"`
	Actor  string `json:"actor"`
	Status string `json:"status"`
	Cause  string `json:"cause"`
	Note   string `json:"note"`
}
type wbDisk struct {
	Jobs    map[string]wbJob    `json:"jobs"`
	Actions map[string]wbAction `json:"actions"`
}

var wbMu sync.Mutex
var wbRunning = map[string]*wbJob{}
var wbSlots = make(chan struct{}, 2)
var wbQueryCurrent = queryETCurrent
var wbQueryTHTCurrent = queryTHTCurrent
var wbLoadMembers = liveWBMembers
var decimalID = regexp.MustCompile(`^[0-9]{16,20}$`)

func firstNonEmptySourceHost(source sourceConfig) string {
	if h := strings.TrimSpace(source.Identity.BaseURL); h != "" {
		return h
	}
	return "https://aeolus-sg.bytedance.net"
}
func loadWBConfig() (wbConfig, error) {
	var c wbConfig
	b, e := os.ReadFile(filepath.Join(pluginDir, "config", "alert_workbench.json"))
	if e != nil {
		return c, e
	}
	if e = json.Unmarshal(b, &c); e != nil {
		return c, e
	}
	if c.Concurrency < 1 || c.Concurrency > 2 || c.MaxClients < 1 || c.MaxClients > 10000 || c.ScanTimeout < 30 || c.ScanTimeout > 1800 {
		return c, errors.New("invalid workbench query budget")
	}
	if c.MembershipMode != "approved_created_window" {
		return c, errors.New("membership_mode must explicitly be approved_created_window")
	}
	if _, e = time.LoadLocation(c.Timezone); e != nil {
		return c, e
	}
	for _, r := range c.Rules {
		if math.IsNaN(r.WatchCCR) || r.WatchCCR < 0 || r.WatchNFS < 0 || r.CriticalCCR < 0 || math.IsInf(r.CriticalCCR, 0) {
			return c, errors.New("invalid thresholds")
		}
	}
	return c, nil
}
func wbDefaultRequest(c wbConfig) wbRequest {
	loc, _ := time.LoadLocation(c.Timezone)
	start, end := previousCompleteWeek(time.Now().In(loc))
	return wbRequest{Program: "ET", Region: "all", Start: start, End: end, MemberStart: "2026-01-01", MemberEnd: end}
}
func validateWBRequest(q *wbRequest) error {
	q.Program = strings.ToUpper(strings.TrimSpace(q.Program))
	if q.Program != "ET" && q.Program != "THT" && q.Program != "ST" {
		return errors.New("program must be ET, THT or ST")
	}
	if q.Region == "" {
		q.Region = "all"
	}
	for _, p := range [][2]string{{q.Start, q.End}, {q.MemberStart, q.MemberEnd}} {
		a, e := time.Parse("2006-01-02", p[0])
		if e != nil {
			return errors.New("invalid start date")
		}
		b, e := time.Parse("2006-01-02", p[1])
		if e != nil || b.Before(a) || b.Sub(a) > 366*24*time.Hour {
			return errors.New("date window must be valid and at most 367 days")
		}
	}
	return nil
}
func wbKey(v any) string {
	b, _ := json.Marshal(v)
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:])
}
func wbScope(principal string, q wbRequest, c wbConfig) string {
	q.Force = false
	return wbKey(struct {
		P       string
		Q       wbRequest
		C       wbConfig
		Sources string
	}{principal, q, c, wbSourceFingerprint()})
}
func wbSourceFingerprint() string {
	raw, err := os.ReadFile(filepath.Join(pluginDir, "config", "data_sources.yaml"))
	if err != nil {
		return "unavailable:" + err.Error()
	}
	h := sha256.Sum256(raw)
	return hex.EncodeToString(h[:])
}
func wbStatePath() (string, error) {
	d, e := resolveDataDir()
	if e != nil {
		return "", e
	}
	if e = os.MkdirAll(d, 0700); e != nil {
		return "", e
	}
	return filepath.Join(d, "tap_alert_workbench_v1.json"), nil
}
func wbReadDisk() (wbDisk, error) {
	s := wbDisk{Jobs: map[string]wbJob{}, Actions: map[string]wbAction{}}
	p, e := wbStatePath()
	if e != nil {
		return s, e
	}
	f, e := os.Open(p)
	if os.IsNotExist(e) {
		return s, nil
	}
	if e != nil {
		return s, e
	}
	defer f.Close()
	if e = json.NewDecoder(f).Decode(&s); e != nil {
		return s, fmt.Errorf("stored workbench state is invalid: %w", e)
	}
	if s.Jobs == nil {
		s.Jobs = map[string]wbJob{}
	}
	if s.Actions == nil {
		s.Actions = map[string]wbAction{}
	}
	return s, nil
}
func wbWriteDisk(s wbDisk) error {
	p, e := wbStatePath()
	if e != nil {
		return e
	}
	f, e := os.CreateTemp(filepath.Dir(p), ".tap-alert-*")
	if e != nil {
		return e
	}
	defer os.Remove(f.Name())
	if e = f.Chmod(0600); e == nil {
		e = json.NewEncoder(f).Encode(s)
	}
	if e == nil {
		e = f.Sync()
	}
	closeErr := f.Close()
	if e != nil {
		return e
	}
	if closeErr != nil {
		return closeErr
	}
	return os.Rename(f.Name(), p)
}
func cloneWBJob(j *wbJob) wbJob {
	b, _ := json.Marshal(j)
	var out wbJob
	_ = json.Unmarshal(b, &out)
	return out
}
func wbSaveJob(j *wbJob) error {
	s, e := wbReadDisk()
	if e != nil {
		return e
	}
	s.Jobs[j.ID] = cloneWBJob(j)
	ids := []string{}
	for id, v := range s.Jobs {
		if v.Principal == j.Principal {
			ids = append(ids, id)
		}
	}
	sort.Slice(ids, func(i, k int) bool { return s.Jobs[ids[i]].StartedAt > s.Jobs[ids[k]].StartedAt })
	for _, id := range ids[min(10, len(ids)):] {
		delete(s.Jobs, id)
	}
	return wbWriteDisk(s)
}

func evaluateWBAbsolute(ccr, nfs *float64, rule wbRule) (string, []string) {
	if !rule.Enabled {
		return "disabled", nil
	}
	if rule.RiskPolicy == wbGovernancePolicyVersion {
		level, reasons := wbEvaluateAbsolute(ccr, nfs, "ALL", "", "", wbDefaultPolicy())
		if level == "extreme" {
			level = "critical"
		}
		return level, reasons
	}
	if ccr == nil {
		return "unavailable", nil
	}
	if *ccr > rule.CriticalCCR {
		return "critical", []string{fmt.Sprintf("P0 CCR %.2f > %.2f", *ccr, rule.CriticalCCR)}
	}
	if nfs != nil && *ccr >= rule.WatchCCR && *nfs > rule.WatchNFS {
		return "watch", []string{fmt.Sprintf("P0 CCR %.2f >= %.2f 且 P0 NFS %.2f > %.2f", *ccr, rule.WatchCCR, *nfs, rule.WatchNFS)}
	}
	return "normal", nil
}
func wbMetric(v any) *float64 {
	if v == nil {
		return nil
	}
	var n float64
	switch t := v.(type) {
	case float64:
		n = t
	case int:
		n = float64(t)
	case json.Number:
		x, e := t.Float64()
		if e != nil {
			return nil
		}
		n = x
	default:
		return nil
	}
	if math.IsNaN(n) || math.IsInf(n, 0) || n < 0 {
		return nil
	}
	return &n
}
func wbMatched(row wbRow) bool { return row.Level == "critical" || row.Level == "watch" }
func wbOrder(rows []wbRow) {
	sort.SliceStable(rows, func(i, j int) bool {
		a, b := rows[i], rows[j]
		for _, pair := range [][2]*float64{{a.CCR, b.CCR}, {a.NFS, b.NFS}} {
			if pair[0] == nil && pair[1] == nil {
				continue
			}
			if pair[0] == nil {
				return false
			}
			if pair[1] == nil {
				return true
			}
			if *pair[0] != *pair[1] {
				return *pair[0] > *pair[1]
			}
		}
		return a.Member.AccountID < b.Member.AccountID
	})
}
func wbRevenueMessageNumber(v *float64) string {
	if v == nil {
		return "未提供"
	}
	// Revenue remains numeric in storage. Avoid exponent notation at the
	// message boundary while preserving the existing compact display for
	// ordinary values.
	compact := fmt.Sprintf("%g", *v)
	if strings.ContainsAny(compact, "eE") {
		return strconv.FormatFloat(*v, 'f', -1, 64)
	}
	return compact
}

func wbMessage(row wbRow, q wbRequest, rule wbRule) string {
	num := func(v *float64) string {
		if v == nil {
			return "未提供"
		}
		return fmt.Sprintf("%g", *v)
	}
	show := func(v string) string {
		if v == "" {
			return "未提供"
		}
		return v
	}
	isET := q.Program == "ET"
	isTHT := q.Program == "THT"
	header := fmt.Sprintf("[TAP %s 绝对值风险%s]", q.Program, map[bool]string{true: "报警", false: "观察"}[row.Level == "critical"])
	lines := []string{header}
	lines = append(lines, "接收人："+show(row.Member.Submitter))
	if !isTHT {
		lines = append(lines, "Account ID："+show(row.Member.AccountID))
	}
	if !isET {
		lines = append(lines, "Advertiser ID："+show(row.Member.AdvertiserID))
	}
	lines = append(lines, "Account Name："+show(row.Member.Name))
	lines = append(lines, "提报区域："+show(row.Member.Region))
	lines = append(lines, "提报工单："+show(row.Member.TicketID))
	lines = append(lines, "保护开始："+show(row.Member.Start))
	if !isET {
		lines = append(lines, "保护结束："+show(row.Member.End))
	}
	lines = append(lines, fmt.Sprintf("指标窗口：%s 至 %s", q.Start, q.End))
	lines = append(lines, fmt.Sprintf("P0 CCR：%s（%s）", num(row.CCR), rule.CCRUnit))
	if row.AccountCCRStatus != "" {
		lines = append(lines, "Account CCR口径："+row.AccountCCRStatus)
	}
	lines = append(lines, "P0 NFS："+num(row.NFS))
	lines = append(lines, "Revenue："+wbRevenueMessageNumber(row.Revenue))
	if len(row.AdvertiserTop10) > 0 {
		top := row.AdvertiserTop10[0]
		lines = append(lines, fmt.Sprintf("高风险 Advertiser：%s（CCR %s / NFS %s / Revenue %s）", top.AdvertiserID, num(top.CCR), num(top.NFS), wbRevenueMessageNumber(top.Revenue)))
	}
	lines = append(lines, "关联 Advertiser 数量："+fmt.Sprint(row.AdvertiserCount))
	lines = append(lines, "触发原因："+strings.Join(row.Reasons, "；"))
	lines = append(lines, fmt.Sprintf("规则版本：%s（业务确认：%t）", rule.Version, rule.BusinessConfirmed))
	lines = append(lines, "查询时间："+row.QueriedAt)
	lines = append(lines, "请核查风险，并在工作台记录归因、措施及后续复查。")
	lines = append(lines, "本页为消息预览，尚未发送外部消息。")
	return strings.Join(lines, "\n")
}

type wbMembershipFilterContract struct {
	TypeNameProven    bool   `json:"type_name_proven"`
	FinalResultProven bool   `json:"final_result_proven"`
	Supplemented      int    `json:"supplemented_rows"`
	BlockReason       string `json:"block_reason,omitempty"`
}

func exactFilterValues(value any) []string {
	values := []string{}
	switch typed := value.(type) {
	case []any:
		for _, item := range typed {
			values = append(values, strings.TrimSpace(asString(item)))
		}
	case []string:
		for _, item := range typed {
			values = append(values, strings.TrimSpace(item))
		}
	default:
		values = append(values, strings.TrimSpace(asString(value)))
	}
	return uniqueNonEmpty(values)
}

// proveETTypeNameFilterContract accepts only the exact et_account_list field
// contract from the VQS request that was actually executed. Missing, ambiguous,
// or conflicting filters remain fail-closed.
func proveETTypeNameFilterContract(sourceKey string, source sourceConfig, effective any) (bool, string) {
	if sourceKey != "et_account_list" {
		return false, "source_is_not_et_account_list"
	}
	spec, ok := source.Fields["type_name"]
	if !ok || strings.TrimSpace(spec.DimMetID) == "" {
		return false, "type_name_field_contract_missing"
	}
	encoded, err := json.Marshal(effective)
	if err != nil {
		return false, "effective_filters_invalid"
	}
	var filters []map[string]any
	if json.Unmarshal(encoded, &filters) != nil || len(filters) == 0 {
		return false, "effective_filters_missing"
	}
	matched := 0
	for _, filter := range filters {
		id := strings.TrimSpace(asString(filter["id"]))
		name := strings.TrimSpace(asString(filter["name"]))
		idMatches := id == strings.TrimSpace(spec.DimMetID) || (strings.TrimSpace(spec.UniqueID) != "" && id == strings.TrimSpace(spec.UniqueID))
		nameMatches := strings.EqualFold(name, "type_name") || strings.EqualFold(name, strings.TrimSpace(spec.SourceName))
		if nameMatches && !idMatches {
			return false, "type_name_filter_identity_conflict"
		}
		if !idMatches {
			continue
		}
		matched++
		op := strings.ToLower(strings.TrimSpace(asString(filter["op"])))
		if op != "in" && op != "eq" && op != "equal" && op != "=" {
			return false, "type_name_filter_operator_conflict"
		}
		values := exactFilterValues(filter["val"])
		if len(values) != 1 || !strings.EqualFold(values[0], "Emerging trust apply") {
			return false, "type_name_filter_value_conflict"
		}
	}
	if matched == 0 {
		return false, "type_name_filter_not_found"
	}
	return true, ""
}

func supplementETTypeNameFromContract(rows []map[string]any, proven bool) ([]map[string]any, int) {
	if !proven {
		return rows, 0
	}
	out := make([]map[string]any, 0, len(rows))
	supplemented := 0
	for _, row := range rows {
		value := strings.TrimSpace(asString(row["type_name"]))
		if value != "" && !strings.EqualFold(value, "NULL") {
			out = append(out, row)
			continue
		}
		copy := cloneMap(row)
		copy["type_name"] = "Emerging trust apply"
		out = append(out, copy)
		supplemented++
	}
	return out, supplemented
}

func proveExactMembershipFilter(source sourceConfig, semantic, expected string, effective any) bool {
	spec, ok := source.Fields[semantic]
	if !ok || strings.TrimSpace(spec.DimMetID) == "" {
		return false
	}
	encoded, err := json.Marshal(effective)
	if err != nil {
		return false
	}
	var filters []map[string]any
	if json.Unmarshal(encoded, &filters) != nil {
		return false
	}
	matched := 0
	for _, filter := range filters {
		id := strings.TrimSpace(asString(filter["id"]))
		if id != strings.TrimSpace(spec.DimMetID) && id != strings.TrimSpace(spec.UniqueID) {
			continue
		}
		matched++
		op := strings.ToLower(strings.TrimSpace(asString(filter["op"])))
		if op != "in" && op != "eq" && op != "equal" && op != "=" && op != "==" {
			return false
		}
		values := exactFilterValues(filter["val"])
		if len(values) != 1 || !strings.EqualFold(values[0], expected) {
			return false
		}
	}
	return matched == 1
}

func supplementMembershipField(rows []map[string]any, semantic, value string, proven bool) ([]map[string]any, int) {
	if !proven {
		return rows, 0
	}
	out := make([]map[string]any, 0, len(rows))
	count := 0
	for _, row := range rows {
		if current := strings.TrimSpace(asString(row[semantic])); current != "" && !strings.EqualFold(current, "NULL") {
			out = append(out, row)
			continue
		}
		copy := cloneMap(row)
		copy[semantic] = value
		out = append(out, copy)
		count++
	}
	return out, count
}

func stBatchDate(quarter, value string) string {
	value = strings.TrimSpace(value)
	if len(value) >= 10 {
		if _, err := time.Parse("2006-01-02", value[:10]); err == nil {
			return value[:10]
		}
	}
	parts := strings.FieldsFunc(value, func(r rune) bool { return r == '.' || r == '/' || r == '-' })
	if len(parts) >= 2 {
		month, day := strings.TrimLeft(parts[0], "0"), strings.TrimLeft(parts[1], "0")
		if month == "" {
			month = "0"
		}
		if day == "" {
			day = "0"
		}
		if parsed, err := time.Parse("2006-1-2", "2026-"+month+"-"+day); err == nil {
			return parsed.Format("2006-01-02")
		}
	}
	if quarter == "Q3" {
		return "2026-06-30"
	}
	return "2026-09-30"
}

func loadSTMembers(q wbRequest) ([]wbMember, bool, error) {
	state, err := readSTSnapshotState()
	if err != nil {
		return nil, false, err
	}
	members := []wbMember{}
	for _, quarter := range []string{"Q3", "Q4"} {
		snapshot, ok := state.Snapshots[quarter]
		if !ok || snapshot.SyncResult != "success" {
			continue
		}
		for _, row := range snapshot.Rows {
			if q.Region != "all" && row.SalesRegion != q.Region {
				continue
			}
			anchor := stBatchDate(quarter, row.StartDate)
			members = append(members, wbMember{AccountID: row.AccountID, Name: row.AccountName, BrandName: row.BrandName, Region: row.SalesRegion, Submitter: row.AdexSubmitter, TicketID: "ST-" + quarter + "-" + row.AccountID, Start: anchor, CreateDate: anchor, Quarter: quarter, EndorsementReason: row.EndorsementReason, Tier: "ST", MetadataStatus: "approved_list_verified", LinkedAccountIDs: []string{row.AccountID}, Submitters: uniqueNonEmpty([]string{row.AdexSubmitter})})
		}
	}
	if len(members) == 0 && len(state.Snapshots) == 0 {
		return nil, false, errors.New("ST snapshot unavailable; sync Q4/Q3 Sheet with current user first")
	}
	sort.Slice(members, func(i, j int) bool {
		if members[i].AccountID == members[j].AccountID {
			return members[i].Quarter < members[j].Quarter
		}
		return members[i].AccountID < members[j].AccountID
	})
	return members, true, nil
}

// Single authoritative source, independently queried in AIME. No legacy snapshots or demo fallback.
func liveWBMembers(ctx context.Context, r *http.Request, q wbRequest, c wbConfig) ([]wbMember, bool, error) {
	if q.Program == "ST" {
		return loadSTMembers(q)
	}
	cfg, e := loadDataSourceConfig()
	if e != nil {
		return nil, false, e
	}
	sourceKey := "et_account_list"
	if q.Program == "THT" {
		sourceKey = "tht_ticket_details"
	}
	src, ok := cfg.Sources[sourceKey]
	if !ok || !src.Enabled || src.RID == 0 {
		return nil, false, fmt.Errorf("%s membership source not configured", q.Program)
	}
	u := *r.URL
	request := r.Clone(ctx)
	request.URL = &u
	v := u.Query()
	v.Set("start_date", q.MemberStart)
	v.Set("end_date", q.MemberEnd)
	if q.Program == "ET" {
		v.Set("client_tier", "emerging_trust")
	} else {
		v.Set("program_type", q.Program)
	}
	v.Del("region")
	v.Del("client_ids")
	request.URL.RawQuery = v.Encode()
	probe, e := runTitanVQSProbe(ctx, request, sourceKey)
	if e != nil {
		return nil, false, e
	}
	contract := wbMembershipFilterContract{BlockReason: "not_applicable"}
	if q.Program == "ET" {
		contract.TypeNameProven, contract.BlockReason = proveETTypeNameFilterContract(sourceKey, src, probe["effective_filters"])
		if contract.TypeNameProven {
			contract.BlockReason = ""
		}
	} else {
		contract.FinalResultProven = proveExactMembershipFilter(src, "final_result", "APPROVE", probe["effective_filters"])
		if !contract.FinalResultProven {
			contract.BlockReason = "final_result_filter_not_proven"
		} else {
			contract.BlockReason = ""
		}
	}
	probe["membership_filter_contract"] = contract
	if q.Program == "THT" && !contract.FinalResultProven {
		return nil, false, errors.New("THT final_result=APPROVE filter contract was not proven")
	}
	rawCount, businessCount := -1, -1
	if rows, ok := probe["rows"].([]map[string]any); ok {
		rawCount = len(rows)
	}
	if value, exists := probe["business_rows"]; exists {
		var rows []map[string]any
		encoded, _ := json.Marshal(value)
		_ = json.Unmarshal(encoded, &rows)
		if rows != nil {
			if q.Program == "ET" {
				rows, contract.Supplemented = supplementETTypeNameFromContract(rows, contract.TypeNameProven)
			} else {
				rows, contract.Supplemented = supplementMembershipField(rows, "final_result", "APPROVE", contract.FinalResultProven)
			}
			probe["membership_filter_contract"] = contract
			businessCount = len(rows)
			inWindow, programMatch, approved, validID := 0, 0, 0, 0
			for _, row := range rows {
				created := asString(row["create_date"])
				if len(created) >= 10 && created[:10] >= q.MemberStart && created[:10] <= q.MemberEnd {
					inWindow++
				}
				if q.Program == "ET" && strings.EqualFold(strings.TrimSpace(asString(row["type_name"])), "Emerging trust apply") || q.Program == "THT" && strings.EqualFold(strings.TrimSpace(asString(row["type_name"])), "Protection program") && strings.EqualFold(strings.TrimSpace(asString(row["protection_program_name"])), "Temporary High Trust (THT) - Advertiser ID") {
					programMatch++
				}
				if strings.EqualFold(strings.TrimSpace(asString(row["final_result"])), "APPROVE") {
					approved++
				}
				id := asString(row["account_id"])
				if q.Program == "THT" {
					id = asString(row["advertiser_id"])
				}
				if decimalID.MatchString(strings.TrimSpace(id)) {
					validID++
				}
			}
			var sample any
			if len(rows) > 0 {
				sample = rows[0]
			}
			logMsg(fmt.Sprintf("[risk-scan] membership mapping audit program=%s rows=%d in_window=%d program_match=%d approved=%d valid_id=%d sample=%#v", q.Program, len(rows), inWindow, programMatch, approved, validID, sample), "plugin")
		}
	}
	logMsg(fmt.Sprintf("[risk-scan] membership audit program=%s source=%s rid=%d window=%s..%s status=%s raw_rows=%d business_rows=%d type_name_contract_proven=%t supplemented_rows=%d block_reason=%s request_id=%s log_id=%s pushed=%#v effective_filters=%#v", q.Program, sourceKey, src.RID, q.MemberStart, q.MemberEnd, asString(probe["status"]), rawCount, businessCount, contract.TypeNameProven, contract.Supplemented, contract.BlockReason, asString(probe["requestId"]), asString(probe["logId"]), probe["pushed_filter_dimensions"], probe["effective_filters"]), "plugin")
	if audit, ok := ctx.Value(wbMembershipAuditContextKey{}).(*wbMembershipAudit); ok {
		if rawCount >= 0 {
			audit.RawRows = intPtr(rawCount)
		}
		if businessCount >= 0 {
			audit.BusinessRows = intPtr(businessCount)
		}
	}
	if asString(probe["status"]) != "ok" {
		logMsg(fmt.Sprintf("[risk-scan] membership probe failed source=%s status=%s details=%#v", sourceKey, asString(probe["status"]), probe), "plugin")
		if step, ok := probe["query_result"].(titanProbeStep); ok && step.Status == "no_fact_row" {
			return []wbMember{}, c.MembershipCompleteConfirmed, nil
		}
		for _, stage := range []string{"titan_exchange", "aeolus_session", "chart_definition", "query_result"} {
			var step *titanProbeStep
			switch value := probe[stage].(type) {
			case titanProbeStep:
				copy := value
				step = &copy
			case *titanProbeStep:
				step = value
			}
			if step != nil && step.Status != "passed" {
				return nil, false, fmt.Errorf("membership query failed at %s: type=%s http=%d message=%s glue_message=%s log_id=%s", stage, step.ErrorType, step.HTTPStatus, step.ErrorMessage, step.GlueMessage, step.LogID)
			}
		}
		return nil, false, fmt.Errorf("membership query failed (%s); report response did not satisfy the configured field contract", asString(probe["status"]))
	}
	if truncated, _ := probe["possibly_truncated"].(bool); truncated {
		return nil, false, errors.New("membership result truncated; cannot derive a complete risk Top20")
	}
	if value, exists := probe["business_rows"]; exists {
		businessRows, ok := value.([]map[string]any)
		if !ok {
			encoded, _ := json.Marshal(value)
			_ = json.Unmarshal(encoded, &businessRows)
		}
		if businessRows != nil {
			if q.Program == "ET" {
				businessRows, _ = supplementETTypeNameFromContract(businessRows, contract.TypeNameProven)
			} else {
				businessRows, _ = supplementMembershipField(businessRows, "final_result", "APPROVE", contract.FinalResultProven)
			}
			return canonicalWBMembers(businessRows, q, c.MembershipCompleteConfirmed)
		}
	}
	raw, ok := probe["rows"].([]map[string]any)
	if !ok {
		return nil, false, errors.New("membership raw rows missing")
	}
	fieldMap, _ := probe["field_map"].(map[string]string)
	rows, e := wbExactMembershipRows(raw, src.Fields, fieldMap)
	if e != nil {
		return nil, false, e
	}
	return canonicalWBMembers(rows, q, c.MembershipCompleteConfirmed)
}

// Map exact runtime dataset field IDs or exact semantic aliases; never fuzzy match IDs/names.
func wbExactMembershipRows(raw []map[string]any, fields map[string]fieldConfig, runtime map[string]string) ([]map[string]any, error) {
	byID := map[string]string{}
	for column, descriptor := range runtime {
		var d map[string]any
		if json.Unmarshal([]byte(descriptor), &d) != nil {
			continue
		}
		id := asString(d["datasetfieldid"])
		if id == "" {
			id = asString(d["datasetFieldId"])
		}
		if id != "" {
			if previous, ok := byID[id]; ok && previous != column {
				return nil, errors.New("ambiguous membership runtime field: " + id)
			}
			byID[id] = column
		}
	}
	requiredFields := []string{"account_id", "type_name", "final_result", "create_date"}
	if _, isTHT := fields["protection_program_name"]; isTHT {
		requiredFields = []string{"type_name", "protection_program_name", "final_result", "create_date", "ticket_id", "advertiser_id"}
	}
	for _, required := range requiredFields {
		field, configured := fields[required]
		if !configured {
			return nil, errors.New("membership source missing required field contract: " + required)
		}
		column := byID[field.DimMetID]
		if column == "" {
			for _, candidate := range []string{required, field.SourceName, field.DimMetID} {
				if len(raw) > 0 {
					if _, exists := raw[0][candidate]; exists {
						column = candidate
						break
					}
				}
			}
		}
		if column == "" {
			return nil, errors.New("membership source missing required field: " + required)
		}
	}
	out := make([]map[string]any, 0, len(raw))
	for _, source := range raw {
		row := map[string]any{}
		for semantic, field := range fields {
			keys := []string{}
			if column := byID[field.DimMetID]; column != "" {
				keys = append(keys, column)
			} else {
				keys = append(keys, semantic, field.SourceName, field.DimMetID)
			}
			for _, key := range keys {
				if key == "" {
					continue
				}
				value, exists := source[key]
				if !exists {
					continue
				}
				if semantic == "account_id" || semantic == "advertiser_id" {
					if _, unsafe := value.(float64); unsafe {
						return nil, errors.New("membership ID returned as imprecise floating point number")
					}
				}
				if value != nil && !strings.EqualFold(strings.TrimSpace(asString(value)), "NULL") {
					row[semantic] = value
				}
				break
			}
		}
		out = append(out, row)
	}
	return out, nil
}

func splitDecimalIDs(value string) []string {
	value = strings.NewReplacer("[", " ", "]", " ", `"`, " ", "'", " ").Replace(value)
	parts := strings.FieldsFunc(value, func(r rune) bool { return r == ',' || r == ';' || r == '|' || r == ' ' || r == '\n' || r == '\t' })
	out := []string{}
	seen := map[string]bool{}
	for _, part := range parts {
		id := strings.TrimSpace(part)
		if decimalID.MatchString(id) && !seen[id] {
			seen[id] = true
			out = append(out, id)
		}
	}
	return out
}

func addUnique(values []string, additions ...string) []string {
	seen := map[string]bool{}
	for _, value := range values {
		if value != "" {
			seen[value] = true
		}
	}
	for _, value := range additions {
		value = strings.TrimSpace(value)
		if value != "" && !seen[value] {
			seen[value] = true
			values = append(values, value)
		}
	}
	sort.Strings(values)
	return values
}

func canonicalWBMembers(rows []map[string]any, q wbRequest, complete bool) ([]wbMember, bool, error) {
	selected := map[string]wbMember{}
	for _, raw := range rows {
		isET := q.Program == "ET"
		if isET {
			if !strings.EqualFold(strings.TrimSpace(asString(raw["type_name"])), "Emerging trust apply") || !strings.EqualFold(strings.TrimSpace(asString(raw["final_result"])), "APPROVE") {
				continue
			}
		} else if !strings.EqualFold(strings.TrimSpace(asString(raw["type_name"])), "Protection program") || !strings.EqualFold(strings.TrimSpace(asString(raw["protection_program_name"])), "Temporary High Trust (THT) - Advertiser ID") || !strings.EqualFold(strings.TrimSpace(asString(raw["final_result"])), "APPROVE") {
			continue
		}

		created := strings.TrimSpace(asString(raw["create_date"]))
		if len(created) < 10 {
			return nil, false, errors.New("membership creation time missing")
		}
		created = created[:10]
		if _, e := time.Parse("2006-01-02", created); e != nil {
			return nil, false, errors.New("membership creation date invalid")
		}
		if created < q.MemberStart || created > q.MemberEnd {
			continue
		}

		accountIDs := splitDecimalIDs(asString(raw["account_id"]))
		advertiserIDs := splitDecimalIDs(asString(raw["advertiser_id"]))
		primaryIDs := accountIDs
		if !isET {
			primaryIDs = advertiserIDs
		}
		if len(primaryIDs) == 0 {
			if isET {
				return nil, false, errors.New("ET candidate missing an exact string Account ID")
			}
			return nil, false, errors.New("approved THT member missing an exact string Advertiser ID")
		}
		ticket := wbTicket{TicketID: strings.TrimSpace(asString(raw["ticket_id"])), Submitter: strings.TrimSpace(asString(raw["submitter"])), Region: normalizeArrayScalar(asString(raw["region"])), FinalResult: strings.TrimSpace(asString(raw["final_result"])), Status: strings.TrimSpace(asString(raw["status"])), TypeName: strings.TrimSpace(asString(raw["type_name"])), CreateDate: created, Start: asString(raw["protection_starttime"]), End: asString(raw["protection_endtime"]), ProtectionProgramName: asString(raw["protection_program_name"]), ProtectionBusinessline: asString(raw["protection_businessline"]), ProtectionEstimatedSpend: asString(raw["protection_estimated_spend"])}
		if isET {
			// ET comparison anchor is the authoritative create_time field only. The
			// source contract also exposes that exact same dataset field ID/name under
			// the legacy protection_starttime alias; accept the alias when projection
			// de-duplication selected it, never a distinct protection date.
			ticket.Start = asString(raw["create_time"])
			if strings.TrimSpace(ticket.Start) == "" {
				ticket.Start = asString(raw["protection_starttime"])
			}
			ticket.End = ""
		}
		if len(accountIDs) > 0 {
			ticket.AccountID = accountIDs[0]
		}
		if len(advertiserIDs) > 0 {
			ticket.AdvertiserID = advertiserIDs[0]
		}
		if ticket.TicketID == "" && !isET {
			return nil, false, errors.New("membership ticket_id missing")
		}

		for _, id := range primaryIDs {
			m := selected[id]
			if isET {
				m.AccountID = id
				m.Tier = "Emerging trust apply"
			} else {
				m.AdvertiserID = id
				m.Tier = "THT"
			}
			m.Name = strings.TrimSpace(asString(raw["account_name"]))
			m.AdvertiserName = strings.TrimSpace(asString(raw["advertiser_name"]))
			m.LinkedAccountIDs = addUnique(m.LinkedAccountIDs, accountIDs...)
			m.LinkedAdvertiserIDs = addUnique(m.LinkedAdvertiserIDs, advertiserIDs...)
			m.Submitters = addUnique(m.Submitters, ticket.Submitter)
			duplicate := false
			for _, existing := range m.Tickets {
				sameIdentity := existing.TicketID == ticket.TicketID && existing.AdvertiserID == ticket.AdvertiserID && existing.AccountID == ticket.AccountID
				if sameIdentity && (!isET || existing.CreateDate == ticket.CreateDate && existing.Start == ticket.Start) {
					duplicate = true
					break
				}
			}
			if !duplicate {
				m.Tickets = append(m.Tickets, ticket)
			}
			if m.CreateDate == "" || created > m.CreateDate || created == m.CreateDate && ticket.TicketID > m.TicketID {
				m.Region, m.Submitter, m.TicketID, m.Start, m.End, m.CreateDate = ticket.Region, ticket.Submitter, ticket.TicketID, ticket.Start, ticket.End, created
				m.ProtectionProgramName = ticket.ProtectionProgramName
				m.ProtectionBusinessline = ticket.ProtectionBusinessline
				m.ProtectionEstimatedSpend = ticket.ProtectionEstimatedSpend
				m.ProtectionStatus = ticket.Status
			}
			m.MissingFields = nil
			if m.Region == "" {
				m.MissingFields = append(m.MissingFields, "region")
			}
			if m.Submitter == "" {
				m.MissingFields = append(m.MissingFields, "question_user_name")
			}
			if m.Name == "" {
				m.MissingFields = append(m.MissingFields, "account_name")
			}
			m.MetadataStatus = "ready"
			if len(m.MissingFields) > 0 {
				m.MetadataStatus = "partial"
			}
			selected[id] = m
		}
	}
	out := []wbMember{}
	for _, m := range selected {
		if q.Region != "all" && m.Region != q.Region {
			continue
		}
		sort.Slice(m.Tickets, func(i, j int) bool {
			if m.Tickets[i].CreateDate == m.Tickets[j].CreateDate {
				return m.Tickets[i].TicketID < m.Tickets[j].TicketID
			}
			return m.Tickets[i].CreateDate < m.Tickets[j].CreateDate
		})
		out = append(out, m)
	}
	sort.Slice(out, func(i, j int) bool {
		ai, aj := out[i].AccountID, out[j].AccountID
		if ai == "" {
			ai = out[i].AdvertiserID
		}
		if aj == "" {
			aj = out[j].AdvertiserID
		}
		return ai < aj
	})
	return out, complete, nil
}

func wbRunJob(request *http.Request, id string, c wbConfig) {
	ctx, cancel := context.WithTimeout(context.WithoutCancel(request.Context()), time.Duration(c.ScanTimeout)*time.Second)
	defer cancel()
	request = request.Clone(ctx)
	wbMu.Lock()
	job := wbRunning[id]
	q := job.Request
	wbMu.Unlock()
	audit := &wbMembershipAudit{}
	ctx = context.WithValue(ctx, wbMembershipAuditContextKey{}, audit)
	request = request.Clone(ctx)
	members, complete, e := wbLoadMembers(ctx, request, q, c)
	if e != nil {
		wbFinish(id, "blocked", e.Error())
		return
	}
	wbMu.Lock()
	job.Members = len(members)
	job.MembershipRawRows = audit.RawRows
	job.MembershipBusinessRows = audit.BusinessRows
	job.Complete = complete
	metricChunkSize := wbETMetricChunkSize
	if q.Program == "ST" {
		metricChunkSize = wbSTMetricChunkSize
	} else if q.Program == "THT" {
		metricChunkSize = wbTHTMetricChunkSize
	}
	totalMetricChunks := 0
	if len(members) > 0 {
		totalMetricChunks = (len(members) + metricChunkSize - 1) / metricChunkSize
	}
	job.Stage = fmt.Sprintf("querying_metrics:0/%d", totalMetricChunks)
	if !complete {
		job.Warnings = append(job.Warnings, fmt.Sprintf("成员来源完整性待验收：结果只代表本次返回的已验证%s候选，不宣称源报表全量", q.Program))
	}
	membershipSnapshot := cloneWBJob(job)
	// wbSaveJob is a read-modify-write operation; keep it under the same mutex
	// used by final persistence so concurrent scans cannot overwrite each other.
	persistErr := wbSaveJob(&membershipSnapshot)
	wbMu.Unlock()
	// Persist membership immediately so polling/UI shows the authoritative count
	// and completeness even if the metric phase is later blocked or fails.
	if persistErr != nil {
		wbFinish(id, "failed", "persist membership result: "+persistErr.Error())
		return
	}
	if len(members) > c.MaxClients {
		wbFinish(id, "blocked", fmt.Sprintf("%d clients exceed max_clients_per_scan=%d; increase verified scan budget; no silent truncation", len(members), c.MaxClients))
		return
	}

	if q.Program == "ET" || q.Program == "ST" || q.Program == "THT" {
		var rows []wbRow
		var requestCount int
		var err error
		progress := func(processed, completedChunks, totalChunks int, checkpointRows []wbRow) {
			wbMu.Lock()
			defer wbMu.Unlock()
			if running := wbRunning[id]; running != nil && running.Status == "running" {
				running.Done = processed
				running.Rows = append([]wbRow(nil), checkpointRows...)
				running.Matched = 0
				for _, row := range running.Rows {
					if wbMatched(row) {
						running.Matched++
					}
				}
				running.Stage = fmt.Sprintf("querying_metrics:%d/%d", completedChunks, totalChunks)
				running.AsOf = time.Now().UTC().Format(time.RFC3339)
				if persistErr := wbSaveJob(running); persistErr != nil {
					warning := "批次进度持久化失败：" + persistErr.Error()
					if len(running.Warnings) == 0 || running.Warnings[len(running.Warnings)-1] != warning {
						running.Warnings = append(running.Warnings, warning)
					}
				}
			}
		}
		switch q.Program {
		case "ST":
			rows, requestCount, err = wbRunSTBatchesWithProgress(ctx, request, members, q, job.Rule, progress)
		case "THT":
			rows, requestCount, err = wbRunTHTBatchesWithProgress(ctx, request, members, q, job.Rule, progress)
		default:
			rows, requestCount, err = wbRunETBatchesWithProgress(ctx, request, members, q, job.Rule, progress)
		}
		if err == nil && q.Program != "THT" {
			pairEvidence, pairErr := wbQueryPairEvidence(ctx, request, members, q, job.Rule)
			if pairErr != nil {
				warning := fmt.Sprintf("%s Advertiser 明细证据不可用（不覆盖或阻断 Account 权威指标）：%s", q.Program, sanitizeLogText(pairErr.Error()))
				logMsg("[risk-scan] "+warning, "plugin")
				wbMu.Lock()
				job.Warnings = append(job.Warnings, warning)
				wbMu.Unlock()
			} else {
				rows = applyPairEvidence(rows, pairEvidence, q, job.Rule)
			}
		}
		if err != nil {
			logMsg(fmt.Sprintf("[risk-scan] %s batch metrics failed members=%d requests=%d error=%v", q.Program, len(members), requestCount, err), "plugin")
			wbFinish(id, "failed", err.Error())
			return
		}
		if q.Program == "THT" {
			// Publish the completed metric rows before the expensive comparison pass.
			// This keeps Risk Monitoring useful while 4k+ advertiser comparisons finish;
			// the checkpoint is read-only and remains explicitly running/incomplete.
			wbMu.Lock()
			job.Rows = append([]wbRow(nil), rows...)
			job.Done = len(rows)
			job.Matched = 0
			for _, row := range rows {
				if wbMatched(row) {
					job.Matched++
				}
			}
			job.Stage = "computing_comparisons"
			job.AsOf = time.Now().UTC().Format(time.RFC3339)
			_ = wbSaveJob(job)
			wbMu.Unlock()
		}
		rows = wbApplyRealComparisons(ctx, request, rows, time.Now())
		for i := range rows {
			if rows[i].Comparison.Status == "" {
				rows[i].Comparison = wbComparisonResult(q.Program, rows[i].Member.Start, nil, nil, time.Now())
			}
		}
		if len(job.Policy.Rules) > 0 || job.Rule.RiskPolicy == wbGovernancePolicyVersion {
			rows = wbApplyGovernanceRowsPolicy(rows, wbPolicyFromJob(*job))
		}
		wbMu.Lock()
		job.Rows = append([]wbRow(nil), rows...)
		job.Done = len(rows)
		job.Matched = 0
		for _, row := range rows {
			if wbMatched(row) {
				job.Matched++
			}
		}
		chunkSize := wbETMetricChunkSize
		if q.Program == "ST" {
			chunkSize = wbSTMetricChunkSize
		} else if q.Program == "THT" {
			chunkSize = wbTHTMetricChunkSize
		}
		job.Warnings = append(job.Warnings, fmt.Sprintf("%s 指标通过 Saved Report/VQS 分块批量查询完成：%d 个候选，%d 个分块，chunk_size=%d。", q.Program, len(members), requestCount, chunkSize))
		wbMu.Unlock()
		status := "ready"
		if !complete {
			status = "partial"
		}
		for _, row := range rows {
			if row.MetricStatus != "success" || row.CCR == nil || row.NFS == nil {
				status = "partial"
				break
			}
		}
		if len(members) == 0 {
			status = "empty"
		}
		wbFinish(id, status, "")
		return
	}
	work := make(chan wbMember)
	var wg sync.WaitGroup
	for i := 0; i < c.Concurrency; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for m := range work {
				row := wbRow{Program: q.Program, Member: m, Reasons: []string{}, Level: "unavailable", AllowlistStatus: "Unknown", DataStatus: "Data Missing", RecipientStatus: "pending_confirmation"}
				customerID := m.AccountID
				if customerID == "" {
					customerID = m.AdvertiserID
				}
				row.ID = wbKey([]string{q.Program, customerID, m.TicketID, q.Start, q.End, job.Rule.Version})[:24]
				select {
				case wbSlots <- struct{}{}:
					metricID := m.AccountID
					query := wbQueryCurrent
					if q.Program == "THT" {
						metricID = m.AdvertiserID
						query = wbQueryTHTCurrent
					}
					clientCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
					result, status := query(clientCtx, request, etCCRDiagnosticRequest{AccountID: metricID, StartDate: q.Start, EndDate: q.End})
					cancel()
					<-wbSlots
					row.MetricStatus = asString(result["status"])
					row.Source = result["data_source"]
					row.QueriedAt = asString(result["last_queried_at"])
					if trace, ok := result["trace"].(map[string]any); ok {
						row.RequestID = asString(trace["request_id"])
					}
					switch row.MetricStatus {
					case "success":
						row.DataStatus = "Success"
					case "no_data":
						row.DataStatus = "No Fact"
					case "pending", "":
						row.DataStatus = "Pending"
					default:
						row.DataStatus = "Query Failed"
					}
					if status == http.StatusOK && row.MetricStatus == "success" {
						row.CCR = wbMetric(result["dynamic_p0_ccr"])
						row.NFS = wbMetric(result["p0_nfs"])
						row.Level, row.Reasons = evaluateWBAbsolute(row.CCR, row.NFS, job.Rule)
						if row.CCR == nil || row.NFS == nil {
							row.DataStatus = "Partial Fact"
						}
					} else {
						row.Error = asString(result["error"])
						if row.Error == "" {
							row.Error = asString(result["message"])
						}
					}
				case <-ctx.Done():
					row.MetricStatus = "timeout"
					row.Error = "scan budget exceeded"
				}
				if m.Submitter != "" {
					row.RecipientStatus = "submitter_available_identity_unverified"
				}
				if q.Program == "THT" {
					accountID := m.AccountID
					if accountID == "" && len(m.LinkedAccountIDs) > 0 {
						accountID = m.LinkedAccountIDs[0]
					}
					evidence := wbAdvertiserEvidence{AccountID: accountID, AccountName: m.Name, AdvertiserID: m.AdvertiserID, AdvertiserName: m.AdvertiserName, CCR: row.CCR, NFS: row.NFS, Revenue: nil, AllowlistStatus: "N/A：THT 未使用 ET/ST bridge allowlist", Level: row.Level, Reasons: append([]string(nil), row.Reasons...), MetricStatus: row.MetricStatus}
					row.Advertisers, row.AdvertiserTop10, row.AdvertiserCount = []wbAdvertiserEvidence{evidence}, []wbAdvertiserEvidence{evidence}, 1
					row.AccountCCRStatus = "N/A：THT source 未提供独立 account 粒度指标"
					row.AggregationNote = "THT 使用自身 Account/Advertiser 字段；Revenue 缺失保持 N/A"
				}
				row.Message = wbMessage(row, q, job.Rule)
				wbMu.Lock()
				job.Rows = append(job.Rows, row)
				job.Done++
				if wbMatched(row) {
					job.Matched++
				}
				wbMu.Unlock()
			}
		}()
	}
sendLoop:
	for _, m := range members {
		select {
		case work <- m:
		case <-ctx.Done():
			break sendLoop
		}
	}
	close(work)
	wg.Wait()
	wbMu.Lock()
	status := "ready"
	if job.Done != job.Members || !job.Complete {
		status = "partial"
	}
	for _, row := range job.Rows {
		if row.MetricStatus != "success" || row.CCR == nil || row.NFS == nil {
			status = "partial"
		}
	}
	wbMu.Unlock()
	if len(members) == 0 {
		status = "empty"
	}
	wbFinish(id, status, "")
}
func wbFinish(id, status, msg string) {
	wbMu.Lock()
	defer wbMu.Unlock()
	job := wbRunning[id]
	if job == nil {
		return
	}
	job.Status = status
	job.Stage = "finished"
	job.Error = msg
	job.FinishedAt = time.Now().UTC().Format(time.RFC3339)
	wbOrder(job.Rows)
	funnel := wbBuildProgramFunnel(*job)
	job.Funnel = &funnel
	if e := wbSaveJob(job); e != nil {
		job.Warnings = append(job.Warnings, "持久化失败："+e.Error())
	} else {
		if e := cwImportJob(cloneWBJob(job)); e != nil {
			job.Warnings = append(job.Warnings, e.Error())
			_ = wbSaveJob(job)
		}
	}
}
func wbLookup(id, principal string) (wbJob, error) {
	wbMu.Lock()
	defer wbMu.Unlock()
	if job := wbRunning[id]; job != nil {
		return cloneWBJob(job), nil
	}
	s, e := wbReadDisk()
	if e != nil {
		return wbJob{}, e
	}
	if j, ok := s.Jobs[id]; ok {
		return j, nil
	}
	return wbJob{}, os.ErrNotExist
}
func wbConfigHandler(w http.ResponseWriter, r *http.Request) {
	c, e := loadWBConfig()
	if e != nil {
		writeJSON(w, 503, map[string]any{"error": e.Error()})
		return
	}
	cfg, e := loadDataSourceConfig()
	if e != nil {
		writeJSON(w, 503, map[string]any{"error": e.Error()})
		return
	}
	sources := map[string]any{}
	for _, key := range []string{"et_account_list", "tht_ticket_details", "et_current_ccr_nfs", "tht_current_ccr_nfs"} {
		s := cfg.Sources[key]
		sources[key] = map[string]any{"app_id": s.AppID, "sid": s.SID, "rid": s.RID, "configured": s.Enabled && s.RID > 0}
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"config": c, "defaults": wbDefaultRequest(c), "quota_baseline": wbQuotaBaseline(), "sources": sources, "live_programs": []string{"ET", "THT"}, "notification_mode": "preview_only", "membership_policy": "ET：RID 2898604 的真实保存口径（Emerging trust apply + APPROVE，按 create_time）；该报表不含 tier_v3_name/p_date，页面明确采用最接近且可审计口径。THT：Protection program + Temporary High Trust (THT) - Advertiser ID + APPROVE，按 create_time。"}})
}
func wbMembershipSource(program string) string {
	switch program {
	case "ST":
		return "st_authoritative_sheet_snapshot"
	case "THT":
		return "tht_ticket_details"
	default:
		return "et_account_list"
	}
}

func wbStartHandler(w http.ResponseWriter, r *http.Request) {
	var q wbRequest
	if e := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&q); e != nil {
		writeJSON(w, 400, map[string]any{"error": "invalid JSON"})
		return
	}
	if e := validateWBRequest(&q); e != nil {
		writeJSON(w, 400, map[string]any{"error": e.Error()})
		return
	}
	c, e := loadWBConfig()
	if e != nil {
		writeJSON(w, 503, map[string]any{"error": e.Error()})
		return
	}
	policy, e := wbActivePolicy(r.Context())
	if e != nil {
		writeJSON(w, 503, map[string]any{"error": "active risk policy unavailable: " + e.Error()})
		return
	}
	rule, ok := c.Rules[q.Program]
	if !ok || !rule.Enabled {
		writeJSON(w, 409, map[string]any{"error": "absolute rule disabled or not configured"})
		return
	}
	rule.RiskPolicy = policy.VersionLabel
	rule.Version = policy.VersionLabel
	principal := requestUsername(r)
	key := wbKey([]any{wbScope(principal, q, c), policy.ConfigHash})
	wbMu.Lock()
	active := 0
	for _, j := range wbRunning {
		if j.Principal == principal && j.Status == "running" {
			if j.ScopeKey == key {
				out := cloneWBJob(j)
				wbMu.Unlock()
				writeJSON(w, 200, map[string]any{"data": out})
				return
			}
			active++
		}
	}
	if active > 0 {
		wbMu.Unlock()
		writeJSON(w, 409, map[string]any{"error": "已有扫描运行，请等待完成后再查询新范围"})
		return
	}
	disk, err := wbReadDisk()
	if err != nil {
		wbMu.Unlock()
		writeJSON(w, 503, map[string]any{"error": err.Error()})
		return
	}
	if !q.Force {
		for _, j := range disk.Jobs {
			if j.Principal == principal && j.ScopeKey == key && (j.Status == "ready" || j.Status == "partial" || j.Status == "empty" || j.Status == "failed" || j.Status == "blocked") {
				wbMu.Unlock()
				writeJSON(w, 200, map[string]any{"data": j})
				return
			}
		}
	}
	for id, j := range wbRunning {
		t, _ := time.Parse(time.RFC3339, j.StartedAt)
		if j.Status != "running" && time.Since(t) > 30*time.Minute {
			delete(wbRunning, id)
		}
	}
	if len(wbRunning) >= 100 {
		wbMu.Unlock()
		writeJSON(w, 429, map[string]any{"error": "scan queue full"})
		return
	}
	membershipSource := wbMembershipSource(q.Program)
	now := time.Now().UTC()
	batchID := fmt.Sprintf("TAP-WEEK-%s-%s", q.Start, q.End)
	j := &wbJob{ID: uuid.NewString(), BatchID: batchID, AsOf: now.Format(time.RFC3339), RuleVersion: policy.VersionLabel, Principal: principal, ScopeKey: key, Request: q, Rule: rule, Policy: policy, Status: "running", Stage: "loading_members", StartedAt: now.Format(time.RFC3339), Rows: []wbRow{}, Warnings: []string{"完整自然周扫描；筛选只读，不触发扫描或通知。"}, MembershipSource: membershipSource, RankBy: "advertiser_current_p0_ccr_desc; Top10 display, full details retained"}
	wbRunning[j.ID] = j
	out := cloneWBJob(j)
	wbMu.Unlock()
	backgroundReq := r.Clone(context.WithoutCancel(r.Context()))
	go wbRunJob(backgroundReq, j.ID, c)
	writeJSON(w, 202, map[string]any{"data": out})
}
func wbGetHandler(w http.ResponseWriter, r *http.Request) {
	j, e := wbLookup(r.PathValue("id"), requestUsername(r))
	if e != nil {
		writeJSON(w, 404, map[string]any{"error": "scan not found"})
		return
	}
	wbMu.Lock()
	s, err := wbReadDisk()
	wbMu.Unlock()
	actions := map[string]wbAction{}
	if err == nil {
		for _, row := range j.Rows {
			if a, ok := s.Actions[wbKey([]string{j.Principal, row.ID})]; ok {
				actions[row.ID] = a
			}
		}
	}
	writeJSON(w, 200, map[string]any{"data": j, "actions": actions})
}
func wbActionHandler(w http.ResponseWriter, r *http.Request) {
	var input struct {
		ScanID string `json:"scan_id"`
		Status string `json:"status"`
		Cause  string `json:"cause"`
		Note   string `json:"note"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 32<<10)).Decode(&input) != nil {
		writeJSON(w, 400, map[string]any{"error": "invalid action"})
		return
	}
	valid := map[string]bool{"open": true, "processing": true, "observing": true, "closed": true}
	if !valid[input.Status] || strings.TrimSpace(input.Note) == "" || len(input.Note) > 8000 {
		writeJSON(w, 400, map[string]any{"error": "请选择状态并填写处理记录（最多8000字节）"})
		return
	}
	principal := requestUsername(r)
	j, e := wbLookup(input.ScanID, principal)
	if e != nil || j.Status == "running" || j.Principal != principal {
		writeJSON(w, 409, map[string]any{"error": "扫描未完成或不可访问"})
		return
	}
	id := r.PathValue("id")
	found := false
	for _, row := range j.Rows {
		if row.ID == id && wbMatched(row) {
			found = true
		}
	}
	if !found {
		writeJSON(w, 404, map[string]any{"error": "risk row not found"})
		return
	}
	wbMu.Lock()
	defer wbMu.Unlock()
	s, e := wbReadDisk()
	if e != nil {
		writeJSON(w, 503, map[string]any{"error": e.Error()})
		return
	}
	key := wbKey([]string{principal, id})
	a := s.Actions[key]
	a.AlertID = id
	a.ScanID = input.ScanID
	a.Principal = principal
	a.Status = input.Status
	a.Cause = input.Cause
	a.Note = input.Note
	a.UpdatedAt = time.Now().UTC().Format(time.RFC3339)
	a.History = append(a.History, wbEvent{Time: a.UpdatedAt, Actor: principal, Status: input.Status, Cause: input.Cause, Note: input.Note})
	s.Actions[key] = a
	if e = wbWriteDisk(s); e != nil {
		writeJSON(w, 503, map[string]any{"error": e.Error()})
		return
	}
	writeJSON(w, 200, map[string]any{"data": a})
}
func init() {
	Register(Route{Method: "GET", Path: "/api/workbench/config", Summary: "工作台规则、来源、默认窗口及接入状态", Handler: wbConfigHandler, Tags: []string{"workbench"}})
	Register(Route{Method: "POST", Path: "/api/workbench/scans", Summary: "创建ET真实指标绝对值风险扫描，返回异步任务", Handler: wbStartHandler, Tags: []string{"workbench"}, BodyParams: []Param{{Name: "program", Type: "string", Required: true, Description: "ET"}, {Name: "start_date", Type: "string", Required: true, Description: "指标开始日"}, {Name: "end_date", Type: "string", Required: true, Description: "指标结束日"}, {Name: "member_start_date", Type: "string", Required: true, Description: "成功提报名单起始日"}, {Name: "member_end_date", Type: "string", Required: true, Description: "成功提报名单结束日"}, {Name: "region", Type: "string", Description: "提报区域精确值或all"}, {Name: "force", Type: "bool", Description: "强制刷新"}}})
	Register(Route{Method: "GET", Path: "/api/workbench/scans/{id}", Summary: "查询当前用户扫描进度、全量命中及处理记录", Handler: wbGetHandler, Tags: []string{"workbench"}})
	Register(Route{Method: "POST", Path: "/api/workbench/alerts/{id}/actions", Summary: "保存真实风险记录的人工归因与处理，不发送外部消息", Handler: wbActionHandler, Tags: []string{"workbench"}, BodyParams: []Param{{Name: "scan_id", Type: "string", Required: true}, {Name: "status", Type: "string", Required: true}, {Name: "cause", Type: "string"}, {Name: "note", Type: "string", Required: true}}})
}
