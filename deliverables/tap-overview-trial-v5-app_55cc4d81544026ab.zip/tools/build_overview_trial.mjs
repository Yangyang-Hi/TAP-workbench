// Builds the authenticated Overview into the standard app/dist target when the explicit trial profile is enabled.
import path from "node:path";
import fs from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const modules = process.env.TAP_BUILD_NODE_MODULES || path.join(root, "app/frontend/node_modules");
const require = createRequire(path.join(modules, "../package.json"));
const { build } = require("esbuild");
let standardTrial = false;
try { standardTrial = JSON.parse(await fs.readFile(path.join(root, "config/overview_trial.json"), "utf8")).enabled === true; }
catch (e) { if (e.code !== "ENOENT") throw e; }
const out = path.join(root, standardTrial ? "app/dist" : "app/overview-dist");
await fs.mkdir(out, { recursive: true });
const result = await build({
  absWorkingDir: path.join(root, "app/frontend"), entryPoints: ["src/overview-entry.tsx"],
  outdir: path.join(out, "assets"), entryNames: "overview-[hash]", chunkNames: "chunk-[hash]", assetNames: "[name]-[hash]",
  bundle: true, splitting: true, format: "esm", minify: true, target: "es2022", jsx: "automatic", nodePaths: [modules],
  alias: { "@bytecloud/common-lib": path.join(root, "app/frontend/vendor/bytecloud/index-CyHTFGrwEOXakQLE.js") },
  define: { "process.env.NODE_ENV": '"production"' }, metafile: true,
});
const outputs = Object.entries(result.metafile.outputs);
const entry = outputs.find(([, x]) => x.entryPoint?.endsWith("overview-entry.tsx"));
if (!entry) throw Error("Overview entry missing");
const css = outputs.filter(([p]) => p.endsWith(".css"));
await fs.writeFile(path.join(out, "index.html"), `<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TAP 数据总览 · Account 分布验证版</title>${css.map(([p]) => `<link rel="stylesheet" href="./assets/${path.basename(p)}">`).join("")}<style>body{margin:0}</style></head><body><div id="root"></div><script type="module" src="./assets/${path.basename(entry[0])}"></script></body></html>`);
console.log("Built Overview trial:", path.basename(entry[0]));
