package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

// Keep the platform's standard service command intact. Trial behavior belongs
// to an explicit application configuration, not to a custom service scaffold.
func overviewTrialProfileEnabled() bool {
	raw, err := os.ReadFile(filepath.Join(pluginDir, "config", "overview_trial.json"))
	if os.IsNotExist(err) {
		return false
	}
	if err != nil {
		panic(fmt.Errorf("read Overview trial profile: %w", err))
	}
	var profile struct {
		Enabled bool `json:"enabled"`
	}
	if err := json.Unmarshal(raw, &profile); err != nil {
		panic(fmt.Errorf("invalid Overview trial profile: %w", err))
	}
	return profile.Enabled
}

func overviewTrialEnabled() bool {
	return os.Getenv("TAP_OVERVIEW_ONLY") == "1" || overviewTrialProfileEnabled()
}

// Explicit opt-in for a NEW trial App. It needs no Casework Cloud schema and
// never starts scan schedulers or notification workers. Production is unchanged.
func overviewTrialMux() *http.ServeMux {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/overview/accounts", wrapAuth(overviewAccountsHandler))
	mux.HandleFunc("GET /api/me", wrapAuth(meHandler))
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/" && r.URL.Query().Get("view") != "overview" {
			u := *r.URL
			q := u.Query()
			q.Set("view", "overview")
			u.RawQuery = q.Encode()
			http.Redirect(w, r, u.String(), http.StatusTemporaryRedirect)
			return
		}
		staticHandler(w, r)
	})
	return mux
}

func overviewServeTrial() {
	if overviewTrialProfileEnabled() {
		staticDir = filepath.Join(pluginDir, "app", "dist")
	} else {
		staticDir = filepath.Join(pluginDir, "app", "overview-dist")
	}
	mux := overviewTrialMux()
	logMsg("Overview-only trial server: no Cloud DB, scans or notification workers", "plugin")
	server := &http.Server{Addr: fmt.Sprintf(":%d", listenPort), Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := server.ListenAndServe(); err != nil {
		panic(err)
	}
}
