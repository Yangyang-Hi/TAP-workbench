import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, expect, it, vi } from "vitest";
import GovernanceWorkbench from "./index";

const analyticsList = vi.fn();

vi.mock("../../api/client.gen", () => ({
  workbenchBatchesList: vi.fn().mockResolvedValue({ data: { batches: [{ batch_id: "b42", week_name: "2026-W42", metric_start_date: "2026-10-12", metric_end_date: "2026-10-18" }] } }),
  workbenchReadModelList: vi.fn().mockResolvedValue({ data: { status: "available", time: { mode: "weekly" }, cards: {}, rows: [], pagination: { page: 1, page_size: 50, total: 0 } } }),
  workbenchAnalyticsList: (...args: unknown[]) => analyticsList(...args),
  workbenchAnalyticsReportsCreate: vi.fn(),
  unwrap: (value: { data: unknown }) => value.data,
}));
vi.mock("../../aime-runtime", () => ({ usePageControlRefresh: vi.fn() }));
vi.mock("../../auth", () => ({ apiFetch: vi.fn() }));
vi.mock("./overview-feature", () => ({ useOverviewFeature: () => true }));
vi.mock("./overview-home", () => ({ IntegratedOverview: () => <div data-testid="integrated-overview">Overview</div> }));
vi.mock("./submission-quota", () => ({ SubmissionQuota: () => <div>Quota</div> }));
vi.mock("./casework", () => ({ WorkbenchSettings: () => null, CaseActions: () => null }));
vi.mock("./casework-task", () => ({ SubmitterCasework: () => null }));

const crossQuarterAnalytics = {
  as_of: "2026-10-04T00:00:00Z",
  filters: { Start: "2026-09-28", End: "2026-10-04", Region: "EUI", Program: "", Tier: "", Submitter: "", Owner: "", TimeMode: "custom", BatchID: "", ScopeReason: "跨季度只读查询" },
  cases: [],
  case_presentations: {},
  summary: { alerts: 0, clients: 0, notified: 0, pending: 0, overdue: 0, quota_full_pairs: 0, quota_exceeded_pairs: 0 },
  Region: [], Attribution: [], Action: [], risk_source: [], risk_level: [], program: [], source_by_case: {}, owner_progress: [],
  coverage: { risk_events: 0, linked_cases: 0, unlinked_alerts: 0, check_filled: 0, action_filled: 0, recheck_covered: 0 },
  metadata: { alert_source_basis: "只读", level_basis: "只读", casework_basis: "只读", alert_sources_overlap: false, top20_candidates_included: false, timezone: "Asia/Shanghai" },
  notification: { formal: {}, test: {} }, effects: {}, effect_status: {}, missing_data: [],
  rule_summaries: [], priority_clients: [], top20_candidates: [],
  batch_status: { label: "阶段性结果", incomplete: true, programs: null },
  quota: { status: "unavailable", denominator_reason: "跨季度 Quota 分段展示" },
};

beforeEach(() => {
  history.replaceState(null, "", "/?region=EUI&time_mode=history&batch_id=b42");
  analyticsList.mockResolvedValue({ data: crossQuarterAnalytics });
});

it("历史周度从总览切到效果分析再到数据中心不白屏", async () => {
  render(<GovernanceWorkbench />);
  expect(screen.getByTestId("governance-workbench")).toBeTruthy();

  fireEvent.click(screen.getByText("治理效果分析"));
  await waitFor(() => expect(analyticsList).toHaveBeenCalledWith(expect.objectContaining({
    time_mode: "weekly", batch_id: "b42", region: "EUI",
  })));
  expect(screen.getByTestId("analysis-page")).toBeTruthy();
  expect(screen.getByText("阶段性结果")).toBeTruthy();

  fireEvent.click(screen.getByText("运营数据中心"));
  expect(screen.getByTestId("data-page")).toBeTruthy();
  expect(screen.getByTestId("governance-workbench")).toBeTruthy();
});
