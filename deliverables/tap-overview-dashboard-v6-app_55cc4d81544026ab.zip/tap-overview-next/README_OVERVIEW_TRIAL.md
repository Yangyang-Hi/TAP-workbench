# v6 · 数据总览独立验证包

目标 App：**app_55cc4d81544026ab**（TAP 数据总览验证）。本包基于 Amy 已修复、已能查询 Account 的源码包继续开发；保留其预览网关资源路径修复及启动二进制回退修复。

在该测试 App 的「本地开发入口 → ZIP 包 → 上传修改后的代码」上传整个安装 ZIP。不要解压再改 ID，不要将这个完整包覆盖原线上工作台。安装后打开页面，确认标题为「数据总览 / Overview」，选择开始日期、结束日期、Region，点击「应用筛选」。

## 本次内容

- 完整保留 Account 四 Tier 快照分布。
- 新增 Revenue 四 Tier 分布、P0 CCR/NFS 区间汇总与周度趋势、Approval 四 Tier 卡片；P1 周度趋势按需展开。
- ET Account / ST Brand Quota 分区、分季度展示，复用原查询与配额配置。
- 风险与处置汇总适配原 Cloud 权威事件、成功通知回执、已有扫描事实；独立 App 没有这些数据时显示未接入，不显示假 0。
- 显示模块来源、时间口径、查询诊断；「下载本次查询记录」导出已应用筛选及各模块结果，便于反馈，不包含登录令牌。
- 统一起止日期和 Region；暂不设置统一 Tier 选择，避免 TAP Tier 和治理 Program 混用。

## 可以验收什么

本地完成了编译、受影响回归、原生服务启动、鉴权/隔离检查，以及桌面/手机浏览器检查。**新增风神报表尚未在 AIME 宿主中进行真实出数对拍，不能仅凭构建通过认定数据验收完成。** Account 的真实出数依据是用户此前对 Amy 基线版本的验证。

Revenue 币种、CCR 单位和 Approval 百分比缩放尚未独立核实，因此当前明确显示源值，不擅自标 USD、% 或转换倍数。风神实际字段与迁移文档不一致时，模块会给出不可用和诊断，而不是猜字段或补零。

ST Quota 依赖当前实例成功保存的季度名单；完整源码包不会搬运其他实例的业务数据。独立 App 没有名单快照时 ST Used / Rate 显示不可用。ET 沿用原 et_quota_tickets 已批准来源；并未根据另一个 RID 的名字猜取数方案。

账户快照的 14 天是当前应用的回看策略（以选定结束日为锚点，含当天），不是已证明的风神历史保留限制。Revenue、CCR 等区间查询没有套用此上限。可自定义历史区间，但能否返回有效数据取决于源端分区、权限、查询限制及对应季度配置；未来未发生的日期不能查出数据。

详见 docs/overview/取数与验收.md、docs/overview/合并到主工作台.md。docs/overview 下两张图片是**界面测试样例，非真实风神出数**。

## 构建与打包

继续使用原标准构建契约，无需更改服务名或启动命令：

```bash
bash build.sh
bash build.sh --mode release
bash pack.sh --include-source --include-go-source --output /tmp/tap-overview-dashboard-v6.zip
```

已完成构建时可使用 --skip-build --skip-go-build 打包，但脚本仍会核对发布二进制可执行、页面和 CDN 资源齐全。完整包包含源码和 Linux amd64 发布二进制，不包含 node_modules、.aime_build、日志、数据库或密钥文件。不要用 git archive 打上传包：Git 忽略规则会省略二进制和 dist。

隔离开关为 config/overview_trial.json 的严格布尔 enabled:true。标准 standalone 服务保留 auto_start；没有开启 Cloud DB 初始化、扫描调度、建单、通知 worker 或业务修改接口。原工作台完整源码仍在包内；合并时必须保留主工作台身份和运行模式。
