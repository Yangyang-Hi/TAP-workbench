# v5：标准 standalone 构建契约修正版

目标测试 App：`app_55cc4d81544026ab`。请在此 App 的“本地开发入口 → ZIP 包 → 上传修改后的代码”上传本包。无需手动修改ID、服务名或启动命令，不要上传到原线上 App。

## 本次修改

- 保留原 `.template_meta.json` 和 `build_contract_version=1`，没有删除、降级或绕过模板契约。
- 服务名和 iframe 服务引用统一为 `standalone`。
- 服务命令恢复为 `cd app/server-go && bash start.sh`。原 build.sh 和 start.sh 保持上传基线原样。
- 前端构建输出和CDN路径使用标准 `app/dist`、`app/dist/assets`。
- 通过 `config/overview_trial.json` 的 `enabled:true` 开启隔离模式，无需修改服务命令或设置环境变量。
- build.sh 的前端步骤读取该显式配置，只构建这个图表；使用 tools/overview-frontend/package-lock.json 冻结安装3项直接公开依赖，保留原完整前端依赖声明和锁文件。没有伪造企业SDK，也没有关闭依赖校验。

## 功能范围

本包仍只验证四 Tier 的 Account 数量、占比、截止日快照和Region筛选。鉴权与风神查询链路保持原实现。不会初始化Casework Cloud DB，不启动扫描或通知worker，不开放建单、处置、飞书回调等业务修改接口。

进入页面后点击“应用筛选”。真实数据仍需新App具有平台登录和风神权限；以Global和APAC同条件对拍RID 2891943为准。图表从截止日向前查询14个自然日中的最新非空快照；缺失不补零，不累计每日账户数，未知字段或重复聚合行不强行生成占比。

## 已验证与边界

本地运行了原标准入口 `bash build.sh`（开发模式）和 `bash build.sh --mode release --target all`，均完成前后端构建。相关后端14个顶层测试含race通过；独立服务使用标准启动命令，在没有TAP_OVERVIEW_ONLY环境变量的情况下，从配置进入隔离模式。页面和标准app/dist静态资源返回200，身份缺失的数据请求被拒绝，修改业务的接口返回404，未创建业务数据目录。

平台端源码上传、构建契约验证、服务安装与真实出数仍需本次重新上传后确认；本地构建通过不等于AIME平台验收通过。若再失败，请提供完整错误及构建日志，不要删除模板元数据或切回完整工作台模式。

本包为独立测试App使用。后续合回原工作台需审查具体源码变更；不要将此包的app.json及enabled:true配置直接覆盖原线上App。
