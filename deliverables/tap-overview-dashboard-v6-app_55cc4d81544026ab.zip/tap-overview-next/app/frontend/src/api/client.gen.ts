// CODE GENERATED FROM app/api/api.yaml BY tools/gen_api.py — DO NOT EDIT
import { apiFetch } from '../auth';

export type ApiEnvelope<T = unknown> = { data: T } & Record<string, unknown>;
export function unwrap<T>(res: { data: T }): T { return res.data; }

export interface GovernanceModel {
  status: string;
  reason: string;
  source: string;
  as_of: string;
}

export type AdminSyncCreateResponse = { data: { status: string; runs: unknown[] } };
export type GovernanceIdentityDiagnosticsListResponse = { data: { workbench_identity: { status: string; principal: string }; aeolus_identity: { status: string; principal: string }; aeolus_network: { status: string; endpoint: string; http_category: string; duration_ms: number }; reports: unknown[] } };
export type GovernanceRegistryListResponse = { data: { sources: Array<{ source_key: string; status: string; latest_sync: Record<string, unknown>; latest_snapshot: Record<string, unknown>; diagnostics: Record<string, unknown> }>; cards: unknown[]; regions: unknown[]; tiers: unknown[] } };
export type GovernanceSyncStatusListResponse = { data: { runs: unknown[] } };
export type GovernanceTabsByTabGetResponse = { data: { tab: string; status: string; page_contract: { controls: unknown[]; fixed_scope: Record<string, unknown> }; cards: unknown[]; filters: Record<string, unknown>; quota: { as_of: string; scope: string; plans: unknown[]; regions: unknown[]; tht: Record<string, unknown> } } };
export type IntegrationsFeishuCardCallbackCreateResponse = { toast: Record<string, unknown>; card: Record<string, unknown> };
export type IntegrationsFeishuConfigStatusListResponse = { data: Record<string, unknown> };
export type IntegrationsFeishuCredentialsCreateResponse = { data: Record<string, unknown> };
export type IntegrationsFeishuTestMessageCreateResponse = { data: { mode: string; message_id: string; sent_at: string; recipient: Record<string, unknown>; api_response: Record<string, unknown> } };
export type IntegrationsFeishuTestRecipientCreateResponse = { data: Record<string, unknown> };
export type MonitoringEtCurrentCreateResponse = { data: { status: string; account_id: string; start_date: string; end_date: string; dynamic_p0_ccr: number; p0_nfs: number; revenue: number; revenue_status: string; revenue_error: string; authority_grain: string; data_source: { app_id: number; sid: number; rid: number; grain: string; revenue: { rid: number; sid: number; grain: string } }; request_id: string; log_id: string; revenue_request_id: string; revenue_log_id: string; query_duration_ms: number; last_queried_at: string; cached: boolean } };
export type MonitoringRiskScansCreateResponse = { data: { id: string; status: string; stage: string; member_count: number; done: number; rows: unknown[] } };
export type MonitoringRiskScansByIdGetResponse = { data: { id: string; status: string; stage: string; member_count: number; done: number; rows: unknown[] }; actions: Record<string, unknown> };
export type MonitoringRiskScansByIdResumeMissingCreateResponse = { data: { id: string; status: string; processed: number; remaining: number; classification: Record<string, unknown> } };
export type OverviewAccountsListResponse = { data: { status: string; reason: string; requested_end_date: string; data_as_of: string; region: string; rows: unknown[]; queried_at: string; attempts: number; diagnostics: Record<string, unknown>; source: { rid: number; sid: number; app_id: number } } };
export type OverviewGovernanceListResponse = { data: { status: string; reason: string; window: Record<string, unknown>; side_effects: boolean } };
export type OverviewMetricsByMetricGetResponse = { data: { module: string; status: string; reason: string; rows: unknown[]; summary: Record<string, unknown>; source: Record<string, unknown>; diagnostics: Record<string, unknown>; window: Record<string, unknown>; queried_at: string } };
export type OverviewQuotaListResponse = { data: { window: Record<string, unknown>; quarters: unknown[]; queried_at: string; side_effects: boolean } };
export type SubmissionsListResponse = { data: unknown[]; total: number; status: string; reason: string };
export type SubmissionsQuotaListResponse = { data: { status: string; quarter: string; time: Record<string, unknown>; side_effects: boolean; as_of: Record<string, unknown>; st_snapshot: Record<string, unknown>; global: Record<string, unknown>; regions: unknown[]; weekly: unknown[]; errors: Record<string, unknown>; source_status: Record<string, unknown>; diagnostics: Record<string, unknown>; methodology: Record<string, unknown> } };
export type SubmissionsStSnapshotsCreateResponse = { data: { status: string; snapshots: unknown[]; last_attempt: Record<string, unknown> } };
export type SubmissionsStatusListResponse = { data: { status: string; reason: string } };
export type WorkbenchAnalyticsListResponse = { data: { summary: Record<string, unknown>; notification: Record<string, unknown>; notification_source: Record<string, unknown>; outcomes: { notification_complete: Record<string, unknown>; case_closed: Record<string, unknown>; risk_improved: Record<string, unknown> }; effect_status: Record<string, unknown>; rule_summaries: unknown[]; priority_clients: unknown[]; top20_candidates: unknown[]; batch_status: { label: string; incomplete: boolean; programs: unknown[] }; quota_alerts: { et: Record<string, unknown>; st: Record<string, unknown> }; cases: unknown[]; case_presentations: Record<string, unknown> } };
export type WorkbenchAnalyticsExportListResponse = { data: Record<string, unknown> };
export type WorkbenchAnalyticsExportHtmlListResponse = { data: Record<string, unknown> };
export type WorkbenchAnalyticsReportsCreateResponse = { data: { report_id: string; version: string; title: string; period: string; generated_at: string; data_as_of: string; share_path: string } };
export type WorkbenchAnalyticsReportsByReportIdGetResponse = { data: { report_id: string; version: string; title: string; period: string; owner: string; created_at: string; generated_at: string; data_as_of: string; filters_json: string; content_html: string; content_hash: string } };
export type WorkbenchBackfillsListResponse = { data: { tasks: unknown[] } };
export type WorkbenchBackfillsCreateResponse = { data: { id: string; status: string; dry_run: boolean; fingerprint: string; progress: Record<string, unknown>; program_results: Record<string, unknown>; errors: unknown[] } };
export type WorkbenchBackfillsByIdGetResponse = { data: { id: string; status: string; progress: Record<string, unknown>; errors: unknown[] } };
export type WorkbenchBackfillsByIdRetryCreateResponse = { data: { id: string; status: string } };
export type WorkbenchBatchesListResponse = { data: { status: string; batches: Array<{ batch_id: string; week_name: string; generated_at: string; metric_start_date: string; metric_end_date: string; timezone: string; rule_versions: Record<string, unknown>; programs: Array<string>; status: string; completeness: string }>; timezone: string; source: string } };
export type WorkbenchCasesListResponse = { data: Record<string, unknown> };
export type WorkbenchCasesCreateResponse = { data: Record<string, unknown> };
export type WorkbenchCasesByIdGetResponse = { data: Record<string, unknown>; notifications: unknown[]; permissions: { can_handle: boolean; can_review: boolean } };
export type WorkbenchCasesByIdCommandsCreateResponse = { data: Record<string, unknown> };
export type WorkbenchCasesByIdNotificationPreviewCreateResponse = { data: { dry_run: boolean; will_send: boolean; alert_id: string; original_submitter: string; region: string; case_version: number; confirmation_token: string; confirmation_expires_in_seconds: number; presentation: { submitter: string; alert_type: string; alert_level: string; status: string; time_window: string; region: string; account_id: string; account_name: string; advertiser_id: string; p0_ccr: null; p0_nfs: null; revenue: null; reported_reasons: unknown[]; trigger_criteria: unknown[] }; mapping_result: Record<string, unknown>; mapping_source: { status: string; source_error: string; revision: string; source_synced_at: string; cache_age_seconds: number }; bot_resolution: { status: string; diagnostic: { stage: string; status: string; app_id_fingerprint: string; response_has_user_id: boolean; response_has_open_id: boolean; cached: boolean } }; actual_target: Record<string, unknown> } };
export type WorkbenchCasesByIdNotifyCreateResponse = { data: Record<string, unknown>; notification_id: string; notification: { id: string; status: string; message_id: string; updated_at: string }; deduplicated: boolean; idempotent: boolean; reused: boolean; message: string };
export type WorkbenchCasesByIdRechecksCreateResponse = { data: Record<string, unknown> };
export type WorkbenchCaseworkConfigListResponse = { data: Record<string, unknown> };
export type WorkbenchComparisonsRefreshCreateResponse = { data: { status: string; account_id: string; program: string; anchor: string; windows: { pre: Array<string>; post: Array<string> }; comparison: { pre_ccr: number; post_ccr: number; pre_ccr_fact: { value: number; status: string; reason: string }; post_ccr_fact: { value: number; status: string; reason: string }; increase_fact: { value: number; status: string; reason: string }; ccr_growth_pct: number; legacy_wow_ccr_growth_pct: null; status: string }; updated_rows: number; updated_jobs: number; targeted_only: boolean; side_effects: { case_status: boolean; actions: boolean; notifications: boolean }; completeness: string; audit: Record<string, unknown> } };
export type WorkbenchHistoryListResponse = { data: { scans: unknown[]; actions: Record<string, unknown>; scope: string; limit: number } };
export type WorkbenchIdentityMappingsListResponse = { data: { mappings: unknown[]; source: { status: string; source_error: string; revision: string; source_synced_at: string; cache_age_seconds: number }; auto_send_enabled: boolean } };
export type WorkbenchIdentityMappingsByRecordIdEnabledUpdateResponse = { data: Record<string, unknown> };
export type WorkbenchNotificationsBatchCreateResponse = { data: { dry_run: boolean; results: unknown[] } };
export type WorkbenchReadModelListResponse = { data: { status: string; reason: string; time: Record<string, unknown>; filters: Record<string, unknown>; cards: Record<string, unknown>; funnel: { ET: { status: string; distinct_key: string; mapping_success: { value: number; status: string }; current_ccr_complete: { value: number; status: string }; advertiser_pairs: { value: number; status: string }; advertiser_pair_ccr_complete: { value: number; status: string }; advertiser_pair_nfs_complete: { value: number; status: string }; advertiser_pair_rule_eligible: { value: number; status: string } }; THT: { status: string; distinct_key: string; comparison_protection_time_valid: { value: number; status: string }; comparison_window_complete: { value: number; status: string }; comparison_queried: { value: number; status: string }; comparison_success: { value: number; status: string }; comparison_no_data: { value: number; status: string }; comparison_failed: { value: number; status: string }; comparison_budget_skipped: { value: number; status: string }; growth_ranking_status: string }; ST: { status: string; distinct_clients: { value: null; status: string } } }; policy: { policy_version: string; snapshot_levels_are_historical: boolean }; rows: Array<{ program: string; comparison: { pre_ccr: number; post_ccr: number; pre_ccr_fact: { value: number; status: string; reason: string }; post_ccr_fact: { value: number; status: string; reason: string }; increase_fact: { value: number; status: string; reason: string }; pre_nfs: number; post_nfs: number; pre_revenue: null; post_revenue: null; status: string; source: { rid: number; grain: string; window_complete: boolean; request_ids: Record<string, unknown> } } }>; rankings: Record<string, unknown>; pagination: Record<string, unknown>; contract_version: string; side_effects: boolean } };
export type WorkbenchReportedReasonsRefreshCreateResponse = { data: { status: string; account_id: string; advertiser_id: string; batch_id: string; current_window: { start_date: string; end_date: string }; reason_status: string; reason_error: string; valid_reason_count: number; sort_basis: string; reported_reasons: unknown[]; updated_rows: number; targeted_only: boolean; side_effects: { case_status: boolean; actions: boolean; notifications: boolean } } };
export type WorkbenchRiskPolicyListResponse = { data: { version: number; version_label: string; config_hash: string; rules: unknown[]; is_operator: boolean; updated_by: string; updated_at: string; latest_rejudgement: Record<string, unknown> } };
export type WorkbenchRiskPolicyUpdateResponse = { data: { version: number; version_label: string; config_hash: string; rules: unknown[]; warnings: unknown[]; rejudgement: Record<string, unknown>; idempotent: boolean; unchanged: boolean } };
export type WorkbenchRiskPolicyPreviewCreateResponse = { data: { expected_version: number; draft_hash: string; preview_token: string; warnings: unknown[]; programs: Record<string, unknown>; total: Record<string, unknown>; source_batch_ids: unknown[]; data_freshness: Record<string, unknown>; partial: boolean; failure_reasons: unknown[]; side_effects: { jobs: boolean; cases: boolean; outbox: boolean; aeolus: boolean } } };
export type WorkbenchRiskPolicyRejudgementsListResponse = { data: { tasks: unknown[] } };
export type WorkbenchRiskPolicyVersionsListResponse = { data: { versions: unknown[] } };

async function request<T>(method: string, path: string, body?: unknown, query?: Record<string, unknown>): Promise<T> {
  let url = path;
  if (query) {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
      if (v !== undefined && v !== null) qs.append(k, String(v));
    }
    const s = qs.toString();
    if (s) url += `?${s}`;
  }
  const res = await apiFetch(url, {
    method,
    ...(body !== undefined ? { headers: { 'Content-Type': 'application/json' } } : {}),
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  if (!res.ok) throw new Error(`${method} ${path} failed: HTTP ${res.status}`);
  const text = await res.text();
  return (text ? JSON.parse(text) : {}) as T;
}

/** POST /api/admin/sync — 按数据源和运行时筛选触发同步 */
export function adminSyncCreate<T = AdminSyncCreateResponse>(body: {
  source_keys?: unknown[];
  filters?: Record<string, unknown>;
  force?: boolean;
}): Promise<T> {
  return request<T>("POST", '/api/admin/sync', body);
}

/** GET /api/governance/identity-diagnostics — 获取工作台登录身份、风神短期凭证状态、网络状态与逐 Report 查询状态 */
export function governanceIdentityDiagnosticsList<T = GovernanceIdentityDiagnosticsListResponse>(): Promise<T> {
  return request<T>("GET", '/api/governance/identity-diagnostics', undefined);
}

/** GET /api/governance/registry — 获取数据源合同、粒度、Ready/Conditional/Blocked 状态、快照与质量诊断；S04仅名称补充，S09范围合同不足时保持conditional/unknown */
export function governanceRegistryList<T = GovernanceRegistryListResponse>(): Promise<T> {
  return request<T>("GET", '/api/governance/registry', undefined);
}

/** GET /api/governance/sync-status — 获取最近同步运行状态 */
export function governanceSyncStatusList<T = GovernanceSyncStatusListResponse>(): Promise<T> {
  return request<T>("GET", '/api/governance/sync-status', undefined);
}

/** GET /api/governance/tabs/{tab} — 获取五个治理 Tab 的标准卡片和图表数据 */
export function governanceTabsByTabGet<T = GovernanceTabsByTabGetResponse>(tab: string | number, query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", `/api/governance/tabs/${tab}`, undefined, query);
}

/** POST /api/integrations/feishu/card-callback — 飞书新版加密卡片回调，独立签名和身份校验，不要求浏览器JWT */
export function integrationsFeishuCardCallbackCreate<T = IntegrationsFeishuCardCallbackCreateResponse>(body: {
  encrypt: string;
}): Promise<T> {
  return request<T>("POST", '/api/integrations/feishu/card-callback', body);
}

/** GET /api/integrations/feishu/config-status — 管理员读取飞书 Bot 凭证配置状态（永不返回 Secret 或 Token） */
export function integrationsFeishuConfigStatusList<T = IntegrationsFeishuConfigStatusListResponse>(): Promise<T> {
  return request<T>("GET", '/api/integrations/feishu/config-status', undefined);
}

/** POST /api/integrations/feishu/credentials — 管理员验证并原子保存飞书 Bot 凭证 */
export function integrationsFeishuCredentialsCreate<T = IntegrationsFeishuCredentialsCreateResponse>(body: {
  app_id: string;
  app_secret: string;
}): Promise<T> {
  return request<T>("POST", '/api/integrations/feishu/credentials', body);
}

/** POST /api/integrations/feishu/test-message — 管理员仅向后端测试白名单中的指定邮箱发送无客户信息纯文本测试消息 */
export function integrationsFeishuTestMessageCreate<T = IntegrationsFeishuTestMessageCreateResponse>(body: {
  email: string;
}): Promise<T> {
  return request<T>("POST", '/api/integrations/feishu/test-message', body);
}

/** POST /api/integrations/feishu/test-recipient — 管理员按完整企业邮箱解析并保存唯一测试接收人，启用 test 模式 */
export function integrationsFeishuTestRecipientCreate<T = IntegrationsFeishuTestRecipientCreateResponse>(body: {
  email: string;
}): Promise<T> {
  return request<T>("POST", '/api/integrations/feishu/test-recipient', body);
}

/** POST /api/monitoring/et/current — 查询单个 ET Account 的权威 Account 粒度 Current P0 CCR/NFS/Revenue 真实业务数据 */
export function monitoringEtCurrentCreate<T = MonitoringEtCurrentCreateResponse>(body: {
  account_id: string; /** ET Account ID，按字符串处理 */
  start_date: string; /** 开始日期 YYYY-MM-DD */
  end_date: string; /** 结束日期 YYYY-MM-DD */
}): Promise<T> {
  return request<T>("POST", '/api/monitoring/et/current', body);
}

/** POST /api/monitoring/risk-scans — 创建 ET/THT 高风险客户异步扫描 */
export function monitoringRiskScansCreate<T = MonitoringRiskScansCreateResponse>(body: {
  program: string;
  start_date: string;
  end_date: string;
  member_start_date: string;
  member_end_date: string;
  region?: string;
  force?: boolean;
}): Promise<T> {
  return request<T>("POST", '/api/monitoring/risk-scans', body);
}

/** GET /api/monitoring/risk-scans/{id} — 查询 ET/THT 高风险客户扫描进度与完整结果 */
export function monitoringRiskScansByIdGet<T = MonitoringRiskScansByIdGetResponse>(id: string | number): Promise<T> {
  return request<T>("GET", `/api/monitoring/risk-scans/${id}`, undefined);
}

/** POST /api/monitoring/risk-scans/{id}/resume-missing — 在既有 ET 扫描任务内按 checkpoint 连续补齐 not_queried/failed Current 指标，不重扫 membership */
export function monitoringRiskScansByIdResumeMissingCreate<T = MonitoringRiskScansByIdResumeMissingCreateResponse>(id: string | number, body: {
  max_chunks?: unknown; /** 本次最多处理 Current 指标分片数；1 用于小分片验证，0 表示处理全部剩余分片 */
  include_enrichment?: boolean; /** 补齐同一任务中未查询的 Names、Advertiser、Reasons 与 Allowlist 字段 */
}): Promise<T> {
  return request<T>("POST", `/api/monitoring/risk-scans/${id}/resume-missing`, body);
}

/** GET /api/overview/accounts — 只读查询四Tier账户快照分布，不扫描、不建单、不发送 */
export function overviewAccountsList<T = OverviewAccountsListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/overview/accounts', undefined, query);
}

/** GET /api/overview/governance — 读取现有权威事件、通知及扫描事实生成治理汇总；未连接时明确不可用 */
export function overviewGovernanceList<T = OverviewGovernanceListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/overview/governance', undefined, query);
}

/** GET /api/overview/metrics/{metric} — 只读查询 Revenue、P0、P1及Approval原生报表，不启动扫描或通知 */
export function overviewMetricsByMetricGet<T = OverviewMetricsByMetricGetResponse>(metric: string | number, query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", `/api/overview/metrics/${metric}`, undefined, query);
}

/** GET /api/overview/quota — 复用已有ET账户和ST品牌配额聚合，按季度展示，不同步Sheet或建单 */
export function overviewQuotaList<T = OverviewQuotaListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/overview/quota', undefined, query);
}

/** GET /api/submissions — 查询最近成功快照中的提报数据 */
export function submissionsList<T = SubmissionsListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/submissions', undefined, query);
}

/** GET /api/submissions/quota — 按季度和时间窗聚合 ET、THT、ST 提报及 Quota 使用率 */
export function submissionsQuotaList<T = SubmissionsQuotaListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/submissions/quota', undefined, query);
}

/** POST /api/submissions/st-snapshots — 使用当前用户 JWT 运行时读取 ST Q4/Q3 权威 Sheet，校验后持久化快照 */
export function submissionsStSnapshotsCreate<T = SubmissionsStSnapshotsCreateResponse>(body: Record<string, unknown>): Promise<T> {
  return request<T>("POST", '/api/submissions/st-snapshots', body);
}

/** GET /api/submissions/status — 查询提报数据质量与快照状态 */
export function submissionsStatusList<T = SubmissionsStatusListResponse>(): Promise<T> {
  return request<T>("GET", '/api/submissions/status', undefined);
}

/** GET /api/workbench/analytics — 运营按共享事件台账查询治理分析 */
export function workbenchAnalyticsList<T = WorkbenchAnalyticsListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/workbench/analytics', undefined, query);
}

/** GET /api/workbench/analytics/export — 运营按同一筛选口径导出治理分析Excel */
export function workbenchAnalyticsExportList<T = WorkbenchAnalyticsExportListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/workbench/analytics/export', undefined, query);
}

/** GET /api/workbench/analytics/export-html — 导出与当前筛选和数据版本一致的独立只读HTML治理报告 */
export function workbenchAnalyticsExportHtmlList<T = WorkbenchAnalyticsExportHtmlListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/workbench/analytics/export-html', undefined, query);
}

/** POST /api/workbench/analytics/reports — 按当前真实统计与筛选生成不可变治理报告版本并保存到 Cloud DB */
export function workbenchAnalyticsReportsCreate<T = WorkbenchAnalyticsReportsCreateResponse>(body: Record<string, unknown>, query?: Record<string, unknown>): Promise<T> {
  return request<T>("POST", '/api/workbench/analytics/reports', body, query);
}

/** GET /api/workbench/analytics/reports/{report_id} — 只读获取 Cloud DB 中固定ID对应的不可变治理报告 */
export function workbenchAnalyticsReportsByReportIdGet<T = WorkbenchAnalyticsReportsByReportIdGetResponse>(report_id: string | number): Promise<T> {
  return request<T>("GET", `/api/workbench/analytics/reports/${report_id}`, undefined);
}

/** GET /api/workbench/backfills — 运营查看回填任务状态、进度、checkpoint、请求ID和分Program结果 */
export function workbenchBackfillsList<T = WorkbenchBackfillsListResponse>(): Promise<T> {
  return request<T>("GET", '/api/workbench/backfills', undefined);
}

/** POST /api/workbench/backfills — 运营显式创建 enrichment 定向回填任务；dry-run 仅预览，禁止全量 membership、建 case 或通知 */
export function workbenchBackfillsCreate<T = WorkbenchBackfillsCreateResponse>(body: {
  request_id: string;
  dry_run: boolean;
  program?: string; /** ET/THT/ST 或空 */
  batch_id?: string;
  case_id?: string;
}): Promise<T> {
  return request<T>("POST", '/api/workbench/backfills', body);
}

/** GET /api/workbench/backfills/{id} — 运营查看单个回填任务详情 */
export function workbenchBackfillsByIdGet<T = WorkbenchBackfillsByIdGetResponse>(id: string | number): Promise<T> {
  return request<T>("GET", `/api/workbench/backfills/${id}`, undefined);
}

/** POST /api/workbench/backfills/{id}/retry — 运营显式从 checkpoint 重试失败或中断的回填任务 */
export function workbenchBackfillsByIdRetryCreate<T = WorkbenchBackfillsByIdRetryCreateResponse>(id: string | number, body: {
  request_id: string;
}): Promise<T> {
  return request<T>("POST", `/api/workbench/backfills/${id}/retry`, body);
}

/** GET /api/workbench/batches — 只读返回真实持久化周度批次；无历史时返回空列表 */
export function workbenchBatchesList<T = WorkbenchBatchesListResponse>(): Promise<T> {
  return request<T>("GET", '/api/workbench/batches', undefined);
}

/** GET /api/workbench/cases — 所有已登录使用者共享业务事件；收件箱可默认限定最新一致指标窗口，完整集合过滤后服务端分页 */
export function workbenchCasesList<T = WorkbenchCasesListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/workbench/cases', undefined, query);
}

/** POST /api/workbench/cases — 从当前用户真实命中扫描幂等建立事件，不自动发送 */
export function workbenchCasesCreate<T = WorkbenchCasesCreateResponse>(body: {
  scan_id: string;
  row_id: string;
}): Promise<T> {
  return request<T>("POST", '/api/workbench/cases', body);
}

/** GET /api/workbench/cases/{id} — 共享事件的初始快照、结构化处置、审计、复查和通知；权限由当前鉴权身份与已验证人员映射服务端计算 */
export function workbenchCasesByIdGet<T = WorkbenchCasesByIdGetResponse>(id: string | number): Promise<T> {
  return request<T>("GET", `/api/workbench/cases/${id}`, undefined);
}

/** POST /api/workbench/cases/{id}/commands — 带版本和幂等键的统一分派、处置、复核状态机 */
export function workbenchCasesByIdCommandsCreate<T = WorkbenchCasesByIdCommandsCreateResponse>(id: string | number, body: {
  expected_version: number;
  request_id: string;
  operation: string; /** operator_confirm/submitter_complete/close（推荐治理闭环）或兼容动作 accept/assign/plan/complete/approve/return/reopen；服务端严格校验状态与角色 */
  plan?: string;
  note: string;
  fields?: Record<string, unknown>;
  owner?: string;
  reviewer?: string;
  closure_reason?: string;
}): Promise<T> {
  return request<T>("POST", `/api/workbench/cases/${id}/commands`, body);
}

/** POST /api/workbench/cases/{id}/notification-preview — 刷新权威人员映射并解析 Bot 域目标的无发送预览 */
export function workbenchCasesByIdNotificationPreviewCreate<T = WorkbenchCasesByIdNotificationPreviewCreateResponse>(id: string | number, body: {
  mode?: string; /** test 或 formal；必须与当前服务配置一致 */
  recipient_id?: string; /** test 模式下指定测试白名单目标；formal 模式忽略 */
}): Promise<T> {
  return request<T>("POST", `/api/workbench/cases/${id}/notification-preview`, body);
}

/** POST /api/workbench/cases/{id}/notify — 显式向白名单测试人员发送卡片；要求确认 token 并保持 test 模式 */
export function workbenchCasesByIdNotifyCreate<T = WorkbenchCasesByIdNotifyCreateResponse>(id: string | number, body: {
  expected_version: number;
  mode: string; /** test 或 formal；测试成功不占用正式幂等键 */
  recipient_id?: string; /** test 模式必填白名单 open_id；formal 模式忽略 */
  preview_token: string; /** notification-preview 返回的短期票据；绑定事件、模式、模板和实际收件人快照 */
  confirmation_token?: string; /** 兼容旧前端；与 preview_token 等价 */
  resend?: boolean; /** 仅 Operator 可用；对已成功发送的正式通知创建独立重发记录，不覆盖原审计 */
  resend_request_id?: string; /** 受控重发必填；作为本次重发的独立幂等键 */
  confirmation_note?: string; /** 受控重发必填；记录人工重发原因 */
}): Promise<T> {
  return request<T>("POST", `/api/workbench/cases/${id}/notify`, body);
}

/** POST /api/workbench/cases/{id}/rechecks — 以当前AIME身份查询独立窗口真实CCR/NFS并保存复查 */
export function workbenchCasesByIdRechecksCreate<T = WorkbenchCasesByIdRechecksCreateResponse>(id: string | number, body: {
  expected_version: number;
  start_date: string;
  end_date: string;
  comparability_note: string;
}): Promise<T> {
  return request<T>("POST", `/api/workbench/cases/${id}/rechecks`, body);
}

/** GET /api/workbench/casework/config — 处置模板、当前角色、测试接收目标和飞书配置状态 */
export function workbenchCaseworkConfigList<T = WorkbenchCaseworkConfigListResponse>(): Promise<T> {
  return request<T>("GET", '/api/workbench/casework/config', undefined);
}

/** POST /api/workbench/comparisons/refresh — 按 account_id 与 program 定向刷新当前持久化行的比较窗口，不触发全量扫描、处置或通知 */
export function workbenchComparisonsRefreshCreate<T = WorkbenchComparisonsRefreshCreateResponse>(body: {
  account_id: string; /** 精确 Account ID，仅刷新该账号 */
  program: string; /** ET（预留 ST）；当前仅允许 ET */
}): Promise<T> {
  return request<T>("POST", '/api/workbench/comparisons/refresh', body);
}

/** GET /api/workbench/history — 所有已登录使用者共享的最近十次扫描与处理记录 */
export function workbenchHistoryList<T = WorkbenchHistoryListResponse>(): Promise<T> {
  return request<T>("GET", '/api/workbench/history', undefined);
}

/** GET /api/workbench/identity-mappings — 刷新并列出权威人员映射（敏感字段脱敏） */
export function workbenchIdentityMappingsList<T = WorkbenchIdentityMappingsListResponse>(): Promise<T> {
  return request<T>("GET", '/api/workbench/identity-mappings', undefined);
}

/** PUT /api/workbench/identity-mappings/{record_id}/enabled — 运营启用或停用人员映射；人工停用不会被后续 Sheet 同步覆盖 */
export function workbenchIdentityMappingsByRecordIdEnabledUpdate<T = WorkbenchIdentityMappingsByRecordIdEnabledUpdateResponse>(record_id: string | number, body: {
  enabled: boolean;
  confirmation_note: string;
}): Promise<T> {
  return request<T>("PUT", `/api/workbench/identity-mappings/${record_id}/enabled`, body);
}

/** POST /api/workbench/notifications/batch — 使用统一通知服务批量预览或排队；默认 dry_run，正式执行要求每条独立有效 preview_token */
export function workbenchNotificationsBatchCreate<T = WorkbenchNotificationsBatchCreateResponse>(body: {
  mode: string; /** test 或 formal */
  dry_run: boolean;
  items: unknown[]; /** 每项包含 alert_id、recipient_id（test）和 preview_token（执行时） */
}): Promise<T> {
  return request<T>("POST", '/api/workbench/notifications/batch', body);
}

/** GET /api/workbench/read-model — 四个主 Tab 共用的只读批次、筛选、卡片、事件与榜单契约 */
export function workbenchReadModelList<T = WorkbenchReadModelListResponse>(query?: Record<string, unknown>): Promise<T> {
  return request<T>("GET", '/api/workbench/read-model', undefined, query);
}

/** POST /api/workbench/reported-reasons/refresh — 按 ET Account 与 Advertiser 定向刷新 Current Window 原因 Top3，仅更新关联持久化行 */
export function workbenchReportedReasonsRefreshCreate<T = WorkbenchReportedReasonsRefreshCreateResponse>(body: {
  account_id: string; /** 19 位 ET Account ID，按字符串处理 */
  advertiser_id: string; /** 19 位 Advertiser ID，按字符串处理 */
  batch_id?: string; /** 可选周度批次；空值取包含该 pair 的最新 ET 批次 */
}): Promise<T> {
  return request<T>("POST", '/api/workbench/reported-reasons/refresh', body);
}

/** GET /api/workbench/risk-policy — 获取后端权威生效阈值、版本、权限与最近自动重判状态 */
export function workbenchRiskPolicyList<T = WorkbenchRiskPolicyListResponse>(): Promise<T> {
  return request<T>("GET", '/api/workbench/risk-policy', undefined);
}

/** PUT /api/workbench/risk-policy — 运营使用预览票据、CAS 与幂等键确认并提交新阈值配置，自动创建当前周重判任务 */
export function workbenchRiskPolicyUpdate<T = WorkbenchRiskPolicyUpdateResponse>(body: {
  expected_version: unknown;
  preview_token: string;
  request_id: string;
  confirmation_note: string;
  rules: unknown[];
}): Promise<T> {
  return request<T>("PUT", '/api/workbench/risk-policy', body);
}

/** POST /api/workbench/risk-policy/preview — 运营基于当前周持久化 ET/ST/THT 指标只读预览阈值草稿影响，不查询 Aeolus 或产生写副作用 */
export function workbenchRiskPolicyPreviewCreate<T = WorkbenchRiskPolicyPreviewCreateResponse>(body: {
  expected_version: unknown;
  rules: unknown[];
}): Promise<T> {
  return request<T>("POST", '/api/workbench/risk-policy/preview', body);
}

/** GET /api/workbench/risk-policy/rejudgements — 获取阈值配置自动重判任务状态与历史，供前端轮询 */
export function workbenchRiskPolicyRejudgementsList<T = WorkbenchRiskPolicyRejudgementsListResponse>(): Promise<T> {
  return request<T>("GET", '/api/workbench/risk-policy/rejudgements', undefined);
}

/** GET /api/workbench/risk-policy/versions — 获取阈值配置版本与变更审计列表 */
export function workbenchRiskPolicyVersionsList<T = WorkbenchRiskPolicyVersionsListResponse>(): Promise<T> {
  return request<T>("GET", '/api/workbench/risk-policy/versions', undefined);
}
