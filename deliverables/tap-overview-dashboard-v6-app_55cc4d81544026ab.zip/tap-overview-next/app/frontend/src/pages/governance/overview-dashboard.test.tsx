import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { GovernanceOverview, OverviewDashboard, QuotaOverview, RevenueDistribution, WeeklyPlot } from "./overview-dashboard";
const api = vi.hoisted(() => vi.fn());
vi.mock("./api", () => ({ workbenchApi: api }));
const names = ["ST", "HT", "BT", "ET"], sourceTiers = ["strategic_trust", "high_trust", "building_trust", "emerging_trust"];
const window = { start_date: "2026-10-01", end_date: "2026-10-26", region: "Global", revision: 1 };
const source = { rid: 2883029, sid: 1139137, app_id: 800414 };
const metric = { module: "revenue", status: "available", window, queried_at: "fixture", source, diagnostics: {}, rows: names.map((tier, i) => ({ tier, source_tier: sourceTiers[i], revenue: (i + 1) * 10, share: (i + 1) * 10 })), summary: { revenue: 100 } };
const account = { status: "available", requested_end_date: "2026-10-26", data_as_of: "2026-10-25", region: "Global", tier_membership_total: 100, queried_at: "fixture", attempts: 2, source, diagnostics: {}, rows: names.map((tier, i) => ({ tier, source_tier: sourceTiers[i], account_count: (i + 1) * 10, account_share: (i + 1) * 10 })) };

function answer(path: string) {
  const u = new URL(path, "https://fixture.test");
  const w = { start_date: u.searchParams.get("start_date") || "", end_date: u.searchParams.get("end_date") || "", region: u.searchParams.get("region") || "Global" };
  if (u.pathname.endsWith("/accounts")) return { data: { ...account, region: w.region } };
  if (u.pathname.endsWith("/quota")) return { data: { window: w, quarters: [], queried_at: "fixture" } };
  if (u.pathname.endsWith("/governance")) return { data: { status: "not_connected", reason: "未连接权威事件", window: w } };
  if (u.pathname.endsWith("/p0")) return { data: { ...metric, window: w, module: "p0", rows: [{ ccr: 123.45, nfs: 500 }], summary: { ccr: 123.45, nfs: 500 } } };
  if (u.pathname.endsWith("/approval")) return { data: { ...metric, window: w, rows: names.map(tier => ({ tier, approval_rate: .975 })), summary: {} } };
  if (u.pathname.endsWith("-weekly")) return { data: { ...metric, window: w, rows: [{ tier: "ST", week: "2026-10-19", ccr: 2, nfs: 10 }], summary: {} } };
  return { data: { ...metric, window: w } };
}

beforeEach(() => { api.mockReset(); api.mockImplementation(async path => answer(path)); });
afterEach(cleanup);

it("loads nothing until Apply, sends dates/Region only, and defers optional P1", async () => {
  history.replaceState(null, "", "/?tier=ET&submitter=person&program=THT");
  render(<OverviewDashboard />);
  expect(api).not.toHaveBeenCalled();
  fireEvent.change(screen.getByLabelText("总览开始日期"), { target: { value: "2026-10-01" } });
  fireEvent.change(screen.getByLabelText("总览结束日期"), { target: { value: "2026-10-26" } });
  fireEvent.change(screen.getByLabelText("总览区域"), { target: { value: "APAC" } });
  fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
  await waitFor(() => expect(api).toHaveBeenCalledTimes(7));
  for (const call of api.mock.calls) {
    const q = new URL(call[0], "https://fixture.test").searchParams;
    expect(Object.fromEntries(q)).toEqual({ start_date: "2026-10-01", end_date: "2026-10-26", region: "APAC" });
    expect(call[0]).not.toMatch(/risk-scans|\/notify|st-snapshots/);
  }
  expect(api.mock.calls.some(c => c[0].includes("p1-weekly"))).toBe(false);
  fireEvent.click(screen.getByRole("button", { name: "展开 P1 周度指标" }));
  await waitFor(() => expect(api).toHaveBeenCalledTimes(8));
  history.replaceState(null, "", "/");
});

it("one failed report does not hide successful modules or fake zero", async () => {
  api.mockImplementation(async path => { if (path.includes("metrics/revenue")) throw Error("fixture report permission denied"); return answer(path); });
  render(<OverviewDashboard />); fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
  expect(await screen.findByText("fixture report permission denied")).toBeTruthy();
  await waitFor(() => expect(screen.getAllByText("123.45").length).toBeGreaterThan(0));
  expect(screen.getByRole("img", { name: /ST 10.0%/ })).toBeTruthy();
  expect(screen.getByText("未连接权威事件")).toBeTruthy();
});

it("edits remain unapplied, and old responses cannot overwrite a newly applied scope", async () => {
  const old: Array<(value: unknown) => void> = [];
  api.mockImplementationOnce(() => new Promise(resolve => old.push(resolve))).mockImplementationOnce(() => new Promise(resolve => old.push(resolve)));
  render(<OverviewDashboard />); fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
  expect(api).toHaveBeenCalledTimes(2);
  const signals = api.mock.calls.map(c => c[2] as AbortSignal);
  fireEvent.change(screen.getByLabelText("总览区域"), { target: { value: "CNOB" } });
  expect(screen.getByText(/筛选条件尚未应用/)).toBeTruthy();
  expect(api).toHaveBeenCalledTimes(2);
  fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
  await waitFor(() => expect(api).toHaveBeenCalledTimes(9));
  expect(signals.every(s => s.aborted)).toBe(true);
  old.forEach(resolve => resolve({ data: { ...account, data_as_of: "1999-01-01" } }));
  await waitFor(() => expect(screen.queryByText("1999-01-01")).toBeNull());
});

it("partial Revenue data shows values without a misleading donut or shares", () => {
  render(<RevenueDistribution state={{ loading: false, data: { ...metric, status: "partial", rows: metric.rows.slice(0, 3).map(r => ({ ...r, share: null })), summary: {}, reason: "四Tier不完整" } }} />);
  expect(screen.getByText("四Tier不完整")).toBeTruthy();
  expect(screen.queryByRole("img")).toBeNull();
  expect(screen.getAllByText("—").length).toBeGreaterThan(0);
});

it("missing calendar weeks break the line and are not zero-filled", () => {
  const data = { ...metric, rows: [{ tier: "ST", week: "2026-10-05", ccr: 2 }, { tier: "ST", week: "2026-10-19", ccr: 4 }] };
  render(<WeeklyPlot data={data} field="ccr" label="CCR test" />);
  const svg = screen.getByRole("img");
  expect(svg.querySelectorAll("circle").length).toBe(2);
  const path = svg.querySelector("path")!.getAttribute("d")!;
  expect((path.match(/M/g) || []).length).toBe(2);
  expect(path).not.toContain("L");
});

it("Quota shows separate quarter and unit plus negative remaining and N/A", () => {
  const q = { used: 12, quota: 10, ratio: 120, remaining: -2 };
  render(<QuotaOverview state={{ loading: false, data: { window, queried_at: "fixture", quarters: [{ quarter: "2026 Q4", status: "partial", start_date: "2026-10-01", end_date: "2026-10-26", et: q, st: { used: null, quota: 817, ratio: null, remaining: null }, regions: [{ region: "APAC", et: q, st: { used: null, quota: 240, ratio: null, remaining: null } }] }] } }} />);
  expect(screen.getByRole("button", { name: "2026 Q4" })).toBeTruthy();
  expect(screen.getByText("Account")).toBeTruthy(); expect(screen.getByText("Brand")).toBeTruthy();
  expect(screen.getAllByText("-2").length).toBeGreaterThan(0); expect(screen.getAllByText("N/A").length).toBeGreaterThan(0);
});

it("disconnected governance does not display invented zero counters", () => {
  render(<GovernanceOverview state={{ loading: false, data: { status: "not_connected", reason: "Cloud facts not connected" } }} />);
  expect(screen.getByText("Cloud facts not connected")).toBeTruthy();
  expect(screen.queryByText("0")).toBeNull();
});

it("query export contains the applied scope, not new draft filters", async () => {
  let exported: Blob | undefined;
  const oldCreate = URL.createObjectURL, oldRevoke = URL.revokeObjectURL;
  URL.createObjectURL = vi.fn(blob => { exported = blob as Blob; return "blob:fixture"; }); URL.revokeObjectURL = vi.fn();
  const click = vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => undefined);
  try {
    render(<OverviewDashboard />); fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
    await waitFor(() => expect(api).toHaveBeenCalledTimes(7));
    fireEvent.change(screen.getByLabelText("总览区域"), { target: { value: "CNOB" } });
    fireEvent.click(screen.getByRole("button", { name: "下载本次查询记录" }));
    expect(exported).toBeTruthy();
    const text = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsText(exported!); });
    const value = JSON.parse(text); expect(value.applied_filters.region).toBe("Global"); expect(text).not.toContain("Byte-Cloud-JWT");
  } finally { URL.createObjectURL = oldCreate; URL.revokeObjectURL = oldRevoke; click.mockRestore(); }
});


it("preserves a Sunday source week anchor instead of dropping returned points", () => {
  const data = { ...metric, rows: [{ tier: "ST", week: "2026-10-04", ccr: 2 }, { tier: "ST", week: "2026-10-18", ccr: 4 }] };
  render(<WeeklyPlot data={data} field="ccr" label="Sunday source" />);
  const svg = screen.getByRole("img");
  expect(svg.querySelectorAll("circle").length).toBe(2);
  expect((svg.querySelector("path")!.getAttribute("d")!.match(/M/g) || []).length).toBe(2);
});
