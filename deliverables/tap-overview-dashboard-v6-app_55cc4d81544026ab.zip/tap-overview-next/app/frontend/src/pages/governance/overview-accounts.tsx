import { useEffect, useRef, useState } from "react";
import { workbenchApi } from "./api";
import "./overview-accounts.css";

export type AccountDistributionData = {
  status: "available" | "partial" | "unavailable" | "no_data";
  reason?: string;
  requested_end_date: string;
  data_as_of: string;
  region: string;
  tier_membership_total: number | null;
  rows: { tier: string; source_tier: string; account_count: number | null; account_share: number | null }[];
  queried_at: string;
  attempts: number;
  diagnostics: Record<string, unknown>;
  source: { rid: number; sid: number; app_id: number };
};
const tiers = ["ST", "HT", "BT", "ET"];
const colors = ["#21988b", "#437ee8", "#8b71d6", "#eba34a"];
const regions = ["Global", "APAC", "CNOB", "EUI", "LATAM", "METAP", "NA", "NEA", "GA", "Scaled Growth", "SMB", "Other"];
const today = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
const number = (n: number | null | undefined) => n == null ? "—" : n.toLocaleString("en-US");

export type AccountExternalState = { data?: AccountDistributionData; loading: boolean; error?: string };
export function AccountDistribution({ external }: { external?: AccountExternalState } = {}) {
  const [end, setEnd] = useState(today);
  const [region, setRegion] = useState("Global");
  const [localData, setData] = useState<AccountDistributionData>();
  const data = external ? external.data : localData;
  const [localLoading, setLoading] = useState(false);
  const loading = external ? external.loading : localLoading;
  const [localError, setError] = useState("");
  const error = external ? external.error || "" : localError;
  const sequence = useRef(0);
  const active = useRef<AbortController | undefined>(undefined);
  useEffect(() => () => { sequence.current++; active.current?.abort(); }, []);
  function invalidate() {
    sequence.current++; active.current?.abort(); setLoading(false); setData(undefined); setError("");
  }
  async function apply() {
    if (!end || end > today()) { setError("请选择不晚于今天的截止日期。"); return; }
    active.current?.abort();
    const controller = new AbortController(); active.current = controller;
    const current = ++sequence.current;
    setLoading(true); setError(""); setData(undefined);
    try {
      const query = new URLSearchParams({ end_date: end, region });
      const response = await workbenchApi<{ data: AccountDistributionData }>(`/api/overview/accounts?${query}`, undefined, controller.signal);
      if (sequence.current === current) setData(response.data);
    } catch (e) {
      if (sequence.current === current && !controller.signal.aborted) setError(e instanceof Error ? e.message : "账户分布查询失败，请重试。");
    } finally { if (sequence.current === current) setLoading(false); }
  }
  const complete = data?.status === "available" && data.rows.length === 4 && data.rows.every(row => row.account_share != null);
  let angle = 0;
  const segments = complete ? data.rows.map((row, i) => {
    const from = angle; angle += row.account_share! * 3.6;
    return `${colors[tiers.indexOf(row.tier)] || colors[i]} ${from}deg ${angle}deg`;
  }) : [];
  return <section className="ov-accounts" aria-label="TAP Account 分布" data-testid="overview-accounts">
    <div className="ov-section-head"><div><p className="ov-eyebrow">BUSINESS SNAPSHOT</p><h2>TAP 账户分布</h2><p>查看四个 TAP Tier 的账户数量与占比</p></div><span className="ov-source-badge">Account · 快照</span></div>
    {!external && <form className="ov-filters" onSubmit={e => { e.preventDefault(); void apply(); }}>
      <label>截止日期<input aria-label="账户快照截止日期" type="date" value={end} max={today()} required onChange={e => { invalidate(); setEnd(e.target.value); }} /></label>
      <label>Customer Region<select aria-label="账户分布区域" value={region} onChange={e => { invalidate(); setRegion(e.target.value); }}>{regions.map(r => <option key={r} value={r}>{r}</option>)}</select></label>
      <button type="submit" disabled={loading}>{loading ? "正在查询…" : "应用筛选"}</button>
      <span>本图独立应用截止日期和区域，始终展示完整四 Tier 分布。</span>
    </form>}
    <div aria-live="polite">
      {error && <div className="ov-notice ov-error" role="alert">{error}<p>可重试查询；失败不会按 0 展示。</p></div>}
      {loading && <div className="ov-placeholder" role="status">正在查找最近账户快照…<small>最多回看 14 天；查询较慢时可修改条件取消本次请求。</small></div>}
      {!data && !loading && !error && <div className="ov-placeholder">选择时间和区域，点击“应用筛选”加载真实数据。<small>数据来自风神保存报表；打开本模块不会触发预警扫描。</small></div>}
      {data && <>
        {data.reason && <div className="ov-notice" role="status">{data.reason}</div>}
        <div className="ov-result-meta"><span>区域 <b>{data.region}</b></span><span>快照日期 <b>{data.data_as_of || "不可用"}</b></span><span>状态 <b>{{ available: "已返回", partial: "部分数据", unavailable: "暂不可用", no_data: "无快照" }[data.status]}</b></span></div>
        <div className="ov-chart-grid">
          <div className="ov-donut-wrap">
            {complete ? <div className="ov-donut" role="img" aria-label={data.rows.map(row => `${row.tier} ${row.account_share!.toFixed(1)}%`).join("，")} style={{ background: `conic-gradient(${segments.join(",")})` }}><div><span>四 Tier 数量合计</span><strong>{number(data.tier_membership_total)}</strong><small>Account</small></div></div> : <div className="ov-chart-empty"><strong>占比暂不可用</strong><span>完整、有效且合计大于 0 时展示</span></div>}
            <p className="ov-denominator">占比分母为四 Tier 数量合计；不是经验证的跨 Tier 去重客户总数。</p>
          </div>
          <div className="ov-table-wrap"><table><caption>Account Count & Share</caption><thead><tr><th scope="col">TAP Tier</th><th scope="col">Account Count</th><th scope="col">Account Share</th></tr></thead><tbody>{data.rows.map(row => <tr key={row.tier}><th scope="row"><i style={{ background: colors[tiers.indexOf(row.tier)] }} />{row.tier}<small>{row.source_tier}</small></th><td>{number(row.account_count)}</td><td>{row.account_share == null ? "—" : `${row.account_share.toFixed(1)}%`}</td></tr>)}</tbody></table></div>
        </div>
        <details className="ov-diagnostics"><summary>数据来源与查询诊断</summary><p>Saved Report {data.source.rid} · App {data.source.app_id} · SID {data.source.sid}</p><p>请求截止日 {data.requested_end_date} · 查询日数 {data.attempts} · 查询时间 {data.queried_at}</p><pre>{JSON.stringify(data.diagnostics, null, 2)}</pre></details>
      </>}
    </div>
    <footer className="ov-footnote">取不晚于截止日的最近有数快照，最多回看 14 天。每日账户数不累加，缺失值不补零。</footer>
  </section>;
}

export function OverviewTrialPage() {
  return <main className="ov-trial-page"><header><span className="ov-brand-mark">T</span><div><p className="ov-eyebrow">TAP GOVERNANCE</p><h1>数据总览 / Overview</h1></div><span className="ov-trial-label">账户分布验证版</span></header><AccountDistribution /></main>;
}
