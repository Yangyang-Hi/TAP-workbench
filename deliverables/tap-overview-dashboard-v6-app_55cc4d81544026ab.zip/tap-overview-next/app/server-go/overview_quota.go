package main

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"
)

// Keep the existing ET ticket query, ST snapshot reader and Quota aggregator.
// Overview adds quarter selection and presentation; it never syncs a Sheet,
// starts scans or creates Quota alerts.
var overviewETQuotaRows = quotaAeolusRows
var overviewSTQuotaRows = loadSTFromSnapshot

func overviewQuarterStarts(f overviewFilter) []time.Time {
	start, _ := time.Parse("2006-01-02", f.Start)
	end, _ := time.Parse("2006-01-02", f.End)
	first := time.Date(start.Year(), time.Month((int(start.Month())-1)/3*3+1), 1, 0, 0, 0, 0, time.UTC)
	out := []time.Time{}
	for q := first; !q.After(end); q = q.AddDate(0, 3, 0) {
		out = append(out, q)
	}
	return out
}

func overviewQuotaMetric(metric map[string]any) map[string]any {
	out := cloneMap(metric)
	used, uok := number(out["used"])
	quota, qok := number(out["quota"])
	if uok && qok {
		out["remaining"] = quota - used
	} else {
		out["remaining"] = nil
	}
	return out
}

func overviewQuotaHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	f, err := overviewParseWindow(r.URL.Query())
	if err != nil {
		writeJSON(w, 400, map[string]any{"error": err.Error()})
		return
	}
	baseline, err := loadQuotaBaseline()
	if err != nil {
		writeJSON(w, 503, map[string]any{"error": "Quota 基线配置不可读取。"})
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()
	quarters := []map[string]any{}
	for _, start := range overviewQuarterStarts(f) {
		q := fmt.Sprintf("Q%d", (int(start.Month())-1)/3+1)
		period := fmt.Sprintf("%d %s", start.Year(), q)
		end := start.AddDate(0, 3, -1).Format("2006-01-02")
		if end > f.End {
			end = f.End
		}
		item := map[string]any{"quarter": period, "start_date": start.Format("2006-01-02"), "end_date": end, "basis": "ET季度起点至截止日；ST季度名单快照", "status": "unavailable", "regions": []any{}, "et": nil, "st": nil}
		// The inherited ST snapshot keys are Q3/Q4 without a year. Never reuse
		// them or a 2026 baseline for an arbitrary historical/future year.
		if !strings.Contains(baseline.Period, fmt.Sprint(start.Year())) || (q != "Q3" && q != "Q4") {
			item["reason"] = "该年份或季度尚无已配置的配额/名单来源，未复用其他年份数据。"
			quarters = append(quarters, item)
			continue
		}
		sources := quotaSourceResult{Status: "partial", SourceStatus: map[string]string{"ET": "failed", "ST": "failed", "THT": "failed"}, Diagnostics: map[string]map[string]any{}, Errors: map[string]string{}}
		request := r.Clone(ctx)
		u := *r.URL
		u.RawQuery = ""
		request.URL = &u
		request.Form = nil
		request.PostForm = nil
		et, e := overviewETQuotaRows(ctx, request, "et_quota_tickets", "ET", start.Format("2006-01-02"), end)
		if e == nil {
			sources.ET = et.Rows
			sources.SourceStatus["ET"] = "available"
		} else {
			sources.Errors["ET"] = sanitizeAuditText(e.Error())
		}
		sources.Diagnostics["ET"] = et.Diagnostic
		st, meta, e := overviewSTQuotaRows(q)
		if e == nil {
			sources.ST = st
			sources.SourceStatus["ST"] = "available"
			sources.AsOf = asString(meta["synced_at"])
		} else {
			sources.Errors["ST"] = sanitizeAuditText(e.Error())
		}
		data := aggregateQuota(baseline, sources, q)
		global, _ := data["global"].(map[string]any)
		regionRows, _ := data["regions"].([]map[string]any)
		selected := global
		displayRows := []map[string]any{}
		for _, row := range regionRows {
			if f.Region != "Global" && asString(row["region"]) != f.Region {
				continue
			}
			next := map[string]any{"region": row["region"]}
			for _, key := range []string{"et", "st"} {
				if m, ok := row[key].(map[string]any); ok {
					next[key] = overviewQuotaMetric(m)
				}
			}
			displayRows = append(displayRows, next)
			if f.Region != "Global" {
				selected = row
			}
		}
		if f.Region != "Global" && len(displayRows) == 0 {
			item["reason"] = "此 Sales Region 与配额区域口径尚无已验证映射，未合并其他区域。"
			quarters = append(quarters, item)
			continue
		}
		for _, key := range []string{"et", "st"} {
			if m, ok := selected[key].(map[string]any); ok {
				item[key] = overviewQuotaMetric(m)
			}
		}
		item["regions"], item["source_status"], item["st_snapshot_at"], item["errors"], item["warnings"] = displayRows, sources.SourceStatus, sources.AsOf, sources.Errors, baseline.Warnings
		item["diagnostics"] = map[string]any{"et": et.Diagnostic, "baseline_period": baseline.Period}
		item["status"] = "available"
		if sources.SourceStatus["ET"] != "available" || sources.SourceStatus["ST"] != "available" {
			item["status"] = "partial"
		}
		quarters = append(quarters, item)
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"window": f, "quarters": quarters, "queried_at": time.Now().UTC().Format(time.RFC3339), "side_effects": false, "scope": "ET Account / ST Brand；分季度，独立于Program和Submitter筛选"}})
}
