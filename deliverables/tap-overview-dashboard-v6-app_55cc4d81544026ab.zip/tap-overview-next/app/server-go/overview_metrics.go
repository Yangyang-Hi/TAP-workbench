package main

// Read-only extensions of the proven Account Saved Report path. Source formulas
// stay in Aeolus. These profiles are NOT added to scan/sync configuration.
import (
	"context"
	"fmt"
	"math"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"
)

type overviewMetricProfile struct {
	Key, Source, Label       string
	RID, AppID, SID          int
	DateID, RegionID, TierID string
	Metrics                  map[string][]string
	ByTier, Weekly, Online   bool
}

func overviewMetricProfiles() map[string]overviewMetricProfile {
	base := overviewMetricProfile{AppID: 800414, SID: 1139137, DateID: "10000003854360", RegionID: "10000016013001", TierID: "10000013113546"}
	revenue := base
	revenue.Key = "revenue"
	revenue.RID = 2883029
	revenue.Label = "Revenue 分布"
	revenue.ByTier = true
	revenue.Metrics = map[string][]string{"revenue": {"revenue"}}
	p0 := base
	p0.Key = "p0"
	p0.RID = 2891879
	p0.Label = "P0 CCR / NFS"
	p0.Online = true
	p0.Metrics = map[string][]string{"ccr": {"p0_ccr", "dynamic_p0_ccr", "Dynamic P0 Content CCR", "10000000032693"}, "nfs": {"p0_nfs", "P0: Negative Feedback Show", "10000000032674"}}
	weekly := p0
	weekly.Key = "p0-weekly"
	weekly.RID = 2883040
	weekly.Label = "P0 周度趋势"
	weekly.ByTier = true
	weekly.Weekly = true
	p1 := weekly
	p1.Key = "p1-weekly"
	p1.RID = 2883016
	p1.Label = "P1 周度趋势"
	p1.Metrics = map[string][]string{"ccr": {"p1_ccr", "dynamic_p1_ccr", "Dynamic P1 Content CCR"}, "nfs": {"p1_nfs", "P1: Negative Feedback Show"}}
	approval := overviewMetricProfile{Key: "approval", RID: 2893221, AppID: 555138, SID: 642402, Label: "Approval Rate", DateID: "1700008351638", RegionID: "10000016013722", TierID: "10000013681491", ByTier: true, Metrics: map[string][]string{"approval_rate": {"Approval Rate", "approval_rate"}}}
	out := map[string]overviewMetricProfile{}
	for _, p := range []overviewMetricProfile{revenue, p0, weekly, p1, approval} {
		p.Source = "overview_metric_" + p.Key
		out[p.Key] = p
	}
	return out
}

func overviewMetricSource(name string) (overviewMetricProfile, bool) {
	for _, p := range overviewMetricProfiles() {
		if p.Source == name {
			return p, true
		}
	}
	return overviewMetricProfile{}, false
}

func (p overviewMetricProfile) config() sourceConfig {
	return sourceConfig{Kind: "aggregate", Grain: "overview_native_aggregate", Enabled: true, AppID: p.AppID, SID: p.SID, RID: p.RID,
		Identity:            sourceIdentity{AppID: p.AppID, SID: p.SID, RID: p.RID, Region: "sg", QueryMode: "aggregate"},
		SupportedDimensions: []string{"date", "region", "client_tier"}, Fields: map[string]fieldConfig{
			"p_date":      {DimMetID: p.DateID, UniqueID: p.DateID, SourceName: "p_date", ExpectedType: "date"},
			"region":      {DimMetID: p.RegionID, UniqueID: p.RegionID, SourceName: "Sales region-8.6"},
			"client_tier": {DimMetID: p.TierID, UniqueID: p.TierID, SourceName: "tier_v3_name"},
		}}
}

func overviewKnownIDs(raw any) map[string]bool {
	ids := map[string]bool{}
	var walk func(any)
	walk = func(v any) {
		switch n := v.(type) {
		case map[string]any:
			for _, key := range []string{"id", "originId", "datasetFieldId", "dimMetId"} {
				if s := contractIDString(n[key]); s != "" {
					ids[s] = true
				}
			}
			for _, child := range n {
				walk(child)
			}
		case []any:
			for _, child := range n {
				walk(child)
			}
		}
	}
	walk(raw)
	return ids
}

// Replace user-controlled date/Region/Tier predicates only. No metric formula,
// approval exclusion, source relation or other fixed predicate is reconstructed.
func overviewMetricChart(raw, chart map[string]any, p overviewMetricProfile, f filterRequest) (map[string]any, error) {
	ids := overviewKnownIDs(raw)
	for semantic, id := range map[string]string{"date": p.DateID, "tier": p.TierID, "region": p.RegionID} {
		if semantic == "region" && f.Region == "" {
			continue
		}
		if !ids[id] {
			return nil, fmt.Errorf("overview %s: Saved Report lacks documented %s field %s", p.Key, semantic, id)
		}
	}
	filters := []any{map[string]any{"type": "whereDate", "datasetFieldId": p.DateID, "uniqueId": p.DateID, "detail": map[string]any{"startTime": map[string]any{"type": "fixed", "date": f.StartDate + " 00:00:00"}, "endTime": map[string]any{"type": "fixed", "date": f.EndDate + " 23:59:59"}, "dateMode": "calendar_days", "dateNullOption": "nonNull"}}, aeolusFilter(p.TierID, p.TierID, "IN", overviewTierKeys)}
	if f.Region != "" {
		filters = append(filters, aeolusFilter(p.RegionID, p.RegionID, "IN", []string{f.Region}))
	}
	if p.Online {
		if !ids["10000000032606"] {
			return nil, fmt.Errorf("overview %s: is_online field contract unavailable", p.Key)
		}
		filters = append(filters, aeolusFilter("10000000032606", "10000000032606", "IN", []string{"1"}))
	}
	out := cloneMap(chart)
	out["filters"] = filters
	return out, nil
}

// Reaggregate with the source's native measures. A total CCR must not be an
// average of per-Region/per-Tier CCRs. Keep the report's week expression intact.
func overviewMetricRequest(raw map[string]any, p overviewMetricProfile, f filterRequest) map[string]any {
	body := cloneMap(raw)
	q, _ := body["query"].(map[string]any)
	where, _ := q["whereList"].([]any)
	kept := []any{}
	for _, item := range where {
		n, _ := item.(map[string]any)
		id := firstNonEmpty(n, "id", "datasetFieldId", "fieldId", "originId")
		if f.Region == "" && id == p.RegionID {
			continue
		}
		kept = append(kept, item)
	}
	q["whereList"] = kept
	remove := map[string]bool{p.RegionID: true}
	if !p.ByTier {
		remove[p.TierID] = true
	}
	if !p.Weekly {
		remove[p.DateID] = true
	}
	fieldID := func(v any) string {
		if n, ok := v.(map[string]any); ok {
			return firstNonEmpty(n, "datasetFieldId", "dimMetId", "id", "originId")
		}
		return contractIDString(v)
	}
	for _, key := range []string{"dimensions", "groupByIdList"} {
		if items, ok := q[key].([]any); ok {
			next := []any{}
			for _, item := range items {
				if !remove[fieldID(item)] {
					next = append(next, item)
				}
			}
			q[key] = next
		}
	}
	if locations, ok := q["locations"].(map[string]any); ok {
		if dims, ok := locations["dimensions"].([]any); ok {
			next := []any{}
			for _, d := range dims {
				if !remove[fieldID(d)] {
					next = append(next, d)
				}
			}
			locations["dimensions"] = next
		}
	}
	return body
}

func overviewCanonicalMetrics(raw []map[string]any, fieldMap map[string]string, p overviewMetricProfile) ([]map[string]any, error) {
	aliases := map[string][]string{}
	for k, v := range p.Metrics {
		aliases[k] = v
	}
	if p.ByTier {
		aliases["tier"] = []string{"tier_v3_name", "client_tier", "Tier V3", p.TierID}
	}
	if p.Weekly {
		aliases["week"] = []string{"week", "周"}
	}
	out := make([]map[string]any, 0, len(raw))
	for _, row := range raw {
		next := map[string]any{}
		for key, names := range aliases {
			matches := 0
			for col, value := range row {
				desc := strings.ToLower(col + " " + fieldMap[col])
				for _, alias := range names {
					if alias != "" && strings.Contains(desc, strings.ToLower(alias)) {
						matches++
						next[key] = value
						break
					}
				}
			}
			if matches != 1 {
				return nil, fmt.Errorf("overview %s mapping: %s matched %d columns", p.Key, key, matches)
			}
		}
		out = append(out, next)
	}
	return out, nil
}

type overviewFilter struct {
	Start  string `json:"start_date"`
	End    string `json:"end_date"`
	Region string `json:"region"`
}

func overviewParseWindow(v url.Values) (overviewFilter, error) {
	today := time.Now().In(cwLocation())
	end := v.Get("end_date")
	if end == "" {
		end = today.Format("2006-01-02")
	}
	start := v.Get("start_date")
	if start == "" {
		endDay, err := time.Parse("2006-01-02", end)
		if err != nil {
			return overviewFilter{}, fmt.Errorf("日期必须为有效的 YYYY-MM-DD")
		}
		start = time.Date(endDay.Year(), time.Month((int(endDay.Month())-1)/3*3+1), 1, 0, 0, 0, 0, cwLocation()).Format("2006-01-02")
	}
	for _, s := range []string{start, end} {
		d, e := time.Parse("2006-01-02", s)
		if e != nil || d.Format("2006-01-02") != s {
			return overviewFilter{}, fmt.Errorf("日期必须为有效的 YYYY-MM-DD")
		}
	}
	if start > end || end > today.Format("2006-01-02") {
		return overviewFilter{}, fmt.Errorf("开始日期不得晚于结束日期，结束日期不得晚于今天")
	}
	region := strings.TrimSpace(v.Get("region"))
	if region == "" || region == "all" {
		region = "Global"
	}
	if !containsString([]string{"Global", "APAC", "CNOB", "EUI", "LATAM", "METAP", "NA", "NEA", "GA", "Scaled Growth", "SMB", "Other"}, region) {
		return overviewFilter{}, fmt.Errorf("Region 不在已声明的 Sales Region 范围内")
	}
	return overviewFilter{start, end, region}, nil
}

type overviewMetricResult struct {
	Module      string           `json:"module"`
	Status      string           `json:"status"`
	Reason      string           `json:"reason,omitempty"`
	Window      overviewFilter   `json:"window"`
	Rows        []map[string]any `json:"rows"`
	Summary     map[string]any   `json:"summary"`
	Source      map[string]any   `json:"source"`
	Diagnostics map[string]any   `json:"diagnostics"`
	QueriedAt   string           `json:"queried_at"`
}

func overviewEmptyMetric(p overviewMetricProfile, f overviewFilter) overviewMetricResult {
	return overviewMetricResult{Module: p.Key, Status: "unavailable", Window: f, Rows: []map[string]any{}, Summary: map[string]any{}, Source: map[string]any{"rid": p.RID, "sid": p.SID, "app_id": p.AppID, "native_aggregation": true, "time_basis": "selected_interval", "tier_scope": "four_tap_tiers", "currency": "unconfirmed"}, Diagnostics: map[string]any{}, QueriedAt: time.Now().UTC().Format(time.RFC3339)}
}

func overviewMetricValues(o overviewMetricResult, p overviewMetricProfile, rows []map[string]any) overviewMetricResult {
	if len(rows) == 0 {
		o.Status = "no_data"
		o.Reason = "源报表在所选范围没有返回数据，未补为 0。"
		return o
	}
	if !p.ByTier && len(rows) != 1 {
		o.Reason = "源报表返回多行汇总，未平均或累加 CCR；请核对原生聚合维度。"
		return o
	}
	seen := map[string]bool{}
	valid := true
	total := 0.0
	for _, raw := range rows {
		r := map[string]any{}
		tier := strings.ToLower(strings.TrimSpace(asString(raw["tier"])))
		if p.ByTier {
			i := -1
			for j, k := range overviewTierKeys {
				if tier == k {
					i = j
					break
				}
			}
			if i < 0 {
				o.Reason = "源返回未知 Tier，未强行归类或计算占比。"
				return o
			}
			r["tier"] = overviewTierLabels[i]
			r["source_tier"] = tier
		}
		key := tier
		if p.Weekly {
			week := strings.TrimSpace(asString(raw["week"]))
			if week == "" || week == "NULL" {
				o.Reason = "周度来源缺少 week。"
				return o
			}
			r["week"] = week
			key = week + "|" + tier
		}
		if seen[key] {
			o.Reason = "同一维度返回重复聚合行，未进行二次累加或平均。"
			return o
		}
		seen[key] = true
		for metric := range p.Metrics {
			n, ok := number(raw[metric])
			if !ok || math.IsNaN(n) || math.IsInf(n, 0) {
				r[metric] = nil
				valid = false
				continue
			}
			if metric != "revenue" && n < 0 {
				r[metric] = nil
				valid = false
				continue
			}
			r[metric] = n
			if metric == "revenue" {
				total += n
			}
		}
		o.Rows = append(o.Rows, r)
	}
	o.Status = "available"
	if !valid {
		o.Status = "partial"
		o.Reason = "部分指标为 NULL 或无效值，未补零。"
	}
	if p.Key == "revenue" {
		if len(seen) != 4 || !valid {
			o.Status = "partial"
			o.Reason = "四 Tier 数据不完整，暂不计算总额与占比。"
			return o
		}
		if math.IsInf(total, 0) || math.IsNaN(total) {
			o.Status = "unavailable"
			o.Reason = "源数值合计超出安全计算范围。"
			return o
		}
		o.Summary["revenue"] = total
		canShare := total > 0
		for _, r := range o.Rows {
			if r["revenue"].(float64) < 0 {
				canShare = false
			}
		}
		for _, r := range o.Rows {
			r["share"] = nil
			if canShare {
				r["share"] = r["revenue"].(float64) / total * 100
			}
		}
		if !canShare {
			o.Reason = "总额非正或包含负营收，不生成误导性占比。"
		}
	}
	if !p.ByTier {
		for metric := range p.Metrics {
			o.Summary[metric] = o.Rows[0][metric]
		}
	}
	if p.Weekly {
		sort.Slice(o.Rows, func(i, j int) bool {
			return fmt.Sprint(o.Rows[i]["week"], o.Rows[i]["tier"]) < fmt.Sprint(o.Rows[j]["week"], o.Rows[j]["tier"])
		})
	}
	return o
}

func overviewMetricsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	p, ok := overviewMetricProfiles()[r.PathValue("metric")]
	if !ok {
		writeJSON(w, 404, map[string]any{"error": "unknown Overview metric"})
		return
	}
	f, err := overviewParseWindow(r.URL.Query())
	if err != nil {
		writeJSON(w, 400, map[string]any{"error": err.Error()})
		return
	}
	o := overviewEmptyMetric(p, f)
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()
	request := r.Clone(ctx)
	u := *r.URL
	q := url.Values{"start_date": {f.Start}, "end_date": {f.End}}
	if f.Region != "Global" {
		q.Set("region", f.Region)
	}
	u.RawQuery = q.Encode()
	request.URL = &u
	request.Form = nil
	request.PostForm = nil
	probe, err := overviewQueryReport(ctx, request, p.Source)
	if err != nil {
		o.Reason = "风神请求未完成，请用查询时间定位服务日志。"
		logMsg("overview_metric "+p.Key+": "+sanitizeAuditText(err.Error()), "plugin")
	} else {
		o.Diagnostics = map[string]any{"status": probe["status"], "audit_id": probe["audit_id"], "request_id": probe["requestId"], "log_id": probe["logId"], "blocked_stage": probe["blocked_stage"], "failure_classification": probe["failure_classification"], "columns": probe["columns"]}
		if asString(probe["status"]) != "ok" {
			o.Reason = "鉴权、报表合同或查询未通过，详见本模块诊断。"
		} else if asBool(probe["possibly_truncated"]) {
			o.Reason = "查询返回可能截断，未生成汇总。"
		} else if rows, ok := probe["business_rows"].([]map[string]any); ok {
			o = overviewMetricValues(o, p, rows)
		} else {
			o.Reason = "返回结构不符合已声明合同。"
		}
	}
	writeJSON(w, 200, map[string]any{"data": o})
}
