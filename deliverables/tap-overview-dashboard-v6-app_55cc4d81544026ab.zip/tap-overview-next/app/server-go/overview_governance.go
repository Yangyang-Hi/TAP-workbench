package main

import (
	"context"
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// These adapters read existing facts only. They do not initialize a database,
// mirror Cloud records to SQLite or reinterpret risk rules.
var overviewReadScans = func() (wbDisk, error) {
	s := wbDisk{Jobs: map[string]wbJob{}}
	dir, err := resolveDataDir()
	if err != nil {
		return s, err
	}
	f, err := os.Open(filepath.Join(dir, "tap_alert_workbench_v1.json"))
	if os.IsNotExist(err) {
		return s, nil
	}
	if err != nil {
		return s, err
	}
	defer f.Close()
	err = json.NewDecoder(f).Decode(&s)
	return s, err
}

type overviewSubmitter struct {
	Submitter string   `json:"submitter"`
	Total     int      `json:"total"`
	Pending   int      `json:"pending"`
	Progress  int      `json:"in_progress"`
	Closed    int      `json:"closed"`
	Unknown   int      `json:"unknown_status"`
	Notified  *int     `json:"notified_cases"`
	Rate      *float64 `json:"closure_rate"`
}

func overviewFormalSubmitterNotice(a cwCase, n cwNotice) bool {
	if n.CaseID != a.ID || n.Kind != "send" || n.Status != "sent" || n.MessageID == "" || n.NotificationMode != "formal" {
		return false
	}
	// A successful receipt to a test user/group/other owner does not prove
	// delivery to the original submitter. Only retain explicit recipient binding.
	email := strings.ToLower(strings.TrimSpace(n.TargetEmail))
	who := strings.ToLower(strings.TrimSpace(a.Row.Member.Submitter))
	if email == "" || who == "" {
		return false
	}
	return who == email || (!strings.Contains(who, "@") && who == strings.SplitN(email, "@", 2)[0])
}

func overviewCaseInScope(a cwCase, f overviewFilter, program, submitter string) bool {
	return a.Kind != "quota" && a.Window.Start != "" && a.Window.End != "" && a.Window.Start <= f.End && a.Window.End >= f.Start &&
		(f.Region == "Global" || a.Row.Member.Region == f.Region) && (program == "" || a.Row.Program == program) && (submitter == "" || a.Row.Member.Submitter == submitter)
}

func overviewGovernanceData(cases []cwCase, notices []cwNotice, scans wbDisk, f overviewFilter, program, submitter string, noticesOK bool) map[string]any {
	latest := map[string]cwCase{}
	for _, a := range cases {
		if old, ok := latest[a.ID]; !ok || a.Version > old.Version {
			latest[a.ID] = a
		}
	}
	byProgram, byRegion, byLevel, weekly := map[string]int{}, map[string]int{}, map[string]int{}, map[string]map[string]bool{}
	noticeByCase := map[string][]cwNotice{}
	for _, n := range notices {
		noticeByCase[n.CaseID] = append(noticeByCase[n.CaseID], n)
	}
	bySubmitter := map[string]*overviewSubmitter{}
	states := map[string]int{"pending": 0, "in_progress": 0, "closed": 0, "unknown": 0}
	total := 0
	latestUpdate := ""
	for _, a := range latest {
		if !overviewCaseInScope(a, f, program, submitter) {
			continue
		}
		total++
		if a.UpdatedAt > latestUpdate {
			latestUpdate = a.UpdatedAt
		}
		byProgram[a.Row.Program]++
		region := a.Row.Member.Region
		if region == "" {
			region = "未映射"
		}
		byRegion[region]++
		level := a.Row.Level
		if level != "critical" && level != "watch" {
			level = "unclassified"
		}
		byLevel[level]++
		week := a.Window.Start + " ~ " + a.Window.End
		if weekly[week] == nil {
			weekly[week] = map[string]bool{}
		}
		weekly[week][a.ID] = true
		name := strings.TrimSpace(a.Row.Member.Submitter)
		if name == "" {
			name = "未映射"
		}
		row := bySubmitter[name]
		if row == nil {
			row = &overviewSubmitter{Submitter: name}
			bySubmitter[name] = row
			if noticesOK {
				v := 0
				row.Notified = &v
			}
		}
		row.Total++
		switch a.Status {
		case "closed":
			states["closed"]++
			row.Closed++
		case "open":
			states["pending"]++
			row.Pending++
		case "processing", "observing", "pending_approval", "pending_review":
			states["in_progress"]++
			row.Progress++
		default:
			states["unknown"]++
			row.Unknown++
		}
		bound, uncertain := false, false
		for _, n := range noticeByCase[a.ID] {
			if overviewFormalSubmitterNotice(a, n) {
				bound = true
			}
			if n.CaseID == a.ID && n.Kind == "send" && n.Status == "sent" && n.MessageID != "" && n.NotificationMode == "formal" && !overviewFormalSubmitterNotice(a, n) {
				uncertain = true
			}
		}
		if noticesOK {
			if bound && row.Notified != nil {
				*row.Notified++
			} else if uncertain {
				row.Notified = nil
			}
		}
	}
	people := []overviewSubmitter{}
	for _, r := range bySubmitter {
		if r.Total > 0 {
			v := float64(r.Closed) * 100 / float64(r.Total)
			r.Rate = &v
		}
		people = append(people, *r)
	}
	sort.Slice(people, func(i, j int) bool { return people[i].Submitter < people[j].Submitter })
	trend := []map[string]any{}
	for window, ids := range weekly {
		trend = append(trend, map[string]any{"window": window, "events": len(ids)})
	}
	sort.Slice(trend, func(i, j int) bool { return asString(trend[i]["window"]) < asString(trend[j]["window"]) })
	pool, risks := map[string]bool{}, map[string]bool{}
	coverage := map[string]string{"ET": "not_scanned", "ST": "not_scanned", "THT": "not_scanned"}
	selected := map[string]wbJob{}
	for _, j := range scans.Jobs {
		if j.Request.Start > f.End || j.Request.End < f.Start || j.Request.Start == "" || (program != "" && j.Request.Program != program) {
			continue
		}
		if f.Region != "Global" && j.Request.Region != "" && j.Request.Region != "Global" && j.Request.Region != "all" && j.Request.Region != f.Region {
			continue
		}
		key := j.Principal + "|" + j.Request.Program + "|" + j.Request.Start + "|" + j.Request.End + "|" + j.Request.Region
		if old, ok := selected[key]; !ok || j.StartedAt > old.StartedAt {
			selected[key] = j
		}
	}
	for _, j := range selected {
		state := "partial"
		globalCovered := f.Region != "Global" || j.Request.Region == "" || j.Request.Region == "Global" || j.Request.Region == "all"
		if globalCovered && j.Complete && (j.Status == "ready" || j.Status == "available") {
			state = "complete"
		}
		if coverage[j.Request.Program] != "partial" {
			coverage[j.Request.Program] = state
		}
		for _, row := range j.Rows {
			if f.Region != "Global" && row.Member.Region != f.Region || submitter != "" && row.Member.Submitter != submitter {
				continue
			}
			pool[wbCustomerKey(row)] = true
			if wbMatched(row) {
				risks[wbCustomerKey(row)] = true
			}
		}
	}
	var riskCount, scannedCount any
	if len(selected) > 0 {
		riskCount = len(risks)
		scannedCount = len(pool)
	}
	return map[string]any{"status": "available", "window": f, "alert_events": total, "risk_subjects": riskCount, "evaluated_subjects": scannedCount, "coverage": coverage, "by_program": byProgram, "by_region": byRegion, "by_level": byLevel, "weekly": trend, "states": states, "submitters": people, "updated_at": latestUpdate, "queried_at": time.Now().UTC().Format(time.RFC3339), "notification_binding": "仅正式成功回执且可核实原提报人邮箱/用户名；未知绑定显示不可用", "time_basis": "相交的已保存指标窗口；事件去重；处置取Cloud最新状态，关闭不等于指标改善", "risk_subject_basis": "已保存扫描，按Program+Account/Advertiser去重；混合主体粒度，缺失覆盖不作为0"}
}

func overviewGovernanceHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	f, err := overviewParseWindow(r.URL.Query())
	if err != nil {
		writeJSON(w, 400, map[string]any{"error": err.Error()})
		return
	}
	program := strings.ToUpper(strings.TrimSpace(r.URL.Query().Get("program")))
	if program != "" && !containsString([]string{"ET", "ST", "THT"}, program) {
		writeJSON(w, 400, map[string]any{"error": "Program 必须为 ET、ST 或 THT。"})
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 45*time.Second)
	defer cancel()
	blocked := func(reason string) {
		writeJSON(w, 200, map[string]any{"data": map[string]any{"status": "not_connected", "reason": reason, "window": f, "side_effects": false}})
	}
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		blocked("此独立测试 App 尚未连接主工作台的权威事件；合并后复用原 Cloud Repository，不需要为业务图表复制数据库密钥。")
		return
	}
	cases, err := repo.listCases(ctx)
	if err != nil {
		logMsg("overview_governance cases: "+sanitizeAuditText(err.Error()), "plugin")
		blocked("权威事件读取失败，未回退本地旧镜像或显示为0。")
		return
	}
	config, err := cwLoadConfig()
	if err != nil {
		blocked("处置权限配置暂不可用。")
		return
	}
	authorized := []cwCase{}
	for _, a := range cases {
		if cwCanRead(config, a, requestUsername(r)) {
			authorized = append(authorized, a)
		}
	}
	notices, noticeErr := repo.listNotices(ctx)
	scans, scanErr := overviewReadScans()
	if scanErr != nil {
		scans = wbDisk{Jobs: map[string]wbJob{}}
	}
	if !cwOperator(config, requestUsername(r)) {
		visible := map[string]wbJob{}
		for id, j := range scans.Jobs {
			if j.Principal == requestUsername(r) {
				visible[id] = j
			}
		}
		scans.Jobs = visible
	}
	data := overviewGovernanceData(authorized, notices, scans, f, program, strings.TrimSpace(r.URL.Query().Get("submitter")), noticeErr == nil)
	data["source_status"] = map[string]bool{"cases": true, "notices": noticeErr == nil, "scan_cache": scanErr == nil}
	data["side_effects"] = false
	if noticeErr != nil || scanErr != nil {
		data["status"] = "partial"
		data["reason"] = "事件已返回；通知或扫描覆盖读取不完整。"
	}
	writeJSON(w, 200, map[string]any{"data": data})
}
