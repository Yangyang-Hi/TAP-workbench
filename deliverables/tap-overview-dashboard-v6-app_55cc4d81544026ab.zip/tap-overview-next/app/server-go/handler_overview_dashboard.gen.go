// CODE GENERATED FROM app/api/api.yaml BY tools/gen_api.py — DO NOT EDIT
package main

import "net/http"

// 本文件由 IDL 生成，登记 overview_dashboard 资源的路由契约。
// 业务逻辑写在 handler_overview_dashboard.go 的 handler 函数里，不要改本文件。
func init() {
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/overview/governance",
		Summary: "读取现有权威事件、通知及扫描事实生成治理汇总；未连接时明确不可用",
		Handler: overviewGovernanceList,
		Tags:    []string{"overview"},
		QueryParams: []Param{
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
			{Name: "program", Type: "string", Description: "可选ET/ST/THT，独立于TAP四Tier"},
			{Name: "submitter", Type: "string", Description: "可选原提报人精确匹配"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status":       "not_connected",
				"reason":       "",
				"window":       map[string]any{},
				"side_effects": false,
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/overview/metrics/{metric}",
		Summary: "只读查询 Revenue、P0、P1及Approval原生报表，不启动扫描或通知",
		Handler: overviewMetricsByMetricGet,
		Tags:    []string{"overview"},
		QueryParams: []Param{
			{Name: "start_date", Type: "string", Description: "区间开始日 YYYY-MM-DD，默认本季度起点"},
			{Name: "end_date", Type: "string", Description: "区间结束日 YYYY-MM-DD，默认今天"},
			{Name: "region", Type: "string", Description: "Sales Region，默认Global"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"module":      "",
				"status":      "unavailable",
				"reason":      "",
				"rows":        []any{},
				"summary":     map[string]any{},
				"source":      map[string]any{},
				"diagnostics": map[string]any{},
				"window":      map[string]any{},
				"queried_at":  "",
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/overview/quota",
		Summary: "复用已有ET账户和ST品牌配额聚合，按季度展示，不同步Sheet或建单",
		Handler: overviewQuotaList,
		Tags:    []string{"overview"},
		QueryParams: []Param{
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"window":       map[string]any{},
				"quarters":     []any{},
				"queried_at":   "",
				"side_effects": false,
			},
		},
	})
}
