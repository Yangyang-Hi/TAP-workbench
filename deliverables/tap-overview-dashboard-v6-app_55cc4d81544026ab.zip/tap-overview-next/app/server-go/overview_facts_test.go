package main

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

func TestOverviewQuotaReusesAccountBrandUnitsAndQuarterWindow(t *testing.T) {
	oldET, oldST, oldDir := overviewETQuotaRows, overviewSTQuotaRows, pluginDir
	pluginDir, _ = filepath.Abs("../..")
	t.Cleanup(func() { overviewETQuotaRows, overviewSTQuotaRows, pluginDir = oldET, oldST, oldDir })
	calls := 0
	overviewETQuotaRows = func(_ context.Context, _ *http.Request, source, program, start, end string) (quotaAeolusResult, error) {
		calls++
		if source != "et_quota_tickets" || program != "ET" || start != "2026-10-01" || end != "2026-10-26" {
			t.Fatal("Quota used weekly window or wrong source", source, program, start, end)
		}
		return quotaAeolusResult{Rows: []submissionMetric{{TicketID: "ticket-1", Region: "APAC", AccountIDs: []string{"account-1"}}, {TicketID: "ticket-2", Region: "APAC", AccountIDs: []string{"account-1"}}}}, nil
	}
	overviewSTQuotaRows = func(q string) ([]stMetric, map[string]any, error) {
		if q != "Q4" {
			t.Fatal(q)
		}
		return []stMetric{{Region: "APAC", Brand: "brand-1", AccountID: "a"}, {Region: "APAC", Brand: "brand-1", AccountID: "b"}}, map[string]any{"synced_at": "fixture"}, nil
	}
	w := httptest.NewRecorder()
	overviewQuotaHandler(w, httptest.NewRequest("GET", "/api/overview/quota?start_date=2026-10-19&end_date=2026-10-26&region=APAC", nil))
	if w.Code != 200 {
		t.Fatal(w.Code, w.Body.String())
	}
	var payload struct {
		Data struct {
			Quarters []map[string]any `json:"quarters"`
		} `json:"data"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &payload); err != nil {
		t.Fatal(err)
	}
	q := payload.Data.Quarters[0]
	et := q["et"].(map[string]any)
	st := q["st"].(map[string]any)
	if et["used"] != 1. || et["ticket_count"] != 2. || st["used"] != 1. || st["account_count"] != 2. || calls != 1 {
		t.Fatal("Quota unit changed", q)
	}
}

func TestOverviewQuotaNoHistoricalBaselineReuseOrFalseZero(t *testing.T) {
	oldET, oldST, oldDir := overviewETQuotaRows, overviewSTQuotaRows, pluginDir
	pluginDir, _ = filepath.Abs("../..")
	t.Cleanup(func() { overviewETQuotaRows, overviewSTQuotaRows, pluginDir = oldET, oldST, oldDir })
	overviewETQuotaRows = func(context.Context, *http.Request, string, string, string, string) (quotaAeolusResult, error) {
		t.Fatal("unsupported year queried source")
		return quotaAeolusResult{}, nil
	}
	overviewSTQuotaRows = func(string) ([]stMetric, map[string]any, error) {
		t.Fatal("unsupported year read Q-only snapshot")
		return nil, nil, nil
	}
	w := httptest.NewRecorder()
	overviewQuotaHandler(w, httptest.NewRequest("GET", "/api/overview/quota?start_date=2025-10-01&end_date=2025-10-26", nil))
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"status":"unavailable"`) || !strings.Contains(w.Body.String(), `"et":null`) {
		t.Fatal(w.Body.String())
	}
}

func TestOverviewQuotaRemainingPreservesOverage(t *testing.T) {
	m := overviewQuotaMetric(map[string]any{"used": 12, "quota": 10, "remaining": 0})
	if m["remaining"] != -2. {
		t.Fatal("remaining clamped to 0", m)
	}
	m = overviewQuotaMetric(map[string]any{"used": nil, "quota": 10})
	if m["remaining"] != nil {
		t.Fatal("failed usage treated as 0", m)
	}
}

func overviewCaseFixture(id, who, status string, version int) cwCase {
	return cwCase{ID: id, Kind: "customer", Status: status, Version: version, Window: wbRequest{Start: "2026-10-19", End: "2026-10-25"}, Row: wbRow{Program: "ET", Level: "critical", Member: wbMember{AccountID: "account-1", Region: "APAC", Submitter: who}}, UpdatedAt: "2026-10-26T00:00:00Z"}
}

func TestOverviewGovernanceUsesLatestCloudFactsAndReceiptDedup(t *testing.T) {
	a := overviewCaseFixture("alert-1", "person@example.com", "open", 1)
	closed := a
	closed.Status = "closed"
	closed.Version = 2
	b := overviewCaseFixture("alert-2", "other@example.com", "processing", 1)
	notices := []cwNotice{{ID: "n1", CaseID: a.ID, Kind: "send", Status: "sent", MessageID: "m1", NotificationMode: "formal", TargetEmail: "person@example.com"}, {ID: "n2", CaseID: a.ID, Kind: "send", Status: "sent", MessageID: "m2", NotificationMode: "formal", TargetEmail: "person@example.com"}, {ID: "test", CaseID: b.ID, Kind: "send", Status: "sent", MessageID: "test-message", NotificationMode: "test", TargetEmail: "other@example.com"}}
	f := overviewFilter{"2026-10-01", "2026-10-26", "APAC"}
	d := overviewGovernanceData([]cwCase{a, closed, b}, notices, wbDisk{}, f, "", "", true)
	if d["alert_events"] != 2 || d["states"].(map[string]int)["closed"] != 1 || d["states"].(map[string]int)["in_progress"] != 1 {
		t.Fatal(d)
	}
	for _, r := range d["submitters"].([]overviewSubmitter) {
		if r.Submitter == "person@example.com" && (*r.Notified != 1 || r.Closed != 1 || *r.Rate != 100) {
			t.Fatal(r)
		}
		if r.Submitter == "other@example.com" && *r.Notified != 0 {
			t.Fatal("test delivery counted as formal", r)
		}
	}
	if d["risk_subjects"] != nil {
		t.Fatal("no scan coverage shown as true0", d)
	}
}

func TestOverviewUnknownRecipientBindingAndStateStayExplicit(t *testing.T) {
	a := overviewCaseFixture("a", "人员甲", "unexpected", 1)
	n := cwNotice{CaseID: a.ID, Kind: "send", Status: "sent", MessageID: "m", NotificationMode: "formal", TargetEmail: "someone@example.com"}
	d := overviewGovernanceData([]cwCase{a}, []cwNotice{n}, wbDisk{}, overviewFilter{"2026-10-01", "2026-10-26", "APAC"}, "", "", true)
	r := d["submitters"].([]overviewSubmitter)[0]
	if r.Notified != nil || r.Unknown != 1 || d["states"].(map[string]int)["pending"] != 0 {
		t.Fatal(d, r)
	}
}

func TestOverviewGovernanceNoDatabaseRequiredForOtherCharts(t *testing.T) {
	old := cwCaseworkRepositoryProvider
	t.Cleanup(func() { cwCaseworkRepositoryProvider = old })
	cwCaseworkRepositoryProvider = func() (caseworkRepository, error) { return nil, errors.New("fixture: no Cloud credentials") }
	w := httptest.NewRecorder()
	overviewGovernanceHandler(w, httptest.NewRequest("GET", "/api/overview/governance?start_date=2026-10-01&end_date=2026-10-26", nil))
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"status":"not_connected"`) || strings.Contains(w.Body.String(), `"alert_events":0`) {
		t.Fatal(w.Code, w.Body.String())
	}
}

func TestOverviewEveryNewTrialEndpointRequiresAuth(t *testing.T) {
	oldID := appInstanceID
	appInstanceID = "fixture-instance"
	t.Cleanup(func() { appInstanceID = oldID })
	mux := overviewTrialMux()
	for _, path := range []string{"/api/overview/metrics/revenue", "/api/overview/metrics/p0", "/api/overview/quota", "/api/overview/governance"} {
		w := httptest.NewRecorder()
		mux.ServeHTTP(w, httptest.NewRequest("GET", path, nil))
		if w.Code != 401 {
			t.Fatal(path, w.Code)
		}
	}
	for _, path := range []string{"/api/monitoring/risk-scans", "/api/workbench/cases", "/api/integrations/feishu/card-callback"} {
		w := httptest.NewRecorder()
		mux.ServeHTTP(w, httptest.NewRequest("POST", path, nil))
		if w.Code != 404 {
			t.Fatal(path, w.Code)
		}
	}
}

func TestOverviewScanCoverageRespectsRegionScope(t *testing.T) {
	row := overviewCaseFixture("case", "person", "closed", 1).Row
	scans := wbDisk{Jobs: map[string]wbJob{"regional": {Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25", Region: "APAC"}, Rows: []wbRow{row}, Complete: true, Status: "ready"}}}
	f := overviewFilter{"2026-10-01", "2026-10-26", "CNOB"}
	data := overviewGovernanceData(nil, nil, scans, f, "", "", true)
	if data["risk_subjects"] != nil || data["coverage"].(map[string]string)["ET"] != "not_scanned" {
		t.Fatal("another Region was treated as zero risk coverage", data)
	}
	f.Region = "Global"
	data = overviewGovernanceData(nil, nil, scans, f, "", "", true)
	if data["coverage"].(map[string]string)["ET"] != "partial" {
		t.Fatal("regional scan claimed full Global coverage", data)
	}
	f.Region = "APAC"
	data = overviewGovernanceData(nil, nil, scans, f, "", "", true)
	if data["coverage"].(map[string]string)["ET"] != "complete" || data["risk_subjects"] != 1 {
		t.Fatal(data)
	}
}
