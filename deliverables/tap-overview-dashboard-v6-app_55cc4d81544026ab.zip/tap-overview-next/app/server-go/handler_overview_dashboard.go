package main

import "net/http"

func overviewGovernanceList(w http.ResponseWriter, r *http.Request)     { overviewGovernanceHandler(w, r) }
func overviewMetricsByMetricGet(w http.ResponseWriter, r *http.Request) { overviewMetricsHandler(w, r) }
func overviewQuotaList(w http.ResponseWriter, r *http.Request)          { overviewQuotaHandler(w, r) }
