# 集成技术说明

## 推荐入口

将 OverviewDashboard 作为现有工作台中的一个新页面，用当前原生布局/AuthGuard/SDK。避免并行加载两个 React Root 或两个 page-control 初始化器。可选 integrated-overview-entry 是旧双入口方案，不能盲目加到当前入口。overview-accounts 组件和 dashboard 样式仍有必要保留。全局主题、operations.css、真实认证工具 auth.ts、生成 API 客户端由当前工作台提供。

## 后端依赖

Overview 是 package main 的新增函数文件，不是独立 Go module。依赖当前工作台中的：

- 风神探针、Saved Report/VQS、字段及过滤工具：共享探针增量见 reference/aeolus_titan_probe.reference.patch；该补丁新增函数依赖 payload 中的 Overview 文件，不能单独用。
- 配额：quotaAeolusRows / loadSTFromSnapshot / loadQuotaBaseline 等现有方法。
- 扫描读取：wbPersistedBatches / wbDisk / wbJob / wbCustomerKey / wbMatched；保留当前只读批次和风险判定语义。
- 治理：cwCaseworkRepositoryProvider / cwCase / cwNotice / cwCanRead / cwLoadConfig / requestUsername；数据读取权限沿用最新实现。Cloud 读取失败保持明确错误，不回退到过期 SQLite 假装成功。
- API：Register / wrapAuth / writeJSON 等当前公共设施。

API 定义片段新增四条认证 GET。优先使用当前 generator；reference 中两份 .gen.go 只是接口生成形态参考。当前旧48条合同在 v8 基线中未变；AIME 可能已增加更多合同，应全部保留。新的总览客户端通过 generator 追加，不用整份旧 client.gen.ts 覆盖。

不要改动 main.go、store_cloud.go、casework_cloud.go、casework_feishu.go、casework_repository.go、原事件处理/通知 worker、旧配置文件、数据库表/数据。若新版本签名发生变化，只改总览侧适配。新增GET内部仍需检查无写入调用，不能只按HTTP动词判断只读。

## 图表清单与来源

核心：Account分布2891943；Revenue分布2883029；ET/ST Quota及已保存风险、通知、处置汇总。

源码额外已实现：业务概览2892274；P0概览2891879和周趋势2883040；P1周趋势2883016（可选）；Approval概览2893221；Approval/Banned周趋势Global2883018/Region2883037；FDR Global2883048/Region2883021；Overturned2883046；Region×Tier2883033；TAP/NonTAP2529294。

所有字段和报表固定过滤以 overview_metrics.go、overview_extended.go、overview_report_contract.go 中配置与实际 Saved Report 核对。成功响应、字段绑定成功、非空结果、指标单位正确和与看板数值一致是不同验收层次。字段歧义或 Region 不支持时明确不可用，不猜字段、不冒充其他 Region。

Time Window 输入起止日期，但 Account 是截至结束日最近快照（目前回看14天）、Revenue是区间聚合、趋势按源周、Quota按季度。P0源值不是处置效果；Closed不代表指标改善。不要把业务指标重算为另一套口径。占比分母不完整时隐藏误导性比例。

## 构建/网关

当前 AIME 能使用真实私有 SDK，优先沿用其正常 Vite/标准构建链。overview-build-dependencies.json 是旧独立公共构建的依赖示例，不是要求替换现有 package.json/lock。若使用多入口，原页面和新 Overview 都必须从当前源码生成。

旧 build_app 和 handler_static 补丁只解释过去的双入口方式。不要还原旧 native-host 或覆盖 AIME 最新 /proxy/<port>/、Content-Type、启动与 code4018 修复。主页面 HTML、模块 JS、CSS、JSON API 各保持正确 MIME；须经真实网关验证，不以本机200代替。不要把网关拒绝等同于缺数据库或一般业务权限。

## 测试边界

v8 基线已有84前端、33总览/集成Go顶层测试（含race）通过。原87选定Go回归中86通过、1因本地缺aime CLI阻塞，并在原始包复现。该成绩仅描述来源版本，不代表本次新合并已通过。payload 包含总览与集成相关测试，需按最新路由/权限/入口适配；测试依赖当前宿主原有测试辅助。

此前没有在本地验证完整生产Cloud启动或发送真实飞书；新增图表未全部真实风神对拍。本包更不包含AIME刚修复后的最新源码，必须现场重新构建和验证。不要把测试样例、旧日志或来源版本测试结果写成新版本实测。

先对当前工作台和合并后做同条件只读检查，再做总览真实取数。真实收件人发送/打标另需明确授权的测试对象。正式发布前保留完整可恢复代码与配置；代码回退不会自动撤销数据库已发生的操作。草稿不能仅凭App名称视为数据库隔离。
