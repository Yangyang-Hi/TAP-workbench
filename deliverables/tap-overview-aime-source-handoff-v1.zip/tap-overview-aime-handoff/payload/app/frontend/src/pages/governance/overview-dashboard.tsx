import { useEffect, useState } from "react";
import { AccountDistribution, type AccountDistributionData } from "./overview-accounts";
import { workbenchApi } from "./api";
import "./overview-dashboard.css";

export type OverviewWindow = { start_date: string; end_date: string; region: string; revision: number };
type State = { loading: boolean; error?: string; data?: unknown };
type Row = { tier?: string; source_tier?: string; week?: string; [metric: string]: string | number | null | undefined };
type Metric = { module: string; status: string; reason?: string; window: OverviewWindow; rows: Row[]; summary: Record<string, number | null>; source: { rid: number; sid: number; app_id: number; currency?: string; data_as_of?: string; time_basis?: string }; diagnostics: Record<string, unknown>; queried_at: string };
const modules = ["accounts", "business-summary", "revenue", "p0", "p0-weekly", "approval", "quota", "governance", "region-accounts", "region-revenue", "comparison-tap", "comparison-non-tap", "comparison-tap-revenue", "comparison-non-tap-revenue", "approval-weekly", "fdr-weekly", "overturned-weekly"];
const colors = ["#21988b", "#437ee8", "#8b71d6", "#eba34a"];
const tiers = ["ST", "HT", "BT", "ET"];
const regions = ["Global", "APAC", "CNOB", "EUI", "LATAM", "METAP", "NA", "NEA", "GA", "Scaled Growth", "SMB", "Other"];
const today = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
const qtd = () => { const day = today(); const month = Number(day.slice(5, 7)); return `${day.slice(0, 4)}-${String(Math.floor((month - 1) / 3) * 3 + 1).padStart(2, "0")}-01`; };
export const overviewNumber = (n: unknown, digits = 2) => typeof n === "number" && Number.isFinite(n) ? n.toLocaleString("en-US", n !== 0 && Math.abs(n) < 10 ** -digits ? { maximumSignificantDigits: 4 } : { maximumFractionDigits: digits }) : "—";
const percent = (n: unknown) => typeof n === "number" ? `${overviewNumber(n, 1)}%` : "N/A";
const endpoint = (key: string) => key === "accounts" ? "/api/overview/accounts" : ["quota", "governance"].includes(key) ? `/api/overview/${key}` : `/api/overview/metrics/${key}`;

export function useOverviewResults(applied?: OverviewWindow, includeP1 = false) {
  const [states, setStates] = useState<Record<string, State>>({});
  useEffect(() => {
    if (!applied) return;
    let alive = true; const abort = new AbortController(); let cursor = 0;
    setStates(Object.fromEntries(modules.map(key => [key, { loading: true }])));
    async function worker() {
      while (alive && cursor < modules.length) {
        const key = modules[cursor++];
        const query = new URLSearchParams({ start_date: applied!.start_date, end_date: applied!.end_date, region: applied!.region });
        try {
          const result = await workbenchApi<{ data: unknown }>(`${endpoint(key)}?${query}`, undefined, abort.signal);
          if (alive) setStates(old => ({ ...old, [key]: { loading: false, data: result.data } }));
        } catch (e) {
          if (alive && !abort.signal.aborted) setStates(old => ({ ...old, [key]: { loading: false, error: e instanceof Error ? e.message : "查询失败" } }));
        }
      }
    }
    void worker(); void worker();
    return () => { alive = false; abort.abort(); };
  }, [applied]);
  useEffect(() => {
    if (!applied || !includeP1) { setStates(old => { const next = { ...old }; delete next["p1-weekly"]; return next; }); return; }
    let alive = true; const abort = new AbortController();
    setStates(old => ({ ...old, "p1-weekly": { loading: true } }));
    const query = new URLSearchParams({ start_date: applied.start_date, end_date: applied.end_date, region: applied.region });
    void workbenchApi<{ data: unknown }>(`/api/overview/metrics/p1-weekly?${query}`, undefined, abort.signal).then(result => {
      if (alive) setStates(old => ({ ...old, "p1-weekly": { loading: false, data: result.data } }));
    }).catch(e => { if (alive && !abort.signal.aborted) setStates(old => ({ ...old, "p1-weekly": { loading: false, error: e.message } })); });
    return () => { alive = false; abort.abort(); };
  }, [applied, includeP1]);
  return states;
}

function MetricState({ state, children }: { state?: State; children: (value: Metric) => React.ReactNode }) {
  if (!state) return <div className="ov2-empty">应用筛选后加载此模块。</div>;
  if (state.loading) return <div className="ov2-empty" role="status">正在排队或读取数据…</div>;
  if (state.error) return <div className="ov-notice ov-error" role="alert">{state.error}</div>;
  const value = state.data as Metric | undefined;
  if (!value) return <div className="ov2-empty">未返回数据。</div>;
  return <>{value.reason && <div className="ov-notice">{value.reason}</div>}{value.status === "unavailable" || value.status === "no_data" ? <div className="ov2-empty">{value.status === "no_data" ? "所选范围无返回数据" : "数据暂不可用"}</div> : children(value)}<Diagnostics data={value} /></>;
}

function Diagnostics({ data }: { data: unknown }) {
  const d = data as Metric;
  return <details className="ov-diagnostics"><summary>数据来源与查询诊断</summary>{d.source && <p>RID {d.source.rid} · App {d.source.app_id} · SID {d.source.sid}</p>}<pre>{JSON.stringify(data, null, 2)}</pre></details>;
}

export function RevenueDistribution({ state }: { state?: State }) {
  return <section className="ov-accounts ov2-revenue"><SectionTitle eyebrow="REVENUE" title="TAP 营收分布" subtitle="所选日期区间 · 完整四 Tier" /><MetricState state={state}>{value => {
    const complete = value.status === "available" && value.rows.length === 4 && value.rows.every(row => typeof row.share === "number"); let degree = 0;
    const segments = complete ? value.rows.map(row => { const from = degree; degree += Number(row.share) * 3.6; return `${colors[tiers.indexOf(row.tier || "")]} ${from}deg ${degree}deg`; }) : [];
    return <><div className="ov-chart-grid"><div className="ov-donut-wrap">{complete ? <div className="ov-donut" role="img" aria-label="四 Tier Revenue 占比" style={{ background: `conic-gradient(${segments.join(",")})` }}><div><span>四 Tier 营收合计</span><strong>{overviewNumber(value.summary.revenue)}</strong><small>Revenue · 源指标值</small></div></div> : <div className="ov-chart-empty">占比暂不可用</div>}</div><div className="ov-table-wrap"><table><caption>Revenue & Share</caption><thead><tr><th>Tier</th><th>Revenue</th><th>Share</th></tr></thead><tbody>{tiers.map(tier => { const row = value.rows.find(r => r.tier === tier); return <tr key={tier}><th><i style={{ background: colors[tiers.indexOf(tier)] }} />{tier}</th><td>{overviewNumber(row?.revenue)}</td><td>{typeof row?.share === "number" ? percent(row.share) : "—"}</td></tr>; })}</tbody></table></div></div><p className="ov-footnote">区间营收采用源端聚合。币种尚需与源报表确认，当前不擅自标注 USD；缺失或负值不强行生成占比。</p></>;
  }}</MetricState></section>;
}

function SectionTitle({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle?: string }) {
  return <div className="ov-section-head"><div><p className="ov-eyebrow">{eyebrow}</p><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div></div>;
}

// Use source week values, never recompute CCR. Missing points break lines.
function weekKey(raw: string) {
  const date = raw.match(/^(\d{4}-\d{2}-\d{2})/); if (date && !Number.isNaN(Date.parse(date[1]))) return date[1];
  const iso = raw.match(/^(\d{4})-?W(\d{1,2})$/i);
  if (iso) { const d = new Date(Date.UTC(Number(iso[1]), 0, 4)); d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7 + (Number(iso[2]) - 1) * 7); return d.toISOString().slice(0, 10); }
  return raw;
}

export function WeeklyPlot({ data, field, label, bars = false }: { data: Metric; field: string; label: string; bars?: boolean }) {
  const records: Row[] = data.rows.map(row => ({ ...row, week: weekKey(String(row.week || "")) }));
  let weeks = [...new Set(records.map(row => row.week || ""))].sort();
  if (weeks.length && weeks.every(w => /^\d{4}-\d{2}-\d{2}$/.test(w))) {
    // Preserve the source week anchor (Sunday/Monday/custom).
    const date = new Date(`${weeks[0]}T00:00:00Z`);
    const start = Date.parse(`${data.window.start_date}T00:00:00Z`);
    date.setUTCDate(date.getUTCDate() + Math.floor((start - date.getTime()) / 604800000) * 7);
    const end = Date.parse(`${data.window.end_date}T00:00:00Z`); const axis: string[] = [];
    while (date.getTime() <= end) { axis.push(date.toISOString().slice(0, 10)); date.setUTCDate(date.getUTCDate() + 7); }
    weeks = axis;
  }
  const values = records.map(row => row[field]).filter((v): v is number => typeof v === "number" && Number.isFinite(v));
  if (!values.length) return <div className="ov2-empty">{label} 暂无有效点位。</div>;
  const max = Math.max(...values, 0) || 1; const width = 620, height = 220, left = 58, top = 18, plotWidth = 545, plotHeight = 150;
  const x = (i: number) => left + (weeks.length <= 1 ? plotWidth / 2 : i * plotWidth / (weeks.length - 1)); const y = (v: number) => top + plotHeight * (1 - v / max);
  return <div className="ov2-plot"><h3>{label}</h3><svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label={`${label} 周度趋势`}>
    {[0, .5, 1].map(ratio => <g key={ratio}><line x1={left} x2={left + plotWidth} y1={y(max * ratio)} y2={y(max * ratio)} stroke="#e7edf5" /><text x={left - 8} y={y(max * ratio) + 4} textAnchor="end" fontSize="10" fill="#8b9bad">{overviewNumber(max * ratio, 1)}</text></g>)}
    {tiers.map((tier, ti) => {
      const byWeek = new Map(records.filter(r => r.tier === tier).map(row => [row.week || "", row[field]])); let path = "", connected = false;
      const shapes = weeks.map((week, i) => { const v = byWeek.get(week); if (typeof v !== "number") { connected = false; return null; } const px = x(i), py = y(v); path += `${connected ? " L" : " M"}${px},${py}`; connected = true; return bars ? <rect key={week} x={px + (ti - 2) * 5} y={py} width="4" height={top + plotHeight - py} fill={colors[ti]}><title>{week} · {tier} · {overviewNumber(v)}</title></rect> : <circle key={week} cx={px} cy={py} r="3" fill={colors[ti]}><title>{week} · {tier} · {overviewNumber(v)}</title></circle>; });
      return <g key={tier}>{!bars && <path d={path} fill="none" stroke={colors[ti]} strokeWidth="2" />}{shapes}</g>;
    })}
    {weeks.map((week, i) => i % Math.max(1, Math.ceil(weeks.length / 5)) === 0 ? <text key={week} x={x(i)} y={193} textAnchor="middle" fontSize="10" fill="#8b9bad">{week}</text> : null)}
  </svg><div className="ov2-legend">{tiers.filter(t => records.some(r => r.tier === t)).map(t => <span key={t}><i style={{ background: colors[tiers.indexOf(t)] }} />{t}</span>)}</div></div>;
}

function WeeklyModule({ state, title }: { state?: State; title: string }) {
  return <section className="ov-accounts"><SectionTitle eyebrow="WEEKLY PERFORMANCE" title={title} subtitle="按原生周粒度及 Tier 展示；首尾周可能只包含所选日期" /><MetricState state={state}>{data => <><div className="ov2-two-plots"><WeeklyPlot data={data} field="ccr" label="CCR · 源指标值" /><WeeklyPlot data={data} field="nfs" label="Negative Feedback Show" bars /></div><details className="ov2-data-table"><summary>查看周度原始值</summary><div className="ov-table-wrap"><table><thead><tr><th>Week</th><th>Tier</th><th>CCR</th><th>NFS</th></tr></thead><tbody>{data.rows.map((r, i) => <tr key={i}><th>{r.week}</th><td>{r.tier}</td><td>{overviewNumber(r.ccr)}</td><td>{overviewNumber(r.nfs)}</td></tr>)}</tbody></table></div></details></>}</MetricState></section>;
}

type QuotaValue = { used: number | null; quota: number | null; ratio: number | null; remaining: number | null };
type QuotaPeriod = { quarter: string; status: string; reason?: string; start_date: string; end_date: string; et?: QuotaValue; st?: QuotaValue; regions: { region: string; et: QuotaValue; st: QuotaValue }[]; st_snapshot_at?: string; errors?: Record<string, string>; warnings?: string[] };
type Quota = { window: OverviewWindow; quarters: QuotaPeriod[]; queried_at: string };

export function QuotaOverview({ state }: { state?: State }) {
  const [quarter, setQuarter] = useState(""); const data = state?.data as Quota | undefined;
  const selected = data?.quarters.find(q => q.quarter === quarter) || data?.quarters[data.quarters.length - 1];
  return <section className="ov-accounts"><SectionTitle eyebrow="CAPACITY" title="Quota 使用概览" subtitle="ET 以 Account、ST 以 Brand 计；跨季度分开展示" />
    {state?.loading ? <div className="ov2-empty">正在读取配额…</div> : state?.error ? <div className="ov-notice ov-error">{state.error}</div> : !data ? <div className="ov2-empty">应用筛选后读取已有来源。</div> : <>
      <div className="ov2-periods">{data.quarters.map(q => <button key={q.quarter} className={selected?.quarter === q.quarter ? "active" : ""} onClick={() => setQuarter(q.quarter)}>{q.quarter}</button>)}</div>
      {selected && <>{selected.reason && <p className="ov-notice">{selected.reason}</p>}<p className="ov2-muted">ET 累计窗口：{selected.start_date} 至 {selected.end_date}；ST 为季度名单快照{selected.st_snapshot_at ? `（同步于 ${selected.st_snapshot_at}）` : "（尚未提供成功快照）"}。</p><div className="ov2-quota-grid">{(["et", "st"] as const).map(key => { const metric = selected[key]; return <article key={key}><h3>{key.toUpperCase()} <small>{key === "et" ? "Account" : "Brand"}</small></h3><div className="ov2-quota-number">{overviewNumber(metric?.used, 0)} <small>/ {overviewNumber(metric?.quota, 0)}</small></div><div className="ov2-progress"><i style={{ width: `${Math.max(0, Math.min(metric?.ratio || 0, 100))}%`, background: (metric?.ratio || 0) >= 100 ? "#de7359" : "#437ee8" }} /></div><p>使用率 {percent(metric?.ratio)} · 剩余额度 {overviewNumber(metric?.remaining, 0)}</p>{selected.errors?.[key.toUpperCase()] && <p className="ov-notice">{selected.errors[key.toUpperCase()]}</p>}<div className="ov-table-wrap"><table><thead><tr><th>Region</th><th>Used</th><th>Quota</th><th>Rate</th><th>Remaining</th></tr></thead><tbody>{selected.regions.map(r => <tr key={r.region}><th>{r.region}</th><td>{overviewNumber(r[key]?.used, 0)}</td><td>{overviewNumber(r[key]?.quota, 0)}</td><td>{percent(r[key]?.ratio)}</td><td>{overviewNumber(r[key]?.remaining, 0)}</td></tr>)}</tbody></table></div></article>; })}</div>{selected.warnings?.map(w => <p className="ov2-muted" key={w}>{w}</p>)}</>}
      <Diagnostics data={data} />
    </>}
  </section>;
}

type Governance = { risk_share?: number | null; risk_share_scope?: string; risk_share_basis?: string; unclassified_subjects?: number; status: string; reason?: string; alert_events: number; risk_subjects: number | null; evaluated_subjects: number | null; coverage: Record<string, string>; by_program: Record<string, number>; by_region: Record<string, number>; by_level: Record<string, number>; states: Record<string, number>; weekly: { window: string; events: number }[]; submitters: { submitter: string; total: number; notified_cases: number | null; pending: number; in_progress: number; closed: number; unknown_status: number; closure_rate: number | null }[]; updated_at: string; time_basis: string; notification_binding: string };

function BarList({ values, label }: { values: Record<string, number>; label: string }) {
  const max = Math.max(1, ...Object.values(values));
  return <div className="ov2-bar-list"><h3>{label}</h3>{Object.entries(values).map(([k, v]) => <div key={k}><span>{k}</span><i><b style={{ width: `${v / max * 100}%` }} /></i><strong>{v}</strong></div>)}{!Object.keys(values).length && <p className="ov2-muted">当前已读取范围没有事件。</p>}</div>;
}

export function GovernanceOverview({ state }: { state?: State }) {
  const data = state?.data as Governance | undefined;
  return <section className="ov-accounts"><SectionTitle eyebrow="GOVERNANCE" title="风险与处置概览" subtitle="复用已有事实，不触发全量扫描；处置按当前权威状态汇总" />
    {state?.loading ? <div className="ov2-empty">正在读取已保存事实…</div> : state?.error ? <div className="ov-notice ov-error">{state.error}</div> : !data ? <div className="ov2-empty">应用筛选后读取治理事实。</div> : data.status === "not_connected" ? <><p className="ov-notice">{data.reason}</p><p className="ov2-muted">独立测试 App 没有主工作台的历史事件时，此处保持未接入；业务指标图表可以独立使用。</p></> : <>
      {data.reason && <p className="ov-notice">{data.reason}</p>}
      <div className="ov2-governance-cards">{[["已评估主体", data.evaluated_subjects], ["风险主体", data.risk_subjects], ["预警事件", data.alert_events], ["待处理", data.states.pending], ["处理中", data.states.in_progress], ["已关闭", data.states.closed]].map(([label, value]) => <article key={String(label)}><span>{label}</span><strong>{overviewNumber(value, 0)}</strong></article>)}</div>
      <div className="ov2-risk-share"><span>已返回扫描样本风险占比</span><strong>{percent(data.risk_share)}</strong><p className="ov2-muted">{data.risk_share_basis || "风险主体 ÷ 已保存扫描样本主体"}。{data.risk_share_scope === "partial_saved_sample" ? "当前范围不完整，仅代表已返回样本。" : "按已保存批次口径。"}{!!data.unclassified_subjects && `另有 ${data.unclassified_subjects} 个主体尚未完成风险分类，占比暂不可用。`}</p></div>
      <p className="ov2-muted">扫描覆盖：{Object.entries(data.coverage).map(([p, s]) => `${p} ${s === "complete" ? "已保存完整批次" : s === "partial" ? "部分批次" : "尚未扫描"}`).join(" · ")}。主体按 Program＋Account/Advertiser 去重，不能当作跨项目唯一客户数。</p>
      <div className="ov2-three-bars"><BarList label="预警事件 · Program" values={data.by_program} /><BarList label="预警事件 · Region" values={data.by_region} /><BarList label="保存的风险等级" values={Object.fromEntries(Object.entries(data.by_level).map(([k, v]) => [({ critical: "极端阈值", watch: "观察预警", unclassified: "未分级" } as Record<string, string>)[k] || k, v]))} /></div>
      <BarList label="保存指标窗口 · 事件趋势" values={Object.fromEntries(data.weekly.map(r => [r.window, r.events]))} />
      {data.states.unknown > 0 && <p className="ov-notice">另有 {data.states.unknown} 个事件状态尚未映射，未并入待处理、处理中或已关闭。</p>}
      <h3>Submitter 通知与处置汇总</h3><div className="ov-table-wrap"><table><thead><tr><th>Submitter</th><th>成功通知事件</th><th>待处理</th><th>处理中</th><th>已关闭</th><th>未映射状态</th><th>关闭率</th></tr></thead><tbody>{data.submitters.map(r => <tr key={r.submitter}><th>{r.submitter}</th><td>{overviewNumber(r.notified_cases, 0)}</td><td>{r.pending}</td><td>{r.in_progress}</td><td>{r.closed}</td><td>{r.unknown_status}</td><td>{percent(r.closure_rate)}</td></tr>)}</tbody></table></div>
      <p className="ov2-muted">{data.notification_binding}。已关闭表示完成处置，不代表指标改善。状态最新更新时间：{data.updated_at || "暂无事件"}。</p><p className="ov2-muted">{data.time_basis}</p><Diagnostics data={data} />
    </>}
  </section>;
}

export function AdditionalTrends({ approval, fdr, overturned }: { approval?: State; fdr?: State; overturned?: State }) {
  return <>
    <section className="ov-accounts"><SectionTitle eyebrow="AUDIT PERFORMANCE" title="Approval Rate / Banned Volume 周趋势" subtitle="Global 与指定 Region 使用各自保存报表；原生审核口径" /><MetricState state={approval}>{data => <><div className="ov2-two-plots"><WeeklyPlot data={data} field="rate" label="Approval Rate · 源值" /><WeeklyPlot data={data} field="volume" label="Banned Volume" bars /></div><NativeRows data={data} fields={["rate", "volume"]} /></>}</MetricState></section>
    <section className="ov-accounts"><SectionTitle eyebrow="QUALITY PERFORMANCE" title="Ads FDR / Overturned Account 周趋势" subtitle="分别读取两个原生来源；分别保留源周标签，不把两个来源累加或补零" /><p className="ov2-muted">保留源报表 p_date 快照条件，以所选日期相交的整周展示；不同于 P0/P1 可按日裁剪的区间趋势。FDR 为源指标值，Overturned 为去重 Account 量。</p><div className="ov2-two-plots"><div><MetricState state={fdr}>{data => <><WeeklyPlot data={data} field="rate" label="Ads FDR · 源值" /><NativeRows data={data} fields={["rate"]} /></>}</MetricState></div><div><MetricState state={overturned}>{data => <><WeeklyPlot data={data} field="volume" label="Overturned Account Volume" bars /><NativeRows data={data} fields={["volume"]} /></>}</MetricState></div></div></section>
  </>;
}

function NativeRows({ data, fields }: { data: Metric; fields: string[] }) {
  return <details className="ov2-data-table"><summary>查看源端原始值</summary><div className="ov-table-wrap"><table><thead><tr><th>Week / Region</th><th>Tier</th>{fields.map(f => <th key={f}>{f}</th>)}</tr></thead><tbody>{data.rows.map((r, i) => <tr key={i}><th>{r.week || r.source_region || r.region || "—"}</th><td>{r.tier || "—"}</td>{fields.map(f => <td key={f}>{overviewNumber(r[f], 4)}</td>)}</tr>)}</tbody></table></div></details>;
}

function RegionTierBars({ data, field, title }: { data: Metric; field: string; title: string }) {
  const max = Math.max(1, ...data.rows.map(r => typeof r[field] === "number" ? Math.abs(Number(r[field])) : 0));
  return <div className="ov2-region-bars"><h3>{title}</h3>{data.rows.map((r, i) => <div key={i}><span>{r.region} · {r.tier}<small>{r.source_region !== r.region ? r.source_region : ""}</small></span><i><b style={{ width: `${Math.abs(Number(r[field]) || 0) / max * 100}%`, background: Number(r[field]) < 0 ? "#d77863" : colors[tiers.indexOf(r.tier || "")] }} /></i><strong>{overviewNumber(r[field], field === "account_count" ? 0 : 2)}</strong></div>)}</div>;
}

export function RegionDistribution({ accounts, revenue }: { accounts?: State; revenue?: State }) {
  return <section className="ov-accounts"><SectionTitle eyebrow="REGION × TIER" title="区域与 Tier · 账户及营收分布" subtitle="动态查询；账户使用最近快照，营收使用所选区间" /><div className="ov2-two-plots"><div><MetricState state={accounts}>{data => <><p className="ov2-muted">账户快照：{data.source.data_as_of || "未返回快照日期"}</p><RegionTierBars data={data} field="account_count" title="Account Count" /><NativeRows data={data} fields={["account_count"]} /></>}</MetricState></div><div><MetricState state={revenue}>{data => <><RegionTierBars data={data} field="revenue" title="Revenue · 所选区间" /><NativeRows data={data} fields={["revenue"]} /></>}</MetricState></div></div><p className="ov2-muted">保留源端区域分组，原始区域显示在标签下；不会将多行去重 Account Count 盲目相加，区域分组不完整时也不冒充 Global 总量。负值以红色标出，条形长度表示绝对值。</p></section>;
}

function availableMetric(state?: State) { const d = state?.data as Metric | undefined; return d && ["available", "partial"].includes(d.status) ? d : undefined; }
function cohortShare(a: unknown, b: unknown) { return typeof a === "number" && typeof b === "number" && a >= 0 && b >= 0 && a + b > 0 ? a / (a + b) * 100 : null; }

export function TapComparison({ states }: { states: Record<string, State> }) {
  const keys = ["comparison-tap", "comparison-non-tap", "comparison-tap-revenue", "comparison-non-tap-revenue"];
  const [ta, na, tr, nr] = keys.map(k => availableMetric(states[k]));
  const rawRegions = [...new Set([ta, na, tr, nr].flatMap(d => d?.rows.map(r => String(r.source_region ?? r.region ?? "")) || []))].sort();
  const rowAt = (d: Metric | undefined, region: string) => d?.rows.find(r => String(r.source_region ?? r.region ?? "") === region);
  const sameSnapshot = !!ta?.source.data_as_of && ta.source.data_as_of === na?.source.data_as_of;
  return <section className="ov-accounts"><SectionTitle eyebrow="TAP / NON-TAP" title="TAP 与 Non-TAP · 区域对比" subtitle="账户与营收分别按源端聚合，不从四 Tier 的去重数推算 Non-TAP" />
    <p className="ov2-muted">TAP 为四个已定义 Tier；Non-TAP 排除这四 Tier 及 NULL/Unknown。账户占比分母为同日快照的 TAP＋Non-TAP；营收占比分母为同区间的 TAP＋Non-TAP，均不含 Unknown。</p>
    {keys.map((k, i) => <div className="ov2-comparison-source" key={k}><strong>{["TAP 账户快照", "Non-TAP 账户快照", "TAP 区间营收 / Approval", "Non-TAP 区间营收 / Approval"][i]}</strong><MetricState state={states[k]}>{() => <span className="ov2-muted">已返回</span>}</MetricState></div>)}
    {(ta || na) && <p className="ov2-muted">账户快照 TAP：{ta?.source.data_as_of || "不可用"}；Non-TAP：{na?.source.data_as_of || "不可用"}。{!sameSnapshot && "两个群组快照不一致或不完整，账户占比暂不可用。"}</p>}
    {!!rawRegions.length && <div className="ov2-comparison-grid">{rawRegions.map(region => { const a = rowAt(ta, region), b = rowAt(na, region), c = rowAt(tr, region), d = rowAt(nr, region); const accountShare = sameSnapshot ? cohortShare(a?.account_count, b?.account_count) : null, revenueShare = cohortShare(c?.revenue, d?.revenue); return <article key={region}><h3>{a?.region || b?.region || c?.region || d?.region || region}</h3><p className="ov2-muted">源区域 {region || "空值"}</p><div className="ov-table-wrap"><table><thead><tr><th>指标</th><th>TAP</th><th>Non-TAP</th></tr></thead><tbody><tr><th>Account · 快照</th><td>{overviewNumber(a?.account_count, 0)}</td><td>{overviewNumber(b?.account_count, 0)}</td></tr><tr><th>Account Share</th><td>{percent(accountShare)}</td><td>{percent(accountShare === null ? null : 100 - accountShare)}</td></tr><tr><th>Revenue · 区间</th><td>{overviewNumber(c?.revenue)}</td><td>{overviewNumber(d?.revenue)}</td></tr><tr><th>Revenue Share</th><td>{percent(revenueShare)}</td><td>{percent(revenueShare === null ? null : 100 - revenueShare)}</td></tr><tr><th>Approval · 源值</th><td>{overviewNumber(c?.approval_rate, 4)}</td><td>{overviewNumber(d?.approval_rate, 4)}</td></tr></tbody></table></div>{accountShare !== null && <div className="ov2-cohort-bar" aria-label={`TAP Account Share ${overviewNumber(accountShare, 1)}%`}><i style={{ width: `${accountShare}%` }} /><b style={{ width: `${100 - accountShare}%` }} /></div>}</article>; })}</div>}
    <p className="ov2-muted">Approval 只展示源端原生率；源报表没有返回时为“—”，不会平均其他群组或临时构造分子分母。未核实币种与百分比缩放前保留源值。</p>
  </section>;
}

export function OverviewDashboard({ embedded = false }: { embedded?: boolean }) {
  const [start, setStart] = useState(qtd), [end, setEnd] = useState(today), [region, setRegion] = useState("Global");
  const [applied, setApplied] = useState<OverviewWindow>(); const [validation, setValidation] = useState("");
  const [advanced, setAdvanced] = useState(false);
  const states = useOverviewResults(applied, advanced);
  const account = states.accounts?.data as AccountDistributionData | undefined, business = states["business-summary"]?.data as Metric | undefined, p0 = states.p0?.data as Metric | undefined;
  const changed = !!applied && (start !== applied.start_date || end !== applied.end_date || region !== applied.region);
  function apply() { if (!start || !end || start > end || end > today()) { setValidation("请选择有效的起止日期，结束日期不得晚于今天。"); return; } setValidation(""); setApplied({ start_date: start, end_date: end, region, revision: (applied?.revision || 0) + 1 }); }
  function download() {
    const payload = { schema: "tap-overview-query-v2", exported_at: new Date().toISOString(), applied_filters: applied, results: states };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `TAP-Overview-${applied?.end_date || "query"}.json`; a.click(); URL.revokeObjectURL(url);
  }
  const content = <>
    <div className="ov2-heading"><div><p className="ov-eyebrow">TAP GOVERNANCE · BUSINESS & OPERATIONS</p><h1>数据总览 / Overview</h1><p>业务规模、指标表现与风险治理进度</p></div><button className="ov2-export" disabled={!applied} onClick={download}>下载本次查询记录</button></div>
    <section className="ov2-filter-panel"><form onSubmit={e => { e.preventDefault(); apply(); }}>
      <label>开始日期<input aria-label="总览开始日期" type="date" required value={start} max={today()} onChange={e => setStart(e.target.value)} /></label>
      <span className="ov2-date-to">至</span><label>结束日期<input aria-label="总览结束日期" type="date" required value={end} max={today()} onChange={e => setEnd(e.target.value)} /></label>
      <label>Customer Region<select aria-label="总览区域" value={region} onChange={e => setRegion(e.target.value)}>{regions.map(r => <option key={r}>{r}</option>)}</select></label>
      <button type="submit">应用筛选</button><button type="button" className="ov2-qtd" onClick={() => { setStart(qtd()); setEnd(today()); }}>本季度至今</button>
    </form><p>Account 看结束日以前最近快照；Revenue／CCR 看所选区间；Quota 分季度；治理读取保存事实。</p><p className="ov2-muted">暂不设置统一 Tier 筛选：分布保留四 Tier，趋势按来源返回的 Tier 展示，治理 Program 另按 ET／ST／THT 统计。</p>{validation && <p role="alert" className="ov2-filter-error">{validation}</p>}{changed && <p className="ov2-unapplied" role="status">筛选条件尚未应用，下方仍为上次已应用结果。</p>}</section>
    {applied && <p className="ov2-applied">当前结果范围：{applied.start_date} 至 {applied.end_date} · {applied.region}</p>}
    {applied && <p className="ov2-muted" role="status">已返回 {modules.filter(k => states[k] && !states[k].loading).length} / {modules.length} 个模块；各模块独立展示，P1 按需展开。</p>}
    <section className="ov2-kpis">{[
      ["TAP Accounts · 区间去重", business?.summary.account_count, "原生 COUNT DISTINCT · 非每日数量相加", states["business-summary"]?.loading],
      ["TAP Revenue", business?.summary.revenue, "原生区间总值 · 币种待源确认", states["business-summary"]?.loading],
      ["P0 CCR", p0?.summary.ccr, "所选区间 · 源端原生聚合值", states.p0?.loading],
      ["P0 NFS", p0?.summary.nfs, "所选区间 · Negative Feedback Show", states.p0?.loading],
    ].map(([label, value, note, loading]) => <article key={String(label)}><span>{label}</span><strong>{loading ? "…" : overviewNumber(value)}</strong><small>{note}</small></article>)}</section>
    <section className="ov2-kpi-source"><MetricState state={states["business-summary"]}>{() => <p className="ov2-muted">顶部账户与营收总卡读取 RID 2892274 的原生区间聚合。下方账户环形图是结束日快照，两者时间口径不同。</p>}</MetricState></section>
    <div className="ov2-distributions"><AccountDistribution external={{ data: account, loading: states.accounts?.loading || false, error: states.accounts?.error }} /><RevenueDistribution state={states.revenue} /></div>
    <section className="ov-accounts"><SectionTitle eyebrow="CONTENT HEALTH" title="P0 CCR / NFS 区间汇总" subtitle="全区间原生聚合，独立于账户快照日期" /><MetricState state={states.p0}>{data => <div className="ov2-p0-summary"><div><span>P0 CCR · 源值</span><strong>{overviewNumber(data.summary.ccr)}</strong></div><div><span>P0 NFS</span><strong>{overviewNumber(data.summary.nfs)}</strong></div><p>直接采用源报表指标；CCR 单位以源报表为准，未对每日或各 Tier 的 CCR 求平均。</p></div>}</MetricState></section>
    <WeeklyModule state={states["p0-weekly"]} title="P0 CCR / NFS 周度趋势" />
    <RegionDistribution accounts={states["region-accounts"]} revenue={states["region-revenue"]} />
    <TapComparison states={states} />
    <QuotaOverview state={states.quota} />
    <GovernanceOverview state={states.governance} />
    <section className="ov-accounts"><SectionTitle eyebrow="APPROVAL" title="Approval Rate · Tier 表现" subtitle="复用 iDA 保存报表固定过滤" /><MetricState state={states.approval}>{data => <><div className="ov2-approval">{tiers.map(tier => <article key={tier}><span>{tier}</span><strong>{overviewNumber(data.rows.find(r => r.tier === tier)?.approval_rate, 4)}</strong></article>)}</div><p className="ov2-muted">展示源端原始值；百分比缩放格式仍需源端对拍。未返回的 Tier 显示“—”。</p></>}</MetricState></section>
    <AdditionalTrends approval={states["approval-weekly"]} fdr={states["fdr-weekly"]} overturned={states["overturned-weekly"]} />
    <button className="ov2-more" onClick={() => setAdvanced(v => !v)} aria-expanded={advanced}>{advanced ? "收起" : "展开"} P1 周度指标</button>{advanced && <WeeklyModule state={states["p1-weekly"]} title="P1 CCR / NFS 周度趋势" />}
    <footer className="ov2-footer">查询模块独立返回，缺失或失败不作为真实 0。此页面不会启动预警扫描、建单或发送通知。</footer>
  </>;
  return embedded ? <div className="ov2-dashboard">{content}</div> : <main className="ov-trial-page ov2-dashboard">{content}</main>;
}
