import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
const calls = vi.hoisted(() => ({ batches: vi.fn(), model: vi.fn() }));
vi.mock("../../api/client.gen", () => ({ workbenchBatchesList: calls.batches, workbenchReadModelList: calls.model, unwrap: (r: unknown) => r }));
vi.mock("@arco-design/web-react", () => {
  const Tabs = ({ children, onChange }: any) => <nav>{children.map((c: any) => <button key={c.key} onClick={() => onChange(c.key)}>{c.props.title}</button>)}</nav>;
  Tabs.TabPane = () => null;
  return { Tabs, Button: ({children,onClick}:any)=><button onClick={onClick}>{children}</button>, Spin:()=>null };
});
vi.mock("./shared-filters", () => {
  const filters = { time_mode:"weekly", start_date:"", end_date:"", tier:"all", region:"all" };
  return { SharedFilterProvider:({children}:any)=>children, SharedFilterBar:()=> <div>原页面筛选</div>, useSharedFilters:()=>({filters}), filterQuery:(_:unknown,q:Record<string, unknown>)=>new URLSearchParams(Object.fromEntries(Object.entries(q).filter(([,v])=>v!==undefined).map(([k,v])=>[k,String(v)]))).toString() };
});
vi.mock("./overview-dashboard", () => ({OverviewDashboard:()=> <div>已合并数据总览</div>}));
vi.mock("./workbench-pages", () => ({Overview:()=> <div>原治理总览内容</div>,Analysis:()=> <div>原治理效果内容</div>,DataCenter:()=> <div>原运营数据内容</div>,UnsupportedState:()=> <div>原不支持提示</div>,RiskMonitor:({onStage,onRanking}:any)=> <div>原风险监控内容<button onClick={()=>onStage("closed")}>检查已关闭</button><button onClick={()=>onRanking("growth")}>检查增幅排序</button></div>}));
vi.mock("./casework",()=>({WorkbenchSettings:()=> <div>原风险规则设置</div>}));
vi.mock("./casework-task",()=>({SubmitterCasework:({alertId}:any)=> <div>原独立处置页 {alertId}</div>}));
import Workbench from "./index";
beforeEach(()=> { history.replaceState(null,"","/"); calls.batches.mockReset().mockResolvedValue({batches:[]}); calls.model.mockReset().mockResolvedValue({status:"available",rows:[],pagination:{total:0}}); });
afterEach(cleanup);
it("integrated Overview provides links into all original pages without rewriting their UI", async()=> {
 const {default:Integrated}=await import("./integrated-overview");render(<Integrated/>);
 for(const [label,href] of [["数据总览 / Overview","?tab=data-overview"],["治理总览","?tab=overview"],["风险监控与预警","?tab=risk"],["治理效果分析","?tab=analysis"],["运营数据中心","?tab=data"]])expect(screen.getByRole("link",{name:label,exact:true}).getAttribute("href")).toBe(href);
 expect(calls.model).not.toHaveBeenCalled();
});
it("original four pages and their risk stage/ranking callbacks remain available",async()=> {
 render(<Workbench/>);
 for(const [tab,text] of [["治理总览","原治理总览内容"],["风险监控与预警","原风险监控内容"],["治理效果分析","原治理效果内容"],["运营数据中心","原运营数据内容"]]) {fireEvent.click(screen.getByRole("button",{name:tab,exact:true}));await screen.findByText(text,{exact:true});}
 fireEvent.click(screen.getByRole("button",{name:"风险监控与预警",exact:true}));await screen.findByText("原风险监控内容",{exact:true});fireEvent.click(screen.getByRole("button",{name:"检查已关闭"}));await waitFor(()=>expect(calls.model.mock.calls[calls.model.mock.calls.length-1]?.[0]).toContain("stage=closed"));
 fireEvent.click(screen.getByRole("button",{name:"检查增幅排序"}));await waitFor(()=>expect(calls.model.mock.calls[calls.model.mock.calls.length-1]?.[0]).toContain("ranking=growth"));
});
it("original overview/risk bookmarks keep their destination",async()=> {
 history.replaceState(null,"","/?tab=overview");const one=render(<Workbench/>);await screen.findByText("原治理总览内容");one.unmount();
 history.replaceState(null,"","/?alert_id=TAP-OLD&tab=risk");render(<Workbench/>);await screen.findByText("原风险监控内容",{exact:true});
});
it("old Feishu task links still enter the original submitter page",()=> {
 history.replaceState(null,"","/?view=tasks&alert_id=TAP-OLD");render(<Workbench/>);expect(screen.getByText("原独立处置页 TAP-OLD")).toBeTruthy();expect(calls.model).not.toHaveBeenCalled();
});
