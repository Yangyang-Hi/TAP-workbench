import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { GovernanceOverview, OverviewDashboard, QuotaOverview, RevenueDistribution, WeeklyPlot, RegionDistribution, TapComparison, AdditionalTrends, overviewNumber } from "./overview-dashboard";
const api = vi.hoisted(() => vi.fn());
vi.mock("./api", () => ({ workbenchApi: api }));
const names = ["ST", "HT", "BT", "ET"], sourceTiers = ["strategic_trust", "high_trust", "building_trust", "emerging_trust"];
const window = { start_date: "2026-10-01", end_date: "2026-10-26", region: "Global", revision: 1 };
const source = { rid: 2883029, sid: 1139137, app_id: 800414 };
const metric = { module: "revenue", status: "available", window, queried_at: "fixture", source, diagnostics: {}, rows: names.map((tier, i) => ({ tier, source_tier: sourceTiers[i], revenue: (i + 1) * 10, share: (i + 1) * 10 })), summary: { revenue: 100 } };
const account = { status: "available", requested_end_date: "2026-10-26", data_as_of: "2026-10-25", region: "Global", tier_membership_total: 100, queried_at: "fixture", attempts: 2, source, diagnostics: {}, rows: names.map((tier, i) => ({ tier, source_tier: sourceTiers[i], account_count: (i + 1) * 10, account_share: (i + 1) * 10 })) };

function answer(path: string) {
  const u = new URL(path, "https://fixture.test");
  const w = { start_date: u.searchParams.get("start_date") || "", end_date: u.searchParams.get("end_date") || "", region: u.searchParams.get("region") || "Global" };
  if (u.pathname.endsWith("/accounts")) return { data: { ...account, region: w.region } };
  if (u.pathname.endsWith("/quota")) return { data: { window: w, quarters: [], queried_at: "fixture" } };
  if (u.pathname.endsWith("/governance")) return { data: { status: "not_connected", reason: "未连接权威事件", window: w } };
  if (u.pathname.endsWith("/p0")) return { data: { ...metric, window: w, module: "p0", rows: [{ ccr: 123.45, nfs: 500 }], summary: { ccr: 123.45, nfs: 500 } } };
  if (u.pathname.endsWith("/approval")) return { data: { ...metric, window: w, rows: names.map(tier => ({ tier, approval_rate: .975 })), summary: {} } };
  if (u.pathname.endsWith("-weekly")) return { data: { ...metric, window: w, rows: [{ tier: "ST", week: "2026-10-19", ccr: 2, nfs: 10 }], summary: {} } };
  return { data: { ...metric, window: w } };
}

beforeEach(() => { api.mockReset(); api.mockImplementation(async path => answer(path)); });
afterEach(cleanup);

it("loads nothing until Apply, sends dates/Region only, and defers optional P1", async () => {
  history.replaceState(null, "", "/?tier=ET&submitter=person&program=THT");
  render(<OverviewDashboard />);
  expect(api).not.toHaveBeenCalled();
  fireEvent.change(screen.getByLabelText("总览开始日期"), { target: { value: "2026-10-01" } });
  fireEvent.change(screen.getByLabelText("总览结束日期"), { target: { value: "2026-10-26" } });
  fireEvent.change(screen.getByLabelText("总览区域"), { target: { value: "APAC" } });
  fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
  await waitFor(() => expect(api).toHaveBeenCalledTimes(17));
  for (const call of api.mock.calls) {
    const q = new URL(call[0], "https://fixture.test").searchParams;
    expect(Object.fromEntries(q)).toEqual({ start_date: "2026-10-01", end_date: "2026-10-26", region: "APAC" });
    expect(call[0]).not.toMatch(/risk-scans|\/notify|st-snapshots/);
  }
  expect(api.mock.calls.some(c => c[0].includes("p1-weekly"))).toBe(false);
  fireEvent.click(screen.getByRole("button", { name: "展开 P1 周度指标" }));
  await waitFor(() => expect(api).toHaveBeenCalledTimes(18));
  history.replaceState(null, "", "/");
});

it("one failed report does not hide successful modules or fake zero", async () => {
  api.mockImplementation(async path => { if (path.includes("metrics/revenue")) throw Error("fixture report permission denied"); return answer(path); });
  render(<OverviewDashboard />); fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
  expect(await screen.findByText("fixture report permission denied")).toBeTruthy();
  await waitFor(() => expect(screen.getAllByText("123.45").length).toBeGreaterThan(0));
  expect(screen.getByRole("img", { name: /ST 10.0%/ })).toBeTruthy();
  expect(screen.getByText("未连接权威事件")).toBeTruthy();
});

it("edits remain unapplied, and old responses cannot overwrite a newly applied scope", async () => {
  const old: Array<(value: unknown) => void> = [];
  api.mockImplementationOnce(() => new Promise(resolve => old.push(resolve))).mockImplementationOnce(() => new Promise(resolve => old.push(resolve)));
  render(<OverviewDashboard />); fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
  expect(api).toHaveBeenCalledTimes(2);
  const signals = api.mock.calls.map(c => c[2] as AbortSignal);
  fireEvent.change(screen.getByLabelText("总览区域"), { target: { value: "CNOB" } });
  expect(screen.getByText(/筛选条件尚未应用/)).toBeTruthy();
  expect(api).toHaveBeenCalledTimes(2);
  fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
  await waitFor(() => expect(api).toHaveBeenCalledTimes(19));
  expect(signals.every(s => s.aborted)).toBe(true);
  old.forEach(resolve => resolve({ data: { ...account, data_as_of: "1999-01-01" } }));
  await waitFor(() => expect(screen.queryByText("1999-01-01")).toBeNull());
});

it("partial Revenue data shows values without a misleading donut or shares", () => {
  render(<RevenueDistribution state={{ loading: false, data: { ...metric, status: "partial", rows: metric.rows.slice(0, 3).map(r => ({ ...r, share: null })), summary: {}, reason: "四Tier不完整" } }} />);
  expect(screen.getByText("四Tier不完整")).toBeTruthy();
  expect(screen.queryByRole("img")).toBeNull();
  expect(screen.getAllByText("—").length).toBeGreaterThan(0);
});

it("missing calendar weeks break the line and are not zero-filled", () => {
  const data = { ...metric, rows: [{ tier: "ST", week: "2026-10-05", ccr: 2 }, { tier: "ST", week: "2026-10-19", ccr: 4 }] };
  render(<WeeklyPlot data={data} field="ccr" label="CCR test" />);
  const svg = screen.getByRole("img");
  expect(svg.querySelectorAll("circle").length).toBe(2);
  const path = svg.querySelector("path")!.getAttribute("d")!;
  expect((path.match(/M/g) || []).length).toBe(2);
  expect(path).not.toContain("L");
});

it("Quota shows separate quarter and unit plus negative remaining and N/A", () => {
  const q = { used: 12, quota: 10, ratio: 120, remaining: -2 };
  render(<QuotaOverview state={{ loading: false, data: { window, queried_at: "fixture", quarters: [{ quarter: "2026 Q4", status: "partial", start_date: "2026-10-01", end_date: "2026-10-26", et: q, st: { used: null, quota: 817, ratio: null, remaining: null }, regions: [{ region: "APAC", et: q, st: { used: null, quota: 240, ratio: null, remaining: null } }] }] } }} />);
  expect(screen.getByRole("button", { name: "2026 Q4" })).toBeTruthy();
  expect(screen.getByText("Account")).toBeTruthy(); expect(screen.getByText("Brand")).toBeTruthy();
  expect(screen.getAllByText("-2").length).toBeGreaterThan(0); expect(screen.getAllByText("N/A").length).toBeGreaterThan(0);
});

it("disconnected governance does not display invented zero counters", () => {
  render(<GovernanceOverview state={{ loading: false, data: { status: "not_connected", reason: "Cloud facts not connected" } }} />);
  expect(screen.getByText("Cloud facts not connected")).toBeTruthy();
  expect(screen.queryByText("0")).toBeNull();
});

it("query export contains the applied scope, not new draft filters", async () => {
  let exported: Blob | undefined;
  const oldCreate = URL.createObjectURL, oldRevoke = URL.revokeObjectURL;
  URL.createObjectURL = vi.fn(blob => { exported = blob as Blob; return "blob:fixture"; }); URL.revokeObjectURL = vi.fn();
  const click = vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => undefined);
  try {
    render(<OverviewDashboard />); fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
    await waitFor(() => expect(api).toHaveBeenCalledTimes(17));
    fireEvent.change(screen.getByLabelText("总览区域"), { target: { value: "CNOB" } });
    fireEvent.click(screen.getByRole("button", { name: "下载本次查询记录" }));
    expect(exported).toBeTruthy();
    const text = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsText(exported!); });
    const value = JSON.parse(text); expect(value.applied_filters.region).toBe("Global"); expect(text).not.toContain("Byte-Cloud-JWT");
  } finally { URL.createObjectURL = oldCreate; URL.revokeObjectURL = oldRevoke; click.mockRestore(); }
});


it("preserves a Sunday source week anchor instead of dropping returned points", () => {
  const data = { ...metric, rows: [{ tier: "ST", week: "2026-10-04", ccr: 2 }, { tier: "ST", week: "2026-10-18", ccr: 4 }] };
  render(<WeeklyPlot data={data} field="ccr" label="Sunday source" />);
  const svg = screen.getByRole("img");
  expect(svg.querySelectorAll("circle").length).toBe(2);
  expect((svg.querySelector("path")!.getAttribute("d")!.match(/M/g) || []).length).toBe(2);
});


it("native KPI cards never substitute a sum of snapshot Tier counts", async () => {
  api.mockImplementation(async path => path.includes("business-summary") ? { data: { ...metric, rows: [{account_count: 77, revenue: 8800}], summary: {account_count: 77, revenue: 8800} } } : answer(path));
  render(<OverviewDashboard />); fireEvent.click(screen.getByRole("button", {name:"应用筛选"}));
  expect(await screen.findByText("77", {exact:true})).toBeTruthy();
  expect(screen.getByText("TAP Accounts · 区间去重")).toBeTruthy();
  expect(screen.getByText(/下方账户环形图是结束日快照/)).toBeTruthy();
});

it("a failed FDR source keeps Overturned Volume visible without filling rate zeros", () => {
  render(<AdditionalTrends fdr={{loading:false,error:"FDR source unavailable"}} overturned={{loading:false,data:{...metric,rows:[{tier:"ST",week:"2026-10-19",volume:321}],summary:{}}}} />);
  expect(screen.getByText("FDR source unavailable")).toBeTruthy();
  expect(screen.getByRole("img", {name:"Overturned Account Volume 周度趋势"})).toBeTruthy();
  expect(screen.queryByRole("img", {name:"Ads FDR · 源值 周度趋势"})).toBeNull();
});

it("regional account snapshot failure does not hide interval Revenue", () => {
  render(<RegionDistribution accounts={{loading:false,error:"snapshot missing"}} revenue={{loading:false,data:{...metric,rows:[{region:"CNOB",source_region:"APAC-China Outbound",tier:"ET",revenue:99}],summary:{}}}} />);
  expect(screen.getByText("snapshot missing")).toBeTruthy();expect(screen.getAllByText("99",{exact:true}).length).toBeGreaterThan(0);
});

it("TAP comparison suppresses account shares across different snapshot dates", () => {
  const state = (account_count:number,date:string) => ({loading:false,data:{...metric,source:{...source,data_as_of:date},rows:[{region:"NA",source_region:"NA Team",account_count}],summary:{}}});
  render(<TapComparison states={{"comparison-tap":state(3,"2026-10-25"),"comparison-non-tap":state(1,"2026-10-24")}} />);
  expect(screen.getByText(/两个群组快照不一致/)).toBeTruthy();
  expect(screen.getAllByText("N/A").length).toBeGreaterThan(0);
  expect(screen.queryByLabelText(/TAP Account Share/)).toBeNull();
});

it("TAP comparison uses only matching native cohorts and leaves missing Approval unavailable", () => {
  const state = (account_count:number) => ({loading:false,data:{...metric,source:{...source,data_as_of:"2026-10-25"},rows:[{region:"NA",source_region:"NA Team",account_count}],summary:{}}});
  render(<TapComparison states={{"comparison-tap":state(3),"comparison-non-tap":state(1)}} />);
  expect(screen.getByLabelText("TAP Account Share 75%")).toBeTruthy();expect(screen.getByText("75%",{exact:true})).toBeTruthy();
  expect(screen.getByText("25%",{exact:true})).toBeTruthy();expect(screen.getAllByText("—").length).toBeGreaterThan(0);
});


it("small nonzero native rates remain visible before source scaling is confirmed", () => {
  expect(overviewNumber(0.00000087)).toBe("0.00000087");
  expect(overviewNumber(0)).toBe("0");
  expect(overviewNumber(null)).toBe("—");
});


it("integrated risk share is labelled as a returned sample with incomplete coverage", () => {
  render(<GovernanceOverview state={{loading:false,data:{status:"available",risk_share:20,risk_share_scope:"partial_saved_sample",risk_share_basis:"已返回扫描样本风险比例",alert_events:1,risk_subjects:2,evaluated_subjects:10,coverage:{ET:"complete",ST:"not_scanned",THT:"not_scanned"},by_program:{ET:1},by_region:{APAC:1},by_level:{critical:1},states:{pending:1,in_progress:0,closed:0,unknown:0},weekly:[],submitters:[],updated_at:"fixture",time_basis:"保存指标窗口",notification_binding:"成功回执"}}}/>);
  expect(screen.getByText("已返回扫描样本风险占比")).toBeTruthy();expect(screen.getByText("20%",{exact:true})).toBeTruthy();expect(screen.getByText(/当前范围不完整，仅代表已返回样本/)).toBeTruthy();
});
