import { OverviewDashboard } from "./overview-dashboard";
import "./operations.css";
const links = [ ["数据总览 / Overview","?tab=data-overview"], ["治理总览","?tab=overview"], ["风险监控与预警","?tab=risk"], ["治理效果分析","?tab=analysis"], ["运营数据中心","?tab=data"] ];
export default function IntegratedOverview() {
 return <main className="ops-app"><header className="ops-header"><div className="ops-brand"><div className="ops-brand-mark">TAP</div><div><span>TAP GOVERNANCE</span><h1>风险治理工作台</h1></div></div></header><nav aria-label="工作台主导航" className="integrated-main-nav">{links.map(([label,href],i)=><a key={href} href={href} aria-current={i===0?"page":undefined}>{label}</a>)}</nav><div className="ops-content"><OverviewDashboard embedded/></div></main>;
}
