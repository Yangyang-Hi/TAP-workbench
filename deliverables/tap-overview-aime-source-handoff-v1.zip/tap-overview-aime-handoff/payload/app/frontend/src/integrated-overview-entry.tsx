import ReactDOM from "react-dom/client";
import { useEffect, useState } from "react";
import IntegratedOverview from "./pages/governance/integrated-overview";
import { getCurrentUser, redirectToLogin } from "./auth";
import { initPageControl } from "./page-control-runtime";
import "./styles/global.css";
function Root() {
 const [state,setState]=useState("loading"),[error,setError]=useState("");
 useEffect(()=>{let alive=true;void getCurrentUser().then(user=>{if(alive)setState(user?"ready":"login")}).catch(e=>{if(alive){setState("failed");setError(e.message)}});return()=>{alive=false}},[]);
 return state==="ready"?<IntegratedOverview/>:<div style={{padding:40,fontFamily:"sans-serif"}}><h2>TAP 数据总览</h2><p>{state==="loading"?"正在验证 AIME 访问身份…":state==="login"?"请登录公司账号后进入工作台。":error}</p>{state!=="loading"&&<button onClick={()=>void redirectToLogin()}>登录 / 重新验证</button>}</div>;
}
initPageControl();const root=document.getElementById("root");if(root)ReactDOM.createRoot(root).render(<Root/>);
