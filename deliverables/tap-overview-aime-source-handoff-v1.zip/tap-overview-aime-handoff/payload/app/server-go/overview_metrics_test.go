package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"path/filepath"
	"strings"
	"testing"
)

func overviewTierRows(metric string, values []any) []map[string]any {
	rows := []map[string]any{}
	for i, v := range values {
		rows = append(rows, map[string]any{"tier": overviewTierKeys[i], metric: v})
	}
	return rows
}

func TestOverviewNewProfilesAreReadOnlyAndScoped(t *testing.T) {
	for key, p := range overviewMetricProfiles() {
		if p.Key != key || p.RID == 0 || p.AppID == 0 || p.SID == 0 {
			t.Fatal(p)
		}
		if found, ok := overviewMetricSource(p.Source); !ok || found.Key != key {
			t.Fatal("profile registry", key)
		}
	}
	if _, ok := overviewMetricSource("et_current_ccr_nfs"); ok {
		t.Fatal("existing scan source was captured by Overview")
	}
}

func TestOverviewRevenueRequiresUnambiguousCompleteScope(t *testing.T) {
	p := overviewMetricProfiles()["revenue"]
	f := overviewFilter{"2026-10-01", "2026-10-26", "Global"}
	for _, tc := range []struct {
		name, status string
		rows         []map[string]any
		share        bool
	}{
		{"complete", "available", overviewTierRows("revenue", []any{10., 20., 30., 40.}), true},
		{"missing", "partial", overviewTierRows("revenue", []any{10., 20., 30.}), false},
		{"null", "partial", overviewTierRows("revenue", []any{10., nil, 30., 40.}), false},
		{"zero", "available", overviewTierRows("revenue", []any{0., 0., 0., 0.}), false},
		{"negative", "available", overviewTierRows("revenue", []any{-1., 20., 30., 40.}), false},
		{"duplicate", "unavailable", append(overviewTierRows("revenue", []any{10., 20., 30., 40.}), map[string]any{"tier": "strategic_trust", "revenue": 10.}), false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			o := overviewMetricValues(overviewEmptyMetric(p, f), p, tc.rows)
			if o.Status != tc.status {
				t.Fatalf("%s: %+v", tc.name, o)
			}
			if tc.share {
				if o.Summary["revenue"] != 100. || o.Rows[0]["share"] != 10. {
					t.Fatal(o)
				}
			} else {
				for _, r := range o.Rows {
					if r["share"] != nil {
						t.Fatal("misleading share", o)
					}
				}
			}
		})
	}
}

func TestOverviewNativeSummaryNeverAveragesCCR(t *testing.T) {
	p := overviewMetricProfiles()["p0"]
	f := overviewFilter{"2026-10-01", "2026-10-26", "APAC"}
	o := overviewMetricValues(overviewEmptyMetric(p, f), p, []map[string]any{{"ccr": 2., "nfs": 5.}, {"ccr": 100., "nfs": 20.}})
	if o.Status != "unavailable" || o.Summary["ccr"] != nil {
		t.Fatal("multiple source CCR rows were averaged", o)
	}
	o = overviewMetricValues(overviewEmptyMetric(p, f), p, []map[string]any{{"ccr": 0., "nfs": nil}})
	if o.Status != "partial" || o.Summary["ccr"] != 0. || o.Summary["nfs"] != nil {
		t.Fatal("real 0 and NULL confused", o)
	}
}

func TestOverviewMetricMappingRejectsAmbiguity(t *testing.T) {
	p := overviewMetricProfiles()["p0"]
	rows, err := overviewCanonicalMetrics([]map[string]any{{"c": "4.2", "n": 12}}, map[string]string{"c": "Dynamic P0 Content CCR", "n": "P0: Negative Feedback Show"}, p)
	if err != nil || rows[0]["ccr"] != "4.2" || rows[0]["nfs"] != 12 {
		t.Fatal(rows, err)
	}
	_, err = overviewCanonicalMetrics([]map[string]any{{"ccr": 1, "other": 2, "n": 3}}, map[string]string{"ccr": "p0_ccr", "other": "dynamic_p0_ccr", "n": "p0_nfs"}, p)
	if err == nil {
		t.Fatal("two CCR columns accepted")
	}
}

func TestOverviewNativeGroupingPreservesFormulaAndFixedPredicates(t *testing.T) {
	p := overviewMetricProfiles()["p0"]
	raw := map[string]any{"query": map[string]any{"dimensions": []any{map[string]any{"id": p.RegionID}, map[string]any{"id": p.TierID}, map[string]any{"id": p.DateID}}, "groupByIdList": []any{p.RegionID, p.TierID, p.DateID}, "measures": []any{map[string]any{"expression": "native CCR formula"}}, "whereList": []any{map[string]any{"id": p.RegionID, "val": []any{"CNOB"}}, map[string]any{"id": "business_fixed", "val": []any{"keep"}}}}}
	q := overviewMetricRequest(raw, p, filterRequest{})["query"].(map[string]any)
	if len(q["dimensions"].([]any)) != 0 || len(q["groupByIdList"].([]any)) != 0 {
		t.Fatal("global summary still grouped by Tier/Region/date", q)
	}
	if !strings.Contains(fmt.Sprint(q), "native CCR formula") || !strings.Contains(fmt.Sprint(q), "business_fixed") || strings.Contains(fmt.Sprint(q), "CNOB") {
		t.Fatal("fixed formula/filter lost or stale Region retained", q)
	}
	p = overviewMetricProfiles()["p0-weekly"]
	raw["query"].(map[string]any)["dimensions"] = []any{map[string]any{"id": "source_week", "expression": "toStartOfWeek(p_date)"}, map[string]any{"id": p.TierID}, map[string]any{"id": p.RegionID}}
	q = overviewMetricRequest(raw, p, filterRequest{})["query"].(map[string]any)
	if len(q["dimensions"].([]any)) != 2 || !strings.Contains(fmt.Sprint(q), "toStartOfWeek(p_date)") {
		t.Fatal("week grain was destroyed", q)
	}
}

func TestOverviewDateAndRegionValidation(t *testing.T) {
	for _, q := range []url.Values{{"start_date": {"bad"}}, {"start_date": {"2026-10-26"}, "end_date": {"2026-10-01"}}, {"end_date": {"2099-01-01"}}, {"region": {"JP"}}} {
		if _, err := overviewParseWindow(q); err == nil {
			t.Fatal("invalid window accepted", q)
		}
	}
	f, err := overviewParseWindow(url.Values{"start_date": {"2010-01-01"}, "end_date": {"2026-10-26"}, "region": {"CNOB"}})
	if err != nil || f.Start != "2010-01-01" {
		t.Fatal("historical interval improperly limited to snapshot lookback", f, err)
	}
	historical, err := overviewParseWindow(url.Values{"end_date": {"2025-05-17"}})
	if err != nil || historical.Start != "2025-04-01" {
		t.Fatal("end-only default must use the selected quarter", historical, err)
	}
	p := overviewMetricProfiles()["revenue"]
	ids := []any{}
	for _, id := range []string{p.DateID, p.RegionID, p.TierID} {
		ids = append(ids, map[string]any{"id": id})
	}
	chart, err := overviewMetricChart(map[string]any{"schema": ids}, map[string]any{}, p, filterRequest{StartDate: f.Start, EndDate: f.End, Region: f.Region})
	if err != nil || !strings.Contains(fmt.Sprint(chart), "2010-01-01 00:00:00") {
		t.Fatal("date range not pushed", chart, err)
	}
}

func TestOverviewMetricHandlerDoesNotForwardOperationalFilters(t *testing.T) {
	old := overviewQueryReport
	t.Cleanup(func() { overviewQueryReport = old })
	overviewQueryReport = func(_ context.Context, r *http.Request, source string) (map[string]any, error) {
		if source != "overview_metric_revenue" || r.URL.Query().Get("submitter") != "" || r.URL.Query().Get("client_tier") != "" || r.URL.Query().Get("client_ids") != "" {
			t.Fatal(r.URL, source)
		}
		return map[string]any{"status": "ok", "business_rows": overviewTierRows("revenue", []any{10., 20., 30., 40.})}, nil
	}
	r := httptest.NewRequest("GET", "/api/overview/metrics/revenue?start_date=2026-10-01&end_date=2026-10-26&submitter=someone&client_tier=ET&client_ids=1", nil)
	r.SetPathValue("metric", "revenue")
	w := httptest.NewRecorder()
	overviewMetricsHandler(w, r)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"revenue":100`) {
		t.Fatal(w.Code, w.Body.String())
	}
}

func TestOverviewMetricEndToEndSavedReportProfiles(t *testing.T) {
	oldClient, oldDir := httpClient, pluginDir
	pluginDir, _ = filepath.Abs("../..")
	t.Cleanup(func() { httpClient, pluginDir = oldClient, oldDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	t.Setenv("AIME_PLUGIN_RUNTIME_DIR", t.TempDir())
	for _, p := range overviewMetricProfiles() {
		if !containsString([]string{"revenue", "p0", "p0-weekly", "p1-weekly", "approval"}, p.Key) {
			continue
		}
		t.Run(p.Key, func(t *testing.T) {
			queries := 0
			httpClient = &http.Client{Transport: overviewRoundTrip(func(r *http.Request) (*http.Response, error) {
				var payload any
				switch r.URL.Path {
				case "/titan/passport/token":
					payload = map[string]any{"data": map[string]any{"token": "fixture-titan"}}
				case aeolusSessionProbePath:
					payload = map[string]any{"code": 0}
				case aeolusSavedReportPath:
					dims := []any{map[string]any{"dimMetId": p.DateID, "uniqueId": "date_uid"}, map[string]any{"dimMetId": p.RegionID, "uniqueId": "region_uid"}, map[string]any{"dimMetId": p.TierID, "uniqueId": "tier_uid"}, map[string]any{"dimMetId": "10000000032606", "uniqueId": "online_uid"}}
					if p.Weekly {
						dims = append(dims, map[string]any{"dimMetId": "source_week", "uniqueId": "week_uid", "name": "week"})
					}
					measures := []any{}
					for k, aliases := range p.Metrics {
						measures = append(measures, map[string]any{"uniqueId": k + "_uid", "name": aliases[0], "expression": "native_" + k})
					}
					grouped := dims[:3]
					if p.Weekly {
						grouped = []any{dims[4], dims[1], dims[2]}
					}
					payload = map[string]any{"data": map[string]any{"reqJson": map[string]any{"version": 4, "schema": map[string]any{"dimensions": dims, "measures": measures}, "query": map[string]any{"datasetId": p.SID, "dimensions": grouped, "measures": measures, "whereList": []any{map[string]any{"id": "fixed_business", "op": "in", "val": []any{"keep"}}}}}}}
				case aeolusVQSQueryPath:
					queries++
					var req map[string]any
					if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
						t.Fatal(err)
					}
					body := fmt.Sprint(req)
					if !strings.Contains(body, "fixed_business") || !strings.Contains(body, "2026-10-26") {
						t.Fatal("governed source filters changed", body)
					}
					rows := []any{}
					n := 1
					if p.ByTier {
						n = 4
					}
					for i := 0; i < n; i++ {
						row := map[string]any{}
						if p.ByTier {
							row["tier_uid"] = overviewTierKeys[i]
						}
						if p.Weekly {
							row["week_uid"] = "2026-10-19"
						}
						for k := range p.Metrics {
							row[k+"_uid"] = float64(i + 1)
						}
						rows = append(rows, row)
					}
					payload = map[string]any{"code": 0, "data": map[string]any{"rows": rows}}
				default:
					return nil, fmt.Errorf("unexpected external request %s", r.URL.Path)
				}
				b, _ := json.Marshal(payload)
				return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"application/json"}}, Body: io.NopCloser(strings.NewReader(string(b))), Request: r}, nil
			})}
			r := httptest.NewRequest("GET", "/api/overview/metrics/"+p.Key+"?start_date=2026-10-01&end_date=2026-10-26&region=APAC", nil)
			r.Header.Set("Authorization", "Byte-Cloud-JWT fixture")
			r.SetPathValue("metric", p.Key)
			w := httptest.NewRecorder()
			overviewMetricsHandler(w, r)
			if w.Code != 200 || !strings.Contains(w.Body.String(), `"status":"available"`) || queries != 1 {
				t.Fatalf("%s: %d %s", p.Key, w.Code, w.Body.String())
			}
		})
	}
}
