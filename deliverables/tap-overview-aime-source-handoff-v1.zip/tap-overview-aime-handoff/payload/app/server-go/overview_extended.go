package main

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"
)

func overviewAdditionalProfiles(base, approval overviewMetricProfile) []overviewMetricProfile {
	actor := overviewMetricProfile{AppID: 800414, SID: 1280034, DateID: "10000002555291", RegionID: "10000016013590", TierID: "10000012645665"}
	summary := actor
	summary.Key = "business-summary"
	summary.RID = 2892274
	summary.Label = "TAP 原生区间总卡"
	summary.Metrics = map[string][]string{"account_count": {"TAP Accounts", "tap_accounts", "account_count"}, "revenue": {"TAP Revenue", "tap_revenue"}}
	approvals := approval
	approvals.Key = "approval-weekly"
	approvals.RID = 2883018
	approvals.RegionalRID = 2883037
	approvals.Weekly = true
	approvals.Metrics = map[string][]string{"rate": {"Approval Rate", "approval_rate"}, "volume": {"banned"}}
	fdr := overviewMetricProfile{Key: "fdr-weekly", Label: "Ads FDR 周趋势", AppID: 800414, SID: 1198629, RID: 2883048, RegionalRID: 2883021, RegionID: "10000000894158", ByTier: true, Weekly: true, WeekWindow: true, RegionMode: "audit", Metrics: map[string][]string{"rate": {"ads_fdr", "false_discovery_rate", "FDR"}}}
	overturned := fdr
	overturned.Key = "overturned-weekly"
	overturned.Label = "Overturned Account 周趋势"
	overturned.RID = 2883046
	overturned.RegionalRID = 0
	overturned.Metrics = map[string][]string{"volume": {"overturned_account_volume"}}
	regionAccounts := actor
	regionAccounts.Key = "region-accounts"
	regionAccounts.Label = "区域账户快照分布"
	regionAccounts.RID = 2883033
	regionAccounts.RegionID = "10000014496228"
	regionAccounts.ByRegion = true
	regionAccounts.ByTier = true
	regionAccounts.Snapshot = true
	regionAccounts.RegionMode = "actor"
	regionAccounts.Metrics = map[string][]string{"account_count": {"TAP Accounts", "account_count", "Account Count", "accountCount"}}
	regionRevenue := regionAccounts
	regionRevenue.Key = "region-revenue"
	regionRevenue.Label = "区域区间营收分布"
	regionRevenue.Snapshot = false
	regionRevenue.Metrics = map[string][]string{"revenue": {"revenue"}}
	tap := regionAccounts
	tap.Key = "comparison-tap"
	tap.Label = "TAP 区域账户快照"
	tap.RID = 2529294
	tap.ByTier = false
	tap.Cohort = "tap"
	tap.Metrics = map[string][]string{"account_count": {"account_count", "Account Count", "accountCount", "TAP Accounts"}}
	non := tap
	non.Key = "comparison-non-tap"
	non.Label = "Non-TAP 区域账户快照"
	non.Cohort = "non-tap"
	non.Metrics = map[string][]string{"account_count": {"account_count", "Account Count", "accountCount"}}
	tapRevenue := tap
	tapRevenue.Key = "comparison-tap-revenue"
	tapRevenue.Label = "TAP 区域区间营收"
	tapRevenue.Snapshot = false
	tapRevenue.Metrics = map[string][]string{"revenue": {"revenue"}, "approval_rate": {"approval_rate", "Approval Rate"}}
	tapRevenue.OptionalMetrics = map[string]bool{"approval_rate": true}
	nonRevenue := tapRevenue
	nonRevenue.Key = "comparison-non-tap-revenue"
	nonRevenue.Label = "Non-TAP 区域区间营收"
	nonRevenue.Cohort = "non-tap"
	return []overviewMetricProfile{summary, approvals, fdr, overturned, regionAccounts, regionRevenue, tap, non, tapRevenue, nonRevenue}
}

func overviewSelectProfile(p overviewMetricProfile, region string) overviewMetricProfile {
	if p.RegionalRID > 0 && region != "Global" {
		p.RID = p.RegionalRID
		p.Source += "~region"
	}
	return p
}

func overviewTierPredicate(p overviewMetricProfile) map[string]any {
	if p.Cohort == "non-tap" {
		predicate := aeolusFilter(p.TierID, p.TierID, "IN", append(append([]string{}, overviewTierKeys...), "Unknown", "unknown", "UNKNOWN", "NULL", "null", ""))
		predicate["detail"].(map[string]any)["operator"] = "not in"
		return predicate
	}
	return aeolusFilter(p.TierID, p.TierID, "IN", overviewTierKeys)
}

// Resolve only exact semantic names in the executable source schema. No field
// ID is invented from a report title or copied from an unrelated dataset.
func overviewSchemaField(raw map[string]any, aliases ...string) (string, error) {
	found := map[string]bool{}
	var walk func(any)
	walk = func(v any) {
		switch n := v.(type) {
		case map[string]any:
			id := firstNonEmpty(n, "dimMetId", "datasetFieldId", "originId", "id")
			for _, key := range []string{"name", "alias", "sourceName", "displayName", "fieldName", "originName"} {
				value := strings.TrimSpace(strings.SplitN(asString(n[key]), "[", 2)[0])
				for _, alias := range aliases {
					if id != "" && strings.EqualFold(value, alias) {
						found[id] = true
					}
				}
			}
			for _, child := range n {
				walk(child)
			}
		case []any:
			for _, child := range n {
				walk(child)
			}
		}
	}
	// Filters may use an arbitrary display label, so only dimension schemas count.
	for _, container := range []map[string]any{raw, func() map[string]any { q, _ := raw["query"].(map[string]any); return q }()} {
		if schema, ok := container["schema"].(map[string]any); ok {
			walk(schema["dimensions"])
		}
		walk(container["dimensions"])
	}
	if len(found) != 1 {
		return "", fmt.Errorf("真实保存报表字段 %v 匹配 %d 个ID；需核对源端定义", aliases, len(found))
	}
	for id := range found {
		return id, nil
	}
	return "", nil
}

func overviewResolveMetricProfile(raw map[string]any, p overviewMetricProfile) (overviewMetricProfile, error) {
	if q, ok := raw["query"].(map[string]any); ok {
		if sid := contractIDString(q["datasetId"]); sid != "" && sid != fmt.Sprint(p.SID) {
			return p, fmt.Errorf("Saved Report dataset %s 与声明 SID %d 不一致", sid, p.SID)
		}
	}
	var err error
	if p.TierID == "" {
		p.TierID, err = overviewSchemaField(raw, "tier_v3_name", "Tier V3")
		if err != nil {
			return p, err
		}
	}
	if p.WeekWindow {
		p.DateID, err = overviewSchemaField(raw, "week", "周")
		if err != nil {
			return p, err
		}
		query, _ := raw["query"].(map[string]any)
		where, _ := query["whereList"].([]any)
		for _, item := range where {
			node, _ := item.(map[string]any)
			if firstNonEmpty(node, "id", "datasetFieldId", "fieldId", "originId") == p.DateID && !strings.EqualFold(firstNonEmpty(node, "name"), "week") {
				return p, fmt.Errorf("源周字段与既有快照过滤共用ID；未覆盖p_date，需独立周筛选合同")
			}
		}

	}
	return p, nil
}

func overviewSourceRegion(region, mode string) (string, error) {
	if region == "Global" {
		return "", nil
	}
	if mode == "audit" {
		mapping := map[string]string{"APAC": "APAC Team", "EUI": "EUI Team", "LATAM": "LATAM Team", "METAP": "METAP Team", "NA": "NA Team"}
		if value, ok := mapping[region]; ok {
			return value, nil
		}
		return "", fmt.Errorf("%s 在 Audit 周趋势尚无已验证区域映射，未用 Global 代替", region)
	}
	if mode == "actor" {
		mapping := map[string]string{"APAC": "APAC-APAC,AU Team,APAC", "CNOB": "APAC-China Outbound", "EUI": "EUI Team", "LATAM": "LATAM Team", "METAP": "METAP Team", "NA": "NA Team", "GA": "GA & A", "Scaled Growth": "Scaled Growth Agency"}
		if value, ok := mapping[region]; ok {
			return value, nil
		}
		return "", fmt.Errorf("%s 在 account_final_region 尚无已验证对应关系", region)
	}
	return region, nil
}
func overviewActorRegion(value string) string {
	m := map[string]string{"APAC-APAC": "APAC", "AU Team": "APAC", "APAC": "APAC", "APAC-China Outbound": "CNOB", "APAC-Japan": "JP", "EUI Team": "EUI", "LATAM Team": "LATAM", "METAP Team": "METAP", "NA Team": "NA", "Scaled Growth Agency": "Scaled Growth", "GA & A": "GA"}
	if v, ok := m[value]; ok {
		return v
	}
	if value == "" || value == "NULL" {
		return "Other"
	}
	// Keep every original source group in source_region. Unknown groups may
	// share a display label but are never summed into an apparent distinct count.
	if containsString([]string{"LATAM", "NA", "METAP", "EUI", "APAC", "JP", "KR", "CNOB", "Scaled Growth", "GA", "Other"}, value) {
		return value
	}
	return "Other"
}

func overviewLoadMetric(r *http.Request, p overviewMetricProfile, f overviewFilter) overviewMetricResult {
	o := overviewEmptyMetric(p, f)
	region, err := overviewSourceRegion(f.Region, p.RegionMode)
	if err != nil {
		o.Reason = err.Error()
		return o
	}
	if p.WeekWindow {
		o.Source["time_basis"] = "whole_source_weeks_intersecting_window; saved p_date snapshot preserved"
	}
	if p.Snapshot {
		o.Source["time_basis"] = "latest_nonempty_snapshot_within_14_days"
	}
	if p.Cohort != "" {
		o.Source["tier_scope"] = p.Cohort + "; NULL/Unknown excluded from Non-TAP"
	}
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()
	attempts := 1
	if p.Snapshot {
		attempts = 14
	}
	for offset := 0; offset < attempts; offset++ {
		queryStart, queryEnd := f.Start, f.End
		if p.Snapshot {
			d, _ := time.Parse("2006-01-02", f.End)
			queryStart = d.AddDate(0, 0, -offset).Format("2006-01-02")
			queryEnd = queryStart
		}
		if p.WeekWindow {
			d, _ := time.Parse("2006-01-02", f.Start)
			queryStart = d.AddDate(0, 0, -6).Format("2006-01-02")
		}
		request := r.Clone(ctx)
		u := *r.URL
		q := url.Values{"start_date": {queryStart}, "end_date": {queryEnd}}
		if region != "" {
			q.Set("region", region)
		}
		u.RawQuery = q.Encode()
		request.URL = &u
		request.Form = nil
		request.PostForm = nil
		probe, e := overviewQueryReport(ctx, request, p.Source)
		if e != nil {
			o.Reason = "风神请求未完成，请查看模块诊断。"
			o.Diagnostics["error"] = sanitizeAuditText(e.Error())
			return o
		}
		o.Diagnostics = map[string]any{"status": probe["status"], "audit_id": probe["audit_id"], "request_id": probe["requestId"], "log_id": probe["logId"], "blocked_stage": probe["blocked_stage"], "failure_classification": probe["failure_classification"], "columns": probe["columns"], "resolved_contract": probe["resolved_overview_contract"], "filter_error": probe["filter_error"], "partition": probe["partition"], "attempts": offset + 1}
		if asString(probe["status"]) != "ok" {
			o.Reason = "鉴权、报表合同或查询未通过，详见本模块诊断。"
			return o
		}
		if asBool(probe["possibly_truncated"]) {
			o.Reason = "查询结果可能截断，未生成完整汇总。"
			return o
		}
		rows, ok := probe["business_rows"].([]map[string]any)
		if !ok {
			o.Reason = "返回结构不符合合同。"
			return o
		}
		if p.WeekWindow {
			rows, e = overviewFilterWeeks(rows, f)
			if e != nil {
				o.Reason = e.Error()
				return o
			}
		}
		if p.Snapshot && len(rows) == 0 {
			continue
		}
		if p.Snapshot {
			o.Source["data_as_of"] = queryEnd
		}
		o = overviewMetricValues(o, p, rows)
		if p.ByRegion {
			sort.Slice(o.Rows, func(i, j int) bool {
				order := []string{"LATAM", "NA", "METAP", "EUI", "APAC", "JP", "KR", "CNOB", "Scaled Growth", "GA", "Other"}
				score := func(r map[string]any) int {
					for k, name := range order {
						if asString(r["region"]) == name {
							return k
						}
					}
					return len(order)
				}
				a, b := score(o.Rows[i]), score(o.Rows[j])
				if a != b {
					return a < b
				}
				return fmt.Sprint(o.Rows[i]["source_region"], o.Rows[i]["tier"]) < fmt.Sprint(o.Rows[j]["source_region"], o.Rows[j]["tier"])
			})
		}
		return o
	}
	o.Status = "no_data"
	o.Reason = "结束日前14天内无可用区域账户快照，未改用未来日期或补零。"
	return o
}

func overviewFilterWeeks(rows []map[string]any, f overviewFilter) ([]map[string]any, error) {
	out := []map[string]any{}
	for _, row := range rows {
		text := strings.TrimSpace(asString(row["week"]))
		if len(text) > 10 {
			text = text[:10]
		}
		day, e := time.Parse("2006-01-02", text)
		if e != nil {
			return nil, fmt.Errorf("源 week 不是可核实的日期，未猜测周编号或归入所选范围")
		}
		if text <= f.End && day.AddDate(0, 0, 6).Format("2006-01-02") >= f.Start {
			out = append(out, row)
		}
	}
	return out, nil
}
