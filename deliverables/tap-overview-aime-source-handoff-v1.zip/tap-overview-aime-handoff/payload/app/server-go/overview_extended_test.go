package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

func TestOverviewExtendedSourceSelectionAndRegionContracts(t *testing.T) {
	profiles := overviewMetricProfiles()
	for _, tc := range []struct {
		key, region string
		rid         int
	}{{"approval-weekly", "Global", 2883018}, {"approval-weekly", "CNOB", 2883037}, {"fdr-weekly", "Global", 2883048}, {"fdr-weekly", "APAC", 2883021}} {
		p := overviewSelectProfile(profiles[tc.key], tc.region)
		if p.RID != tc.rid {
			t.Fatal(p)
		}
		found, ok := overviewMetricSource(p.Source)
		if !ok || found.RID != p.RID {
			t.Fatal("physical source not registered", p)
		}
	}
	if got, e := overviewSourceRegion("APAC", "audit"); e != nil || got != "APAC Team" {
		t.Fatal(got, e)
	}
	if _, e := overviewSourceRegion("CNOB", "audit"); e == nil {
		t.Fatal("unverified CNOB silently fell back")
	}
	if got, e := overviewSourceRegion("APAC", "actor"); e != nil || !strings.Contains(got, "AU Team") {
		t.Fatal(got, e)
	}
}

func TestOverviewRuntimeSchemaBindingDoesNotGuessUnknownAuditFields(t *testing.T) {
	p := overviewMetricProfiles()["fdr-weekly"]
	if _, e := overviewResolveMetricProfile(map[string]any{"query": map[string]any{"datasetId": 1198629}}, p); e == nil {
		t.Fatal("missing fields guessed")
	}
	dims := []any{map[string]any{"dimMetId": "fixture_tier", "name": "tier_v3_name"}, map[string]any{"dimMetId": "fixture_week", "name": "week"}}
	raw := map[string]any{"query": map[string]any{"datasetId": 1198629}, "schema": map[string]any{"dimensions": dims}}
	found, e := overviewResolveMetricProfile(raw, p)
	if e != nil || found.TierID != "fixture_tier" || found.DateID != "fixture_week" {
		t.Fatal(found, e)
	}
	raw["query"].(map[string]any)["whereList"] = []any{map[string]any{"id": "fixture_week", "name": "p_date", "val": []any{"latest"}}}
	if _, e := overviewResolveMetricProfile(raw, p); e == nil {
		t.Fatal("snapshot partition overwritten by week filter")
	}
	delete(raw["query"].(map[string]any), "whereList")
	dims = append(dims, map[string]any{"dimMetId": "other_tier", "name": "tier_v3_name"})
	raw["schema"].(map[string]any)["dimensions"] = dims
	if _, e := overviewResolveMetricProfile(raw, p); e == nil {
		t.Fatal("ambiguous Tier resolved")
	}
	raw["query"].(map[string]any)["datasetId"] = 123
	if _, e := overviewResolveMetricProfile(raw, p); e == nil {
		t.Fatal("wrong dataset accepted")
	}
}

func TestOverviewAuditWindowPreservesSnapshotAndFixedBusinessPredicates(t *testing.T) {
	p := overviewMetricProfiles()["fdr-weekly"]
	p.DateID = "fixture_week"
	p.TierID = "fixture_tier"
	fixed := []any{map[string]any{"id": "native_partition", "name": "p_date", "op": "eq", "val": []any{"latest_snapshot"}}, map[string]any{"id": "product_filter", "val": []any{"Auction", "ACC", "FPR"}}}
	dims := []any{map[string]any{"dimMetId": p.DateID, "name": "week"}, map[string]any{"dimMetId": p.TierID}, map[string]any{"dimMetId": p.RegionID}}
	raw := map[string]any{"query": map[string]any{"datasetId": p.SID, "dimensions": dims, "whereList": fixed}}
	f := filterRequest{StartDate: "2026-10-01", EndDate: "2026-10-26", Region: "APAC Team"}
	chart, e := overviewMetricChart(raw, map[string]any{}, p, f)
	if e != nil {
		t.Fatal(e)
	}
	body, e := savedReportVQSRequest(raw, chart, p.config(), f, nil, "")
	if e != nil {
		t.Fatal(e)
	}
	body = overviewMetricRequest(body, p, f)
	text := fmt.Sprint(body)
	if p.Cohort == "non-tap" && !strings.Contains(text, "not in") {
		t.Fatal("Non-TAP predicate lost", text)
	}
	if !strings.Contains(text, "latest_snapshot") || !strings.Contains(text, "Auction") || !strings.Contains(text, "APAC Team") {
		t.Fatal(body)
	}
	rows, e := overviewFilterWeeks([]map[string]any{{"week": "2026-09-28"}, {"week": "2026-10-26"}, {"week": "2026-09-21"}, {"week": "2026-11-02"}}, overviewFilter{"2026-10-01", "2026-10-26", "Global"})
	if e != nil || len(rows) != 2 {
		t.Fatal(rows, e)
	}
}

func TestOverviewNonTAPQueriesUseNativeDistinctWithoutSummingTiers(t *testing.T) {
	p := overviewMetricProfiles()["comparison-non-tap"]
	pred := overviewTierPredicate(p)
	text := fmt.Sprint(pred)
	if !strings.Contains(text, "not in") || !strings.Contains(text, "Unknown") || !strings.Contains(text, "strategic_trust") {
		t.Fatal(pred)
	}
	raw := map[string]any{"query": map[string]any{"dimensions": []any{map[string]any{"dimMetId": p.RegionID}, map[string]any{"dimMetId": p.TierID}}, "measures": []any{map[string]any{"expression": "COUNT DISTINCT account_id"}}}}
	raw["query"].(map[string]any)["whereList"] = []any{map[string]any{"id": p.TierID, "op": "in", "val": []string{"must_exclude"}}}
	q := overviewMetricRequest(raw, p, filterRequest{})["query"].(map[string]any)
	if q["whereList"].([]any)[0].(map[string]any)["op"] != "not in" {
		t.Fatal("Non-TAP became a positive Tier selection", q)
	}
	if len(q["dimensions"].([]any)) != 1 || !strings.Contains(fmt.Sprint(q), "COUNT DISTINCT account_id") {
		t.Fatal(q)
	}
	o := overviewMetricValues(overviewEmptyMetric(p, overviewFilter{}), p, []map[string]any{{"region": "NA Team", "account_count": 3}, {"region": "NA Team", "account_count": 4}})
	if o.Status != "unavailable" {
		t.Fatal("duplicate aggregate rows were accepted", o)
	}
}

func TestOverviewRegionSnapshotAndIntervalSemanticsStaySeparate(t *testing.T) {
	old := overviewQueryReport
	t.Cleanup(func() { overviewQueryReport = old })
	calls := 0
	overviewQueryReport = func(_ context.Context, r *http.Request, source string) (map[string]any, error) {
		calls++
		q := r.URL.Query()
		if source == overviewMetricProfiles()["region-accounts"].Source {
			if q.Get("start_date") != q.Get("end_date") {
				t.Fatal("account daily counts would be summed", q)
			}
			if calls == 1 {
				return map[string]any{"status": "ok", "business_rows": []map[string]any{}}, nil
			}
			return map[string]any{"status": "ok", "business_rows": []map[string]any{{"tier": "strategic_trust", "region": "NA Team", "account_count": 7}}}, nil
		}
		if q.Get("start_date") != "2026-10-01" || q.Get("end_date") != "2026-10-26" {
			t.Fatal("Revenue turned into snapshot", q)
		}
		return map[string]any{"status": "ok", "business_rows": []map[string]any{{"tier": "strategic_trust", "region": "NA Team", "revenue": 7.}}}, nil
	}
	f := overviewFilter{"2026-10-01", "2026-10-26", "Global"}
	r := httptest.NewRequest("GET", "/", nil)
	a := overviewLoadMetric(r, overviewMetricProfiles()["region-accounts"], f)
	if a.Source["data_as_of"] != "2026-10-25" || a.Status != "available" {
		t.Fatal(a)
	}
	b := overviewLoadMetric(r, overviewMetricProfiles()["region-revenue"], f)
	if b.Status != "available" {
		t.Fatal(b)
	}
}

func TestOverviewExtendedSavedReportEndToEnd(t *testing.T) {
	oldClient, oldDir := httpClient, pluginDir
	pluginDir, _ = filepath.Abs("../..")
	t.Cleanup(func() { httpClient, pluginDir = oldClient, oldDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	t.Setenv("AIME_PLUGIN_RUNTIME_DIR", t.TempDir())
	for key, original := range overviewMetricProfiles() {
		if containsString([]string{"revenue", "p0", "p0-weekly", "p1-weekly", "approval"}, key) {
			continue
		}
		for _, region := range []string{"Global", "APAC"} {
			t.Run(key+"/"+region, func(t *testing.T) {
				p := overviewSelectProfile(original, region)
				if p.DateID == "" {
					p.DateID = "fixture_week"
				}
				if p.TierID == "" {
					p.TierID = "fixture_tier"
				}
				dims := []any{map[string]any{"dimMetId": p.DateID, "uniqueId": "date_uid", "name": map[bool]string{true: "week", false: "p_date"}[p.WeekWindow]}, map[string]any{"dimMetId": p.RegionID, "uniqueId": "region_uid", "name": "account_final_region"}, map[string]any{"dimMetId": p.TierID, "uniqueId": "tier_uid", "name": "tier_v3_name"}}
				projected := []any{}
				if p.ByTier {
					projected = append(projected, dims[2])
				}
				if p.ByRegion {
					projected = append(projected, dims[1])
				}
				if p.Weekly {
					if p.WeekWindow {
						projected = append(projected, dims[0])
					} else {
						d := map[string]any{"dimMetId": "fixture_week", "uniqueId": "week_uid", "name": "week"}
						dims = append(dims, d)
						projected = append(projected, d)
					}
				}
				measures := []any{}
				for k, aliases := range p.Metrics {
					measures = append(measures, map[string]any{"uniqueId": k + "_uid", "name": aliases[0], "expression": "native_" + k})
				}
				queries := 0
				httpClient = &http.Client{Transport: overviewRoundTrip(func(r *http.Request) (*http.Response, error) {
					var payload any
					switch r.URL.Path {
					case "/titan/passport/token":
						payload = map[string]any{"data": map[string]any{"token": "fixture"}}
					case aeolusSessionProbePath:
						payload = map[string]any{"code": 0}
					case aeolusSavedReportPath:
						if r.URL.Query().Get("reportId") != fmt.Sprint(p.RID) {
							t.Fatal("wrong regional report", r.URL)
						}
						payload = map[string]any{"data": map[string]any{"reqJson": map[string]any{"schema": map[string]any{"dimensions": dims, "measures": measures}, "query": map[string]any{"datasetId": p.SID, "dimensions": projected, "measures": measures, "whereList": []any{map[string]any{"id": "native_fixed", "val": []any{"preserved"}}}}}}}
					case aeolusVQSQueryPath:
						queries++
						var body map[string]any
						if e := json.NewDecoder(r.Body).Decode(&body); e != nil {
							t.Fatal(e)
						}
						text := fmt.Sprint(body)
						if p.Cohort == "non-tap" && !strings.Contains(text, "not in") {
							t.Fatal("Non-TAP predicate lost", text)
						}
						if !strings.Contains(text, "native_fixed") {
							t.Fatal("fixed source predicates lost", text)
						}
						row := map[string]any{}
						if p.ByTier {
							row["tier_uid"] = "strategic_trust"
						}
						if p.ByRegion {
							row["region_uid"] = "APAC"
						}
						if p.Weekly {
							if p.WeekWindow {
								row["date_uid"] = "2026-10-19"
							} else {
								row["week_uid"] = "2026-10-19"
							}
						}
						for k := range p.Metrics {
							row[k+"_uid"] = 10.
						}
						payload = map[string]any{"code": 0, "data": map[string]any{"rows": []any{row}}}
					default:
						return nil, fmt.Errorf("unexpected endpoint %s", r.URL.Path)
					}
					b, _ := json.Marshal(payload)
					return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"application/json"}}, Body: io.NopCloser(strings.NewReader(string(b))), Request: r}, nil
				})}
				r := httptest.NewRequest("GET", "/api/overview/metrics/"+key+"?start_date=2026-10-01&end_date=2026-10-26&region="+region, nil)
				r.Header.Set("Authorization", "Byte-Cloud-JWT fixture")
				r.SetPathValue("metric", key)
				w := httptest.NewRecorder()
				overviewMetricsHandler(w, r)
				if w.Code != 200 || !strings.Contains(w.Body.String(), `"status":"available"`) || queries != 1 {
					t.Fatalf("%d %s queries=%d", w.Code, w.Body.String(), queries)
				}
			})
		}
	}
}
