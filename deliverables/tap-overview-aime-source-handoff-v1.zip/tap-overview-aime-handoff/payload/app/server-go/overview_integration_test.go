package main

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestOverviewMergedNormalRoutesKeepAuthenticationAndOldMutations(t *testing.T) {
	old := appInstanceID
	appInstanceID = "merged-fixture"
	t.Cleanup(func() { appInstanceID = old })
	mux := http.NewServeMux()
	mountRoutes(mux)
	for _, path := range []string{"/api/overview/accounts", "/api/overview/metrics/business-summary", "/api/overview/metrics/fdr-weekly", "/api/overview/quota", "/api/overview/governance", "/api/workbench/read-model"} {
		w := httptest.NewRecorder()
		mux.ServeHTTP(w, httptest.NewRequest("GET", path, nil))
		if w.Code != 401 {
			t.Fatal(path, w.Code)
		}
	}
	for _, path := range []string{"/api/monitoring/risk-scans", "/api/workbench/cases/TAP-x/notify"} {
		w := httptest.NewRecorder()
		mux.ServeHTTP(w, httptest.NewRequest("POST", path, strings.NewReader(`{}`)))
		if w.Code != 401 {
			t.Fatal("existing mutation disappeared or lost auth", path, w.Code)
		}
	}
	callbackFound := false
	for _, r := range registry {
		if r.Path == "/api/integrations/feishu/card-callback" {
			callbackFound = true
			if !r.Public {
				t.Fatal("callback signature path was changed to browser auth")
			}
		}
	}
	if !callbackFound {
		t.Fatal("Feishu callback removed")
	}
}

func TestOverviewMergedHTTPStaticAndProxyAssets(t *testing.T) {
	oldDir, oldID := staticDir, appInstanceID
	staticDir = t.TempDir()
	appInstanceID = "merged-fixture"
	t.Cleanup(func() { staticDir, appInstanceID = oldDir, oldID })
	if e := os.MkdirAll(filepath.Join(staticDir, "assets"), 0755); e != nil {
		t.Fatal(e)
	}
	os.WriteFile(filepath.Join(staticDir, "index.html"), []byte(`<title>merged</title>`), 0644)
	os.WriteFile(filepath.Join(staticDir, "assets", "workbench.js"), []byte(`console.log("fixture")`), 0644)
	mux := http.NewServeMux()
	mountRoutes(mux)
	mux.HandleFunc("/", staticHandler)
	server := httptest.NewServer(mux)
	defer server.Close()
	for _, path := range []string{"/", "/?tab=data-overview", "/?tab=risk", "/?tab=analysis", "/?tab=data", "/?view=tasks&alert_id=TAP-old", "/proxy/123/assets/workbench.js"} {
		response, e := http.Get(server.URL + path)
		if e != nil {
			t.Fatal(e)
		}
		b, _ := io.ReadAll(response.Body)
		response.Body.Close()
		if response.StatusCode != 200 {
			t.Fatal(path, response.StatusCode)
		}
		if strings.Contains(path, "assets") && (strings.Contains(response.Header.Get("Content-Type"), "html") || !strings.Contains(string(b), "console.log")) {
			t.Fatal("gateway returned HTML for JS", path)
		}
	}
}

func TestOverviewMergedRiskShareUsesSavedClassificationAndMarksIncompleteScope(t *testing.T) {
	row := overviewCaseFixture("x", "person", "closed", 1).Row
	healthy := row
	healthy.Member.AccountID = "healthy"
	healthy.Level = "normal"
	job := wbJob{Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25", Region: "APAC"}, Status: "ready", Complete: true, Rows: []wbRow{row, healthy}}
	f := overviewFilter{"2026-10-01", "2026-10-26", "APAC"}
	data := overviewGovernanceData(nil, nil, wbDisk{Jobs: map[string]wbJob{"j": job}}, f, "", "", true)
	if data["risk_share"] != 50. || data["risk_share_scope"] != "partial_saved_sample" {
		t.Fatal(data)
	}
	data = overviewGovernanceData(nil, nil, wbDisk{Jobs: map[string]wbJob{"j": job}}, f, "ET", "", true)
	if data["risk_share_scope"] != "complete_saved_sample" {
		t.Fatal(data)
	}
	unknown := healthy
	unknown.Member.AccountID = "unknown"
	unknown.Level = "unavailable"
	job.Rows = append(job.Rows, unknown)
	data = overviewGovernanceData(nil, nil, wbDisk{Jobs: map[string]wbJob{"j": job}}, f, "ET", "", true)
	if data["risk_share"] != nil || data["unclassified_subjects"] != 1 {
		t.Fatal("unknown subjects treated as safe", data)
	}
}

func TestOverviewMergedReusesAmyPersistedBatchMergeWithoutWrites(t *testing.T) {
	job := readModelFixture(t, 2)
	path, e := wbStatePath()
	if e != nil {
		t.Fatal(e)
	}
	before, e := os.ReadFile(path)
	if e != nil {
		t.Fatal(e)
	}
	scans, e := overviewReadScans()
	if e != nil {
		t.Fatal(e)
	}
	if len(scans.Jobs) != 1 {
		t.Fatal(scans)
	}
	for _, got := range scans.Jobs {
		if len(got.Rows) != len(job.Rows) {
			t.Fatal("persisted membership lost", got)
		}
	}
	after, e := os.ReadFile(path)
	if e != nil || string(before) != string(after) {
		t.Fatal("read changed scan checkpoint", e)
	}
	request := httptest.NewRequest("GET", "/api/overview/governance?start_date=2026-10-12&end_date=2026-10-18&region=Global", nil).WithContext(wbReq("reader").Context())
	w := httptest.NewRecorder()
	overviewGovernanceHandler(w, request)
	var body struct {
		Data map[string]any `json:"data"`
	}
	if e := json.Unmarshal(w.Body.Bytes(), &body); e != nil {
		t.Fatal(e)
	}
	if body.Data["risk_subjects"] != 2. {
		t.Fatal("shared scheduler facts hidden from authenticated workbench reader", w.Body.String())
	}
	after, _ = os.ReadFile(path)
	if string(before) != string(after) {
		t.Fatal("governance generated or changed a scan")
	}
}

func TestOverviewMergedDispatchKeepsNativeTasksReportsAndBookmarks(t *testing.T) {
	old := staticDir
	staticDir = t.TempDir()
	t.Cleanup(func() { staticDir = old })
	os.WriteFile(filepath.Join(staticDir, "index.html"), []byte("<body>NATIVE_HOST</body>"), 0644)
	os.WriteFile(filepath.Join(staticDir, "overview.html"), []byte("<body>NEW_OVERVIEW</body>"), 0644)
	for _, tc := range []struct {
		path, want string
		link       bool
	}{{"/", "NEW_OVERVIEW", false}, {"/proxy/8791/?tab=data-overview", "NEW_OVERVIEW", false}, {"/proxy/8791/?tab=risk", "NATIVE_HOST", true}, {"/?tab=data-overview", "NEW_OVERVIEW", false}, {"/?view=overview", "NEW_OVERVIEW", false}, {"/?tab=overview", "NATIVE_HOST", true}, {"/?tab=risk&alert_id=TAP-x", "NATIVE_HOST", true}, {"/?tab=analysis", "NATIVE_HOST", true}, {"/?tab=data", "NATIVE_HOST", true}, {"/?view=tasks&alert_id=TAP-x", "NATIVE_HOST", false}, {"/reports/existing-report", "NATIVE_HOST", false}} {
		w := httptest.NewRecorder()
		staticHandler(w, httptest.NewRequest("GET", tc.path, nil))
		if w.Code != 200 || !strings.Contains(w.Body.String(), tc.want) || strings.Contains(w.Body.String(), "tap-overview-return") != tc.link {
			t.Fatal(tc.path, w.Code, w.Body.String())
		}
	}
}
