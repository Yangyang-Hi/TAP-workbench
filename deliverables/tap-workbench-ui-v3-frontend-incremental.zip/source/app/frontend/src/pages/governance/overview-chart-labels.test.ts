import { describe, expect, it } from "vitest";
import { compactChartValue, niceAxisMax } from "./overview-charts";

describe("overview chart labels", () => {
  it("keeps zero distinct from missing and compacts only large values", () => {
    expect(compactChartValue(0)).toBe("0");
    expect(compactChartValue(null)).toBe("—");
    expect(compactChartValue(1_250)).toBe("1.3K");
    expect(compactChartValue(2_500_000)).toBe("2.5M");
    expect(compactChartValue(3_000_000_000)).toBe("3B");
  });

  it("builds independent zero-based nice maxima with headroom", () => {
    expect(niceAxisMax([83, 12, null])).toBe(100);
    expect(niceAxisMax([2_500_000, 0])).toBe(3_000_000);
    expect(niceAxisMax([0, null, undefined])).toBe(1);
  });
});
