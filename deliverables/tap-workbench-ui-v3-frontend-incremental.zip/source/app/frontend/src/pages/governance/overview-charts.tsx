import { useEffect, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import "./overview-charts.css";

export type ChartRow = Record<string, unknown>;
const ORDER = ["ST", "HT", "BT", "ET"];
const COLORS: Record<string, string> = { ST: "#45d3a1", HT: "#6faeff", BT: "#f5b85b", ET: "#b39aff" };
export const tierColor = (tier: string) => COLORS[tier] || "#68d9d2";
const finite = (v: unknown): number | undefined => typeof v === "number" && Number.isFinite(v) ? v : undefined;
const full = (v: unknown) => finite(v)?.toLocaleString("zh-CN", { maximumFractionDigits: 6 }) ?? "—";
export const compactChartValue = (v: unknown) => {
  const n = finite(v); if (n === undefined) return "—";
  for (const [size, unit] of [[1e9, "B"], [1e6, "M"], [1e3, "K"]] as const) {
    if (Math.abs(n) >= size) return `${(n / size).toFixed(1).replace(/\.0$/, "")}${unit}`;
  }
  return n.toLocaleString("zh-CN", { maximumFractionDigits: 2 });
};
export const niceAxisMax = (values: unknown[]) => {
  const max = Math.max(0, ...values.map(finite).filter((v): v is number => v !== undefined));
  if (!max) return 1;
  const target = max * 1.12, magnitude = 10 ** Math.floor(Math.log10(target));
  return ([1, 1.2, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6, 7.5, 8, 10].find(s => s * magnitude >= target) ?? 10) * magnitude;
};
const tierOrder = (rows: ChartRow[]) => {
  const values = [...new Set(rows.map(r => String(r.tier ?? "")))];
  return [...ORDER.filter(t => values.includes(t)), ...values.filter(t => !ORDER.includes(t)).sort()];
};
const category = (row: ChartRow, key: string) => String(row[key] ?? "未标注");
function useWidth() {
  const ref = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(700);
  useEffect(() => {
    const node = ref.current; if (!node) return;
    const update = () => { if (node.clientWidth) setWidth(node.clientWidth); };
    update();
    if (typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(update); observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return { ref, width };
}
function Legend({ tiers, hidden, toggle }: { tiers: string[]; hidden: string[]; toggle: (tier: string) => void }) {
  return <div className="tap-chart-legend" aria-label="图表系列"><span>点击图例查看系列</span>{tiers.map(t => <button type="button" key={t || "all"} aria-label={`${t || "总体"} 系列`} aria-pressed={!hidden.includes(t)} onClick={() => toggle(t)} style={{ "--series": tierColor(t) } as CSSProperties}><i />{t || "总体"}</button>)}</div>;
}
function ChartTip({ title, children }: { title?: string; children?: ReactNode }) {
  return <div className={`tap-chart-tip ${title ? "has-value" : ""}`} role="status" aria-live="polite">{title ? <><b>{title}</b>{children}</> : <span>悬停或聚焦图形查看完整数值 · 图例仅影响展示</span>}</div>;
}
function AxisLabel({ x, y, value }: { x: number; y: number; value: string }) {
  const parts = value.length > 14 && value.includes(" ") ? [value.slice(0, value.lastIndexOf(" ")), value.slice(value.lastIndexOf(" ") + 1)] : [value];
  return <text x={x} y={y} textAnchor="middle" className="tap-chart-axis-label"><title>{value}</title>{parts.map((part, i) => <tspan key={i} x={x} dy={i ? 15 : 0}>{part}</tspan>)}</text>;
}

export function DistributionDonut({ rows, valueKey, shareKey }: { rows: ChartRow[]; valueKey: string; shareKey: string }) {
  const [active, setActive] = useState<number | null>(null);
  let cursor = 0;
  const slices = rows.map(row => { const share = Math.max(0, Number(row[shareKey]) || 0); const start = cursor; cursor += share; return { row, start, share }; });
  const valid = rows.length === 4 && cursor > 99.5 && cursor < 100.5;
  const selected = active === null ? undefined : rows[active];
  return <div className="tap-donut-box"><svg viewBox="0 0 240 240" className="tap-donut" role="group" aria-label={valid ? "四 Tier 实际占比" : "占比数据不完整，未绘制环图"}>
    <circle cx="120" cy="120" r="88" className="tap-donut-track" />
    {valid && slices.map(({ row, start, share }, i) => <circle key={String(row.tier)} cx="120" cy="120" r="88" pathLength="100" fill="none" stroke={tierColor(String(row.tier))} strokeWidth={active === i ? 34 : 28} strokeDasharray={`${share} ${100 - share}`} strokeDashoffset={-start} transform="rotate(-90 120 120)" tabIndex={0} role="img" aria-label={`${row.tier}：${full(row[valueKey])}，${full(row[shareKey])}%`} onMouseEnter={() => setActive(i)} onMouseLeave={() => setActive(null)} onFocus={() => setActive(i)} onBlur={() => setActive(null)}><title>{`${row.tier}：${full(row[valueKey])}，${full(row[shareKey])}%`}</title></circle>)}
    <text x="120" y="113" textAnchor="middle" className="tap-donut-number">{valid ? compactChartValue(selected ? selected[valueKey] : rows.reduce((sum, r) => sum + (Number(r[valueKey]) || 0), 0)) : "N/A"}</text>
    <text x="120" y="140" textAnchor="middle" className="tap-donut-caption">{selected ? `${selected.tier} · ${full(selected[shareKey])}%` : "四 Tier 合计"}</text>
  </svg><p className="tap-donut-hint">{selected ? `${selected.tier}：${full(selected[valueKey])}` : "悬停扇区查看 Tier 明细"}</p></div>;
}

export function GroupedRegionBars({ rows }: { rows: ChartRow[] }) {
  const [hidden, setHidden] = useState<string[]>([]);
  const tiers = tierOrder(rows);
  const toggle = (t: string) => setHidden(old => old.includes(t) ? old.filter(x => x !== t) : [...old, t]);
  return <div className="tap-region-charts"><Legend tiers={tiers} hidden={hidden} toggle={toggle} /><div className="tap-region-panels">{[{ key: "account_count", label: "账户数量", unit: "Account" }, { key: "revenue", label: "Revenue", unit: "源端金额" }].map(metric => <GroupedMetric key={metric.key} rows={rows} tiers={tiers} hidden={hidden} metric={metric} />)}</div></div>;
}
function GroupedMetric({ rows, tiers, hidden, metric }: { rows: ChartRow[]; tiers: string[]; hidden: string[]; metric: { key: string; label: string; unit: string } }) {
  const { ref, width: containerWidth } = useWidth();
  const [hover, setHover] = useState<ChartRow | null>(null);
  const regions = [...new Set(rows.map(row => category(row, "region")))];
  const max = niceAxisMax(rows.map(r => r[metric.key]));
  const width = Math.max(containerWidth, 560, regions.length * 110 + 90);
  const left = 58, right = 18, top = 32, bottom = 270, step = (width - left - right) / Math.max(1, regions.length);
  const visible = tiers.filter(t => !hidden.includes(t)), groupWidth = Math.min(step * .72, 80), slot = groupWidth / Math.max(visible.length, 1);
  const hasValues = rows.some(row => finite(row[metric.key]) !== undefined);
  return <section className="tap-plot-panel"><header><h4>{metric.label}</h4><span>{metric.unit} · 线性刻度 / 0 起点</span></header>{hasValues ? <>
    <div ref={ref} className="tap-chart-scroll"><svg width={width} height="328" viewBox={`0 0 ${width} 328`} role="group" aria-label={`${metric.label}，按 Region 分组、Tier 并列柱状图`}>
      {[0, .25, .5, .75, 1].map(t => <g key={t} className="tap-chart-grid"><line x1={left} x2={width - right} y1={bottom - t * (bottom - top)} y2={bottom - t * (bottom - top)} /><text x={left - 8} y={bottom - t * (bottom - top) + 4} textAnchor="end">{compactChartValue(max * t)}</text></g>)}
      {regions.map((region, index) => { const center = left + (index + .5) * step; return <g key={region}><AxisLabel x={center} y={bottom + 24} value={region} />{visible.map((tier, j) => {
        const cells = rows.filter(row => category(row, "region") === region && String(row.tier ?? "") === tier);
        const x = center - groupWidth / 2 + (j + .5) * slot;
        if (cells.length !== 1) return <text key={tier} x={x} y={bottom - 6} textAnchor="middle" className="tap-chart-missing"><title>{cells.length ? `${region} · ${tier} 返回多条源记录；未累加，详见源端明细` : `${region} · ${tier} 未返回；未补零`}</title>—</text>;
        const row = cells[0], value = finite(row[metric.key]);
        if (value === undefined) return <text key={tier} x={x} y={bottom - 6} textAnchor="middle" className="tap-chart-missing"><title>{`${region} · ${tier} 未返回；未补零`}</title>—</text>;
        const height = value / max * (bottom - top), label = `${region} · ${tier} · ${metric.label} ${full(value)}`;
        return <g key={tier} role="img" tabIndex={0} aria-label={label} className="tap-chart-mark" onMouseEnter={() => setHover(row)} onMouseLeave={() => setHover(null)} onFocus={() => setHover(row)} onBlur={() => setHover(null)} style={{ "--series": tierColor(tier) } as CSSProperties}><title>{label}</title><rect className="tap-chart-hit" x={x - slot / 2} y={top} width={slot} height={bottom - top} /><rect className="tap-chart-bar" x={x - Math.min(slot * .75, 18) / 2} y={bottom - height} width={Math.min(slot * .75, 18)} height={Math.max(0, height)} rx="3" />{value === 0 && <circle cx={x} cy={bottom} r="3" fill={tierColor(tier)} />}{hover === row && <text className="tap-chart-point-value" x={x} y={Math.max(18, bottom - height - 9)} textAnchor="middle">{compactChartValue(value)}</text>}</g>;
      })}</g>; })}
    </svg></div><ChartTip title={hover ? `${category(hover, "region")} · ${hover.tier}` : undefined}><span>{metric.label}<strong>{hover ? full(hover[metric.key]) : ""}</strong></span></ChartTip>
  </> : <div className="tap-chart-no-data">本指标未返回可绘制数值，保留源端状态，不以零代替。</div>}</section>;
}

export function RateVolumePlot({ rows, rateKey, volumeKey, axisKey, ratio = false, rateUnit = "源值" }: { rows: ChartRow[]; rateKey: string; volumeKey?: string; axisKey: string; ratio?: boolean; rateUnit?: string }) {
  const { ref, width: containerWidth } = useWidth();
  const [hidden, setHidden] = useState<string[]>([]), [hover, setHover] = useState<ChartRow | null>(null);
  const series = tierOrder(rows), categories = [...new Set(rows.map(r => category(r, axisKey)))];
  const maxRate = niceAxisMax(rows.map(r => r[rateKey])), maxVolume = niceAxisMax(rows.map(r => volumeKey ? r[volumeKey] : undefined));
  const left = 62, right = volumeKey ? 66 : 22, top = 32, bottom = 278;
  const width = Math.max(containerWidth, 640, categories.length * Math.max(86, series.length * 19) + left + right);
  const step = (width - left - right) / Math.max(1, categories.length);
  const visible = series.filter(t => !hidden.includes(t));
  const groupWidth = Math.min(step * .65, 76), slot = groupWidth / Math.max(1, visible.length);
  const center = (index: number) => left + (index + .5) * step;
  const rateLabel = (n: unknown) => { const v = finite(n); return v === undefined ? "—" : ratio ? `${full(v * 100)}%` : full(v); };
  const rateTick = (n: number) => ratio ? `${compactChartValue(n * 100)}%` : compactChartValue(n);
  const toggle = (t: string) => setHidden(old => old.includes(t) ? old.filter(x => x !== t) : [...old, t]);
  const cell = (key: string, tier: string) => rows.filter(r => category(r, axisKey) === key && String(r.tier ?? "") === tier);
  return <div className="tap-rate-plot"><div className="tap-chart-encoding"><span><i className="tap-line-key" />左轴：{rateKey}（{ratio ? "%" : rateUnit}）</span>{volumeKey && <span><i className="tap-bar-key" />右轴：{volumeKey}（count）</span>}</div><Legend tiers={series} hidden={hidden} toggle={toggle} />
    <div ref={ref} className="tap-chart-scroll"><svg width={width} height="338" viewBox={`0 0 ${width} 338`} role="group" aria-label={`${axisKey} 分类对比，${rateKey} 折线${volumeKey ? `及 ${volumeKey} 分组柱状图` : ""}`}>
      {[0, .25, .5, .75, 1].map(t => <g key={t} className="tap-chart-grid"><line x1={left} x2={width - right} y1={bottom - t * (bottom - top)} y2={bottom - t * (bottom - top)} /><text x={left - 10} y={bottom - t * (bottom - top) + 4} textAnchor="end">{rateTick(maxRate * t)}</text>{volumeKey && <text x={width - right + 10} y={bottom - t * (bottom - top) + 4}>{compactChartValue(maxVolume * t)}</text>}</g>)}
      {categories.map((key, i) => <AxisLabel key={key} x={center(i)} y={bottom + 25} value={key} />)}
      {visible.map((tier, j) => {
        // A missing or duplicate native key breaks the line; never average or connect through missing values.
        const points = categories.map((key, i) => { const matches = cell(key, tier); const row = matches.length === 1 ? matches[0] : undefined; return { row, x: center(i), value: row ? finite(row[rateKey]) : undefined }; });
        let path = "", connected = false;
        for (const p of points) { if (p.value === undefined) { connected = false; continue; } path += `${connected ? "L" : "M"}${p.x},${bottom - p.value / maxRate * (bottom - top)} `; connected = true; }
        return <g key={tier || "overall"} style={{ "--series": tierColor(tier) } as CSSProperties}>
          {volumeKey && categories.map((key, i) => { const matches = cell(key, tier); if (matches.length !== 1) return null; const row = matches[0], value = finite(row[volumeKey]); if (value === undefined) return null; const height = value / maxVolume * (bottom - top), x = center(i) - groupWidth / 2 + (j + .5) * slot; return <g key={key} className="tap-chart-mark" role="img" tabIndex={0} aria-label={`${key} ${tier} ${volumeKey} ${full(value)}`} onMouseEnter={() => setHover(row)} onMouseLeave={() => setHover(null)} onFocus={() => setHover(row)} onBlur={() => setHover(null)}><title>{`${key} · ${tier} · ${volumeKey} ${full(value)}`}</title><rect className="tap-chart-hit" x={x - slot / 2} y={top} width={slot} height={bottom - top} /><rect className="tap-chart-bar tap-volume-bar" x={x - Math.min(slot * .75, 16) / 2} y={bottom - height} width={Math.min(slot * .75, 16)} height={Math.max(0, height)} rx="2" />{value === 0 && <circle cx={x} cy={bottom} r="3" fill={tierColor(tier)} />}</g>; })}
          <path d={path} className="tap-chart-line" />{points.map(p => p.row && p.value !== undefined ? <g key={category(p.row, axisKey)} className="tap-chart-mark" tabIndex={0} role="img" aria-label={`${category(p.row, axisKey)} ${tier} ${rateKey} ${rateLabel(p.value)}`} onMouseEnter={() => setHover(p.row!)} onMouseLeave={() => setHover(null)} onFocus={() => setHover(p.row!)} onBlur={() => setHover(null)}><title>{`${category(p.row, axisKey)} · ${tier} · ${rateKey} ${rateLabel(p.value)}`}</title><circle className="tap-chart-point-hit" cx={p.x} cy={bottom - p.value / maxRate * (bottom - top)} r="10" /><circle className="tap-chart-dot" cx={p.x} cy={bottom - p.value / maxRate * (bottom - top)} r={hover === p.row ? 6 : 4} /></g> : null)}
        </g>;
      })}
    </svg></div><ChartTip title={hover ? `${category(hover, axisKey)}${hover.tier ? ` · ${hover.tier}` : ""}` : undefined}><span>{rateKey}<strong>{hover ? rateLabel(hover[rateKey]) : ""}{!ratio && rateUnit !== "源值" ? ` ${rateUnit}` : ""}</strong></span>{volumeKey && <span>{volumeKey}<strong>{hover ? full(hover[volumeKey]) : ""}</strong></span>}</ChartTip>
  </div>;
}
