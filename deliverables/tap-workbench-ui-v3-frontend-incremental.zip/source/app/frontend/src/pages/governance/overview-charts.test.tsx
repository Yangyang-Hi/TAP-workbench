import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { DistributionDonut, GroupedRegionBars, RateVolumePlot } from "./overview-charts";
afterEach(cleanup);
describe("overview chart presentation", () => {
  it("groups four native tier values under one Region and toggles display only", () => {
    const rows = ["ST", "HT", "BT", "ET"].map((tier, i) => ({ region: "EUI", tier, account_count: i + 1, revenue: i + 100 }));
    const { container } = render(<GroupedRegionBars rows={rows} />);
    expect(container.querySelectorAll(".tap-chart-axis-label")).toHaveLength(2);
    expect(container.querySelectorAll(".tap-chart-bar")).toHaveLength(8);
    fireEvent.click(screen.getByRole("button", { name: "HT 系列" }));
    expect(container.querySelectorAll(".tap-chart-bar")).toHaveLength(6);
    expect(screen.getByRole("button", { name: "HT 系列" }).getAttribute("aria-pressed")).toBe("false");
    expect(rows[1].account_count).toBe(2);
  });
  it("does not sum duplicate native keys or draw missing values as zero", () => {
    const { container } = render(<GroupedRegionBars rows={[{ region: "EUI", tier: "ST", account_count: 10 }, { region: "EUI", tier: "ST", account_count: 20 }, { region: "NA", tier: "ST", account_count: null }, { region: "APAC", tier: "ST", account_count: 0 }]} />);
    expect(container.querySelectorAll(".tap-chart-bar")).toHaveLength(1);
    expect(container.querySelectorAll(".tap-chart-missing")).toHaveLength(2);
    expect(screen.getByText(/本指标未返回可绘制数值/)).toBeTruthy();
  });
  it("breaks a rate line at a missing category instead of implying interpolation", () => {
    const { container } = render(<RateVolumePlot rows={[{region:"A",tier:"ST",ccr:1,nfs:5},{region:"B",tier:"ST",ccr:null,nfs:2},{region:"C",tier:"ST",ccr:3,nfs:8}]} rateKey="ccr" volumeKey="nfs" axisKey="region" />);
    expect(container.querySelector(".tap-chart-line")?.getAttribute("d")?.match(/M/g)).toHaveLength(2);
    expect(container.querySelectorAll(".tap-chart-dot")).toHaveLength(2);
    expect(container.querySelectorAll(".tap-chart-grid text")).toHaveLength(10);
    fireEvent.focus(screen.getByRole("img", {name:"A ST ccr 1"}));
    expect(screen.getByRole("status").textContent).toContain("A · ST");
    expect(screen.getByRole("status").textContent).toContain("5");
  });
  it("keeps rate null distinct from a real zero and preserves native percentage scale", () => {
    const {container} = render(<RateVolumePlot rows={[{quarter:"Q1",approval_rate:0},{quarter:"Q2",approval_rate:null},{quarter:"Q3",approval_rate:.96}]} rateKey="approval_rate" axisKey="quarter" ratio />);
    expect(container.querySelectorAll(".tap-chart-dot")).toHaveLength(2);
    fireEvent.focus(screen.getByRole("img", {name:"Q3 approval_rate 96%"}));
    expect(screen.getByRole("status").textContent).toContain("96%");
  });
  it("exposes the same donut values to keyboard and mouse without altering shares", () => {
    const rows = ["ST", "HT", "BT", "ET"].map((tier, i) => ({tier, account_count:[6,85,5,4][i],account_share:[6,85,5,4][i]}));
    render(<DistributionDonut rows={rows} valueKey="account_count" shareKey="account_share" />);
    fireEvent.focus(screen.getByRole("img", {name:"HT：85，85%"}));
    expect(screen.getByText("HT · 85%")).toBeTruthy();
    expect(rows[1].account_share).toBe(85);
  });
});
