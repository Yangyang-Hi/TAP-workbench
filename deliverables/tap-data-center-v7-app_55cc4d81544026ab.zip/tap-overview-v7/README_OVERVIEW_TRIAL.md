# v7 · 数据中心完整组件验证包

安装目标仍为 **app_55cc4d81544026ab**。用户已确认 v6 可安装、可打开且时间/Region筛选响应；本版在该基线上补齐迁移清单中的组件。暂不合并原生产工作台。

在该测试 App 的「本地开发入口 → ZIP包 → 上传修改后的代码」上传完整 ZIP。无需手改 ID、standalone 服务或启动命令。安装后选择起止日期、Region，点击应用；看到“区域与Tier”“TAP与Non-TAP”“Approval/Banned”“Ads FDR/Overturned”即为新版界面。页面显示17个基础模块返回进度，P1按需展开。

## 本次新增

- 原生 TAP Accounts / TAP Revenue 总卡（RID 2892274），不再用四Tier快照合计冒充区间去重总量。
- Approval Rate / Banned Volume周趋势，Global与指定Region分源。
- Ads FDR / Overturned Account周趋势，两个来源独立显示、保留快照分区。
- Region×Tier账户与营收分布，账户快照、区间营收分开查询。
- TAP / Non-TAP区域对比，按群组分别由源端去重，不累加各Tier去重数；账户快照和区间营收分开；快照不一致时不算账户占比。

原账户/营收环形图、P0汇总和趋势、Approval卡片、P1、ET/ST Quota、风险与处置汇总、Submitter表、查询记录导出继续保留。所有迁移清单中的展示组件均有实现，但**代码及本地测试完成不等于全部真实报表数据验收完成**。

## 真实出数边界

- 本地无法代替AIME宿主身份对拍新增风神报表；安装后以实际结果及对应RID同条件核实。
- FDR/Overturned尚缺文档中的Tier/周字段ID，代码从真实reqJson维度定义绑定；缺失、歧义、SID不符，或周字段与固定p_date冲突时停止该模块并显示诊断。不会猜ID或把p_date快照误改为时间窗口。
- Audit区域只确认APAC/EUI/LATAM/METAP/NA与Team名映射。CNOB等未确认区域显示不可用，不用Global或APAC替代。Actor区域也按已提供映射执行。
- Revenue币种、CCR/FDR/Approval的单位与缩放仍待源端对拍，显示原值；极小非零率保留有效数字，不舍入为假0。
- ST季度名单、Cloud事件和扫描历史不随源码包搬运；独立App缺少时保留未接入状态。Quota只使用原有已配置年份/季度。
- 全局Tier选择继续暂缓。TAP四Tier、治理Program和Audit层级不混用。

详见 docs/overview/取数与验收.md 与 迁移清单.md。图片均标明界面测试样例，非真实风神数据。

## 本地验证

79项前端回归通过；31项总览Go顶层测试含race及子测试通过；另外17项已有取数合同、Quota及Reported reason回归通过。TypeScript总览检查、11项IDL生成一致性和标准release构建通过；桌面/手机无脚本异常或页面横向溢出。真实风神对拍尚待安装后完成。

## 安装/构建

包内包含全部源码、app/dist及可执行Linux amd64发布二进制；排除node_modules、.aime_build、日志、数据库及密钥。标准脚手架与Amy的启动回退、网关静态资源修复均保留。

```bash
bash build.sh --mode release
bash pack.sh --include-source --include-go-source --output /tmp/tap-data-center-v7.zip
```

已有合格release产物可加 --skip-build --skip-go-build打包，脚本仍校验文件齐全和二进制权限。不要用git archive替代。

若安装后前端新组件可见但新增metric接口统一404，请让AIME核对实际启动二进制是否仍为旧的.aime_build开发产物，标准构建并重启；不要改ID或删除模板契约。

config/overview_trial.json保持enabled:true：不初始化Cloud业务库、不启动扫描/建单/通知worker，不开放处置和推送修改接口。主工作台合并等用户验收后，在其最新源码上审查实施；勿把测试App身份或隔离开关覆盖到生产。
