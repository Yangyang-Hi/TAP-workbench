package main

import (
	"sort"
	"strings"
)

// Three mutually exclusive customer categories retain all original trigger tags.
func wbRiskPartitions(rows []wbReadRow, policy wbResolvedPolicy) map[string]string {
	type hits struct{ absolute, growth bool }
	customers := map[string]hits{}
	for _, r := range rows {
		key := wbReadCustomerKey(r)
		h := customers[key]
		level, _ := wbEvaluateAbsolute(r.CCR, r.NFS, r.Program, r.Tier, r.Region, wbPolicyOnlyKind(policy, "absolute"))
		h.absolute = h.absolute || wbRiskRank(level) > 0
		eval := wbRow{Program: r.Program, Member: wbMember{Tier: r.Tier, Region: r.Region}, CCR: r.CCR, NFS: r.NFS, Comparison: r.Comparison}
		growthLevel, _ := wbEvaluateRow(eval, wbPolicyOnlyKind(policy, "growth"))
		h.growth = h.growth || wbRiskRank(growthLevel) > 0
		for _, rule := range policy.Rules {
			if rule.Kind == "ranking" && rule.Enabled {
				for _, reason := range r.RiskReasons {
					if strings.Contains(reason, rule.ID+"：") {
						h.growth = true
					}
				}
			}
		}
		customers[key] = h
	}
	out := map[string]string{}
	for key, h := range customers {
		switch {
		case h.absolute && h.growth:
			out[key] = "both"
		case h.absolute:
			out[key] = "absolute"
		default:
			out[key] = "growth"
		}
	}
	return out
}
func wbRiskReadFilter(r wbReadRow, q map[string]string) bool {
	if level := q["alert_level"]; level != "" && level != "all" {
		if wbRiskLevel(level) != wbRiskLevel(r.RiskLevel) {
			return false
		}
	}
	if stage := q["stage"]; stage != "" && stage != "all" && r.EventStage != stage {
		return false
	}
	if status := q["status"]; status != "" && status != "all" {
		actual := r.CaseStatus
		if actual == "" {
			actual = "open"
		}
		if !strings.EqualFold(status, actual) {
			return false
		}
	}
	return true
}
func wbDistinctRiskCount(rows []wbReadRow) int {
	m := map[string]bool{}
	for _, r := range rows {
		m[wbReadCustomerKey(r)] = true
	}
	return len(m)
}
func wbRiskCards(rows []wbReadRow, queried int) map[string]wbCardValue {
	type state struct {
		allClosed bool
		active    bool
	}
	customers := map[string]state{}
	closedEvents, sentCustomers, pendingCustomers := map[string]bool{}, map[string]bool{}, map[string]bool{}
	for _, r := range rows {
		key := wbReadCustomerKey(r)
		s, ok := customers[key]
		if !ok {
			s.allClosed = true
		}
		if r.EventStage != "closed" {
			s.allClosed = false
		} else {
			eventKey := wbReadEventKey(r)
			if r.AlertID != nil {
				eventKey = *r.AlertID
			}
			closedEvents[eventKey] = true
		}
		if r.EventStage == "pending_submitter" || r.CaseStatus == "processing" || r.CaseStatus == "observing" || r.CaseStatus == "pending_approval" || r.CaseStatus == "pending_review" {
			s.active = true
		}
		if r.Notification.Status == "sent" {
			sentCustomers[key] = true
		}
		if r.EventStage == "pending_operator" {
			pendingCustomers[key] = true
		}
		customers[key] = s
	}
	pending, active, closed := 0, 0, 0
	for _, s := range customers {
		if s.allClosed {
			closed++
		} else if s.active {
			active++
		} else {
			pending++
		}
	}
	return map[string]wbCardValue{
		"queried_customers":     wbCard(queried, "available", "相同客户筛选下已查询客户池去重；包含未命中客户"),
		"risk_customers":        wbCard(len(customers), "available", "与当前分类、状态及筛选后的列表一致，按 Program＋客户 ID 去重，不受分页影响"),
		"auto_alerted":          wbNullCard("unavailable", "仅通知回执不能推断自动发送；不将命中数伪装成自动发送数"),
		"pending":               wbCard(len(pendingCustomers), "available", "待运营确认客户数，保留原字段语义"),
		"handled":               wbCard(len(sentCustomers), "available", "成功通知客户去重，保留原字段语义；不等于已完成"),
		"closed":                wbCard(len(closedEvents), "available", "已关闭事件数，保留原字段语义"),
		"pending_customers":     wbCard(pending, "available", "当前风险客户中仍待运营确认或未接单的客户"),
		"in_progress_customers": wbCard(active, "available", "当前风险客户中有处理、观察或复核中事件的客户；不等于已完成"),
		"closed_customers":      wbCard(closed, "available", "当前范围内该客户的所有命中事件均已关闭；有未关闭事件仍归待处理或处理中"),
		"closed_events":         wbCard(len(closedEvents), "available", "当前范围已关闭预警记录数，与客户数分开")}

}
func wbRiskOptionValues(rows []wbReadRow) ([]string, []string, []string) {
	regions, submitters, statuses := map[string]bool{}, map[string]bool{}, map[string]bool{}
	for _, r := range rows {
		if r.Region != "" {
			regions[r.Region] = true
		}
		if r.OriginalSubmitter != "" {
			submitters[r.OriginalSubmitter] = true
		}
		s := r.CaseStatus
		if s == "" {
			s = "open"
		}
		statuses[s] = true
	}
	sorted := func(m map[string]bool) []string {
		a := []string{}
		for v := range m {
			a = append(a, v)
		}
		sort.Strings(a)
		return a
	}
	return sorted(regions), sorted(submitters), sorted(statuses)
}

// A batch may contain Program scans made under different saved policy versions.
// Apply each Program's own immutable policy instead of whichever map entry came first.
func wbSavedBatchPolicy(jobs []wbJob) wbResolvedPolicy {
	out := wbResolvedPolicy{VersionLabel: "saved-program-policies", UpdatedBy: "saved_scan"}
	for _, job := range jobs {
		p := job.Policy
		if len(p.Rules) == 0 {
			p = wbDefaultPolicy()
		}
		program := strings.ToUpper(job.Request.Program)
		for _, rule := range p.Rules {
			if rule.Program != "ALL" && !strings.EqualFold(rule.Program, program) {
				continue
			}
			rule.Program = program
			out.Rules = append(out.Rules, rule)
		}
	}
	if len(out.Rules) == 0 {
		return wbDefaultPolicy()
	}
	sort.SliceStable(out.Rules, func(i, j int) bool {
		return out.Rules[i].Program+out.Rules[i].ID < out.Rules[j].Program+out.Rules[j].ID
	})
	out.ConfigHash = wbPolicyHash(out.Rules)
	return out
}
