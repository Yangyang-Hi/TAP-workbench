package main

import (
	"bytes"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	"crypto/subtle"
	"database/sql"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type cwNotice struct {
	ID               string `json:"id"`
	CaseID           string `json:"case_id"`
	Recipient        string `json:"recipient"`
	Kind             string `json:"kind"`
	Status           string `json:"status"`
	MessageID        string `json:"message_id"`
	Attempts         int    `json:"attempts"`
	Error            string `json:"error"`
	CreatedAt        string `json:"created_at"`
	UpdatedAt        string `json:"updated_at"`
	NotificationMode string `json:"notification_mode"`
	BotFingerprint   string `json:"-"`
	MappingVersion   string `json:"mapping_version"`
	MappingRevision  string `json:"mapping_revision"`
	TargetEmail      string `json:"-"`
	ResolvedOpenID   string `json:"-"`
	Source           string `json:"source"`
	Mode             string `json:"mode"`
	BatchID          string `json:"batch_id"`
	RuleVersion      string `json:"rule_version"`
	Result           string `json:"result"`
}

func cwNotices(db *sql.DB, id string) ([]cwNotice, error) {
	rows, e := db.Query("SELECT id,case_id,recipient,kind,status,message_id,attempts,error,created_at,updated_at,notification_mode,bot_fingerprint,mapping_version,mapping_revision,target_email,resolved_open_id,source,mode,batch_id,rule_version,result FROM tap_outbox WHERE case_id=? ORDER BY created_at DESC", id)
	if e != nil {
		return nil, e
	}
	defer rows.Close()
	out := []cwNotice{}
	seenDeliveries := map[string]bool{}
	for rows.Next() {
		var n cwNotice
		if e = rows.Scan(&n.ID, &n.CaseID, &n.Recipient, &n.Kind, &n.Status, &n.MessageID, &n.Attempts, &n.Error, &n.CreatedAt, &n.UpdatedAt, &n.NotificationMode, &n.BotFingerprint, &n.MappingVersion, &n.MappingRevision, &n.TargetEmail, &n.ResolvedOpenID, &n.Source, &n.Mode, &n.BatchID, &n.RuleVersion, &n.Result); e != nil {
			return nil, e
		}
		if n.Kind == "send" && strings.TrimSpace(n.MessageID) != "" {
			key := n.CaseID + "|" + n.MessageID
			if seenDeliveries[key] {
				continue
			}
			seenDeliveries[key] = true
		}
		parts := strings.SplitN(n.Recipient, ":", 2)
		if len(parts) == 2 {
			n.Recipient = parts[0] + ":" + cwMaskID(parts[1])
		}
		out = append(out, n)
	}
	return out, rows.Err()
}

func cwExistingCaseNotification(tx *sql.Tx, caseID, mode string) (cwNotice, bool, error) {
	var n cwNotice
	err := tx.QueryRow(`SELECT id,case_id,recipient,kind,status,message_id,attempts,error,created_at,updated_at,notification_mode,bot_fingerprint,mapping_version,mapping_revision,target_email,resolved_open_id
		FROM tap_outbox
		WHERE case_id=? AND notification_mode=? AND kind='send' AND status='sent' AND TRIM(message_id)<>''
		ORDER BY updated_at DESC LIMIT 1`, caseID, mode).Scan(&n.ID, &n.CaseID, &n.Recipient, &n.Kind, &n.Status, &n.MessageID, &n.Attempts, &n.Error, &n.CreatedAt, &n.UpdatedAt, &n.NotificationMode, &n.BotFingerprint, &n.MappingVersion, &n.MappingRevision, &n.TargetEmail, &n.ResolvedOpenID)
	if err == nil {
		return n, true, nil
	}
	if err != sql.ErrNoRows {
		return n, false, err
	}
	err = tx.QueryRow(`SELECT id,case_id,recipient,kind,status,message_id,attempts,error,created_at,updated_at,notification_mode,bot_fingerprint,mapping_version,mapping_revision,target_email,resolved_open_id
		FROM tap_outbox
		WHERE case_id=? AND notification_mode=? AND kind='send' AND status IN ('pending','sending')
		ORDER BY created_at LIMIT 1`, caseID, mode).Scan(&n.ID, &n.CaseID, &n.Recipient, &n.Kind, &n.Status, &n.MessageID, &n.Attempts, &n.Error, &n.CreatedAt, &n.UpdatedAt, &n.NotificationMode, &n.BotFingerprint, &n.MappingVersion, &n.MappingRevision, &n.TargetEmail, &n.ResolvedOpenID)
	if err == sql.ErrNoRows {
		return cwNotice{}, false, nil
	}
	return n, err == nil, err
}
func cwQueueUpdates(tx *sql.Tx, a cwCase) error {
	rows, e := tx.Query("SELECT recipient,message_id,notification_mode,bot_fingerprint FROM tap_outbox WHERE case_id=? AND kind='send' AND status='sent'", a.ID)
	if e != nil {
		return e
	}
	type target struct{ r, m, mode, bot string }
	ts := []target{}
	for rows.Next() {
		var t target
		if e = rows.Scan(&t.r, &t.m, &t.mode, &t.bot); e != nil {
			rows.Close()
			return e
		}
		ts = append(ts, t)
	}
	re := rows.Err()
	rows.Close()
	if re != nil {
		return re
	}
	for _, t := range ts {
		id := wbKey([]string{"update", a.ID, t.m, strconv.Itoa(a.Version)})
		if _, e = tx.Exec("INSERT OR IGNORE INTO tap_outbox(id,case_id,recipient,kind,status,message_id,notification_mode,bot_fingerprint,created_at,updated_at) VALUES(?,?,?,'update','pending',?,?,?,?,?)", id, a.ID, t.r, t.m, t.mode, t.bot, cwNow(), cwNow()); e != nil {
			return e
		}
	}
	return nil
}
func cwIntegrationStatus(autoSendEnabled bool) map[string]any {
	credentials, _, credentialErr := loadFeishuCredentials()
	return map[string]any{"app_id_configured": credentialErr == nil && credentials.AppID != "", "app_secret_configured": credentialErr == nil && credentials.AppSecret != "", "verification_token_configured": os.Getenv("TAP_FEISHU_VERIFICATION_TOKEN") != "", "encrypt_key_configured": os.Getenv("TAP_FEISHU_ENCRYPT_KEY") != "", "tenant_key_configured": os.Getenv("TAP_FEISHU_TENANT_KEY") != "", "workbench_url_configured": cwWorkbenchURL("") != "", "callback_path": "/api/integrations/feishu/card-callback", "transport": "HTTP encrypted callback; no browser JWT required; signature + token + operator mapping required", "mode": "test recipients only unless formal mode is explicitly configured; auto_send_enabled=false by default", "auto_send_enabled": autoSendEnabled}
}
func cwNotifyHandler(w http.ResponseWriter, r *http.Request) {
	var in struct {
		RecipientID       string `json:"recipient_id"`
		ExpectedVersion   int    `json:"expected_version"`
		Mode              string `json:"mode"`
		PreviewToken      string `json:"preview_token"`
		ConfirmationToken string `json:"confirmation_token"`
		Resend            bool   `json:"resend"`
		ResendRequestID   string `json:"resend_request_id"`
		ConfirmationNote  string `json:"confirmation_note"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&in) != nil {
		cwWriteError(w, cwErr(400, "无效JSON"))
		return
	}
	cfg, e := cwLoadConfig()
	if e != nil {
		cwWriteError(w, e)
		return
	}
	if in.PreviewToken == "" {
		in.PreviewToken = in.ConfirmationToken
	}
	if in.Mode == "" {
		in.Mode = cfg.NotificationMode
	}
	if in.Mode != "test" && in.Mode != "formal" {
		cwWriteError(w, cwErr(400, "mode 必须为 test 或 formal"))
		return
	}
	if in.Resend {
		in.ResendRequestID = strings.TrimSpace(in.ResendRequestID)
		in.ConfirmationNote = strings.TrimSpace(in.ConfirmationNote)
		if in.Mode != "formal" {
			cwWriteError(w, cwErr(400, "受控重新发送仅支持 formal 模式"))
			return
		}
		if !cwOperator(cfg, requestUsername(r)) {
			cwWriteError(w, cwErr(403, "仅运营可重新发送已成功通知"))
			return
		}
		if in.ResendRequestID == "" || in.ConfirmationNote == "" {
			cwWriteError(w, cwErr(400, "受控重新发送需要 resend_request_id 和 confirmation_note"))
			return
		}
	}
	creds, _, credErr := loadFeishuCredentials()
	if credErr != nil || creds.AppID == "" || creds.AppSecret == "" {
		cwWriteError(w, cwErr(409, "当前 Bot 凭证不可用，无法执行通知"))
		return
	}
	id := r.PathValue("id")

	var target *cwRecipient
	if in.Mode == "test" {
		if cfg.NotificationMode != "test" {
			cwWriteError(w, cwErr(409, "测试发送仅在服务测试模式下允许"))
			return
		}
		for _, item := range cfg.TestRecipients {
			item := item
			if item.ID == in.RecipientID && item.Type == "open_id" {
				target = &item
			}
		}
		if target == nil {
			cwWriteError(w, cwErr(400, "接收目标必须是配置中的测试人员 open_id 白名单"))
			return
		}
	}
	db, e := cwDB()
	if e != nil {
		cwWriteError(w, e)
		return
	}
	defer db.Close()
	if _, mirrorErr := cwMirrorCloudCaseToLocal(r.Context(), db, id); mirrorErr != nil {
		cwWriteError(w, mirrorErr)
		return
	}
	var formalMapping cwIdentityMapping
	formalOpenID, formalRevision := "", ""
	if in.Mode == "formal" {
		preflight, readErr := cwRead(db, id)
		if readErr != nil {
			cwWriteError(w, readErr)
			return
		}
		if !cwCanHandle(cfg, preflight, requestUsername(r)) {
			cwWriteError(w, cwErr(403, "无通知权限"))
			return
		}
		ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
		defer cancel()
		formalRevision, e = cwSyncIdentityMappings(ctx, db)
		if e != nil {
			cwWriteError(w, cwErr(503, "权威人员映射刷新失败，正式发送已阻止"))
			return
		}
		resolution, resolveErr := cwResolveCaseMapping(ctx, db, preflight)
		if resolveErr != nil || resolution.Status != "matched" || resolution.Mapping == nil {
			writeJSON(w, 409, map[string]any{"error": "recipient_changed", "reason": "正式收件人映射不可用或已变化，请刷新预览"})
			return
		}
		formalMapping = *resolution.Mapping
		formalOpenID, _, _ = cwResolveFormalOpenID(ctx, id, formalMapping.Email)
		if formalOpenID == "" {
			writeJSON(w, 409, map[string]any{"error": "recipient_changed", "reason": "正式收件人在当前 Bot 域不可解析，请刷新预览"})
			return
		}
	}
	tx, e := db.Begin()
	if e != nil {
		cwWriteError(w, e)
		return
	}
	defer tx.Rollback()
	a, e := cwRead(tx, id)
	if e != nil {
		cwWriteError(w, e)
		return
	}
	if !cwCanHandle(cfg, a, requestUsername(r)) {
		cwWriteError(w, cwErr(403, "无通知权限"))
		return
	}
	confirmation, used, e := cwReadNotificationPreview(tx, in.PreviewToken)
	if e != nil {
		cwWriteError(w, e)
		return
	}
	if in.Mode == "formal" {
		if confirmation.Mode != "formal" || confirmation.Recipient == "" || confirmation.Recipient != formalOpenID || confirmation.ResolvedOpenID != formalOpenID || confirmation.RecipientEmail != formalMapping.Email || confirmation.Mapping.RecordID != formalMapping.RecordID || confirmation.Mapping.RecordVersion != formalMapping.RecordVersion || confirmation.Revision != formalRevision {
			writeJSON(w, 409, map[string]any{"error": "recipient_changed", "reason": "正式收件人或权威映射已变化，请刷新预览"})
			return
		}
		target = &cwRecipient{ID: formalOpenID, Type: "open_id", Label: confirmation.RecipientName, Email: formalMapping.Email}
	}
	if target == nil {
		cwWriteError(w, cwErr(409, "通知目标不可用，请刷新预览"))
		return
	}
	fingerprint, e := cwBotFingerprint()
	if e != nil || confirmation.AlertID != a.ID || confirmation.Actor != requestUsername(r) || (confirmation.Mode != "" && confirmation.Mode != in.Mode) || confirmation.Recipient != target.ID || confirmation.CaseVersion != in.ExpectedVersion || confirmation.BotFingerprint != fingerprint {
		writeJSON(w, 409, map[string]any{"error": "preview_stale", "reason": "预览目标、事件状态、消息模板、操作者或 Bot 配置发生变化，请刷新预览"})
		return
	}
	if in.Resend {
		var sentCount int
		if e = tx.QueryRow("SELECT COUNT(1) FROM tap_outbox WHERE case_id=? AND kind='send' AND mode='formal' AND status='sent'", a.ID).Scan(&sentCount); e != nil {
			cwWriteError(w, e)
			return
		}
		if sentCount == 0 {
			cwWriteError(w, cwErr(409, "该事件尚无成功正式通知，不能使用重新发送"))
			return
		}
	} else {
		existing, reused, existingErr := cwExistingCaseNotification(tx, a.ID, in.Mode)
		if existingErr != nil {
			cwWriteError(w, existingErr)
			return
		}
		if reused {
			if e = tx.Commit(); e != nil {
				cwWriteError(w, e)
				return
			}
			writeJSON(w, 202, map[string]any{
				"data":            a,
				"notification_id": existing.ID,
				"notification": map[string]any{
					"id": existing.ID, "status": existing.Status, "message_id": existing.MessageID, "updated_at": existing.UpdatedAt,
				},
				"deduplicated": true,
				"idempotent":   true,
				"reused":       true,
				"message":      "该 Alert 已成功发送或存在有效排队，未重复创建通知",
			})
			return
		}
	}
	stateJSON, _ := json.Marshal(a)
	cardJSON, _ := json.Marshal(cwNotificationCard(a, in.Mode, confirmation.RecipientName))
	if confirmation.StateHash != "" && confirmation.StateHash != cwPreviewHash(string(stateJSON)) || confirmation.TemplateHash != "" && confirmation.TemplateHash != cwPreviewHash(string(cardJSON)) {
		writeJSON(w, 409, map[string]any{"error": "preview_stale", "reason": "事件状态或消息模板发生变化，请刷新预览"})
		return
	}
	generation := 1
	idempotencyParts := []string{"notification", a.ID, strconv.Itoa(generation), in.Mode, target.ID}
	if in.Resend {
		if e = tx.QueryRow("SELECT COALESCE(MAX(generation),0)+1 FROM tap_outbox WHERE case_id=? AND kind='send' AND mode=?", a.ID, in.Mode).Scan(&generation); e != nil {
			cwWriteError(w, e)
			return
		}
		idempotencyParts = []string{"notification-resend", a.ID, in.Mode, target.ID, in.ResendRequestID}
	}
	idempotency := wbKey(idempotencyParts)
	notificationID := wbKey([]string{"send", idempotency})
	var existingStatus string
	e = tx.QueryRow("SELECT status FROM tap_outbox WHERE idempotency_key=?", idempotency).Scan(&existingStatus)
	if e != nil && e != sql.ErrNoRows {
		cwWriteError(w, e)
		return
	}
	if existingStatus != "" && existingStatus != "failed" && existingStatus != "blocked" {
		_ = tx.Commit()
		writeJSON(w, 202, map[string]any{"data": a, "notification_id": notificationID, "notification": map[string]any{"id": notificationID, "status": existingStatus, "message_id": "", "updated_at": ""}, "deduplicated": true, "idempotent": true, "reused": true, "message": "通知已存在，未重复排队"})
		return
	}
	if used {
		cwWriteError(w, cwErr(409, "本次确认已使用，请重新生成预览后确认重试"))
		return
	}

	if a.Version != in.ExpectedVersion {
		cwWriteError(w, cwErr(409, "事件已更新，请刷新"))
		return
	}
	mapping := confirmation.Mapping
	var result sql.Result
	if existingStatus == "failed" || existingStatus == "blocked" {
		result, e = tx.Exec(`UPDATE tap_outbox SET status='pending',error='',next_at=0,mapping_record_id=?,mapping_row=?,mapping_version=?,mapping_revision=?,matched_alias=?,target_email=?,resolved_open_id=?,actual_target=?,bot_fingerprint=?,updated_at=? WHERE id=? AND status IN ('failed','blocked')`, mapping.RecordID, mapping.SheetRow, mapping.RecordVersion, confirmation.Revision, a.Row.Member.Submitter, mapping.Email, confirmation.ResolvedOpenID, "open_id:"+target.ID, fingerprint, cwNow(), notificationID)
	} else {
		result, e = tx.Exec(`INSERT INTO tap_outbox(id,case_id,recipient,kind,status,notification_mode,generation,idempotency_key,original_submitter,alert_region,actual_target,mapping_record_id,mapping_row,mapping_version,mapping_revision,matched_alias,target_email,resolved_open_id,bot_fingerprint,source,mode,batch_id,rule_version,result,created_at,updated_at) VALUES(?,?,?,'send','pending',?,?,?,?,?,?,?,?,?,?,?,?,?,?,'manual',?,?,?,'pending',?,?)`, notificationID, a.ID, "open_id:"+target.ID, in.Mode, generation, idempotency, a.Row.Member.Submitter, a.Row.Member.Region, "open_id:"+target.ID, mapping.RecordID, mapping.SheetRow, mapping.RecordVersion, confirmation.Revision, a.Row.Member.Submitter, mapping.Email, confirmation.ResolvedOpenID, fingerprint, in.Mode, a.Fields["batch_id"], a.Rule.Version, cwNow(), cwNow())
	}
	if e != nil {
		cwWriteError(w, e)
		return
	}
	inserted, _ := result.RowsAffected()
	if _, e = tx.Exec("UPDATE tap_notification_previews SET consumed=1 WHERE token_hash=? AND consumed=0", cwPreviewHash(in.PreviewToken)); e != nil {
		cwWriteError(w, e)
		return
	}

	if inserted == 1 {
		before := a.Version
		a.Version++
		a.UpdatedAt = cwNow()
		note := "已确认排队发送至测试人员白名单：" + target.Label
		operation := "notify"
		if in.Mode == "formal" {
			note = "已通过正式预览确认单条发送至真实负责人：" + target.Label
		}
		if in.Resend {
			operation = "notify_resend"
			note = "已确认重新发送正式卡片至真实负责人：" + target.Label + "；原因：" + in.ConfirmationNote
		}
		a.History = append(a.History, cwAudit{ID: notificationID, At: a.UpdatedAt, Actor: requestUsername(r), Source: "workbench", Operation: operation, Status: a.Status, Version: a.Version, Note: note})
		if e = cwSave(tx, a, before); e != nil {
			cwWriteError(w, e)
			return
		}
	}
	if e = tx.Commit(); e != nil {
		cwWriteError(w, e)
		return
	}
	if inserted == 1 {
		repo, cloudErr := cwCaseworkRepositoryProvider()
		if cloudErr == nil {
			if _, local := repo.(localCaseworkRepository); !local {
				cloudErr = repo.saveCaseCAS(r.Context(), a, in.ExpectedVersion)
			}
		}
		if cloudErr == nil {
			var n cwNotice
			var nextAt int64
			var idem string
			cloudErr = db.QueryRow("SELECT id,case_id,recipient,kind,status,message_id,attempts,error,created_at,updated_at,notification_mode,bot_fingerprint,mapping_version,mapping_revision,target_email,resolved_open_id,source,mode,batch_id,rule_version,result,next_at,idempotency_key FROM tap_outbox WHERE id=?", notificationID).Scan(&n.ID, &n.CaseID, &n.Recipient, &n.Kind, &n.Status, &n.MessageID, &n.Attempts, &n.Error, &n.CreatedAt, &n.UpdatedAt, &n.NotificationMode, &n.BotFingerprint, &n.MappingVersion, &n.MappingRevision, &n.TargetEmail, &n.ResolvedOpenID, &n.Source, &n.Mode, &n.BatchID, &n.RuleVersion, &n.Result, &nextAt, &idem)
			if cloudErr == nil {
				cloudErr = repo.upsertNotice(r.Context(), n, idem, nextAt)
			}
		}
		if cloudErr != nil {
			cwWriteError(w, fmt.Errorf("cloud casework notification persistence: %w", cloudErr))
			return
		}
	}
	message := "已保存单条测试通知请求；出队前将再次校验测试白名单、Bot 配置和事件绑定，且重复请求不重复发送"
	if in.Mode == "formal" {
		message = "已保存经正式预览确认的单条通知请求；出队前将再次校验权威映射、Bot 域收件人和事件绑定，批量及自动正式发送仍保持禁用"
	}
	if in.Resend {
		message = "已保存受控重新发送请求；原消息与审计保留，本次将生成独立飞书消息"
	}
	writeJSON(w, 202, map[string]any{"data": a, "notification_id": notificationID, "notification": map[string]any{"id": notificationID, "status": "pending", "message_id": "", "updated_at": a.UpdatedAt}, "deduplicated": inserted == 0, "idempotent": inserted == 0, "reused": inserted == 0, "resend": in.Resend, "message": message})
}
func cwWorkbenchURL(id string) string {
	const rowAppID = "app_e5d1388d65ef1b49"
	id = strings.TrimSpace(id)
	if strings.ContainsAny(id, "\r\n\t\x00") {
		return ""
	}
	raw := strings.TrimSpace(os.Getenv("TAP_WORKBENCH_URL"))
	if raw == "" {
		location := "/?view=tasks"
		if id != "" {
			location += "&alert_id=" + url.QueryEscape(id)
		}
		return "https://aime.tiktok-row.net/standalone/app/" + rowAppID + "?installed_first=1&app_location=" + url.QueryEscape(location)
	}
	u, e := url.Parse(raw)
	if e != nil || u.Scheme != "https" || u.Host == "" || u.User != nil {
		return ""
	}
	if strings.Contains(u.Path, "/standalone/app/") && !strings.HasSuffix(strings.TrimRight(u.Path, "/"), "/"+rowAppID) {
		return ""
	}
	if id != "" {
		q := u.Query()
		// AIME standalone URLs carry the actual App route inside app_location.
		// Putting alert_id only on the outer container opens the App home instead.
		if q.Has("app_location") || strings.Contains(u.Path, "/standalone/app/") {
			location := q.Get("app_location")
			if location == "" {
				location = "/"
			}
			inner, err := url.Parse(location)
			if err != nil || inner.Scheme != "" || inner.Host != "" || !strings.HasPrefix(inner.Path, "/") {
				return ""
			}
			innerQuery := inner.Query()
			innerQuery.Set("view", "tasks")
			innerQuery.Set("alert_id", id)
			inner.RawQuery = innerQuery.Encode()
			q.Set("app_location", inner.String())
			q.Del("alert_id")
		} else {
			q.Set("alert_id", id)
			q.Set("view", "tasks")
		}
		u.RawQuery = q.Encode()
	}
	return u.String()
}
func cwCard(a cwCase, cfg cwConfig) map[string]any {
	return cwNotificationCard(a, cfg.NotificationMode, "")
}

// cwNotificationCard is the single renderer shared by preview, manual delivery
// and the outbox worker. Mode affects only the explicit test banner and never
// business facts or the formal recipient greeting.
func cwNotificationCard(a cwCase, mode, recipientName string) map[string]any {
	text := func(s string) map[string]any { return map[string]any{"tag": "plain_text", "content": s} }
	view := cwPresentation(a)
	greeting := view.RecipientGreeting
	if strings.TrimSpace(recipientName) != "" {
		greeting = recipientName
	}
	if strings.TrimSpace(greeting) == "" {
		greeting = "TAP owner"
	}
	testBanner := ""
	title := "TAP Alert · Action Required"
	button := "Go to event"
	if mode == "test" {
		testBanner = "🧪 TEST MODE · allowlist recipient only · not sent to the business owner\n\n"
		title = "TAP Alert · Test Preview"
		button = "Open test event"
	}

	var contextSection, evidenceSection, actionSection string
	if view.Kind == "quota" {
		contextSection = fmt.Sprintf("REGION / QUOTA\nRegion: %s\nTier: %s", cwValue(view.Region), cwValue(view.Tier))
		evidenceSection = fmt.Sprintf("ALERT DETAILS\nAlert Type: %s\nAlert Level: %s\nCount Unit: %s\nUsage: %s\nQuota: %s\nUsage Rate: %s\nExcess: %s", cwValue(view.AlertType), cwValue(view.AlertLevel), cwValue(view.QuotaUnit), cwFormatInt(view.QuotaUsed), cwFormatInt(view.QuotaLimit), cwFormatPercent(view.QuotaRatio), cwFormatInt(view.QuotaExcess))
		actionSection = fmt.Sprintf("REQUIRED ACTION\nHi %s, please review regional capacity and complete the quota follow-up by %s.", greeting, cwValue(view.Deadline))
	} else {
		identity := fmt.Sprintf("%s\nAccount ID: %s\nAccount Name: %s", cwValue(view.IdentityLabel), cwValue(view.AccountID), cwValue(view.AccountName))
		if strings.EqualFold(a.Row.Program, "ST") {
			identity = fmt.Sprintf("%s\nAccount ID: %s\nBrand Name: %s", cwValue(view.IdentityLabel), cwValue(view.AccountID), cwValue(view.AccountName))
		}
		if strings.EqualFold(a.Row.Program, "THT") {
			identity = fmt.Sprintf("Advertiser ID: %s\nAdvertiser Name: %s", cwValue(view.AdvertiserID), cwValue(view.AdvertiserName))
		} else if view.AdvertiserID != "" {
			identity += "\nAdvertiser ID: " + view.AdvertiserID
		}
		contextSection = fmt.Sprintf("Subject: [Action Required] TAP Alert\nCUSTOMER / ACCOUNT\nSubmitter: %s\nProgram: %s\nStatus: %s\nTime Window: %s\nRegion: %s\n%s", cwValue(view.Submitter), cwValue(view.Program), cwValue(view.Status), cwValue(view.TimeWindow), cwValue(view.Region), identity)
		evidenceSection = fmt.Sprintf("ALERT DETAILS · %s\nAlert Type: %s\nAlert Level: %s\nP0 CCR: %s\nP0 NFS: %s\nRevenue: %s\nPre → Post P0 CCR: %s → %s\n%s: %s\nComparison Status: %s\nReported Reasons: %s\nTrigger Criteria: %s", cwValue(view.DimensionLabel), cwValue(view.AlertType), cwValue(view.AlertLevel), cwFormatNumber(view.P0CCR, 2), cwFormatNumber(view.P0NFS, 0), cwFormatNumber(view.Revenue, 2), cwFormatNumber(view.PreCCR, 2), cwFormatNumber(view.PostCCR, 2), cwValue(view.IncreaseLabel), cwFormatPercent(view.CCRGrowthPct), cwValue(view.ComparisonReason), cwReportedReasonsText(view.ReportedReasons), cwValue(strings.Join(view.TriggerCriteria, "\n")))
		actionSection = fmt.Sprintf("REQUIRED ACTION\nHi %s, please complete the RCA by %s.\nRequired SLA: one week from the Alert date. If no action is taken, the account may be removed from TAP. Contact the TAP POC if support is needed.", greeting, cwValue(view.Deadline))
	}
	elements := []any{
		map[string]any{"tag": "div", "text": text(testBanner + contextSection)},
		map[string]any{"tag": "hr"},
		map[string]any{"tag": "div", "text": text(evidenceSection)},
		map[string]any{"tag": "hr"},
		map[string]any{"tag": "div", "text": text(actionSection)},
	}
	if u := cwWorkbenchURL(a.ID); u != "" {
		elements = append(elements, map[string]any{"tag": "action", "actions": []any{map[string]any{"tag": "button", "text": text(button), "url": u, "type": "primary"}}})
	}
	elements = append(elements, map[string]any{"tag": "note", "elements": []any{text("Alert ID: " + a.ID)}})
	return map[string]any{"config": map[string]any{"wide_screen_mode": true}, "header": map[string]any{"template": "blue", "title": text(title)}, "elements": elements}
}
func (m wbMember) AccountName() string {
	if m.Name != "" {
		return m.Name
	}
	if m.AccountID != "" {
		return m.AccountID
	}
	return m.AdvertiserID
}
func cwValue(s string) string {
	if strings.TrimSpace(s) == "" {
		return "未提供"
	}
	return s
}
func cwMetricText(v *float64) string {
	if v == nil {
		return "未返回"
	}
	return strconv.FormatFloat(*v, 'f', -1, 64)
}

var cwHTTPClient = &http.Client{Timeout: 8 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
var cwTokenMu sync.Mutex
var cwTokenValue, cwTokenApp string
var cwTokenUntil time.Time

func cwAPIBase() string {
	if os.Getenv("TAP_FEISHU_REGION") == "lark" {
		return "https://open.larksuite.com"
	}
	return "https://open.feishu.cn"
}

var cwAPIBaseForRequest = cwAPIBase

func cwHTTP(ctx context.Context, method, path, token string, body any) (map[string]any, error) {
	var requestBody io.Reader
	if body != nil {
		b, e := json.Marshal(body)
		if e != nil {
			return nil, e
		}
		requestBody = bytes.NewReader(b)
	}
	r, e := http.NewRequestWithContext(ctx, method, cwAPIBaseForRequest()+path, requestBody)
	if e != nil {
		return nil, e
	}
	if body != nil {
		r.Header.Set("Content-Type", "application/json")
	}
	if token != "" {
		r.Header.Set("Authorization", "Bearer "+token)
	}
	resp, e := cwHTTPClient.Do(r)
	if e != nil {
		return nil, errors.New("Feishu network/timeout failure")
	}
	defer resp.Body.Close()
	payload, readErr := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if readErr != nil {
		return nil, errors.New("invalid Feishu response")
	}
	var out map[string]any
	if json.Unmarshal(payload, &out) != nil {
		return nil, fmt.Errorf("Feishu HTTP %d", resp.StatusCode)
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, fmt.Errorf("Feishu HTTP %d code=%v msg=%v", resp.StatusCode, out["code"], cwSafeAPIMessage(asString(out["msg"]), token))
	}
	if v, ok := out["code"].(float64); !ok || v != 0 {
		return nil, fmt.Errorf("Feishu API code=%v msg=%s log_id=%s", out["code"], cwSafeAPIMessage(asString(out["msg"]), token), resp.Header.Get("X-Tt-Logid"))
	}
	return out, nil
}
func cwAccessToken(ctx context.Context) (string, error) {
	cwTokenMu.Lock()
	defer cwTokenMu.Unlock()
	creds, _, err := loadFeishuCredentials()
	if err != nil {
		return "", err
	}
	app := creds.AppID
	key := wbKey([]string{app, creds.AppSecret, cwAPIBase()})
	if cwTokenValue != "" && cwTokenApp == key && time.Now().Before(cwTokenUntil) {
		return cwTokenValue, nil
	}
	if app == "" || creds.AppSecret == "" {
		return "", errors.New("Feishu credentials not configured")
	}
	out, e := cwHTTP(ctx, "POST", "/open-apis/auth/v3/tenant_access_token/internal", "", map[string]string{"app_id": app, "app_secret": creds.AppSecret})
	if e != nil {
		return "", e
	}
	token, _ := out["tenant_access_token"].(string)
	expiry, _ := out["expire"].(float64)
	if token == "" {
		return "", errors.New("Feishu token missing")
	}
	cwTokenValue = token
	cwTokenApp = key
	cwTokenUntil = time.Now().Add(time.Duration(expiry-60) * time.Second)
	return token, nil
}

var cwOutboxMu sync.Mutex

func cwProcessOutbox() {
	if !cwOutboxMu.TryLock() {
		return
	}
	defer cwOutboxMu.Unlock()
	cfg, e := cwLoadConfig()
	if e != nil {
		return
	}
	db, e := cwDB()
	if e != nil {
		return
	}
	defer db.Close()
	now := time.Now().Unix()
	db.Exec("UPDATE tap_outbox SET status='failed',error='delivery_unknown_after_worker_restart_check_before_retry' WHERE status='sending' AND next_at<?", now-90)
	var n cwNotice
	e = db.QueryRow(`SELECT id,case_id,recipient,kind,status,message_id,attempts,error,created_at,updated_at,notification_mode,bot_fingerprint,mapping_version,mapping_revision,target_email,resolved_open_id,source,mode
		FROM tap_outbox AS pending
		WHERE pending.status='pending' AND pending.next_at<=?
		AND (pending.kind<>'send' OR NOT EXISTS (
			SELECT 1 FROM tap_outbox AS delivered
			WHERE delivered.case_id=pending.case_id AND delivered.notification_mode=pending.notification_mode AND delivered.kind='send' AND delivered.status='sent' AND TRIM(delivered.message_id)<>'' AND delivered.generation>=pending.generation
		))
		ORDER BY pending.created_at LIMIT 1`, now).Scan(&n.ID, &n.CaseID, &n.Recipient, &n.Kind, &n.Status, &n.MessageID, &n.Attempts, &n.Error, &n.CreatedAt, &n.UpdatedAt, &n.NotificationMode, &n.BotFingerprint, &n.MappingVersion, &n.MappingRevision, &n.TargetEmail, &n.ResolvedOpenID, &n.Source, &n.Mode)
	if e != nil {
		return
	}
	if n.NotificationMode != "test" && n.NotificationMode != "formal" {
		cwOutboxBlocked(db, n, "notification_mode_changed_or_unsupported")
		return
	}
	if n.NotificationMode == "formal" && (n.Source != "manual" || n.Mode != "formal") {
		cwOutboxBlocked(db, n, "formal_batch_or_auto_disabled")
		return
	}
	if n.NotificationMode == "test" && cfg.NotificationMode != "test" {
		cwOutboxBlocked(db, n, "notification_mode_changed_or_unsupported")
		return
	}
	fingerprint, err := cwBotFingerprint()
	if err != nil || n.BotFingerprint == "" || n.BotFingerprint != fingerprint {
		cwOutboxBlocked(db, n, "bot_configuration_changed_repreview_required")
		return
	}
	a, e := cwRead(db, n.CaseID)
	if e != nil {
		cwOutboxBlocked(db, n, "case_not_available")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	parts := strings.SplitN(n.Recipient, ":", 2)
	if len(parts) != 2 || parts[0] != "open_id" || parts[1] == "" {
		cwOutboxBlocked(db, n, "notification_target_invalid")
		return
	}
	receiveType, receiveID, actualTarget := "open_id", parts[1], n.Recipient
	recipientName := ""
	if n.NotificationMode == "test" {
		allowed := false
		for _, target := range cfg.TestRecipients {
			if target.Type == "open_id" && target.ID == receiveID {
				allowed, recipientName = true, target.Label
			}
		}
		if !allowed {
			cwOutboxBlocked(db, n, "test_target_removed_or_not_person")
			return
		}
	} else {
		revision, refreshErr := cwSyncIdentityMappings(ctx, db)
		resolution, resolveErr := cwResolveCaseMapping(ctx, db, a)
		if refreshErr != nil || resolveErr != nil || resolution.Status != "matched" || resolution.Mapping == nil {
			cwOutboxBlocked(db, n, "formal_mapping_changed_repreview_required")
			return
		}
		mapping := *resolution.Mapping
		resolvedID, status, _ := cwResolveFormalOpenID(ctx, a.ID, mapping.Email)
		if status != "resolved" || resolvedID != receiveID || resolvedID != n.ResolvedOpenID || mapping.Email != n.TargetEmail || mapping.RecordVersion != n.MappingVersion || revision != n.MappingRevision {
			cwOutboxBlocked(db, n, "formal_recipient_changed_repreview_required")
			return
		}
		recipientName = mapping.BusinessName
	}
	_, e = db.Exec(`UPDATE tap_outbox SET status='pending',actual_target=?,error='',updated_at=? WHERE id=? AND status='pending'`, actualTarget, cwNow(), n.ID)
	if e != nil {
		return
	}
	claimed, e := db.Exec("UPDATE tap_outbox SET status='sending',attempts=attempts+1,next_at=?,last_attempt_at=?,updated_at=? WHERE id=? AND status='pending'", now, cwNow(), cwNow(), n.ID)
	if e != nil {
		return
	}
	count, _ := claimed.RowsAffected()
	if count != 1 {
		return
	}
	token, e := cwAccessToken(ctx)
	if e != nil {
		cwOutboxError(db, n, e)
		return
	}
	latestConfig, configErr := cwLoadConfig()
	latestBot, botErr := cwBotFingerprint()
	allowedNow := n.NotificationMode == "formal" && n.Source == "manual" && n.Mode == "formal"
	if n.NotificationMode == "test" && configErr == nil && latestConfig.NotificationMode == "test" {
		for _, target := range latestConfig.TestRecipients {
			if target.Type == "open_id" && target.ID == receiveID {
				allowedNow = true
			}
		}
	}
	if configErr != nil || botErr != nil || latestBot != n.BotFingerprint || !allowedNow {
		cwOutboxBlocked(db, n, "notification_configuration_changed_repreview_required")
		return
	}
	content, _ := json.Marshal(cwNotificationCard(a, n.NotificationMode, recipientName))
	var out map[string]any
	if n.Kind == "send" {
		out, e = cwHTTP(ctx, http.MethodPost, "/open-apis/im/v1/messages?receive_id_type="+url.QueryEscape(receiveType), token, map[string]any{"receive_id": receiveID, "msg_type": "interactive", "content": string(content), "uuid": cwMessageUUID(n.ID)})
		if e == nil {
			data, _ := out["data"].(map[string]any)
			n.MessageID, _ = data["message_id"].(string)
			if n.MessageID == "" {
				e = errors.New("Feishu response missing message_id")
			}
		}
	} else {
		_, e = cwHTTP(ctx, http.MethodPatch, "/open-apis/im/v1/messages/"+url.PathEscape(n.MessageID), token, map[string]string{"content": string(content)})
	}
	if e != nil {
		cwOutboxError(db, n, e)
		return
	}
	tx, e := db.Begin()
	if e != nil {
		return
	}
	defer tx.Rollback()
	if _, e = tx.Exec("UPDATE tap_outbox SET status='sent',message_id=?,error='',result='sent',updated_at=? WHERE id=? AND status='sending'", n.MessageID, cwNow(), n.ID); e != nil {
		return
	}
	latest, e := cwRead(tx, n.CaseID)
	if e != nil {
		return
	}
	if latest.Version != a.Version {
		if e = cwQueueUpdates(tx, latest); e != nil {
			return
		}
	}
	if e = tx.Commit(); e != nil {
		return
	}
	if e = cwSyncNoticeFromLocal(ctx, db, n.ID); e != nil {
		logMsg("[casework] cloud outbox sync failed after delivery", "plugin")
	}
}
func cwOutboxBlocked(db *sql.DB, n cwNotice, reason string) {
	if result, err := db.Exec("UPDATE tap_outbox SET status='blocked',result='blocked',error=?,next_at=?,updated_at=? WHERE id=?", reason, time.Now().Add(5*time.Minute).Unix(), cwNow(), n.ID); err == nil {
		if count, _ := result.RowsAffected(); count == 1 {
			ctx, cancel := cwCloudContext()
			defer cancel()
			_ = cwSyncNoticeFromLocal(ctx, db, n.ID)
		}
	}
}
func cwOutboxError(db *sql.DB, n cwNotice, e error) {
	// A timeout can mean accepted-but-response-lost. Only a new explicit preview
	// and confirmation may retry, with the same message uuid.
	if result, err := db.Exec("UPDATE tap_outbox SET status='failed',result='failed',error=?,updated_at=? WHERE id=?", e.Error(), cwNow(), n.ID); err == nil {
		if count, _ := result.RowsAffected(); count == 1 {
			ctx, cancel := cwCloudContext()
			defer cancel()
			_ = cwSyncNoticeFromLocal(ctx, db, n.ID)
		}
	}
}
func cwMessageUUID(id string) string {
	// Preserve the old UUID for existing jobs; hash only short legacy fixture IDs.
	if len(id) >= 32 {
		return id[:32]
	}
	return wbKey([]string{"feishu-message", id})[:32]
}
func cwSafeAPIMessage(message, token string) string {
	if token != "" {
		message = strings.ReplaceAll(message, token, "[redacted]")
	}
	if c, _, err := loadFeishuCredentials(); err == nil && c.AppSecret != "" {
		message = strings.ReplaceAll(message, c.AppSecret, "[redacted]")
	}
	message = strings.ReplaceAll(strings.ReplaceAll(message, "\n", " "), "\r", " ")
	if len(message) > 512 {
		message = message[:512]
	}
	return message
}

func cwStartWorker() {
	go func() {
		ticker := time.NewTicker(2 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			cwProcessOutbox()
		}
	}()
}

func cwDecrypt(raw []byte, key string) ([]byte, error) {
	var envelope struct {
		Encrypt string `json:"encrypt"`
	}
	if json.Unmarshal(raw, &envelope) != nil || envelope.Encrypt == "" {
		return nil, errors.New("encrypted payload required")
	}
	b, e := base64.StdEncoding.DecodeString(envelope.Encrypt)
	if e != nil || len(b) < 32 || (len(b)-16)%16 != 0 {
		return nil, errors.New("invalid encryption")
	}
	h := sha256.Sum256([]byte(key))
	block, _ := aes.NewCipher(h[:])
	plain := make([]byte, len(b)-16)
	cipher.NewCBCDecrypter(block, b[:16]).CryptBlocks(plain, b[16:])
	padding := int(plain[len(plain)-1])
	if padding < 1 || padding > 16 || padding > len(plain) {
		return nil, errors.New("invalid padding")
	}
	for _, x := range plain[len(plain)-padding:] {
		if int(x) != padding {
			return nil, errors.New("invalid padding")
		}
	}
	return plain[:len(plain)-padding], nil
}
func cwEqual(a, b string) bool {
	return a != "" && b != "" && subtle.ConstantTimeCompare([]byte(a), []byte(b)) == 1
}
func cwVerifyCallback(r *http.Request, raw []byte) ([]byte, error) {
	key := os.Getenv("TAP_FEISHU_ENCRYPT_KEY")
	if key == "" || os.Getenv("TAP_FEISHU_VERIFICATION_TOKEN") == "" {
		return nil, errors.New("callback not configured")
	}
	ts := r.Header.Get("X-Lark-Request-Timestamp")
	n, e := strconv.ParseInt(ts, 10, 64)
	if e != nil || time.Now().Unix()-n > 300 || n-time.Now().Unix() > 300 {
		return nil, errors.New("stale callback")
	}
	nonce := r.Header.Get("X-Lark-Request-Nonce")
	if nonce == "" {
		return nil, errors.New("missing nonce")
	}
	sum := sha256.Sum256(append([]byte(ts+nonce+key), raw...))
	if !cwEqual(hex.EncodeToString(sum[:]), r.Header.Get("X-Lark-Signature")) {
		return nil, errors.New("invalid signature")
	}
	return cwDecrypt(raw, key)
}
func cwCallbackHandler(w http.ResponseWriter, r *http.Request) {
	raw, e := io.ReadAll(http.MaxBytesReader(w, r.Body, 256<<10))
	if e != nil {
		writeJSON(w, 400, map[string]any{"error": "invalid callback"})
		return
	}
	plain, e := cwVerifyCallback(r, raw)
	if e != nil {
		writeJSON(w, 401, map[string]any{"error": "callback verification failed"})
		return
	}
	var payload struct {
		Type      string `json:"type"`
		Token     string `json:"token"`
		Challenge string `json:"challenge"`
		Header    struct {
			EventID   string `json:"event_id"`
			EventType string `json:"event_type"`
			Token     string `json:"token"`
			AppID     string `json:"app_id"`
			TenantKey string `json:"tenant_key"`
		} `json:"header"`
		Event struct {
			Operator struct {
				OpenID    string `json:"open_id"`
				TenantKey string `json:"tenant_key"`
			} `json:"operator"`
			Action struct {
				Value     map[string]string `json:"value"`
				FormValue map[string]any    `json:"form_value"`
			} `json:"action"`
			Context struct {
				MessageID string `json:"open_message_id"`
			} `json:"context"`
		} `json:"event"`
	}
	if json.Unmarshal(plain, &payload) != nil {
		writeJSON(w, 400, map[string]any{"error": "invalid callback JSON"})
		return
	}
	token := payload.Header.Token
	if payload.Type == "url_verification" {
		token = payload.Token
	}
	if !cwEqual(token, os.Getenv("TAP_FEISHU_VERIFICATION_TOKEN")) {
		writeJSON(w, 401, map[string]any{"error": "invalid callback token"})
		return
	}
	if payload.Type == "url_verification" {
		writeJSON(w, 200, map[string]any{"challenge": payload.Challenge})
		return
	}
	if payload.Header.EventType != "card.action.trigger" || !cwEqual(payload.Header.AppID, os.Getenv("TAP_FEISHU_APP_ID")) || (os.Getenv("TAP_FEISHU_TENANT_KEY") != "" && !cwEqual(payload.Header.TenantKey, os.Getenv("TAP_FEISHU_TENANT_KEY"))) {
		writeJSON(w, 403, map[string]any{"error": "unexpected app/tenant/event"})
		return
	}
	cfg, e := cwLoadConfig()
	if e != nil {
		cwWriteError(w, e)
		return
	}
	actor := ""
	for _, m := range cfg.Members {
		if m.OpenID != "" && m.OpenID == payload.Event.Operator.OpenID {
			actor = m.Username
		}
	}
	toast := func(s string) {
		writeJSON(w, 200, map[string]any{"toast": map[string]any{"type": "error", "content": s}})
	}
	if actor == "" {
		toast("当前飞书账号未映射工作台身份，请联系运营")
		return
	}
	id := payload.Event.Action.Value["alert_id"]
	version, _ := strconv.Atoi(payload.Event.Action.Value["version"])
	db, e := cwDB()
	if e != nil {
		toast("台账暂不可用，未保存，请重试")
		return
	}
	var validMessage int
	e = db.QueryRow("SELECT COUNT(*) FROM tap_outbox WHERE case_id=? AND message_id=? AND kind='send' AND status='sent'", id, payload.Event.Context.MessageID).Scan(&validMessage)
	db.Close()
	if e != nil || payload.Event.Context.MessageID == "" || validMessage == 0 {
		toast("未找到对应通知，请在工作台处理")
		return
	}
	form := payload.Event.Action.FormValue
	field := func(k string) string { v, _ := form[k].(string); return v }
	fields := map[string]string{}
	for k, v := range form {
		if s, ok := v.(string); ok && k != "note" && k != "operation" && k != "plan" {
			fields[k] = s
		}
	}
	if payload.Header.EventID == "" {
		toast("回调缺少事件标识，未保存")
		return
	}
	cmd := cwCommand{ExpectedVersion: version, RequestID: "feishu:" + payload.Header.EventID, Operation: field("operation"), Plan: field("plan"), Note: field("note"), Fields: fields}
	if cmd.Operation != "accept" && cmd.Operation != "plan" && cmd.Operation != "complete" {
		toast("请在卡片中选择接受任务、保存方案或提交完成")
		return
	}
	a, e := cwMutate(id, cmd, actor, "feishu")
	if e != nil {
		var ce *cwError
		if errors.As(e, &ce) {
			toast(ce.Message)
		} else {
			toast("保存失败，请在工作台刷新确认后重试")
		}
		return
	}
	writeJSON(w, 200, map[string]any{"toast": map[string]any{"type": "success", "content": "已保存至共享台账"}, "card": map[string]any{"type": "raw", "data": cwCard(a, cfg)}})
}
