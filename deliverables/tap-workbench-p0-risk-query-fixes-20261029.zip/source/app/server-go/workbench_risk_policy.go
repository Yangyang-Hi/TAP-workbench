package main

import (
	"fmt"
	"sort"
	"strings"
	"time"
)

// Legacy name is retained for persisted snapshots and compatibility tests only.
// New scans resolve the active backend policy and persist its version on the job.
const wbGovernancePolicyVersion = wbDefaultPolicyLabel

func wbGovernanceRule(rule wbRule) wbRule {
	rule.RiskPolicy = wbGovernancePolicyVersion
	return rule
}

func wbPairGovernanceLevel(advertisers []wbAdvertiserEvidence, rule wbRule) (string, []string) {
	level := "unavailable"
	reasons := []string{}
	policy := wbDefaultPolicy()
	for _, advertiser := range advertisers {
		pairLevel, pairReasons := wbEvaluateAbsolute(advertiser.CCR, advertiser.NFS, "ET", "", "", policy)
		if pairLevel != "watch" && pairLevel != "extreme" {
			continue
		}
		if pairLevel == "extreme" || level != "extreme" {
			level = pairLevel
		}
		for _, reason := range pairReasons {
			reasons = append(reasons, fmt.Sprintf("Advertiser %s: %s", advertiser.AdvertiserID, reason))
		}
	}
	return level, reasons
}

func wbGovernanceLevel(row wbRow, rule wbRule) (string, []string) {
	return wbEvaluateRow(row, wbDefaultPolicy())
}

func wbGrowthGroupKey(program, tier, region string) string {
	return program + "|" + tier + "|" + region
}
func wbPolicyOnlyKind(policy wbResolvedPolicy, kind string) wbResolvedPolicy {
	out := policy
	out.Rules = nil
	for _, rule := range policy.Rules {
		if rule.Kind == kind {
			out.Rules = append(out.Rules, rule)
		}
	}
	return out
}
func wbComparisonGrowth(program string, c wbComparison) *float64 {
	if strings.EqualFold(program, "ET") || strings.EqualFold(program, "THT") {
		return c.CCRGrowthPct
	}
	// Only explicitly computed anchor-relative ST quarters are admissible.
	if strings.EqualFold(program, "ST") && c.Kind == "qoq" && c.PreStart != "" && c.PreEndExclusive != "" && c.PostStart == c.PreEndExclusive && c.PostEndExclusive != "" {
		return c.CCRGrowthPct
	}
	return nil
}
func wbComparisonGrowthAvailable(program string, c wbComparison) bool {
	return wbComparisonGrowth(program, c) != nil && c.Status == metricAvailable
}

func wbApplyGovernanceRows(rows []wbRow, rule wbRule) []wbRow {
	return wbApplyGovernanceRowsPolicy(rows, wbDefaultPolicy())
}
func wbApplyGovernanceRowsPolicy(rows []wbRow, policy wbResolvedPolicy) []wbRow {
	out := append([]wbRow(nil), rows...)
	for i := range out {
		out[i].Level, out[i].Reasons = wbEvaluateRow(out[i], policy)
	}
	for _, rankingRule := range policy.Rules {
		if rankingRule.Kind != "ranking" || !rankingRule.Enabled || rankingRule.Ranking == nil {
			continue
		}
		groups := map[string][]int{}
		for i := range out {
			g := wbComparisonGrowth(out[i].Program, out[i].Comparison)
			if !wbRuleApplies(rankingRule, out[i].Program, out[i].Member.Tier, out[i].Member.Region) || !wbComparisonGrowthAvailable(out[i].Program, out[i].Comparison) || g == nil || rankingRule.Ranking.PositiveOnly && *g <= 0 {
				continue
			}
			groups[wbGrowthGroupKey(out[i].Program, out[i].Member.Tier, out[i].Member.Region)] = append(groups[wbGrowthGroupKey(out[i].Program, out[i].Member.Tier, out[i].Member.Region)], i)
		}
		for _, indices := range groups {
			sort.SliceStable(indices, func(i, j int) bool {
				a, b := out[indices[i]], out[indices[j]]
				ga, gb := *wbComparisonGrowth(a.Program, a.Comparison), *wbComparisonGrowth(b.Program, b.Comparison)
				if ga != gb {
					return ga > gb
				}
				return a.ID < b.ID
			})
			rank := 0
			selectedCustomers := map[string]int{}
			for _, index := range indices {
				key := wbCustomerKey(out[index])
				customerRank := selectedCustomers[key]
				if customerRank == 0 {
					if rank >= rankingRule.Ranking.TopN {
						continue
					}
					rank++
					customerRank = rank
					selectedCustomers[key] = rank
				}
				out[index].Level = wbHigherRisk(out[index].Level, rankingRule.RiskLevel)
				out[index].Reasons = append(out[index].Reasons, fmt.Sprintf("%s：%s CCR 正增幅 Top%d · 第%d名 · %g%%", rankingRule.ID, out[index].Program, rankingRule.Ranking.TopN, customerRank, *wbComparisonGrowth(out[index].Program, out[index].Comparison)))
			}
		}
	}
	for i := range out {
		if out[i].Level == "extreme" {
			out[i].Level = "critical"
		}
	}
	return out
}

// wbGovernedRiskRowsForJob applies the same complete-batch policy used by the
// read model. Keeping event eligibility here prevents growth Top-N rows shown in
// the risk list from being rejected later merely because their absolute level is
// normal.
func wbGovernedRiskRowsForJob(job wbJob, selected ...wbRow) map[string]wbReadRow {
	persisted := append([]wbRow(nil), job.Rows...)
	if len(selected) > 0 {
		found := false
		for i := range persisted {
			if persisted[i].ID == selected[0].ID {
				// The create handler passes the governance-enriched row. Replace the
				// persisted snapshot so event eligibility uses the same comparison
				// facts that made the row visible in the read model.
				persisted[i] = selected[0]
				found = true
				break
			}
		}
		if !found {
			persisted = append(persisted, selected[0])
		}
	}
	rows := make([]wbReadRow, 0, len(persisted))
	for _, row := range persisted {
		rows = append(rows, wbToReadRow(job, row, nil, nil, time.Now()))
	}
	policy := wbDefaultPolicy()
	if len(job.Policy.Rules) > 0 {
		policy = job.Policy
	}
	out := make(map[string]wbReadRow)
	for _, row := range wbRiskList(rows, "combined", policy) {
		out[row.RowID] = row
	}
	return out
}

func wbRiskList(rows []wbReadRow, ranking string, optional ...wbResolvedPolicy) []wbReadRow {
	policy := wbDefaultPolicy()
	if len(optional) > 0 && len(optional[0].Rules) > 0 {
		policy = optional[0]
	}
	groups := map[string][]wbReadRow{}
	for _, row := range rows {
		g := wbComparisonGrowth(row.Program, row.Comparison)
		if wbComparisonGrowthAvailable(row.Program, row.Comparison) && g != nil {
			groups[wbGrowthGroupKey(row.Program, row.Tier, row.Region)] = append(groups[wbGrowthGroupKey(row.Program, row.Tier, row.Region)], row)
		}
	}
	growth := map[string]wbRiskRuleConfig{}
	for _, rule := range policy.Rules {
		if rule.Kind != "ranking" || !rule.Enabled || rule.Ranking == nil {
			continue
		}
		for groupKey, group := range groups {
			wbSortRows(group, "growth")
			n := 0
			seen := map[string]bool{}
			selectedCustomers := map[string]bool{}
			for _, row := range group {
				g := wbComparisonGrowth(row.Program, row.Comparison)
				if !wbRuleApplies(rule, row.Program, row.Tier, row.Region) || g == nil || rule.Ranking.PositiveOnly && *g <= 0 {
					continue
				}
				key := wbReadEventKey(row)
				if seen[key] {
					continue
				}
				seen[key] = true
				customer := wbReadCustomerKey(row)
				if !selectedCustomers[customer] {
					if n >= rule.Ranking.TopN {
						continue
					}
					selectedCustomers[customer] = true
					n++
				}
				growth[groupKey+"|"+key] = rule
			}
		}
	}
	out := []wbReadRow{}
	seen := map[string]bool{}
	for _, row := range rows {
		key := wbReadEventKey(row)
		evalRow := wbRow{ID: row.RowID, Program: row.Program, Member: wbMember{Tier: row.Tier, Region: row.Region}, CCR: row.CCR, NFS: row.NFS, Comparison: row.Comparison}
		level, reasons := wbEvaluateRow(evalRow, policy)
		absoluteLevel, _ := wbEvaluateAbsolute(row.CCR, row.NFS, row.Program, row.Tier, row.Region, wbPolicyOnlyKind(policy, "absolute"))
		absolute := wbRiskRank(absoluteLevel) > 0
		rankingRule, isGrowth := growth[wbGrowthGroupKey(row.Program, row.Tier, row.Region)+"|"+key]
		match := absolute || isGrowth || wbRiskRank(level) > 1
		if ranking == "absolute" {
			match = absolute
		}
		if ranking == "growth" {
			match = isGrowth
		}
		if !match || seen[key] {
			continue
		}
		seen[key] = true
		if isGrowth {
			level = wbHigherRisk(level, rankingRule.RiskLevel)
			if g := wbComparisonGrowth(row.Program, row.Comparison); g != nil {
				reasons = append(reasons, fmt.Sprintf("%s：%s × %s 有效正增幅 Top%d · %g%%", rankingRule.ID, row.Tier, row.Region, rankingRule.Ranking.TopN, *g))
			}
		}
		row.RiskLevel = level
		row.RiskReasons = reasons
		out = append(out, row)
	}
	wbSortRows(out, ranking)
	return out
}
func wbReadEventKey(row wbReadRow) string {
	if row.RowID != "" {
		return row.Program + "|event|" + row.RowID
	}
	return wbReadCustomerKey(row)
}
func wbReadCustomerKey(row wbReadRow) string {
	id := row.AccountID
	if row.Program == "THT" {
		id = row.AdvertiserID
		if id == "" {
			id = row.AccountID
		}
	}
	if id == "" {
		id = row.RowID
	}
	return row.Program + "|" + id
}
