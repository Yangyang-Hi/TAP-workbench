package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"
)

func TestP0ThreeWayCustomerPartitionAndCards(t *testing.T) {
	rows := []wbReadRow{
		{Program: "ET", AccountID: "absolute", RowID: "a", CCR: f64(45), NFS: f64(300)},
		{Program: "ET", AccountID: "both", RowID: "b", CCR: f64(45), NFS: f64(300), Comparison: wbComparison{Status: "available", CCRGrowthPct: f64(20)}},
		{Program: "ET", AccountID: "growth", RowID: "c", CCR: f64(1), NFS: f64(1), Comparison: wbComparison{Status: "available", CCRGrowthPct: f64(30)}},
		{Program: "ET", AccountID: "normal", RowID: "n", CCR: f64(1), NFS: f64(1)},
		{Program: "ET", AccountID: "missing", RowID: "m"},
	}
	risks := wbRiskList(rows, "combined")
	if len(risks) != 3 {
		t.Fatalf("risks=%+v", risks)
	}
	parts := wbRiskPartitions(risks, wbDefaultPolicy())
	if parts["ET|both"] != "both" || parts["ET|absolute"] != "absolute" || parts["ET|growth"] != "growth" {
		t.Fatalf("%v", parts)
	}
	// Multiple events for a single customer must not inflate the card.
	risks = append(risks, risks[0])
	for i := range risks {
		switch risks[i].AccountID {
		case "absolute":
			risks[i].EventStage = "closed"
		case "both":
			risks[i].EventStage = "pending_submitter"
		default:
			risks[i].EventStage = "pending_operator"
		}
	}
	cards := wbRiskCards(risks, 5)
	if *cards["risk_customers"].Value != 3 || *cards["pending_customers"].Value+*cards["in_progress_customers"].Value+*cards["closed_customers"].Value != 3 {
		t.Fatalf("%+v", cards)
	}
	if len(wbRiskList([]wbReadRow{{Program: "ST", RowID: "st", Comparison: wbComparison{Status: "available", Kind: "qoq", PreStart: "2026-04-01", PreEndExclusive: "2026-07-01", PostStart: "2026-07-01", PostEndExclusive: "2026-10-01", CCRGrowthPct: f64(20)}}}, "growth")) != 1 {
		t.Fatal("valid ST anchor-quarter growth excluded")
	}
}
func TestP0RankCustomersBeforeSearchAndPage(t *testing.T) {
	job := readModelFixture(t, 41)
	for i := range job.Rows {
		job.Rows[i].CCR = f64(1)
		job.Rows[i].NFS = f64(1)
		job.Rows[i].Level = "normal"
		job.Rows[i].Member.Region = "EUI"
		job.Rows[i].Member.Submitter = fmt.Sprintf("submitter-%02d", i)
		job.Rows[i].Comparison = wbComparison{Status: "available", PreCCR: f64(1), PostCCR: f64(1 + float64(i+1)/100), CCRGrowthPct: f64(float64(i + 1))}
	}
	if e := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); e != nil {
		t.Fatal(e)
	}
	read := func(query string) map[string]any {
		rr := httptest.NewRecorder()
		req := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly&"+query, nil).WithContext(wbReq("reader").Context())
		wbReadModelHandler(rr, req)
		if rr.Code != 200 {
			t.Fatal(rr.Body.String())
		}
		var body map[string]any
		if e := json.Unmarshal(rr.Body.Bytes(), &body); e != nil {
			t.Fatal(e)
		}
		return body["data"].(map[string]any)
	}
	filtered := read("submitter=submitter-00")
	if filtered["pagination"].(map[string]any)["total"] != float64(0) {
		t.Fatal("search recomputed Top20")
	}
	page := read("page_size=1")
	if len(page["rows"].([]any)) != 1 || page["cards"].(map[string]any)["risk_customers"].(map[string]any)["value"] != float64(20) {
		t.Fatalf("pagination changed customer count: %+v", page["cards"])
	}
	if page["pagination"].(map[string]any)["total"] != float64(20) {
		t.Fatal("normal pool leaked")
	}
	counts := page["rankings"].(map[string]any)["category_counts"].(map[string]any)
	if counts["combined"].(float64) != counts["absolute"].(float64)+counts["growth"].(float64)+counts["both"].(float64) {
		t.Fatal(counts)
	}
	options := page["filter_options"].(map[string]any)["submitters"].([]any)
	if len(options) != 20 {
		t.Fatalf("non-risk filter options leaked: %v", options)
	}
	if got := read("status=open")["pagination"].(map[string]any)["total"]; got != float64(20) {
		t.Fatalf("uncreated risk rows disappeared from open: %v", got)
	}
	if got := read("alert_level=critical")["pagination"].(map[string]any)["total"]; got != float64(0) {
		t.Fatal("risk level filter applied before adjudication")
	}
}
func TestP0EnrichedAdvertiserSearch(t *testing.T) {
	row := wbRow{Program: "ET", Member: wbMember{AccountID: "account", Name: "North Star"}, Advertisers: []wbAdvertiserEvidence{{AdvertiserID: "900000000000000001", AdvertiserName: "广告主名字"}}}
	for _, q := range []map[string]string{{"search": "900000000000000001"}, {"search": "north star"}, {"search": "广告主名字"}, {"advertiser_id": "900000000000000001"}} {
		if !wbRowMatches(row, nil, q, nil, nil) {
			t.Fatalf("failed %+v", q)
		}
	}
	if wbRowMatches(row, nil, map[string]string{"advertiser_id": "900000000000000002"}, nil, nil) {
		t.Fatal("inexact ADV match")
	}
}
func TestP0ArchiveKeepsHistoryAndRestoresMissingJSON(t *testing.T) {
	wbTestEnv(t)
	for i := 0; i < 15; i++ {
		j := wbJob{ID: fmt.Sprint(i), Principal: "same-operator", BatchID: fmt.Sprintf("week-%d", i), Request: wbRequest{Program: "ET"}, Status: "ready", StartedAt: fmt.Sprintf("2026-10-%02d", i+1)}
		if e := wbSaveJob(&j); e != nil {
			t.Fatal(e)
		}
	}
	state, e := wbReadDisk()
	if e != nil || len(state.Jobs) != 15 {
		t.Fatalf("%d %v", len(state.Jobs), e)
	}
	path, _ := wbStatePath()
	if e = os.Remove(path); e != nil {
		t.Fatal(e)
	}
	state, e = wbReadDisk()
	if e != nil || len(state.Jobs) != 15 {
		t.Fatalf("archive restore %d %v", len(state.Jobs), e)
	}
	db, _ := cwDB()
	defer db.Close()
	var cases int
	if e = db.QueryRow("SELECT count(*) FROM tap_cases").Scan(&cases); e != nil || cases != 0 {
		t.Fatal("scan archive touched business cases")
	}
}
func TestP0CoreQueriesSkipOptionalSources(t *testing.T) {
	wbTestEnv(t)
	old := accountVQSProbe
	defer func() { accountVQSProbe = old }()
	calls := make(chan string, 4)
	id := "7000000000000000001"
	accountVQSProbe = func(_ context.Context, _ *http.Request, source string) (map[string]any, error) {
		calls <- source
		return map[string]any{"status": "ok", "business_rows": []map[string]any{{"account_id": id, "dynamic_p0_ccr": 3.0, "p0_nfs": 60.0}}}, nil
	}
	ctx := context.WithValue(context.Background(), wbCorePhaseKey{}, true)
	metrics, e := queryAccountCurrentBatch(ctx, wbReq("reader"), []string{id}, "2026-10-01", "2026-10-25", "et_current_ccr_nfs", "ET")
	if e != nil || metrics[id].CCR == nil || len(calls) != 1 {
		t.Fatalf("core queries %d %v", len(calls), e)
	}
	if <-calls != "et_current_ccr_nfs" {
		t.Fatal("optional source requested before decision")
	}
	w := wbCurrentWindow(wbRequest{Start: "2026-10-19", End: "2026-10-25"})
	if w.Start != "2026-10-01" || w.End != "2026-10-25" {
		t.Fatal(w)
	}
}
func TestP0PipelineSavesDecisionsBeforeRiskOnlyDetails(t *testing.T) {
	wbTestEnv(t)
	oldM, oldB, oldC, oldD, oldP := wbLoadMembers, wbQueryETBatch, wbAccountComparisonQuery, wbScanAccountDetailQuery, wbQueryPairEvidence
	defer func() {
		wbLoadMembers = oldM
		wbQueryETBatch = oldB
		wbAccountComparisonQuery = oldC
		wbScanAccountDetailQuery = oldD
		wbQueryPairEvidence = oldP
	}()
	members := makeETMembers(3)
	for i := range members {
		members[i].Start = "2026-10-01"
		members[i].Tier = "ET"
		members[i].Region = "EUI"
	}
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return members, true, nil
	}
	wbQueryETBatch = func(ctx context.Context, _ *http.Request, ids []string, start, end string) (map[string]wbBatchMetric, error) {
		if !wbCoreOnly(ctx) || start != "2026-10-01" || end != "2026-10-25" {
			t.Fatal("wrong core phase/window")
		}
		out := map[string]wbBatchMetric{}
		for _, id := range ids {
			out[id] = wbBatchMetric{Status: "success", CCR: f64(1), NFS: f64(1)}
		}
		out[members[0].AccountID] = wbBatchMetric{Status: "success", CCR: f64(45), NFS: f64(300)}
		return out, nil
	}
	comparisons := 0
	wbAccountComparisonQuery = func(_ context.Context, _ *http.Request, ids []string, start, end, source, program string) (map[string]wbBatchMetric, error) {
		comparisons++
		out := map[string]wbBatchMetric{}
		for _, id := range ids {
			value := 1.0
			if id == members[2].AccountID && start == "2026-10-01" {
				value = 2
			}
			out[id] = wbBatchMetric{Status: "success", CCR: f64(value), NFS: f64(50)}
		}
		return out, nil
	}
	wbScanAccountDetailQuery = func(ctx context.Context, _ *http.Request, ids []string, start, end, source, program string) (map[string]wbBatchMetric, error) {
		state, e := wbReadDisk()
		if e != nil || state.Jobs["pipeline"].Stage != "risk_decisions_saved:enriching_risks" || comparisons != 2 || wbCoreOnly(ctx) {
			t.Fatal("details preceded durable decisions")
		}
		if len(ids) != 2 {
			t.Fatalf("normal customer queried: %v", ids)
		}
		out := map[string]wbBatchMetric{}
		for _, id := range ids {
			out[id] = wbBatchMetric{CCR: f64(999), Revenue: f64(10), RevenueStatus: "success"}
		}
		return out, nil
	}
	wbQueryPairEvidence = func(_ context.Context, _ *http.Request, got []wbMember, q wbRequest, _ wbRule) (map[string][]wbAdvertiserEvidence, error) {
		if len(got) != 2 || q.Start != "2026-10-01" {
			t.Fatalf("unexpected pair scope %d %+v", len(got), q)
		}
		return map[string][]wbAdvertiserEvidence{}, nil
	}
	config, _ := loadWBConfig()
	rule := testRule()
	job := &wbJob{ID: "pipeline", Principal: "operator", BatchID: "TAP-WEEK-2026-10-19-2026-10-25", Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rule: rule, Policy: wbDefaultPolicy(), Status: "running"}
	wbRunning[job.ID] = job
	wbRunJob(wbReq("operator"), job.ID, config)
	if job.Status != "ready" || len(job.Rows) != 3 || job.Matched != 2 {
		t.Fatalf("job %+v", job)
	}
	for _, r := range job.Rows {
		if r.CCR == nil || *r.CCR == 999 || r.CurrentWindow == nil {
			t.Fatal("enrichment changed core facts or lost window")
		}
	}
}
func TestP0QuotaReusesCloudCaseAndConfirmedPOCFlow(t *testing.T) {
	wbTestEnv(t)
	old := cwLoadRegionalPOCsForQuota
	defer func() { cwLoadRegionalPOCsForQuota = old }()
	rev := "one"
	email := "poc@bytedance.com"
	cwLoadRegionalPOCsForQuota = func(context.Context) (map[string]cwRegionalPOC, string, error) {
		return map[string]cwRegionalPOC{"EUI": {Region: "EUI", Name: "Regional POC", Email: email}}, rev, nil
	}
	item, e := cwCreateProgramQuotaAlert("ST", "Q4", "2026-10-19", "2026-10-25", wbQuotaExcess{Region: "EUI", Used: 11, Quota: 10, Ratio: 110})
	if e != nil {
		t.Fatal(e)
	}
	repo, _ := cwCaseworkRepositoryProvider()
	if _, e = repo.caseByID(context.Background(), item.ID); e != nil {
		t.Fatal("case absent from authority", e)
	}
	db, _ := cwDB()
	defer db.Close()
	first, e := cwResolveCaseMapping(context.Background(), db, item)
	if e != nil || first.Status != "matched" || first.Mapping.Email != email {
		t.Fatalf("%+v %v", first, e)
	}
	rev, email = "two", "changed@bytedance.com"
	second, _ := cwResolveCaseMapping(context.Background(), db, item)
	if first.Mapping.RecordVersion == second.Mapping.RecordVersion {
		t.Fatal("changed POC would bypass preview validation")
	}
	data := map[string]any{"quarter": "Q4", "regions": []map[string]any{{"region": "EUI", "st": map[string]any{}}}}
	cwDecorateQuotaNotificationState(context.Background(), data)
	metric := data["regions"].([]map[string]any)[0]["st"].(map[string]any)
	if metric["notification_status"] != "awaiting_confirmation" || metric["alert_id"] != item.ID {
		t.Fatal(metric)
	}
	_, e = db.Exec(`INSERT INTO tap_outbox(id,case_id,recipient,kind,status,message_id,notification_mode,created_at,updated_at) VALUES('formal-proof',?,'open_id:unit','send','sent','receipt','formal','now','now')`, item.ID)
	if e != nil {
		t.Fatal(e)
	}
	cwDecorateQuotaNotificationState(context.Background(), data)
	if metric["notification_status"] != "sent" {
		t.Fatal("formal receipt not reflected", metric)
	}
}
func TestP0STQuarterMaturityAndNoSyntheticAnchor(t *testing.T) {
	pre, post := 1.0, 2.5
	complete := wbComparisonResult("ST", "2026-07-01", &pre, &post, time.Date(2026, 10, 2, 0, 0, 0, 0, cwLocation()))
	if complete.Kind != "qoq" || complete.QoQGrowthPct == nil || *complete.QoQGrowthPct != 150 {
		t.Fatal(complete)
	}
	incomplete := wbComparisonResult("ST", "2026-10-01", &pre, &post, time.Date(2026, 10, 29, 0, 0, 0, 0, cwLocation()))
	if incomplete.Status != "window_incomplete" || incomplete.CCRGrowthPct != nil {
		t.Fatal(incomplete)
	}
	if anchor := stBatchDate("Q4", ""); anchor != "" {
		t.Fatal("fabricated source date", anchor)
	}
	row := wbRow{Program: "ET", CurrentWindow: &wbMetricWindow{Start: "2026-10-01", End: "2026-10-25"}}
	q := wbBackfillQuery(row, wbRequest{Start: "2026-10-19", End: "2026-10-25"})
	if !strings.HasSuffix(q.Start, "10-01") {
		t.Fatal("repair changed measurement window")
	}
}

func TestP0SavedPoliciesAreAppliedPerProgram(t *testing.T) {
	et, st := wbDefaultPolicy(), wbDefaultPolicy()
	et.Rules = []wbRiskRuleConfig{{ID: "watch", Program: "ALL", Kind: "absolute", MatchMode: "all", Conditions: []wbRiskCondition{{Metric: "p0_ccr", Operator: ">", Value: 10}}, Enabled: true, RiskLevel: "watch"}}
	st.Rules = []wbRiskRuleConfig{{ID: "watch", Program: "ALL", Kind: "absolute", MatchMode: "all", Conditions: []wbRiskCondition{{Metric: "p0_ccr", Operator: ">", Value: 20}}, Enabled: true, RiskLevel: "watch"}}
	p := wbSavedBatchPolicy([]wbJob{{Request: wbRequest{Program: "ET"}, Policy: et}, {Request: wbRequest{Program: "ST"}, Policy: st}})
	rows := wbRiskList([]wbReadRow{{Program: "ET", AccountID: "one", RowID: "one", CCR: f64(15)}, {Program: "ST", AccountID: "two", RowID: "two", CCR: f64(15)}}, "combined", p)
	if len(rows) != 1 || rows[0].Program != "ET" {
		t.Fatalf("batch policy mixed Programs %+v", rows)
	}
}
func TestP0QuotaCombinedRegionMustNotPickArbitraryPOC(t *testing.T) {
	wbTestEnv(t)
	old := cwLoadRegionalPOCsForQuota
	defer func() { cwLoadRegionalPOCsForQuota = old }()
	cwLoadRegionalPOCsForQuota = func(context.Context) (map[string]cwRegionalPOC, string, error) {
		return map[string]cwRegionalPOC{"KR": {Email: "kr@bytedance.com"}, "JP": {Email: "jp@bytedance.com"}}, "rev", nil
	}
	db, _ := cwDB()
	defer db.Close()
	resolution, e := cwResolveCaseMapping(context.Background(), db, cwCase{Kind: "quota", Row: wbRow{Member: wbMember{Region: "KR+JP"}}})
	if e != nil || resolution.Status != "conflict" {
		t.Fatal("ambiguous POC was selected", resolution, e)
	}
}

func TestP0FailedOnlyBatchRemainsVisibleAndDoesNotReportZero(t *testing.T) {
	job := readModelFixture(t, 0)
	job.Status = "failed"
	job.Complete = false
	job.Error = "source query timeout"
	job.Members = 100
	if e := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); e != nil {
		t.Fatal(e)
	}
	batches, _, e := wbPersistedBatches()
	if e != nil || len(batches) != 1 || batches[0].Status != "unavailable" {
		t.Fatalf("failed batch disappeared: %+v %v", batches, e)
	}
	rr := httptest.NewRecorder()
	r := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly", nil).WithContext(wbReq("reader").Context())
	wbReadModelHandler(rr, r)
	var body map[string]any
	if e = json.Unmarshal(rr.Body.Bytes(), &body); e != nil {
		t.Fatal(e)
	}
	data := body["data"].(map[string]any)
	if rr.Code != 200 || data["status"] != "unavailable" {
		t.Fatal(rr.Body.String())
	}
	card := data["cards"].(map[string]any)["risk_customers"].(map[string]any)
	if card["value"] != nil {
		t.Fatal("failed query masqueraded as zero", card)
	}
}
