package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func f64(n float64) *float64 { return &n }
func testRule() wbRule {
	return wbRule{Enabled: true, Version: "test", WatchCCR: 3, WatchNFS: 50, CriticalCCR: 45, CCRUnit: "raw"}
}
func TestAbsoluteBoundaries(t *testing.T) {
	for _, tt := range []struct {
		c, n *float64
		want string
	}{{f64(3), f64(50), "normal"}, {f64(3), f64(51), "watch"}, {f64(45), f64(0), "normal"}, {f64(45.01), f64(0), "critical"}, {f64(46), nil, "critical"}, {f64(0), f64(0), "normal"}, {nil, f64(90), "unavailable"}} {
		got, _ := evaluateWBAbsolute(tt.c, tt.n, testRule())
		if got != tt.want {
			t.Fatalf("got %s want %s", got, tt.want)
		}
	}
}
func TestMembershipAndLatestTicket(t *testing.T) {
	q := wbRequest{Program: "THT", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-15"}
	base := map[string]any{"type_name": "Protection program", "protection_program_name": "Temporary High Trust (THT) - Advertiser ID", "final_result": "APPROVE", "advertiser_id": "7675782032500424721", "create_date": "2026-10-02", "ticket_id": "11", "submitter": "Alice", "region": "APAC"}
	newer := cloneMap(base)
	newer["create_date"] = "2026-10-03"
	newer["ticket_id"] = "12"
	newer["submitter"] = "Bob"
	rejected := cloneMap(base)
	rejected["final_result"] = "REJECT"
	other := cloneMap(base)
	other["type_name"] = "Strategic trust apply"
	ms, _, err := canonicalWBMembers([]map[string]any{base, newer, rejected, other}, q, true)
	if err != nil || len(ms) != 1 || ms[0].Submitter != "Bob" || len(ms[0].Tickets) != 2 || len(ms[0].Submitters) != 2 {
		t.Fatalf("%+v %v", ms, err)
	}
	if ms[0].TicketID != "12" || ms[0].Tickets[0].TicketID != "11" {
		t.Fatal("latest display ticket or ticket history is incorrect")
	}
	q.Region = "CNOB"
	ms, _, err = canonicalWBMembers([]map[string]any{base}, q, true)
	if err != nil || len(ms) != 0 {
		t.Fatal("region filter ignored")
	}
	delete(base, "advertiser_id")
	if _, _, e := canonicalWBMembers([]map[string]any{base}, q, true); e == nil {
		t.Fatal("missing membership ID accepted")
	}
}
func wbTestEnv(t *testing.T) {
	t.Helper()
	oldPolicyProvider := wbRiskRepoProvider
	policyRepo := newMemoryRiskPolicyRepository()
	wbRiskRepoProvider = func() (riskPolicyRepository, error) { return policyRepo, nil }
	t.Cleanup(func() { wbRiskRepoProvider = oldPolicyProvider })
	old := pluginDir
	oldCaseworkProvider := cwCaseworkRepositoryProvider
	cwCaseworkRepositoryProvider = func() (caseworkRepository, error) { return localCaseworkRepository{}, nil }
	oldPairEvidence := wbQueryPairEvidence
	wbQueryPairEvidence = func(context.Context, *http.Request, []wbMember, wbRequest, wbRule) (map[string][]wbAdvertiserEvidence, error) {
		return map[string][]wbAdvertiserEvidence{}, nil
	}
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() {
		pluginDir = old
		cwCaseworkRepositoryProvider = oldCaseworkProvider
		wbQueryPairEvidence = oldPairEvidence
	})
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	wbMu.Lock()
	wbRunning = map[string]*wbJob{}
	wbMu.Unlock()
}
func wbReq(user string) *http.Request {
	r := httptest.NewRequest("GET", "/", nil)
	return r.WithContext(context.WithValue(r.Context(), ctxKeyUser, authResult{Username: user, Valid: true, HasAccess: true}))
}
func TestLiveScanFullListNoTop20Truncation(t *testing.T) {
	wbTestEnv(t)
	oldM, oldBatch := wbLoadMembers, wbQueryETBatch
	defer func() { wbLoadMembers = oldM; wbQueryETBatch = oldBatch }()
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		out := []wbMember{}
		for i := 0; i < 23; i++ {
			out = append(out, wbMember{AccountID: strings.Repeat("7", 18) + string(rune('0'+i/10)) + string(rune('0'+i%10)), TicketID: "ticket", Submitter: "Alice", Region: "APAC"})
		}
		return out, true, nil
	}
	wbQueryETBatch = func(_ context.Context, request *http.Request, ids []string, _, _ string) (map[string]wbBatchMetric, error) {
		if requestUsername(request) != "Alice" {
			t.Error("scan lost authenticated principal")
		}
		out := map[string]wbBatchMetric{}
		for _, id := range ids {
			out[id] = wbBatchMetric{Status: "success", CCR: f64(46), NFS: f64(2), QueriedAt: "now"}
		}
		return out, nil
	}
	q := wbRequest{Program: "ET", Region: "all", Start: "2026-10-01", End: "2026-10-15", MemberStart: "2026-10-01", MemberEnd: "2026-10-15"}
	c, e := loadWBConfig()
	if e != nil {
		t.Fatal(e)
	}
	job := &wbJob{ID: "full", Principal: "Alice", Request: q, Rule: testRule(), Status: "running", Rows: []wbRow{}}
	wbRunning["full"] = job
	wbRunJob(wbReq("Alice"), "full", c)
	j, e := wbLookup("full", "Alice")
	if e != nil || j.Status != "ready" || len(j.Rows) != 23 || j.Matched != 23 {
		t.Fatalf("scan=%+v error=%v", j, e)
	}
	if !strings.Contains(j.Rows[0].Message, "接收人：Alice") {
		t.Fatal("recipient not associated")
	}
	if shared, e := wbLookup("full", "Bob"); e != nil || shared.ID != "full" {
		t.Fatal("shared scan unavailable")
	}
	disk, e := wbReadDisk()
	if e != nil || len(disk.Jobs) != 1 {
		t.Fatal("scan not persisted")
	}
}
func TestPartialAndMissingMetrics(t *testing.T) {
	wbTestEnv(t)
	oldM, oldBatch := wbLoadMembers, wbQueryETBatch
	defer func() { wbLoadMembers = oldM; wbQueryETBatch = oldBatch }()
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return []wbMember{{AccountID: "7675782032500424721"}}, false, nil
	}
	wbQueryETBatch = func(context.Context, *http.Request, []string, string, string) (map[string]wbBatchMetric, error) {
		return map[string]wbBatchMetric{"7675782032500424721": {Status: "no_data", Message: "no fact row"}}, nil
	}
	c, _ := loadWBConfig()
	wbRunning["partial"] = &wbJob{ID: "partial", Principal: "Alice", Request: wbRequest{Program: "ET"}, Rule: testRule(), Status: "running"}
	wbRunJob(wbReq("Alice"), "partial", c)
	j, _ := wbLookup("partial", "Alice")
	if j.Status != "partial" || j.Matched != 0 || j.Rows[0].CCR != nil || j.Rows[0].MetricStatus != "no_data" || j.Rows[0].DataStatus != "No Fact" {
		t.Fatal("missing metric treated as zero or normal")
	}
}
func TestActionValidationPersistenceAndIsolation(t *testing.T) {
	wbTestEnv(t)
	j := &wbJob{ID: "scan", Principal: "Alice", Status: "ready", Rows: []wbRow{{ID: "risk", Level: "critical"}}}
	wbRunning[j.ID] = j
	call := func(user, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest("POST", "/api/workbench/alerts/risk/actions", strings.NewReader(body))
		r = r.WithContext(wbReq(user).Context())
		r.SetPathValue("id", "risk")
		w := httptest.NewRecorder()
		wbActionHandler(w, r)
		return w
	}
	if call("Alice", `{"scan_id":"scan","status":"closed","note":""}`).Code != 400 {
		t.Fatal("blank closure accepted")
	}
	if call("Bob", `{"scan_id":"scan","status":"closed","note":"checked"}`).Code < 400 {
		t.Fatal("cross-user action allowed")
	}
	if w := call("Alice", `{"scan_id":"scan","status":"processing","cause":"客户风险","note":"核查中"}`); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	s, e := wbReadDisk()
	if e != nil || len(s.Actions) != 1 {
		t.Fatal("action not persisted")
	}
	for _, a := range s.Actions {
		if len(a.History) != 1 || a.Principal != "Alice" {
			t.Fatal("audit missing")
		}
	}
}
func TestExactRuntimeMappingAndMissingValues(t *testing.T) {
	fm := map[string]string{"aid": `{"datasetfieldid":"10000000032791"}`, "ccr": `{"datasetfieldid":"10000000032693"}`, "nfs": `{"datasetfieldid":"10000000032674"}`}
	rows, e := runtimeBusinessRows([]map[string]any{{"aid": "7675782032500424721", "ccr": "0", "nfs": "0"}}, fm)
	if e != nil || rows[0]["dynamic_p0_ccr"] != float64(0) {
		t.Fatal(e)
	}
	for _, bad := range []any{"NaN", "Inf", "-1"} {
		_, e = runtimeBusinessRows([]map[string]any{{"aid": "7675782032500424721", "ccr": bad, "nfs": "2"}}, fm)
		if e == nil {
			t.Fatalf("accepted bad value %v", bad)
		}
	}
	nullable, ne := runtimeBusinessRows([]map[string]any{{"aid": "7675782032500424721", "ccr": "46", "nfs": nil}}, fm)
	if ne != nil || nullable[0]["p0_nfs"] != nil {
		t.Fatal("NULL NFS not preserved")
	}
	level, _ := evaluateWBAbsolute(wbMetric(nullable[0]["dynamic_p0_ccr"]), wbMetric(nullable[0]["p0_nfs"]), testRule())
	if level != "critical" {
		t.Fatal("CCR-only high risk suppressed by NULL NFS")
	}
	_, e = runtimeBusinessRows([]map[string]any{{"aid": float64(7675782032500424721), "ccr": "1", "nfs": "2"}}, fm)
	if e == nil {
		t.Fatal("unsafe numeric ID accepted")
	}
}
func TestScanAPIValidationAndAuthRegistry(t *testing.T) {
	wbTestEnv(t)
	r := httptest.NewRequest("POST", "/api/workbench/scans", strings.NewReader(`{"program":"ST"}`))
	r = r.WithContext(wbReq("Alice").Context())
	w := httptest.NewRecorder()
	wbStartHandler(w, r)
	if w.Code != 400 {
		t.Fatal("ST queried with ET route")
	}
	for _, route := range registry {
		if strings.HasPrefix(route.Path, "/api/workbench/") && route.Public {
			t.Fatal("public workbench route")
		}
	}
}
func TestDefaultCompleteNaturalWeekAndConfigCompleteness(t *testing.T) {
	wbTestEnv(t)
	c, e := loadWBConfig()
	if e != nil {
		t.Fatal(e)
	}
	q := wbDefaultRequest(c)
	if e = validateWBRequest(&q); e != nil {
		t.Fatal(e)
	}
	if c.Rules["ET"].BusinessConfirmed || c.MembershipCompleteConfirmed {
		t.Fatal("unverified rules marked confirmed")
	}
	start, end := previousCompleteWeek(time.Now().In(cwLocation()))
	if q.Start != start || q.End != end {
		t.Fatalf("default window must be previous complete natural week: %+v", q)
	}
	b, _ := os.ReadFile(filepath.Join(pluginDir, "config", "alert_workbench.json"))
	var m map[string]any
	if json.Unmarshal(b, &m) != nil {
		t.Fatal("config invalid")
	}
}

func TestMembershipExactMappingAndIDPrecision(t *testing.T) {
	fields := map[string]fieldConfig{}
	for _, key := range []string{"type_name", "final_result", "create_date", "account_id"} {
		fields[key] = fieldConfig{DimMetID: key + "-field", SourceName: key}
	}
	raw := map[string]any{"type_name": "Emerging trust apply", "final_result": "APPROVE", "create_date": "2026-10-01 03:04:05", "account_id": "7675782032500424721"}
	rows, e := wbExactMembershipRows([]map[string]any{raw}, fields, nil)
	if e != nil || len(rows) != 1 {
		t.Fatalf("exact aliases failed: %v", e)
	}
	raw["account_id"] = float64(7675782032500424721)
	if _, e = wbExactMembershipRows([]map[string]any{raw}, fields, nil); e == nil {
		t.Fatal("membership rounded ID accepted")
	}
	delete(raw, "account_id")
	raw["another_account_id_column"] = "7675782032500424721"
	if _, e = wbExactMembershipRows([]map[string]any{raw}, fields, nil); e == nil {
		t.Fatal("fuzzy membership ID matched")
	}
}
func TestScopeChangesWhenSourceContractChanges(t *testing.T) {
	wbTestEnv(t)
	pluginDir = t.TempDir()
	if e := os.MkdirAll(filepath.Join(pluginDir, "config"), 0700); e != nil {
		t.Fatal(e)
	}
	file := filepath.Join(pluginDir, "config", "data_sources.yaml")
	if e := os.WriteFile(file, []byte("RID1"), 0600); e != nil {
		t.Fatal(e)
	}
	first := wbScope("Alice", wbRequest{}, wbConfig{})
	if e := os.WriteFile(file, []byte("RID2"), 0600); e != nil {
		t.Fatal(e)
	}
	if first == wbScope("Alice", wbRequest{}, wbConfig{}) {
		t.Fatal("stale scan cache reused after config update")
	}
}
func TestTHTScanBudgetStillBlocksWithoutLosingMembershipCount(t *testing.T) {
	wbTestEnv(t)
	oldM, oldQ := wbLoadMembers, wbQueryTHTCurrent
	defer func() { wbLoadMembers = oldM; wbQueryTHTCurrent = oldQ }()
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return []wbMember{{AdvertiserID: "7675782032500424721"}, {AdvertiserID: "7244006541899137025"}}, true, nil
	}
	wbQueryTHTCurrent = func(context.Context, *http.Request, etCCRDiagnosticRequest) (map[string]any, int) {
		t.Error("THT query ran despite budget blocking whole cohort")
		return nil, 500
	}
	c, _ := loadWBConfig()
	c.MaxClients = 1
	wbRunning["budget"] = &wbJob{ID: "budget", Principal: "Alice", Request: wbRequest{Program: "THT"}, Rule: testRule(), Status: "running"}
	wbRunJob(wbReq("Alice"), "budget", c)
	j, _ := wbLookup("budget", "Alice")
	if j.Status != "blocked" || j.Done != 0 || j.Members != 2 || !j.Complete {
		t.Fatalf("THT budget/count contract changed: %+v", j)
	}
	disk, err := wbReadDisk()
	if err != nil || disk.Jobs["budget"].Members != 2 || !disk.Jobs["budget"].Complete {
		t.Fatalf("membership count was not persisted before block: disk=%+v err=%v", disk.Jobs["budget"], err)
	}
}

func TestAllowlistPresentationDoesNotChangeAlertLevel(t *testing.T) {
	level, reasons := evaluateWBAbsolute(f64(46), f64(0), testRule())
	row := wbRow{Level: level, Reasons: reasons, AllowlistStatus: "Yes"}
	if row.Level != "critical" || !wbMatched(row) {
		t.Fatal("allowlist changed alert decision")
	}
}

func TestEmptyHighRiskResultState(t *testing.T) {
	level, _ := evaluateWBAbsolute(f64(2), f64(100), testRule())
	rows := []wbRow{{Level: level, DataStatus: "Success"}}
	matched := 0
	for _, row := range rows {
		if wbMatched(row) {
			matched++
		}
	}
	if len(rows) != 1 || matched != 0 {
		t.Fatal("completed scan must preserve scanned count with zero high risk")
	}
}

func etMembershipContractFixture() (sourceConfig, []map[string]any) {
	source := sourceConfig{Fields: map[string]fieldConfig{
		"type_name": {DimMetID: "10000000536474", UniqueID: "260907113221380", SourceName: "type_name"},
	}}
	filters := []map[string]any{{"id": "10000000536474", "name": "type_name", "op": "in", "val": []any{"Emerging trust apply"}}}
	return source, filters
}

func etMembershipRow(accountID, ticketID string) map[string]any {
	return map[string]any{"final_result": "APPROVE", "create_date": "2026-10-02 03:04:05", "account_id": accountID, "ticket_id": ticketID, "submitter": "Alice", "region": "APAC"}
}

func TestETMembershipMissingTypeNameRequiresProvenVQSFilterContract(t *testing.T) {
	source, filters := etMembershipContractFixture()
	proven, reason := proveETTypeNameFilterContract("et_account_list", source, filters)
	if !proven || reason != "" {
		t.Fatalf("valid VQS filter contract not proven: proven=%t reason=%s", proven, reason)
	}
	rows := []map[string]any{etMembershipRow("7675782032500424721", "ticket-1")}
	rows, supplemented := supplementETTypeNameFromContract(rows, proven)
	members, _, err := canonicalWBMembers(rows, wbRequest{Program: "ET", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-15"}, true)
	if err != nil || supplemented != 1 || len(members) != 1 || members[0].AccountID != "7675782032500424721" {
		t.Fatalf("contract-backed ET row rejected: supplemented=%d members=%#v err=%v", supplemented, members, err)
	}

	unproven, blockReason := proveETTypeNameFilterContract("et_account_list", source, nil)
	blockedRows, blockedSupplemented := supplementETTypeNameFromContract([]map[string]any{etMembershipRow("7675782032500424721", "ticket-1")}, unproven)
	blocked, _, err := canonicalWBMembers(blockedRows, wbRequest{Program: "ET", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-15"}, true)
	if err != nil || unproven || blockReason == "" || blockedSupplemented != 0 || len(blocked) != 0 {
		t.Fatalf("unproven ET row did not fail closed: proven=%t reason=%s supplemented=%d members=%#v err=%v", unproven, blockReason, blockedSupplemented, blocked, err)
	}
}

func TestETMembershipContractNeverOverridesExplicitTypeOrApproval(t *testing.T) {
	source, filters := etMembershipContractFixture()
	proven, _ := proveETTypeNameFilterContract("et_account_list", source, filters)
	wrongType := etMembershipRow("7675782032500424721", "wrong-type")
	wrongType["type_name"] = "Strategic trust apply"
	rejected := etMembershipRow("7244006541899137025", "rejected")
	rejected["final_result"] = "REJECT"
	rows, supplemented := supplementETTypeNameFromContract([]map[string]any{wrongType, rejected}, proven)
	members, _, err := canonicalWBMembers(rows, wbRequest{Program: "ET", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-15"}, true)
	if err != nil || supplemented != 1 || len(members) != 0 || rows[0]["type_name"] != "Strategic trust apply" {
		t.Fatalf("explicit type or per-row approval was overwritten: supplemented=%d rows=%#v members=%#v err=%v", supplemented, rows, members, err)
	}
}

func TestETMembershipContractPreservesDedupAndAccountIDSemantics(t *testing.T) {
	source, filters := etMembershipContractFixture()
	proven, _ := proveETTypeNameFilterContract("et_account_list", source, filters)
	rows, supplemented := supplementETTypeNameFromContract([]map[string]any{
		etMembershipRow("7675782032500424721", "ticket-1"),
		etMembershipRow("7675782032500424721", "ticket-2"),
	}, proven)
	members, _, err := canonicalWBMembers(rows, wbRequest{Program: "ET", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-15"}, true)
	if err != nil || supplemented != 2 || len(members) != 1 || members[0].AccountID != "7675782032500424721" || len(members[0].Tickets) != 2 {
		t.Fatalf("ET dedup/account semantics changed: supplemented=%d members=%#v err=%v", supplemented, members, err)
	}
}

func TestETMembershipFilterContractRejectsConflictingValue(t *testing.T) {
	source, _ := etMembershipContractFixture()
	conflict := []map[string]any{{"id": "10000000536474", "name": "type_name", "op": "in", "val": []any{"Strategic trust apply"}}}
	if proven, reason := proveETTypeNameFilterContract("et_account_list", source, conflict); proven || reason != "type_name_filter_value_conflict" {
		t.Fatalf("conflicting VQS contract accepted: proven=%t reason=%s", proven, reason)
	}
}

func TestETMembershipAllowsSavedReportWithoutTicketProjection(t *testing.T) {
	source, filters := etMembershipContractFixture()
	proven, _ := proveETTypeNameFilterContract("et_account_list", source, filters)
	row := etMembershipRow("7675782032500424721", "")
	rows, _ := supplementETTypeNameFromContract([]map[string]any{row}, proven)
	members, _, err := canonicalWBMembers(rows, wbRequest{Program: "ET", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-15"}, true)
	if err != nil || len(members) != 1 || members[0].AccountID != "7675782032500424721" {
		t.Fatalf("saved-report ET row without projected ticket rejected: members=%#v err=%v", members, err)
	}
}
