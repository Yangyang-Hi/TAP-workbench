package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/google/uuid"
)

const wbSchedulerPrincipal = "tap-weekly-scheduler"

func previousCompleteWeekIn(now time.Time, loc *time.Location) (string, string) {
	local := now.In(loc)
	daysSinceMonday := (int(local.Weekday()) + 6) % 7
	thisMonday := time.Date(local.Year(), local.Month(), local.Day(), 0, 0, 0, 0, loc).AddDate(0, 0, -daysSinceMonday)
	return thisMonday.AddDate(0, 0, -7).Format("2006-01-02"), thisMonday.AddDate(0, 0, -1).Format("2006-01-02")
}

// wbWeeklyScheduleDecision is kept as the default Monday gate used by older
// callers. Production scheduling uses wbWeeklyScheduleDecisionWithConfig.
func wbWeeklyScheduleDecision(now time.Time, timezone string, completed map[string]bool) (bool, string, string, error) {
	return wbWeeklyScheduleDecisionWithConfig(now, timezone, wbWeeklySchedulerConfig{Enabled: true, Weekday: int(time.Monday)}, completed)
}

func wbWeeklyScheduleDecisionWithConfig(now time.Time, timezone string, schedule wbWeeklySchedulerConfig, completed map[string]bool) (bool, string, string, error) {
	loc, err := time.LoadLocation(timezone)
	if err != nil {
		return false, "", "", err
	}
	local := now.In(loc)
	start, end := previousCompleteWeekIn(now, loc)
	batchID := fmt.Sprintf("TAP-WEEK-%s-%s", start, end)
	if !schedule.Enabled {
		return false, batchID, "disabled", nil
	}
	weekday := schedule.Weekday
	if weekday < 0 || weekday > 6 {
		return false, batchID, "invalid_weekday", fmt.Errorf("weekly scheduler weekday must be 0..6")
	}
	if int(local.Weekday()) != weekday {
		return false, batchID, "outside_schedule_day", nil
	}
	daysSinceMonday := (int(local.Weekday()) + 6) % 7
	thisMonday := time.Date(local.Year(), local.Month(), local.Day(), 0, 0, 0, 0, loc).AddDate(0, 0, -daysSinceMonday)
	dueOffset := (weekday - int(time.Monday) + 7) % 7
	due := thisMonday.AddDate(0, 0, dueOffset).Add(time.Duration(schedule.Hour)*time.Hour + time.Duration(schedule.Minute+schedule.DataReadyDelayMin)*time.Minute)
	if local.Before(due) {
		return false, batchID, "data_not_ready", nil
	}
	for _, program := range []string{"ET", "THT", "ST"} {
		if !completed[program] {
			return true, batchID, "missing_" + strings.ToLower(program), nil
		}
	}
	return false, batchID, "batch_complete", nil
}

func wbScheduledJobComplete(job wbJob) bool {
	if job.Status != "ready" && job.Status != "partial" && job.Status != "empty" {
		return false
	}
	// ET/ST completion is based on the authoritative Account-grain scan. Optional
	// advertiser evidence may be unavailable without making Account metrics stale.
	return true
}

func wbScheduledJobInFlight(job wbJob, now time.Time) bool {
	if job.Status != "running" {
		return false
	}
	started, err := time.Parse(time.RFC3339, job.StartedAt)
	return err == nil && now.Sub(started) >= 0 && now.Sub(started) < time.Hour
}

func wbScheduledPrograms(batchID string) (map[string]bool, error) {
	wbMu.Lock()
	defer wbMu.Unlock()
	state, err := wbReadDisk()
	if err != nil {
		return nil, err
	}
	completed := map[string]bool{}
	for _, job := range state.Jobs {
		if job.BatchID != batchID {
			continue
		}
		// A completed authoritative batch is complete regardless of whether it was
		// started manually or by the scheduler. Restricting this check to the
		// scheduler principal caused service restarts to duplicate existing scans.
		if wbScheduledJobComplete(job) || job.Principal == wbSchedulerPrincipal && wbScheduledJobInFlight(job, time.Now()) {
			completed[job.Request.Program] = true
		}
	}
	for _, job := range wbRunning {
		if job.BatchID == batchID && job.Principal == wbSchedulerPrincipal {
			// In-memory means this process owns an active scan; suppress concurrent
			// duplicates even before it reaches a terminal state.
			completed[job.Request.Program] = true
		}
	}
	return completed, nil
}

func wbCreateScheduledJob(request *http.Request, c wbConfig, q wbRequest) (*wbJob, bool, error) {
	if err := validateWBRequest(&q); err != nil {
		return nil, false, err
	}
	rule, ok := c.Rules[q.Program]
	if !ok || !rule.Enabled {
		return nil, false, fmt.Errorf("%s absolute rule disabled or not configured", q.Program)
	}
	policy, policyErr := wbActivePolicy(request.Context())
	if policyErr != nil {
		return nil, false, fmt.Errorf("active risk policy unavailable: %w", policyErr)
	}
	rule.RiskPolicy = policy.VersionLabel // Preserve the legacy rule version used by existing event IDs.
	key := wbKey([]any{wbScope(wbSchedulerPrincipal, q, c), policy.ConfigHash})
	batchID := fmt.Sprintf("TAP-WEEK-%s-%s", q.Start, q.End)
	wbMu.Lock()
	defer wbMu.Unlock()
	for _, job := range wbRunning {
		if job.Principal == wbSchedulerPrincipal && job.ScopeKey == key {
			return job, false, nil
		}
	}
	state, err := wbReadDisk()
	if err != nil {
		return nil, false, err
	}
	for id := range state.Jobs {
		job := state.Jobs[id]
		if job.Principal == wbSchedulerPrincipal && job.ScopeKey == key && (wbScheduledJobComplete(job) || wbScheduledJobInFlight(job, time.Now())) {
			copy := job
			return &copy, false, nil
		}
	}
	now := time.Now().UTC()
	job := &wbJob{ID: uuid.NewString(), BatchID: batchID, AsOf: now.Format(time.RFC3339), RuleVersion: rule.Version, Principal: wbSchedulerPrincipal, ScopeKey: key, Request: q, Rule: rule, Policy: policy, Status: "running", Stage: "loading_members", StartedAt: now.Format(time.RFC3339), Rows: []wbRow{}, Warnings: []string{"周一自动扫描；通知保持 test/dry-run，auto_send=false。"}, MembershipSource: wbMembershipSource(q.Program), RankBy: "advertiser_current_p0_ccr_desc; Top10 display, full details retained"}
	wbRunning[job.ID] = job
	if err := wbSaveJob(job); err != nil {
		delete(wbRunning, job.ID)
		return nil, false, err
	}
	return job, true, nil
}

func wbRunScheduledBatch(now time.Time) {
	c, err := loadWBConfig()
	if err != nil {
		logMsg("[weekly-scheduler] config failed: "+err.Error(), "plugin")
		return
	}
	loc, err := time.LoadLocation(c.Timezone)
	if err != nil {
		logMsg("[weekly-scheduler] timezone failed: "+err.Error(), "plugin")
		return
	}
	start, end := previousCompleteWeekIn(now, loc)
	batchID := fmt.Sprintf("TAP-WEEK-%s-%s", start, end)
	completed, err := wbScheduledPrograms(batchID)
	if err != nil {
		logMsg("[weekly-scheduler] state failed: "+err.Error(), "plugin")
		return
	}
	run, _, reason, err := wbWeeklyScheduleDecisionWithConfig(now, c.Timezone, c.WeeklyScheduler, completed)
	if err != nil || !run {
		if err != nil {
			logMsg("[weekly-scheduler] decision failed: "+err.Error(), "plugin")
		} else if reason == "batch_complete" {
			logMsg("[weekly-scheduler] batch already complete: "+batchID, "plugin")
		}
		return
	}
	ctx := context.WithValue(context.Background(), ctxKeyUser, authResult{Username: wbSchedulerPrincipal, Valid: true, HasAccess: true})
	request, _ := http.NewRequestWithContext(ctx, http.MethodPost, "/internal/weekly-scan", nil)
	for _, program := range []string{"ET", "THT", "ST"} {
		if completed[program] {
			continue
		}
		q := wbRequest{Program: program, Region: "all", Start: start, End: end, MemberStart: "2026-01-01", MemberEnd: end}
		job, created, createErr := wbCreateScheduledJob(request, c, q)
		if createErr != nil {
			logMsg(fmt.Sprintf("[weekly-scheduler] program=%s batch=%s create failed: %v", program, batchID, createErr), "plugin")
			continue
		}
		if created {
			logMsg(fmt.Sprintf("[weekly-scheduler] program=%s batch=%s scan_id=%s started", program, batchID, job.ID), "plugin")
			go wbRunJob(request.Clone(ctx), job.ID, c)
		}
	}
	go wbGenerateETQuotaAlerts(ctx, request, start, end)
}

func wbStartWeeklyScheduler() {
	go func() {
		// Check shortly after startup, then every minute. The decision function only
		// permits Monday and persisted batch/program keys make retries idempotent.
		timer := time.NewTimer(5 * time.Second)
		defer timer.Stop()
		<-timer.C
		wbRunScheduledBatch(time.Now())
		ticker := time.NewTicker(time.Minute)
		defer ticker.Stop()
		for now := range ticker.C {
			wbRunScheduledBatch(now)
		}
	}()
}

func calendarQuarter(t time.Time) (string, string) {
	month := int(t.Month())
	quarter := (month-1)/3 + 1
	startMonth := time.Month((quarter-1)*3 + 1)
	start := time.Date(t.Year(), startMonth, 1, 0, 0, 0, 0, t.Location())
	return fmt.Sprintf("Q%d", quarter), start.Format("2006-01-02")
}

type wbQuotaExcess struct {
	Region string
	Used   int
	Quota  int
	Ratio  float64
}

func etQuotaExcesses(baseline quotaBaseline, source quotaSourceResult) []wbQuotaExcess {
	if source.SourceStatus["ET"] != "available" {
		return nil
	}
	result := aggregateQuota(baseline, source, "")
	regions, _ := result["regions"].([]map[string]any)
	out := []wbQuotaExcess{}
	for _, region := range regions {
		et, _ := region["et"].(map[string]any)
		ratio, ok := et["ratio"].(float64)
		if !ok || !quotaAlertTriggered("ET", &ratio) {
			continue
		}
		used, usedOK := et["used"].(int)
		quota, quotaOK := et["quota"].(int)
		if usedOK && quotaOK && quota > 0 {
			out = append(out, wbQuotaExcess{Region: asString(region["region"]), Used: used, Quota: quota, Ratio: ratio})
		}
	}
	return out
}

func wbGenerateETQuotaAlerts(ctx context.Context, request *http.Request, start, end string) {
	baseline, err := loadQuotaBaseline()
	if err != nil {
		logMsg("[quota-alert] baseline failed: "+err.Error(), "plugin")
		return
	}
	endTime, _ := time.ParseInLocation("2006-01-02", end, cwLocation())
	quarter, quarterStart := calendarQuarter(endTime)
	source := loadQuotaSources(ctx, request, quarter, quarterStart, end)
	for _, program := range []string{"ET", "ST"} {
		for _, excess := range wbProgramQuotaExcesses(baseline, source, program) {
			if _, err := cwCreateProgramQuotaAlert(program, quarter, start, end, excess); err != nil {
				logMsg(fmt.Sprintf("[quota-alert] %s region=%s persist failed: %v", program, excess.Region, err), "plugin")
			}
		}
	}
}

func cwCreateQuotaAlert(quarter, start, end string, excess wbQuotaExcess) (cwCase, error) {
	return cwCreateProgramQuotaAlert("ET", quarter, start, end, excess)
}
func cwCreateProgramQuotaAlert(program, quarter, start, end string, excess wbQuotaExcess) (cwCase, error) {
	if program != "ET" && program != "ST" {
		return cwCase{}, fmt.Errorf("unsupported quota program")
	}
	cfg, err := cwLoadConfig()
	if err != nil {
		return cwCase{}, err
	}
	id := "TAP-QUOTA-" + wbKey([]string{program, excess.Region, quarter, quotaThresholdVersion})[:24]
	reason := fmt.Sprintf("%s Region quota reached threshold: %.2f%% (%d/%d)", program, excess.Ratio, excess.Used, excess.Quota)
	row := wbRow{ID: id, Program: program, Member: wbMember{Region: excess.Region, Tier: program, MetadataStatus: "ready"}, Level: "critical", Reasons: []string{reason}, MetricStatus: "success", DataStatus: "Success", Message: reason, RecipientStatus: "pending_regional_poc"}
	now := cwNow()
	fields := map[string]string{"quarter": quarter, "used": fmt.Sprint(excess.Used), "quota": fmt.Sprint(excess.Quota), "ratio": fmt.Sprintf("%.6f", excess.Ratio), "batch_id": fmt.Sprintf("TAP-WEEK-%s-%s", start, end), "threshold_version": quotaThresholdVersion, "candidate_status": "pending_regional_poc", "regional_poc_status": "pending_regional_poc", "notification_source": "auto", "notification_mode": "test", "notification_result": "pending_regional_poc"}
	item := cwCase{ID: id, Kind: "quota", Version: 1, Status: "open", Creator: wbSchedulerPrincipal, Owner: wbSchedulerPrincipal, CreatedAt: now, UpdatedAt: now, ScanID: fmt.Sprintf("TAP-WEEK-%s-%s", start, end), Row: row, Window: wbRequest{Program: program, Region: excess.Region, Start: start, End: end}, WorkflowVersion: cfg.Version, Fields: fields, History: []cwAudit{{ID: "create", At: now, Actor: wbSchedulerPrincipal, Source: "quota", Operation: "create", Status: "open", Version: 1, Note: reason}}}
	cwEnsureNotificationDeadline(&item)
	db, err := cwDB()
	if err != nil {
		return cwCase{}, err
	}
	defer db.Close()
	pocs, revision, mappingErr := cwLoadRegionalPOCsForQuota(context.Background())
	keys := cwRegionalPOCKeys(excess.Region)
	var poc cwRegionalPOC
	mapped := false
	for _, key := range keys {
		if candidate, ok := pocs[key]; ok {
			poc, mapped = candidate, true
			break
		}
	}
	outboxStatus, outboxError := "blocked", "missing_regional_poc"
	if mappingErr != nil {
		outboxError = "regional_poc_mapping_unavailable"
	} else if mapped {
		outboxStatus, outboxError = "ready", ""
		item.Row.RecipientStatus = "ready_in_test_mode"
		item.Fields["candidate_status"] = "ready_in_test_mode"
		item.Fields["regional_poc_status"] = "mapped"
		item.Fields["regional_poc_name"] = poc.Name
		item.Fields["regional_poc_email"] = poc.Email
		item.Fields["notification_result"] = "ready_in_test_mode"
	} else {
		item.Row.RecipientStatus = "blocked_missing_poc"
		item.Fields["candidate_status"] = "blocked_missing_poc"
		item.Fields["regional_poc_status"] = "missing"
		item.Fields["notification_result"] = "blocked_missing_poc"
	}
	if mapped {
		item.Row.Member.Submitter = poc.Name
		item.Owner = strings.SplitN(poc.Email, "@", 2)[0]
	}
	repo, repoErr := cwCaseworkRepositoryProvider()
	if repoErr != nil {
		return cwCase{}, repoErr
	}
	// Create in the same Cloud authority used by deep links, preview and tagging.
	persisted, createErr := repo.createCase(context.Background(), item)
	if createErr != nil {
		return cwCase{}, createErr
	}
	item = persisted
	body, _ := json.Marshal(item)
	if _, err = db.Exec("INSERT OR IGNORE INTO tap_cases(id,version,body) VALUES(?,?,?)", item.ID, 1, string(body)); err != nil {
		return cwCase{}, err
	}
	idempotency := wbKey([]string{"quota-notification", quarter, program, excess.Region, quotaThresholdVersion})
	recipient := ""
	if mapped {
		recipient = "email:" + poc.Email
	}
	_, err = db.Exec(`INSERT OR IGNORE INTO tap_outbox(id,case_id,recipient,kind,status,notification_mode,idempotency_key,alert_region,mapping_revision,target_email,source,mode,batch_id,rule_version,result,error,created_at,updated_at) VALUES(?,?,?,'send',?,'test',?,?,?,?, 'auto','test',?,?,?, ?,?,?)`, "quota-"+idempotency[:24], item.ID, recipient, outboxStatus, idempotency, excess.Region, revision, poc.Email, item.Fields["batch_id"], quotaThresholdVersion, item.Fields["notification_result"], outboxError, now, now)
	if err != nil {
		return cwCase{}, err
	}
	return cwRead(db, id)
}
