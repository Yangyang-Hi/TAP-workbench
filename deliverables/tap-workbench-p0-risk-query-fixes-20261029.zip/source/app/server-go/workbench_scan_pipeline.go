package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type wbCorePhaseKey struct{}
type wbCurrentWindowKey struct{}
type wbMetricWindow struct {
	Start string `json:"start_date"`
	End   string `json:"end_date"`
}

func wbCoreOnly(ctx context.Context) bool { v, _ := ctx.Value(wbCorePhaseKey{}).(bool); return v }

// The scan week remains the event identity. Absolute rules use QTD through that
// week's end; neither enrichment nor retries may silently use today's quarter.
func wbCurrentWindow(q wbRequest) wbMetricWindow {
	t, e := time.ParseInLocation("2006-01-02", q.End, cwLocation())
	if e != nil {
		return wbMetricWindow{q.Start, q.End}
	}
	_, start := calendarQuarter(t)
	return wbMetricWindow{start, q.End}
}
func wbMetricDates(ctx context.Context, q wbRequest) (string, string) {
	if w, ok := ctx.Value(wbCurrentWindowKey{}).(wbMetricWindow); ok {
		return w.Start, w.End
	}
	return q.Start, q.End
}

// Persist the complete authoritative decision before optional enrichment. The
// caller retains every candidate and every ID; only detail-query indices shrink.
func wbRiskEnrichmentIndices(rows []wbRow) []int {
	out := []int{}
	for i, r := range rows {
		if wbMatched(r) {
			out = append(out, i)
		}
	}
	return out
}

var wbScanAccountDetailQuery = queryAccountCurrentBatch

func wbEnrichScanRisks(ctx context.Context, request *http.Request, rows []wbRow, q wbRequest, rule wbRule) ([]wbRow, error) {
	out := append([]wbRow(nil), rows...)
	indices := wbRiskEnrichmentIndices(out)
	// The saved checkpoint can be polled concurrently. Clone only risk details
	// before enrichment so Source maps/evidence slices are never mutated in place.
	for _, i := range indices {
		raw, err := json.Marshal(out[i])
		if err != nil {
			return out, err
		}
		var clone wbRow
		if err = json.Unmarshal(raw, &clone); err != nil {
			return out, err
		}
		out[i] = clone
	}
	if len(indices) == 0 {
		return out, nil
	}
	// Enrichment receives its own flag but exactly the same current window.
	ctx = context.WithValue(ctx, wbCorePhaseKey{}, false)
	request = request.Clone(ctx)
	start, end := wbMetricDates(ctx, q)
	detailQ := q
	detailQ.Start, detailQ.End = start, end
	members := []wbMember{}
	for _, i := range indices {
		members = append(members, out[i].Member)
	}
	if q.Program == "THT" {
		ids := []string{}
		for _, m := range members {
			ids = append(ids, m.AdvertiserID)
		}
		for _, chunk := range chunkIDs(uniqueNonEmpty(ids), wbTHTMetricChunkSize) {
			metrics, err := wbQueryTHTBatch(ctx, request, chunk, start, end)
			if err != nil {
				return out, err
			}
			for _, i := range indices {
				for _, m := range metrics[out[i].Member.AdvertiserID] {
					if m.AccountID != out[i].Member.AccountID {
						continue
					}
					if out[i].Revenue == nil {
						out[i].Revenue = m.Revenue
					}
					for j := range out[i].Advertisers {
						adv := &out[i].Advertisers[j]
						if adv.AccountID == m.AccountID {
							if adv.Revenue == nil {
								adv.Revenue = m.Revenue
							}
							adv.RevenueStatus = m.RevenueStatus
							adv.ReportedReasons = m.ReportedReasons
						}
					}
					out[i].AdvertiserTop10 = topAdvertisers(out[i].Advertisers, 10)
				}
			}
		}
		return out, nil
	}
	// Account revenue remains Account-grain; Pair revenue never replaces it.
	ids := []string{}
	for _, m := range members {
		ids = append(ids, m.AccountID)
	}
	source := "et_current_ccr_nfs"
	if q.Program == "ST" {
		source = "st_current_ccr_nfs"
	}
	var detailErr error
	for _, chunk := range chunkIDs(uniqueNonEmpty(ids), wbETMetricChunkSize) {
		metrics, err := wbScanAccountDetailQuery(ctx, request, chunk, start, end, source, q.Program)
		if err != nil {
			detailErr = err
			continue
		}
		for _, i := range indices {
			if m, ok := metrics[out[i].Member.AccountID]; ok {
				if out[i].Revenue == nil {
					out[i].Revenue = m.Revenue
				}
				if src, ok := out[i].Source.(map[string]any); ok {
					src["revenue"] = map[string]any{"source": "account_current_revenue", "authority": "saved_report", "grain": "account_week", "window": wbMetricWindow{start, end}, "status": m.RevenueStatus, "request_id": m.RevenueRequestID, "log_id": m.RevenueLogID}
				}
			}
		}
	}
	evidence, err := wbQueryPairEvidence(ctx, request, members, detailQ, rule)
	if err != nil {
		return out, err
	}
	selected := make([]wbRow, 0, len(indices))
	for _, i := range indices {
		selected = append(selected, out[i])
	}
	selected = applyPairEvidence(selected, evidence, detailQ, rule)
	for k, i := range indices { // Pair details cannot change an already saved decision.
		selected[k].CCR, selected[k].NFS = out[i].CCR, out[i].NFS
		selected[k].Comparison, selected[k].Level, selected[k].Reasons = out[i].Comparison, out[i].Level, out[i].Reasons
		out[i] = selected[k]
	}
	return out, detailErr
}

// Dedicated local scan archive; unrelated Case/Outbox tables are not modified.
func wbScanArchiveDB() (*sql.DB, error) {
	dir, e := resolveDataDir()
	if e != nil {
		return nil, e
	}
	if e = os.MkdirAll(dir, 0700); e != nil {
		return nil, e
	}
	db, e := sql.Open("sqlite", filepath.Join(dir, "tap_scan_history.db"))
	if e != nil {
		return nil, e
	}
	db.SetMaxOpenConns(1)
	_, e = db.Exec(`PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL;
 CREATE TABLE IF NOT EXISTS tap_scan_jobs(id TEXT PRIMARY KEY,batch_id TEXT NOT NULL,program TEXT NOT NULL,body TEXT NOT NULL);
 CREATE INDEX IF NOT EXISTS tap_scan_jobs_batch ON tap_scan_jobs(batch_id,program);`)
	if e != nil {
		db.Close()
		return nil, e
	}
	return db, nil
}
func wbArchiveState(state wbDisk) error {
	db, e := wbScanArchiveDB()
	if e != nil {
		return e
	}
	defer db.Close()
	tx, e := db.Begin()
	if e != nil {
		return e
	}
	defer tx.Rollback()
	statement, e := tx.Prepare(`INSERT INTO tap_scan_jobs(id,batch_id,program,body) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET batch_id=excluded.batch_id,program=excluded.program,body=excluded.body WHERE body!=excluded.body`)
	if e != nil {
		return e
	}
	defer statement.Close()
	for _, job := range state.Jobs {
		body, err := json.Marshal(job)
		if err != nil {
			return err
		}
		if _, err = statement.Exec(job.ID, job.BatchID, job.Request.Program, string(body)); err != nil {
			return err
		}
	}
	return tx.Commit()
}
func wbReadScanArchive() (map[string]wbJob, error) {
	out := map[string]wbJob{}
	db, e := wbScanArchiveDB()
	if e != nil {
		return nil, e
	}
	defer db.Close()
	var exists int
	if e = db.QueryRow("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='tap_scan_jobs'").Scan(&exists); e != nil || exists == 0 {
		return out, e
	}
	rows, e := db.Query("SELECT body FROM tap_scan_jobs")
	if e != nil {
		return nil, e
	}
	defer rows.Close()
	for rows.Next() {
		var raw string
		if e = rows.Scan(&raw); e != nil {
			return nil, e
		}
		var j wbJob
		if e = json.Unmarshal([]byte(raw), &j); e != nil {
			return nil, fmt.Errorf("scan archive: %w", e)
		}
		out[j.ID] = j
	}
	return out, rows.Err()
}
func wbCurrentScopeNote(q wbRequest) string {
	w := wbCurrentWindow(q)
	return strings.Join([]string{"absolute_current_qtd", w.Start, w.End}, ":")
}

func wbProgramQuotaExcesses(baseline quotaBaseline, source quotaSourceResult, program string) []wbQuotaExcess {
	if source.SourceStatus[program] != "available" {
		return nil
	}
	result := aggregateQuota(baseline, source, "")
	regions, _ := result["regions"].([]map[string]any)
	out := []wbQuotaExcess{}
	for _, row := range regions {
		item, _ := row[strings.ToLower(program)].(map[string]any)
		ratio, ok := item["ratio"].(float64)
		if !ok || !quotaAlertTriggered(program, &ratio) || item["complete"] == false {
			continue
		}
		used := int(asInt64(item["used"]))
		quota := int(asInt64(item["quota"]))
		if quota <= 0 {
			continue
		}
		out = append(out, wbQuotaExcess{Region: asString(row["region"]), Used: used, Quota: quota, Ratio: ratio})
	}
	return out
}

func wbStoredMetricQuery(rows []wbRow, q wbRequest) (wbRequest, error) {
	var window *wbMetricWindow
	for _, row := range rows {
		if row.CurrentWindow == nil {
			continue
		}
		if window != nil && *window != *row.CurrentWindow {
			return q, fmt.Errorf("mixed_current_metric_windows_require_separate_repair")
		}
		window = row.CurrentWindow
	}
	if window != nil {
		for _, row := range rows {
			if row.CurrentWindow == nil {
				return q, fmt.Errorf("legacy_and_qtd_windows_require_separate_repair")
			}
		}
		q.Start, q.End = window.Start, window.End
	}
	return q, nil
}

func wbInheritMetricWindow(fresh, prior []wbRow) {
	for _, r := range prior {
		if r.CurrentWindow != nil {
			for i := range fresh {
				w := *r.CurrentWindow
				fresh[i].CurrentWindow = &w
			}
			return
		}
	}
}
