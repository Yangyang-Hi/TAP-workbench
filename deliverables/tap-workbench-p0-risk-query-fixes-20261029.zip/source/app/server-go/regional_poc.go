package main

import (
	"context"
	"database/sql"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"
)

const cwRegionalPOCSheetID = "9zaKsD"

type cwRegionalPOC struct {
	Region string `json:"region"`
	Name   string `json:"name"`
	Email  string `json:"email"`
}

var cwRegionalPOCCache struct {
	sync.Mutex
	Rows      map[string]cwRegionalPOC
	Revision  string
	FetchedAt time.Time
}

func cwRegionalPOCKeys(region string) []string {
	r := strings.ToUpper(strings.TrimSpace(region))
	switch r {
	case "KR+JP", "KR / JP", "KR&JP":
		return []string{"KR", "JP"}
	case "MET":
		return []string{"MET", "METAP"}
	case "SCALED GROWTH AGENCY", "SGA":
		return []string{"SCALED GROWTH AGENCY"}
	default:
		return []string{r}
	}
}

func cwLoadRegionalPOCs(ctx context.Context) (map[string]cwRegionalPOC, string, error) {
	cwRegionalPOCCache.Lock()
	defer cwRegionalPOCCache.Unlock()
	if len(cwRegionalPOCCache.Rows) > 0 && time.Since(cwRegionalPOCCache.FetchedAt) < 5*time.Minute {
		return cwRegionalPOCCache.Rows, cwRegionalPOCCache.Revision, nil
	}
	token, err := cwAccessToken(ctx)
	if err != nil {
		return nil, "", fmt.Errorf("regional_poc_refresh_failed: bot credentials: %w", err)
	}
	sheetRange := cwRegionalPOCSheetID + "!A1:C200"
	path := "/open-apis/sheets/v2/spreadsheets/" + cwMappingSheetToken + "/values/" + url.PathEscape(sheetRange)
	out, err := cwHTTP(ctx, http.MethodGet, path, token, nil)
	if err != nil {
		return nil, "", fmt.Errorf("regional_poc_refresh_failed: sheet read: %w", err)
	}
	data, _ := out["data"].(map[string]any)
	valueRange, _ := data["valueRange"].(map[string]any)
	values, _ := valueRange["values"].([]any)
	if len(values) == 0 {
		values, _ = data["values"].([]any)
	}
	rows := make([][]string, 0, len(values))
	for _, raw := range values {
		items, _ := raw.([]any)
		row := make([]string, len(items))
		for i, item := range items {
			row[i] = strings.TrimSpace(asString(item))
		}
		rows = append(rows, row)
	}
	if len(rows) < 2 || strings.TrimSpace(cwCell(rows[0], 0)) != "Region" || strings.TrimSpace(cwCell(rows[0], 1)) != "姓名" || strings.TrimSpace(cwCell(rows[0], 2)) != "企业邮箱" {
		return nil, "", fmt.Errorf("regional_poc_refresh_failed: unexpected sheet headers")
	}
	mapped := map[string]cwRegionalPOC{}
	for _, row := range rows[1:] {
		region, name, email := cwCell(row, 0), cwCell(row, 1), strings.ToLower(cwCell(row, 2))
		if region == "" && name == "" && email == "" {
			continue
		}
		if region == "" || name == "" || email == "" {
			return nil, "", fmt.Errorf("regional_poc_refresh_failed: incomplete row for region %q", region)
		}
		if !strings.Contains(email, "@") || strings.HasPrefix(email, "@") || strings.HasSuffix(email, "@") {
			return nil, "", fmt.Errorf("regional_poc_refresh_failed: invalid email for region %q", region)
		}
		poc := cwRegionalPOC{Region: region, Name: name, Email: email}
		for _, key := range cwRegionalPOCKeys(region) {
			if _, exists := mapped[key]; exists {
				return nil, "", fmt.Errorf("regional_poc_refresh_failed: duplicate region mapping %q", key)
			}
			mapped[key] = poc
		}
	}
	revision := strings.TrimSpace(cwParseRevision(data["revision"]))
	if revision == "" {
		revision = strings.TrimSpace(cwParseRevision(out["revision"]))
	}
	cwRegionalPOCCache.Rows, cwRegionalPOCCache.Revision, cwRegionalPOCCache.FetchedAt = mapped, revision, time.Now()
	return mapped, revision, nil
}

var cwLoadRegionalPOCsForQuota = cwLoadRegionalPOCs

func cwDecorateQuotaRegionalPOCs(ctx context.Context, data map[string]any) {
	pocs, revision, err := cwLoadRegionalPOCsForQuota(ctx)
	if err != nil {
		data["regional_poc_status"] = "unavailable"
		data["regional_poc_error"] = err.Error()
		return
	}
	data["regional_poc_status"] = "available"
	data["regional_poc_revision"] = revision
	regions, _ := data["regions"].([]map[string]any)
	for _, row := range regions {
		key := strings.ToUpper(strings.TrimSpace(asString(row["region"])))
		if poc, ok := pocs[key]; ok {
			row["regional_poc"] = poc.Name
			row["regional_poc_email"] = poc.Email
			row["regional_poc_status"] = "mapped"
		} else {
			row["regional_poc"] = nil
			row["regional_poc_email"] = nil
			row["regional_poc_status"] = "unmapped"
		}
	}
}

// Customer recipients retain the exact existing resolver. Quota cases resolve
// the authoritative Region POC at preview AND both send-time checks.
func cwResolveCaseMapping(ctx context.Context, db *sql.DB, item cwCase) (cwMappingResolution, error) {
	if item.Kind != "quota" {
		return cwResolveMapping(db, item.Row.Member.Submitter, item.Row.Member.Region)
	}
	// Recipient checks must read fresh POCs; the UI-only five-minute cache
	// cannot authorize a delivery after an assignment has changed.
	cwRegionalPOCCache.Lock()
	cwRegionalPOCCache.FetchedAt = time.Time{}
	cwRegionalPOCCache.Unlock()
	rows, revision, err := cwLoadRegionalPOCsForQuota(ctx)
	if err != nil {
		return cwMappingResolution{Status: "unavailable", Reason: "regional_poc_mapping_unavailable"}, err
	}
	var poc cwRegionalPOC
	found := false
	for _, key := range cwRegionalPOCKeys(item.Row.Member.Region) {
		if p, ok := rows[key]; ok {
			if found && !strings.EqualFold(strings.TrimSpace(poc.Email), strings.TrimSpace(p.Email)) {
				return cwMappingResolution{Status: "conflict", Reason: "multiple_regional_pocs"}, nil
			}
			poc, found = p, true
		}
	}
	if !found {
		return cwMappingResolution{Status: "blocked", Reason: "missing_regional_poc"}, nil
	}
	email, valid := cwExactEmail(poc.Email)
	if !valid {
		return cwMappingResolution{Status: "blocked", Reason: "invalid_regional_poc_email"}, nil
	}
	version := wbKey([]string{revision, poc.Region, poc.Name, email})
	mapping := cwIdentityMapping{RecordID: "regional-poc-" + strings.ToUpper(item.Row.Member.Region), Region: poc.Region, BusinessName: poc.Name, AeolusName: poc.Name, Email: email, MatchStatus: "已确认", Enabled: true, SheetToken: cwMappingSheetToken, SheetID: cwRegionalPOCSheetID, SheetRevision: revision, RecordVersion: version}
	return cwMappingResolution{Status: "matched", Reason: "authoritative_regional_poc", Mapping: &mapping, MatchedAlias: poc.Name}, nil
}

// Read actual Cloud case/notice evidence, never turn a displayed POC into proof
// of enqueueing or delivery. GET does not create cases or notifications.
func cwDecorateQuotaNotificationState(ctx context.Context, data map[string]any) {
	regions, _ := data["regions"].([]map[string]any)
	for _, row := range regions {
		for _, program := range []string{"et", "st"} {
			if metric, ok := row[program].(map[string]any); ok {
				metric["notification_status"] = "unknown"
			}
		}
	}
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		data["quota_notice_status"] = "unavailable"
		return
	}
	cases, err := repo.listCases(ctx)
	if err != nil {
		data["quota_notice_status"] = "unavailable"
		return
	}
	notices, err := repo.listNotices(ctx)
	if err != nil {
		data["quota_notice_status"] = "unavailable"
		return
	}
	byCase := map[string][]cwNotice{}
	for _, n := range notices {
		if n.NotificationMode == "formal" || n.Mode == "formal" {
			byCase[n.CaseID] = append(byCase[n.CaseID], n)
		}
	}
	quarter := asString(data["quarter"])
	for _, row := range regions {
		for _, program := range []string{"ET", "ST"} {
			metric, _ := row[strings.ToLower(program)].(map[string]any)
			if metric == nil {
				continue
			}
			metric["notification_status"] = "not_created"
			for _, item := range cases {
				if item.Kind != "quota" || item.Row.Program != program || !strings.EqualFold(item.Row.Member.Region, asString(row["region"])) || item.Fields["quarter"] != quarter {
					continue
				}
				metric["alert_id"] = item.ID
				status := wbNotificationStatus(byCase[item.ID])
				if status == "not_sent" {
					status = "awaiting_confirmation"
				}
				metric["notification_status"] = status
				break
			}
		}
	}
	data["quota_notice_status"] = "available"
}
