package main

import (
	"context"
	"errors"
	"fmt"
	"math"
	"net/http"
	"strings"
	"time"
)

const wbETMetricChunkSize = defaultIDBatchSize

type wbBatchMetric struct {
	Status           string
	CCR              *float64
	NFS              *float64
	Revenue          *float64
	RevenueStatus    string
	RevenueError     string
	RevenueRequestID string
	RevenueLogID     string
	AccountID        string
	AdvertiserID     string
	Region           string
	Source           any
	QueriedAt        string
	RequestID        string
	LogID            string
	Message          string
	SemanticsLabel   string
	SemanticsStatus  string
	ReportedReasons  []reportedReason
}

var wbQueryETBatch = queryETCurrentBatch
var accountVQSProbe = runTitanVQSProbe

// queryETCurrentBatch reads the authoritative Account-grain CCR/NFS and Revenue
// Saved Reports. Advertiser reports are intentionally queried elsewhere only as
// expandable evidence and never overwrite these values.
func queryETCurrentBatch(ctx context.Context, request *http.Request, ids []string, startDate, endDate string) (map[string]wbBatchMetric, error) {
	return queryAccountCurrentBatch(ctx, request, ids, startDate, endDate, "et_current_ccr_nfs", "ET")
}

func queryAccountCurrentBatch(ctx context.Context, request *http.Request, ids []string, startDate, endDate, metricSource, program string) (map[string]wbBatchMetric, error) {
	ids = uniqueNonEmpty(ids)
	if len(ids) == 0 {
		return map[string]wbBatchMetric{}, nil
	}
	for _, id := range ids {
		if !decimalID.MatchString(id) {
			return nil, fmt.Errorf("invalid %s account_id %q", program, id)
		}
	}

	makeRequest := func() *http.Request {
		u := *request.URL
		r := request.Clone(ctx)
		r.URL = &u
		query := u.Query()
		query.Set("start_date", startDate)
		query.Set("end_date", endDate)
		query.Set("client_ids", strings.Join(ids, ","))
		query.Set("id_dimension", "account_id")
		r.URL.RawQuery = query.Encode()
		r.Header = request.Header.Clone()
		r.Header.Set("X-TAP-Allow-Missing-IDs", "1")
		return r
	}

	type probeResult struct {
		name  string
		probe map[string]any
		err   error
	}
	sourceNames := []string{metricSource, "account_current_revenue"}
	if wbCoreOnly(ctx) {
		sourceNames = sourceNames[:1]
	}
	results := make(chan probeResult, len(sourceNames))
	for _, sourceName := range sourceNames {
		sourceName := sourceName
		go func() {
			probe, err := accountVQSProbe(ctx, makeRequest(), sourceName)
			results <- probeResult{name: sourceName, probe: probe, err: err}
		}()
	}
	var probe, revenueProbe map[string]any
	var metricErr, revenueErr error
	for i := 0; i < len(sourceNames); i++ {
		result := <-results
		if result.name == metricSource {
			probe, metricErr = result.probe, result.err
		} else {
			revenueProbe, revenueErr = result.probe, result.err
		}
	}
	if metricErr != nil {
		return nil, metricErr
	}
	if asString(probe["status"]) != "ok" {
		return nil, accountProbeError(program+" Account CCR/NFS", probe)
	}
	if truncated, _ := probe["possibly_truncated"].(bool); truncated {
		return nil, fmt.Errorf("%s Account CCR/NFS result reached the hard limit; refusing silent truncation", program)
	}

	rows, _ := probe["business_rows"].([]map[string]any)
	wanted := make(map[string]bool, len(ids))
	out := make(map[string]wbBatchMetric, len(ids))
	for _, id := range ids {
		wanted[id] = true
		out[id] = wbBatchMetric{Status: "no_data", RevenueStatus: "no_data", Source: accountMetricSource(metricSource, probe, nil), QueriedAt: asString(probe["queriedAt"]), RequestID: asString(probe["requestId"]), LogID: asString(probe["logId"]), Message: "该 Account ID 在所选日期范围内没有返回权威 Account 事实行"}
	}
	for _, row := range rows {
		id := strings.TrimSpace(asString(row["account_id"]))
		if id == "" || !wanted[id] {
			return nil, fmt.Errorf("%s Account CCR/NFS returned an unrequested or empty account_id %q", program, id)
		}
		if out[id].Status == "success" {
			return nil, fmt.Errorf("%s Account CCR/NFS grain contract failed: account_id %s returned multiple rows", program, id)
		}
		ccr, metricErr := strictWBMetric(row["dynamic_p0_ccr"])
		if metricErr != nil {
			return nil, fmt.Errorf("account_id %s has invalid dynamic_p0_ccr: %w", id, metricErr)
		}
		nfs, metricErr := strictWBMetric(row["p0_nfs"])
		if metricErr != nil {
			return nil, fmt.Errorf("account_id %s has invalid p0_nfs: %w", id, metricErr)
		}
		out[id] = wbBatchMetric{Status: "success", CCR: ccr, NFS: nfs, RevenueStatus: "no_data", Source: accountMetricSource(metricSource, probe, nil), QueriedAt: asString(probe["queriedAt"]), RequestID: asString(probe["requestId"]), LogID: asString(probe["logId"]), Message: "authoritative Account-grain metrics"}
	}

	if wbCoreOnly(ctx) {
		return out, nil
	}
	if revenueErr != nil || asString(revenueProbe["status"]) != "ok" {
		revenueMessage := ""
		if revenueErr != nil {
			revenueMessage = sanitizeLogText(revenueErr.Error())
		} else {
			revenueMessage = sanitizeLogText(accountProbeError(program+" Account Revenue", revenueProbe).Error())
		}
		for id, metric := range out {
			metric.RevenueStatus = "source_error"
			metric.RevenueError = revenueMessage
			metric.RevenueRequestID, metric.RevenueLogID = asString(revenueProbe["requestId"]), asString(revenueProbe["logId"])
			out[id] = metric
		}
		return out, nil
	}
	if truncated, _ := revenueProbe["possibly_truncated"].(bool); truncated {
		for id, metric := range out {
			metric.RevenueStatus = "partial_rejected"
			metric.RevenueError = program + " Account Revenue result reached the hard limit; result rejected"
			metric.RevenueRequestID, metric.RevenueLogID = asString(revenueProbe["requestId"]), asString(revenueProbe["logId"])
			out[id] = metric
		}
		return out, nil
	}
	for _, row := range mustBusinessRows(revenueProbe) {
		id := strings.TrimSpace(asString(row["account_id"]))
		if id == "" || !wanted[id] {
			return nil, fmt.Errorf("%s Account Revenue returned an unrequested or empty account_id %q", program, id)
		}
		metric := out[id]
		if metric.RevenueStatus == "success" {
			return nil, fmt.Errorf("%s Account Revenue grain contract failed: account_id %s returned multiple rows", program, id)
		}
		value, valueErr := strictWBMetric(row["revenue"])
		if valueErr != nil {
			return nil, fmt.Errorf("account_id %s has invalid revenue: %w", id, valueErr)
		}
		metric.Revenue, metric.RevenueStatus = value, "success"
		metric.RevenueRequestID, metric.RevenueLogID = asString(revenueProbe["requestId"]), asString(revenueProbe["logId"])
		out[id] = metric
	}
	for id, metric := range out {
		metric.Source = accountMetricSource(metricSource, probe, revenueProbe)
		if source, ok := metric.Source.(map[string]any); ok {
			if revenueSource, ok := source["revenue"].(map[string]any); ok {
				revenueSource["status"] = metric.RevenueStatus
				revenueSource["error"] = metric.RevenueError
			}
		}
		out[id] = metric
	}
	return out, nil
}

func mustBusinessRows(probe map[string]any) []map[string]any {
	rows, _ := probe["business_rows"].([]map[string]any)
	if rows == nil {
		return []map[string]any{}
	}
	return rows
}

func accountMetricSource(name string, metricProbe, revenueProbe map[string]any) map[string]any {
	source := map[string]any{"source": name, "rid": metricProbe["report_id"], "sid": metricProbe["dataset_id"], "grain": "account_week", "authority": "saved_report", "request_id": metricProbe["requestId"], "log_id": metricProbe["logId"]}
	if revenueProbe != nil {
		source["revenue"] = map[string]any{"source": "account_current_revenue", "rid": revenueProbe["report_id"], "sid": revenueProbe["dataset_id"], "grain": "account_week", "authority": "saved_report", "request_id": revenueProbe["requestId"], "log_id": revenueProbe["logId"]}
	}
	return source
}

func accountProbeError(label string, probe map[string]any) error {
	detail := ""
	if step, ok := probe["query_result"].(titanProbeStep); ok {
		detail = fmt.Sprintf(" error_type=%s message=%s glue_message=%s", step.ErrorType, step.ErrorMessage, step.GlueMessage)
	}
	if filterError := asString(probe["filter_error"]); filterError != "" {
		detail += " filter_error=" + filterError
	}
	if filters := probe["effective_filters"]; filters != nil {
		detail += fmt.Sprintf(" effective_filters=%v", filters)
	}
	if partition := probe["partition"]; partition != nil {
		detail += fmt.Sprintf(" partition=%v", partition)
	}
	return wbProbeQueryError(label, probe, detail)
}

func strictWBMetric(value any) (*float64, error) {
	if value == nil || strings.EqualFold(strings.TrimSpace(asString(value)), "NULL") || strings.TrimSpace(asString(value)) == "" {
		return nil, nil
	}
	n, ok := number(value)
	if !ok || math.IsNaN(n) || math.IsInf(n, 0) || n < 0 {
		return nil, errors.New("metric must be a finite nonnegative number or NULL")
	}
	return &n, nil
}

func wbRowsFromETBatch(members []wbMember, metrics map[string]wbBatchMetric, q wbRequest, rule wbRule) ([]wbRow, error) {
	rows := make([]wbRow, 0, len(members))
	for _, member := range members {
		metric, ok := metrics[member.AccountID]
		if !ok {
			return nil, fmt.Errorf("ET batch result missing mapping for account_id %s", member.AccountID)
		}
		// Membership metadata remains authoritative. Account-based tiers do not
		// expose an advertiser_id that is absent from their membership contract.
		if member.Region == "" {
			member.Region = metric.Region
		}
		row := wbRow{Program: q.Program, Member: member, CCR: metric.CCR, NFS: metric.NFS, Revenue: metric.Revenue, MetricStatus: metric.Status, Reasons: []string{}, Level: "unavailable", AllowlistStatus: "Unknown", DataStatus: "No Fact", RecipientStatus: "pending_confirmation", Source: metric.Source, QueriedAt: metric.QueriedAt, RequestID: metric.RequestID}
		if q.Program != "THT" && metric.Status == "success" {
			row.AccountCCRStatus = "权威 Account 粒度（Saved Report RID 2979783；Revenue RID 2980054）"
		}
		row.ID = wbKey([]string{q.Program, member.AccountID, member.TicketID, q.Start, q.End, rule.Version})[:24]
		switch metric.Status {
		case "success":
			row.DataStatus = "Success"
			row.Level, row.Reasons = evaluateWBAbsolute(row.CCR, row.NFS, rule)
			if row.CCR == nil || row.NFS == nil {
				row.DataStatus = "Partial Fact"
			}
		case "no_data":
			row.Error = metric.Message
		default:
			return nil, fmt.Errorf("account_id %s has unexpected batch status %q", member.AccountID, metric.Status)
		}
		if member.Submitter != "" {
			row.RecipientStatus = "submitter_available_identity_unverified"
		}
		row.Message = wbMessage(row, q, rule)
		rows = append(rows, row)
	}
	return rows, nil
}

func wbRunETBatches(ctx context.Context, request *http.Request, members []wbMember, q wbRequest, rule wbRule) ([]wbRow, int, error) {
	return wbRunETBatchesWithProgress(ctx, request, members, q, rule, nil)
}

func wbRunETBatchesWithProgress(ctx context.Context, request *http.Request, members []wbMember, q wbRequest, rule wbRule, onChunkDone func(processed, completedChunks, totalChunks int, rows []wbRow)) ([]wbRow, int, error) {
	ids := make([]string, 0, len(members))
	for _, member := range members {
		ids = append(ids, member.AccountID)
	}
	all := make(map[string]wbBatchMetric, len(ids))
	requestCount := 0
	processed := 0
	checkpointRows := make([]wbRow, 0, len(members))
	chunks := chunkIDs(ids, wbETMetricChunkSize)
	for index, chunk := range chunks {
		chunkCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
		metrics, err := wbRunMetricChunkWithRetry(chunkCtx, q.Program, index+1, len(chunks), func(attemptCtx context.Context) (map[string]wbBatchMetric, error) {
			startDate, endDate := wbMetricDates(ctx, q)
			return wbQueryETBatch(attemptCtx, request, chunk, startDate, endDate)
		})
		cancel()
		requestCount++
		if err != nil {
			return nil, requestCount, fmt.Errorf("ET metric chunk %d/%d failed after at most %d attempts: %w", requestCount, len(chunks), wbMetricMaxAttempts, err)
		}
		for id, metric := range metrics {
			if _, duplicate := all[id]; duplicate {
				return nil, requestCount, fmt.Errorf("ET metric account_id %s appeared in multiple chunks", id)
			}
			all[id] = metric
		}
		chunkMembers := members[processed : processed+len(chunk)]
		chunkRows, rowErr := wbRowsFromETBatch(chunkMembers, metrics, q, rule)
		if rowErr != nil {
			return nil, requestCount, rowErr
		}
		checkpointRows = append(checkpointRows, chunkRows...)
		processed += len(chunk)
		if onChunkDone != nil {
			onChunkDone(processed, requestCount, len(chunks), append([]wbRow(nil), checkpointRows...))
		}
	}
	rows, err := wbRowsFromETBatch(members, all, q, rule)
	return rows, requestCount, err
}

// queryAccountComparisonBatch reads only the authoritative Account-grain CCR/NFS
// source for Pre/Post windows. Revenue is intentionally excluded: the approved
// comparison contract contains Pre/Post P0 CCR (and NFS evidence), not revenue.
func queryAccountComparisonBatch(ctx context.Context, request *http.Request, ids []string, startDate, endDate, metricSource, program string) (map[string]wbBatchMetric, error) {
	ids = uniqueNonEmpty(ids)
	if len(ids) == 0 {
		return map[string]wbBatchMetric{}, nil
	}
	for _, id := range ids {
		if !decimalID.MatchString(id) {
			return nil, fmt.Errorf("invalid %s account_id %q", program, id)
		}
	}

	u := *request.URL
	r := request.Clone(ctx)
	r.URL = &u
	query := u.Query()
	query.Set("start_date", startDate)
	query.Set("end_date", endDate)
	query.Set("client_ids", strings.Join(ids, ","))
	query.Set("id_dimension", "account_id")
	r.URL.RawQuery = query.Encode()
	r.Header = request.Header.Clone()
	r.Header.Set("X-TAP-Allow-Missing-IDs", "1")

	probe, err := accountVQSProbe(ctx, r, metricSource)
	if err != nil {
		return nil, err
	}
	if asString(probe["status"]) != "ok" {
		return nil, accountProbeError(program+" Account CCR/NFS comparison", probe)
	}
	if truncated, _ := probe["possibly_truncated"].(bool); truncated {
		return nil, fmt.Errorf("%s Account CCR/NFS comparison result reached the hard limit; refusing silent truncation", program)
	}

	wanted := make(map[string]bool, len(ids))
	out := make(map[string]wbBatchMetric, len(ids))
	for _, id := range ids {
		wanted[id] = true
		out[id] = wbBatchMetric{Status: "no_data", Source: accountMetricSource(metricSource, probe, nil), QueriedAt: asString(probe["queriedAt"]), RequestID: asString(probe["requestId"]), LogID: asString(probe["logId"]), Message: "该 Account ID 在所选日期范围内没有返回权威 Account 比较事实行"}
	}
	for _, row := range mustBusinessRows(probe) {
		id := strings.TrimSpace(asString(row["account_id"]))
		if id == "" || !wanted[id] {
			return nil, fmt.Errorf("%s Account CCR/NFS comparison returned an unrequested or empty account_id %q", program, id)
		}
		if out[id].Status == "success" {
			return nil, fmt.Errorf("%s Account CCR/NFS comparison grain contract failed: account_id %s returned multiple rows", program, id)
		}
		ccr, metricErr := strictWBMetric(row["dynamic_p0_ccr"])
		if metricErr != nil {
			return nil, fmt.Errorf("account_id %s has invalid comparison dynamic_p0_ccr: %w", id, metricErr)
		}
		nfs, metricErr := strictWBMetric(row["p0_nfs"])
		if metricErr != nil {
			return nil, fmt.Errorf("account_id %s has invalid comparison p0_nfs: %w", id, metricErr)
		}
		out[id] = wbBatchMetric{Status: "success", CCR: ccr, NFS: nfs, Source: accountMetricSource(metricSource, probe, nil), QueriedAt: asString(probe["queriedAt"]), RequestID: asString(probe["requestId"]), LogID: asString(probe["logId"]), Message: "authoritative Account-grain comparison metrics"}
	}
	return out, nil
}
