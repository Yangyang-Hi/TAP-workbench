package main

import (
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"testing"
	"time"
)

func TestGovernanceAbsolutePolicyBoundaries(t *testing.T) {
	rule := wbGovernanceRule(wbRule{Enabled: true})
	for _, tt := range []struct {
		ccr, nfs float64
		want     string
	}{{3, 50, "normal"}, {3, 51, "watch"}, {45, 299, "watch"}, {45, 300, "critical"}, {46, 1, "normal"}, {2, 1000, "normal"}} {
		got, _ := evaluateWBAbsolute(&tt.ccr, &tt.nfs, rule)
		if got != tt.want {
			t.Fatalf("ccr=%g nfs=%g got=%s want=%s", tt.ccr, tt.nfs, got, tt.want)
		}
	}
}
func TestRiskUnionFullPoolTierTop20AndInvalidGrowth(t *testing.T) {
	rows := []wbReadRow{}
	for _, tier := range []string{"ET", "THT", "ST"} {
		for i := 0; i < 40; i++ {
			g := float64(i + 1)
			cmp := wbComparison{Status: "available", CCRGrowthPct: &g}
			if tier == "ST" {
				cmp.CCRGrowthPct = nil
				cmp.QoQGrowthPct = &g
			}
			region := "APAC"
			if i%2 == 0 {
				region = "EUI"
			}
			rows = append(rows, wbReadRow{Program: tier, AccountID: fmt.Sprintf("%s-%d", tier, i), RowID: fmt.Sprintf("%s-%d", tier, i), Region: region, Comparison: cmp})
		}
	}
	// Distinct normal pool must not leak into risks, even if an old row was labelled critical.
	for i := 0; i < 6000; i++ {
		rows = append(rows, wbReadRow{Program: "ET", AccountID: fmt.Sprint(i), RowID: fmt.Sprint(i), CCR: f64(46), NFS: f64(1), RiskLevel: "extreme"})
	}
	for _, status := range []string{"baseline_zero", "window_incomplete", "unavailable"} {
		rows = append(rows, wbReadRow{Program: "ET", AccountID: status, RowID: status, Comparison: wbComparison{Status: status, CCRGrowthPct: f64(999), PostCCR: f64(999)}})
	}
	rows = append(rows, wbReadRow{Program: "ET", AccountID: "negative", Comparison: wbComparison{Status: "available", CCRGrowthPct: f64(-3)}})
	rows = append(rows, wbReadRow{Program: "ET", AccountID: "absolute", CCR: f64(3), NFS: f64(51)})
	rows = append(rows, wbReadRow{Program: "ET", AccountID: "extreme", CCR: f64(45), NFS: f64(300)})
	// Same identity and evidence appears twice; the union must not duplicate it.
	rows = append(rows, rows[39])
	got := wbRiskList(rows, "combined")
	if len(got) != 82 {
		t.Fatalf("full pool=%d risks=%d want=82", len(rows), len(got))
	}
	counts := map[string]int{}
	for _, row := range wbRiskList(rows, "growth") {
		counts[row.Program]++
	}
	for _, tier := range []string{"ET", "THT"} {
		if counts[tier] != 40 {
			t.Fatalf("Top20 must be computed independently for configured Tier×Region groups: %#v", counts)
		}
	}
	if counts["ST"] != 0 {
		t.Fatalf("ST growth must be not configured: %#v", counts)
	}
}
func TestReadModelSeparatesQueriedPoolRiskPaginationAndStages(t *testing.T) {
	job := readModelFixture(t, 60)
	for i := range job.Rows {
		job.Rows[i].CCR = f64(1)
		job.Rows[i].NFS = f64(1)
	}
	job.Rows[59].CCR = f64(45)
	job.Rows[59].NFS = f64(300)
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	for _, view := range []string{"", "&view=customers"} {
		rr := httptest.NewRecorder()
		r := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly&page_size=1"+view, nil).WithContext(wbReq("reader").Context())
		wbReadModelHandler(rr, r)
		var body struct {
			Data struct {
				Rows       []wbReadRow            `json:"rows"`
				Pagination map[string]int         `json:"pagination"`
				Cards      map[string]wbCardValue `json:"cards"`
			} `json:"data"`
		}
		if e := json.Unmarshal(rr.Body.Bytes(), &body); e != nil {
			t.Fatal(e)
		}
		want := 1
		if view != "" {
			want = 60
		}
		if body.Data.Pagination["total"] != want || *body.Data.Cards["queried_customers"].Value != 60 || *body.Data.Cards["pending"].Value != 1 {
			t.Fatalf("%s: %s", view, rr.Body.String())
		}
	}
}
func TestSTComparisonUsesExplicitAnchorAndThreeCalendarMonths(t *testing.T) {
	now := time.Date(2026, 10, 21, 0, 0, 0, 0, cwLocation())
	pre, post := 2.0, 5.0
	got := wbComparisonResult("ST", "2026-07-01", &pre, &post, now)
	if got.Status != "available" || got.Kind != "qoq" || got.QoQGrowthPct == nil || *got.QoQGrowthPct != 150 || got.PreStart != "2026-04-01" || got.PostEndExclusive != "2026-10-01" {
		t.Fatalf("%+v", got)
	}
}

func TestSentWithoutMessageIDIsNotSuccessful(t *testing.T) {
	notices := []cwNotice{{Kind: "send", Status: "sent"}}
	if wbSuccessfulNotice(notices) || wbNotificationStatus(notices) != "unknown" {
		t.Fatal("missing message ID must not count as sent")
	}
}

func TestETPairAbsoluteRiskIsEvidenceOnly(t *testing.T) {
	criticalCCR, criticalNFS := 45.0, 300.0
	row := wbRow{Program: "ET", Member: wbMember{AccountID: "account"}, Advertisers: []wbAdvertiserEvidence{{AccountID: "account", AdvertiserID: "advertiser", CCR: &criticalCCR, NFS: &criticalNFS}}}
	got := wbApplyGovernanceRows([]wbRow{row}, wbRule{Enabled: true, RiskPolicy: wbGovernancePolicyVersion})[0]
	if got.CCR != nil || got.Level == "critical" || len(got.Reasons) != 0 {
		t.Fatalf("pair evidence overrode Account-level decision: %+v", got)
	}
	view := wbReadRow{Program: "ET", AccountID: "account", PairAbsoluteLevel: "critical", PairAbsoluteReasons: []string{"pair only"}}
	if risks := wbRiskList([]wbReadRow{view}, "absolute"); len(risks) != 0 {
		t.Fatalf("pair-only evidence entered Account absolute risk list: %+v", risks)
	}
}

func TestGrowthExtremeUsesCurrentP0CCR(t *testing.T) {
	row := wbRow{Program: "THT", CCR: f64(7), Comparison: wbComparison{Status: "available", PreCCR: f64(1), PostCCR: f64(2), CCRGrowthPct: f64(101)}}
	level, reasons := wbGovernanceLevel(row, wbRule{})
	if level != "critical" || len(reasons) == 0 {
		t.Fatalf("current P0 CCR threshold did not trigger: level=%s reasons=%v", level, reasons)
	}
	row.CCR, row.Comparison.PreCCR, row.Comparison.PostCCR = f64(6), f64(99), f64(99)
	level, _ = wbGovernanceLevel(row, wbRule{})
	if level == "critical" {
		t.Fatal("comparison-window CCR incorrectly triggered growth extreme when current P0 CCR was not > 6")
	}
}

func TestRiskRankingKeepsDistinctProtectionEventsForSameCustomer(t *testing.T) {
	rows := []wbReadRow{
		{Program: "THT", AdvertiserID: "7000000000000000001", RowID: "event-a", Tier: "THT", Region: "APAC", Comparison: wbComparison{Status: "available", CCRGrowthPct: f64(10)}},
		{Program: "THT", AdvertiserID: "7000000000000000001", RowID: "event-b", Tier: "THT", Region: "APAC", Comparison: wbComparison{Status: "available", CCRGrowthPct: f64(20)}},
	}
	got := wbRiskList(rows, "growth")
	if len(got) != 2 || got[0].RowID == got[1].RowID {
		t.Fatalf("distinct protection events were collapsed to a customer representative: %+v", got)
	}
}
