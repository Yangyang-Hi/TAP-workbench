import { useEffect, useMemo, useState } from "react";
import { Drawer } from "@arco-design/web-react";
import { CaseActions } from "./casework";
import { submissionsQuotaList, submissionsStSnapshotsCreate, unwrap } from "../../api/client.gen";
import type { ScanRequest } from "./api";
import { useSharedFilters } from "./shared-filters";
import "./submission-quota.css";

type Dict = Record<string, unknown>;
type QuotaRow = {
  scope?: string;
  region?: string;
  tier?: string;
  total?: number;
  used?: number;
  rate?: number;
  remaining?: number;
  approvedTickets?: number;
  distinctAdvertisers?: number;
  accountCount?: number;
  brandCount?: number;
  ticketCount?: number;
  metricLevel?: string;
  poc?: string;
  notificationStatus?: string;
  alertId?: string;
  complete?: boolean;
  alert?: string;
  asOf?: string;
  status?: string;
  reason?: string;
};
type WeeklyPoint = { week: string; et?: number; tht?: number; status?: string };

const unavailable = "数据暂不可用";
const isDict = (value: unknown): value is Dict => !!value && typeof value === "object" && !Array.isArray(value);
const text = (value: unknown) => (typeof value === "string" && value.trim() ? value.trim() : undefined);
const scalar = (value: unknown) => text(value) || (typeof value === "number" ? String(value) : Array.isArray(value) ? value.map(String).join(" — ") : undefined);
const number = (value: unknown) => (typeof value === "number" && Number.isFinite(value) ? value : undefined);
const list = (value: unknown): unknown[] => (Array.isArray(value) ? value : []);
const first = <T,>(...values: (T | undefined)[]) => values.find((value) => value !== undefined);

function normalizeRow(value: unknown, fallback: Partial<QuotaRow> = {}): QuotaRow | undefined {
  if (!isDict(value)) return undefined;
  const row: QuotaRow = {
    scope: first(text(value.scope), fallback.scope),
    region: first(text(value.region), text(value.region_name), fallback.region),
    tier: first(text(value.tier), text(value.program), text(value.program_type), fallback.tier)?.toUpperCase(),
    total: first(number(value.total), number(value.total_quota), number(value.quota)),
    used: first(number(value.used), number(value.used_quota), number(value.count)),
    rate: first(number(value.rate), number(value.usage), number(value.usage_rate)),
    remaining: first(number(value.remaining), number(value.remaining_quota)),
    alert: first(text(value.alert), text(value.alert_level)),
    asOf: first(text(value.data_as_of), text(value.as_of), text(value.updated_at)),
    status: text(value.status),
    reason: first(text(value.reason), text(value.error)),
  };
  if (!row.scope && !row.region && !row.tier) return undefined;
  return row;
}

function parsePayload(payload: unknown) {
  const data = isDict(payload) ? payload : {};
  const quota = isDict(data.quota) ? data.quota : data;
  const rows: QuotaRow[] = [];
  const global = isDict(quota.global) ? quota.global : {};
  for (const tier of ["ET", "THT", "ST"]) {
    const item = global[tier.toLowerCase()];
    if (isDict(item)) rows.push({
      scope: "Global", region: "Global", tier,
      total: number(item.quota), used: number(item.used), rate: number(item.ratio),
      remaining: number(item.quota) !== undefined && number(item.used) !== undefined ? number(item.quota)! - number(item.used)! : undefined,
      approvedTickets: number(item.approved_ticket_count), distinctAdvertisers: number(item.distinct_advertiser_count),
      accountCount: number(item.account_count), brandCount: number(item.brand_count), ticketCount: number(item.ticket_count), metricLevel: text(item.metric_level), complete: item.complete !== false,
      alert: text(item.status), asOf: text(isDict(quota.as_of) ? quota.as_of[tier.toLowerCase()] : undefined), status: text(item.status),
    });
  }
  for (const regionItem of list(quota.regions)) {
    if (!isDict(regionItem)) continue;
    for (const tier of ["ET", "THT", "ST"]) {
      const item = regionItem[tier.toLowerCase()];
      if (!isDict(item)) continue;
      rows.push({ scope: "Region", region: text(regionItem.region), tier, total: number(item.quota), used: number(item.used), rate: number(item.ratio), remaining: number(item.remaining), approvedTickets: number(item.approved_ticket_count), distinctAdvertisers: number(item.distinct_advertiser_count), accountCount: number(item.account_count), brandCount: number(item.brand_count), ticketCount: number(item.ticket_count), metricLevel: text(item.metric_level), poc: text(regionItem.regional_poc), notificationStatus: first(text(item.notification_status), text(regionItem.notification_status)), alertId: text(item.alert_id), complete: item.complete !== false, alert: text(item.status), status: text(item.status) });
    }
  }
  for (const item of [...list(quota.plans), ...list(quota.rows)]) {
    const row = normalizeRow(item, { scope: "Global" });
    if (row) rows.push(row);
  }
  const weeklyRaw = list(quota.weekly).length ? list(quota.weekly) : list(data.weekly);
  const weekly: WeeklyPoint[] = weeklyRaw.flatMap((item) => {
    if (!isDict(item)) return [];
    const week = first(text(item.week), text(item.week_start), text(item.label));
    return week ? [{ week, et: first(number(item.et_qtd), number(item.et), number(item.ET)), tht: first(number(item.tht_qtd), number(item.tht), number(item.THT)), status: text(item.status) }] : [];
  });
  return {
    status: first(text(data.status), text(quota.status)),
    reason: first(text(data.reason), text(quota.reason), ...Object.values(isDict(quota.errors) ? quota.errors : {}).map(text)),
    diagnostics: isDict(quota.diagnostics) ? quota.diagnostics : {},
    sourceErrors: isDict(quota.errors) ? quota.errors : {},
    warnings: list(quota.warnings).map(text).filter(Boolean),
    quarter: text(quota.quarter),
    time: isDict(quota.time) ? quota.time : {},
    asOf: first(text(quota.as_of), text(isDict(quota.as_of) ? quota.as_of.st : undefined), text(data.as_of)),
    rows,
    weekly,
    stSnapshot: isDict(quota.st_snapshot) ? quota.st_snapshot : {},
  };
}

const displayNumber = (value: number | undefined) => value === undefined ? unavailable : value.toLocaleString("en-US", { maximumFractionDigits: 2 });
// The existing quota API returns ratio in percentage points (e.g. 1.5 = 1.5%).
const rateValue = (row: QuotaRow) => {
  if (row.total === 0) return undefined;
  return row.rate ?? (row.total !== undefined && row.used !== undefined ? row.used / row.total * 100 : undefined);
};
const displayRate = (row: QuotaRow) => row.tier === "THT" ? "N/A" : rateValue(row) === undefined ? unavailable : `${rateValue(row)!.toFixed(1)}%`;
const tone = (rate: number | undefined) => rate === undefined ? "unknown" : rate < 60 ? "green" : rate < 80 ? "yellow" : rate < 100 ? "orange" : "red";
const notificationLabel = (status?: string) => ({ pending_regional_poc: "待确认区域 POC", ready_in_test_mode: "测试候选，尚未正式发送", sent: "已正式发送", blocked_missing_poc: "缺少区域 POC", not_triggered: "未触发", not_created:"尚未建立事件", awaiting_confirmation:"待预览并确认发送", failed:"发送失败", pending:"发送中", unknown:"回执待核对" }[status || ""] || status || "pending regional POC");
const alertLabel = (row: QuotaRow) => {
  const labels: Record<string, string> = { green: "正常", yellow: "关注", orange: "预警", red: "超额", unavailable: unavailable, no_denominator: "无配额分母" };
  return row.alert ? (labels[row.alert] || row.alert) : labels[tone(rateValue(row))] || unavailable;
};

function quarterForDate(value: string) {
  const month = Number(value.slice(5, 7));
  if (month >= 7 && month <= 9) return "Q3";
  if (month >= 10 && month <= 12) return "Q4";
  return "";
}
function selectedSTQuarters(start: string, end: string) {
  const firstQuarter = quarterForDate(start);
  const lastQuarter = quarterForDate(end);
  if (!firstQuarter || !lastQuarter) return ["Q4"];
  if (firstQuarter === lastQuarter) return [firstQuarter];
  if ([firstQuarter, lastQuarter].includes("Q3") && [firstQuarter, lastQuarter].includes("Q4")) return ["Q3", "Q4"];
  return [];
}

export function SubmissionQuota({ query, alertsOnly = false, summaryOnly = false }: { query?: ScanRequest; alertsOnly?: boolean; summaryOnly?: boolean }) {
  const [activeQuotaCase, setActiveQuotaCase] = useState<string>();
  const { filters } = useSharedFilters();
  const unsupported = false;
  const [region, setRegion] = useState("all");
  const [quotaType, setQuotaType] = useState("all");
  const [from, setFrom] = useState(query?.start_date || filters.start_date || "");
  const [to, setTo] = useState(query?.end_date || filters.end_date || "");
  const customWindow = filters.time_mode === "custom" || !!query?.start_date;
  const quarters = useMemo(() => selectedSTQuarters(customWindow ? filters.start_date || from : "", customWindow ? filters.end_date || to : ""), [customWindow, filters.start_date, filters.end_date, from, to]);
  const quarter = quarters[0] || "Q4";
  const [raw, setRaw] = useState<unknown>();
  const [additionalST, setAdditionalST] = useState<Dict[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [syncingST, setSyncingST] = useState(false);
  const [syncError, setSyncError] = useState("");
  // Weekly risk batches do not populate custom start_date/end_date. Let the
  // backend resolve the selected batch cutoff to a quarter-to-date window.
  const effectiveStart = customWindow ? filters.start_date || query?.start_date || from : "";
  const effectiveEnd = customWindow ? filters.end_date || query?.end_date || to : "";

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    if (customWindow && (!effectiveStart || !effectiveEnd)) {
      setRaw(undefined); setAdditionalST([]); setError("请选择完整的自定义开始和结束日期"); setLoading(false);
      return () => { active = false; };
    }
    const request = (stQuarter: string) => submissionsQuotaList({
      quarter: stQuarter,
      ...(customWindow ? { start_date: effectiveStart, end_date: effectiveEnd } : { time_mode: "weekly", ...(filters.batch_id ? { batch_id: filters.batch_id } : {}) }),
      ...(filters.tier === "all" ? {} : { program: filters.tier }),
      ...(filters.region === "all" ? {} : { region: filters.region }),
    });
    Promise.all((quarters.length ? quarters : [quarter]).map(request))
      .then((responses) => {
        if (!active) return;
        const values = responses.map((response) => unwrap(response));
        setRaw(values[0]);
        setAdditionalST(values.slice(1).filter(isDict));
      })
      .catch((cause: unknown) => {
        if (!active) return;
        setRaw(undefined);
        setAdditionalST([]);
        const message = cause instanceof Error ? cause.message : String(cause);
        setError(/HTTP 403\b/.test(message) ? "ROW 网关拒绝访问（HTTP 403），请重试" : `${unavailable}：${message}`);
      })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [filters.tier, filters.region, filters.time_mode, filters.batch_id, customWindow, effectiveStart, effectiveEnd, quarter, quarters.join(","), reloadKey]);

  const parsed = useMemo(() => parsePayload(raw), [raw]);
  const shownStart = text(parsed.time.start_date) || effectiveStart;
  const shownEnd = text(parsed.time.end_date) || effectiveEnd;
  const shownQuarter = parsed.quarter || quarter;
  const shownQuarters = customWindow ? quarters : [shownQuarter];
  const rows = parsed.rows.filter((row) =>
    (region === "all" || row.region === region || row.scope?.toLowerCase() === "global") &&
    (quotaType === "all" || row.tier === quotaType));
  const regions = [...new Set(parsed.rows.map((row) => row.region).filter((value): value is string => !!value))];
  const summary = (name: string) => parsed.rows.find((row) => row.tier === name && row.scope?.toLowerCase() === "global") || parsed.rows.find((row) => row.tier === name);
  const stateUnavailable = !!error || parsed.status === "unavailable" || parsed.status === "failed";
  const quotaAlerts = rows.filter((row) => row.scope?.toLowerCase() === "region" && (row.tier === "ET" || row.tier === "ST") && row.complete !== false && row.total !== undefined && row.total > 0 && (row.tier === "ET" ? (rateValue(row) ?? -1) >= 100 : (rateValue(row) ?? -1) > 100));
  const riskUnknown = loading || stateUnavailable || !rows.length || rows.some((row) => (row.tier === "ET" || row.tier === "ST") && (row.complete === false || row.total === undefined));
  async function syncST() {
    setSyncingST(true); setSyncError("");
    try { await submissionsStSnapshotsCreate({}); setReloadKey((value) => value + 1); }
    catch (cause) { setSyncError(cause instanceof Error ? cause.message : "ST 权威表同步失败"); }
    finally { setSyncingST(false); }
  }

  if (unsupported) return <div className="quota-center" data-testid="submission-page"><div className="tg-warning" role="status">不支持此筛选 / 数据暂不可用：Quota 分母不能按负责人、关键词、我的范围或独立 Tier 分摊，未展示全局值。</div></div>;

  if (alertsOnly) {
    return <section className="ops-panel" data-testid="quota-alerts"><header><div><h2>Quota 区域预警</h2><p>仅 ET 使用率达到或超过 100%、ST 严格超过 100% 且数据完整、有配额分母才进入；THT 无分母不报警。</p></div></header>{loading ? <p>正在读取配额数据…</p> : stateUnavailable ? <p role="alert">{error || unavailable} · {parsed.reason || "请求未完成"} <button type="button" onClick={() => setReloadKey((value) => value + 1)}>重试</button></p> : <div className="quota-table-wrap"><table><thead><tr>{["Region","Tier","使用量","配额","使用率","Regional POC","正式通知状态","操作"].map(label=><th key={label}>{label}</th>)}</tr></thead><tbody>{quotaAlerts.map(row=><tr key={`${row.region}-${row.tier}`}><td>{row.region}</td><td>{row.tier}</td><td>{displayNumber(row.used)}</td><td>{displayNumber(row.total)}</td><td>{displayRate(row)}</td><td>{row.poc || "待补负责人"}</td><td>{notificationLabel(row.notificationStatus || (row.poc ? "awaiting_confirmation" : "blocked_missing_poc"))}</td><td>{row.alertId ? <button type="button" className="tg-btn" onClick={() => setActiveQuotaCase(row.alertId)}>查看 / 通知</button> : <span>等待扫描建单</span>}</td></tr>)}</tbody></table>{!quotaAlerts.length && <p className="ops-empty-inline">当前范围未返回完整且超过 100% 的 ET / ST 区域记录；不完整或缺失数据不作为正常结果。</p>}</div>}<Drawer title="Quota 区域预警处理" visible={!!activeQuotaCase} width={760} footer={null} onCancel={() => setActiveQuotaCase(undefined)}>{activeQuotaCase && <CaseActions id={activeQuotaCase} showEvidence={false} onSaved={() => setReloadKey(v => v + 1)} />}</Drawer></section>;
  }

  if (summaryOnly) {
    return <section className="ops-panel" data-testid="quota-summary"><header><div><h2>Quota 统计摘要</h2><p>与运营数据中心复用同一 /api/submissions/quota 口径。</p></div></header>{loading ? <p>正在读取配额数据…</p> : stateUnavailable ? <p role="alert">{error || unavailable} · {parsed.reason || "请求未完成"} <button type="button" onClick={() => setReloadKey((value) => value + 1)}>重试</button></p> : <div className="quota-overview">{["ET", "ST", "THT"].map((tier) => { const row = summary(tier); return <article className="quota-summary" key={tier}><div><b>{tier}</b><span>Global</span></div><strong>{row ? displayRate(row) : unavailable}</strong><small>{tier === "THT" ? `通过客户 ${displayNumber(row?.distinctAdvertisers ?? row?.used)} · 无配额分母` : `Used ${displayNumber(row?.used)} / Quota ${displayNumber(row?.total)}`}</small></article>; })}</div>}</section>;
  }

  return (
    <div className="quota-center" data-testid="submission-page">
      <section className="quota-hero" aria-labelledby="quota-title">
        <div>
          <span className="quota-eyebrow">SUBMISSION &amp; QUOTA</span>
          <h2 id="quota-title">提报与配额运行视图</h2>
          <p>ET 按查询范围内去重 Account 计算配额占用，工单数单独展示；THT 展示通过客户数和工单数且无分母；ST 以去重 Brand Name 作为正式配额占用量，并保留 Account 数作辅助。</p>
        </div>
        <span className="quota-asof">Data As Of · {parsed.asOf || unavailable}</span>
      </section>

      {parsed.warnings.map((warning, index) => <p role="status" key={index}>{warning}</p>)}
      <div className="quota-overview" aria-label="Global ST / ET 使用总览">
        {["ET", "THT", "ST"].map((name) => {
          const row = summary(name);
          return <article key={name} className="quota-summary">
            <div><b>{name}</b><span>{name === "ST" ? `${shownQuarter} · ${shownQuarter === "Q3" ? "Full Quarter" : "QTD"}` : `${shownStart || "—"} — ${shownEnd || "—"}`}</span></div>
            <strong>{stateUnavailable || !row ? unavailable : name === "ET" || name === "ST" ? (row.total === undefined ? displayNumber(row.used ?? row.brandCount) : displayRate(row)) : displayNumber(row.distinctAdvertisers ?? row.used)}</strong>
            <small>{name === "ET"
              ? `Account 占用 ${row ? displayNumber(row.accountCount ?? row.used) : unavailable} · 通过工单 ${row ? displayNumber(row.ticketCount) : unavailable} · Account Quota ${row ? displayNumber(row.total) : unavailable}`
              : name === "THT"
                ? `通过客户 ${row ? displayNumber(row.distinctAdvertisers ?? row.used) : unavailable} · 通过工单 ${row ? displayNumber(row.approvedTickets ?? row.ticketCount) : unavailable} · 无配额分母`
                : `Account ${row ? displayNumber(row.accountCount) : unavailable} · Brand ${row ? displayNumber(row.brandCount) : unavailable} · Quota ${row ? displayNumber(row.total) : unavailable}`}</small>
          </article>;
        })}
      </div>

      <section className="quota-controls" aria-label="Submission & Quota 筛选">
        <div className="quota-control-group st-scope">
          <div><b>ST 季度口径</b><span>由同一日期控件自动映射季度，不按天切分或折算</span></div>
          <span>{shownQuarters.length ? shownQuarters.map((item) => `${item} · ${item === "Q3" ? "Full Quarter" : "QTD"}`).join(" / ") : "所选日期没有对应 ST 季度快照"}</span>
          {quarters.length > 1 && <span>跨季度分开展示，不直接累加</span>}
        </div>
        <div className="quota-control-group global-scope">
          <div><b>统一日期范围</b><span>ET / THT 按日期过滤；ST 自动映射季度</span></div>
          <span>{shownStart || "等待解析查询窗口"} → {shownEnd || "等待解析查询窗口"}</span>
          {text(parsed.time.basis) === "live_qtd_no_weekly_batch" && <small>暂无周度批次；当前为本季度截至今日的实时只读查询，实际出数以源分区为准。</small>}
        </div>
        <div className="quota-filter-row">
          <label>Region<select aria-label="Quota Region" value={region} onChange={(event) => setRegion(event.target.value)}><option value="all">全部区域</option>{regions.map((item) => <option key={item}>{item}</option>)}</select></label>
          <label>Quota 类型<select aria-label="Quota 类型" value={quotaType} onChange={(event) => setQuotaType(event.target.value)}><option value="all">全部类型</option><option value="ET">ET</option><option value="ST">ST</option><option value="THT">THT</option></select></label>
          <span className="quota-legend">局部类型筛选仅影响 Quota Monitoring、预警与明细，不修改页面共享筛选 <i className="green" />&lt;60 <i className="yellow" />60–80 <i className="orange" />80–100 <i className="red" />≥100</span>
        </div>
      </section>

      {(loading || stateUnavailable || !rows.length) && <div className="quota-state" role={error ? "alert" : "status"}>{loading ? "正在读取配额数据…" : error || unavailable}{parsed.reason ? ` · ${parsed.reason}` : ""}{error && <button type="button" onClick={() => setReloadKey((value) => value + 1)}>重试</button>}</div>}
      <>
        <section className="quota-section" data-testid="quota-warning-list">
          <div className="quota-section-head"><div><h3>Quota 预警列表</h3><p>仅列出完整、有分母且 ET ≥100% / ST &gt;100% 的区域；THT 不报警。</p></div><strong>{riskUnknown && !quotaAlerts.length ? "待判定" : `${quotaAlerts.length} 条${riskUnknown ? "（部分未完成）" : ""}`}</strong></div>
          <div className="quota-table-wrap"><table><thead><tr>{["Region", "Tier", "Used", "Quota", "Rate", "状态"].map((label) => <th key={label}>{label}</th>)}</tr></thead><tbody>{quotaAlerts.map((row) => <tr key={`${row.region}-${row.tier}`}><td>{row.region}</td><td>{row.tier}</td><td>{displayNumber(row.used)}</td><td>{displayNumber(row.total)}</td><td>{displayRate(row)}</td><td><span className="quota-alert red">超额</span></td></tr>)}</tbody></table>{!quotaAlerts.length && <p className="ops-empty-inline">{riskUnknown ? "配额数据未完整返回或缺少有效分母，暂无法判断是否超额。" : "当前范围无超过 100% 的 ET / ST 区域预警。"}</p>}</div>
        </section>
        <section className="quota-section">
          <div className="quota-section-head"><div><h3>Quota Monitoring · Global + Region</h3><p>ET / ST 按配额使用率着色；THT 无配额分母，固定显示 N/A。</p></div></div>
          <div className="quota-region-grid">{rows.map((row, index) => {
            const rate = rateValue(row);
            const headline = row.tier === "THT" ? displayNumber(row.distinctAdvertisers ?? row.used) : row.total === undefined ? displayNumber(row.used ?? row.brandCount) : displayRate(row);
            const detail = row.tier === "ET" ? `工单 ${displayNumber(row.ticketCount)} · Account ${displayNumber(row.accountCount)}` : row.tier === "THT" ? `通过客户 ${displayNumber(row.distinctAdvertisers ?? row.used)} · 工单 ${displayNumber(row.approvedTickets ?? row.ticketCount)}` : `Account ${displayNumber(row.accountCount)} · Brand ${displayNumber(row.brandCount)} · Quota ${displayNumber(row.total)}`;
            return <article className="quota-region" key={`${row.region}-${row.tier}-${index}`}>
              <header><b>{row.region || unavailable}</b><span>{row.tier || unavailable}</span></header>
              <strong>{headline}</strong><small>{detail}</small>
              {row.tier !== "THT" && <div className="quota-progress" aria-label={`${row.region} ${row.tier} ${displayRate(row)}`}><i className={tone(rate)} style={{ width: `${Math.min(rate ?? 0, 100)}%` }} /></div>}
              <footer><span>{alertLabel(row)}</span><small>{row.poc || "待补负责人"}</small></footer>
            </article>;
          })}</div>
        </section>

        <section className="quota-section">
          <div className="quota-section-head"><div><h3>Global / Region 明细</h3><p>统一字段与状态语义；THT 分母相关字段固定为 N/A。</p></div></div>
          <div className="quota-table-wrap"><table><thead><tr>{["Scope", "Region", "Tier", "Total", "Used（ET Account / ST Brand）/ THT 通过工单", "去重 Advertiser", "Rate", "Remaining", "Alert", "Data As Of"].map((label) => <th key={label}>{label}</th>)}</tr></thead><tbody>{rows.map((row, index) => <tr key={`${row.scope}-${row.region}-${row.tier}-${index}`}><td>{row.scope || unavailable}</td><td>{row.region || (row.scope?.toLowerCase() === "global" ? "Global" : unavailable)}</td><td>{row.tier || unavailable}</td><td>{row.tier === "THT" ? "N/A" : displayNumber(row.total)}</td><td>{displayNumber(row.tier === "THT" ? row.approvedTickets ?? row.used : row.used)}</td><td>{row.tier === "THT" ? displayNumber(row.distinctAdvertisers) : "N/A"}</td><td>{displayRate(row)}</td><td>{row.tier === "THT" ? "N/A" : displayNumber(row.remaining)}</td><td><span className={`quota-alert ${tone(rateValue(row))}`}>{alertLabel(row)}</span></td><td>{row.asOf || parsed.asOf || unavailable}</td></tr>)}</tbody></table></div>
        </section>

        <details className="quota-section"><summary>查询诊断</summary>
          <div className="quota-section-head"><div><h3>ET / THT 查询诊断</h3><p>仅展示查询追踪与聚合完整性，不打印凭证。</p></div></div>
          <div className="quota-table-wrap"><table><thead><tr>{["Tier", "RID", "实际端点", "业务窗口", "分区", "源返回", "去重工单", "去重客户", "完整性", "失败原因", "Request ID / Log ID"].map((label) => <th key={label}>{label}</th>)}</tr></thead><tbody>{["ET", "THT"].map((tier) => { const diagnostic = isDict(parsed.diagnostics[tier]) ? parsed.diagnostics[tier] as Dict : {}; const window = isDict(diagnostic.business_window) ? diagnostic.business_window : {}; return <tr key={tier}><td>{tier}</td><td>{scalar(diagnostic.rid) || unavailable}</td><td>{text(diagnostic.endpoint) || unavailable}</td><td>{`${text(window.start_date) || "—"} — ${text(window.end_date) || "—"}`}</td><td>{scalar(diagnostic.partition) || unavailable}</td><td>{displayNumber(number(diagnostic.source_returned_rows))}</td><td>{displayNumber(number(diagnostic.deduplicated_ticket_count))}</td><td>{displayNumber(number(diagnostic.deduplicated_customer_count))}</td><td>{diagnostic.complete === true ? "完整" : "不完整"}</td><td>{text(parsed.sourceErrors[tier]) || text(diagnostic.error) || (error ? "请求未到达数据源查询阶段" : "—")}</td><td>{text(diagnostic.request_id) || unavailable}<br />{text(diagnostic.log_id) || ""}</td></tr>; })}</tbody></table></div>
        </details>

        <section className="quota-section st-source-section">
          <div className="quota-section-head"><div><h3>ST 权威来源快照</h3><p>季度表保存的是已批准客户明细，不是总配额或预聚合使用量；Used 按 Brand Name 去重，原始 Account 行保留展示。</p></div><button type="button" disabled={syncingST} onClick={() => void syncST()}>{syncingST ? "正在同步 ST…" : "同步 ST 权威表"}</button></div>
          {(syncError || text(parsed.sourceErrors.ST)) && <p role="status">ST：{syncError || text(parsed.sourceErrors.ST)}</p>}
          <div className="st-source-meta">
            <span><b>季度</b>{text(parsed.stSnapshot.quarter) || quarter}</span>
            <span><b>口径</b>{text(parsed.stSnapshot.period_basis) || unavailable}</span>
            <span><b>原表更新时间</b>{text(parsed.stSnapshot.source_modified_at) || unavailable}</span>
            <span><b>同步时间</b>{text(parsed.stSnapshot.synced_at) || unavailable}</span>
            <span><b>同步结果</b>{text(parsed.stSnapshot.sync_result) || unavailable}</span>
            <span><b>明细行数</b>{displayNumber(number(parsed.stSnapshot.row_count))}</span>
          </div>
          {text(parsed.stSnapshot.source_url) ? <p><a href={text(parsed.stSnapshot.source_url)} target="_blank" rel="noreferrer">打开权威飞书 Sheet</a></p> : null}
          <div className="quota-table-wrap"><table><thead><tr>{["Sales Region", "Brand Name", "Account ID", "Endorsement Reason", "Adex Submitter", "Start date"].map((label) => <th key={label}>{label}</th>)}</tr></thead><tbody>{list(parsed.stSnapshot.rows).map((item, index) => { const row = isDict(item) ? item : {}; return <tr key={`${text(row.account_id) || index}`}><td>{text(row.sales_region) || unavailable}</td><td>{text(row.brand_name) || unavailable}</td><td>{text(row.account_id) || unavailable}</td><td>{text(row.endorsement_reason) || unavailable}</td><td>{text(row.adex_submitter) || unavailable}</td><td>{text(row.start_date) || unavailable}</td></tr>; })}</tbody></table></div>
          {number(parsed.stSnapshot.row_count) !== undefined && number(parsed.stSnapshot.rows_returned) !== undefined && number(parsed.stSnapshot.row_count)! > number(parsed.stSnapshot.rows_returned)! ? <small>页面预览前 {number(parsed.stSnapshot.rows_returned)} 行；完整明细已保存在 App 快照中。</small> : null}
        </section>
        {additionalST.map((item) => { const extra = parsePayload(item); const snapshot = extra.stSnapshot; const st = extra.rows.find((row) => row.scope?.toLowerCase() === "global" && row.tier === "ST"); return <section className="quota-section st-source-section" key={text(snapshot.quarter) || "additional-st"}><div className="quota-section-head"><div><h3>ST {text(snapshot.quarter) || unavailable} · {text(snapshot.period_basis) || unavailable}</h3><p>跨季度独立展示，不与其他季度直接累加。</p></div><strong>Used {displayNumber(st?.used)}</strong></div><div className="st-source-meta"><span><b>实际季度</b>{text(snapshot.quarter) || unavailable}</span><span><b>源数据截止时间</b>{text(snapshot.source_modified_at) || unavailable}</span><span><b>同步时间</b>{text(snapshot.synced_at) || unavailable}</span><span><b>同步结果</b>{text(snapshot.sync_result) || unavailable}</span></div></section>; })}

        <section className="quota-section weekly-section">
          <div className="quota-section-head"><div><h3>QTD 周度 ET / THT</h3><p>ET 按 Account、THT 按 Advertiser 在查询窗口内累计去重；不是各周去重数相加。</p></div></div>
          {parsed.weekly.length ? <div className="weekly-chart" role="img" aria-label="QTD 周度 ET 与 THT 数量">{parsed.weekly.map((point) => { const max = Math.max(1, ...parsed.weekly.flatMap((item) => [item.et || 0, item.tht || 0])); return <div className="weekly-column" key={point.week}><div><i className="et" style={{ height: `${((point.et || 0) / max) * 100}%` }} /><i className="tht" style={{ height: `${((point.tht || 0) / max) * 100}%` }} /></div><b>{point.week}</b><small>ET {displayNumber(point.et)} · THT {displayNumber(point.tht)}</small></div>;})}</div> : <div className="quota-state">{unavailable}</div>}
        </section>
      </>
    </div>
  );
}
