import type { MetricFact } from "./metric-display";

export type CardValue = { value: number | null; status: string; description?: string; note?: string };
export type Comparison = {
  pre_ccr_fact?: MetricFact; post_ccr_fact?: MetricFact; increase_fact?: MetricFact;
  pre_ccr: number | null; post_ccr: number | null; ccr_delta?: number | null; ccr_growth_pct?: number | null; protection_ccr_growth_pct?: number | null;
  pre_nfs?: number | null; post_nfs?: number | null; nfs_delta?: number | null; nfs_growth_pct?: number | null;
  pre_revenue?: number | null; post_revenue?: number | null; revenue_delta?: number | null; revenue_growth_pct?: number | null;
  wow_ccr_growth_pct: number | null; wow_status?: string; wow_missing_reason?: string;
  qoq_ccr_growth_pct: number | null; qoq_status?: string; qoq_missing_reason?: string;
  rolling_90d_ccr_growth_pct?: number | null;
  status: string; missing_reason: string; kind: string; pre_start_date: string; pre_end_exclusive: string;
  post_start_date: string; post_end_exclusive: string; timezone: string;
  event_anchor?: string; event_id?: string; anchor_source?: string;
};
export type Notice = { id?: string; kind?: string; status: string; recipient?: string; message_id?: string; attempts?: number; error?: string; updated_at?: string };
export type ReportedReason = {
  original_label: string; raw_path?: string; display_name_en: string; mapped_name?: string; description: string; mapping_status: string;
  p0_ccr: number | null; p0_nfs?: number | null; rank: number | null; ranking_available: boolean; ranking_unavailable_reason?: string;
  source_status?: string; source_reason?: string; query_status?: string; sort_basis?: string;
};
export type AdvertiserEvidence = {
  advertiser_id?: string; advertiser_name?: string; account_id?: string; ccr?: number | null; nfs?: number | null; revenue?: number | null;
  ccr_fact?: MetricFact; nfs_fact?: MetricFact; revenue_fact?: MetricFact; pre_ccr_fact?: MetricFact; post_ccr_fact?: MetricFact; increase_fact?: MetricFact;
  pre_ccr?: number | null; post_ccr?: number | null; ccr_delta?: number | null; ccr_growth_pct?: number | null; protection_ccr_growth_pct?: number | null;
  pre_nfs?: number | null; post_nfs?: number | null; nfs_delta?: number | null; nfs_growth_pct?: number | null;
  pre_revenue?: number | null; post_revenue?: number | null; revenue_delta?: number | null; revenue_growth_pct?: number | null;
  current_source?: Record<string, unknown>; comparison_source?: Record<string, unknown>;
  wow_ccr_growth_pct?: number | null; wow_status?: string; wow_missing_reason?: string;
  qoq_ccr_growth_pct?: number | null; qoq_status?: string; qoq_missing_reason?: string;
  comparison_status?: string; comparison_reason?: string; semantics_label_tier_1_2_3_4?: string; semantics_label_status?: string;
  reported_reasons?: ReportedReason[]; reported_reasons_status?: string; reported_reasons_error?: string; reported_reasons_sort_basis?: string;
  allowlist_status?: string; allowlist_error?: string;
};
export type ReadRow = {
  alert_id: string | null; account_id: string; account_name: string; advertiser_id: string; program: string; tier: string; region: string;
  original_submitter: string; actual_recipient: string | null; p0_ccr: number | null; p0_nfs: number | null; revenue: number | null;
  p0_ccr_fact?: MetricFact; p0_nfs_fact?: MetricFact; revenue_fact?: MetricFact;
  comparison: Comparison; advertiser_valid_count: number; advertiser_top10: AdvertiserEvidence[];
  advertiser_candidate_summary?: { total: number; ccr_available?: number; nfs_available?: number; revenue_available?: number; name_available?: number; reasons_available?: number; allowlist_captured?: number };
  pair_absolute_level?: string; pair_absolute_reasons?: string[]; risk_level: string; risk_reasons: string[];
  metric_status?: string; ccr_status?: string; nfs_status?: string; revenue_status?: string;
  allowlist_status?: string; allowlist_reason?: string; event_anchor?: string; protection_event_id?: string;
  protection_anchor?: string; protection_anchor_status?: "available" | "missing" | "ambiguous"; protection_anchor_source?: string;
  current_window?: { start_date: string; end_date: string };
  event_stage: string; notification: { status: string; history: Notice[] }; scan_id: string; row_id: string;
};
export type Batch = { batch_id: string; week_name: string; generated_at: string; metric_start_date: string; metric_end_date: string; timezone: string; programs: string[]; status: string; completeness: string };
export type ReadModel = {
  status: string; reason: string; time: { mode: string; selected_batch?: Batch; batches?: Batch[]; start_date?: string; end_date?: string };
  filters: Record<string, unknown>; filter_options?: { regions?: string[]; submitters?: string[]; statuses?: string[] }; cards: Record<string, CardValue>; rows: ReadRow[];
  rankings: Record<string, unknown>; pagination: { page: number; page_size: number; total: number }; contract_version: string;
};

export const metric = (value: number | null | undefined) => value == null ? "—" : value.toLocaleString("en-US", { maximumFractionDigits: 6 });
export const ccr = (value: number | null | undefined) => value == null ? "—" : value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const nfs = (value: number | null | undefined) => value == null ? "—" : Math.round(value).toLocaleString("en-US");
export const revenue = (value: number | null | undefined) => value == null ? "—" : value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const pct = (value: number | null | undefined) => value == null ? "—" : `${value > 0 ? "+" : ""}${value.toFixed(2)}%`;
export const present = (value: unknown) => typeof value === "string" && value.trim() ? value : "—";
export const stageLabels: Record<string, string> = { pending_operator: "待运营确认", pending_submitter: "待提报人处理", closed: "已关闭" };
export const noticeLabels: Record<string, string> = { sent: "已发送", unknown: "发送结果待核实", failed: "发送失败", queued: "发送排队中", blocked: "发送受阻", not_sent: "尚未发送" };
export const riskLabels: Record<string, string> = { extreme: "极端", watch: "观察", normal: "正常", unavailable: "不可评估" };
export const comparisonReason = (comparison: Comparison) => comparison.status === "available" ? "比较窗口完整" : comparison.missing_reason || comparison.status || "比较数据未提供";
export const missingFactReason = (status?: string) => {
  const normalized = status?.trim().toLowerCase();
  if (!normalized) return "无事实";
  if (["null", "source_null", "field_null"].includes(normalized)) return "源字段 NULL";
  if (["failed", "error", "query_failed"].includes(normalized)) return "查询失败";
  if (["not_applicable", "out_of_scope", "unsupported"].includes(normalized)) return "范围不适用";
  if (["unknown", "unverified"].includes(normalized)) return "状态未知";
  return status || "无事实";
};
export const metricFact = (value: number | null | undefined, status?: string) => value == null ? `—（${missingFactReason(status)}）` : metric(value);
export const semanticsLabelFact = (label?: string, status?: string) => {
  if (label?.trim()) return label.trim();
  if (status === "source_empty" || status === "backfilled_source_empty") return "源字段为空";
  if (status === "field_not_returned" || status === "backfilled_field_not_returned") return "本次源响应未返回该字段";
  if (status === "legacy_not_captured" || !status) return "历史事件未采集该字段";
  return `暂不可用（${status}）`;
};
export const riskGrowth = (row: ReadRow) => row.comparison.increase_fact?.value ?? row.comparison.ccr_growth_pct;
export const riskGrowthLabel = (row: ReadRow) => row.program === "ST" ? "QoQ CCR Increase" : "WoW CCR Increase";
export const riskGrowthReason = (row: ReadRow) => {
  if (row.comparison.status === "incompatible_legacy_grain") return row.comparison.missing_reason || "旧记录粒度不兼容";
  if ((row.comparison.increase_fact?.value != null || row.comparison.ccr_growth_pct != null) && row.comparison.status === "available") return row.program === "ST" ? "业务锚点前后各 3 个月整窗原生聚合" : "业务锚点前后各 7 日整窗原生聚合";
  if (row.comparison.wow_ccr_growth_pct != null) return "旧批次自然周口径，不可作为 CCR Increase";
  return row.comparison.missing_reason || row.comparison.status || "CCR Increase 不可用";
};
export const entityGrain = (row: ReadRow) => row.program === "THT" ? "Advertiser Level" : "Account Level";
export const eventAnchor = (row: ReadRow) => row.comparison.event_anchor || row.event_anchor || "—（事件锚点未提供）";
