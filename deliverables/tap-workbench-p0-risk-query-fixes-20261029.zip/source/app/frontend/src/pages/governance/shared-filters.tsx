import { Checkbox, DatePicker, Input, Radio, Select } from "@arco-design/web-react";
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type BatchOption = {
  batch_id: string;
  week_name: string;
  generated_at: string;
  metric_start_date: string;
  metric_end_date: string;
  status: string;
  completeness: string;
};

export type SharedFilters = {
  time_mode: "weekly" | "history" | "custom"; // custom is accepted only for legacy deep links/tests
  batch_id: string;
  start_date: string;
  end_date: string; // legacy deep-link state; intentionally ignored
  tier: string;
  region: string;
  submitter: string;
  search: string;
  only_mine: boolean;
  protection_start_date?: string;
  protection_end_date?: string;
  include_anchor_anomalies?: boolean;
  alert_start_date: string; // legacy deep-link state; ignored
  alert_end_date: string; // legacy deep-link state; ignored
  alert_level: string;
  status: string;
};

const emptyFilters: SharedFilters = {
  time_mode: "weekly", batch_id: "", start_date: "", end_date: "", tier: "all", region: "all",
  submitter: "", search: "", only_mine: false,
  protection_start_date: "", protection_end_date: "", include_anchor_anomalies: false,
  alert_start_date: "", alert_end_date: "", alert_level: "all", status: "all",
};
const persistedKeys: (keyof SharedFilters)[] = ["time_mode", "batch_id", "tier", "region", "submitter", "search", "only_mine", "protection_start_date", "protection_end_date", "include_anchor_anomalies", "alert_level", "status"];
const FilterContext = createContext<{ filters: SharedFilters; setFilters: (value: SharedFilters) => void; clear: () => void }>({ filters: emptyFilters, setFilters: () => undefined, clear: () => undefined });

function fromUrl(): SharedFilters {
  const params = new URLSearchParams(location.search);
  const legacyTier = params.get("tier") || params.get("program") || "all";
  return {
    ...emptyFilters,
    time_mode: ["history", "custom"].includes(params.get("time_mode") || "") ? "history" : "weekly",
    batch_id: params.get("batch_id") || "",
    start_date: params.get("start_date") || "",
    end_date: params.get("end_date") || "",
    tier: ["ET", "THT", "ST"].includes(legacyTier) ? legacyTier : "all",
    region: params.get("region") || "all",
    submitter: params.get("submitter") || "",
    search: params.get("search") || "",
    only_mine: params.get("only_mine") === "true",
    protection_start_date: params.get("protection_start_date") || "",
    protection_end_date: params.get("protection_end_date") || "",
    include_anchor_anomalies: params.get("include_anchor_anomalies") === "true",
    alert_start_date: params.get("alert_start_date") || "",
    alert_end_date: params.get("alert_end_date") || "",
    alert_level: params.get("alert_level") || "all",
    status: params.get("status") || "all",
  };
}

export function filterQuery(filters: SharedFilters, extra: Record<string, unknown> = {}) {
  const query: Record<string, unknown> = {
    time_mode: "weekly",
    batch_id: filters.batch_id || undefined,
    program: filters.tier === "all" ? undefined : filters.tier,
    region: filters.region === "all" ? undefined : filters.region,
    submitter: filters.submitter || undefined,
    search: filters.search || undefined,
    only_mine: filters.only_mine || undefined,
    protection_start_date: filters.protection_start_date || undefined,
    protection_end_date: filters.protection_end_date || undefined,
    include_anchor_anomalies: filters.include_anchor_anomalies || undefined,
    alert_level: filters.alert_level === "all" ? undefined : filters.alert_level,
    status: filters.status === "all" ? undefined : filters.status,
    ...extra,
  };
  return Object.fromEntries(Object.entries(query).filter(([, value]) => value !== "" && value !== undefined && value !== null));
}

export function SharedFilterProvider({ children }: { children: ReactNode }) {
  const [filters, setFilters] = useState(fromUrl);
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    ["view", "program", "owner", "advertiser_id", "account_id", "mine", "start_date", "end_date", "date_field", "alert_start_date", "alert_end_date"].forEach((key) => { params.delete(key); });
    persistedKeys.forEach((key) => {
      const value = filters[key];
      const isDefault = value === emptyFilters[key];
      if (isDefault) params.delete(key);
      else params.set(key, String(value));
    });
    history.replaceState(null, "", `${location.pathname}${params.size ? `?${params}` : ""}`);
  }, [filters]);
  return <FilterContext.Provider value={{ filters, setFilters, clear: () => setFilters(emptyFilters) }}>{children}</FilterContext.Provider>;
}
export function useSharedFilters() { return useContext(FilterContext); }

export function SharedFilterBar({ batches = [], availableSubmitters = [], availableRegions = [], riskOnly = false, availableStatuses }: {
  riskOnly?: boolean;
  availableStatuses?: string[];
  batches?: BatchOption[];
  availableSubmitters?: string[];
  availableRegions?: string[];
}) {
  const { filters, setFilters, clear } = useSharedFilters();
  const update = <K extends keyof SharedFilters>(key: K, value: SharedFilters[K]) => setFilters({ ...filters, [key]: value });
  const selectedBatch = batches.find((item) => item.batch_id === filters.batch_id) || batches[0];
  const activeCount = useMemo(() => [
    filters.tier !== "all",
    filters.region !== "all",
    !!filters.submitter,
    !!filters.search,
    filters.only_mine,
    !!filters.protection_start_date,
    !!filters.protection_end_date,
    filters.include_anchor_anomalies,
    filters.alert_level !== "all",
    filters.status !== "all",
  ].filter(Boolean).length, [filters]);
  return <section className="ops-filter" aria-label="四页共享筛选" data-testid="shared-filter-bar">
    <div className="ops-filter-time">
      <Radio.Group type="button" value={filters.time_mode} onChange={(value) => setFilters({ ...filters, time_mode: value, batch_id: value === "weekly" ? "" : (filters.batch_id || batches[1]?.batch_id || batches[0]?.batch_id || "") })} aria-label="时间模式">
        <Radio value="weekly">最新一周</Radio><Radio value="history">历史周度</Radio>
      </Radio.Group>
      {filters.time_mode === "history" && <Select aria-label="历史周度批次" value={filters.batch_id || selectedBatch?.batch_id || ""} placeholder="暂无历史批次" disabled={!batches.length} onChange={(value) => update("batch_id", value)}>
        {batches.map((batch) => <Select.Option value={batch.batch_id} key={batch.batch_id}>{batch.week_name} · {batch.metric_start_date}—{batch.metric_end_date}</Select.Option>)}
      </Select>}
      <details className="ops-time-details"><summary>查看时间口径</summary><div className="ops-time-meta" data-testid="time-status">{selectedBatch ? <><b>{filters.time_mode === "weekly" ? `最新权威批次 · ${selectedBatch.week_name}` : selectedBatch.week_name}</b><span>生成 {selectedBatch.generated_at || "—"} · 完整保存窗口 {selectedBatch.metric_start_date} 至 {selectedBatch.metric_end_date}</span></> : <b>暂无历史批次</b>}</div></details>
    </div>
    <div className="ops-filter-fields"><span className="ops-filter-label">筛选范围</span>
      <Select aria-label="共享 Tier" value={filters.tier} onChange={(value) => update("tier", value)}><Select.Option value="all">全部 Tier</Select.Option>{["ET", "THT", "ST"].map((value) => <Select.Option key={value} value={value}>{value}</Select.Option>)}</Select>
      <Select aria-label="共享 Region" value={filters.region} onChange={(value) => update("region", value)} showSearch><Select.Option value="all">全部 Region</Select.Option>{availableRegions.map((value) => <Select.Option key={value} value={value}>{value}</Select.Option>)}</Select>
      <Select aria-label="共享提报人" value={filters.submitter || undefined} onChange={(value) => update("submitter", value)} allowClear showSearch placeholder="全部原提报人">{availableSubmitters.map((value) => <Select.Option key={value} value={value}>{value}</Select.Option>)}</Select>
      <Select aria-label="预警等级" value={filters.alert_level} onChange={(value) => update("alert_level", value)}><Select.Option value="all">全部预警等级</Select.Option><Select.Option value="critical">高风险</Select.Option><Select.Option value="watch">观察</Select.Option>{!riskOnly && <Select.Option value="normal">正常</Select.Option>}</Select>
      <Select aria-label="当前状态" value={filters.status} onChange={(value) => update("status", value)}><Select.Option value="all">全部状态</Select.Option>{(riskOnly && availableStatuses ? availableStatuses : ["open","processing","observing","pending_approval","pending_review","closed"]).map(value => <Select.Option key={value} value={value}>{{open:"待接单 / 未建单",processing:"处理中",observing:"持续观察",pending_approval:"待审批",pending_review:"待复核",closed:"已关闭"}[value] || value}</Select.Option>)}</Select>
      <DatePicker.RangePicker aria-label="保护开始时间" value={filters.protection_start_date && filters.protection_end_date ? [filters.protection_start_date, filters.protection_end_date] : undefined} onChange={(dates) => setFilters({ ...filters, protection_start_date: dates?.[0] || "", protection_end_date: dates?.[1] || "" })} placeholder={["保护开始日期", "保护结束日期"]} />
      <Checkbox aria-label="包含时间异常" checked={filters.include_anchor_anomalies} onChange={(checked) => update("include_anchor_anomalies", checked)}>包含时间异常</Checkbox>
      <Input.Search aria-label="共享客户搜索" value={filters.search} onChange={(value) => update("search", value)} allowClear placeholder="Account / Adv ID / 客户名称" />
      <Checkbox aria-label="只看我的" checked={filters.only_mine} onChange={(checked) => update("only_mine", checked)}>只看我的</Checkbox>
      <button className="ops-text-button" type="button" onClick={clear} disabled={!activeCount && filters.time_mode === "weekly"}>清空筛选{activeCount ? ` (${activeCount})` : ""}</button>
    </div>
    {riskOnly && <p className="ops-filter-note">仅读取保存的周度预警。比较锚点：ET 为提报创建时间，THT 为保护开始时间，ST 为名单开始日期。</p>}
    {filters.only_mine && <p className="ops-filter-note" title="当前身份由后端关联">仅向后端传递 only_mine；身份关联由已验证人员映射完成，前端不猜测姓名或邮箱。</p>}
  </section>;
}
