# TAP 风险扫描 P0 修复源码交接包

这是供 AIME **增量合入并重新构建**的源码补丁，不是可直接上传覆盖 App 的整包。
目标 App：`app_e5d1388d65ef1b49`。基线为用户本次上传的同名 ZIP，准确 SHA256 见 manifest.json。

将 ZIP 和《交给AIME执行.md》一起交给 AIME；以当前成功工作台为底版合并，不能覆盖后续改动。

本次：关键指标先行、先保存风险再补明细；互斥三分类；卡片/列表同范围；真实筛选与历史读取；独立 SQLite 扫描归档；Quota 复用 Cloud Case/Regional POC/原通知流程。

不包含：旧二进制、dist、app.json、生产数据库、凭证、日志、浏览器示例数据或替代私有 SDK。

本地验证不能替代真实源端验证：没有风神/Cloud/飞书真实凭证，未运行生产全量扫描、未发送消息、未发布 ONLINE。完整原生前端构建及真实数据验收须由 AIME 完成。

文件：source/ 为变更源码；p0-fixes.patch 为同一变更的补丁（两者任选一种合入）；manifest.json 为校验；validation.json 为验证范围；审计说明解释规则及限制；screenshots/ 仅界面测试，已标明示例响应。
