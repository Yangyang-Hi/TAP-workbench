这是给 Amy 审查并合并到最新主工作台的源码差异包，不是 AIME 安装包。
安装请使用 tap-overview-dashboard-v6-app_55cc4d81544026ab.zip。
integration.diff 不包含测试 App 身份、隔离运行配置、编译产物；generated-reference.diff 仅供参考，客户端应按当前主分支 IDL 重新生成。
请先阅读 docs/overview/合并到主工作台.md。
