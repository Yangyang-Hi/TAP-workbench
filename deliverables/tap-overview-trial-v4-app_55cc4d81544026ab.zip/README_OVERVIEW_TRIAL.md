> v4 打包修正：已补齐与当前测试 App 匹配的 app.json.id；本次未修改图表代码、取数逻辑或二进制。

# Account Tier 分布：新 AIME App 验证指南

## 本次交付范围

仅首个图表：ST/HT/BT/ET Account 数量及占比，环形图和明细表。支持截止日期与 Sales Region，显式点击“应用筛选”后查询。默认截止日期按 Asia/Shanghai 动态计算。

来源为 iDA 迁移说明中的 App 800414 / SID 1280034 / RID 2891943。用现有 ByteCloud JWT → Titan → Saved Report reqJson → VQS 链路，不使用截图、演示数据或手写 SQL。字段 ID、Region 枚举和账户指标别名来自迁移文档，尚未完成企业风神真实对拍。

## 给 AIME 的执行说明

本包已绑定用户新建的测试 App **app_55cc4d81544026ab**，用于该 App 的“本地开发入口 → ZIP 包 → 上传修改后的代码”。不要上传到原 app_e5d1388d65ef1b49。

1. 确认当前页面的应用 ID 为 app_55cc4d81544026ab，直接上传本 ZIP。app.json 已填入匹配 ID，无需手动编辑；平台将按该入口的规则备份并覆盖这个测试 App。
2. 保留新 App 平台分配的实例、服务及权限配置。不要复制原 App 的数据库、凭证、业务记录、Bot 设置或持久化目录。
3. 测试包服务命令已经设置 `TAP_OVERVIEW_ONLY=1`。此模式只挂载账户分布、当前用户身份和静态页面，不初始化 Casework Cloud DB、不启动扫描调度、不启动通知 worker，也不开放处置或通知接口。
4. 包内包含本次重建的 `app/server-go/bin/server` 和独立的 `app/overview-dist`。不携带 `.aime_build` 旧二进制。如果平台要求重新构建，Go 命令见下文；不要让原应用的旧二进制覆盖新产物。
5. `app/server-go/start.sh` 运行时应位于新 App 上下文。`AIME_APP_INSTANCE_ID` 必须由新 App 平台注入，不能复制原 App 实例标识。访问仍经过原平台鉴权，没有登录绕过。
6. 为新 App 确认原有 ByteCloud/Titan/风神授权与网络访问。代码复用鉴权实现，不意味着新 App 自动继承原 App 权限。若源查询需要额外运行配置，请在新 App 安全设置中配置，不把秘密写入源码或聊天。
7. 开启页面，先执行 Global 截止日快照查询，再执行 APAC。与同条件 RID 2891943 对拍并记录实际快照日、四 Tier 原始值、占比、request_id/audit_id；失败时提供脱敏诊断。
8. 在 AIME 测试通过前，不发布到原线上应用。此包只验证一个图表，不代表整个数据总览或风险数据已经接通。

测试包 app.json 使用原平台结构，绑定测试 App ID app_55cc4d81544026ab，移除了旧 App 导航目标与原 CLI Skill 注册，并切为仅总览服务模式。本包只能覆盖此 ID 对应的测试 App；其他 App 需要重新匹配 ID 后打包。

## 启动和构建

工作目录：项目根目录。

```sh
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -mod=readonly -buildvcs=false -trimpath -ldflags='-s -w' -o app/server-go/bin/server ./app/server-go
TAP_BUILD_NODE_MODULES=/absolute/path/to/node_modules node tools/build_overview_trial.mjs
```

`TAP_BUILD_NODE_MODULES` 不设置时使用 `app/frontend/node_modules`。独立构建脚本仅输出 `app/overview-dist`，不会改写原 `app/dist`。它沿用上传包的 ByteCloud 认证运行库，不使用认证替身。

新 App 的服务命令：

```sh
cd app/server-go && TAP_OVERVIEW_ONLY=1 bash start.sh
```

页面根路径会进入 `/?view=overview`。独立模式服务使用 `app/overview-dist`。

## 取数与缺失处理

- 逐日查询截止日、截止日前1日……前13日，取首个返回记录的快照。不会累加每日账户数量，也不访问未来快照。
- 最新非空结果缺失 Tier 时显示部分结果，不回退旧的“更好看”结果；四 Tier 不全、数量无效、重复聚合行、截断或合计为0时不生成占比。
- 每 Tier 仅接受一行；保留 Saved Report 的原指标定义。未确认账户是否可跨 Tier 重复，所以只称“四 Tier 数量合计”，不称跨 Tier 去重客户总数。
- 本图不接收 Program、Submitter 或账户ID过滤，始终展示完整四 Tier。请求范围与页面回显一致。编辑条件会取消旧请求，旧响应不能覆盖新结果。
- 原始固定过滤保留；仅替换本图需要的日期、Region UI 条件和完整四 Tier 条件。真实 Saved Report 缺少文档所给字段时明确阻断，不猜新字段ID。
- 不做跨用户共享缓存。查询诊断只回显受控字段，不向前端返回 JWT、Titan Token、SQL 正文或完整源响应。

## 真实验收清单

- 新 App 登录及访问权限正常，无法登录者不能查询账户数据。
- Global 和指定 Region 的 Account 数与同条件风神一致，快照日不晚于截止日。
- 修改日期或Region后必须应用；修改Program/Submitter不裁剪此图。
- 缺失、无数据、权限失败与真实0的页面状态不同。
- 桌面、手机无页面级横向溢出。
- 确认没有风险扫描、建Case、数据库迁移、通知发送或后台调度。

## 集成回原工作台

请在试验通过后单独审查 `OVERVIEW_CHANGE_MANIFEST.json` 和集成补丁。完整工作台源码已在第一页挂载图表，并保留独立 `view=overview` 路由。默认完整启动逻辑未改，只有显式 `TAP_OVERVIEW_ONLY=1` 才进入隔离模式。

试验包的 app.json 不能覆盖原应用 app.json。包内原 `app/dist` 仅为上传版本保留产物；完整工作台新增入口需要在有企业依赖的环境重新构建，不能将独立 `overview-dist` 当作整个工作台产物。

当前既有“风险状态、列表与统计的一致性”等问题不在本次修复范围。没有修改事件状态机、飞书发送、业务规则或原数据源配置。
