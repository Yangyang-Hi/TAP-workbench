package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const partialCoverageMessage = "Partial：当前覆盖2026-09-10～2026-09-27，QTD仍有71个日窗未完成。"

type fileImportManifest struct {
	Status     string `json:"status"`
	Submission struct {
		CompletedDateCount int `json:"completed_date_count"`
		RemainingDateCount int `json:"remaining_date_count"`
		RowCount           int `json:"row_count"`
	} `json:"submission"`
	Protection struct {
		RowCount int `json:"row_count"`
	} `json:"protection"`
}

func decodeJSONRows(path string) ([]map[string]any, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	dec := json.NewDecoder(f)
	dec.UseNumber()
	var rows []map[string]any
	if err = dec.Decode(&rows); err != nil {
		return nil, err
	}
	return rows, nil
}

func approvedResult(row map[string]any) bool {
	v := strings.ToUpper(strings.TrimSpace(asString(row["final_result"])))
	return v == "APPROVE" || v == "PASS"
}

func importBundledFileSnapshots() error {
	dir := filepath.Join(pluginDir, "app", "data", "file_import")
	var manifest fileImportManifest
	b, err := os.ReadFile(filepath.Join(dir, "manifest.json"))
	if err != nil {
		return err
	}
	if err = json.Unmarshal(b, &manifest); err != nil {
		return err
	}
	submission, err := decodeJSONRows(filepath.Join(dir, "submission_qtd_partial.json"))
	if err != nil {
		return err
	}
	protection, err := decodeJSONRows(filepath.Join(dir, "protection_qtd_partial.json"))
	if err != nil {
		return err
	}
	if len(submission) != 495 || manifest.Submission.RowCount != 495 || manifest.Submission.CompletedDateCount != 18 || manifest.Submission.RemainingDateCount != 71 {
		return fmt.Errorf("submission file integrity failed")
	}
	if len(protection) != 89 || manifest.Protection.RowCount != 89 {
		return fmt.Errorf("protection file integrity failed")
	}
	seenSubmission, seenProtection := map[string]bool{}, map[string]bool{}
	for i, row := range submission {
		row = normalizeDetailRow(row)
		id := asString(row["ticket_id"])
		if id == "" || seenSubmission[id] {
			return fmt.Errorf("submission duplicate/empty ticket_id at row %d", i)
		}
		seenSubmission[id] = true
		submission[i] = row
	}
	results := map[string]int{}
	now := time.Now()
	active, approvedAdvertisers, expired, over14 := 0, map[string]bool{}, 0, 0
	for i, row := range protection {
		row = normalizeDetailRow(row)
		id := asString(row["ticket_id"])
		if id == "" || seenProtection[id] {
			return fmt.Errorf("protection duplicate/empty ticket_id at row %d", i)
		}
		seenProtection[id] = true
		if row["program_type"] != "THT" {
			return fmt.Errorf("protection row %d is not explicit THT", i)
		}
		result := strings.ToUpper(asString(row["final_result"]))
		results[result]++
		approved := approvedResult(row)
		start, startOK := parseDate(row["protection_starttime"])
		end, endOK := parseDate(row["protection_endtime"])
		effective := approved && startOK && endOK && !now.Before(start) && !now.After(end)
		row["effective_active"] = effective
		if effective {
			active++
		}
		if approved {
			approvedAdvertisers[asString(row["advertiser_id"])] = true
			if endOK && now.After(end) {
				expired++
			}
			if startOK && endOK && end.Sub(start) > 14*24*time.Hour {
				over14++
			}
		}
		protection[i] = row
	}
	if results["APPROVE"] != 57 || results["REJECT"] != 32 || len(approvedAdvertisers) != 52 || active < 5 || active > 7 {
		return fmt.Errorf("protection metric integrity failed: approve=%d reject=%d advertisers=%d active=%d", results["APPROVE"], results["REJECT"], len(approvedAdvertisers), active)
	}
	cfg, err := loadDataSourceConfig()
	if err != nil {
		return err
	}
	importedAt := time.Now().UTC().Format(time.RFC3339)
	coverage := map[string]any{"start_date": "2026-09-10", "end_date": "2026-09-27", "completed_windows": 18, "remaining_windows": 71, "message": partialCoverageMessage}
	makeSnap := func(name string, rid int, rows []map[string]any, complete bool, completeness string) sourceSnapshot {
		s := cfg.Sources[name]
		return sourceSnapshot{Source: name, Kind: "detail", Grain: "ticket", Mode: "file_import", Status: strings.ToLower(completeness), ReportID: rid, DatasetID: 1198629, IdentityKey: sourceIdentityKey(s), DataAsOf: "2026-09-27", DataAsOfCanonical: "2026-09-27", QueriedAt: importedAt, LastSuccessAt: importedAt, RowCount: len(rows), RowCountCanonical: len(rows), SourceRID: rid, Complete: complete, Partial: !complete, RuntimeReady: true, SourceType: "file_import", ImportedAt: importedAt, Coverage: coverage, Completeness: completeness, BusinessPayload: buildBusinessPayload(name, rows), RawSchema: map[string]any{"format": "json", "primary_key": "ticket_id"}}
	}
	stateMu.Lock()
	defer stateMu.Unlock()
	path, err := snapshotPath()
	if err != nil {
		return err
	}
	st := emptySnapshotState()
	if raw, readErr := os.ReadFile(path); readErr == nil {
		_ = json.Unmarshal(raw, &st)
		initializeSnapshotState(&st)
	}
	st.DetailSources["submission_detail"] = submission
	st.DetailSources["protection"] = protection
	st.DetailSources["tht_detail"] = protection
	st.Business["submission_detail"] = makeSnap("submission_detail", 2933760, submission, false, "Partial")
	protectionSnap := makeSnap("protection", 2933751, protection, true, "Complete")
	protectionSnap.Coverage = map[string]any{"start_date": "2026-07-01", "end_date": "2026-09-27", "scope": "exact_THT_program_QTD", "message": "Complete：THT Protection QTD"}
	protectionSnap.BusinessPayload["approved"] = 57
	protectionSnap.BusinessPayload["rejected"] = 32
	protectionSnap.BusinessPayload["effective_active"] = active
	protectionSnap.BusinessPayload["expired"] = expired
	protectionSnap.BusinessPayload["over_14_days"] = over14
	protectionSnap.BusinessPayload["approved_distinct_advertisers"] = 52
	st.Business["protection"] = protectionSnap
	thtSnap := protectionSnap
	thtSnap.Source = "tht_detail"
	thtSnap.IdentityKey = sourceIdentityKey(cfg.Sources["tht_detail"])
	st.Business["tht_detail"] = thtSnap
	st.UpdatedAt["submission_detail"], st.UpdatedAt["protection"], st.UpdatedAt["tht_detail"] = importedAt, importedAt, importedAt
	encoded, err := json.MarshalIndent(st, "", "  ")
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err = os.WriteFile(tmp, encoded, 0600); err != nil {
		return err
	}
	if err = os.Rename(tmp, path); err != nil {
		return err
	}
	snapshotCacheMu.Lock()
	snapshotCacheValid = false
	snapshotCacheMu.Unlock()
	return nil
}
