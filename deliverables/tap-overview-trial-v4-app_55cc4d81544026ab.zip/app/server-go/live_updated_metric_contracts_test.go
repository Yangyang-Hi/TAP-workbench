package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// TestLiveUpdatedMetricContracts is opt-in and read-only. It verifies the new
// Account authorities and the S05/S07 Advertiser path without deploying or
// sending notifications. Supply known IDs so no membership source can expand M.
func TestLiveUpdatedMetricContracts(t *testing.T) {
	if os.Getenv("RUN_LIVE_UPDATED_METRIC_CONTRACTS") != "1" {
		t.Skip("set RUN_LIVE_UPDATED_METRIC_CONTRACTS=1 for read-only S05/S06/S07/S08 verification")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	accountID := os.Getenv("LIVE_ACCOUNT_ID")
	advertiserID := os.Getenv("LIVE_THT_ADVERTISER_ID")
	if jwt == "" || !decimalID.MatchString(accountID) || !decimalID.MatchString(advertiserID) {
		t.Fatal("AIME_USER_CLOUD_JWT, LIVE_ACCOUNT_ID and LIVE_THT_ADVERTISER_ID are required")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())

	ctx, cancel := context.WithTimeout(context.Background(), 180*time.Second)
	defer cancel()
	req := httptest.NewRequest(http.MethodGet, "/api/live", nil)
	req.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	account, err := queryETCurrentBatch(ctx, req, []string{accountID}, "2026-10-12", "2026-10-18")
	if err != nil || account[accountID].Status == "" {
		t.Fatalf("S06/S08 query failed: metric=%+v err=%v", account[accountID], err)
	}
	advertiser, err := queryTHTCurrentBatch(ctx, req, []string{advertiserID}, "2026-10-12", "2026-10-18")
	advertiserPairs := advertiser[advertiserID]
	if err != nil || len(advertiserPairs) == 0 || advertiserPairs[0].Status == "" {
		t.Fatalf("S05/S07 query failed: metrics=%+v err=%v", advertiserPairs, err)
	}
	t.Logf("account_status=%s account_revenue_status=%s advertiser_pairs=%d advertiser_status=%s advertiser_revenue_status=%s account_request=%s advertiser_request=%s", account[accountID].Status, account[accountID].RevenueStatus, len(advertiserPairs), advertiserPairs[0].Status, advertiserPairs[0].RevenueStatus, account[accountID].RequestID, advertiserPairs[0].RequestID)
}
