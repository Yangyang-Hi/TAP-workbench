package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
)

func TestReportVersionsAreImmutableAndRepeatedGenerationUsesNewIDs(t *testing.T) {
	id1, e := newReportID()
	if e != nil {
		t.Fatal(e)
	}
	id2, e := newReportID()
	if e != nil {
		t.Fatal(e)
	}
	if id1 == id2 || !strings.HasPrefix(id1, "rpt_") {
		t.Fatalf("IDs must be random and distinct: %q %q", id1, id2)
	}
	var mu sync.Mutex
	versionRecords := []map[string]any{}
	chunkRecords := []map[string]any{}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		isChunks := strings.Contains(r.URL.Path, "/tables/"+reportContentChunksTable+"/")
		if r.Method == http.MethodPost && strings.HasSuffix(r.URL.Path, "/records") {
			var body map[string]any
			_ = json.NewDecoder(r.Body).Decode(&body)
			if isChunks {
				chunkRecords = append(chunkRecords, body)
			} else {
				versionRecords = append(versionRecords, body)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"code": 0, "data": body})
			return
		}
		if r.Method == http.MethodPost && strings.HasSuffix(r.URL.Path, "/query") {
			var q struct {
				Filters []struct {
					Value string `json:"value"`
				} `json:"filters"`
			}
			_ = json.NewDecoder(r.Body).Decode(&q)
			found := []map[string]any{}
			source := versionRecords
			if isChunks {
				source = chunkRecords
			}
			for _, v := range source {
				if len(q.Filters) > 0 && v["report_id"] == q.Filters[0].Value {
					found = append(found, v)
				}
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"code": 0, "data": map[string]any{"records": found}})
			return
		}
		http.Error(w, "unexpected", 500)
	}))
	defer srv.Close()
	store := &cloudStore{baseURL: srv.URL, appID: "app", apiKey: "key"}
	ctx := context.Background()
	first := reportVersion{ReportID: id1, Version: id1, Owner: "owner", CreatedAt: "2026-10-26T05:00:00Z", GeneratedAt: "2026-10-26T05:00:00Z", DataAsOf: "2026-10-26T04:59:00Z", FiltersJSON: "{}", ContentHTML: "<html>old</html>", ContentHash: "old", Title: "report", Period: "p"}
	second := first
	second.ReportID = id2
	second.Version = id2
	second.ContentHTML = "<html>new</html>"
	second.ContentHash = "new"
	if e = insertReportVersion(ctx, store, first); e != nil {
		t.Fatal(e)
	}
	if e = insertReportVersion(ctx, store, second); e != nil {
		t.Fatal(e)
	}
	old, e := getReportVersion(ctx, store, id1)
	if e != nil {
		t.Fatal(e)
	}
	if old.ContentHTML != "<html>old</html>" || len(versionRecords) != 2 {
		t.Fatalf("old version changed or record overwritten: %+v", old)
	}
}

func TestReportCloudFailureDoesNotFallback(t *testing.T) {
	t.Setenv("DB_APP_ID", "")
	t.Setenv("DB_API_KEY", "")
	if _, err := reportCloudStore(); err == nil || !strings.Contains(err.Error(), "Cloud DB 不可用") {
		t.Fatalf("expected honest cloud error, got %v", err)
	}
}
