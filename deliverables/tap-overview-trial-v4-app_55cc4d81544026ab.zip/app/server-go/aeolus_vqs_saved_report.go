package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

// probeSavedReportRequest retrieves the executable reqJson directly from the
// Saved Report. It deliberately does not call Glue to_simple_chart.
func probeSavedReportRequest(ctx context.Context, host, titanToken string, reportID int) (map[string]any, map[string]any, titanProbeStep) {
	endpoint, _ := url.Parse(strings.TrimRight(host, "/") + aeolusSavedReportPath)
	q := endpoint.Query()
	q.Set("reportId", strconv.Itoa(reportID))
	endpoint.RawQuery = q.Encode()
	step := titanProbeStep{Status: "failed", RequestURL: endpoint.String(), ReportID: reportID, TestedAt: time.Now().UTC().Format(time.RFC3339)}
	resp, raw, err := titanRequest(ctx, http.MethodGet, endpoint.String(), titanToken, nil)
	if err != nil {
		step.ErrorType, step.ErrorMessage = "network_error", sanitizeLogText(err.Error())
		return nil, nil, step
	}
	step.HTTPStatus = resp.StatusCode
	step.RequestID = resp.Header.Get("x-request-id")
	step.LogID = resp.Header.Get("x-tt-logid")
	step.ResponseContentType = resp.Header.Get("Content-Type")
	step.ResponsePreview = sanitizeLogText(truncateForLog(string(raw), 300))
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		step.ErrorType, step.ErrorMessage = "http_error", fmt.Sprintf("saved report metadata returned HTTP %d", resp.StatusCode)
		return nil, nil, step
	}
	var parsed any
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	if err := decoder.Decode(&parsed); err != nil {
		step.ErrorType, step.ErrorMessage = "non_json_response", "saved report metadata returned non-JSON response"
		return nil, nil, step
	}
	req := findExecutableReqJSON(parsed)
	if req == nil {
		step.ErrorType, step.ErrorMessage = "missing_req_json", "saved report metadata missing executable reqJson.query"
		return nil, nil, step
	}
	chart := findSavedReportChart(req)
	if chart == nil {
		// The query itself is still the authoritative field contract when the
		// report does not carry a separate chart wrapper.
		chart, _ = req["query"].(map[string]any)
	}
	if chart == nil {
		step.ErrorType, step.ErrorMessage = "missing_chart_schema", "saved report reqJson missing query schema"
		return nil, nil, step
	}
	step.Status, step.SimpleChartObtained, step.ResponsePreview = "passed", true, ""
	return req, chart, step
}

func findExecutableReqJSON(value any) map[string]any {
	var walk func(any) map[string]any
	walk = func(current any) map[string]any {
		switch node := current.(type) {
		case string:
			var decoded any
			if json.Unmarshal([]byte(strings.TrimSpace(node)), &decoded) == nil {
				return walk(decoded)
			}
		case map[string]any:
			if query, ok := node["query"].(map[string]any); ok && query != nil {
				return cloneMap(node)
			}
			for _, key := range []string{"reqJson", "requestJson", "data"} {
				if child, ok := node[key]; ok {
					if found := walk(child); found != nil {
						return found
					}
				}
			}
			for _, child := range node {
				if found := walk(child); found != nil {
					return found
				}
			}
		case []any:
			for _, child := range node {
				if found := walk(child); found != nil {
					return found
				}
			}
		}
		return nil
	}
	return walk(value)
}

// savedReportVQSRequest preserves the raw request and replaces only governed
// where predicates using the already-validated chart filters.
func savedReportVQSRequest(raw, sentChart map[string]any, source sourceConfig, f filterRequest, ids []string, idDimension string) (map[string]any, error) {
	body := cloneMap(raw)
	query, ok := body["query"].(map[string]any)
	if !ok {
		return nil, fmt.Errorf("reqJson.query is not an object")
	}
	filters, _ := sentChart["filters"].([]any)
	where, _ := query["whereList"].([]any)
	for _, rawFilter := range filters {
		filter, ok := rawFilter.(map[string]any)
		if !ok {
			continue
		}
		fieldID := firstNonEmpty(filter, "datasetFieldId", "dimMetId", "fieldId", "id")
		if fieldID == "" {
			continue
		}
		legacy := chartFilterToVQSWhere(filter, fieldID)
		replaced := false
		for i, existing := range where {
			node, _ := existing.(map[string]any)
			if firstNonEmpty(node, "id", "datasetFieldId", "fieldId", "originId") == fieldID {
				where[i], replaced = legacy, true
			}
		}
		if !replaced {
			where = append(where, legacy)
		}
	}
	query["whereList"] = where
	// The executable Saved Report request is authoritative for dataset and joins,
	// while the governed detail profile is authoritative for the projected fields.
	// Copy the temporary detail dimensions into VQS so required identities (for
	// example ET ticket_id) are actually returned without modifying the report.
	if dimensions, ok := sentChart["dimensions"].([]any); ok && len(dimensions) > 0 {
		query["dimensions"] = dimensions
		fieldIDs := make([]any, 0, len(dimensions))
		for _, raw := range dimensions {
			if dimension, ok := raw.(map[string]any); ok {
				if fieldID := firstNonEmpty(dimension, "datasetFieldId", "dimMetId", "id", "originId"); fieldID != "" {
					fieldIDs = append(fieldIDs, fieldID)
				}
			}
		}
		query["groupByIdList"] = fieldIDs
		if locations, ok := query["locations"].(map[string]any); ok {
			locations["dimensions"] = fieldIDs
			query["locations"] = locations
		}
		if schema, ok := query["schema"].(map[string]any); ok {
			schema["dimensions"] = mergeVQSSchemaDimensions(schema["dimensions"], dimensions)
			query["schema"] = schema
		}
		if schema, ok := body["schema"].(map[string]any); ok {
			schema["dimensions"] = mergeVQSSchemaDimensions(schema["dimensions"], dimensions)
			body["schema"] = schema
		}
	}
	query["limit"] = savedReportHardLimit
	delete(query, "paging")
	body["query"] = query
	body["reportId"] = source.RID
	body["liveResultFetch"] = true
	query["liveResultFetch"] = true
	if _, ok := body["version"]; !ok {
		body["version"] = 4
	}
	return body, nil
}

func mergeVQSSchemaDimensions(rawExisting any, projected []any) []any {
	existing, _ := rawExisting.([]any)
	out := append([]any{}, existing...)
	seen := map[string]bool{}
	for _, raw := range existing {
		if dimension, ok := raw.(map[string]any); ok {
			seen[firstNonEmpty(dimension, "dimMetId", "datasetFieldId", "id", "originId")] = true
		}
	}
	for _, raw := range projected {
		dimension, ok := raw.(map[string]any)
		if !ok {
			continue
		}
		fieldID := firstNonEmpty(dimension, "datasetFieldId", "dimMetId", "id", "originId")
		if fieldID == "" || seen[fieldID] {
			continue
		}
		uniqueID := firstNonEmpty(dimension, "uniqueId", "uniqueID")
		if uniqueID == "" {
			uniqueID = fieldID
		}
		out = append(out, map[string]any{
			"id": fieldID, "originId": fieldID, "dimMetId": fieldID,
			"uniqueId": uniqueID, "location": "dimensions", "type": "string",
			"isMetric": false, "roleType": 0, "index": len(out), "aggrConf": map[string]any{}, "format": map[string]any{},
		})
		seen[fieldID] = true
	}
	return out
}

func chartFilterToVQSWhere(filter map[string]any, fieldID string) map[string]any {
	where := map[string]any{"id": fieldID, "name": fieldID, "preRelation": "and", "option": map[string]any{"isReportFilter": true, "isWhereInAggr": true, "filterPattern": "Accurate"}, "valOption": map[string]any{}}
	detail, _ := filter["detail"].(map[string]any)
	if start, ok := detail["startTime"].(map[string]any); ok {
		end, _ := detail["endTime"].(map[string]any)
		where["op"] = "between"
		where["val"] = []any{firstNonEmpty(start, "date", "value"), firstNonEmpty(end, "date", "value")}
		return where
	}
	where["op"] = "in"
	if values, ok := detail["value"].([]string); ok {
		where["val"] = values
	} else if values, ok := detail["value"].([]any); ok {
		where["val"] = values
	} else {
		where["val"] = []any{detail["value"]}
	}
	return where
}

var needToQueueRetryDelay = 2 * time.Second

func probeVQS(ctx context.Context, host, titanToken string, appID, reportID int, body map[string]any) titanProbeStep {
	requestID := fmt.Sprintf("aeolus.vizQuery.aime.app_%d.report_%d.%d", appID, reportID, time.Now().UnixNano())
	endpoint := strings.TrimRight(host, "/") + aeolusVQSQueryPath + "?requestId=" + url.QueryEscape(requestID) + "&reportId=" + strconv.Itoa(reportID) + "&liveResultFetch=true"
	step := titanProbeStep{Status: "failed", RequestURL: endpoint, ReportID: reportID, TestedAt: time.Now().UTC().Format(time.RFC3339), RequestID: requestID}
	encoded, _ := json.Marshal(body)
	var parsed any
	for attempt := 1; attempt <= 20; attempt++ {
		req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(encoded))
		if err != nil {
			step.ErrorType, step.ErrorMessage = "request_build_error", err.Error()
			return step
		}
		req.Header.Set("x-titan-token", titanToken)
		req.Header.Set("x-app-id", strconv.Itoa(appID))
		req.Header.Set("x-request-id", requestID)
		req.Header.Set("request-id", requestID)
		req.Header.Set("Accept", "application/json, text/plain, */*")
		req.Header.Set("Content-Type", "application/json")
		resp, err := httpClient.Do(req)
		if err != nil {
			step.ErrorType, step.ErrorMessage = "network_error", sanitizeLogText(err.Error())
			return step
		}
		raw, readErr := io.ReadAll(resp.Body)
		resp.Body.Close()
		if readErr != nil {
			step.ErrorType, step.ErrorMessage = "read_error", sanitizeLogText(readErr.Error())
			return step
		}
		step.HTTPStatus = resp.StatusCode
		step.LogID = resp.Header.Get("x-tt-logid")
		if actual := resp.Header.Get("x-request-id"); actual != "" {
			step.RequestID = actual
		}
		step.ResponseContentType = resp.Header.Get("Content-Type")
		step.ResponsePreview = sanitizeLogText(truncateForLog(string(raw), 300))
		decoder := json.NewDecoder(bytes.NewReader(raw))
		decoder.UseNumber()
		if err := decoder.Decode(&parsed); err != nil {
			step.ErrorType, step.ErrorMessage = "non_json_response", "VQS returned non-JSON response"
			return step
		}
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			step.ErrorType, step.ErrorMessage = "http_error", fmt.Sprintf("VQS returned HTTP %d", resp.StatusCode)
			return step
		}
		if envelope, ok := parsed.(map[string]any); ok {
			step.GlueCode, step.GlueMessage = envelope["code"], firstNonEmpty(envelope, "msg", "message", "error")
			step.QueryHistoryID = firstDeepString(envelope, "queryHistoryId", "query_history_id", "historyId")
			step.SQL = firstDeepString(envelope, "sql", "querySql", "query_sql")
			code := strings.TrimSpace(asString(envelope["code"]))
			if code == "aeolus/performance/needToQueue" && attempt < 20 {
				step.QueuePollCount++
				select {
				case <-ctx.Done():
					step.ErrorType, step.ErrorMessage = "context_cancelled", ctx.Err().Error()
					return step
				case <-time.After(needToQueueRetryDelay):
					continue
				}
			}
			if code != "" && code != "0" && code != "success" && code != "aeolus/ok" {
				step.ErrorType, step.ErrorMessage = "vqs_business_error", "VQS returned non-success code: "+code
				return step
			}
		}
		break
	}
	rows := findRows(parsed)
	if rows == nil || len(rows) == 0 {
		if datasetRows := findVQSDatasetRows(parsed); datasetRows != nil {
			rows = datasetRows
		}
	}
	step.FieldMap = findQueryColumnMap(parsed)
	if rows == nil && hasExplicitZeroResult(parsed) {
		rows = []map[string]any{}
	}
	if rows == nil {
		step.ErrorType, step.ErrorMessage = "rows_not_found", "VQS response does not expose rows in a recognized shape; shape="+jsonShape(parsed, 0)
		return step
	}
	step.Rows, step.RowsCount = rows, len(rows)
	if len(rows) == 0 {
		step.Status = "passed"
		return step
	}
	step.SampleRows = rows[0]
	for key := range rows[0] {
		step.Columns = append(step.Columns, key)
	}
	step.Status, step.ResponsePreview = "passed", ""
	return step
}

func describeVQSFilters(body map[string]any) []map[string]any {
	out := []map[string]any{}
	query, _ := body["query"].(map[string]any)
	where, _ := query["whereList"].([]any)
	for _, item := range where {
		node, _ := item.(map[string]any)
		if node == nil {
			continue
		}
		out = append(out, map[string]any{"id": firstNonEmpty(node, "id", "datasetFieldId", "fieldId"), "name": firstNonEmpty(node, "name", "displayName", "datasetFieldName"), "op": node["op"], "val": node["val"]})
	}
	return out
}

func extractVQSPartition(body map[string]any) any {
	for _, filter := range describeVQSFilters(body) {
		name := strings.ToLower(asString(filter["name"]) + " " + asString(filter["id"]))
		if strings.Contains(name, "p_date") || strings.Contains(name, "partition") {
			return filter["val"]
		}
	}
	return nil
}

func jsonShape(value any, depth int) string {
	if depth > 4 {
		return "…"
	}
	switch node := value.(type) {
	case map[string]any:
		parts := []string{}
		for key, child := range node {
			parts = append(parts, key+":"+jsonShape(child, depth+1))
			if len(parts) >= 20 {
				break
			}
		}
		return "{" + strings.Join(parts, ",") + "}"
	case []any:
		if len(node) == 0 {
			return "[]"
		}
		return fmt.Sprintf("[%d]%s", len(node), jsonShape(node[0], depth+1))
	case string:
		return "string"
	case float64, json.Number, int, int64:
		return "number"
	case bool:
		return "bool"
	case nil:
		return "null"
	default:
		return fmt.Sprintf("%T", value)
	}
}

func findVQSDatasetRows(value any) []map[string]any {
	var find func(any) []map[string]any
	find = func(current any) []map[string]any {
		switch node := current.(type) {
		case map[string]any:
			if datasets, ok := node["datasets"].([]any); ok {
				if direct := mapsFromAny(datasets); len(direct) > 0 {
					hasScalar := false
					for _, value := range direct[0] {
						if _, isArray := value.([]any); !isArray {
							hasScalar = true
							break
						}
					}
					if hasScalar {
						return direct
					}
				}
				all := []map[string]any{}
				for _, rawDataset := range datasets {
					dataset, _ := rawDataset.(map[string]any)
					if dataset == nil {
						continue
					}
					rowCount := 0
					for _, rawColumn := range dataset {
						if column, ok := rawColumn.([]any); ok && len(column) > rowCount {
							rowCount = len(column)
						}
					}
					for i := 0; i < rowCount; i++ {
						row := map[string]any{}
						for key, rawColumn := range dataset {
							if column, ok := rawColumn.([]any); ok && i < len(column) {
								row[key] = column[i]
							}
						}
						all = append(all, row)
					}
				}
				if len(all) > 0 {
					return all
				}
			}
			for _, child := range node {
				if rows := find(child); rows != nil {
					return rows
				}
			}
		case []any:
			if len(node) > 0 {
				if first, ok := node[0].(map[string]any); ok {
					numericFields := 0
					for key := range first {
						if len(key) >= 12 {
							if _, err := strconv.ParseInt(key, 10, 64); err == nil {
								numericFields++
							}
						}
					}
					if numericFields > 0 {
						direct := mapsFromAny(node)
						hasArray := false
						for _, cell := range first {
							if _, ok := cell.([]any); ok {
								hasArray = true
								break
							}
						}
						if !hasArray {
							return direct
						}
						rowCount := 0
						for _, cell := range first {
							if column, ok := cell.([]any); ok && len(column) > rowCount {
								rowCount = len(column)
							}
						}
						rows := make([]map[string]any, rowCount)
						for i := range rows {
							rows[i] = map[string]any{}
						}
						for key, cell := range first {
							if column, ok := cell.([]any); ok {
								for i, value := range column {
									rows[i][key] = value
								}
							}
						}
						if len(rows) > 0 {
							return rows
						}
					}
				}
			}
			for _, child := range node {
				if rows := find(child); rows != nil {
					return rows
				}
			}
		}
		return nil
	}
	return find(value)
}

func hasExplicitZeroResult(value any) bool {
	found := false
	var walk func(any)
	walk = func(current any) {
		if found {
			return
		}
		switch node := current.(type) {
		case map[string]any:
			for _, key := range []string{"atLeast", "total"} {
				if raw, ok := node[key]; ok {
					switch n := raw.(type) {
					case float64:
						if n == 0 {
							found = true
							return
						}
					case json.Number:
						if value, err := n.Float64(); err == nil && value == 0 {
							found = true
							return
						}
					}
				}
			}
			for _, child := range node {
				walk(child)
			}
		case []any:
			for _, child := range node {
				walk(child)
			}
		}
	}
	walk(value)
	return found
}

func firstDeepString(value any, keys ...string) string {
	wanted := map[string]bool{}
	for _, key := range keys {
		wanted[strings.ToLower(key)] = true
	}
	var walk func(any) string
	walk = func(v any) string {
		switch node := v.(type) {
		case map[string]any:
			for key, child := range node {
				if wanted[strings.ToLower(key)] {
					if text := strings.TrimSpace(asString(child)); text != "" {
						return text
					}
				}
			}
			for _, child := range node {
				if found := walk(child); found != "" {
					return found
				}
			}
		case []any:
			for _, child := range node {
				if found := walk(child); found != "" {
					return found
				}
			}
		}
		return ""
	}
	return walk(value)
}
