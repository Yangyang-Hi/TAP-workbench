package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type accountAggregateSnapshot struct {
	SourceType string `json:"source_type"`
	SourceRID int `json:"source_rid"`
	StartDate string `json:"start_date"`
	EndDate string `json:"end_date"`
	FactDays int `json:"fact_days"`
	WindowCount int `json:"window_count"`
	Failed int `json:"failed"`
	Unresolved int `json:"unresolved"`
	MaxWindow int `json:"max_window"`
	DetailAvailable bool `json:"detail_available"`
	AggregateCompleteness string `json:"aggregate_completeness"`
	DetailCompleteness string `json:"detail_completeness"`
	CanonicalMetric string `json:"canonical_metric"`
	FieldContract []map[string]any `json:"field_contract"`
	Coverage map[string]any `json:"coverage"`
	ExecutionAudit map[string]any `json:"execution_audit"`
	Provenance map[string]any `json:"provenance"`
	DailyQuality []map[string]any `json:"daily_quality"`
	WeeklySummary []map[string]any `json:"weekly_summary"`
	WeeklyAccountMetrics []map[string]any `json:"weekly_account_metrics"`
	WeeklyMetricDecision string `json:"weekly_metric_decision"`
}

func accountAggregateSnapshotPath() (string, error) {
	d, err := resolveDataDir()
	if err != nil { return "", err }
	return filepath.Join(d, "account_aggregate_snapshot.json"), os.MkdirAll(d, 0700)
}

func importAccountAggregateSeed() error {
	src := filepath.Join(pluginDir, "app", "data", "account_aggregate_seed.json")
	b, err := os.ReadFile(src)
	if err != nil { return err }
	var snap accountAggregateSnapshot
	if err = json.Unmarshal(b, &snap); err != nil { return err }
	if snap.SourceRID != 2833031 || snap.FactDays != 88 || snap.WindowCount != 36936 || snap.Failed != 0 || snap.Unresolved != 0 || snap.MaxWindow >= savedReportHardLimit || len(snap.DailyQuality) != 88 || len(snap.WeeklyAccountMetrics) != 268 {
		return fmt.Errorf("account aggregate seed failed audit")
	}
	p, err := accountAggregateSnapshotPath(); if err != nil { return err }
	tmp := p + ".tmp"
	if err = os.WriteFile(tmp, b, 0600); err != nil { return err }
	return os.Rename(tmp, p)
}

func loadAccountAggregateSnapshot() (accountAggregateSnapshot, error) {
	var snap accountAggregateSnapshot
	p, err := accountAggregateSnapshotPath(); if err != nil { return snap, err }
	b, err := os.ReadFile(p); if err != nil { return snap, err }
	err = json.Unmarshal(b, &snap)
	return snap, err
}

func normalizeAggregateRegion(v any) string {
	s := strings.TrimSpace(asString(v))
	if s == "" || strings.EqualFold(s, "null") { return "Unknown / Unmapped" }
	return s
}

func accountAggregateView(s accountAggregateSnapshot, f filterRequest) map[string]any {
	unsupported := []string{}
	if f.ProgramType != "" { unsupported = append(unsupported, "program_type") }
	end := f.EndDate
	if end == "" || end > s.EndDate { end = s.EndDate }
	var day map[string]any
	for _, row := range s.DailyQuality {
		d := asString(row["p_date"])
		if d <= end && (f.StartDate == "" || d >= f.StartDate) && (day == nil || d > asString(day["p_date"])) { day = row }
	}
	distribution := []map[string]any{}
	accountCount := 0
	if day != nil && len(unsupported) == 0 {
		rows, _ := day["region_tier_distribution"].([]any)
		for _, raw := range rows {
			r, _ := raw.(map[string]any); if r == nil { continue }
			region, tier := normalizeAggregateRegion(r["region"]), normalizeTier(asString(r["tier"]))
			if f.Region != "" && f.Region != region { continue }
			if f.ClientTier != "" && normalizeTier(f.ClientTier) != tier { continue }
			count := asInt(r["distinct_account_count"])
			accountCount += count
			distribution = append(distribution, map[string]any{"date": day["p_date"], "region": region, "tier": tier, "client_tier": tier, "value": count})
		}
		if f.Region == "" && f.ClientTier == "" { accountCount = asInt(day["distinct_account_count"]) }
	}
	weekly := []map[string]any{}
	if len(unsupported) == 0 {
		for _, row := range s.WeeklyAccountMetrics {
			region, tier := normalizeAggregateRegion(row["region"]), normalizeTier(asString(row["client_tier"]))
			if f.Region != "" && f.Region != region { continue }
			if f.ClientTier != "" && normalizeTier(f.ClientTier) != tier { continue }
			if f.StartDate != "" && asString(row["week_end"]) < f.StartDate { continue }
			if f.EndDate != "" && asString(row["week_start"]) > f.EndDate { continue }
			item := cloneMap(row); item["region"] = region; item["client_tier"] = tier; item["date"] = row["last_valid_fact_date"]; item["value"] = row["metric_A_last_valid_day_account_count"]
			weekly = append(weekly, item)
		}
	}
	sort.Slice(weekly, func(i,j int) bool { return asString(weekly[i]["date"])+asString(weekly[i]["region"])+asString(weekly[i]["client_tier"]) < asString(weekly[j]["date"])+asString(weekly[j]["region"])+asString(weekly[j]["client_tier"]) })
	return map[string]any{"account_count": accountCount, "account_distribution": distribution, "account_weekly": weekly, "unsupported": unsupported, "data_as_of": func() any { if day == nil { return nil }; return day["p_date"] }(), "metadata": map[string]any{"source_type": s.SourceType, "source_rid": s.SourceRID, "window_count": s.WindowCount, "fact_days": s.FactDays, "failed": s.Failed, "unresolved": s.Unresolved, "max_window": s.MaxWindow, "detail_available": false, "aggregate_completeness": s.AggregateCompleteness, "detail_completeness": s.DetailCompleteness, "canonical_metric": s.CanonicalMetric, "metric_A": "last valid day snapshot (Provisional)", "metric_B": "distinct accounts seen during week", "pending_business_owner_confirmation": true, "coverage": s.Coverage, "execution_audit": s.ExecutionAudit, "provenance": s.Provenance, "field_contract": s.FieldContract}}
}
