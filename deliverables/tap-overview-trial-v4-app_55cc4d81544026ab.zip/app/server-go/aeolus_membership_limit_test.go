package main

import "testing"

func TestBuildDetailSavedReportChartOverridesPreviewDataLimit(t *testing.T) {
	original := map[string]any{
		"tableConfig": map[string]any{"dataLimit": float64(50)},
		"dimensions":  []any{},
		"filters":     []any{},
	}
	source := sourceConfig{QueryProfile: queryProfile{GroupBy: []string{"account_id"}}}
	fields := map[string]fieldConfig{"account_id": {DimMetID: "account-field"}}

	chart := buildDetailSavedReportChart(original, source, fields)
	tableConfig, ok := chart["tableConfig"].(map[string]any)
	if !ok {
		t.Fatalf("tableConfig missing: %#v", chart["tableConfig"])
	}
	if got := asInt(tableConfig["dataLimit"]); got != savedReportHardLimit {
		t.Fatalf("dataLimit=%d, want %d", got, savedReportHardLimit)
	}
	if got := asInt(original["tableConfig"].(map[string]any)["dataLimit"]); got != 50 {
		t.Fatalf("original chart mutated: dataLimit=%d", got)
	}
}
