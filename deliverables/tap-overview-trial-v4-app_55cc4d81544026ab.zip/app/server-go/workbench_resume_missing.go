package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type wbResumeMissingInput struct {
	MaxChunks         int  `json:"max_chunks"`
	IncludeEnrichment bool `json:"include_enrichment"`
}

type wbFieldClassification map[string]map[string]int

const wbResumeEnrichmentChunkSize = 25

func wbClassifyMetric(value *float64, status string) string {
	if value != nil {
		if *value == 0 {
			return "real_zero"
		}
		return metricAvailable
	}
	switch strings.ToLower(strings.TrimSpace(status)) {
	case "success", "no_data", metricSourceNull:
		return metricSourceNull
	case "window_incomplete":
		return "window_incomplete"
	case metricMissingAnchor:
		return metricMissingAnchor
	case metricAmbiguousAnchor:
		return metricAmbiguousAnchor
	case metricFailed, "error", "query_failed", "source_error", "partial_rejected":
		return metricFailed
	case "", metricQuerying, "pending", "running", "not_queried":
		return "not_queried"
	default:
		return metricFailed
	}
}

func wbClassifyRows(rows []wbRow) wbFieldClassification {
	out := wbFieldClassification{}
	add := func(field, status string) {
		if out[field] == nil {
			out[field] = map[string]int{}
		}
		out[field][status]++
	}
	for _, row := range rows {
		add("current_ccr", wbClassifyMetric(row.CCR, row.MetricStatus))
		add("current_nfs", wbClassifyMetric(row.NFS, row.MetricStatus))
		revenueStatus, _ := wbRowRevenueState(row)
		add("current_revenue", wbClassifyMetric(row.Revenue, revenueStatus))
		add("pre_ccr", wbClassifyMetric(row.Comparison.PreCCR, row.Comparison.PreCCRFact.Status))
		add("post_ccr", wbClassifyMetric(row.Comparison.PostCCR, row.Comparison.PostCCRFact.Status))
		add("wow", wbClassifyMetric(row.Comparison.WoWGrowthPct, row.Comparison.WoWStatus))
		completedEnrichment := strings.TrimSpace(row.AggregationNote) != ""
		if strings.TrimSpace(row.Member.Name) != "" {
			add("account_name", metricAvailable)
		} else if completedEnrichment {
			add("account_name", metricSourceNull)
		} else {
			add("account_name", "not_queried")
		}
		if len(row.AdvertiserTop10) > 0 {
			add("advertiser_top10", metricAvailable)
		} else if completedEnrichment {
			add("advertiser_top10", metricSourceNull)
		} else {
			add("advertiser_top10", "not_queried")
		}
		reasonStatus, allowlistStatus := "not_queried", "not_queried"
		if completedEnrichment {
			reasonStatus, allowlistStatus = metricSourceNull, metricSourceNull
		}
		for _, item := range row.Advertisers {
			if item.ReportedReasonsStatus == metricFailed {
				reasonStatus = metricFailed
			} else if item.ReportedReasonsStatus == metricAvailable {
				if len(item.ReportedReasons) > 0 {
					reasonStatus = metricAvailable
				} else if reasonStatus != metricAvailable {
					reasonStatus = metricSourceNull
				}
			}
			if item.AllowlistStatus == "query_failed" {
				allowlistStatus = metricFailed
			} else if item.AllowlistStatus != "" && !strings.EqualFold(item.AllowlistStatus, "unknown") {
				allowlistStatus = metricAvailable
			}
		}
		add("reported_reasons", reasonStatus)
		add("allowlist", allowlistStatus)
	}
	return out
}

func wbNeedsCurrentRepair(row wbRow) bool {
	statuses := []string{
		wbClassifyMetric(row.CCR, row.MetricStatus),
		wbClassifyMetric(row.NFS, row.MetricStatus),
	}
	revenueStatus, _ := wbRowRevenueState(row)
	statuses = append(statuses, wbClassifyMetric(row.Revenue, revenueStatus))
	for _, status := range statuses {
		if status == "not_queried" || status == metricFailed {
			return true
		}
	}
	return false
}

func wbMergeSnapshotFacts(state *wbDisk, target wbJob) (int, error) {
	path, err := wbStatePath()
	if err != nil {
		return 0, err
	}
	files, err := filepath.Glob(path + ".*")
	if err != nil {
		return 0, err
	}
	byKey := map[string]int{}
	for i, row := range target.Rows {
		byKey[wbFunnelRowKey(target.Request.Program, row)] = i
	}
	mergedFields := 0
	for _, name := range files {
		file, openErr := os.Open(name)
		if openErr != nil {
			continue
		}
		var snapshot wbDisk
		decodeErr := json.NewDecoder(file).Decode(&snapshot)
		_ = file.Close()
		if decodeErr != nil {
			continue
		}
		for _, job := range snapshot.Jobs {
			if job.BatchID != target.BatchID || !strings.EqualFold(job.Request.Program, target.Request.Program) {
				continue
			}
			for _, candidate := range job.Rows {
				index, ok := byKey[wbFunnelRowKey(target.Request.Program, candidate)]
				if !ok {
					continue
				}
				before, _ := json.Marshal(target.Rows[index])
				target.Rows[index] = wbMergeRowBestFacts(target.Rows[index], candidate)
				after, _ := json.Marshal(target.Rows[index])
				if string(before) != string(after) {
					mergedFields++
				}
			}
		}
	}
	state.Jobs[target.ID] = target
	return mergedFields, nil
}

func wbResumeMissingCurrent(request *http.Request, jobID string, maxChunks int, includeEnrichment bool) (map[string]any, int) {
	if maxChunks < 0 {
		return map[string]any{"error": "max_chunks must be >= 0"}, http.StatusBadRequest
	}
	wbMu.Lock()
	state, err := wbReadDisk()
	if err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	job, ok := state.Jobs[jobID]
	if !ok {
		wbMu.Unlock()
		return map[string]any{"error": "scan not found"}, http.StatusNotFound
	}
	if !strings.EqualFold(job.Request.Program, "ET") {
		wbMu.Unlock()
		return map[string]any{"error": "resume-missing is ET-only"}, http.StatusBadRequest
	}
	mergedSnapshots, err := wbMergeSnapshotFacts(&state, job)
	if err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	job = state.Jobs[jobID]
	before := wbClassifyRows(job.Rows)
	targets := make([]wbMember, 0)
	for _, row := range job.Rows {
		if wbNeedsCurrentRepair(row) {
			targets = append(targets, row.Member)
		}
	}
	sort.SliceStable(targets, func(i, j int) bool { return targets[i].AccountID < targets[j].AccountID })
	limit := len(targets)
	if maxChunks > 0 && maxChunks*wbETMetricChunkSize < limit {
		limit = maxChunks * wbETMetricChunkSize
	}
	targets = targets[:limit]
	job.Stage = fmt.Sprintf("repairing_current:%d/%d", 0, len(targets))
	state.Jobs[jobID] = job
	if err := wbWriteDisk(state); err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	wbMu.Unlock()

	processed := 0
	for start := 0; start < len(targets); start += wbETMetricChunkSize {
		end := start + wbETMetricChunkSize
		if end > len(targets) {
			end = len(targets)
		}
		chunk := targets[start:end]
		ids := make([]string, 0, len(chunk))
		for _, member := range chunk {
			ids = append(ids, member.AccountID)
		}
		metrics, queryErr := wbQueryETBatch(request.Context(), request, ids, job.Request.Start, job.Request.End)
		if queryErr != nil {
			return map[string]any{"error": queryErr.Error(), "processed": processed, "remaining": len(targets) - processed}, http.StatusBadGateway
		}
		freshRows, rowsErr := wbRowsFromETBatch(chunk, metrics, job.Request, job.Rule)
		if rowsErr != nil {
			return map[string]any{"error": rowsErr.Error(), "processed": processed, "remaining": len(targets) - processed}, http.StatusInternalServerError
		}
		freshByKey := map[string]wbRow{}
		for _, row := range freshRows {
			freshByKey[wbFunnelRowKey("ET", row)] = row
		}
		wbMu.Lock()
		state, err = wbReadDisk()
		if err == nil {
			job = state.Jobs[jobID]
			for i, row := range job.Rows {
				if fresh, exists := freshByKey[wbFunnelRowKey("ET", row)]; exists {
					job.Rows[i] = wbMergeRowBestFacts(fresh, row)
				}
			}
			processed += len(chunk)
			job.Stage = fmt.Sprintf("repairing_current:%d/%d", processed, len(targets))
			state.Jobs[jobID] = job
			err = wbWriteDisk(state)
		}
		wbMu.Unlock()
		if err != nil {
			return map[string]any{"error": err.Error(), "processed": processed}, http.StatusInternalServerError
		}
	}

	enrichmentProcessed := 0
	if includeEnrichment {
		wbMu.Lock()
		state, err = wbReadDisk()
		if err == nil {
			job = state.Jobs[jobID]
		}
		wbMu.Unlock()
		if err != nil {
			return map[string]any{"error": err.Error(), "processed": processed}, http.StatusInternalServerError
		}
		enrichmentMembers := make([]wbMember, 0)
		for _, row := range job.Rows {
			if strings.TrimSpace(row.AggregationNote) == "" {
				enrichmentMembers = append(enrichmentMembers, row.Member)
			}
		}
		sort.SliceStable(enrichmentMembers, func(i, j int) bool { return enrichmentMembers[i].AccountID < enrichmentMembers[j].AccountID })
		if maxChunks > 0 && maxChunks*wbResumeEnrichmentChunkSize < len(enrichmentMembers) {
			enrichmentMembers = enrichmentMembers[:maxChunks*wbResumeEnrichmentChunkSize]
		}
		if len(enrichmentMembers) > 0 {
			evidence, evidenceErr := wbQueryPairEvidence(request.Context(), request, enrichmentMembers, job.Request, job.Rule)
			if evidenceErr != nil {
				return map[string]any{"error": evidenceErr.Error(), "processed": processed, "enrichment_processed": 0}, http.StatusBadGateway
			}
			freshRows := make([]wbRow, 0, len(enrichmentMembers))
			wanted := map[string]bool{}
			for _, member := range enrichmentMembers {
				wanted[member.AccountID] = true
			}
			for _, row := range job.Rows {
				if wanted[row.Member.AccountID] {
					freshRows = append(freshRows, row)
				}
			}
			freshRows = applyPairEvidence(freshRows, evidence, job.Request, job.Rule)
			freshByKey := map[string]wbRow{}
			for _, row := range freshRows {
				freshByKey[wbFunnelRowKey("ET", row)] = row
			}
			wbMu.Lock()
			state, err = wbReadDisk()
			if err == nil {
				job = state.Jobs[jobID]
				for i, row := range job.Rows {
					if fresh, exists := freshByKey[wbFunnelRowKey("ET", row)]; exists {
						job.Rows[i] = wbMergeRowBestFacts(fresh, row)
					}
				}
				enrichmentProcessed = len(enrichmentMembers)
				job.Stage = fmt.Sprintf("enrichment_repaired:%d", enrichmentProcessed)
				state.Jobs[jobID] = job
				err = wbWriteDisk(state)
			}
			wbMu.Unlock()
			if err != nil {
				return map[string]any{"error": err.Error(), "processed": processed, "enrichment_processed": enrichmentProcessed}, http.StatusInternalServerError
			}
		}
	}

	wbMu.Lock()
	state, err = wbReadDisk()
	if err == nil {
		job = state.Jobs[jobID]
		remaining := 0
		for _, row := range job.Rows {
			if wbNeedsCurrentRepair(row) {
				remaining++
			}
		}
		job.Done = len(job.Rows) - remaining
		if remaining == 0 && enrichmentProcessed == 0 {
			job.Stage = "current_metrics_repaired"
		} else if remaining == 0 {
			job.Stage = fmt.Sprintf("enrichment_repaired:%d", enrichmentProcessed)
		}
		state.Jobs[jobID] = job
		err = wbWriteDisk(state)
	}
	wbMu.Unlock()
	if err != nil {
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	after := wbClassifyRows(job.Rows)
	remaining := 0
	for _, row := range job.Rows {
		if wbNeedsCurrentRepair(row) {
			remaining++
		}
	}
	logMsg(fmt.Sprintf("[resume-missing] scan_id=%s merged_snapshots=%d processed=%d remaining=%d", jobID, mergedSnapshots, processed, remaining), "plugin")
	return map[string]any{"id": jobID, "status": job.Status, "stage": job.Stage, "processed": processed, "remaining": remaining, "enrichment_processed": enrichmentProcessed, "merged_snapshot_rows": mergedSnapshots, "classification_before": before, "classification": after, "side_effects": map[string]any{"membership_scan": false, "new_task": false, "pre_post_revenue": false, "case": false, "notification": false}}, http.StatusOK
}

func wbResumeMissingHandler(w http.ResponseWriter, r *http.Request) {
	var input wbResumeMissingInput
	if r.Body != nil {
		decoder := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20))
		if err := decoder.Decode(&input); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": "invalid JSON body"})
			return
		}
	}
	data, status := wbResumeMissingCurrent(r, r.PathValue("id"), input.MaxChunks, input.IncludeEnrichment)
	if status >= 400 {
		writeJSON(w, status, data)
		return
	}
	writeJSON(w, status, map[string]any{"data": data})
}
