package main

import (
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"time"
)

// A random, short-lived, persisted confirmation binds an explicit test send to
// the previewed actor, Alert, Bot credentials and actual allowlist user. The
// real submitter mapping is retained only as optional audit context.
// The raw confirmation is never logged and the database stores only its hash.
type cwNotificationConfirmation struct {
	AlertID        string
	Actor          string
	CaseVersion    int
	Mode           string
	Recipient      string
	RecipientEmail string
	RecipientName  string
	Mapping        cwIdentityMapping
	ResolvedOpenID string
	Revision       string
	BotFingerprint string
	StateHash      string
	TemplateHash   string
}

func cwBotFingerprint() (string, error) {
	c, _, err := loadFeishuCredentials()
	if err != nil {
		return "", err
	}
	if c.AppID == "" || c.AppSecret == "" {
		return "", errors.New("Bot credentials missing")
	}
	sum := sha256.Sum256([]byte(c.AppID + "\x00" + c.AppSecret + "\x00" + cwAPIBase()))
	return hex.EncodeToString(sum[:]), nil
}
func cwPreviewHash(token string) string {
	sum := sha256.Sum256([]byte(token))
	return hex.EncodeToString(sum[:])
}
func cwCreateNotificationPreview(db *sql.DB, a cwCase, actor, recipient string, m cwIdentityMapping, openID, revision string) (string, error) {
	return cwCreateNotificationPreviewSnapshot(db, a, cwNotificationConfirmation{AlertID: a.ID, Actor: actor, CaseVersion: a.Version, Mode: "test", Recipient: recipient, Mapping: m, ResolvedOpenID: openID, Revision: revision})
}

func cwCreateNotificationPreviewSnapshot(db *sql.DB, a cwCase, confirmation cwNotificationConfirmation) (string, error) {
	fingerprint, err := cwBotFingerprint()
	if err != nil {
		return "", err
	}
	b := make([]byte, 32)
	if _, err = rand.Read(b); err != nil {
		return "", err
	}
	token := base64.RawURLEncoding.EncodeToString(b)
	confirmation.BotFingerprint = fingerprint
	if confirmation.AlertID == "" {
		confirmation.AlertID = a.ID
	}
	if confirmation.CaseVersion == 0 {
		confirmation.CaseVersion = a.Version
	}
	body, err := json.Marshal(confirmation)
	if err != nil {
		return "", err
	}
	_, err = db.Exec("INSERT INTO tap_notification_previews(token_hash,body,expires_at) VALUES(?,?,?)", cwPreviewHash(token), string(body), time.Now().Add(10*time.Minute).Unix())
	if err != nil {
		return "", err
	}
	// Retain a bounded window for idempotent HTTP response retries.
	_, _ = db.Exec("DELETE FROM tap_notification_previews WHERE expires_at<?", time.Now().Add(-24*time.Hour).Unix())
	return token, nil
}
func cwReadNotificationPreview(db interface{ QueryRow(string, ...any) *sql.Row }, token string) (cwNotificationConfirmation, bool, error) {
	var c cwNotificationConfirmation
	var body string
	var expiry int64
	var used int
	if len(token) != 43 {
		return c, false, cwErr(400, "请先生成有效的无发送预览，再确认发送")
	}
	err := db.QueryRow("SELECT body,expires_at,consumed FROM tap_notification_previews WHERE token_hash=?", cwPreviewHash(token)).Scan(&body, &expiry, &used)
	if err != nil || expiry <= time.Now().Unix() {
		return c, false, cwErr(409, "发送预览已失效，请重新生成")
	}
	if err = json.Unmarshal([]byte(body), &c); err != nil {
		return c, false, err
	}
	return c, used == 1, nil
}
