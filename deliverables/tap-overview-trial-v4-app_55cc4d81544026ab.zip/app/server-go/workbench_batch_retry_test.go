package main

import (
	"context"
	"errors"
	"testing"
	"time"
)

func TestMetricChunkRetriesTransientFailureThenSucceeds(t *testing.T) {
	oldDelay := wbMetricRetryBaseDelay
	wbMetricRetryBaseDelay = time.Millisecond
	defer func() { wbMetricRetryBaseDelay = oldDelay }()

	attempts := 0
	result, err := wbRunMetricChunkWithRetry(context.Background(), "ET", 6, 23, func(context.Context) (string, error) {
		attempts++
		if attempts == 1 {
			return "", &wbMetricQueryError{message: "ET Account CCR/NFS VQS query failed: status=failed audit_id=qa_transient request_id=req_transient", retryable: true, auditID: "qa_transient", requestID: "req_transient"}
		}
		return "ok", nil
	})
	if err != nil || result != "ok" || attempts != 2 {
		t.Fatalf("result=%q attempts=%d err=%v", result, attempts, err)
	}
}

func TestMetricChunkPermanentFailureIsNotRetried(t *testing.T) {
	attempts := 0
	_, err := wbRunMetricChunkWithRetry(context.Background(), "ST", 1, 1, func(context.Context) (struct{}, error) {
		attempts++
		return struct{}{}, errors.New("filter_contract_failed: account filter integrity mismatch")
	})
	if err == nil || attempts != 1 {
		t.Fatalf("attempts=%d err=%v", attempts, err)
	}
}

func TestMetricChunkStopsAfterThreeTransientFailures(t *testing.T) {
	oldDelay := wbMetricRetryBaseDelay
	wbMetricRetryBaseDelay = time.Millisecond
	defer func() { wbMetricRetryBaseDelay = oldDelay }()

	attempts := 0
	_, err := wbRunMetricChunkWithRetry(context.Background(), "THT", 2, 4, func(context.Context) (struct{}, error) {
		attempts++
		return struct{}{}, errors.New("VQS query failed: status=failed audit_id=qa_retry request_id=req_retry")
	})
	if err == nil || attempts != wbMetricMaxAttempts {
		t.Fatalf("attempts=%d err=%v", attempts, err)
	}
}

func TestMetricChunkRetryBackoffHonorsContextCancellation(t *testing.T) {
	oldDelay := wbMetricRetryBaseDelay
	wbMetricRetryBaseDelay = time.Second
	defer func() { wbMetricRetryBaseDelay = oldDelay }()

	ctx, cancel := context.WithCancel(context.Background())
	attempts := 0
	started := make(chan struct{})
	done := make(chan error, 1)
	go func() {
		_, err := wbRunMetricChunkWithRetry(ctx, "ET", 1, 1, func(context.Context) (struct{}, error) {
			attempts++
			if attempts == 1 {
				close(started)
			}
			return struct{}{}, errors.New("temporary network error")
		})
		done <- err
	}()
	<-started
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) || attempts != 1 {
			t.Fatalf("attempts=%d err=%v", attempts, err)
		}
	case <-time.After(250 * time.Millisecond):
		t.Fatal("retry backoff ignored context cancellation")
	}
}

func TestProbeFailureClassificationKeepsPermanentErrorsOutOfRetry(t *testing.T) {
	transient := wbProbeQueryError("ET Account CCR/NFS", map[string]any{
		"status": "failed", "audit_id": "qa", "requestId": "req",
		"query_result": titanProbeStep{ErrorType: "network_error"},
	}, "")
	retryable, auditID, requestID := wbMetricErrorTrace(transient)
	if !retryable || auditID != "qa" || requestID != "req" {
		t.Fatalf("transient classification=%t audit=%q request=%q", retryable, auditID, requestID)
	}

	permanent := wbProbeQueryError("ET Account CCR/NFS", map[string]any{
		"status": "filter_contract_failed", "audit_id": "qa-permanent",
		"query_result": titanProbeStep{ErrorType: "vqs_business_error", ForbiddenDetected: true},
	}, " filter_error=invalid account filter")
	retryable, _, _ = wbMetricErrorTrace(permanent)
	if retryable {
		t.Fatal("permanent filter/permission failure was classified retryable")
	}
}
