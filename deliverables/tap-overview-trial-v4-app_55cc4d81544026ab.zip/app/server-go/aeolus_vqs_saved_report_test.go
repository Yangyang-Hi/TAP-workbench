package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestProductionDefinitionReadsSavedReportWithoutGlue(t *testing.T) {
	paths := []string{}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		paths = append(paths, r.URL.Path)
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{"data": map[string]any{"reqJson": map[string]any{"version": 4, "query": map[string]any{"datasetId": 42, "dimensions": []any{map[string]any{"uniqueId": "u1"}}, "whereList": []any{}}}}})
	}))
	defer server.Close()
	original := httpClient
	httpClient = &http.Client{Timeout: time.Second}
	t.Cleanup(func() { httpClient = original })

	req, chart, step := probeSavedReportRequest(context.Background(), server.URL, "token", 123)
	if step.Status != "passed" || req == nil || chart == nil {
		t.Fatalf("unexpected saved report result: %#v", step)
	}
	if len(paths) != 1 || paths[0] != aeolusSavedReportPath {
		t.Fatalf("production definition called unexpected endpoints: %#v", paths)
	}
}

func TestProbeVQSUsesVQSEndpointAndPreservesTrace(t *testing.T) {
	var path string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		path = r.URL.Path
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("x-request-id", "req-real")
		w.Header().Set("x-tt-logid", "log-real")
		_ = json.NewEncoder(w).Encode(map[string]any{"code": 0, "data": map[string]any{"rows": []any{map[string]any{"u1": "value"}}}})
	}))
	defer server.Close()
	original := httpClient
	httpClient = &http.Client{Timeout: time.Second}
	t.Cleanup(func() { httpClient = original })

	step := probeVQS(context.Background(), server.URL, "token", 800414, 123, map[string]any{"version": 4, "query": map[string]any{}})
	if path != aeolusVQSQueryPath {
		t.Fatalf("expected VQS, got %s", path)
	}
	if strings.Contains(path, "query_chart") || strings.Contains(path, "to_simple_chart") {
		t.Fatalf("Glue endpoint used: %s", path)
	}
	if step.Status != "passed" || step.RequestID != "req-real" || step.LogID != "log-real" {
		t.Fatalf("trace/result mismatch: %#v", step)
	}
}

func TestQuotaSourcesPreserveEveryDistinctTicket(t *testing.T) {
	rows := []map[string]any{
		{"ticket_id": "t1", "account_id": "a1", "advertiser_id": "v1", "p_date": "2026-10-19"},
		{"ticket_id": "t2", "account_id": "a1", "advertiser_id": "v1", "p_date": "2026-10-19"},
	}
	if got := dedupeRows("et_account_list", rows); len(got) != 2 {
		t.Fatalf("ET tickets collapsed: %#v", got)
	}
	if got := dedupeRows("tht_ticket_details", rows); len(got) != 2 {
		t.Fatalf("THT tickets collapsed: %#v", got)
	}
}

func TestSavedReportSchemaMapsNumericUniqueIDsWithoutPrecisionLoss(t *testing.T) {
	request := map[string]any{"schema": map[string]any{
		"dimensions": []any{map[string]any{"uniqueId": float64(261015230741091), "dimMetId": float64(10000000032791)}},
		"measures":   []any{map[string]any{"uniqueId": float64(260325121636716), "dimMetId": float64(10000000032674)}, map[string]any{"uniqueId": float64(260325121636679), "dimMetId": float64(10000000032693)}},
	}}
	columns := []string{"261015230741091", "260325121636716", "260325121636679"}
	fieldMap := buildContractFieldMap(request, columns)
	if len(fieldMap) != 3 {
		t.Fatalf("numeric Saved Report uniqueIds were not mapped exactly: %#v", fieldMap)
	}
	source := sourceConfig{Fields: map[string]fieldConfig{
		"account_id":     {DimMetID: "10000000032791"},
		"p0_nfs":         {DimMetID: "10000000032674"},
		"dynamic_p0_ccr": {DimMetID: "10000000032693"},
	}}
	rows := canonicalizeSavedReportDetails([]map[string]any{{"261015230741091": "7675782032500424721", "260325121636716": "3", "260325121636679": "0.25"}}, source.Fields, fieldMap)
	if len(rows) != 1 || asString(rows[0]["account_id"]) != "7675782032500424721" || asString(rows[0]["p0_nfs"]) != "3" || asString(rows[0]["dynamic_p0_ccr"]) != "0.25" {
		t.Fatalf("Saved Report fields mapped incorrectly: %#v", rows)
	}
}

func TestProbeVQSRetriesNeedToQueueAndPreservesDecimalIDTrace(t *testing.T) {
	attempts := 0
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		attempts++
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("x-request-id", "req-final")
		w.Header().Set("x-tt-logid", "log-final")
		if attempts < 3 {
			_ = json.NewEncoder(w).Encode(map[string]any{"code": "aeolus/performance/needToQueue", "msg": "queued"})
			return
		}
		_, _ = w.Write([]byte(`{"code":0,"data":{"rows":[{"account_id":7462465462811770896}]}}`))
	}))
	defer server.Close()
	originalClient, originalDelay := httpClient, needToQueueRetryDelay
	httpClient, needToQueueRetryDelay = server.Client(), time.Millisecond
	t.Cleanup(func() { httpClient, needToQueueRetryDelay = originalClient, originalDelay })

	step := probeVQS(context.Background(), server.URL, "token", 800414, 2979783, map[string]any{"query": map[string]any{}})
	if attempts != 3 || step.Status != "passed" || step.RequestID != "req-final" || step.LogID != "log-final" {
		t.Fatalf("queue retry/trace mismatch attempts=%d step=%+v", attempts, step)
	}
	id, ok := step.SampleRows["account_id"].(json.Number)
	if !ok || id.String() != "7462465462811770896" {
		t.Fatalf("decimal ID lost precision: %#v (%T)", step.SampleRows["account_id"], step.SampleRows["account_id"])
	}
}

func TestETQuotaOpaqueColumnsMapAccountAndTicketIdentities(t *testing.T) {
	fields := map[string]fieldConfig{
		"create_date":     {DimMetID: "10000001311927", UniqueID: "261021115949047", SourceName: "create_date"},
		"submitter":       {DimMetID: "10000000536479", UniqueID: "260907113221317", SourceName: "question_user_name"},
		"region":          {DimMetID: "10000016047833", UniqueID: "261021115949127", SourceName: "region"},
		"account_id":      {DimMetID: "10000000536486", UniqueID: "261015231407179", SourceName: "account_id"},
		"account_name":    {DimMetID: "10000000915461", UniqueID: "261021115949563", SourceName: "account_name[dm_advertiser_base_info_df_utc0_1]"},
		"advertiser_id":   {DimMetID: "10000000536485", UniqueID: "261021115949308", SourceName: "advertiser_id"},
		"advertiser_name": {DimMetID: "10000000915459", UniqueID: "261021115949273", SourceName: "advertiser_name[dm_advertiser_base_info_df_utc0_1]"},
		"create_time":     {DimMetID: "10000000536473", UniqueID: "261015231407638", SourceName: "create_time"},
		"final_result":    {DimMetID: "10000000536562", UniqueID: "261015231407764", SourceName: "final_result"},
		"ticket_id":       {DimMetID: "10000000536470", UniqueID: "10000000536470", SourceName: "ticket_id"},
	}
	raw := map[string]any{
		"261021115949047": "2026-10-01", "260907113221317": "owner", "261021115949127": "APAC",
		"261015231407179": "account-1", "261021115949563": "Account", "261021115949308": "adv-1",
		"261021115949273": "Advertiser", "261015231407638": "2026-10-01 12:00:00",
		"261015231407764": "APPROVE", "10000000536470": "ticket-1",
	}
	rows := canonicalizeSavedReportDetails([]map[string]any{raw}, fields, nil)
	if len(rows) != 1 || asString(rows[0]["account_id"]) != "account-1" || asString(rows[0]["ticket_id"]) != "ticket-1" {
		t.Fatalf("opaque ET identities not mapped: %#v", rows)
	}
}

func TestSavedReportVQSRequestProjectsGovernedDetailDimensions(t *testing.T) {
	raw := map[string]any{"query": map[string]any{"dimensions": []any{map[string]any{"uniqueId": "old"}}, "whereList": []any{}}}
	sent := map[string]any{"dimensions": []any{map[string]any{"datasetFieldId": "10000000536486", "uniqueId": "261015231407179"}, map[string]any{"datasetFieldId": "10000000536470", "uniqueId": "10000000536470"}}}
	got, err := savedReportVQSRequest(raw, sent, sourceConfig{RID: 2933760}, filterRequest{}, nil, "account_id")
	if err != nil {
		t.Fatal(err)
	}
	dimensions := got["query"].(map[string]any)["dimensions"].([]any)
	if len(dimensions) != 2 || asString(dimensions[1].(map[string]any)["datasetFieldId"]) != "10000000536470" {
		t.Fatalf("governed ticket projection missing: %#v", dimensions)
	}
}
