package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestReportedReasonMappingContract(t *testing.T) {
	raw, err := os.ReadFile(filepath.Join(pluginDir, "config", "reported_reason_mapping.json"))
	if err != nil {
		t.Fatal(err)
	}
	dict, err := parseReportedReasonDictionary(raw)
	if err != nil {
		t.Fatal(err)
	}
	if len(dict.ByKey) != 126 {
		t.Fatalf("mapping count = %d, want 126", len(dict.ByKey))
	}
}

func TestReportedReasonNormalizationCollision(t *testing.T) {
	entries := make([]reportedReasonMapping, 126)
	for i := range entries {
		entries[i] = reportedReasonMapping{OriginalLabel: strings.Repeat("x", i+1)}
	}
	entries[0].OriginalLabel = "a - b"
	entries[1].OriginalLabel = "a  -  b"
	raw, _ := json.Marshal(reportedReasonMappingFile{Version: reportedReasonMappingVersion, Entries: entries})
	if _, err := parseReportedReasonDictionary(raw); err == nil || !strings.Contains(err.Error(), "collision") {
		t.Fatalf("expected normalized-key collision, got %v", err)
	}
}

func testReasonDict() reportedReasonDictionary {
	return reportedReasonDictionary{ByKey: map[string]reportedReasonMapping{
		"a": {OriginalLabel: "a", DisplayNameEN: "A"},
		"b": {OriginalLabel: "b", DisplayNameEN: "B"},
		"c": {OriginalLabel: "c", DisplayNameEN: "C"},
		"d": {OriginalLabel: "d", DisplayNameEN: "D"},
	}}
}

func TestAuthoritativeNameSourceContract(t *testing.T) {
	cfg, err := loadDataSourceConfig()
	if err != nil {
		t.Fatal(err)
	}
	names := cfg.Sources["account_advertiser_names"]
	if names.AppID != 800414 || names.SID != 1280034 || names.RID != 3052502 || names.TID != 6236 {
		t.Fatalf("name source = app %d / SID %d / RID %d / TID %d, want 800414 / 1280034 / 3052502 / 6236", names.AppID, names.SID, names.RID, names.TID)
	}
	for _, field := range []string{"account_id", "account_name", "advertiser_id", "advertiser_name"} {
		if names.Fields[field].DimMetID == "" || names.Fields[field].UniqueID == "" {
			t.Fatalf("name source field %s is missing governed projection identity", field)
		}
	}
}

func TestReportedReasonQueryContractExcludesIsOnline(t *testing.T) {
	cfg, err := loadDataSourceConfig()
	if err != nil {
		t.Fatal(err)
	}
	reasons := cfg.Sources["advertiser_reported_reasons"]
	if reasons.AppID != 800414 || reasons.RID != 3023305 {
		t.Fatalf("reported reason source = app %d / RID %d, want app 800414 / RID 3023305", reasons.AppID, reasons.RID)
	}
	if containsString(reasons.QueryProfile.Filters, "is_online") {
		t.Fatalf("reported reason contract must not inject is_online: %v", reasons.QueryProfile.Filters)
	}
	if !containsString(reasons.QueryProfile.Filters, "p_date") {
		t.Fatalf("reported reason contract must retain p_date: %v", reasons.QueryProfile.Filters)
	}
	wantGroupBy := []string{"account_id", "advertiser_id", "semantics_label_tier_1_2_3_4"}
	if strings.Join(reasons.QueryProfile.GroupBy, ",") != strings.Join(wantGroupBy, ",") {
		t.Fatalf("reported reason detail expansion dimensions = %v, want %v", reasons.QueryProfile.GroupBy, wantGroupBy)
	}
	if len(reasons.QueryProfile.Metrics) != 0 {
		t.Fatalf("reported reason contract must preserve saved report measures, got explicit metrics %v", reasons.QueryProfile.Metrics)
	}
	originalMeasure := map[string]any{"datasetFieldId": "saved-ccr", "uniqueId": "saved-ccr", "type": "measure", "aggr": "authoritative"}
	expanded := buildDetailSavedReportChart(map[string]any{"dimensions": []any{}, "measures": []any{originalMeasure}}, reasons, reasons.Fields)
	dimensions, _ := expanded["dimensions"].([]any)
	if len(dimensions) != 3 {
		t.Fatalf("expanded reason dimensions = %v, want exactly three", dimensions)
	}
	for i, semantic := range wantGroupBy {
		dimension, _ := dimensions[i].(map[string]any)
		if dimension["datasetFieldId"] != reasons.Fields[semantic].DimMetID {
			t.Fatalf("expanded dimension %d = %v, want %s", i, dimension, semantic)
		}
	}
	measures, _ := expanded["measures"].([]any)
	if len(measures) != 1 || measures[0].(map[string]any)["aggr"] != "authoritative" {
		t.Fatalf("saved report measures were not preserved: %v", measures)
	}

	_, applied := chartWithBusinessFilters(map[string]any{}, reasons, filterRequest{
		StartDate: "2026-10-19", EndDate: "2026-10-25",
	})
	if containsString(applied, "is_online") || !containsString(applied, "p_date") {
		t.Fatalf("unexpected reported reason contract filters: %v", applied)
	}

	current := cfg.Sources["advertiser_current_ccr_nfs"]
	if !containsString(current.QueryProfile.Filters, "is_online") {
		t.Fatalf("current Account/ADV contract lost is_online: %v", current.QueryProfile.Filters)
	}
}

func TestReportedReasonDedupePreservesLabelGrain(t *testing.T) {
	rows := []map[string]any{
		{"account_id": "7554611686985007105", "advertiser_id": "7554611409972297729", "semantics_label_tier_1_2_3_4": "a"},
		{"account_id": "7554611686985007105", "advertiser_id": "7554611409972297729", "semantics_label_tier_1_2_3_4": "b"},
	}
	if got := dedupeRows("advertiser_reported_reasons", rows); len(got) != 2 {
		t.Fatalf("reason-level rows collapsed to pair grain: %v", got)
	}
}

func TestReportedReasonsCCRTop3FiltersInvalidCandidates(t *testing.T) {
	key := wbPairKey{"7000000000000000001", "7100000000000000001"}
	rows := []map[string]any{
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "b", "dynamic_p0_ccr": 2.0, "p0_nfs": 1.0},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "a", "dynamic_p0_ccr": 2.0, "p0_nfs": 2.0},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "c", "dynamic_p0_ccr": 1.0},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "d", "dynamic_p0_ccr": .5},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "", "dynamic_p0_ccr": 99.0},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "zero", "dynamic_p0_ccr": 0.0},
	}
	got := rankReportedReasonsDetailed(testReasonDict(), rows, true, "")
	ranked := got.Reasons[key]
	if len(ranked) != 3 || ranked[0].OriginalLabel != "a" || ranked[1].OriginalLabel != "b" || ranked[2].OriginalLabel != "c" {
		t.Fatalf("unexpected CCR top3: %#v", ranked)
	}
	if got.Status[key] != metricAvailable || got.SortBasis[key] != "p0_ccr_desc" || *ranked[0].Rank != 1 {
		t.Fatalf("unexpected ranking metadata: %#v", got)
	}
}

func TestReportedReasonsNFSFallbackOnlyWhenAllCCRNull(t *testing.T) {
	key := wbPairKey{"7000000000000000001", "7100000000000000001"}
	fallback := rankReportedReasonsDetailed(testReasonDict(), []map[string]any{
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "content_issues - sensitive_content - sexual_related_content - ", "Dynamic P0 Content CCR": nil, "P0: Negative Feedback Show": "1494"},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "content_issues - dislike_or_report_mapping - report_no_label - ", "Dynamic P0 Content CCR": "NULL", "P0: Negative Feedback Show": "197"},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "content_issues - marketing_content - deceptive_content - money_or_personal_information_scam", "Dynamic P0 Content CCR": "", "P0: Negative Feedback Show": "97"},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "zero", "Dynamic P0 Content CCR": nil, "P0: Negative Feedback Show": "0"},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "", "Dynamic P0 Content CCR": nil, "P0: Negative Feedback Show": "9999"},
	}, true, "")
	if got := fallback.Reasons[key]; len(got) != 3 || got[0].P0NFS == nil || *got[0].P0NFS != 1494 || got[1].P0NFS == nil || *got[1].P0NFS != 197 || got[2].P0NFS == nil || *got[2].P0NFS != 97 || got[2].OriginalLabel != "content_issues - marketing_content - deceptive_content - money_or_personal_information_scam" || got[0].SortBasis != "nfs_fallback_all_ccr_null" {
		t.Fatalf("NFS fallback failed for source aliases/string metrics: %+v", got)
	}

	noFallback := rankReportedReasonsDetailed(testReasonDict(), []map[string]any{
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "a", "dynamic_p0_ccr": 0.0, "p0_nfs": 100.0},
		{"account_id": key.AccountID, "advertiser_id": key.AdvertiserID, "semantics_label_tier_1_2_3_4": "b", "dynamic_p0_ccr": nil, "p0_nfs": 200.0},
	}, true, "")
	if len(noFallback.Reasons[key]) != 0 || noFallback.SortBasis[key] != "p0_ccr_desc" || noFallback.Status[key] != metricAvailable {
		t.Fatalf("non-positive CCR must yield a successful empty result without NFS fallback: %#v", noFallback)
	}
}

func TestReportedReasonsFailureIsNotEmptySuccess(t *testing.T) {
	key := wbPairKey{"7000000000000000001", "7100000000000000001"}
	evidence := map[string][]wbAdvertiserEvidence{key.AccountID: {{AccountID: key.AccountID, AdvertiserID: key.AdvertiserID}}}
	if err := attachReportedReasons(evidence, nil, false, "RID 3023305 unavailable"); err != nil {
		t.Fatal(err)
	}
	got := evidence[key.AccountID][0]
	if got.ReportedReasonsStatus != metricFailed || got.ReportedReasonsError != "RID 3023305 unavailable" || len(got.ReportedReasons) != 0 {
		t.Fatalf("query failure collapsed into empty success: %+v", got)
	}
}

func TestReportedReasonTruncationNeverRanks(t *testing.T) {
	rows := make([]map[string]any, 24)
	if complete, reason := reportedReasonRowsCompleteness(rows, true); complete || !strings.Contains(reason, "truncated") {
		t.Fatalf("complete=%v reason=%q", complete, reason)
	}
	if complete, reason := reportedReasonRowsCompleteness(rows, false); !complete || reason != "" {
		t.Fatalf("verified complete row set rejected: complete=%v reason=%q", complete, reason)
	}
}
