package main

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"net/http/httptest"
	"testing"
	"time"
)

func TestDefaultRiskPolicyEquivalentToGovernanceRules(t *testing.T) {
	policy := wbDefaultPolicy()
	cases := []struct {
		ccr, nfs float64
		want     string
	}{{3, 50, "normal"}, {3, 51, "watch"}, {45, 299, "watch"}, {45, 300, "extreme"}, {46, 1, "normal"}}
	for _, tc := range cases {
		got, _ := wbEvaluateAbsolute(&tc.ccr, &tc.nfs, "ET", "", "", policy)
		if got != tc.want {
			t.Fatalf("ccr=%g nfs=%g got=%s want=%s", tc.ccr, tc.nfs, got, tc.want)
		}
	}
}

func TestRiskPolicyValidationCASIdempotencyAndLease(t *testing.T) {
	repo := newMemoryRiskPolicyRepository()
	rules := wbDefaultPolicy().Rules
	if err := wbValidatePolicyRules(rules); err != nil {
		t.Fatal(err)
	}
	bad := append([]wbRiskRuleConfig(nil), rules...)
	bad[0].Program = "INVALID"
	if err := wbValidatePolicyRules(bad); err == nil {
		t.Fatal("invalid program accepted")
	}
	changed := append([]wbRiskRuleConfig(nil), rules...)
	changed[0].Conditions = append([]wbRiskCondition(nil), changed[0].Conditions...)
	changed[0].Conditions[0].Value = 4
	p, idem, unchanged, err := repo.PutCAS(context.Background(), 0, "request-1", "operator", changed, "adjust threshold")
	if err != nil || idem || unchanged || p.Version != 1 {
		t.Fatalf("put=%+v idem=%v unchanged=%v err=%v", p, idem, unchanged, err)
	}
	got, idem, _, err := repo.PutCAS(context.Background(), 0, "request-1", "operator", changed, "adjust threshold")
	if err != nil || !idem || got.Version != p.Version {
		t.Fatalf("idempotency failed: %+v %v %v", got, idem, err)
	}
	if _, _, _, err = repo.PutCAS(context.Background(), 0, "request-2", "operator", rules, "stale"); err == nil {
		t.Fatal("stale CAS accepted")
	}
	task, created, err := repo.EnsureTask(context.Background(), wbRejudgeTask{ID: "task", Fingerprint: "fp", Status: "pending", CreatedAt: time.Now().Format(time.RFC3339)})
	if err != nil || !created {
		t.Fatal(err)
	}
	claimed, ok, err := repo.Claim(context.Background(), task.ID, "worker-a", time.Now())
	if err != nil || !ok || claimed.LeaseOwner != "worker-a" {
		t.Fatalf("claim failed: %+v %v %v", claimed, ok, err)
	}
	if _, ok, _ = repo.Claim(context.Background(), task.ID, "worker-b", time.Now()); ok {
		t.Fatal("active lease was stolen")
	}
	claimed.LeaseUntil = time.Now().Add(-time.Minute).Format(time.RFC3339)
	repo.tasks[task.ID] = claimed
	if _, ok, err = repo.Claim(context.Background(), task.ID, "worker-b", time.Now()); err != nil || !ok {
		t.Fatalf("expired lease not recoverable: %v %v", ok, err)
	}
}

func TestCurrentWeekRejudgeOnlyUpdatesPersistedRiskFields(t *testing.T) {
	wbTestEnv(t)
	batch := "2026-W43"
	actions := map[string]wbAction{"manual": {}}
	jobs := map[string]wbJob{}
	for _, program := range []string{"ET", "ST", "THT"} {
		jobs[program] = wbJob{ID: program, BatchID: batch, Request: wbRequest{Program: program}, Rows: []wbRow{{ID: program + "-row", Program: program, CCR: f64(45), NFS: f64(300), Level: "normal"}}}
	}
	if err := wbWriteDisk(wbDisk{Jobs: jobs, Actions: actions}); err != nil {
		t.Fatal(err)
	}
	policy := wbDefaultPolicy()
	policy.Version = 2
	policy.VersionLabel = "TAP-RISK-2"
	for _, program := range []string{"ET", "ST", "THT"} {
		result := wbRejudgeProgram(program, policy, []string{batch})
		if result.Status != "success" || result.UpdatedRows != 1 {
			t.Fatalf("%s: %+v", program, result)
		}
	}
	disk, err := wbReadDisk()
	if err != nil {
		t.Fatal(err)
	}
	if len(disk.Actions) != 1 {
		t.Fatalf("manual actions changed: %+v", disk.Actions)
	}
	for _, program := range []string{"ET", "ST", "THT"} {
		job := disk.Jobs[program]
		if job.RuleVersion != policy.VersionLabel || job.Rows[0].Level != "critical" {
			t.Fatalf("%s not rejudged: %+v", program, job)
		}
	}
	failed := wbRejudgeProgram("ET", policy, nil)
	if failed.Status != "failed" || failed.Reason == "" {
		t.Fatalf("missing batch failure not explicit: %+v", failed)
	}
}

func TestRiskPolicyNoChangeDoesNotCreateVersion(t *testing.T) {
	repo := newMemoryRiskPolicyRepository()
	p, idem, unchanged, err := repo.PutCAS(context.Background(), 0, "same", "operator", wbDefaultPolicy().Rules, "same")
	if err != nil || idem || !unchanged || p.Version != 0 {
		t.Fatalf("unexpected no-change result: %+v %v %v %v", p, idem, unchanged, err)
	}
	if _, err = repo.Active(context.Background()); !errors.Is(err, sql.ErrNoRows) {
		t.Fatalf("no-change unexpectedly persisted a version: %v", err)
	}
}

func TestRiskPolicyHandlersStatusCodesAndOperatorPermission(t *testing.T) {
	wbTestEnv(t)
	repo := newMemoryRiskPolicyRepository()
	oldProvider := wbRiskRepoProvider
	wbRiskRepoProvider = func() (riskPolicyRepository, error) { return repo, nil }
	t.Cleanup(func() { wbRiskRepoProvider = oldProvider })

	read := httptest.NewRecorder()
	wbRiskPolicyListHandler(read, wbReq("reader"))
	if read.Code != 200 {
		t.Fatalf("GET status=%d body=%s", read.Code, read.Body.String())
	}

	payload := map[string]any{"expected_version": 0, "request_id": "handler-1", "confirmation_note": "test", "rules": wbDefaultPolicy().Rules}
	body, _ := json.Marshal(payload)
	forbidden := httptest.NewRecorder()
	req := httptest.NewRequest("PUT", "/api/workbench/risk-policy", bytes.NewReader(body)).WithContext(wbReq("reader").Context())
	wbRiskPolicyUpdateHandler(forbidden, req)
	if forbidden.Code != 403 {
		t.Fatalf("non-operator status=%d body=%s", forbidden.Code, forbidden.Body.String())
	}

	previewForbidden := httptest.NewRecorder()
	previewReq := httptest.NewRequest("POST", "/api/workbench/risk-policy/preview", bytes.NewReader(body)).WithContext(wbReq("reader").Context())
	wbRiskPolicyPreviewHandler(previewForbidden, previewReq)
	if previewForbidden.Code != 403 {
		t.Fatalf("non-operator preview status=%d body=%s", previewForbidden.Code, previewForbidden.Body.String())
	}

	cfg, err := cwLoadConfig()
	if err != nil || len(cfg.Operators) == 0 {
		t.Fatalf("operator config: %v", err)
	}
	preview := httptest.NewRecorder()
	previewReq = httptest.NewRequest("POST", "/api/workbench/risk-policy/preview", bytes.NewReader(body)).WithContext(wbReq(cfg.Operators[0]).Context())
	wbRiskPolicyPreviewHandler(preview, previewReq)
	if preview.Code != 200 {
		t.Fatalf("operator preview status=%d body=%s", preview.Code, preview.Body.String())
	}
	bad := httptest.NewRecorder()
	req = httptest.NewRequest("PUT", "/api/workbench/risk-policy", bytes.NewReader([]byte(`{}`))).WithContext(wbReq(cfg.Operators[0]).Context())
	wbRiskPolicyUpdateHandler(bad, req)
	if bad.Code != 400 {
		t.Fatalf("invalid status=%d body=%s", bad.Code, bad.Body.String())
	}
}

func TestLegacyPolicyNormalizationPreservesSemantics(t *testing.T) {
	var policy wbResolvedPolicy
	legacy := `{"version":7,"rules":[{"id":"absolute-watch","program":"ALL","kind":"absolute","conditions":{"ccr_gte":3,"nfs_gt":50},"risk_level":"watch","scope":{},"enabled":true},{"id":"absolute-extreme","program":"ALL","kind":"absolute","conditions":{"ccr_gte":45,"nfs_gte":300},"risk_level":"extreme","scope":{},"enabled":true},{"id":"growth-extreme","program":"ALL","kind":"growth","conditions":{"growth_gt":100,"current_ccr_gt":6},"risk_level":"extreme","scope":{},"enabled":true},{"id":"growth-ranking","program":"ALL","kind":"ranking","conditions":{"top_n":20,"positive_only":true},"risk_level":"watch","scope":{},"enabled":true}]}`
	if err := json.Unmarshal([]byte(legacy), &policy); err != nil {
		t.Fatal(err)
	}
	policy = wbNormalizePolicy(policy)
	if policy.Rules[0].MatchMode != "all" || len(policy.Rules[0].Conditions) != 2 || policy.Rules[3].Ranking == nil || policy.Rules[3].Ranking.TopN != 20 {
		t.Fatalf("legacy policy not normalized: %+v", policy)
	}
	level, _ := wbEvaluateAbsolute(f64(3), f64(51), "ET", "", "", policy)
	if level != "watch" {
		t.Fatalf("legacy semantics changed: %s", level)
	}
	job := wbJob{Policy: policy}
	if got := wbPolicyFromJob(job); got.Rules[2].Conditions[0].Metric == "" {
		t.Fatalf("legacy job policy not normalized: %+v", got)
	}
}

func TestGenericConditionsAllAnyOperatorsAndMissing(t *testing.T) {
	tests := []struct {
		name       string
		mode       string
		conditions []wbRiskCondition
		ccr, nfs   *float64
		want       string
	}{
		{"gt", "all", []wbRiskCondition{{"p0_ccr", ">", 3}}, f64(3), f64(1), "normal"},
		{"gte", "all", []wbRiskCondition{{"p0_ccr", ">=", 3}}, f64(3), f64(1), "watch"},
		{"lt", "all", []wbRiskCondition{{"p0_ccr", "<", 4}}, f64(3), f64(1), "watch"},
		{"lte", "all", []wbRiskCondition{{"p0_ccr", "<=", 3}}, f64(3), f64(1), "watch"},
		{"any-one", "any", []wbRiskCondition{{"p0_ccr", ">", 3}, {"p0_nfs", ">", 50}}, nil, f64(51), "watch"},
		{"any-all-missing", "any", []wbRiskCondition{{"p0_ccr", ">", 3}, {"p0_nfs", ">", 50}}, nil, nil, "unavailable"},
		{"all-partial-missing", "all", []wbRiskCondition{{"p0_ccr", ">", 3}, {"p0_nfs", ">", 50}}, f64(4), nil, "unavailable"},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			rule := wbRiskRuleConfig{ID: tc.name, Name: tc.name, Program: "ALL", Kind: "absolute", MatchMode: tc.mode, Conditions: tc.conditions, RiskLevel: "watch", Enabled: true}
			level, _ := wbEvaluateRow(wbRow{Program: "ET", CCR: tc.ccr, NFS: tc.nfs}, wbResolvedPolicy{Rules: []wbRiskRuleConfig{rule}})
			if level != tc.want {
				t.Fatalf("got %s want %s", level, tc.want)
			}
		})
	}
}

func TestPolicyValidationDuplicatesAndOverlapWarnings(t *testing.T) {
	rules := wbDefaultPolicy().Rules
	duplicate := rules[0]
	duplicate.ID, duplicate.Name = "duplicate", "duplicate"
	if _, err := wbValidatePolicy(append(rules, duplicate)); err == nil {
		t.Fatal("semantic duplicate accepted")
	}
	overlap := rules[0]
	overlap.ID, overlap.Name, overlap.Program = "et-overlap", "ET overlap", "ET"
	overlap.Conditions = append([]wbRiskCondition(nil), overlap.Conditions...)
	overlap.Conditions[0].Value = 4
	warnings, err := wbValidatePolicy(append(rules, overlap))
	if err != nil || len(warnings) == 0 {
		t.Fatalf("overlap warning missing: warnings=%v err=%v", warnings, err)
	}
}

func TestPolicyPreviewUsesPersistedRowsAndHasNoWriteSideEffects(t *testing.T) {
	wbTestEnv(t)
	batch := "TAP-WEEK-2026-10-19-2026-10-25"
	jobs := map[string]wbJob{}
	for _, program := range []string{"ET", "ST", "THT"} {
		jobs[program] = wbJob{ID: program, BatchID: batch, AsOf: "2026-10-26T01:00:00Z", StartedAt: "2026-10-26T01:00:00Z", Request: wbRequest{Program: program}, Policy: wbDefaultPolicy(), Rows: []wbRow{{ID: program + "-1", Program: program, Member: wbMember{AccountID: "7000000000000000001", AdvertiserID: "7000000000000000002"}, CCR: f64(2), NFS: f64(51)}}}
	}
	if err := wbWriteDisk(wbDisk{Jobs: jobs, Actions: map[string]wbAction{"manual": {Note: "keep"}}}); err != nil {
		t.Fatal(err)
	}
	before, _ := wbReadDisk()
	beforeJSON, _ := json.Marshal(before)
	rules := wbDefaultPolicy().Rules
	rules[0].Conditions = append([]wbRiskCondition(nil), rules[0].Conditions...)
	for i := range rules[0].Conditions {
		if rules[0].Conditions[i].Metric == "p0_ccr" {
			rules[0].Conditions[i].Value = 2
		}
	}
	preview, err := wbBuildPolicyPreview(0, rules)
	if err != nil {
		t.Fatal(err)
	}
	if preview.Total.Added != 3 || len(preview.SourceBatchIDs) != 1 || preview.SideEffects["aeolus"] || preview.SideEffects["jobs"] {
		t.Fatalf("unexpected preview: %+v", preview)
	}
	after, _ := wbReadDisk()
	afterJSON, _ := json.Marshal(after)
	if !bytes.Equal(beforeJSON, afterJSON) {
		t.Fatal("preview mutated persisted jobs/actions")
	}
}

func TestPreviewTokenInvalidatesWhenDraftChanges(t *testing.T) {
	rules := wbDefaultPolicy().Rules
	token := wbPreviewToken(3, wbPolicyHash(rules))
	rules[0].Conditions = append([]wbRiskCondition(nil), rules[0].Conditions...)
	rules[0].Conditions[0].Value++
	if token == wbPreviewToken(3, wbPolicyHash(rules)) {
		t.Fatal("changed draft kept old preview token")
	}
	if token == wbPreviewToken(4, wbPolicyHash(wbDefaultPolicy().Rules)) {
		t.Fatal("changed version kept old preview token")
	}
}

func TestGrowthMetricUsesOfficialProgramCadenceOnly(t *testing.T) {
	wow, qoq, protection := 20.0, 300.0, 900.0
	comparison := wbComparison{Status: "available", CCRGrowthPct: &wow, WoWStatus: "available", QoQGrowthPct: &qoq, QoQStatus: "available", ProtectionCCRGrowthPct: &protection}
	if got := wbComparisonGrowth("ET", comparison); got == nil || *got != 20 {
		t.Fatalf("ET did not use WoW: %v", got)
	}
	if got := wbComparisonGrowth("THT", comparison); got == nil || *got != 20 {
		t.Fatalf("THT did not use WoW: %v", got)
	}
	if got := wbComparisonGrowth("ST", comparison); got != nil {
		t.Fatalf("ST must remain not configured without an approved Account anchor: %v", got)
	}
	comparison.QoQGrowthPct = nil
	if wbComparisonGrowthAvailable("ST", comparison) {
		t.Fatal("ST incorrectly fell back to WoW/protection growth")
	}
	comparison.CCRGrowthPct = nil
	comparison.QoQGrowthPct = &qoq
	if wbComparisonGrowthAvailable("ET", comparison) {
		t.Fatal("ET incorrectly fell back to QoQ/protection growth")
	}
}
