package main

import (
	"fmt"
	"sort"
	"strings"
)

type chartFieldSummary struct {
	Key     string `json:"key"`
	Type    string `json:"type"`
	IsNull  bool   `json:"is_null"`
	Missing bool   `json:"missing"`
}

type chartDiagnostics struct {
	TopLevelKeys        []string            `json:"top_level_keys"`
	TopLevelFields      []chartFieldSummary `json:"top_level_fields"`
	DimensionsCount     int                 `json:"dimensions_count"`
	MetricsCount        int                 `json:"metrics_count"`
	FiltersCount        int                 `json:"filters_count"`
	OrdersPresent       bool                `json:"orders_present"`
	SortsPresent        bool                `json:"sorts_present"`
	GroupByPresent      bool                `json:"group_by_present"`
	DatasetPresent      bool                `json:"dataset_present"`
	DataSourcePresent   bool                `json:"data_source_present"`
	ChartTypePresent    bool                `json:"chart_type_present"`
	TypePresent         bool                `json:"type_present"`
	SuspiciousPaths     []string            `json:"suspicious_paths"`
	LikelyProblemPaths  []string            `json:"likely_problem_paths"`
	ClassificationHint  string              `json:"classification_hint"`
	OriginalVsSentDiffs []string            `json:"original_vs_sent_diffs"`
}

var chartDiagnosticImportantKeys = []string{
	"dimensions", "dimensionList", "metrics", "measures", "measureList", "filters", "whereList",
	"orders", "sorts", "groupBy", "groupBys", "dataset", "dataSet", "datasetId", "dataSetId", "dataSource",
	"chartType", "type", "displayType", "vizType",
}

var chartDiagnosticStringLikeKeys = map[string]bool{
	"type": true, "chartType": true, "dataType": true, "fieldType": true, "aggregation": true,
	"agg": true, "operator": true, "op": true, "sortType": true, "direction": true,
	"dateType": true, "dateMode": true, "filterType": true, "displayType": true, "vizType": true,
}

func buildChartDiagnostics(original map[string]any, sent map[string]any) chartDiagnostics {
	d := chartDiagnostics{}
	for key := range original {
		d.TopLevelKeys = append(d.TopLevelKeys, key)
	}
	sort.Strings(d.TopLevelKeys)
	for _, key := range d.TopLevelKeys {
		value := original[key]
		d.TopLevelFields = append(d.TopLevelFields, chartFieldSummary{Key: key, Type: jsonTypeName(value), IsNull: value == nil})
	}
	for _, key := range chartDiagnosticImportantKeys {
		if _, ok := original[key]; !ok {
			d.TopLevelFields = append(d.TopLevelFields, chartFieldSummary{Key: key, Type: "missing", Missing: true})
		}
	}
	d.DimensionsCount = firstArrayLength(original, "dimensions", "dimensionList", "dims")
	d.MetricsCount = firstArrayLength(original, "metrics", "measures", "measureList")
	d.FiltersCount = firstArrayLength(original, "filters", "whereList")
	d.OrdersPresent = hasAnyKey(original, "orders", "orderList")
	d.SortsPresent = hasAnyKey(original, "sorts", "sortList")
	d.GroupByPresent = hasAnyKey(original, "groupBy", "groupBys")
	d.DatasetPresent = hasAnyKey(original, "dataset", "dataSet", "datasetId", "dataSetId")
	d.DataSourcePresent = hasAnyKey(original, "dataSource", "dataSourceId")
	d.ChartTypePresent = hasAnyKey(original, "chartType", "displayType", "vizType")
	d.TypePresent = hasAnyKey(original, "type")
	d.SuspiciousPaths = collectSuspiciousChartPaths(original)
	d.LikelyProblemPaths = likelyProblemPaths(d.SuspiciousPaths)
	d.OriginalVsSentDiffs = diffChartShape(original, sent, "")
	if len(d.OriginalVsSentDiffs) == 0 {
		d.ClassificationHint = "simple_chart_schema_error_or_unsupported_report_type"
	} else {
		d.ClassificationHint = "chart_mutation_error"
	}
	return d
}

func jsonTypeName(v any) string {
	switch v.(type) {
	case nil:
		return "null"
	case string:
		return "string"
	case bool:
		return "boolean"
	case float64, float32, int, int64, int32:
		return "number"
	case []any:
		return "array"
	case map[string]any:
		return "object"
	default:
		return fmt.Sprintf("%T", v)
	}
}

func firstArrayLength(m map[string]any, keys ...string) int {
	for _, key := range keys {
		if arr, ok := m[key].([]any); ok {
			return len(arr)
		}
	}
	return 0
}

func hasAnyKey(m map[string]any, keys ...string) bool {
	for _, key := range keys {
		if _, ok := m[key]; ok {
			return true
		}
	}
	return false
}

func collectSuspiciousChartPaths(v any) []string {
	paths := []string{}
	walkChartValue(v, "", &paths)
	sort.Strings(paths)
	return paths
}

func walkChartValue(v any, path string, paths *[]string) {
	switch typed := v.(type) {
	case map[string]any:
		for key, value := range typed {
			child := key
			if path != "" {
				child = path + "." + key
			}
			lower := strings.ToLower(key)
			if value == nil {
				*paths = append(*paths, child+" = null")
			} else if s, ok := value.(string); ok && strings.TrimSpace(s) == "" {
				*paths = append(*paths, child+" = empty_string")
			} else if chartDiagnosticStringLikeKeys[lower] {
				if _, ok := value.(string); !ok {
					*paths = append(*paths, fmt.Sprintf("%s = non_string(%s)", child, jsonTypeName(value)))
				}
			}
			walkChartValue(value, child, paths)
		}
	case []any:
		for i, item := range typed {
			walkChartValue(item, fmt.Sprintf("%s[%d]", path, i), paths)
		}
	}
}

func likelyProblemPaths(paths []string) []string {
	result := []string{}
	for _, path := range paths {
		lower := strings.ToLower(path)
		for key := range chartDiagnosticStringLikeKeys {
			if strings.Contains(lower, "."+key) || strings.Contains(lower, "["+key) || strings.HasPrefix(lower, key) {
				result = append(result, path)
				break
			}
		}
	}
	if len(result) > 20 {
		return result[:20]
	}
	return result
}

func diffChartShape(a map[string]any, b map[string]any, path string) []string {
	diffs := []string{}
	keys := map[string]bool{}
	for key := range a {
		keys[key] = true
	}
	for key := range b {
		keys[key] = true
	}
	ordered := []string{}
	for key := range keys {
		ordered = append(ordered, key)
	}
	sort.Strings(ordered)
	for _, key := range ordered {
		child := key
		if path != "" {
			child = path + "." + key
		}
		av, aok := a[key]
		bv, bok := b[key]
		if !aok {
			diffs = append(diffs, child+" added_in_sent")
			continue
		}
		if !bok {
			diffs = append(diffs, child+" missing_in_sent")
			continue
		}
		at, bt := jsonTypeName(av), jsonTypeName(bv)
		if at != bt {
			diffs = append(diffs, fmt.Sprintf("%s type_changed %s->%s", child, at, bt))
			continue
		}
		am, aIsMap := av.(map[string]any)
		bm, bIsMap := bv.(map[string]any)
		if aIsMap && bIsMap {
			diffs = append(diffs, diffChartShape(am, bm, child)...)
		}
	}
	if len(diffs) > 50 {
		return diffs[:50]
	}
	return diffs
}
