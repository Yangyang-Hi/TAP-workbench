// CODE GENERATED FROM app/api/api.yaml BY tools/gen_api.py — DO NOT EDIT
package main

import "net/http"

// 本文件由 IDL 生成，登记 sync 资源的路由契约。
// 业务逻辑写在 handler_sync.go 的 handler 函数里，不要改本文件。
func init() {
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/admin/sync",
		Summary: "按数据源和运行时筛选触发同步",
		Handler: adminSyncCreate,
		Tags:    []string{"sync"},
		BodyParams: []Param{
			{Name: "source_keys", Type: "array"},
			{Name: "filters", Type: "object"},
			{Name: "force", Type: "boolean"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status": "partial",
				"runs":   []any{},
			},
		},
	})
}
