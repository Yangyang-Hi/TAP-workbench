package main

import (
	"strings"
	"testing"
)

func TestProgramAnchorsAreNotInterchanged(t *testing.T) {
	base := map[string]any{"final_result": "APPROVE", "create_date": "2026-10-01", "account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "submitter": "owner", "region": "APAC"}
	et := cloneMap(base)
	et["type_name"], et["create_time"], et["protection_starttime"] = "Emerging trust apply", "2026-09-03 01:02:03", "2026-08-01"
	members, _, err := canonicalWBMembers([]map[string]any{et}, wbRequest{Program: "ET", Region: "all", MemberStart: "2026-01-01", MemberEnd: "2026-12-31"}, true)
	if err != nil || len(members) != 1 || dateOnly(members[0].Start) != "2026-09-03" {
		t.Fatalf("ET must use create_time: members=%+v err=%v", members, err)
	}

	tht := cloneMap(base)
	tht["type_name"], tht["ticket_id"], tht["protection_program_name"] = "Protection program", "ticket-1", "Temporary High Trust (THT) - Advertiser ID"
	tht["create_time"], tht["protection_starttime"] = "2026-09-03", "2026-09-20 12:00:00"
	members, _, err = canonicalWBMembers([]map[string]any{tht}, wbRequest{Program: "THT", Region: "all", MemberStart: "2026-01-01", MemberEnd: "2026-12-31"}, true)
	if err != nil || len(members) != 1 || dateOnly(members[0].Start) != "2026-09-20" {
		t.Fatalf("THT must use protection_starttime: members=%+v err=%v", members, err)
	}
}

func TestLegacyNaturalWeekFieldIsNeverPromoted(t *testing.T) {
	legacy := wbNormalizeLegacyComparison("ET", wbComparison{PreCCR: f64(1), PostCCR: f64(2), WoWGrowthPct: f64(100)})
	if legacy.CCRGrowthPct != nil || legacy.WoWGrowthPct == nil || legacy.WoWStatus != "legacy_invalid" || !strings.Contains(legacy.WoWMissingReason, "不可作为CCR Increase") {
		t.Fatalf("legacy natural-week value was promoted: %+v", legacy)
	}
	st := wbNormalizeLegacyComparison("ST", wbComparison{PreCCR: f64(1), PostCCR: f64(2), Rolling90DGrowthPct: f64(100)})
	if st.CCRGrowthPct != nil || st.Status != metricNotConfigured {
		t.Fatalf("legacy ST value must not be promoted: %+v", st)
	}
}

func TestReportedReasonsPartialMarksFailureWithoutFabricatingReasons(t *testing.T) {
	dict := reportedReasonDictionary{ByKey: map[string]reportedReasonMapping{"known": {OriginalLabel: "known", DisplayNameEN: "Known"}}}
	rows := []map[string]any{{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "semantics_label_tier_1_2_3_4": "known", "dynamic_p0_ccr": 2.0}}
	got := rankReportedReasonsDetailed(dict, rows, false, "saved report top20 partial")
	key := wbPairKey{"7000000000000000001", "7100000000000000001"}
	if len(got.Reasons[key]) != 0 || got.Status[key] != metricFailed || got.Errors[key] != "saved report top20 partial" {
		t.Fatalf("partial source must be explicit failure without a fabricated ranking: %+v", got)
	}
	evidence := map[string][]wbAdvertiserEvidence{"7000000000000000001": {{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000002", CCR: f64(9), MetricStatus: "success"}}}
	if err := attachReportedReasons(evidence, rows, false, "saved report top20 partial"); err != nil {
		t.Fatal(err)
	}
	item := evidence["7000000000000000001"][0]
	if item.CCR == nil || item.ReportedReasonsStatus != metricFailed || item.ReportedReasonsError != "saved report top20 partial" || len(item.ReportedReasons) != 0 {
		t.Fatalf("valid advertiser must remain while reason failure stays explicit: %+v", item)
	}
}
