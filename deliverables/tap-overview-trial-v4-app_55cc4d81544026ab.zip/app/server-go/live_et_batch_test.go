package main

import (
	"context"
	"encoding/json"
	"math"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// TestLiveETMetricBatch is opt-in and read-only. It verifies that the ET metric
// Saved Report accepts an IN filter and maps every requested account_id to either
// a fact row or an explicit no_data result without per-account queries.
func TestLiveETMetricBatch(t *testing.T) {
	if os.Getenv("RUN_LIVE_ET_BATCH") != "1" {
		t.Skip("set RUN_LIVE_ET_BATCH=1 for real ET batch verification")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())

	const start, end = "2026-10-01", "2026-10-20"
	membershipRequest := httptest.NewRequest(http.MethodGet, "/api/live?start_date="+start+"&end_date="+end+"&client_tier=emerging_trust", nil)
	membershipRequest.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	ctx, cancel := context.WithTimeout(context.Background(), 180*time.Second)
	defer cancel()
	probe, err := runTitanVQSProbe(ctx, membershipRequest, "et_account_list")
	if err != nil || asString(probe["status"]) != "ok" {
		t.Fatalf("membership query failed: err=%v status=%s request_id=%s log_id=%s", err, asString(probe["status"]), asString(probe["requestId"]), asString(probe["logId"]))
	}
	cfg, err := loadDataSourceConfig()
	if err != nil {
		t.Fatal(err)
	}
	proven, reason := proveETTypeNameFilterContract("et_account_list", cfg.Sources["et_account_list"], probe["effective_filters"])
	var rows []map[string]any
	encoded, _ := json.Marshal(probe["business_rows"])
	_ = json.Unmarshal(encoded, &rows)
	rows, _ = supplementETTypeNameFromContract(rows, proven)
	members, _, err := canonicalWBMembers(rows, wbRequest{Program: "ET", Region: "all", MemberStart: start, MemberEnd: end}, true)
	if err != nil || !proven || reason != "" || len(members) < 2 {
		t.Fatalf("membership cannot supply a live batch: members=%d proven=%t reason=%s err=%v", len(members), proven, reason, err)
	}
	ids := []string{members[0].AccountID, members[1].AccountID}
	if len(members) > 2 {
		ids = append(ids, members[2].AccountID)
	}
	metricRequest := httptest.NewRequest(http.MethodGet, "/api/live", nil)
	metricRequest.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	metrics, err := queryETCurrentBatch(ctx, metricRequest, ids, start, end)
	if err != nil {
		t.Fatal(err)
	}
	successFacts := 0
	noData := 0
	for _, id := range ids {
		metric, ok := metrics[id]
		if !ok || (metric.Status != "success" && metric.Status != "no_data") {
			t.Fatalf("account_id %s was not mapped: %#v", id, metric)
		}
		if metric.Status == "success" && (metric.CCR != nil || metric.NFS != nil) {
			successFacts++
		}
		if metric.Status == "no_data" {
			noData++
		}
	}
	proof, _ := json.Marshal(map[string]any{"membership_count": len(members), "batch_size": len(ids), "mapped_count": len(metrics), "success_facts": successFacts, "no_data": noData})
	t.Log(string(proof))
}

// TestLiveAuthoritativeAccountReports is opt-in and read-only. It proves the
// production Account-grain CCR/NFS and Revenue Saved Reports for the fixed test
// event without creating an Alert or sending any notification.
func TestLiveAuthoritativeAccountReports(t *testing.T) {
	if os.Getenv("RUN_LIVE_ACCOUNT_REPORT") != "1" {
		t.Skip("set RUN_LIVE_ACCOUNT_REPORT=1 for real Account report verification")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())

	const accountID, start, end = "7462465462811770896", "2026-10-12", "2026-10-18"
	req := httptest.NewRequest(http.MethodGet, "/api/live", nil)
	req.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	ctx, cancel := context.WithTimeout(context.Background(), 180*time.Second)
	defer cancel()
	metrics, err := queryETCurrentBatch(ctx, req, []string{accountID}, start, end)
	if err != nil {
		t.Fatal(err)
	}
	metric := metrics[accountID]
	if metric.CCR != nil && metric.NFS != nil && metric.Revenue != nil {
		t.Logf("actual ccr=%.17g nfs=%.17g revenue=%.17g", *metric.CCR, *metric.NFS, *metric.Revenue)
	}
	if metric.Status != "success" || metric.CCR == nil || math.Abs(*metric.CCR-8.552188750450918) > 1e-12 || metric.NFS == nil || *metric.NFS != 61 || metric.Revenue == nil || math.Abs(*metric.Revenue-4080.989999999989) > 1e-9 {
		t.Fatalf("authoritative Account values mismatch: %+v", metric)
	}
	if metric.RequestID == "" || metric.LogID == "" || metric.RevenueRequestID == "" || metric.RevenueLogID == "" {
		t.Fatalf("request/log evidence missing: %+v", metric)
	}
	t.Logf("account_id=%s window=%s..%s ccr=%.15g nfs=%.15g revenue=%.15g request_id=%s log_id=%s revenue_request_id=%s revenue_log_id=%s", accountID, start, end, *metric.CCR, *metric.NFS, *metric.Revenue, metric.RequestID, metric.LogID, metric.RevenueRequestID, metric.RevenueLogID)
}
