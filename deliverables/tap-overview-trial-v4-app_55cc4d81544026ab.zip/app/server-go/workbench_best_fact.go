package main

import "strings"

// wbFactRank orders persisted facts by business completeness, not by write time.
// A later failed/not_queried checkpoint must never erase an older terminal fact.
func wbFactRank(f metricFact) int {
	status := strings.ToLower(strings.TrimSpace(f.Status))
	if f.Value != nil {
		return 100
	}
	switch status {
	case metricSourceNull, "no_data", "real_zero":
		return 90
	case "window_incomplete":
		return 80
	case metricMissingAnchor, metricAmbiguousAnchor:
		return 70
	case metricNotApplicable:
		return 60
	case metricNotConfigured:
		return 40
	case metricQuerying, "pending", "running", "not_queried", "":
		return 10
	case metricFailed, "error", "query_failed", "source_error":
		return 0
	default:
		return 20
	}
}

func wbBestFact(current, candidate metricFact) metricFact {
	if wbFactRank(candidate) > wbFactRank(current) {
		return candidate
	}
	return current
}

func wbStatusFact(value *float64, status, reason string) metricFact {
	if value != nil {
		return successfulMetricFact(value)
	}
	if strings.TrimSpace(status) == "" {
		return metricFact{Status: "not_queried", Reason: reason}
	}
	if strings.EqualFold(status, "window_incomplete") {
		return metricFact{Status: "window_incomplete", Reason: reason}
	}
	if strings.EqualFold(status, "not_queried") {
		return metricFact{Status: "not_queried", Reason: reason}
	}
	return legacyMetricFact(value, status, reason)
}

func wbMergeFloatFact(value **float64, status *string, reason *string, candidateValue *float64, candidateStatus, candidateReason string) {
	currentFact := wbStatusFact(*value, *status, *reason)
	candidateFact := wbStatusFact(candidateValue, candidateStatus, candidateReason)
	if wbFactRank(candidateFact) <= wbFactRank(currentFact) {
		return
	}
	*value = candidateValue
	*status = candidateFact.Status
	*reason = candidateFact.Reason
	if candidateValue != nil {
		*status = metricAvailable
		*reason = ""
	}
}

func wbMergeMetricFact(value **float64, fact *metricFact, candidateValue *float64, candidateFact metricFact) {
	current := *fact
	if current.Status == "" {
		current = wbStatusFact(*value, "", "")
	}
	if candidateFact.Status == "" {
		candidateFact = wbStatusFact(candidateValue, "", "")
	}
	if wbFactRank(candidateFact) < wbFactRank(current) || wbFactRank(candidateFact) == wbFactRank(current) && fact.Status != "" {
		return
	}
	*value = candidateValue
	*fact = candidateFact
	if candidateValue != nil {
		*fact = successfulMetricFact(candidateValue)
	}
}

func wbMergeString(current *string, candidate string) {
	if strings.TrimSpace(*current) == "" && strings.TrimSpace(candidate) != "" {
		*current = candidate
	}
}

func wbMergeMemberBest(current *wbMember, candidate wbMember) {
	wbMergeString(&current.AccountID, candidate.AccountID)
	wbMergeString(&current.AdvertiserID, candidate.AdvertiserID)
	wbMergeString(&current.Name, candidate.Name)
	wbMergeString(&current.BrandName, candidate.BrandName)
	wbMergeString(&current.AdvertiserName, candidate.AdvertiserName)
	wbMergeString(&current.Region, candidate.Region)
	wbMergeString(&current.Submitter, candidate.Submitter)
	wbMergeString(&current.TicketID, candidate.TicketID)
	wbMergeString(&current.Start, candidate.Start)
	wbMergeString(&current.End, candidate.End)
	wbMergeString(&current.CreateDate, candidate.CreateDate)
	wbMergeString(&current.Quarter, candidate.Quarter)
	wbMergeString(&current.EndorsementReason, candidate.EndorsementReason)
	wbMergeString(&current.ProtectionProgramName, candidate.ProtectionProgramName)
	wbMergeString(&current.ProtectionBusinessline, candidate.ProtectionBusinessline)
	wbMergeString(&current.ProtectionEstimatedSpend, candidate.ProtectionEstimatedSpend)
	wbMergeString(&current.ProtectionStatus, candidate.ProtectionStatus)
	wbMergeString(&current.Tier, candidate.Tier)
	if len(current.LinkedAccountIDs) == 0 && len(candidate.LinkedAccountIDs) > 0 {
		current.LinkedAccountIDs = append([]string(nil), candidate.LinkedAccountIDs...)
	}
	if len(current.LinkedAdvertiserIDs) == 0 && len(candidate.LinkedAdvertiserIDs) > 0 {
		current.LinkedAdvertiserIDs = append([]string(nil), candidate.LinkedAdvertiserIDs...)
	}
	if len(current.Submitters) == 0 && len(candidate.Submitters) > 0 {
		current.Submitters = append([]string(nil), candidate.Submitters...)
	}
	if len(current.Tickets) == 0 && len(candidate.Tickets) > 0 {
		current.Tickets = append([]wbTicket(nil), candidate.Tickets...)
	}
	if current.Name != "" && strings.EqualFold(current.MetadataStatus, "partial") {
		current.MetadataStatus = "available"
	}
}

func wbMergeComparisonBest(current *wbComparison, candidate wbComparison) {
	wbMergeMetricFact(&current.PreCCR, &current.PreCCRFact, candidate.PreCCR, candidate.PreCCRFact)
	wbMergeMetricFact(&current.PostCCR, &current.PostCCRFact, candidate.PostCCR, candidate.PostCCRFact)
	current.IncreaseFact = wbBestFact(current.IncreaseFact, candidate.IncreaseFact)
	if current.PreNFS == nil && candidate.PreNFS != nil {
		current.PreNFS = candidate.PreNFS
	}
	if current.PostNFS == nil && candidate.PostNFS != nil {
		current.PostNFS = candidate.PostNFS
	}
	if current.WoWGrowthPct == nil && candidate.WoWGrowthPct != nil {
		current.WoWGrowthPct = candidate.WoWGrowthPct
		current.WoWStatus, current.WoWMissingReason = candidate.WoWStatus, candidate.WoWMissingReason
	} else if wbFactRank(wbStatusFact(current.WoWGrowthPct, current.WoWStatus, current.WoWMissingReason)) < wbFactRank(wbStatusFact(candidate.WoWGrowthPct, candidate.WoWStatus, candidate.WoWMissingReason)) {
		current.WoWGrowthPct, current.WoWStatus, current.WoWMissingReason = candidate.WoWGrowthPct, candidate.WoWStatus, candidate.WoWMissingReason
	}
	currentRank := wbFactRank(wbStatusFact(current.CCRGrowthPct, current.Status, current.MissingReason))
	candidateRank := wbFactRank(wbStatusFact(candidate.CCRGrowthPct, candidate.Status, candidate.MissingReason))
	if candidateRank > currentRank {
		current.Status, current.MissingReason, current.Kind = candidate.Status, candidate.MissingReason, candidate.Kind
		current.PreStart, current.PreEndExclusive = candidate.PreStart, candidate.PreEndExclusive
		current.PostStart, current.PostEndExclusive = candidate.PostStart, candidate.PostEndExclusive
		current.Timezone, current.Source = candidate.Timezone, candidate.Source
	}
	// Pre/Post Revenue is intentionally outside the ET contract and must not be resurrected.
	current.PreRevenue, current.PostRevenue = nil, nil
	current.RevenueDelta, current.RevenueGrowthPct = nil, nil
	wbFinalizeComparison(current)
}

func wbMergeEvidenceBest(current, candidate wbAdvertiserEvidence) wbAdvertiserEvidence {
	wbMergeString(&current.AccountName, candidate.AccountName)
	wbMergeString(&current.AdvertiserName, candidate.AdvertiserName)
	wbMergeMetricFact(&current.CCR, &current.CCRFact, candidate.CCR, candidate.CCRFact)
	wbMergeMetricFact(&current.NFS, &current.NFSFact, candidate.NFS, candidate.NFSFact)
	wbMergeMetricFact(&current.Revenue, &current.RevenueFact, candidate.Revenue, candidate.RevenueFact)
	wbMergeMetricFact(&current.PreCCR, &current.PreCCRFact, candidate.PreCCR, candidate.PreCCRFact)
	wbMergeMetricFact(&current.PostCCR, &current.PostCCRFact, candidate.PostCCR, candidate.PostCCRFact)
	current.IncreaseFact = wbBestFact(current.IncreaseFact, candidate.IncreaseFact)
	if len(current.ReportedReasons) == 0 && len(candidate.ReportedReasons) > 0 {
		current.ReportedReasons = append([]reportedReason(nil), candidate.ReportedReasons...)
		current.ReportedReasonsStatus = candidate.ReportedReasonsStatus
		current.ReportedReasonsError = candidate.ReportedReasonsError
		current.ReportedReasonsBasis = candidate.ReportedReasonsBasis
	}
	if strings.TrimSpace(current.SemanticsLabel) == "" && strings.TrimSpace(candidate.SemanticsLabel) != "" {
		current.SemanticsLabel, current.SemanticsStatus = candidate.SemanticsLabel, candidate.SemanticsStatus
	}
	if current.AllowlistStatus == "" || strings.EqualFold(current.AllowlistStatus, "unknown") {
		wbMergeString(&current.AllowlistStatus, candidate.AllowlistStatus)
		if strings.EqualFold(current.AllowlistStatus, "unknown") && !strings.EqualFold(candidate.AllowlistStatus, "unknown") && candidate.AllowlistStatus != "" {
			current.AllowlistStatus = candidate.AllowlistStatus
		}
	}
	current.PreRevenue, current.PostRevenue = nil, nil
	current.RevenueDelta, current.RevenueGrowthPct = nil, nil
	return current
}

func wbMergeEvidenceListBest(current, candidate []wbAdvertiserEvidence) []wbAdvertiserEvidence {
	byKey := map[wbPairKey]int{}
	out := append([]wbAdvertiserEvidence(nil), current...)
	for i, item := range out {
		byKey[wbPairKey{AccountID: item.AccountID, AdvertiserID: item.AdvertiserID}] = i
	}
	for _, item := range candidate {
		key := wbPairKey{AccountID: item.AccountID, AdvertiserID: item.AdvertiserID}
		if i, ok := byKey[key]; ok {
			out[i] = wbMergeEvidenceBest(out[i], item)
			continue
		}
		byKey[key] = len(out)
		out = append(out, item)
	}
	return out
}

func wbMergeMapBest(current, candidate map[string]any) map[string]any {
	if current == nil {
		current = map[string]any{}
	}
	for key, candidateValue := range candidate {
		currentValue, exists := current[key]
		if !exists || currentValue == nil || strings.TrimSpace(asString(currentValue)) == "" {
			current[key] = candidateValue
			continue
		}
		currentMap, currentOK := currentValue.(map[string]any)
		candidateMap, candidateOK := candidateValue.(map[string]any)
		if currentOK && candidateOK {
			current[key] = wbMergeMapBest(currentMap, candidateMap)
			continue
		}
		if strings.EqualFold(key, "status") {
			currentFact := wbStatusFact(nil, asString(currentValue), "")
			candidateFact := wbStatusFact(nil, asString(candidateValue), "")
			if wbFactRank(candidateFact) > wbFactRank(currentFact) {
				current[key] = candidateValue
			}
		}
	}
	return current
}

// wbMergeRowBestFacts merges facts by field/stage. The receiver is normally the
// newest row; candidates may be older snapshots. Equal-quality facts keep the
// newer value, while older completed facts repair newer failures or blanks.
func wbMergeRowBestFacts(current, candidate wbRow) wbRow {
	wbMergeMemberBest(&current.Member, candidate.Member)
	ccrStatus, ccrReason := current.MetricStatus, current.Error
	wbMergeFloatFact(&current.CCR, &ccrStatus, &ccrReason, candidate.CCR, candidate.MetricStatus, candidate.Error)
	nfsStatus, nfsReason := current.MetricStatus, current.Error
	wbMergeFloatFact(&current.NFS, &nfsStatus, &nfsReason, candidate.NFS, candidate.MetricStatus, candidate.Error)
	current.MetricStatus = ccrStatus
	if wbFactRank(wbStatusFact(current.NFS, nfsStatus, nfsReason)) > wbFactRank(wbStatusFact(current.CCR, ccrStatus, ccrReason)) {
		current.MetricStatus, current.Error = nfsStatus, nfsReason
	} else {
		current.Error = ccrReason
	}
	currentRevenueStatus, currentRevenueReason := wbRowRevenueState(current)
	candidateRevenueStatus, candidateRevenueReason := wbRowRevenueState(candidate)
	wbMergeFloatFact(&current.Revenue, &currentRevenueStatus, &currentRevenueReason, candidate.Revenue, candidateRevenueStatus, candidateRevenueReason)
	wbMergeComparisonBest(&current.Comparison, candidate.Comparison)
	current.Advertisers = wbMergeEvidenceListBest(current.Advertisers, candidate.Advertisers)
	current.AdvertiserTop10 = wbMergeEvidenceListBest(current.AdvertiserTop10, candidate.AdvertiserTop10)
	if len(current.Reasons) == 0 && len(candidate.Reasons) > 0 {
		current.Reasons = append([]string(nil), candidate.Reasons...)
	}
	if (current.AllowlistStatus == "" || strings.EqualFold(current.AllowlistStatus, "unknown")) && candidate.AllowlistStatus != "" && !strings.EqualFold(candidate.AllowlistStatus, "unknown") {
		current.AllowlistStatus = candidate.AllowlistStatus
	}
	if current.AdvertiserCount < candidate.AdvertiserCount {
		current.AdvertiserCount = candidate.AdvertiserCount
	}
	currentSource, _ := current.Source.(map[string]any)
	candidateSource, _ := candidate.Source.(map[string]any)
	current.Source = wbMergeMapBest(currentSource, candidateSource)
	if current.CCR != nil || current.NFS != nil || current.Revenue != nil {
		current.DataStatus = "Partial Fact"
	}
	if current.CCR != nil && current.NFS != nil && current.Revenue != nil {
		current.DataStatus = "Success"
	}
	return current
}
