package main

import (
	"bytes"
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

const stSnapshotSourceURL = "https://bytedance.larkoffice.com/wiki/BvySwO6zuiH9IEkzsU8c9pksnxc?sheet=wKgK4I"

type stSnapshotRow struct {
	Quarter           string `json:"quarter"`
	SalesRegion       string `json:"sales_region"`
	BrandName         string `json:"brand_name"`
	AccountID         string `json:"account_id"`
	EndorsementReason string `json:"endorsement_reason"`
	AdexSubmitter     string `json:"adex_submitter"`
	StartDate         string `json:"start_date"`
}

type stQuarterSnapshot struct {
	Quarter          string            `json:"quarter"`
	PeriodBasis      string            `json:"period_basis"`
	SheetName        string            `json:"sheet_name"`
	SourceURL        string            `json:"source_url"`
	SourceModifiedAt string            `json:"source_modified_at,omitempty"`
	SourceRevision   int64             `json:"source_revision,omitempty"`
	SyncedAt         string            `json:"synced_at"`
	SyncedBy         string            `json:"synced_by,omitempty"`
	SyncResult       string            `json:"sync_result"`
	Fields           []string          `json:"fields"`
	Rows             []stSnapshotRow   `json:"rows"`
	RowCount         int               `json:"row_count"`
	MetricSemantics  string            `json:"metric_semantics"`
	FieldSemantics   map[string]string `json:"field_semantics"`
}

type stSnapshotState struct {
	Snapshots   map[string]stQuarterSnapshot `json:"snapshots"`
	LastAttempt map[string]any               `json:"last_attempt,omitempty"`
}

func stSnapshotPath() (string, error) {
	dir, err := resolveDataDir()
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	return filepath.Join(dir, "st_snapshots.json"), nil
}

func readSTSnapshotState() (stSnapshotState, error) {
	path, err := stSnapshotPath()
	if err != nil {
		return stSnapshotState{}, err
	}
	raw, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return stSnapshotState{Snapshots: map[string]stQuarterSnapshot{}}, nil
	}
	if err != nil {
		return stSnapshotState{}, err
	}
	var state stSnapshotState
	if err := json.Unmarshal(raw, &state); err != nil {
		return stSnapshotState{}, err
	}
	if state.Snapshots == nil {
		state.Snapshots = map[string]stQuarterSnapshot{}
	}
	return state, nil
}

func writeSTSnapshotState(state stSnapshotState) error {
	path, err := stSnapshotPath()
	if err != nil {
		return err
	}
	raw, err := json.MarshalIndent(state, "", "  ")
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, raw, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func readSTQuarterFromLark(ctx context.Context, quarter, actor string) (stQuarterSnapshot, error) {
	quarter = strings.ToUpper(strings.TrimSpace(quarter))
	titles := map[string]string{"Q4": "2026 Q4 ST Application", "Q3": "2026 Q3 TAP 3.0 ST Application"}
	sheetIDs := map[string]string{"Q4": "wKgK4I", "Q3": "a4a678"}
	headerRow := map[string]int{"Q4": 1, "Q3": 0}
	title, ok := titles[quarter]
	if !ok {
		return stQuarterSnapshot{}, errors.New("quarter must be Q3 or Q4")
	}
	readCtx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()
	cmd := exec.CommandContext(readCtx, "lark-cli", "sheets", "+csv-get", "--url", stSnapshotSourceURL, "--sheet-id", sheetIDs[quarter], "--range", "A1:G5000", "--include-row-prefix=false", "--max-chars", "1000000")
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	raw, err := cmd.Output()
	if err != nil {
		return stQuarterSnapshot{}, fmt.Errorf("user-context Sheet read failed for %s: %s", quarter, strings.TrimSpace(stderr.String()))
	}
	text := extractCSVText(raw)
	records, err := csv.NewReader(strings.NewReader(text)).ReadAll()
	if err != nil || len(records) <= headerRow[quarter] {
		return stQuarterSnapshot{}, fmt.Errorf("invalid %s Sheet CSV", quarter)
	}
	headers := map[string]int{}
	for i, value := range records[headerRow[quarter]] {
		headers[strings.TrimSpace(value)] = i
	}
	columns := []string{"Sales Region", "Brand Name", "Account ID", "Endorsement Reason", "Adex Submitter", "Start date"}
	for _, name := range columns {
		if _, exists := headers[name]; !exists {
			return stQuarterSnapshot{}, fmt.Errorf("%s Sheet missing column %s", quarter, name)
		}
	}
	rows := make([]stSnapshotRow, 0, len(records))
	seen := map[string]bool{}
	value := func(record []string, name string) string {
		idx := headers[name]
		if idx >= len(record) {
			return ""
		}
		return strings.TrimSpace(record[idx])
	}
	for _, record := range records[headerRow[quarter]+1:] {
		accountID := value(record, "Account ID")
		if !decimalID.MatchString(accountID) {
			continue
		}
		// Only deduplicate within this authoritative quarter/batch. The same Account
		// ID in another quarter remains a separate membership record.
		if seen[accountID] {
			continue
		}
		seen[accountID] = true
		rows = append(rows, stSnapshotRow{Quarter: quarter, SalesRegion: value(record, "Sales Region"), BrandName: value(record, "Brand Name"), AccountID: accountID, EndorsementReason: value(record, "Endorsement Reason"), AdexSubmitter: value(record, "Adex Submitter"), StartDate: value(record, "Start date")})
	}
	return stQuarterSnapshot{Quarter: quarter, PeriodBasis: map[string]string{"Q3": "Full Quarter", "Q4": "QTD"}[quarter], SheetName: title, SourceURL: stSnapshotSourceURL, SyncedBy: actor, SourceModifiedAt: time.Now().UTC().Format(time.RFC3339), Rows: rows}, nil
}

func syncSTSnapshotsFromLark(ctx context.Context, actor string) (stSnapshotState, error) {
	snapshots := make([]stQuarterSnapshot, 0, 2)
	for _, quarter := range []string{"Q4", "Q3"} {
		snapshot, err := readSTQuarterFromLark(ctx, quarter, actor)
		if err != nil {
			return readSTSnapshotStateWithAttempt(actor, err)
		}
		snapshots = append(snapshots, snapshot)
	}
	return saveSTSnapshots(snapshots, actor)
}

func readSTSnapshotStateWithAttempt(actor string, cause error) (stSnapshotState, error) {
	state, _ := readSTSnapshotState()
	state.LastAttempt = map[string]any{"status": "failed", "at": time.Now().UTC().Format(time.RFC3339), "by": actor, "error": cause.Error()}
	_ = writeSTSnapshotState(state)
	return state, cause
}

func validateSTSnapshot(s *stQuarterSnapshot) error {
	s.Quarter = strings.ToUpper(strings.TrimSpace(s.Quarter))
	if s.Quarter != "Q3" && s.Quarter != "Q4" {
		return errors.New("quarter must be Q3 or Q4")
	}
	expectedBasis := map[string]string{"Q3": "Full Quarter", "Q4": "QTD"}[s.Quarter]
	if strings.TrimSpace(s.PeriodBasis) != expectedBasis {
		return fmt.Errorf("%s period_basis must be %s", s.Quarter, expectedBasis)
	}
	if strings.TrimSpace(s.SourceURL) == "" {
		s.SourceURL = stSnapshotSourceURL
	}
	if len(s.Rows) == 0 {
		return errors.New("rows must not be empty")
	}
	deduped := make([]stSnapshotRow, 0, len(s.Rows))
	seen := map[string]bool{}
	for i, row := range s.Rows {
		row.Quarter = s.Quarter
		row.AccountID = strings.TrimSpace(row.AccountID)
		if strings.TrimSpace(row.SalesRegion) == "" || strings.TrimSpace(row.BrandName) == "" || row.AccountID == "" {
			return fmt.Errorf("row %d missing Sales Region, Brand Name or Account ID", i+1)
		}
		if seen[row.AccountID] {
			continue
		}
		seen[row.AccountID] = true
		deduped = append(deduped, row)
	}
	s.Rows = deduped
	s.Fields = []string{"Sales Region", "Brand Name", "Account ID", "Endorsement Reason", "Adex Submitter", "Start date", "Quarter"}
	s.RowCount = len(s.Rows)
	s.SyncResult = "success"
	s.MetricSemantics = "The quarter sheet contains approved ST client detail rows, not a total quota or pre-aggregated usage table. Brand Name is brand metadata and must not populate Account Name. Start date semantics are unverified and must not drive membership windows or Pre/Post protection comparisons."
	s.FieldSemantics = map[string]string{"Brand Name": "brand metadata; not Account Name", "Start date": "source metadata; protection-start semantics unverified"}
	return nil
}

func saveSTSnapshots(in []stQuarterSnapshot, actor string) (stSnapshotState, error) {
	state, err := readSTSnapshotState()
	if err != nil {
		return state, err
	}
	now := time.Now().UTC().Format(time.RFC3339)
	validated := make([]stQuarterSnapshot, len(in))
	copy(validated, in)
	for i := range validated {
		if err := validateSTSnapshot(&validated[i]); err != nil {
			state.LastAttempt = map[string]any{"status": "failed", "at": now, "by": actor, "error": err.Error()}
			_ = writeSTSnapshotState(state)
			return state, err
		}
		validated[i].SyncedAt, validated[i].SyncedBy = now, actor
	}
	for _, snapshot := range validated {
		state.Snapshots[snapshot.Quarter] = snapshot
	}
	state.LastAttempt = map[string]any{"status": "success", "at": now, "by": actor, "quarters": len(validated)}
	return state, writeSTSnapshotState(state)
}

func loadSTFromSnapshot(quarter string) ([]stMetric, map[string]any, error) {
	state, err := readSTSnapshotState()
	if err != nil {
		return nil, nil, fmt.Errorf("unavailable: read saved ST snapshot: %w", err)
	}
	snapshot, ok := state.Snapshots[strings.ToUpper(strings.TrimSpace(quarter))]
	if !ok || snapshot.SyncResult != "success" {
		return nil, nil, errors.New("unavailable: no successful saved ST snapshot")
	}
	metrics := make([]stMetric, 0, len(snapshot.Rows))
	for _, row := range snapshot.Rows {
		region, brand, accountID := strings.TrimSpace(row.SalesRegion), strings.TrimSpace(row.BrandName), strings.TrimSpace(row.AccountID)
		if region == "" || (brand == "" && accountID == "") {
			continue
		}
		metrics = append(metrics, stMetric{Region: region, Brand: brand, AccountID: accountID})
	}
	previewLimit := 200
	if len(snapshot.Rows) < previewLimit {
		previewLimit = len(snapshot.Rows)
	}
	preview := snapshot.Rows[:previewLimit]
	meta := map[string]any{"quarter": snapshot.Quarter, "period_basis": snapshot.PeriodBasis, "sheet_name": snapshot.SheetName, "source_url": snapshot.SourceURL, "source_modified_at": snapshot.SourceModifiedAt, "source_revision": snapshot.SourceRevision, "synced_at": snapshot.SyncedAt, "synced_by": snapshot.SyncedBy, "sync_result": snapshot.SyncResult, "fields": snapshot.Fields, "field_semantics": snapshot.FieldSemantics, "row_count": snapshot.RowCount, "metric_semantics": snapshot.MetricSemantics, "rows": preview, "rows_returned": len(preview), "last_attempt": state.LastAttempt}
	return metrics, meta, nil
}

func stSnapshotSummaries(state stSnapshotState) []map[string]any {
	keys := make([]string, 0, len(state.Snapshots))
	for key := range state.Snapshots {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	out := make([]map[string]any, 0, len(keys))
	for _, key := range keys {
		s := state.Snapshots[key]
		out = append(out, map[string]any{"quarter": s.Quarter, "period_basis": s.PeriodBasis, "row_count": s.RowCount, "source_modified_at": s.SourceModifiedAt, "synced_at": s.SyncedAt, "sync_result": s.SyncResult, "source_url": s.SourceURL})
	}
	return out
}
