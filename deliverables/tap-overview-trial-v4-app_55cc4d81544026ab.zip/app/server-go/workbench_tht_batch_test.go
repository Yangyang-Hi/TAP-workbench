package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"testing"
)

func makeTHTMembers(count int) []wbMember {
	members := make([]wbMember, 0, count)
	for i := 0; i < count; i++ {
		members = append(members, wbMember{AdvertiserID: fmt.Sprintf("78%016d", i), TicketID: fmt.Sprintf("ticket-%d", i), Submitter: "owner"})
	}
	return members
}

func TestTHT5400UsesEveryIDInBoundedChunks(t *testing.T) {
	wbTestEnv(t)
	oldMembers, oldBatch := wbLoadMembers, wbQueryTHTBatch
	defer func() { wbLoadMembers, wbQueryTHTBatch = oldMembers, oldBatch }()
	members := makeTHTMembers(5400)
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return members, true, nil
	}
	calls, seen := 0, map[string]bool{}
	wbQueryTHTBatch = func(_ context.Context, _ *http.Request, ids []string, _, _ string) (map[string][]wbBatchMetric, error) {
		calls++
		if len(ids) > wbTHTMetricChunkSize {
			t.Fatalf("oversized chunk: %d", len(ids))
		}
		out := make(map[string][]wbBatchMetric, len(ids))
		for _, id := range ids {
			if seen[id] {
				t.Fatalf("duplicate ID %s", id)
			}
			seen[id] = true
			out[id] = []wbBatchMetric{{Status: "success", CCR: f64(1), NFS: f64(2)}}
		}
		return out, nil
	}
	config, err := loadWBConfig()
	if err != nil || config.MaxClients != 6000 {
		t.Fatalf("config must cover the verified 5400-member THT pool while retaining a finite guard: %+v err=%v", config, err)
	}
	wbRunning["tht-5400"] = &wbJob{ID: "tht-5400", Principal: "Alice", Request: wbRequest{Program: "THT", Start: "2026-10-01", End: "2026-10-07"}, Rule: testRule(), Status: "running"}
	wbRunJob(wbReq("Alice"), "tht-5400", config)
	job, err := wbLookup("tht-5400", "Alice")
	if err != nil || job.Status != "ready" || job.Members != 5400 || job.Done != 5400 || len(job.Rows) != 5400 || len(seen) != 5400 || calls != 54 {
		t.Fatalf("job=%+v seen=%d calls=%d err=%v", job, len(seen), calls, err)
	}
	if job.Rows[0].Advertisers[0].Revenue != nil || job.Rows[0].Advertisers[0].RevenueStatus != "" || !strings.Contains(job.Rows[0].AggregationNote, "Revenue 状态：") {
		t.Fatal("THT Revenue status contract changed")
	}
}

func TestTHTBatchFailureKeepsCheckpointRowsAndFailsWholeScan(t *testing.T) {
	wbTestEnv(t)
	oldMembers, oldBatch := wbLoadMembers, wbQueryTHTBatch
	defer func() { wbLoadMembers, wbQueryTHTBatch = oldMembers, oldBatch }()
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return makeTHTMembers(101), true, nil
	}
	calls := 0
	wbQueryTHTBatch = func(_ context.Context, _ *http.Request, ids []string, _, _ string) (map[string][]wbBatchMetric, error) {
		calls++
		if calls == 2 {
			return nil, errors.New("source unavailable")
		}
		out := map[string][]wbBatchMetric{}
		for _, id := range ids {
			out[id] = []wbBatchMetric{{Status: "success", CCR: f64(1), NFS: f64(2)}}
		}
		return out, nil
	}
	config, _ := loadWBConfig()
	wbRunning["tht-fail"] = &wbJob{ID: "tht-fail", Principal: "Alice", Request: wbRequest{Program: "THT"}, Rule: testRule(), Status: "running"}
	wbRunJob(wbReq("Alice"), "tht-fail", config)
	job, _ := wbLookup("tht-fail", "Alice")
	if job.Status != "failed" || len(job.Rows) != wbTHTMetricChunkSize || job.Done != wbTHTMetricChunkSize || !strings.Contains(job.Error, "chunk 2/2") {
		t.Fatalf("batch failure did not preserve diagnostic checkpoint rows: %+v", job)
	}
}

func TestScanBudgetBoundaryAndExplicitOverflow(t *testing.T) {
	wbTestEnv(t)
	oldMembers, oldBatch := wbLoadMembers, wbQueryTHTBatch
	defer func() { wbLoadMembers, wbQueryTHTBatch = oldMembers, oldBatch }()
	config, _ := loadWBConfig()
	members := makeTHTMembers(config.MaxClients + 1)
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return members, true, nil
	}
	wbQueryTHTBatch = func(context.Context, *http.Request, []string, string, string) (map[string][]wbBatchMetric, error) {
		t.Fatal("overflow must not query")
		return nil, nil
	}
	wbRunning["overflow"] = &wbJob{ID: "overflow", Principal: "Alice", Request: wbRequest{Program: "THT"}, Rule: testRule(), Status: "running"}
	wbRunJob(wbReq("Alice"), "overflow", config)
	job, _ := wbLookup("overflow", "Alice")
	want := fmt.Sprintf("%d clients exceed max_clients_per_scan=%d", config.MaxClients+1, config.MaxClients)
	if job.Status != "blocked" || job.Members != config.MaxClients+1 || !strings.Contains(job.Error, want) {
		t.Fatalf("overflow not explicit: %+v", job)
	}
}

func TestTHTSourceUsesS05AndPreservesReturnedAccountAssociation(t *testing.T) {
	wbTestEnv(t)
	cfg, err := loadDataSourceConfig()
	if err != nil {
		t.Fatal(err)
	}
	source := cfg.Sources["tht_current_ccr_nfs"]
	if source.RID != 2942519 || source.Identity.IDDimension != "advertiser_id" || source.Grain != "account_advertiser_week" {
		t.Fatalf("THT authority mismatch: %+v", source)
	}
	metric := wbBatchMetric{Status: "success", AccountID: "7000000000000000001", CCR: f64(1), NFS: f64(2), RevenueStatus: "no_data"}
	rows, err := wbRowsFromTHTBatch([]wbMember{{AdvertiserID: "7100000000000000001", AccountID: "7999999999999999999"}}, map[string][]wbBatchMetric{"7100000000000000001": {metric}}, wbRequest{Program: "THT"}, testRule())
	if err != nil {
		t.Fatal(err)
	}
	if rows[0].Advertisers[0].AccountID != metric.AccountID {
		t.Fatalf("membership account replaced the S05 association: %+v", rows[0].Advertisers[0])
	}
}

func TestPairGrainFilterIntegrityAllowsRepeatedAdvertiserRowsButRejectsScopeLeak(t *testing.T) {
	source := sourceConfig{Grain: "account_advertiser_week", Fields: map[string]fieldConfig{"advertiser_id": {DimMetID: "advertiser-field", UniqueID: "advertiser-uid"}}}
	rows := []map[string]any{
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001"},
		{"account_id": "7000000000000000002", "advertiser_id": "7100000000000000001"},
	}
	integrity := verifyReturnedIDs(source, "advertiser_id", []string{"7100000000000000001"}, rows)
	if integrity.Status != "verified" || integrity.DuplicateN != 1 || !allowsRepeatedIDRows(source, "advertiser_id") || len(integrity.Wrong) != 0 || integrity.NullN != 0 {
		t.Fatalf("legitimate repeated advertiser failed pair-grain integrity: %+v", integrity)
	}
	rows = append(rows, map[string]any{"account_id": "7000000000000000003", "advertiser_id": "7199999999999999999"})
	integrity = verifyReturnedIDs(source, "advertiser_id", []string{"7100000000000000001"}, rows)
	if integrity.Status == "verified" || len(integrity.Wrong) != 1 {
		t.Fatalf("scope leak was silently accepted: %+v", integrity)
	}
}

func TestTHTBatchPreservesOneAdvertiserAcrossMultipleAccounts(t *testing.T) {
	oldProbe := thtVQSProbe
	defer func() { thtVQSProbe = oldProbe }()
	advertiserID := "7100000000000000001"
	thtVQSProbe = func(_ context.Context, _ *http.Request, source string) (map[string]any, error) {
		base := map[string]any{"status": "ok", "report_id": 2942519, "dataset_id": 1139137, "requestId": source + "-request", "queriedAt": "2026-10-22T00:00:00Z"}
		if source == "tht_current_ccr_nfs" {
			base["business_rows"] = []map[string]any{
				{"account_id": "7000000000000000001", "advertiser_id": advertiserID, "dynamic_p0_ccr": 7.0, "p0_nfs": 11.0, "semantics_label_tier_1_2_3_4": "ads_delivery_issues - dislike_or_report_mapping - dislike_other_issues - "},
				{"account_id": "7000000000000000002", "advertiser_id": advertiserID, "dynamic_p0_ccr": 9.0, "p0_nfs": 13.0},
			}
			return base, nil
		}
		base["report_id"] = 2942918
		base["business_rows"] = []map[string]any{
			{"account_id": "7000000000000000001", "advertiser_id": advertiserID, "revenue": 101.0},
			{"account_id": "7000000000000000002", "advertiser_id": advertiserID, "revenue": 202.0},
		}
		return base, nil
	}
	req, _ := http.NewRequest(http.MethodGet, "http://example.test/api", nil)
	metrics, err := queryTHTCurrentBatch(context.Background(), req, []string{advertiserID}, "2026-10-12", "2026-10-18")
	if err != nil {
		t.Fatal(err)
	}
	pairs := metrics[advertiserID]
	if len(pairs) != 2 || pairs[0].AccountID != "7000000000000000001" || pairs[1].AccountID != "7000000000000000002" || pairs[0].Revenue == nil || *pairs[0].Revenue != 101 || pairs[1].Revenue == nil || *pairs[1].Revenue != 202 || pairs[0].SemanticsLabel != "ads_delivery_issues - dislike_or_report_mapping - dislike_other_issues -" || pairs[1].SemanticsLabel != "" {
		t.Fatalf("pair facts were collapsed or copied across accounts: %+v", pairs)
	}
	rows, err := wbRowsFromTHTBatch([]wbMember{{AdvertiserID: advertiserID, TicketID: "ticket"}}, metrics, wbRequest{Program: "THT", Start: "2026-10-12", End: "2026-10-18"}, testRule())
	if err != nil || len(rows) != 2 || rows[0].ID == rows[1].ID || rows[0].Advertisers[0].AccountID == rows[1].Advertisers[0].AccountID || rows[0].Advertisers[0].SemanticsLabel != "ads_delivery_issues - dislike_or_report_mapping - dislike_other_issues -" {
		t.Fatalf("pair-grain rows not preserved: rows=%+v err=%v", rows, err)
	}
}
