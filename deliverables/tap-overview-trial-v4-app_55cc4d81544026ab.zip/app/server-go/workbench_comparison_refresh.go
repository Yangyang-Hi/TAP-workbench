package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"
)

var wbTargetedLoadMembers = wbLoadTargetedETMembers

func wbLoadTargetedETMembers(ctx context.Context, request *http.Request, q wbRequest, c wbConfig) ([]wbMember, bool, error) {
	probe, err := runTitanVQSProbe(ctx, request, "et_quota_tickets")
	if err != nil {
		return nil, false, err
	}
	if asString(probe["status"]) != "ok" {
		return nil, false, accountProbeError("ET targeted membership", probe)
	}
	if truncated, _ := probe["possibly_truncated"].(bool); truncated {
		return nil, false, errors.New("targeted membership result truncated")
	}
	rows := mustBusinessRows(probe)
	members, complete, err := canonicalWBMembers(rows, q, c.MembershipCompleteConfirmed)
	if err != nil {
		return nil, false, err
	}
	return members, complete, nil
}

var wbTargetedQueryAccount = queryAccountComparisonBatch

type wbComparisonRefreshRequest struct {
	AccountID string `json:"account_id"`
	Program   string `json:"program"`
}

func wbPersistedMemberAnchor(accountID, program string, jobs []wbJob) (wbMember, bool) {
	var selected wbMember
	for _, job := range jobs {
		for _, row := range job.Rows {
			if !strings.EqualFold(row.Program, program) || row.Member.AccountID != accountID {
				continue
			}
			candidates := []string{strings.TrimSpace(row.Member.Start), strings.TrimSpace(row.Member.CreateDate)}
			for _, ticket := range row.Member.Tickets {
				candidates = append(candidates, strings.TrimSpace(ticket.Start), strings.TrimSpace(ticket.CreateDate))
			}
			for _, candidate := range candidates {
				if _, err := time.ParseInLocation("2006-01-02", dateOnly(candidate), cwLocation()); err == nil && candidate > selected.Start {
					selected = row.Member
					selected.Start = candidate
				}
			}
		}
	}
	return selected, strings.TrimSpace(selected.Start) != ""
}

func wbTargetedMembership(ctx context.Context, request *http.Request, accountID, program string, jobs []wbJob, config wbConfig) (wbMember, map[string]any, error) {
	var lastErr error
	for _, job := range jobs {
		if !strings.EqualFold(job.Request.Program, program) {
			continue
		}
		q := job.Request
		if q.MemberStart == "" {
			q.MemberStart = q.Start
		}
		if q.MemberEnd == "" {
			q.MemberEnd = q.End
		}
		u := *request.URL
		targetedRequest := request.Clone(ctx)
		targetedRequest.URL = &u
		query := u.Query()
		query.Set("account_id", accountID)
		query.Set("client_ids", accountID)
		query.Set("id_dimension", "account_id")
		targetedRequest.URL.RawQuery = query.Encode()
		members, complete, err := wbTargetedLoadMembers(ctx, targetedRequest, q, config)
		if err != nil {
			lastErr = err
			continue
		}
		for _, member := range members {
			if member.AccountID == accountID {
				// Historical aggregates may have selected a duplicate membership row whose
				// anchor was empty. For a targeted repair, derive the newest non-empty exact
				// source create_time anchor from this ET account only.
				anchor, anchorDate := strings.TrimSpace(member.Start), member.CreateDate
				for _, ticket := range member.Tickets {
					candidate := strings.TrimSpace(ticket.Start)
					if candidate != "" && (anchor == "" || ticket.CreateDate > anchorDate || ticket.CreateDate == anchorDate && candidate > anchor) {
						anchor, anchorDate = candidate, ticket.CreateDate
					}
				}
				member.Start = anchor
				logMsg(fmt.Sprintf("[comparison-refresh] membership target account_id=%s selected_anchor=%s create_date=%s ticket_count=%d", accountID, sanitizeLogText(member.Start), sanitizeLogText(member.CreateDate), len(member.Tickets)), "plugin")
				if strings.TrimSpace(member.Start) != "" {
					return member, map[string]any{"membership_complete": complete, "member_start_date": q.MemberStart, "member_end_date": q.MemberEnd, "source": config.MembershipSource, "anchor_source": "membership_create_time"}, nil
				}
				lastErr = errors.New("create_time_source_null:target account returned with empty create_time")
				continue
			}
		}
		lastErr = errors.New("target account not returned by membership source")
	}
	if member, ok := wbPersistedMemberAnchor(accountID, program, jobs); ok {
		logMsg(fmt.Sprintf("[comparison-refresh] recovered persisted source anchor account_id=%s selected_anchor=%s", accountID, sanitizeLogText(member.Start)), "plugin")
		return member, map[string]any{"source": config.MembershipSource, "anchor_source": "persisted_membership_source_evidence", "source_lookup_error": sanitizeLogText(fmt.Sprint(lastErr))}, nil
	}
	if lastErr == nil {
		lastErr = errors.New("create_time_mapping_failed:no current persisted row for account and program")
	} else if strings.HasPrefix(lastErr.Error(), "create_time_source_null:") {
		// Preserve the authoritative source-empty classification.
	} else if strings.Contains(lastErr.Error(), "not returned") {
		lastErr = fmt.Errorf("create_time_mapping_failed:%w", lastErr)
	} else {
		lastErr = fmt.Errorf("create_time_technical_failed:%w", lastErr)
	}
	return wbMember{}, nil, lastErr
}

func wbRefreshComparison(ctx context.Context, request *http.Request, accountID, program string, now time.Time) (map[string]any, error) {
	program = strings.ToUpper(strings.TrimSpace(program))
	accountID = strings.TrimSpace(accountID)
	if !decimalID.MatchString(accountID) {
		return nil, errors.New("account_id must be a 16-20 digit string")
	}
	if program != "ET" {
		return nil, errors.New("program currently supports ET only")
	}
	config, err := loadWBConfig()
	if err != nil {
		return nil, err
	}

	wbMu.Lock()
	defer wbMu.Unlock()
	state, err := wbReadDisk()
	if err != nil {
		return nil, err
	}
	jobs := make([]wbJob, 0, len(state.Jobs))
	for _, job := range state.Jobs {
		for _, row := range job.Rows {
			if strings.EqualFold(row.Program, program) && row.Member.AccountID == accountID {
				jobs = append(jobs, job)
				break
			}
		}
	}
	if len(jobs) == 0 {
		return nil, errors.New("no current persisted row for account and program")
	}
	member, membershipAudit, err := wbTargetedMembership(ctx, request, accountID, program, jobs, config)
	if err != nil {
		return nil, fmt.Errorf("targeted membership lookup failed: %w", err)
	}
	window, err := wbBuildComparisonWindow(program, member.Start, now)
	if err != nil {
		return nil, err
	}
	queryPostEnd := window.PostEnd
	lastCompleteDay := now.In(cwLocation()).AddDate(0, 0, -1).Format("2006-01-02")
	latestPersistedEnd := ""
	for _, job := range jobs {
		for _, row := range job.Rows {
			if row.Member.AccountID == accountID && job.Request.End > latestPersistedEnd {
				latestPersistedEnd = job.Request.End
				break
			}
		}
	}
	if latestPersistedEnd != "" && latestPersistedEnd < lastCompleteDay {
		lastCompleteDay = latestPersistedEnd
	}
	if queryPostEnd > lastCompleteDay {
		queryPostEnd = lastCompleteDay
	}
	queryWindow := func(start, end string) (wbBatchMetric, error) {
		queryCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
		defer cancel()
		metrics, queryErr := wbTargetedQueryAccount(queryCtx, request, []string{accountID}, start, end, "et_current_ccr_nfs", program)
		if queryErr != nil {
			return wbBatchMetric{}, queryErr
		}
		metric, ok := metrics[accountID]
		if !ok {
			return wbBatchMetric{}, errors.New("account window result missing")
		}
		if metric.Status != "success" && metric.Status != "no_data" {
			return wbBatchMetric{}, fmt.Errorf("account window result unavailable: %s", metric.Status)
		}
		return metric, nil
	}
	pre, err := queryWindow(window.PreStart, window.PreEnd)
	if err != nil {
		return nil, fmt.Errorf("pre window query failed: %w", err)
	}
	post, err := queryWindow(window.PostStart, queryPostEnd)
	if err != nil {
		return nil, fmt.Errorf("post window query failed: %w", err)
	}
	comparison := wbSuccessfulComparison(program, member.Start, pre.CCR, post.CCR, now)
	comparison.PreNFS, comparison.PostNFS = pre.NFS, post.NFS
	wbFinalizeComparison(&comparison)
	queryStatus := "success"
	if pre.Status == "no_data" || post.Status == "no_data" || pre.CCR == nil || post.CCR == nil {
		queryStatus = metricSourceNull
	}
	if !window.Complete {
		comparison.Status = "window_incomplete"
		comparison.MissingReason = "post_observation_window_not_complete"
		comparison.CCRGrowthPct = nil
		comparison.IncreaseFact = queryingMetricFact("Post 观察窗口尚未结束")
		comparison.PostCCRFact = metricFact{Value: post.CCR, Status: metricQuerying, Reason: "Post 观察窗口尚未结束"}
		queryStatus = "window_incomplete"
	}
	comparison.Source = map[string]any{
		"source": "et_current_ccr_nfs", "rid": 2979783, "grain": "account_window", "aggregation": "whole_window_source_metric_not_daily_average", "window_complete": window.Complete,
		"filters":     map[string]any{"id_dimension": "account_id", "account_id": accountID, "pre": []string{window.PreStart, window.PreEnd}, "post": []string{window.PostStart, queryPostEnd}},
		"request_ids": map[string]string{"pre": pre.RequestID, "post": post.RequestID}, "log_ids": map[string]string{"pre": pre.LogID, "post": post.LogID}, "query_status": queryStatus,
	}

	updatedRows, updatedJobs := 0, 0
	for id, job := range state.Jobs {
		changed := false
		for i := range job.Rows {
			row := &job.Rows[i]
			if !strings.EqualFold(row.Program, program) || row.Member.AccountID != accountID {
				continue
			}
			row.Member.Start = member.Start
			row.Comparison = comparison
			updatedRows++
			changed = true
		}
		if changed {
			state.Jobs[id] = job
			updatedJobs++
		}
	}
	if updatedRows == 0 {
		return nil, errors.New("target row disappeared before persistence")
	}
	if err := wbWriteDisk(state); err != nil {
		return nil, err
	}
	updatedCases := 0
	caseRepo, repoErr := cwCaseworkRepositoryProvider()
	if repoErr != nil {
		return nil, fmt.Errorf("persisted scan rows but case repository is unavailable: %w", repoErr)
	}
	cases, repoErr := caseRepo.listCases(ctx)
	if repoErr != nil {
		return nil, fmt.Errorf("persisted scan rows but cases could not be listed: %w", repoErr)
	}
	for _, item := range cases {
		if !strings.EqualFold(item.Row.Program, program) || item.Row.Member.AccountID != accountID {
			continue
		}
		previous := item.Version
		item.Row.Member.Start = member.Start
		item.Row.Comparison = comparison
		item.Version++
		item.UpdatedAt = now.Format(time.RFC3339)
		if repoErr = caseRepo.saveCaseCAS(ctx, item, previous); repoErr != nil {
			return nil, fmt.Errorf("persisted scan rows but case %s refresh failed: %w", item.ID, repoErr)
		}
		updatedCases++
	}
	completeness := "complete"
	if !window.Complete {
		completeness = "window_incomplete"
	}
	logMsg(fmt.Sprintf("[comparison-refresh] targeted_only=true program=%s account_id=%s anchor=%s pre=%s..%s post=%s..%s updated_jobs=%d updated_rows=%d updated_cases=%d pre_request_id=%s post_request_id=%s completeness=%s", program, accountID, dateOnly(member.Start), window.PreStart, window.PreEnd, window.PostStart, window.PostEnd, updatedJobs, updatedRows, updatedCases, pre.RequestID, post.RequestID, completeness), "plugin")
	return map[string]any{
		"status": "success", "account_id": accountID, "program": program, "anchor": dateOnly(member.Start),
		"windows":    map[string]any{"pre": []string{window.PreStart, window.PreEnd}, "post": []string{window.PostStart, window.PostEnd}, "post_observed_through": queryPostEnd},
		"comparison": comparison, "updated_rows": updatedRows, "updated_jobs": updatedJobs, "updated_cases": updatedCases, "targeted_only": true,
		"side_effects": map[string]bool{"case_status": false, "actions": false, "notifications": false}, "completeness": completeness,
		"audit": map[string]any{"membership": membershipAudit, "pre_request_id": pre.RequestID, "post_request_id": post.RequestID, "pre_log_id": pre.LogID, "post_log_id": post.LogID},
	}, nil
}

func wbComparisonRefreshHandler(w http.ResponseWriter, r *http.Request) {
	var body wbComparisonRefreshRequest
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "invalid JSON body"})
		return
	}
	result, err := wbRefreshComparison(r.Context(), r, body.AccountID, body.Program, time.Now())
	if err != nil {
		logMsg(fmt.Sprintf("[comparison-refresh] failed targeted_only=true program=%s account_id=%s error=%s", sanitizeLogText(body.Program), sanitizeLogText(body.AccountID), sanitizeLogText(err.Error())), "plugin")
		writeJSON(w, http.StatusUnprocessableEntity, map[string]any{"error": err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"data": result})
}
