package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
)

const reportedReasonMappingVersion = "2026-10-26.v1"

var reasonSeparator = regexp.MustCompile(`\s+-\s+`)

type reportedReason struct {
	OriginalLabel      string   `json:"original_label"`
	RawPath            string   `json:"raw_path"`
	DisplayNameEN      string   `json:"display_name_en"`
	MappedName         string   `json:"mapped_name"`
	Description        string   `json:"description"`
	MappingStatus      string   `json:"mapping_status"`
	SourceStatus       string   `json:"source_status,omitempty"`
	SourceReason       string   `json:"source_reason,omitempty"`
	QueryStatus        string   `json:"query_status"`
	SortBasis          string   `json:"sort_basis,omitempty"`
	P0CCR              *float64 `json:"p0_ccr"`
	P0NFS              *float64 `json:"p0_nfs"`
	Rank               *int     `json:"rank"`
	RankingAvailable   bool     `json:"ranking_available"`
	RankingUnavailable string   `json:"ranking_unavailable_reason,omitempty"`
}

type reportedReasonMappingFile struct {
	Version string                  `json:"version"`
	Entries []reportedReasonMapping `json:"entries"`
}

type reportedReasonMapping struct {
	OriginalLabel string `json:"original_label"`
	DisplayNameEN string `json:"display_name_en"`
	Description   string `json:"description"`
	MappingStatus string `json:"mapping_status"`
}

type reportedReasonDictionary struct {
	Version string
	ByKey   map[string]reportedReasonMapping
}

func normalizeReportedReasonLabel(label string) string {
	parts := reasonSeparator.Split(label, -1)
	for i := range parts {
		parts[i] = strings.TrimSpace(parts[i])
	}
	return strings.Join(parts, " - ")
}

func parseReportedReasonDictionary(raw []byte) (reportedReasonDictionary, error) {
	var file reportedReasonMappingFile
	if err := json.Unmarshal(raw, &file); err != nil {
		return reportedReasonDictionary{}, err
	}
	if file.Version != reportedReasonMappingVersion {
		return reportedReasonDictionary{}, fmt.Errorf("unsupported reported reason mapping version %q", file.Version)
	}
	if len(file.Entries) != 126 {
		return reportedReasonDictionary{}, fmt.Errorf("reported reason mapping must contain 126 entries, got %d", len(file.Entries))
	}
	out := reportedReasonDictionary{Version: file.Version, ByKey: make(map[string]reportedReasonMapping, len(file.Entries))}
	for _, entry := range file.Entries {
		key := normalizeReportedReasonLabel(entry.OriginalLabel)
		if existing, ok := out.ByKey[key]; ok {
			return reportedReasonDictionary{}, fmt.Errorf("reported reason normalized-key collision: %q and %q", existing.OriginalLabel, entry.OriginalLabel)
		}
		out.ByKey[key] = entry
	}
	return out, nil
}

var (
	reportedReasonsOnce sync.Once
	reportedReasonsDict reportedReasonDictionary
	reportedReasonsErr  error
)

func loadReportedReasonDictionary() (reportedReasonDictionary, error) {
	reportedReasonsOnce.Do(func() {
		raw, err := os.ReadFile(filepath.Join(pluginDir, "config", "reported_reason_mapping.json"))
		if err != nil {
			reportedReasonsErr = err
			return
		}
		reportedReasonsDict, reportedReasonsErr = parseReportedReasonDictionary(raw)
	})
	return reportedReasonsDict, reportedReasonsErr
}

func mapReportedReason(dict reportedReasonDictionary, label string, ccr, nfs *float64) reportedReason {
	original := label
	if entry, ok := dict.ByKey[normalizeReportedReasonLabel(label)]; ok {
		return reportedReason{OriginalLabel: original, RawPath: original, DisplayNameEN: entry.DisplayNameEN, MappedName: entry.DisplayNameEN, Description: entry.Description, MappingStatus: entry.MappingStatus, SourceStatus: "verified", QueryStatus: "success", P0CCR: ccr, P0NFS: nfs}
	}
	return reportedReason{OriginalLabel: original, RawPath: original, DisplayNameEN: "Unmapped Reason", MappedName: "Unmapped Reason", Description: "原始标签尚未纳入固定映射，已保留供维护。", MappingStatus: "unmapped", SourceStatus: "verified", QueryStatus: "success", P0CCR: ccr, P0NFS: nfs}
}

func noSemanticLabelReason() reportedReason {
	return reportedReason{DisplayNameEN: "No Semantic Label", Description: "源标签数组为空；不等于无风险。", MappingStatus: "no_semantic_label", SourceStatus: "verified", QueryStatus: "success", RankingAvailable: false, RankingUnavailable: "source semantic label is empty"}
}

func unavailableReportedReason(reason string) reportedReason {
	if strings.TrimSpace(reason) == "" {
		reason = "pending_source: authoritative single-label CCR source is unavailable"
	}
	return reportedReason{DisplayNameEN: "Reported Reasons Unavailable", MappedName: "Reported Reasons Unavailable", Description: "原因级来源查询未成功；未生成 Top3。", MappingStatus: "unavailable", SourceStatus: metricFailed, QueryStatus: metricFailed, SourceReason: reason, RankingUnavailable: reason}
}

type reportedReasonRanking struct {
	Reasons   map[wbPairKey][]reportedReason
	Status    map[wbPairKey]string
	Errors    map[wbPairKey]string
	SortBasis map[wbPairKey]string
}

func reportedReasonField(row map[string]any, aliases ...string) any {
	for _, alias := range aliases {
		if value, ok := row[alias]; ok {
			return value
		}
	}
	for key, value := range row {
		for _, alias := range aliases {
			if strings.EqualFold(strings.TrimSpace(key), strings.TrimSpace(alias)) {
				return value
			}
		}
	}
	return nil
}

func rankReportedReasonsDetailed(dict reportedReasonDictionary, rows []map[string]any, complete bool, unavailableReason string) reportedReasonRanking {
	out := reportedReasonRanking{
		Reasons: map[wbPairKey][]reportedReason{}, Status: map[wbPairKey]string{},
		Errors: map[wbPairKey]string{}, SortBasis: map[wbPairKey]string{},
	}
	grouped := map[wbPairKey][]reportedReason{}
	for _, row := range rows {
		key := wbPairKey{strings.TrimSpace(asString(row["account_id"])), strings.TrimSpace(asString(row["advertiser_id"]))}
		if !validPair(key.AccountID, key.AdvertiserID) {
			continue
		}
		if !complete {
			out.Status[key], out.Errors[key] = metricFailed, unavailableReason
			continue
		}
		label := strings.TrimSpace(asString(row["semantics_label_tier_1_2_3_4"]))
		if label == "" {
			continue
		}
		rawCCR := reportedReasonField(row, "dynamic_p0_ccr", "Dynamic P0 Content CCR")
		ccr, ccrErr := strictWBMetric(rawCCR)
		nfs, nfsErr := strictWBMetric(reportedReasonField(row, "p0_nfs", "P0: Negative Feedback Show"))
		// Negative CCR is a valid source observation but is ineligible for Top3;
		// preserve it long enough for the ranking filter to exclude it truthfully.
		if ccrErr != nil {
			if value, ok := rawCCR.(float64); ok && !math.IsNaN(value) && !math.IsInf(value, 0) && value < 0 {
				ccr, ccrErr = &value, nil
			}
		}
		if ccrErr != nil || nfsErr != nil {
			out.Status[key] = metricFailed
			out.Errors[key] = sanitizeLogText(fmt.Sprintf("原因指标解析失败: ccr=%v nfs=%v", ccrErr, nfsErr))
			continue
		}
		grouped[key] = append(grouped[key], mapReportedReason(dict, label, ccr, nfs))
	}
	for key, reasons := range grouped {
		if out.Status[key] == metricFailed {
			continue
		}
		allCCRNull := true
		for _, reason := range reasons {
			if reason.P0CCR != nil {
				allCCRNull = false
				break
			}
		}
		basis := "p0_ccr_desc"
		valid := make([]reportedReason, 0, len(reasons))
		if allCCRNull {
			basis = "nfs_fallback_all_ccr_null"
			for _, reason := range reasons {
				if reason.P0NFS != nil && !math.IsNaN(*reason.P0NFS) && !math.IsInf(*reason.P0NFS, 0) && *reason.P0NFS > 0 {
					valid = append(valid, reason)
				}
			}
		} else {
			for _, reason := range reasons {
				if reason.P0CCR != nil && !math.IsNaN(*reason.P0CCR) && !math.IsInf(*reason.P0CCR, 0) && *reason.P0CCR > 0 {
					valid = append(valid, reason)
				}
			}
		}
		sort.SliceStable(valid, func(i, j int) bool {
			var left, right float64
			if allCCRNull {
				left, right = *valid[i].P0NFS, *valid[j].P0NFS
			} else {
				left, right = *valid[i].P0CCR, *valid[j].P0CCR
			}
			if left != right {
				return left > right
			}
			return valid[i].OriginalLabel < valid[j].OriginalLabel
		})
		if len(valid) > 3 {
			valid = valid[:3]
		}
		for i := range valid {
			rank := i + 1
			valid[i].Rank = &rank
			valid[i].RankingAvailable = true
			valid[i].SortBasis = basis
		}
		out.Reasons[key], out.Status[key], out.SortBasis[key] = valid, metricAvailable, basis
	}
	return out
}

func rankReportedReasons(dict reportedReasonDictionary, rows []map[string]any, complete bool, unavailableReason string) map[wbPairKey][]reportedReason {
	return rankReportedReasonsDetailed(dict, rows, complete, unavailableReason).Reasons
}

func attachReportedReasons(evidence map[string][]wbAdvertiserEvidence, rows []map[string]any, complete bool, reason string) error {
	dict, err := loadReportedReasonDictionary()
	if err != nil {
		return err
	}
	ranked := rankReportedReasonsDetailed(dict, rows, complete, reason)
	for accountID, items := range evidence {
		for i := range items {
			key := wbPairKey{items[i].AccountID, items[i].AdvertiserID}
			items[i].ReportedReasons = ranked.Reasons[key]
			items[i].ReportedReasonsStatus = ranked.Status[key]
			items[i].ReportedReasonsError = ranked.Errors[key]
			items[i].ReportedReasonsBasis = ranked.SortBasis[key]
			if items[i].ReportedReasonsStatus == "" {
				if complete {
					items[i].ReportedReasonsStatus = metricAvailable
				} else {
					items[i].ReportedReasonsStatus = metricFailed
					items[i].ReportedReasonsError = reason
				}
			}
		}
		evidence[accountID] = items
	}
	return nil
}

func reportedReasonRowsCompleteness(rows []map[string]any, sourcePossiblyTruncated bool) (bool, string) {
	if sourcePossiblyTruncated {
		return false, "Reason ranking unavailable: configured reason-level result was truncated"
	}
	if rows == nil {
		return false, "Reason ranking unavailable: label-level source returned no auditable row set"
	}
	return true, ""
}

var errReportedReasonCandidateSetIncomplete = errors.New("reported reason candidate set incomplete")
