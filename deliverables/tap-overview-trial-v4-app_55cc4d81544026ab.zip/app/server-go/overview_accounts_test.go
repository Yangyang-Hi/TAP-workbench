package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

type overviewRoundTrip func(*http.Request) (*http.Response, error)

func (f overviewRoundTrip) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func TestOverviewExecutesExistingTitanSavedReportPipeline(t *testing.T) {
	oldClient, oldDir := httpClient, pluginDir
	pluginDir, _ = filepath.Abs("../..")
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	t.Setenv("AIME_PLUGIN_RUNTIME_DIR", t.TempDir())
	t.Cleanup(func() { httpClient, pluginDir = oldClient, oldDir })
	s := overviewAccountSourceConfig()
	dims := []any{}
	for _, key := range []string{"p_date", "region", "client_tier"} {
		dims = append(dims, map[string]any{"dimMetId": s.Fields[key].DimMetID, "uniqueId": key + "_uid", "name": s.Fields[key].SourceName})
	}
	report := map[string]any{"version": 4, "schema": map[string]any{"dimensions": dims, "measures": []any{map[string]any{"uniqueId": "count_uid", "name": "TAP Accounts"}}}, "query": map[string]any{"datasetId": 1280034, "dimensions": []any{dims[2]}, "measures": []any{map[string]any{"name": "TAP Accounts", "expression": "COUNT(DISTINCT account_id)"}}, "whereList": []any{}}}
	queries := 0
	httpClient = &http.Client{Transport: overviewRoundTrip(func(r *http.Request) (*http.Response, error) {
		var payload any
		switch r.URL.Path {
		case "/titan/passport/token":
			payload = map[string]any{"data": map[string]any{"token": "fixture-titan"}}
		case aeolusSessionProbePath:
			payload = map[string]any{"code": 0}
		case aeolusSavedReportPath:
			payload = map[string]any{"data": map[string]any{"reqJson": report}}
		case aeolusVQSQueryPath:
			queries++
			var body map[string]any
			if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
				t.Fatal(err)
			}
			query := body["query"].(map[string]any)
			foundRegion, foundDate := false, false
			for _, item := range query["whereList"].([]any) {
				f := item.(map[string]any)
				if f["id"] == s.Fields["region"].DimMetID {
					foundRegion = true
					v := f["val"].([]any)
					if len(v) != 1 || v[0] != "APAC" {
						t.Fatal("Region was incorrectly encoded", f)
					}
				}
				if f["id"] == s.Fields["p_date"].DimMetID {
					foundDate = true
					if !strings.Contains(fmt.Sprint(f["val"]), "2026-10-26") {
						t.Fatal(f)
					}
				}
			}
			if !foundRegion || !foundDate {
				t.Fatal("source filters not pushed", query)
			}
			rows := []any{}
			for i, k := range overviewTierKeys {
				rows = append(rows, map[string]any{"client_tier_uid": k, "count_uid": i + 1})
			}
			payload = map[string]any{"code": 0, "data": map[string]any{"rows": rows}}
		default:
			return nil, fmt.Errorf("unexpected external request: %s", r.URL.Path)
		}
		b, _ := json.Marshal(payload)
		return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"application/json"}}, Body: io.NopCloser(strings.NewReader(string(b))), Request: r}, nil
	})}
	r := httptest.NewRequest("GET", "/api/overview/accounts", nil)
	r.Header.Set("Authorization", "Byte-Cloud-JWT fixture")
	o := overviewLoadAccounts(context.Background(), r, "2026-10-26", "APAC")
	if o.Status != "available" || o.Total == nil || *o.Total != 10 || queries != 1 {
		t.Fatalf("Saved Report pipeline failed: %+v", o)
	}
}

func overviewTestRows() []map[string]any {
	rows := []map[string]any{}
	for i, key := range overviewTierKeys {
		rows = append(rows, map[string]any{"client_tier": key, "account_count": float64((i + 1) * 10)})
	}
	return rows
}

func TestOverviewAccountSharesAndPartialBoundaries(t *testing.T) {
	for _, tc := range []struct {
		name, status string
		change       func([]map[string]any) []map[string]any
	}{
		{"complete", "available", func(r []map[string]any) []map[string]any { return r }},
		{"missing_tier", "partial", func(r []map[string]any) []map[string]any { return r[:3] }},
		{"unknown", "partial", func(r []map[string]any) []map[string]any {
			return append(r, map[string]any{"client_tier": "unknown", "account_count": 12})
		}},
		{"null", "partial", func(r []map[string]any) []map[string]any { r[0]["account_count"] = nil; return r }},
		{"negative", "partial", func(r []map[string]any) []map[string]any { r[0]["account_count"] = -1; return r }},
		{"fraction", "partial", func(r []map[string]any) []map[string]any { r[0]["account_count"] = 1.5; return r }},
		{"duplicate", "unavailable", func(r []map[string]any) []map[string]any { return append(r, r[0]) }},
	} {
		t.Run(tc.name, func(t *testing.T) {
			o := overviewParseAccounts(overviewEmpty("2026-10-26", "Global"), tc.change(overviewTestRows()))
			if o.Status != tc.status {
				t.Fatalf("status %s: %s", o.Status, o.Reason)
			}
			if tc.name == "complete" {
				if o.Total == nil || *o.Total != 100 || *o.Rows[0].Share != 10 {
					t.Fatal(o)
				}
			} else {
				if o.Total != nil {
					t.Fatal("partial returned misleading total")
				}
				for _, r := range o.Rows {
					if r.Share != nil {
						t.Fatal("partial returned misleading share")
					}
				}
			}
		})
	}
	rows := overviewTestRows()
	for _, r := range rows {
		r["account_count"] = 0
	}
	o := overviewParseAccounts(overviewEmpty("2026-10-26", "Global"), rows)
	if o.Total == nil || *o.Total != 0 || o.Rows[0].Share != nil {
		t.Fatal("zero denominator mishandled", o)
	}
}

func TestOverviewSnapshotLookbackAndIsolation(t *testing.T) {
	original := overviewQueryReport
	t.Cleanup(func() { overviewQueryReport = original })
	for _, fail := range []bool{false, true} {
		calls := 0
		overviewQueryReport = func(ctx context.Context, r *http.Request, source string) (map[string]any, error) {
			calls++
			q := r.URL.Query()
			if source != overviewAccountSource || q.Get("client_tier") != "" || q.Get("submitter") != "" || q.Get("program_type") != "" || q.Get("client_ids") != "" {
				t.Fatal("leaked filters", q)
			}
			if q.Get("region") != "APAC" || q.Get("start_date") != q.Get("end_date") {
				t.Fatal("snapshot filters", q)
			}
			if r.Header.Get("Authorization") != "Byte-Cloud-JWT fixture" {
				t.Fatal("caller auth lost")
			}
			if fail {
				return map[string]any{"status": "failed"}, nil
			}
			if calls == 1 {
				return map[string]any{"status": "ok", "business_rows": []map[string]any{}}, nil
			}
			if q.Get("end_date") != "2026-10-25" {
				t.Fatal(q)
			}
			return map[string]any{"status": "ok", "business_rows": overviewTestRows(), "requestId": "fixture-request"}, nil
		}
		r := httptest.NewRequest("GET", "/api/overview/accounts?client_tier=ET&submitter=someone&client_ids=1&program_type=ET", nil)
		r.Header.Set("Authorization", "Byte-Cloud-JWT fixture")
		o := overviewLoadAccounts(context.Background(), r, "2026-10-26", "APAC")
		if fail {
			if calls != 1 || o.AsOf != "" || o.Status != "unavailable" {
				t.Fatal(o)
			}
		} else if calls != 2 || o.AsOf != "2026-10-25" || o.Status != "available" {
			t.Fatal(o)
		}
	}
}

func TestOverviewNoDataAndTruncation(t *testing.T) {
	original := overviewQueryReport
	t.Cleanup(func() { overviewQueryReport = original })
	calls := 0
	overviewQueryReport = func(context.Context, *http.Request, string) (map[string]any, error) {
		calls++
		return map[string]any{"status": "ok", "business_rows": []map[string]any{}}, nil
	}
	r := httptest.NewRequest("GET", "/", nil)
	o := overviewLoadAccounts(context.Background(), r, "2026-10-26", "Global")
	if calls != 14 || o.Status != "no_data" || o.Total != nil {
		t.Fatal(o, calls)
	}
	overviewQueryReport = func(context.Context, *http.Request, string) (map[string]any, error) {
		return map[string]any{"status": "ok", "possibly_truncated": true, "business_rows": overviewTestRows()}, nil
	}
	o = overviewLoadAccounts(context.Background(), r, "2026-10-26", "Global")
	if o.Status != "unavailable" || o.Total != nil {
		t.Fatal("truncation counted", o)
	}
}

func TestOverviewRejectsInvalidInputWithoutQuery(t *testing.T) {
	original := overviewQueryReport
	t.Cleanup(func() { overviewQueryReport = original })
	overviewQueryReport = func(context.Context, *http.Request, string) (map[string]any, error) {
		t.Fatal("invalid input queried")
		return nil, nil
	}
	for _, query := range []string{"end_date=bad", "end_date=2099-01-01", "end_date=2026-02-30", "region=JP"} {
		w := httptest.NewRecorder()
		overviewAccountsHandler(w, httptest.NewRequest("GET", "/api/overview/accounts?"+query, nil))
		if w.Code != 400 {
			t.Fatal(query, w.Code)
		}
	}
}

func TestOverviewSavedRequestPreservesDefinitionsAndFilters(t *testing.T) {
	s := overviewAccountSourceConfig()
	where := []any{
		map[string]any{"id": s.Fields["region"].DimMetID, "op": "in", "val": []any{"CNOB"}},
		map[string]any{"id": "fixed_business_predicate", "op": "in", "val": []any{"keep"}},
	}
	raw := map[string]any{"query": map[string]any{"whereList": where, "measures": []any{map[string]any{"name": "TAP Accounts", "expression": "COUNT(DISTINCT account_id)"}}, "schema": map[string]any{"dimensions": []any{map[string]any{"id": s.Fields["p_date"].DimMetID}, map[string]any{"id": s.Fields["client_tier"].DimMetID}, map[string]any{"id": s.Fields["region"].DimMetID}}}}}
	for _, region := range []string{"", "APAC"} {
		f := filterRequest{StartDate: "2026-10-26", EndDate: "2026-10-26", Region: region}
		chart, _ := chartWithBusinessFilters(map[string]any{}, s, f)
		chart, err := overviewAccountChart(raw, chart, s, f)
		if err != nil {
			t.Fatal(err)
		}
		body, err := savedReportVQSRequest(overviewAccountBase(raw, f), chart, s, f, nil, "")
		if err != nil {
			t.Fatal(err)
		}
		q := body["query"].(map[string]any)
		text := fmt.Sprint(q)
		if !strings.Contains(text, "COUNT(DISTINCT account_id)") || !strings.Contains(text, "fixed_business_predicate") {
			t.Fatal("source definition lost", q)
		}
		for _, key := range overviewTierKeys {
			if !strings.Contains(text, key) {
				t.Fatal("tier distribution clipped", q)
			}
		}
		if region == "" && strings.Contains(text, "CNOB") {
			t.Fatal("Global retained saved region", q)
		}
		if region != "" && !strings.Contains(text, "APAC") {
			t.Fatal("region missing", q)
		}
	}
	if _, err := overviewAccountChart(map[string]any{}, map[string]any{}, s, filterRequest{}); err == nil {
		t.Fatal("unverified field contract accepted")
	}
}

func TestOverviewAccountMappingPreservesAllTierRows(t *testing.T) {
	raw := []map[string]any{}
	for i, k := range overviewTierKeys {
		raw = append(raw, map[string]any{"tier_uid": k, "count_uid": float64(i + 1)})
	}
	mapped, err := overviewCanonicalAccounts(raw, map[string]string{"tier_uid": "10000012645665 tier_v3_name", "count_uid": "TAP Accounts"})
	if err != nil {
		t.Fatal(err)
	}
	o := overviewParseAccounts(overviewEmpty("2026-10-26", "Global"), mapped)
	if o.Status != "available" || *o.Total != 10 {
		t.Fatal("Saved Report columns failed to map", o)
	}
}

func TestOverviewTrialExposesNoMutationRoutes(t *testing.T) {
	originalID := appInstanceID
	appInstanceID = "fixture-instance"
	t.Cleanup(func() { appInstanceID = originalID })
	mux := overviewTrialMux()
	for _, path := range []string{"/api/monitoring/risk-scans", "/api/workbench/cases", "/api/integrations/feishu/card-callback"} {
		w := httptest.NewRecorder()
		mux.ServeHTTP(w, httptest.NewRequest("POST", path, nil))
		if w.Code != 404 {
			t.Fatalf("trial exposed mutation route %s: %d", path, w.Code)
		}
	}
	w := httptest.NewRecorder()
	mux.ServeHTTP(w, httptest.NewRequest("GET", "/api/overview/accounts", nil))
	if w.Code != 401 {
		t.Fatal("trial must require platform authentication", w.Code)
	}
}
