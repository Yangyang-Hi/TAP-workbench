// handler_governance.go — governance 资源的业务逻辑。
// 路由契约在 handler_governance.gen.go（由 IDL 生成，勿改）；此文件由你填实现。
//
// stub 目前直接返回 IDL 里的 response，让契约先跑通；
// Agent B 请用真实 store 读写替换每个 handler 内部。
package main

import "net/http"

// governanceIdentityDiagnosticsList 处理 GET /api/governance/identity-diagnostics：获取工作台登录身份、风神短期凭证状态、网络状态与逐 Report 查询状态
func governanceIdentityDiagnosticsList(w http.ResponseWriter, r *http.Request) {
	// TODO(Agent B): 替换为真实业务逻辑（读写 store、校验参数等）。
	writeJSON(w, http.StatusOK, map[string]any{
		"data": map[string]any{
			"workbench_identity": map[string]any{
				"status":    "available",
				"principal": "heyangyang.31",
			},
			"aeolus_identity": map[string]any{
				"status":    "available",
				"principal": "heyangyang.31",
			},
			"aeolus_network": map[string]any{
				"status":        "available",
				"endpoint":      "https://aeolus-sg.bytedance.net",
				"http_category": "success",
				"duration_ms":   0,
			},
			"reports": []any{},
		},
	})
}

// governanceRegistryList 处理 GET /api/governance/registry：获取数据源合同、Ready/Conditional/Blocked 状态、快照与质量诊断
func governanceRegistryList(w http.ResponseWriter, r *http.Request) {
	// TODO(Agent B): 替换为真实业务逻辑（读写 store、校验参数等）。
	writeJSON(w, http.StatusOK, map[string]any{
		"data": map[string]any{
			"sources": []any{
				map[string]any{
					"source_key":      "SUBMISSION_VOLUME_V2",
					"status":          "ready",
					"latest_sync":     map[string]any{},
					"latest_snapshot": map[string]any{},
					"diagnostics":     map[string]any{},
				},
			},
			"cards":   []any{},
			"regions": []any{},
			"tiers":   []any{},
		},
	})
}

// governanceSyncStatusList 处理 GET /api/governance/sync-status：获取最近同步运行状态
func governanceSyncStatusList(w http.ResponseWriter, r *http.Request) {
	// TODO(Agent B): 替换为真实业务逻辑（读写 store、校验参数等）。
	writeJSON(w, http.StatusOK, map[string]any{
		"data": map[string]any{
			"runs": []any{},
		},
	})
}

// governanceTabsByTabGet 处理 GET /api/governance/tabs/{tab}：获取五个治理 Tab 的标准卡片和图表数据
func governanceTabsByTabGet(w http.ResponseWriter, r *http.Request) {
	// TODO(Agent B): 替换为真实业务逻辑（读写 store、校验参数等）。
	writeJSON(w, http.StatusOK, map[string]any{
		"data": map[string]any{
			"tab":    "overview",
			"status": "unavailable",
			"page_contract": map[string]any{
				"controls":    []any{},
				"fixed_scope": map[string]any{},
			},
			"cards":   []any{},
			"filters": map[string]any{},
			"quota": map[string]any{
				"as_of":   "",
				"scope":   "global",
				"plans":   []any{},
				"regions": []any{},
				"tht":     map[string]any{},
			},
		},
	})
}
