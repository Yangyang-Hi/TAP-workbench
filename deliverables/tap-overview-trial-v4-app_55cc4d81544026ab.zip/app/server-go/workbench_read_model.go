package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"
)

const wbReadContractVersion = "2026-10-26"

type wbBatchContract struct {
	BatchID      string            `json:"batch_id"`
	WeekName     string            `json:"week_name"`
	GeneratedAt  string            `json:"generated_at"`
	MetricStart  string            `json:"metric_start_date"`
	MetricEnd    string            `json:"metric_end_date"`
	Timezone     string            `json:"timezone"`
	RuleVersions map[string]string `json:"rule_versions"`
	Programs     []string          `json:"programs"`
	Status       string            `json:"status"`
	Completeness string            `json:"completeness"`
}

type wbComparison struct {
	PreCCRFact             metricFact `json:"pre_ccr_fact"`
	PostCCRFact            metricFact `json:"post_ccr_fact"`
	IncreaseFact           metricFact `json:"increase_fact"`
	PreCCR                 *float64   `json:"pre_ccr"`
	PostCCR                *float64   `json:"post_ccr"`
	CCRDelta               *float64   `json:"ccr_delta,omitempty"`
	PreNFS                 *float64   `json:"pre_nfs"`
	PostNFS                *float64   `json:"post_nfs"`
	NFSDelta               *float64   `json:"nfs_delta,omitempty"`
	NFSGrowthPct           *float64   `json:"nfs_growth_pct,omitempty"`
	PreRevenue             *float64   `json:"pre_revenue"`
	PostRevenue            *float64   `json:"post_revenue"`
	RevenueDelta           *float64   `json:"revenue_delta,omitempty"`
	RevenueGrowthPct       *float64   `json:"revenue_growth_pct,omitempty"`
	CCRGrowthPct           *float64   `json:"ccr_growth_pct"`
	ProtectionCCRGrowthPct *float64   `json:"protection_ccr_growth_pct,omitempty"` // legacy alias; never populated from wow
	WoWGrowthPct           *float64   `json:"wow_ccr_growth_pct,omitempty"`        // legacy natural-week field; never used as CCR Increase
	WoWStatus              string     `json:"wow_status"`
	WoWMissingReason       string     `json:"wow_missing_reason"`

	QoQGrowthPct        *float64       `json:"qoq_ccr_growth_pct"`
	QoQStatus           string         `json:"qoq_status"`
	QoQMissingReason    string         `json:"qoq_missing_reason"`
	Rolling90DGrowthPct *float64       `json:"rolling_90d_ccr_growth_pct,omitempty"`
	Status              string         `json:"status"`
	MissingReason       string         `json:"missing_reason"`
	Kind                string         `json:"kind"`
	PreStart            string         `json:"pre_start_date"`
	PreEndExclusive     string         `json:"pre_end_exclusive"`
	PostStart           string         `json:"post_start_date"`
	PostEndExclusive    string         `json:"post_end_exclusive"`
	Timezone            string         `json:"timezone"`
	Source              map[string]any `json:"source,omitempty"`
}

type wbNotificationView struct {
	Status  string     `json:"status"`
	History []cwNotice `json:"history"`
}

type wbReadRow struct {
	AlertID              *string                `json:"alert_id"`
	AccountID            string                 `json:"account_id"`
	AccountName          string                 `json:"account_name"`
	AdvertiserID         string                 `json:"advertiser_id"`
	Program              string                 `json:"program"`
	Tier                 string                 `json:"tier"`
	Region               string                 `json:"region"`
	OriginalSubmitter    string                 `json:"original_submitter"`
	ActualRecipient      *string                `json:"actual_recipient"`
	CCR                  *float64               `json:"p0_ccr"`
	NFS                  *float64               `json:"p0_nfs"`
	Revenue              *float64               `json:"revenue"`
	CCRFact              metricFact             `json:"p0_ccr_fact"`
	NFSFact              metricFact             `json:"p0_nfs_fact"`
	RevenueFact          metricFact             `json:"revenue_fact"`
	MetricStatus         string                 `json:"metric_status"`
	CCRStatus            string                 `json:"ccr_status"`
	NFSStatus            string                 `json:"nfs_status"`
	RevenueStatus        string                 `json:"revenue_status"`
	Comparison           wbComparison           `json:"comparison"`
	AdvertiserValidCount int                    `json:"advertiser_valid_count"`
	AdvertiserTop10      []wbAdvertiserEvidence `json:"advertiser_top10"`
	PairAbsoluteLevel    string                 `json:"pair_absolute_level,omitempty"`
	PairAbsoluteReasons  []string               `json:"pair_absolute_reasons,omitempty"`
	RiskLevel            string                 `json:"risk_level"`
	RiskReasons          []string               `json:"risk_reasons"`
	EventStage           string                 `json:"event_stage"`
	Notification         wbNotificationView     `json:"notification"`
	ScanID               string                 `json:"scan_id"`
	RowID                string                 `json:"row_id"`
}

type wbCardValue struct {
	Value       *int   `json:"value"`
	Status      string `json:"status"`
	Description string `json:"description"`
}

func wbDeltaAndGrowth(pre, post *float64) (*float64, *float64) {
	if pre == nil || post == nil {
		return nil, nil
	}
	delta := *post - *pre
	if *pre == 0 {
		return &delta, nil
	}
	growth := delta / *pre * 100
	return &delta, &growth
}

func wbFinalizeComparison(out *wbComparison) {
	out.CCRDelta, out.CCRGrowthPct = wbDeltaAndGrowth(out.PreCCR, out.PostCCR)
	out.ProtectionCCRGrowthPct = out.CCRGrowthPct // deprecated anchor-relative alias for old readers
	out.NFSDelta, out.NFSGrowthPct = wbDeltaAndGrowth(out.PreNFS, out.PostNFS)
	out.RevenueDelta, out.RevenueGrowthPct = wbDeltaAndGrowth(out.PreRevenue, out.PostRevenue)
	wbFinalizeComparisonFacts(out)
}

func wbFinalizeComparisonFacts(out *wbComparison) {
	if out.PreCCRFact.Status == "" {
		out.PreCCRFact = legacyMetricFact(out.PreCCR, out.Status, out.MissingReason)
	}
	if out.PostCCRFact.Status == "" {
		out.PostCCRFact = legacyMetricFact(out.PostCCR, out.Status, out.MissingReason)
	}
	if out.PreCCRFact.Status == "not_queried" || out.PostCCRFact.Status == "not_queried" {
		out.IncreaseFact = metricFact{Status: "not_queried", Reason: "Pre/Post 未查询"}
		return
	}
	if out.PreCCRFact.Status == metricQuerying || out.PostCCRFact.Status == metricQuerying {
		out.IncreaseFact = queryingMetricFact("Pre/Post 查询未结束")
		return
	}
	if out.PreCCRFact.Status == metricMissingAnchor || out.PostCCRFact.Status == metricMissingAnchor {
		out.IncreaseFact = metricFact{Status: metricMissingAnchor, Reason: "缺少唯一有效 create_time 锚点"}
		return
	}
	if out.PreCCRFact.Status == metricAmbiguousAnchor || out.PostCCRFact.Status == metricAmbiguousAnchor {
		out.IncreaseFact = metricFact{Status: metricAmbiguousAnchor, Reason: "存在多个有效 create_time 锚点"}
		return
	}
	if out.PreCCRFact.Status == metricFailed || out.PostCCRFact.Status == metricFailed || out.PreCCRFact.Status == metricNotConfigured || out.PostCCRFact.Status == metricNotConfigured {
		reason := out.PreCCRFact.Reason
		if reason == "" {
			reason = out.PostCCRFact.Reason
		}
		out.IncreaseFact = failedMetricFact(reason)
		return
	}
	if out.PreCCRFact.Status == metricSourceNull || out.PostCCRFact.Status == metricSourceNull {
		out.IncreaseFact = metricFact{Status: metricSourceNull, Reason: "源指标缺失"}
		return
	}
	if out.PreCCR != nil && *out.PreCCR == 0 {
		out.IncreaseFact = metricFact{Status: metricNotApplicable, Reason: "基数为零、无法计算增幅"}
		return
	}
	out.IncreaseFact = successfulMetricFact(out.CCRGrowthPct)
}

func wbSuccessfulComparison(program, anchor string, pre, post *float64, now time.Time) wbComparison {
	out := wbComparisonResult(program, anchor, pre, post, now)
	out.PreCCRFact = successfulMetricFact(pre)
	out.PostCCRFact = successfulMetricFact(post)
	if pre == nil || post == nil {
		out.Status, out.MissingReason = metricSourceNull, "源指标缺失"
	} else if *pre == 0 {
		out.Status, out.MissingReason = metricNotApplicable, "基数为零、无法计算增幅"
	} else {
		out.Status, out.MissingReason = metricAvailable, ""
	}
	wbFinalizeComparisonFacts(&out)
	return out
}

func wbComparisonResult(program, anchor string, pre, post *float64, now time.Time) wbComparison {
	out := wbComparison{PreCCR: pre, PostCCR: post, Timezone: "Asia/Shanghai"}
	if strings.EqualFold(program, "ST") {
		out.Kind = "qoq"
		out.Status = "unavailable"
		out.MissingReason = "st_q3_end_date_business_definition_unconfirmed"
		out.QoQStatus = "unavailable"
		out.QoQMissingReason = "st_q3_end_date_business_definition_unconfirmed"
		return out
	} else {
		out.WoWStatus = "unavailable"
		out.WoWMissingReason = "weekly_baseline_not_queried"
	}
	if out.Kind == "" {
		out.Kind = "relative_7d"
	}
	days := 7
	if strings.EqualFold(program, "ST") {
		days = 90
	}
	start, err := time.ParseInLocation("2006-01-02", dateOnly(anchor), cwLocation())
	if err != nil {
		out.Status, out.MissingReason = "unavailable", "missing_or_invalid_formal_anchor"
		if strings.EqualFold(program, "ET") {
			out.MissingReason = "missing_or_invalid_create_time"
		} else if strings.EqualFold(program, "THT") {
			out.MissingReason = "missing_or_invalid_protection_starttime"
		}
		return out
	}
	out.PreStart = start.AddDate(0, 0, -days).Format("2006-01-02")
	out.PreEndExclusive = start.Format("2006-01-02")
	out.PostStart = start.Format("2006-01-02")
	out.PostEndExclusive = start.AddDate(0, 0, days).Format("2006-01-02")
	if now.In(cwLocation()).Before(start.AddDate(0, 0, days)) {
		out.Status, out.MissingReason = "window_incomplete", "post_observation_window_not_complete"
		return out
	}
	if pre == nil || post == nil {
		out.Status = "unavailable"
		if pre == nil && post == nil {
			out.MissingReason = "reaggregated_ccr_numerator_denominator_not_persisted"
		} else if pre == nil {
			out.MissingReason = "pre_ccr_missing"
		} else {
			out.MissingReason = "post_ccr_missing_or_waiting_data_update"
		}
		return out
	}
	if *pre < 0 || *post < 0 || math.IsNaN(*pre) || math.IsNaN(*post) || math.IsInf(*pre, 0) || math.IsInf(*post, 0) {
		out.Status, out.MissingReason = "unavailable", "invalid_ccr_value"
		return out
	}
	wbFinalizeComparison(&out)
	if *pre == 0 {
		out.Status, out.MissingReason = "baseline_zero", "pre_ccr_is_zero"
		return out
	}
	out.Status = "available"
	return out
}

func wbWeekName(start string) string {
	t, err := time.Parse("2006-01-02", start)
	if err != nil {
		return start
	}
	year, week := t.ISOWeek()
	return fmt.Sprintf("%d-W%02d", year, week)
}

type wbSemanticsFact struct {
	Label  string
	Status string
	AsOf   string
}

func wbSemanticsKey(accountID, advertiserID string) string {
	return strings.TrimSpace(accountID) + "\x1f" + strings.TrimSpace(advertiserID)
}

func wbLatestSemanticsEvidence(jobsByBatch map[string][]wbJob) map[string]wbSemanticsFact {
	latest := map[string]wbSemanticsFact{}
	for _, jobs := range jobsByBatch {
		for _, job := range jobs {
			asOf := job.AsOf
			if asOf == "" {
				asOf = job.StartedAt
			}
			for _, row := range job.Rows {
				for _, evidence := range append(append([]wbAdvertiserEvidence(nil), row.Advertisers...), row.AdvertiserTop10...) {
					status := evidence.SemanticsStatus
					if status == "" && evidence.SemanticsLabel != "" {
						status = "available"
					}
					if status == "" {
						continue
					}
					key := wbSemanticsKey(evidence.AccountID, evidence.AdvertiserID)
					if evidence.AdvertiserID == "" || key == "\x1f" {
						continue
					}
					if current, ok := latest[key]; !ok || asOf > current.AsOf {
						latest[key] = wbSemanticsFact{Label: evidence.SemanticsLabel, Status: status, AsOf: asOf}
					}
				}
			}
		}
	}
	return latest
}

func wbBackfillSemantics(row wbRow, latest map[string]wbSemanticsFact) wbRow {
	backfill := func(items []wbAdvertiserEvidence) []wbAdvertiserEvidence {
		out := append([]wbAdvertiserEvidence(nil), items...)
		for i := range out {
			if out[i].SemanticsStatus != "" {
				continue
			}
			if out[i].SemanticsLabel != "" {
				out[i].SemanticsStatus = "available"
				continue
			}
			accountID := out[i].AccountID
			if accountID == "" {
				accountID = row.Member.AccountID
			}
			if fact, ok := latest[wbSemanticsKey(accountID, out[i].AdvertiserID)]; ok {
				out[i].SemanticsLabel, out[i].SemanticsStatus = fact.Label, "backfilled_"+fact.Status
			} else {
				out[i].SemanticsStatus = "legacy_not_captured"
			}
		}
		return out
	}
	row.Advertisers = backfill(row.Advertisers)
	row.AdvertiserTop10 = backfill(row.AdvertiserTop10)
	return row
}

func wbJobDistinctCustomerCount(job wbJob) int {
	seen := map[string]bool{}
	for _, row := range job.Rows {
		id := strings.TrimSpace(row.Member.AccountID)
		if strings.EqualFold(job.Request.Program, "THT") {
			id = strings.TrimSpace(row.Member.AdvertiserID)
		}
		if id != "" {
			seen[id] = true
		}
	}
	return len(seen)
}

func wbPersistedBatches() ([]wbBatchContract, map[string][]wbJob, error) {
	wbMu.Lock()
	state, err := wbReadDisk()
	wbMu.Unlock()
	if err != nil {
		return nil, nil, err
	}
	jobsByBatch := map[string][]wbJob{}
	for _, job := range state.Jobs {
		if job.BatchID == "" || !cwIsCompleteNaturalWeek(job.Request.Start, job.Request.End) {
			continue
		}
		// THT scans checkpoint metric rows before the slower comparison enrichment.
		// Keep an empty running job hidden, but surface a checkpointed running job so
		// Risk Monitoring does not lose the whole program while enrichment continues.
		if job.Status == "running" && len(job.Rows) == 0 {
			continue
		}
		jobsByBatch[job.BatchID] = append(jobsByBatch[job.BatchID], job)
	}
	for batchID, jobs := range jobsByBatch {
		programs := map[string]bool{}
		for _, job := range jobs {
			programs[strings.ToUpper(job.Request.Program)] = true
		}
		selected := make([]wbJob, 0, len(programs))
		for program := range programs {
			merged, ok := wbMergeProgramJobs(program, jobs)
			if ok {
				selected = append(selected, merged)
			}
		}
		jobsByBatch[batchID] = selected
	}
	batches := make([]wbBatchContract, 0, len(jobsByBatch))
	for id, jobs := range jobsByBatch {
		b := wbBatchContract{BatchID: id, WeekName: wbWeekName(jobs[0].Request.Start), MetricStart: jobs[0].Request.Start, MetricEnd: jobs[0].Request.End, Timezone: "Asia/Shanghai", RuleVersions: map[string]string{}, Status: "available", Completeness: "complete"}
		programs := map[string]bool{}
		for _, job := range jobs {
			programs[job.Request.Program] = true
			b.RuleVersions[job.Request.Program] = job.RuleVersion
			generated := job.AsOf
			if generated == "" {
				generated = job.StartedAt
			}
			if b.GeneratedAt == "" || generated < b.GeneratedAt {
				b.GeneratedAt = generated
			}
			if job.Status == "failed" || job.Status == "blocked" {
				b.Status = "unavailable"
			}
			if job.Status == "partial" || job.Status == "running" || !job.Complete {
				b.Completeness = "partial"
				if b.Status == "available" {
					b.Status = "partial"
				}
			}
		}
		for program := range programs {
			b.Programs = append(b.Programs, program)
		}
		sort.Strings(b.Programs)
		batches = append(batches, b)
	}
	sort.Slice(batches, func(i, j int) bool { return batches[i].MetricStart > batches[j].MetricStart })
	return batches, jobsByBatch, nil
}

func wbBatchesHandler(w http.ResponseWriter, r *http.Request) {
	batches, _, err := wbPersistedBatches()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	status := "available"
	if len(batches) == 0 {
		status = "empty"
	}
	writeJSON(w, http.StatusOK, map[string]any{"data": map[string]any{"status": status, "batches": batches, "timezone": "Asia/Shanghai", "source": "persisted_scans", "side_effects": false}})
}

func wbReadAllCases(db *sql.DB) (map[string]cwCase, error) {
	rows, err := db.Query("SELECT body FROM tap_cases")
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := map[string]cwCase{}
	for rows.Next() {
		var raw string
		var item cwCase
		if err = rows.Scan(&raw); err != nil {
			return nil, err
		}
		if err = json.Unmarshal([]byte(raw), &item); err != nil {
			return nil, err
		}
		out[item.ID] = item
	}
	return out, rows.Err()
}

func wbNoticesByCase(db *sql.DB, cases map[string]cwCase) (map[string][]cwNotice, error) {
	out := map[string][]cwNotice{}
	for id := range cases {
		items, err := cwNotices(db, id)
		if err != nil {
			return nil, err
		}
		out[id] = items
	}
	return out, nil
}

func wbSuccessfulNotice(items []cwNotice) bool {
	for _, item := range items {
		if item.Kind == "send" && item.Status == "sent" && strings.TrimSpace(item.MessageID) != "" {
			return true
		}
	}
	return false
}

func wbNotificationStatus(items []cwNotice) string {
	if wbSuccessfulNotice(items) {
		return "sent"
	}
	for _, item := range items {
		if item.Kind != "send" {
			continue
		}
		switch item.Status {
		case "sent":
			return "unknown"
		case "failed":
			return "failed"
		case "pending", "sending":
			return "queued"
		case "blocked":
			return "blocked"
		}
	}
	return "not_sent"
}

func wbEventStage(item *cwCase, notices []cwNotice) string {
	if item != nil && item.Status == "closed" {
		return "closed"
	}
	if wbSuccessfulNotice(notices) {
		return "pending_submitter"
	}
	return "pending_operator"
}

func wbCustomerKey(row wbRow) string {
	id := row.Member.AccountID
	if strings.EqualFold(row.Program, "THT") {
		id = row.Member.AdvertiserID
		if id == "" {
			id = row.Member.AccountID
		}
	}
	if id == "" {
		id = row.ID
	}
	return strings.ToUpper(row.Program) + "|" + id
}

func wbReadIdentity(db *sql.DB, username string) ([]string, string) {
	username = cwNormalizeIdentity(username)
	if username == "" {
		return nil, "authenticated_identity_missing"
	}
	rows, err := db.Query("SELECT " + cwMappingColumns + " FROM tap_identity_mappings WHERE enabled=1 AND manual_disabled=0 AND match_status='已确认'")
	if err != nil {
		return nil, "verified_mapping_unavailable"
	}
	defer rows.Close()
	matches := []cwIdentityMapping{}
	for rows.Next() {
		m, scanErr := cwScanMapping(rows)
		if scanErr != nil {
			return nil, "verified_mapping_unavailable"
		}
		local := ""
		if email, ok := cwExactEmail(m.Email); ok {
			local = strings.SplitN(email, "@", 2)[0]
		}
		if cwNormalizeIdentity(local) == username || cwNormalizeIdentity(m.BusinessName) == username || cwNormalizeIdentity(m.AeolusName) == username {
			matches = append(matches, m)
		}
	}
	if len(matches) != 1 {
		return nil, "current_identity_does_not_uniquely_match_verified_mapping"
	}
	return uniqueNonEmpty([]string{matches[0].BusinessName, matches[0].AeolusName, matches[0].Email, strings.SplitN(matches[0].Email, "@", 2)[0]}), ""
}

func wbBoolQuery(raw string) bool { v, _ := strconv.ParseBool(raw); return v }

func wbRowMatches(row wbRow, item *cwCase, q map[string]string, aliases []string, notices []cwNotice) bool {
	if v := strings.ToUpper(q["program"]); v != "" && v != "ALL" && row.Program != v {
		return false
	}
	if v := q["tier"]; v != "" && v != "all" && !strings.EqualFold(row.Member.Tier, v) {
		return false
	}
	if v := q["region"]; v != "" && v != "all" && row.Member.Region != v {
		return false
	}
	if v := q["submitter"]; v != "" && !exactMember(append(row.Member.Submitters, row.Member.Submitter), v) {
		return false
	}
	if v := q["account_id"]; v != "" && !exactMember(append(row.Member.LinkedAccountIDs, row.Member.AccountID), v) {
		return false
	}
	if v := q["advertiser_id"]; v != "" && !exactMember(append(row.Member.LinkedAdvertiserIDs, row.Member.AdvertiserID), v) {
		return false
	}
	if v := q["stage"]; v != "" && v != "all" && wbEventStage(item, notices) != v {
		return false
	}
	if q["only_mine"] == "true" {
		mine := false
		for _, alias := range aliases {
			if exactMember(append(row.Member.Submitters, row.Member.Submitter), alias) || item != nil && item.Owner == alias {
				mine = true
			}
			for _, notice := range notices {
				if notice.Kind == "send" && strings.EqualFold(strings.TrimSpace(notice.TargetEmail), strings.TrimSpace(alias)) {
					mine = true
				}
			}
		}
		if !mine {
			return false
		}
	}
	if v := strings.ToLower(q["search"]); v != "" {
		hay := strings.ToLower(strings.Join(append(append([]string{row.Member.AccountID, row.Member.Name, row.Member.AdvertiserID, row.Member.AdvertiserName}, row.Member.LinkedAccountIDs...), row.Member.LinkedAdvertiserIDs...), "\n"))
		if !strings.Contains(hay, v) {
			return false
		}
	}
	return true
}

func wbRiskLevel(level string) string {
	if level == "critical" {
		return "extreme"
	}
	return level
}

func wbNormalizeLegacyComparison(program string, comparison wbComparison) wbComparison {
	// Legacy natural-week values are retained only for truthful compatibility.
	// They are never promoted to anchor-relative CCR Increase.
	if comparison.CCRGrowthPct == nil && comparison.ProtectionCCRGrowthPct != nil && comparison.WoWGrowthPct == nil {
		// protection_ccr_growth_pct was the prior explicit anchor-relative field.
		comparison.CCRGrowthPct = comparison.ProtectionCCRGrowthPct
	}
	if comparison.WoWGrowthPct != nil {
		comparison.WoWStatus = "legacy_invalid"
		comparison.WoWMissingReason = "旧批次自然周口径，不可作为CCR Increase"
	}
	if strings.EqualFold(program, "ST") && comparison.CCRGrowthPct == nil {
		comparison.Status = metricNotConfigured
		comparison.MissingReason = "st_account_anchor_not_configured"
	}
	wbFinalizeComparisonFacts(&comparison)
	return comparison
}

func wbNormalizeLegacyReasons(items []reportedReason) []reportedReason {
	out := append([]reportedReason(nil), items...)
	for i := range out {
		if out[i].SourceStatus == "" {
			out[i].SourceStatus = "legacy_unverified"
			out[i].SourceReason = "legacy snapshot source is outside the 2026-10-26 authoritative source list"
			out[i].RankingAvailable = false
			out[i].Rank = nil
			out[i].RankingUnavailable = out[i].SourceReason
		}
	}
	return out
}

func wbRowRevenueState(row wbRow) (string, string) {
	if source, ok := row.Source.(map[string]any); ok {
		if revenue, ok := source["revenue"].(map[string]any); ok {
			status, reason := asString(revenue["status"]), asString(revenue["error"])
			if status == "" {
				// Account scans before the status-persistence fix still prove that the
				// governed Revenue report completed: the nested source is only written
				// after that probe succeeds. A missing fact row is therefore source NULL.
				status = "no_data"
			}
			return status, reason
		}
		if strings.EqualFold(asString(source["source"]), "et_current_ccr_nfs") {
			// Legacy current-account scans issued CCR/NFS and Revenue together but did
			// not persist RevenueStatus when the Revenue source returned no fact row.
			return "no_data", "权威 Revenue 查询成功但该 Account 无事实行"
		}
	}
	if row.Revenue != nil {
		return metricAvailable, ""
	}
	return "unknown", "旧批次未记录 Revenue 状态"
}

func wbTHTAdvertiserGrainCompatible(row wbRow) bool {
	if !strings.EqualFold(row.Program, "THT") || strings.TrimSpace(row.Member.AdvertiserID) == "" {
		return !strings.EqualFold(row.Program, "THT")
	}
	for _, source := range []any{row.Source, row.Comparison.Source} {
		if values, ok := source.(map[string]any); ok {
			grain := strings.ToLower(asString(values["grain"]))
			if strings.Contains(grain, "advertiser") {
				return true
			}
			if strings.Contains(grain, "account") {
				return false
			}
		}
	}
	return false
}

func wbHideComparisonRevenue(comparison *wbComparison) {
	// Historical values remain persisted for audit compatibility, but Pre/Post
	// Revenue is outside the approved comparison contract and must not be exposed.
	comparison.PreRevenue = nil
	comparison.PostRevenue = nil
	comparison.RevenueDelta = nil
	comparison.RevenueGrowthPct = nil
}

func wbToReadRow(job wbJob, row wbRow, item *cwCase, notices []cwNotice, now time.Time) wbReadRow {
	comparison := wbNormalizeLegacyComparison(row.Program, row.Comparison)
	wbHideComparisonRevenue(&comparison)
	if strings.EqualFold(row.Program, "THT") && !wbTHTAdvertiserGrainCompatible(row) {
		comparison = wbComparisonResult(row.Program, row.Member.Start, nil, nil, now)
		comparison.Status = "incompatible_legacy_grain"
		comparison.MissingReason = "旧记录粒度不兼容：THT 主指标不是 Advertiser Level"
		comparison.PreCCR, comparison.PostCCR, comparison.CCRGrowthPct = nil, nil, nil
		comparison.PreCCRFact = failedMetricFact(comparison.MissingReason)
		comparison.PostCCRFact = failedMetricFact(comparison.MissingReason)
		comparison.IncreaseFact = failedMetricFact(comparison.MissingReason)
	} else if comparison.Status == "" {
		comparison = wbComparisonResult(row.Program, row.Member.Start, nil, nil, now)
	}
	var alertID, recipient *string
	if item != nil {
		v := item.ID
		alertID = &v
	}
	for _, notice := range notices {
		if notice.Kind == "send" && notice.Status == "sent" && notice.Recipient != "" {
			v := notice.Recipient
			recipient = &v
			break
		}
	}
	pool := row.Advertisers
	if len(pool) == 0 {
		pool = row.AdvertiserTop10
	}
	top := []wbAdvertiserEvidence{}
	seenAdv := map[string]bool{}
	for _, adv := range pool {
		if adv.AdvertiserID != "" && adv.CCR != nil && *adv.CCR >= 0 && !seenAdv[adv.AdvertiserID] {
			top = append(top, adv)
			seenAdv[adv.AdvertiserID] = true
		}
	}
	validAdv := len(top)
	sort.SliceStable(top, func(i, j int) bool { return *top[i].CCR > *top[j].CCR })
	if len(top) > 10 {
		top = top[:10]
	}
	for i := range top {
		top[i].ReportedReasons = wbNormalizeLegacyReasons(top[i].ReportedReasons)
		top[i].PreRevenue, top[i].PostRevenue = nil, nil
		top[i].RevenueDelta, top[i].RevenueGrowthPct = nil, nil
		if top[i].ComparisonStatus == "" {
			if row.Program == "THT" {
				top[i].PreCCR, top[i].PostCCR, top[i].CCRGrowthPct = nil, nil, nil
				top[i].WoWGrowthPct = nil
				top[i].ComparisonStatus = "incompatible_legacy_grain"
				top[i].ComparisonReason = "旧记录粒度不兼容：缺少该 Advertiser 自身比较数据"
			} else if row.Program == "ST" {
				top[i].ComparisonStatus, top[i].ComparisonReason = "unavailable", "advertiser_relative_90d_ccr_not_persisted"
			} else {
				top[i].ComparisonStatus, top[i].ComparisonReason = "unavailable", "advertiser_reaggregated_ccr_not_persisted"
			}
		}
		if row.Program == "THT" && top[i].Revenue == nil && top[i].RevenueStatus == "" {
			// Legacy scans did not persist RevenueStatus. Do not turn that absence into a
			// fabricated upstream failure: current scans persist source_error/no_data.
			top[i].RevenueStatus = "unknown"
			top[i].RevenueError = "legacy_scan_revenue_status_not_persisted"
		}
		top[i].CCRFact = legacyMetricFact(top[i].CCR, top[i].MetricStatus, "advertiser metric query failed")
		top[i].NFSFact = legacyMetricFact(top[i].NFS, top[i].MetricStatus, "advertiser metric query failed")
		top[i].RevenueFact = legacyMetricFact(top[i].Revenue, top[i].RevenueStatus, top[i].RevenueError)
		top[i].PreCCRFact = legacyMetricFact(top[i].PreCCR, top[i].ComparisonStatus, top[i].ComparisonReason)
		top[i].PostCCRFact = legacyMetricFact(top[i].PostCCR, top[i].ComparisonStatus, top[i].ComparisonReason)
		advComparison := wbComparison{PreCCR: top[i].PreCCR, PostCCR: top[i].PostCCR, CCRGrowthPct: top[i].CCRGrowthPct, PreCCRFact: top[i].PreCCRFact, PostCCRFact: top[i].PostCCRFact}
		wbFinalizeComparisonFacts(&advComparison)
		top[i].IncreaseFact = advComparison.IncreaseFact
	}
	pairLevel, pairReasons := wbPairGovernanceLevel(row.Advertisers, job.Rule)
	accountID := row.Member.AccountID
	if row.Program == "THT" && accountID == "" && len(row.Advertisers) == 1 {
		accountID = row.Advertisers[0].AccountID
	}
	revenueStatus, revenueReason := wbRowRevenueState(row)
	ccrFact := legacyMetricFact(row.CCR, row.MetricStatus, row.Error)
	nfsFact := legacyMetricFact(row.NFS, row.MetricStatus, row.Error)
	revenueFact := legacyMetricFact(row.Revenue, revenueStatus, revenueReason)
	return wbReadRow{AlertID: alertID, AccountID: accountID, AccountName: row.Member.Name, AdvertiserID: row.Member.AdvertiserID, Program: row.Program, Tier: row.Member.Tier, Region: row.Member.Region, OriginalSubmitter: row.Member.Submitter, ActualRecipient: recipient, CCR: row.CCR, NFS: row.NFS, Revenue: row.Revenue, CCRFact: ccrFact, NFSFact: nfsFact, RevenueFact: revenueFact, MetricStatus: row.MetricStatus, CCRStatus: ccrFact.Status, NFSStatus: nfsFact.Status, RevenueStatus: revenueFact.Status, Comparison: comparison, AdvertiserValidCount: validAdv, AdvertiserTop10: top, PairAbsoluteLevel: pairLevel, PairAbsoluteReasons: pairReasons, RiskLevel: wbRiskLevel(row.Level), RiskReasons: append([]string(nil), row.Reasons...), EventStage: wbEventStage(item, notices), Notification: wbNotificationView{Status: wbNotificationStatus(notices), History: notices}, ScanID: job.ID, RowID: row.ID}
}

func wbSortRows(rows []wbReadRow, ranking string) {
	sort.SliceStable(rows, func(i, j int) bool {
		a, b := rows[i], rows[j]
		if ranking == "growth" {
			av, bv := wbComparisonGrowth(a.Program, a.Comparison), wbComparisonGrowth(b.Program, b.Comparison)
			if av == nil {
				return false
			}
			if bv == nil {
				return true
			}
			if *av != *bv {
				return *av > *bv
			}
		}
		if ranking == "combined" && a.RiskLevel != b.RiskLevel {
			return a.RiskLevel == "extreme"
		}
		if a.CCR == nil {
			return false
		}
		if b.CCR == nil {
			return true
		}
		if *a.CCR != *b.CCR {
			return *a.CCR > *b.CCR
		}
		return a.RowID < b.RowID
	})
}

func wbGrowthTop20(rows []wbReadRow) map[string][]wbReadRow {
	groups := map[string][]wbReadRow{}
	for _, row := range rows {
		g := wbComparisonGrowth(row.Program, row.Comparison)
		if !wbComparisonGrowthAvailable(row.Program, row.Comparison) || g == nil || *g <= 0 {
			continue
		}
		key := wbGrowthGroupKey(row.Program, row.Tier, row.Region)
		groups[key] = append(groups[key], row)
	}
	for key := range groups {
		wbSortRows(groups[key], "growth")
		unique := []wbReadRow{}
		seenEvents := map[string]bool{}
		for _, row := range groups[key] {
			eventKey := wbReadEventKey(row)
			if seenEvents[eventKey] {
				continue
			}
			seenEvents[eventKey] = true
			unique = append(unique, row)
			if len(unique) == 20 {
				break
			}
		}
		groups[key] = unique
	}
	return groups
}

func wbCard(value int, status, description string) wbCardValue {
	return wbCardValue{Value: &value, Status: status, Description: description}
}
func wbNullCard(status, description string) wbCardValue {
	return wbCardValue{Value: nil, Status: status, Description: description}
}

func wbReadModelHandler(w http.ResponseWriter, r *http.Request) {
	mode := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("time_mode")))
	if mode != "weekly" && mode != "custom" {
		writeJSON(w, 400, map[string]any{"error": "time_mode must be weekly or custom"})
		return
	}
	if mode == "custom" {
		start, end := r.URL.Query().Get("start_date"), r.URL.Query().Get("end_date")
		if !validDate(start) || !validDate(end) || start == "" || end == "" || end < start {
			writeJSON(w, 400, map[string]any{"error": "custom mode requires a valid start_date and end_date"})
			return
		}
		wbCustomReadModelHandler(w, r, start, end)
		return
	}
	batches, jobsByBatch, err := wbPersistedBatches()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	if len(batches) == 0 {
		writeJSON(w, 200, map[string]any{"data": map[string]any{"status": "empty", "reason": "no_persisted_weekly_batch", "time": map[string]any{"mode": "weekly", "batches": batches}, "cards": map[string]any{}, "rows": []any{}, "rankings": map[string]any{}, "pagination": map[string]int{"page": 1, "page_size": 0, "total": 0}, "contract_version": wbReadContractVersion, "side_effects": false}})
		return
	}
	q := map[string]string{}
	for _, key := range []string{"program", "tier", "region", "submitter", "account_id", "advertiser_id", "search", "stage"} {
		q[key] = strings.TrimSpace(r.URL.Query().Get(key))
	}
	q["only_mine"] = strconv.FormatBool(wbBoolQuery(r.URL.Query().Get("only_mine")))
	batchID := strings.TrimSpace(r.URL.Query().Get("batch_id"))
	if batchID == "" {
		programFilter := strings.ToUpper(strings.TrimSpace(q["program"]))
		if programFilter == "" {
			programFilter = strings.ToUpper(strings.TrimSpace(q["tier"]))
		}
		batchID = batches[0].BatchID
		if programFilter != "" && programFilter != "ALL" {
			for _, b := range batches {
				for _, program := range b.Programs {
					if strings.EqualFold(program, programFilter) {
						batchID = b.BatchID
						goto selectedBatch
					}
				}
			}
		}
	}
selectedBatch:
	jobs, ok := jobsByBatch[batchID]
	if !ok {
		writeJSON(w, 404, map[string]any{"error": "weekly batch not found"})
		return
	}
	db, err := cwDB()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	defer db.Close()
	cases, err := wbReadAllCases(db)
	if err != nil {
		cwWriteError(w, err)
		return
	}
	notices, err := wbNoticesByCase(db, cases)
	if err != nil {
		cwWriteError(w, err)
		return
	}
	aliases := []string{}
	if wbBoolQuery(r.URL.Query().Get("only_mine")) {
		var reason string
		aliases, reason = wbReadIdentity(db, requestUsername(r))
		if reason != "" {
			writeJSON(w, 422, map[string]any{"status": "needs_selection", "error": reason})
			return
		}
	}
	all := []wbReadRow{}
	semanticsEvidence := wbLatestSemanticsEvidence(jobsByBatch)
	dataView := r.URL.Query().Get("view") == "customers"
	queried, pending, handled := map[string]bool{}, map[string]bool{}, map[string]bool{}
	for _, job := range jobs {
		for _, persistedRow := range job.Rows {
			row := wbBackfillSemantics(persistedRow, semanticsEvidence)
			var item *cwCase
			for id, candidate := range cases {
				if candidate.ScanID == job.ID && candidate.Row.ID == row.ID {
					copy := candidate
					item = &copy
					_ = id
					break
				}
			}
			itemNotices := []cwNotice{}
			if item != nil {
				itemNotices = notices[item.ID]
			}
			matchQuery := map[string]string{}
			for k, v := range q {
				if k != "stage" {
					matchQuery[k] = v
				}
			}
			if !wbRowMatches(row, item, matchQuery, aliases, itemNotices) {
				continue
			}
			view := wbToReadRow(job, row, item, itemNotices, time.Now())
			key := wbCustomerKey(row)
			all = append(all, view)
			queried[key] = true
			if wbMatched(row) && view.EventStage == "pending_operator" {
				pending[key] = true
			}
			if wbSuccessfulNotice(itemNotices) {
				handled[key] = true
			}
		}
	}
	ranking := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("ranking")))
	if ranking == "" {
		ranking = "combined"
	}
	if ranking != "combined" && ranking != "absolute" && ranking != "growth" {
		writeJSON(w, 400, map[string]any{"error": "ranking must be combined, absolute or growth"})
		return
	}
	resolvedPolicy := wbDefaultPolicy()
	for _, job := range jobs {
		if len(job.Policy.Rules) > 0 {
			resolvedPolicy = job.Policy
			break
		}
	}
	growthTop20 := wbGrowthTop20(all)
	filteredPool := append([]wbReadRow(nil), all...)
	riskPool := wbRiskList(all, "combined", resolvedPolicy)
	funnels := wbBuildBatchFunnels(jobs)
	riskCounts := map[string]map[string]int{}
	for _, row := range riskPool {
		if riskCounts[row.Program] == nil {
			riskCounts[row.Program] = map[string]int{}
		}
		riskCounts[row.Program][row.RiskLevel]++
	}
	for program, funnel := range funnels {
		if funnel.Status == "available" {
			funnel.Watch = wbKnownCount(riskCounts[program]["watch"])
			funnel.Extreme = wbKnownCount(riskCounts[program]["extreme"])
			funnels[program] = funnel
		}
	}
	policy := wbPolicyExplanation(filteredPool, riskPool, jobs)
	if !dataView {
		all = wbRiskList(all, ranking, resolvedPolicy)
	}
	if q["stage"] != "" && q["stage"] != "all" {
		filtered := []wbReadRow{}
		for _, row := range all {
			if row.EventStage == q["stage"] {
				filtered = append(filtered, row)
			}
		}
		all = filtered
	}
	wbSortRows(all, ranking)
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	size, _ := strconv.Atoi(r.URL.Query().Get("page_size"))
	if size < 1 {
		size = 50
	}
	if size > 500 {
		size = 500
	}
	start := (page - 1) * size
	end := start + size
	if start > len(all) {
		start = len(all)
	}
	if end > len(all) {
		end = len(all)
	}
	pending = map[string]bool{}
	for _, row := range riskPool {
		if row.EventStage == "pending_operator" {
			pending[wbReadCustomerKey(row)] = true
		}
	}
	cards := map[string]wbCardValue{"queried_customers": wbCard(len(queried), "available", "完整筛选客户池去重，不受分页影响"), "auto_alerted": wbNullCard("unavailable", "历史通知台账未持久化 auto/manual 来源，禁止推断"), "pending": wbCard(len(pending), "available", "命中且仍待运营确认发送的客户去重"), "handled": wbCard(len(handled), "available", "成功发送客户并集去重；失败、排队、未知均排除")}
	var selected wbBatchContract
	for _, b := range batches {
		if b.BatchID == batchID {
			selected = b
			break
		}
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"status": "available", "reason": "", "time": map[string]any{"mode": "weekly", "selected_batch": selected, "batches": batches}, "filters": q, "cards": cards, "funnel": funnels, "policy": policy, "rows": all[start:end], "rankings": map[string]any{"selected": ranking, "growth_top20_by_tier_region": growthTop20, "scope": "full_filtered_set_before_pagination"}, "pagination": map[string]int{"page": page, "page_size": size, "total": len(all)}, "contract_version": wbReadContractVersion, "side_effects": false}})
}
