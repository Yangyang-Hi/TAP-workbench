package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestBackfillTableNameMeetsCloudDBLimit(t *testing.T) {
	if wbBackfillTable != "tap_enrich_backfills" {
		t.Fatalf("unexpected backfill table name: %q", wbBackfillTable)
	}
	if len(wbBackfillTable) > 26 {
		t.Fatalf("backfill table name exceeds Cloud DB 26-character limit: %q", wbBackfillTable)
	}
}

func TestBackfillCloudSchemaUsesSupportedDatetimeFields(t *testing.T) {
	item := wbBackfillTask{CreatedAt: "2026-10-26T05:00:00Z", UpdatedAt: "2026-10-26T06:00:00Z"}
	data := wbBackfillCloudData(item)

	if got := data[wbBackfillStartedAtField]; got != item.CreatedAt {
		t.Fatalf("started_at=%v, want %q", got, item.CreatedAt)
	}
	if got := data[wbBackfillModifiedAtField]; got != item.UpdatedAt {
		t.Fatalf("modified_at=%v, want %q", got, item.UpdatedAt)
	}
	if _, ok := data["created_at"]; ok {
		t.Fatal("Cloud DB mapping must not write unsupported created_at field")
	}
	if _, ok := data["updated_at"]; ok {
		t.Fatal("Cloud DB mapping must not write unsupported updated_at field")
	}
	if wbBackfillModifiedAtField != "modified_at" {
		t.Fatalf("Cloud DB list sort field=%q, want modified_at", wbBackfillModifiedAtField)
	}
}

func TestBackfillFingerprintIsIdempotentAndScoped(t *testing.T) {
	base := wbBackfillRequest{RequestID: "request-a", DryRun: true, Program: "et", BatchID: "batch-1"}
	otherRequest := base
	otherRequest.RequestID = "request-b"
	if wbBackfillFingerprint(base) != wbBackfillFingerprint(otherRequest) {
		t.Fatal("request id must not change the idempotent scope fingerprint")
	}
	otherScope := base
	otherScope.BatchID = "batch-2"
	if wbBackfillFingerprint(base) == wbBackfillFingerprint(otherScope) {
		t.Fatal("different target scopes must not share a fingerprint")
	}
}

func TestBackfillMergeOnlyFillsEnrichment(t *testing.T) {
	oldCCR, sourceCCR, newCCR := 9.0, 3.0, 5.0
	dst := wbRow{
		ID: "row-1", CCR: &oldCCR, Level: "extreme", Reasons: []string{"original trigger"},
		Comparison:  wbComparison{Status: "unavailable", MissingReason: "legacy_not_captured"},
		Advertisers: []wbAdvertiserEvidence{{AccountID: "a", AdvertiserID: "d", CCR: &sourceCCR}},
	}
	src := wbRow{
		ID: "row-1", CCR: &newCCR, Level: "normal", Reasons: []string{"new rule"},
		Comparison:  wbComparison{Status: "available", PreCCR: f64(1), PostCCR: f64(2), CCRDelta: f64(1)},
		Advertisers: []wbAdvertiserEvidence{{AccountID: "a", AdvertiserID: "d", CCR: &newCCR, ComparisonStatus: "available", PreCCR: f64(1), PostCCR: f64(2), ReportedReasons: []reportedReason{unavailableReportedReason("source unavailable")}}},
	}
	if !wbMergeEnrichment(&dst, src) {
		t.Fatal("expected enrichment update")
	}
	if *dst.CCR != 9 || dst.Level != "extreme" || dst.Reasons[0] != "original trigger" {
		t.Fatalf("trigger evidence was overwritten: %+v", dst)
	}
	if dst.Comparison.Status != "available" || dst.Advertisers[0].ComparisonStatus != "available" || *dst.Advertisers[0].CCR != 3 {
		t.Fatalf("enrichment was not merged without overwriting current evidence: %+v", dst)
	}
}

func TestInterruptedBackfillQueuesAutomaticCheckpointResume(t *testing.T) {
	repo := newWBMemoryBackfillRepository()
	repo.items["one"] = wbBackfillTask{ID: "one", Status: "running", LeaseOwner: "dead-worker", Checkpoint: 4}
	old := wbBackfillRepoProvider
	wbBackfillRepoProvider = func() (wbBackfillRepository, error) { return repo, nil }
	defer func() { wbBackfillRepoProvider = old }()
	if err := wbMarkInterruptedBackfills(); err != nil {
		t.Fatal(err)
	}
	got, err := repo.Get(context.Background(), "one")
	if err != nil || got.Status != "queued" || got.Checkpoint != 4 || got.LeaseOwner != "" || len(got.Errors) != 1 || got.Errors[0] != "service_restarted_resume_pending_auth" {
		t.Fatalf("interrupted task did not queue its retained checkpoint: %+v %v", got, err)
	}
	if err := wbMarkInterruptedBackfills(); err != nil {
		t.Fatal(err)
	}
	got, _ = repo.Get(context.Background(), "one")
	if len(got.Errors) != 1 {
		t.Fatalf("restart marker must be idempotent, got errors=%v", got.Errors)
	}
}

func TestBackfillTargetsAreChunkAndMetricStageGranular(t *testing.T) {
	state := wbDisk{Jobs: map[string]wbJob{
		"job-one": {
			ID: "job-one", BatchID: "batch-one", Request: wbRequest{Program: "ET"},
			Rows: []wbRow{{Program: "ET", MetricStatus: "failed", Comparison: wbComparison{Status: "unavailable"}}},
		},
	}}
	targets, err := wbBackfillTargetsFromState(wbBackfillRequest{Program: "ET", BatchID: "batch-one"}, state)
	if err != nil {
		t.Fatal(err)
	}
	want := map[string]bool{
		"job:job-one:0:current_account":       true,
		"job:job-one:0:account_comparison":    true,
		"job:job-one:0:advertiser_enrichment": true,
	}
	if len(targets) != len(want) {
		t.Fatalf("targets=%v, want three metric stages", targets)
	}
	for _, target := range targets {
		if !want[target] {
			t.Fatalf("unexpected target %q in %v", target, targets)
		}
	}
}

func TestBackfillListAPIRequiresOperatorAndReturnsOK(t *testing.T) {
	_, _ = cwFixture(t)
	repo := newWBMemoryBackfillRepository()
	old := wbBackfillRepoProvider
	wbBackfillRepoProvider = func() (wbBackfillRepository, error) { return repo, nil }
	defer func() { wbBackfillRepoProvider = old }()

	forbidden := httptest.NewRecorder()
	workbenchBackfillsList(forbidden, cwTestRequest("owner", ""))
	if forbidden.Code != http.StatusForbidden {
		t.Fatalf("non-operator status=%d body=%s", forbidden.Code, forbidden.Body.String())
	}
	ok := httptest.NewRecorder()
	workbenchBackfillsList(ok, cwTestRequest("operator", ""))
	if ok.Code != http.StatusOK {
		t.Fatalf("operator status=%d body=%s", ok.Code, ok.Body.String())
	}
}

func TestPersistedETAnchorsRecoverExactPriorCreateTime(t *testing.T) {
	state := wbDisk{Jobs: map[string]wbJob{
		"old": {Rows: []wbRow{{Program: "ET", Member: wbMember{AccountID: "7100000000000000001", Start: "2026-10-07 14:51:28"}}}},
		"new": {Rows: []wbRow{{Program: "ET", Member: wbMember{AccountID: "7100000000000000001"}}}},
	}}
	if got := wbPersistedETAnchors(state)["7100000000000000001"]; got != "2026-10-07 14:51:28" {
		t.Fatalf("persisted exact create_time anchor=%q", got)
	}
}
