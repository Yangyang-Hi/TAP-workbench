package main

import (
	"net/http"
	"strconv"
	"strings"
	"time"
)

// businessFilter is the shared server-side contract used by lists, summaries and exports.
// All matching is performed against the complete collection before pagination.
type businessFilter struct {
	Program, Tier, Region, Submitter, Owner, AdvertiserID, AccountID, Search string
	StartDate, EndDate, DateField, Mine                                      string
	AlertStartDate, AlertEndDate, AlertLevel, Status                         string
	Page, PageSize                                                           int
}

func parseBusinessFilter(r *http.Request) businessFilter {
	q := r.URL.Query()
	page, _ := strconv.Atoi(q.Get("page"))
	if page < 1 {
		page = 1
	}
	pageSize, _ := strconv.Atoi(q.Get("page_size"))
	if pageSize < 1 {
		pageSize = 50
	}
	if pageSize > 500 {
		pageSize = 500
	}
	program := strings.ToUpper(strings.TrimSpace(q.Get("program")))
	tier := strings.TrimSpace(q.Get("tier"))
	if program == "" && (strings.EqualFold(tier, "ET") || strings.EqualFold(tier, "THT") || strings.EqualFold(tier, "ST")) {
		program, tier = strings.ToUpper(tier), ""
	}
	return businessFilter{
		Program: program, Tier: tier, Region: strings.TrimSpace(q.Get("region")),
		Submitter: strings.TrimSpace(q.Get("submitter")), Owner: "", AdvertiserID: strings.TrimSpace(q.Get("advertiser_id")), AccountID: strings.TrimSpace(q.Get("account_id")), Search: strings.TrimSpace(q.Get("search")),
		StartDate: q.Get("start_date"), EndDate: q.Get("end_date"), DateField: q.Get("date_field"), Mine: q.Get("mine"),
		AlertStartDate: q.Get("alert_start_date"), AlertEndDate: q.Get("alert_end_date"), AlertLevel: q.Get("alert_level"), Status: q.Get("status"),
		Page: page, PageSize: pageSize,
	}
}

func exactMember(values []string, wanted string) bool {
	wanted = strings.TrimSpace(wanted)
	if wanted == "" || wanted == "all" {
		return true
	}
	for _, value := range values {
		if strings.TrimSpace(value) == wanted {
			return true
		}
	}
	return false
}

func caseSubmitters(a cwCase) []string {
	values := append([]string{}, a.Row.Member.Submitters...)
	values = append(values, a.Row.Member.Submitter)
	for _, ticket := range a.Row.Member.Tickets {
		values = append(values, ticket.Submitter)
	}
	return uniqueNonEmpty(values)
}
func caseAccountIDs(a cwCase) []string {
	return uniqueNonEmpty(append([]string{a.Row.Member.AccountID}, a.Row.Member.LinkedAccountIDs...))
}
func caseAdvertiserIDs(a cwCase) []string {
	return uniqueNonEmpty(append([]string{a.Row.Member.AdvertiserID}, a.Row.Member.LinkedAdvertiserIDs...))
}

func caseApplicableDate(a cwCase, field string) string {
	switch field {
	case "updated_at":
		return dateOnly(a.UpdatedAt)
	case "submission_date":
		return dateOnly(a.Row.Member.CreateDate)
	case "protection_start":
		return dateOnly(a.Row.Member.Start)
	case "protection_end":
		return dateOnly(a.Row.Member.End)
	default:
		return dateOnly(a.CreatedAt)
	}
}

func alertCreatedDay(a cwCase) (string, bool) {
	if strings.TrimSpace(a.CreatedAt) == "" {
		return "", false
	}
	at, err := time.Parse(time.RFC3339, a.CreatedAt)
	if err != nil {
		return "", false
	}
	return at.In(cwLocation()).Format("2006-01-02"), true
}

func matchBusinessCase(a cwCase, f businessFilter, currentUser string) bool {
	if f.Program != "" && f.Program != "ALL" && strings.ToUpper(a.Row.Program) != f.Program {
		return false
	}
	if f.Region != "" && f.Region != "all" && a.Row.Member.Region != f.Region {
		return false
	}
	if f.Tier != "" && f.Tier != "all" && a.Row.Member.Tier != f.Tier {
		return false
	}
	if !exactMember(caseSubmitters(a), f.Submitter) || !exactMember(caseAccountIDs(a), f.AccountID) || !exactMember(caseAdvertiserIDs(a), f.AdvertiserID) {
		return false
	}
	if f.Owner != "" && f.Owner != "all" && a.Owner != f.Owner {
		return false
	}
	if f.Mine == "todo" {
		if currentUser == "" || !exactMember(caseSubmitters(a), currentUser) {
			return false
		}
		status := strings.ToLower(strings.TrimSpace(a.Status))
		if status == "closed" || status == "resolved" || status == "done" || status == "completed" || status == "cancelled" || status == "canceled" {
			return false
		}
	}
	if f.Mine == "submitted" && (currentUser == "" || !exactMember(caseSubmitters(a), currentUser)) {
		return false
	}
	d := caseApplicableDate(a, f.DateField)
	if f.StartDate != "" && d < f.StartDate {
		return false
	}
	if f.EndDate != "" && d > f.EndDate {
		return false
	}

	// Alert Date Range (Always Asia/Shanghai)
	if f.AlertStartDate != "" || f.AlertEndDate != "" {
		atDay, ok := alertCreatedDay(a)
		if !ok {
			return false // Exclude cases with missing/invalid created_at when filtering by date
		}
		if f.AlertStartDate != "" && atDay < f.AlertStartDate {
			return false
		}
		if f.AlertEndDate != "" && atDay > f.AlertEndDate {
			return false
		}
	}

	if f.AlertLevel != "" && f.AlertLevel != "all" && a.Row.Level != f.AlertLevel {
		return false
	}
	if f.Status != "" && f.Status != "all" && a.Status != f.Status {
		return false
	}

	if f.Search != "" {
		hay := strings.ToLower(strings.Join(append(append(append([]string{a.ID, a.Row.Member.Name, a.Owner, a.Row.Member.Region, a.Row.Program}, caseSubmitters(a)...), caseAccountIDs(a)...), caseAdvertiserIDs(a)...), "\n"))
		if !strings.Contains(hay, strings.ToLower(f.Search)) {
			return false
		}
	}
	return true
}

func paginateCases(all []cwCase, page, size int) []cwCase {
	start := (page - 1) * size
	if start >= len(all) {
		return []cwCase{}
	}
	end := start + size
	if end > len(all) {
		end = len(all)
	}
	return all[start:end]
}

func validateIdentityFilter(f businessFilter, currentUser string) (string, string) {
	if f.Mine != "" && f.Mine != "todo" && f.Mine != "submitted" {
		return "unsupported", "mine must be todo or submitted"
	}
	if f.Mine != "" && strings.TrimSpace(currentUser) == "" {
		return "needs_selection", "authenticated identity cannot be matched"
	}
	if !validDate(f.AlertStartDate) || !validDate(f.AlertEndDate) {
		return "unsupported", "alert_start_date and alert_end_date must use YYYY-MM-DD"
	}
	if f.AlertStartDate != "" && f.AlertEndDate != "" && f.AlertStartDate > f.AlertEndDate {
		return "unsupported", "alert_start_date must not be after alert_end_date"
	}
	return "available", ""
}

func validDate(value string) bool {
	if value == "" {
		return true
	}
	_, err := time.Parse("2006-01-02", value)
	return err == nil
}
