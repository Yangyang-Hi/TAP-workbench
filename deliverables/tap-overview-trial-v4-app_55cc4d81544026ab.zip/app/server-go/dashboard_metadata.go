package main

// dashboardMetadata exposes a consistent audit envelope on every dashboard response.
func dashboardMetadata(st snapshotState, sources []string, status string, filterStatus map[string]any) map[string]any {
	dataAsOf, syncedAt, rowCount := "", "", 0
	completeness := "complete"
	for _, name := range sources {
		s := st.Business[name]
		if s.DataAsOf > dataAsOf {
			dataAsOf = s.DataAsOf
		}
		if s.QueriedAt > syncedAt {
			syncedAt = s.QueriedAt
		}
		rowCount += s.RowCount
		if !s.Complete || s.Partial || s.Truncated || s.PossiblyTruncated {
			completeness = "partial"
		}
	}
	if status == "failed" {
		completeness = "failed"
	}
	var apiError any
	if status == "failed" {
		apiError = "source sync failed; last complete snapshot retained"
	}
	displayMode, semantics := "complete", "total"
	if completeness == "partial" {
		displayMode, semantics = "observed_partial", "observed_lower_bound"
	} else if completeness == "failed" || status == "not_ready" || status == "detail_source_not_ready" || status == "unsupported_filter" {
		displayMode, semantics = "not_ready", "unavailable"
	}
	return map[string]any{"data_as_of": dataAsOf, "synced_at": syncedAt, "completeness": completeness, "row_count": rowCount, "display_mode": displayMode, "value_semantics": semantics, "coverage": map[string]any{"sources": sources, "row_count": rowCount, "data_as_of": dataAsOf}, "truncated_reason": func() any {
		if completeness == "partial" {
			return "source response is partial or truncated; values cover verified rows only"
		}
		return nil
	}(), "error": apiError, "filters": filterStatus}
}
