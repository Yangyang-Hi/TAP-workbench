package main

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
)

func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

func decodeHTTPBody(resp *http.Response) ([]byte, error) {
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	encoding := strings.TrimSpace(strings.ToLower(resp.Header.Get("Content-Encoding")))
	if encoding == "gzip" || (len(raw) >= 2 && raw[0] == 0x1f && raw[1] == 0x8b) {
		reader, err := gzip.NewReader(bytes.NewReader(raw))
		if err != nil {
			return nil, err
		}
		defer reader.Close()
		return io.ReadAll(reader)
	}
	return raw, nil
}

func asString(v any) string {
	switch val := v.(type) {
	case string:
		return val
	case float64:
		// JSON decodes unquoted Aeolus uniqueId values as float64. Preserve the
		// integer decimal form; scientific notation is not a valid VQS field ID.
		return strconv.FormatFloat(val, 'f', -1, 64)
	case float32:
		return strconv.FormatFloat(float64(val), 'f', -1, 32)
	case fmt.Stringer:
		return val.String()
	case nil:
		return ""
	default:
		return fmt.Sprintf("%v", val)
	}
}

func asInt64(v any) int64 {
	switch val := v.(type) {
	case int:
		return int64(val)
	case int64:
		return val
	case float64:
		return int64(val)
	case json.Number:
		parsed, _ := val.Int64()
		return parsed
	case string:
		parsed, _ := strconv.ParseInt(strings.TrimSpace(val), 10, 64)
		return parsed
	default:
		return 0
	}
}

func asBool(v any) bool {
	switch val := v.(type) {
	case bool:
		return val
	case string:
		parsed, _ := strconv.ParseBool(strings.TrimSpace(val))
		return parsed
	default:
		return false
	}
}

// mapToEnvelope maps the demo Store shape to typed columns.
// Unknown keys are kept in metadata only as a scaffold fallback; real business
// fields used for query/sort/statistics/constraints should become explicit
// Store fields, SQLite columns, or Cloud DB table fields.
func mapToEnvelope(data map[string]any) recordEnvelope {
	record := recordEnvelope{
		ID:          asString(data["id"]),
		Title:       asString(data["title"]),
		Description: asString(data["description"]),
		Status:      asString(data["status"]),
		Category:    asString(data["category"]),
		OwnerID:     asString(data["ownerId"]),
		Priority:    asInt64(data["priority"]),
		Amount:      asString(data["amount"]),
		Active:      asBool(data["active"]),
		DueAt:       asString(data["dueAt"]),
		CreatedAt:   asString(data["createdAt"]),
		UpdatedAt:   asString(data["updatedAt"]),
		Metadata:    map[string]any{},
	}
	if record.OwnerID == "" {
		record.OwnerID = asString(data["owner_id"])
	}
	if record.DueAt == "" {
		record.DueAt = asString(data["due_at"])
	}
	if metadata, ok := data["metadata"].(map[string]any); ok {
		for key, value := range metadata {
			record.Metadata[key] = value
		}
	}
	for key, value := range data {
		switch key {
		case "id", "_id", "title", "description", "status", "category", "ownerId", "owner_id", "priority", "amount", "active", "dueAt", "due_at", "createdAt", "updatedAt", "create_time", "update_time", "metadata":
			continue
		default:
			record.Metadata[key] = value
		}
	}
	return record
}

func envelopeToMap(record recordEnvelope) map[string]any {
	data := map[string]any{}
	for key, value := range record.Metadata {
		data[key] = value
	}
	data["id"] = record.ID
	data["title"] = record.Title
	data["description"] = record.Description
	data["status"] = record.Status
	data["category"] = record.Category
	data["ownerId"] = record.OwnerID
	data["priority"] = record.Priority
	data["amount"] = record.Amount
	data["active"] = record.Active
	data["dueAt"] = record.DueAt
	data["createdAt"] = record.CreatedAt
	data["updatedAt"] = record.UpdatedAt
	if record.Metadata != nil {
		data["metadata"] = record.Metadata
	}
	return data
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
