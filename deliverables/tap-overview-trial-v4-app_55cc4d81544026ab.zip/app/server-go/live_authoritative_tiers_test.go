package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// TestLiveAuthoritativeTierScan is opt-in. It reads the authoritative ET/THT
// Saved Reports and current-user ST Sheet, then executes representative metric
// queries through each tier's production query path.
func TestLiveAuthoritativeTierScan(t *testing.T) {
	if os.Getenv("RUN_LIVE_AUTHORITY_SCAN") != "1" {
		t.Skip("set RUN_LIVE_AUTHORITY_SCAN=1 for real ET/THT/ST verification")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	if os.Getenv("LIVE_PERSIST_ST") != "1" {
		t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
	defer cancel()
	req := httptest.NewRequest(http.MethodGet, "/api/live", nil)
	req.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	config, err := loadWBConfig()
	if err != nil {
		t.Fatal(err)
	}
	const start, end = "2026-10-01", "2026-10-21"
	proof := map[string]any{}

	for _, program := range []string{"ET", "THT"} {
		query := wbRequest{Program: program, Region: "all", Start: start, End: end, MemberStart: start, MemberEnd: end}
		members, complete, err := liveWBMembers(ctx, req, query, config)
		if err != nil || len(members) == 0 {
			t.Fatalf("%s live membership failed: count=%d complete=%t err=%v", program, len(members), complete, err)
		}
		entry := map[string]any{"membership_count": len(members), "complete": complete}
		if program == "ET" {
			limit := 3
			if len(members) < limit {
				limit = len(members)
			}
			rows, requests, err := wbRunETBatches(ctx, req, members[:limit], query, config.Rules[program])
			if err != nil {
				t.Fatalf("ET representative batch failed: %v", err)
			}
			entry["metric_rows"], entry["metric_requests"] = len(rows), requests
			entry["metric_status"] = rows[0].MetricStatus
		} else {
			result, status := queryTHTCurrent(ctx, req, etCCRDiagnosticRequest{AccountID: members[0].AdvertiserID, StartDate: start, EndDate: end})
			entry["metric_http_status"], entry["metric_status"] = status, asString(result["status"])
			if status >= 500 {
				t.Fatalf("THT representative metric failed: status=%d result=%#v", status, result)
			}
		}
		proof[program] = entry
	}

	syncRequest := httptest.NewRequest(http.MethodPost, "/api/submissions/st-snapshots", nil)
	syncRequest = syncRequest.WithContext(context.WithValue(ctx, ctxKeyUser, authResult{Username: "current-user", Valid: true, HasAccess: true}))
	syncResponse := httptest.NewRecorder()
	submissionsStSnapshotsCreate(syncResponse, syncRequest)
	if syncResponse.Code != http.StatusOK {
		t.Fatalf("ST snapshot API returned %d: %s", syncResponse.Code, syncResponse.Body.String())
	}
	state, err := readSTSnapshotState()
	if err != nil {
		t.Fatal(err)
	}
	query := wbRequest{Program: "ST", Region: "all", Start: start, End: end, MemberStart: "2026-01-01", MemberEnd: "2026-12-31"}
	members, complete, err := loadSTMembers(query)
	if err != nil || len(members) == 0 {
		t.Fatalf("ST membership failed: count=%d complete=%t err=%v", len(members), complete, err)
	}
	limit := 3
	if len(members) < limit {
		limit = len(members)
	}
	rows, requests, err := wbRunSTBatches(ctx, req, members[:limit], query, config.Rules["ST"])
	if err != nil {
		t.Fatalf("ST representative batch failed: %v", err)
	}
	proof["ST"] = map[string]any{"membership_count": len(members), "complete": complete, "q3_rows": state.Snapshots["Q3"].RowCount, "q4_rows": state.Snapshots["Q4"].RowCount, "metric_rows": len(rows), "metric_requests": requests, "metric_status": rows[0].MetricStatus}
	encoded, _ := json.Marshal(proof)
	t.Log(string(encoded))
}
