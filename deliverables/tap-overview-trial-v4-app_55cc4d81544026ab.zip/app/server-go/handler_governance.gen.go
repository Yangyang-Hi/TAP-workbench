// CODE GENERATED FROM app/api/api.yaml BY tools/gen_api.py — DO NOT EDIT
package main

import "net/http"

// 本文件由 IDL 生成，登记 governance 资源的路由契约。
// 业务逻辑写在 handler_governance.go 的 handler 函数里，不要改本文件。
func init() {
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/governance/identity-diagnostics",
		Summary: "获取工作台登录身份、风神短期凭证状态、网络状态与逐 Report 查询状态",
		Handler: governanceIdentityDiagnosticsList,
		Tags:    []string{"governance"},
		Response: map[string]any{
			"data": map[string]any{
				"workbench_identity": map[string]any{
					"status":    "available",
					"principal": "heyangyang.31",
				},
				"aeolus_identity": map[string]any{
					"status":    "available",
					"principal": "heyangyang.31",
				},
				"aeolus_network": map[string]any{
					"status":        "available",
					"endpoint":      "https://aeolus-sg.bytedance.net",
					"http_category": "success",
					"duration_ms":   0,
				},
				"reports": []any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/governance/registry",
		Summary: "获取数据源合同、粒度、Ready/Conditional/Blocked 状态、快照与质量诊断；S04仅名称补充，S09范围合同不足时保持conditional/unknown",
		Handler: governanceRegistryList,
		Tags:    []string{"governance"},
		Response: map[string]any{
			"data": map[string]any{
				"sources": []any{
					map[string]any{
						"source_key":      "SUBMISSION_VOLUME_V2",
						"status":          "ready",
						"latest_sync":     map[string]any{},
						"latest_snapshot": map[string]any{},
						"diagnostics":     map[string]any{},
					},
				},
				"cards":   []any{},
				"regions": []any{},
				"tiers":   []any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/governance/sync-status",
		Summary: "获取最近同步运行状态",
		Handler: governanceSyncStatusList,
		Tags:    []string{"governance"},
		Response: map[string]any{
			"data": map[string]any{
				"runs": []any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/governance/tabs/{tab}",
		Summary: "获取五个治理 Tab 的标准卡片和图表数据",
		Handler: governanceTabsByTabGet,
		Tags:    []string{"governance"},
		QueryParams: []Param{
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
			{Name: "tier", Type: "string"},
			{Name: "application_type", Type: "string"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"tab":    "overview",
				"status": "unavailable",
				"page_contract": map[string]any{
					"controls":    []any{},
					"fixed_scope": map[string]any{},
				},
				"cards":   []any{},
				"filters": map[string]any{},
				"quota": map[string]any{
					"as_of":   "",
					"scope":   "global",
					"plans":   []any{},
					"regions": []any{},
					"tht":     map[string]any{},
				},
			},
		},
	})
}
