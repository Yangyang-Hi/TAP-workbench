package main

import (
	"fmt"
	"net/http"
	"path/filepath"
	"time"
)

// Explicit opt-in for a NEW trial App. It needs no Casework Cloud schema and
// never starts scan schedulers or notification workers. Production is unchanged.
func overviewTrialMux() *http.ServeMux {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/overview/accounts", wrapAuth(overviewAccountsHandler))
	mux.HandleFunc("GET /api/me", wrapAuth(meHandler))
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/" && r.URL.Query().Get("view") != "overview" {
			u := *r.URL
			q := u.Query()
			q.Set("view", "overview")
			u.RawQuery = q.Encode()
			http.Redirect(w, r, u.String(), http.StatusTemporaryRedirect)
			return
		}
		staticHandler(w, r)
	})
	return mux
}

func overviewServeTrial() {
	staticDir = filepath.Join(pluginDir, "app", "overview-dist")
	mux := overviewTrialMux()
	logMsg("Overview-only trial server: no Cloud DB, scans or notification workers", "plugin")
	server := &http.Server{Addr: fmt.Sprintf(":%d", listenPort), Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := server.ListenAndServe(); err != nil {
		panic(err)
	}
}
