package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

func quotaFloat(v float64) *float64 { return &v }

func TestQuotaStatusThresholds(t *testing.T) {
	cases := []struct {
		value *float64
		want  string
	}{{quotaFloat(59.99), "green"}, {quotaFloat(60), "yellow"}, {quotaFloat(79.99), "yellow"}, {quotaFloat(80), "orange"}, {quotaFloat(99.99), "orange"}, {quotaFloat(100), "red"}, {quotaFloat(140), "red"}, {nil, "unavailable"}}
	for _, tc := range cases {
		if got := quotaStatus(tc.value); got != tc.want {
			t.Fatalf("status(%v)=%s want %s", tc.value, got, tc.want)
		}
	}
	if quotaRatio(2, 0) != nil {
		t.Fatal("zero denominator must return nil")
	}
}

func TestAggregateQuotaGlobalAndDedupe(t *testing.T) {
	var b quotaBaseline
	b.Regions = append(b.Regions, struct {
		Region string `json:"region"`
		ET     int    `json:"ET"`
		ST     int    `json:"ST"`
	}{"APAC", 2, 1})
	s := quotaSourceResult{Status: "available", ET: []submissionMetric{{ID: "a1", TicketID: "t1", Region: "APAC", Date: "2026-10-01", AccountIDs: []string{"a1"}}, {ID: "a1", TicketID: "t2", Region: "APAC", Date: "2026-10-02", AccountIDs: []string{"a1"}}, {ID: "a2", TicketID: "t2", Region: "APAC", Date: "2026-10-02", AccountIDs: []string{"a2"}}}, THT: []submissionMetric{{ID: "x", TicketID: "x", Region: "APAC", Date: "2026-10-01", AdvertiserIDs: []string{"adv1"}}, {ID: "x", TicketID: "x", Region: "APAC", Date: "2026-10-08", AdvertiserIDs: []string{"adv1"}}}, ST: []stMetric{{Region: "APAC", Brand: "Brand", AccountID: "acc1"}, {Region: "APAC", Brand: "Brand", AccountID: "acc2"}}}
	got := aggregateQuota(b, s, "Q4")
	global := got["global"].(map[string]any)
	if global["et"].(map[string]any)["used"] != 2 || global["et"].(map[string]any)["metric_level"] != "distinct_account_id" || global["et"].(map[string]any)["account_count"] != 2 {
		t.Fatalf("unexpected ET global: %#v", global["et"])
	}
	if global["tht"].(map[string]any)["used"] != 1 || global["tht"].(map[string]any)["approved_ticket_count"] != 1 || global["st"].(map[string]any)["used"] != 1 || global["st"].(map[string]any)["metric_level"] != "distinct_brand_name" || global["st"].(map[string]any)["account_count"] != 2 || global["st"].(map[string]any)["brand_count"] != 1 {
		t.Fatalf("unexpected global: %#v", global)
	}
	if global["et"].(map[string]any)["status"] != "red" {
		t.Fatal("100 percent must be red")
	}
}

func TestWeeklyQTDUsesOriginalIDDedupeAcrossWeeks(t *testing.T) {
	rows := weeklyQuota([]submissionMetric{{ID: "a", AccountIDs: []string{"a"}, Region: "APAC", Date: "2026-10-01"}, {ID: "a", AccountIDs: []string{"a"}, Region: "APAC", Date: "2026-10-08"}, {ID: "b", AccountIDs: []string{"b"}, Region: "APAC", Date: "2026-10-08"}}, nil)
	if len(rows) != 2 {
		t.Fatalf("weeks=%d", len(rows))
	}
	if rows[0]["et_qtd"] != 1 || rows[1]["et_qtd"] != 2 {
		t.Fatalf("weekly QTD=%#v", rows)
	}
}

func TestSubmissionQuotaUnavailableAndValidation(t *testing.T) {
	old := loadQuotaSources
	defer func() { loadQuotaSources = old }()
	loadQuotaSources = func(_ context.Context, _ *http.Request, _, _, _ string) quotaSourceResult {
		return quotaSourceResult{Status: "partial", SourceStatus: map[string]string{"ET": "available", "THT": "available", "ST": "failed"}, Errors: map[string]string{"ST": "unavailable: denied"}}
	}
	req := httptest.NewRequest(http.MethodGet, "/api/submissions/quota?quarter=Q4&start_date=2026-10-01&end_date=2026-10-20", nil)
	rr := httptest.NewRecorder()
	submissionsQuotaList(rr, req)
	if rr.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", rr.Code, rr.Body.String())
	}
	var body map[string]any
	_ = json.Unmarshal(rr.Body.Bytes(), &body)
	data := body["data"].(map[string]any)
	if data["status"] != "partial" || len(data["errors"].(map[string]any)) != 1 {
		t.Fatalf("unexpected partial response: %s", rr.Body.String())
	}
	global := data["global"].(map[string]any)
	if global["st"].(map[string]any)["used"] != nil || global["et"].(map[string]any)["used"] == nil {
		t.Fatalf("failed source must not hide healthy sources: %s", rr.Body.String())
	}
	bad := httptest.NewRequest(http.MethodGet, "/api/submissions/quota?quarter=Q2", nil)
	badRR := httptest.NewRecorder()
	submissionsQuotaList(badRR, bad)
	if badRR.Code != http.StatusBadRequest {
		t.Fatalf("bad request status=%d", badRR.Code)
	}
}

func TestQuotaFailureKeepsETDenominatorButMarksUsageUnavailable(t *testing.T) {
	var b quotaBaseline
	b.Regions = append(b.Regions, struct {
		Region string `json:"region"`
		ET     int    `json:"ET"`
		ST     int    `json:"ST"`
	}{"APAC", 100, 0})
	s := quotaSourceResult{Status: "partial", SourceStatus: map[string]string{"ET": "failed", "THT": "available", "ST": "available"}, Errors: map[string]string{"ET": "VQS failed"}}
	global := aggregateQuota(b, s, "Q4")["global"].(map[string]any)
	et := global["et"].(map[string]any)
	if et["quota"] != 100 || et["used"] != nil || et["ratio"] != nil || et["status"] != "unavailable" {
		t.Fatalf("ET failure semantics mismatch: %#v", et)
	}
}

func TestQuotaNotificationUsesETInclusiveBoundaryAndKeepsPOCNullable(t *testing.T) {
	var b quotaBaseline
	b.Regions = append(b.Regions, struct {
		Region string `json:"region"`
		ET     int    `json:"ET"`
		ST     int    `json:"ST"`
	}{"AT_LIMIT", 1, 0}, struct {
		Region string `json:"region"`
		ET     int    `json:"ET"`
		ST     int    `json:"ST"`
	}{"OVER", 1, 0})
	s := quotaSourceResult{Status: "available", SourceStatus: map[string]string{"ET": "available", "THT": "available", "ST": "available"}, ET: []submissionMetric{{TicketID: "t1", AccountIDs: []string{"a1"}, Region: "AT_LIMIT"}, {TicketID: "t2", AccountIDs: []string{"a2"}, Region: "OVER"}, {TicketID: "t3", AccountIDs: []string{"a3"}, Region: "OVER"}}}
	regions := aggregateQuota(b, s, "Q4")["regions"].([]map[string]any)
	got := map[string]map[string]any{}
	for _, row := range regions {
		got[row["region"].(string)] = row
	}
	if got["AT_LIMIT"]["notification_status"] != "pending_regional_poc" || got["OVER"]["notification_status"] != "pending_regional_poc" || got["OVER"]["tier"] != "ET" || got["OVER"]["regional_poc"] != nil {
		t.Fatalf("quota notification contract mismatch: %#v", got)
	}
	if len(etQuotaExcesses(b, s)) != 2 {
		t.Fatalf("ET >=100 boundary mismatch: %#v", etQuotaExcesses(b, s))
	}
}

func TestTHTSeparatesTicketAndAdvertiserCounts(t *testing.T) {
	s := quotaSourceResult{Status: "available", SourceStatus: map[string]string{"ET": "available", "THT": "available", "ST": "available"}, THT: []submissionMetric{
		{TicketID: "t1", ID: "t1", Region: "APAC", AdvertiserIDs: []string{"a1"}},
		{TicketID: "t2", ID: "t2", Region: "APAC", AdvertiserIDs: []string{"a1"}},
		{TicketID: "t2", ID: "t2", Region: "", AdvertiserIDs: []string{"a2"}},
	}}
	result := aggregateQuota(quotaBaseline{}, s, "Q4")
	global := result["global"].(map[string]any)["tht"].(map[string]any)
	if global["approved_ticket_count"] != 2 || global["distinct_advertiser_count"] != 2 || global["ratio"] != nil || global["remaining"] != nil {
		t.Fatalf("THT semantics mismatch: %#v", global)
	}
	regions := result["regions"].([]map[string]any)
	foundUnknown := false
	for _, region := range regions {
		if region["region"] == "Unknown / Unmapped" {
			foundUnknown = true
		}
	}
	if !foundUnknown {
		t.Fatal("missing Region must remain visible as Unknown / Unmapped")
	}
}

func TestSTQuotaRatioAndStrictAlertBoundary(t *testing.T) {
	var b quotaBaseline
	b.Regions = append(b.Regions, struct {
		Region string `json:"region"`
		ET     int    `json:"ET"`
		ST     int    `json:"ST"`
	}{"AT_LIMIT", 0, 1}, struct {
		Region string `json:"region"`
		ET     int    `json:"ET"`
		ST     int    `json:"ST"`
	}{"OVER", 0, 1})
	s := quotaSourceResult{Status: "available", SourceStatus: map[string]string{"ET": "available", "THT": "available", "ST": "available"}, ST: []stMetric{
		{Region: "AT_LIMIT", Brand: "brand-1"},
		{Region: "OVER", Brand: "brand-2"},
		{Region: "OVER", Brand: "brand-3"},
	}}
	regions := aggregateQuota(b, s, "Q4")["regions"].([]map[string]any)
	got := map[string]map[string]any{}
	for _, region := range regions {
		got[region["region"].(string)] = region["st"].(map[string]any)
	}
	if got["AT_LIMIT"]["ratio"] != float64(100) || got["AT_LIMIT"]["alert"] != false {
		t.Fatalf("ST 100%% boundary alerted or ratio missing: %#v", got["AT_LIMIT"])
	}
	if got["OVER"]["ratio"] != float64(200) || got["OVER"]["alert"] != true || got["OVER"]["status"] != "red" {
		t.Fatalf("ST over-quota ratio/alert mismatch: %#v", got["OVER"])
	}
}

// A repeated approved submission consumes one account slot, but remains two tickets.
func TestETQuotaAccountUnitAcrossTicketsWeeksAndRegions(t *testing.T) {
	var b quotaBaseline
	b.Regions = append(b.Regions, struct {
		Region string `json:"region"`
		ET     int    `json:"ET"`
		ST     int    `json:"ST"`
	}{"APAC", 2, 240})
	rows := []submissionMetric{
		{TicketID: "t1", AccountIDs: []string{"a1"}, Region: "APAC", Date: "2026-10-01"},
		{TicketID: "t2", AccountIDs: []string{"a1"}, Region: "APAC", Date: "2026-10-08"},
		{TicketID: "t3", AccountIDs: []string{"a1"}, Region: "CNOB", Date: "2026-10-08"},
	}
	result := aggregateQuota(b, quotaSourceResult{ET: rows, ST: []stMetric{{Region: "APAC", Brand: "B1", AccountID: "s1"}, {Region: "APAC", Brand: "B1", AccountID: "s2"}}}, "Q4")
	g := result["global"].(map[string]any)
	et := g["et"].(map[string]any)
	st := g["st"].(map[string]any)
	if et["used"] != 1 || et["ticket_count"] != 3 || et["ratio"] != float64(50) || et["cross_region_duplicate_account_count"] != 1 {
		t.Fatalf("ET units mixed: %#v", et)
	}
	if st["used"] != 1 || st["account_count"] != 2 || st["quota"] != 240 {
		t.Fatalf("ST brand/account units mixed: %#v", st)
	}
	for _, p := range weeklyQuota(rows, nil) {
		if p["et_qtd"] != 1 {
			t.Fatalf("Repeated ticket inflated account trend: %#v", p)
		}
	}
	// A ticket without an account must never become an account identity.
	missing := aggregateQuota(b, quotaSourceResult{ET: []submissionMetric{{TicketID: "t-only", Region: "APAC"}}}, "Q4")["global"].(map[string]any)["et"].(map[string]any)
	if missing["used"] != 0 || missing["ticket_count"] != 1 {
		t.Fatalf("Ticket substituted for account: %#v", missing)
	}
}

func TestQuotaBrandBaselineMatchesRegionalScreenshot(t *testing.T) {
	b, err := loadQuotaBaseline()
	if err != nil {
		t.Fatal(err)
	}
	expected := map[string]int{"APAC": 240, "CNOB": 36, "EUI": 111, "JP": 76, "KR": 11, "LATAM": 52, "METAP": 180, "NA": 111, "Scaled Growth Agency": 0}
	et, st := 0, 0
	for _, q := range b.Regions {
		if q.ST != expected[q.Region] {
			t.Fatalf("Wrong brand quota: %+v", q)
		}
		et += q.ET
		st += q.ST
	}
	if et != 6356 || st != 817 || len(b.Warnings) == 0 {
		t.Fatalf("Baseline totals/warning: ET=%d ST=%d warnings=%v", et, st, b.Warnings)
	}
}
