package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func withProbeHTTPClient(t *testing.T, timeout time.Duration) {
	t.Helper()
	original := httpClient
	httpClient = &http.Client{Timeout: timeout}
	t.Cleanup(func() { httpClient = original })
}

func TestResolveSavedReportChartTimeoutFallbackSuccess(t *testing.T) {
	withProbeHTTPClient(t, 20*time.Millisecond)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case aeolusGlueToSimplePath:
			time.Sleep(60 * time.Millisecond)
		case aeolusSavedReportPath:
			if r.Header.Get("x-titan-token") != "token" || r.URL.Query().Get("rid") != "2915920" {
				t.Fatalf("metadata request lost auth or report id: %s", r.URL.String())
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"data": map[string]any{"reqJson": `{"chart":{"datasetId":1198629,"dimensions":[{"datasetFieldId":"10000000536486","uniqueId":"261020132518278"}],"measures":[],"filters":[],"tableConfig":{"dataLimit":50}}}`}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()

	chart, primary, fallback, source := resolveSavedReportChart(context.Background(), server.URL, "token", 2915920)
	if primary.ErrorType != "network_error" || fallback == nil || fallback.Status != "passed" {
		t.Fatalf("unexpected steps: primary=%+v fallback=%+v", primary, fallback)
	}
	if source != "saved_report_metadata" || chart == nil {
		t.Fatalf("fallback source=%q chart=%#v", source, chart)
	}
	if got := chart["datasetId"].(json.Number).String(); got != "1198629" {
		t.Fatalf("dataset id precision changed: %s", got)
	}
}

func TestResolveSavedReportChartFallbackFailure(t *testing.T) {
	withProbeHTTPClient(t, time.Second)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == aeolusGlueToSimplePath {
			_ = json.NewEncoder(w).Encode(map[string]any{"data": map[string]any{}})
			return
		}
		w.WriteHeader(http.StatusForbidden)
	}))
	defer server.Close()

	chart, primary, fallback, _ := resolveSavedReportChart(context.Background(), server.URL, "token", 2915920)
	if chart != nil || primary.ErrorType != "missing_simple_chart" || fallback == nil || fallback.ErrorType != "permission_denied" {
		t.Fatalf("permission failure must remain explicit: chart=%#v primary=%+v fallback=%+v", chart, primary, fallback)
	}
}

func TestFallbackChartRetainsFilterAndFieldContracts(t *testing.T) {
	metadata := map[string]any{"data": map[string]any{"reqJson": `{"datasetId":1198629,"dimensions":[{"datasetFieldId":"10000000536486","uniqueId":"261020132518278"}],"measures":[],"filters":[]}`}}
	chart := findSavedReportChart(metadata)
	source := sourceConfig{Fields: map[string]fieldConfig{
		"account_id":  {DimMetID: "10000000536486", UniqueID: "261020132518278"},
		"create_date": {DimMetID: "10000000536473", UniqueID: "261020132518600"},
	}}
	filtered, pushed := chartWithBusinessFilters(chart, source, filterRequest{StartDate: "2026-10-01", EndDate: "2026-10-20"})
	if len(pushed) != 1 || pushed[0] != "create_date" {
		t.Fatalf("date filter contract not applied: %#v", pushed)
	}
	exact, err := exactIDFilter(source, "account_id", []string{"7668503101095297031"})
	if err != nil || exact["uniqueId"] != "261020132518278" {
		t.Fatalf("id contract changed: filter=%#v err=%v", exact, err)
	}
	if chart["filters"] == nil || len(filtered["filters"].([]any)) != 1 {
		t.Fatalf("fallback chart mutation/filter mismatch: base=%#v filtered=%#v", chart, filtered)
	}
}

func TestFallbackEligibilityRejectsAuthenticationAndPermissionErrors(t *testing.T) {
	for _, step := range []titanProbeStep{{ErrorType: "http_error", HTTPStatus: 401}, {ErrorType: "http_error", HTTPStatus: 403}, {ErrorType: "permission_denied", HTTPStatus: 403}} {
		if isSavedReportFallbackEligible(step) {
			t.Fatalf("must not fallback for auth/permission error: %+v", step)
		}
	}
}
