package main

import (
	"fmt"
	"testing"
)

func TestProgramFunnelCountsKnownAndUnknownFields(t *testing.T) {
	ccr, nfs, revenue := 50.0, 300.0, 1000.0
	raw, business := 5, 3
	job := wbJob{
		Request:                wbRequest{Program: "ET"},
		Rule:                   wbRule{Enabled: true},
		Complete:               true,
		MembershipRawRows:      &raw,
		MembershipBusinessRows: &business,
		Rows: []wbRow{
			{ID: "one", Member: wbMember{AccountID: "a1", MetadataStatus: "ready"}, CCR: &ccr, NFS: &nfs, Revenue: &revenue, Advertisers: []wbAdvertiserEvidence{{AccountID: "a1", AdvertiserID: "adv1", CCR: &ccr, NFS: &nfs, Revenue: &revenue}}},
			{ID: "two", Member: wbMember{AccountID: "a2", MetadataStatus: "missing"}, MetricStatus: "no_fact"},
		},
	}
	funnel := wbBuildProgramFunnel(job)
	if funnel.RawRows.Value == nil || *funnel.RawRows.Value != 5 || funnel.BusinessFiltered.Value == nil || *funnel.BusinessFiltered.Value != 3 {
		t.Fatalf("membership funnel mismatch: %+v", funnel)
	}
	if funnel.DistinctClients.Value == nil || *funnel.DistinctClients.Value != 2 || *funnel.MappingSuccess.Value != 1 || *funnel.MappingFail.Value != 1 {
		t.Fatalf("identity funnel mismatch: %+v", funnel)
	}
	if *funnel.Extreme.Value != 1 || *funnel.NoFact.Value != 1 || *funnel.Partial.Value != 0 {
		t.Fatalf("risk/completeness funnel mismatch: extreme=%d no_fact=%d partial=%d", *funnel.Extreme.Value, *funnel.NoFact.Value, *funnel.Partial.Value)
	}

	legacy := wbBuildProgramFunnel(wbJob{Request: wbRequest{Program: "ST"}})
	if legacy.RawRows.Status != "unknown" || legacy.BusinessFiltered.Status != "unknown" {
		t.Fatalf("legacy membership fields must be unknown: %+v", legacy)
	}
}

func TestPolicyExplanationSeparatesHistoricalSnapshotFromV2(t *testing.T) {
	ccr, nfs := 50.0, 300.0
	job := wbJob{ID: "scan", Request: wbRequest{Program: "ET"}, Rows: []wbRow{{ID: "row", Level: "watch"}}}
	row := wbReadRow{Program: "ET", AccountID: "a1", ScanID: "scan", RowID: "row", CCR: &ccr, NFS: &nfs, Comparison: wbComparison{Status: "unavailable", MissingReason: "pre_ccr_missing"}}
	risk := row
	risk.RiskLevel = "critical"
	policy := wbPolicyExplanation([]wbReadRow{row}, []wbReadRow{risk}, []wbJob{job})
	legacy := policy["legacy_snapshot_counts"].(map[string]map[string]int)
	current := policy["v2_reclassified_counts"].(map[string]map[string]int)
	changed := policy["changed_classification_counts"].(map[string]int)
	if legacy["ET"]["watch"] != 1 || current["ET"]["critical"] != 1 || changed["ET"] != 1 {
		t.Fatalf("policy explanation mixed historical/current state: %+v", policy)
	}
	if policy["policy_version"] != wbGovernancePolicyVersion || policy["snapshot_levels_are_historical"] != true {
		t.Fatalf("policy metadata mismatch: %+v", policy)
	}
}

func TestBatchFunnelsMergeRealWeeklyShapeAndMarkAbsentST(t *testing.T) {
	ccr, nfs := 4.0, 60.0
	et := wbJob{ID: "et", BatchID: "TAP-WEEK-2026-10-12-2026-10-18", Status: "ready", Complete: true, FinishedAt: "2026-10-21T10:00:00Z", Request: wbRequest{Program: "ET"}}
	tht := wbJob{ID: "tht", BatchID: et.BatchID, Status: "ready", Complete: true, FinishedAt: "2026-10-21T10:00:00Z", Request: wbRequest{Program: "THT"}}
	for i := 0; i < 2150; i++ {
		accountID := fmt.Sprintf("et-account-%d", i)
		advertisers := []wbAdvertiserEvidence{}
		if i < 1994 {
			advertisers = append(advertisers, wbAdvertiserEvidence{AccountID: accountID, AdvertiserID: fmt.Sprintf("et-advertiser-%d", i), CCR: &ccr, NFS: &nfs})
		}
		et.Rows = append(et.Rows, wbRow{ID: fmt.Sprintf("et-%d", i), Program: "ET", Member: wbMember{AccountID: accountID, MetadataStatus: "ready"}, CCR: &ccr, NFS: &nfs, Advertisers: advertisers, AdvertiserCount: len(advertisers)})
	}
	for i := 0; i < 4096; i++ {
		tht.Rows = append(tht.Rows, wbRow{ID: fmt.Sprintf("tht-%d", i), Program: "THT", Member: wbMember{AccountID: "shared-account", AdvertiserID: fmt.Sprintf("tht-advertiser-%d", i), MetadataStatus: "ready"}, CCR: &ccr, NFS: &nfs})
	}
	// A retry for the same batch/program overlaps one customer. It must replace,
	// rather than append to, the selected batch's distinct business-key pool.
	retry := wbJob{ID: "tht-retry", BatchID: et.BatchID, Status: "ready", Complete: true, FinishedAt: "2026-10-21T11:00:00Z", Request: wbRequest{Program: "THT"}, Rows: []wbRow{tht.Rows[0]}}
	funnels := wbBuildBatchFunnels([]wbJob{et, tht, retry})
	if got := *funnels["ET"].DistinctClients.Value; got != 2150 {
		t.Fatalf("ET scans were not merged by batch: got %d", got)
	}
	if got := *funnels["THT"].DistinctClients.Value; got != 4096 {
		t.Fatalf("THT distinct advertiser pool inflated by retry/account collision: got %d", got)
	}
	if funnels["ST"].Status != "not_scanned" || funnels["ST"].DistinctClients.Status != "unknown" || funnels["ST"].DistinctClients.Value != nil {
		t.Fatalf("absent ST must be explicit unknown/not_scanned: %+v", funnels["ST"])
	}
}

func TestPolicyCountsNeverExceedDistinctProgramPool(t *testing.T) {
	ccr, nfs := 50.0, 300.0
	job1 := wbJob{ID: "scan-1", Request: wbRequest{Program: "THT"}, Rows: []wbRow{{ID: "old", Program: "THT", Level: "watch", Member: wbMember{AccountID: "account", AdvertiserID: "adv"}}}}
	job2 := wbJob{ID: "scan-2", Request: wbRequest{Program: "THT"}, Rows: []wbRow{{ID: "new", Program: "THT", Level: "critical", Member: wbMember{AccountID: "account", AdvertiserID: "adv"}}}}
	old := wbReadRow{Program: "THT", AccountID: "account", AdvertiserID: "adv", ScanID: "scan-1", RowID: "old", CCR: &ccr, NFS: &nfs}
	latest := old
	latest.ScanID, latest.RowID = "scan-2", "new"
	risk := latest
	risk.RiskLevel = "extreme"
	policy := wbPolicyExplanation([]wbReadRow{old, latest}, []wbReadRow{risk, risk}, []wbJob{job1, job2})
	legacy := policy["legacy_snapshot_counts"].(map[string]map[string]int)["THT"]
	current := policy["v2_reclassified_counts"].(map[string]map[string]int)["THT"]
	changed := policy["changed_classification_counts"].(map[string]int)["THT"]
	if legacy["watch"]+legacy["critical"] != 1 || current["extreme"] != 1 || changed > 1 {
		t.Fatalf("policy counts exceeded one distinct advertiser: %+v", policy)
	}
}

func TestETFunnelUsesPairBridgeAndPairMetricsAtRealWeeklyShape(t *testing.T) {
	watchCCR, watchNFS := 4.0, 60.0
	criticalCCR, criticalNFS := 45.0, 300.0
	job := wbJob{Request: wbRequest{Program: "ET"}, Rule: wbRule{Enabled: true, RiskPolicy: wbGovernancePolicyVersion}, Complete: true}
	pairTotal := 0
	for i := 0; i < 2150; i++ {
		row := wbRow{ID: fmt.Sprintf("et-%d", i), Program: "ET", Member: wbMember{AccountID: fmt.Sprintf("account-%d", i)}}
		if i < 1994 {
			pairCount := 7
			if i < 1849 {
				pairCount = 8
			}
			for j := 0; j < pairCount; j++ {
				ccr, nfs := &watchCCR, &watchNFS
				if i == 0 && j == 0 {
					ccr, nfs = &criticalCCR, &criticalNFS
				}
				row.Advertisers = append(row.Advertisers, wbAdvertiserEvidence{AccountID: row.Member.AccountID, AdvertiserID: fmt.Sprintf("advertiser-%d-%d", i, j), CCR: ccr, NFS: nfs})
				pairTotal++
			}
			row.AdvertiserCount = len(row.Advertisers)
			row.CCR, row.NFS, row.Revenue = &watchCCR, &watchNFS, f64(100)
			if i == 0 {
				row.CCR, row.NFS = &criticalCCR, &criticalNFS
			}
		}
		job.Rows = append(job.Rows, row)
	}
	if pairTotal != 15807 {
		t.Fatalf("fixture pair count=%d", pairTotal)
	}
	funnel := wbBuildProgramFunnel(job)
	if *funnel.DistinctClients.Value != 2150 || *funnel.MappingSuccess.Value != 1994 || *funnel.MappingFail.Value != 156 {
		t.Fatalf("bridge mapping used wrong grain: %+v", funnel)
	}
	if *funnel.CurrentCCRComplete.Value != 1994 || *funnel.CurrentNFSComplete.Value != 1994 || *funnel.RevenueComplete.Value != 1994 {
		t.Fatalf("authoritative Account metric completeness mismatch: %+v", funnel)
	}
	if *funnel.AdvertiserPairs.Value != 15807 || *funnel.AdvertiserPairCCRComplete.Value != 15807 || *funnel.AdvertiserPairNFSComplete.Value != 15807 || *funnel.AdvertiserPairRuleEligible.Value != 15807 {
		t.Fatalf("pair completeness mismatch: %+v", funnel)
	}
	if *funnel.RuleEligible.Value != 1994 || *funnel.Extreme.Value != 1 || *funnel.Watch.Value != 1993 {
		t.Fatalf("pair rules were not rolled up to account: %+v", funnel)
	}
}
