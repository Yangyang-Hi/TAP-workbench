package main

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

const savedReportHardLimit = 50000

// chartFieldRef resolves the field contract from the saved report itself. This
// avoids hard-coding unstable Aeolus IDs while still pushing filters to Aeolus.
func chartFieldRef(chart map[string]any, semantic string, spec fieldConfig) (string, string) {
	// Confirmed contracts are authoritative. In particular, the Account
	// historical report has separate partition and business-date fields whose
	// labels overlap, so fuzzy chart walking can silently select the wrong one.
	if strings.TrimSpace(spec.DimMetID) != "" && strings.TrimSpace(spec.UniqueID) != "" {
		return strings.TrimSpace(spec.DimMetID), strings.TrimSpace(spec.UniqueID)
	}
	needles := uniqueNonEmpty([]string{semantic, spec.SourceName, spec.DimMetID})
	fieldID, uniqueID := "", ""
	var walk func(any)
	walk = func(value any) {
		if fieldID != "" {
			return
		}
		switch node := value.(type) {
		case map[string]any:
			encoded, _ := json.Marshal(node)
			desc := strings.ToLower(string(encoded))
			matched := false
			for _, needle := range needles {
				if needle != "" && strings.Contains(desc, strings.ToLower(needle)) {
					matched = true
					break
				}
			}
			if matched {
				fieldID = firstNonEmpty(node, "datasetFieldId", "dimMetId", "fieldId", "uniqueId")
				uniqueID = firstNonEmpty(node, "uniqueId", "uniqueID", "dimMetId", "datasetFieldId")
				if uniqueID == "" {
					uniqueID = fieldID
				}
				if fieldID != "" {
					return
				}
			}
			for _, child := range node {
				walk(child)
			}
		case []any:
			for _, child := range node {
				walk(child)
			}
		}
	}
	walk(chart)
	return fieldID, uniqueID
}

func firstNonEmpty(node map[string]any, keys ...string) string {
	for _, key := range keys {
		if value := strings.TrimSpace(asString(node[key])); value != "" {
			return value
		}
	}
	return ""
}

func aeolusFilter(fieldID, uniqueID, operator string, value any) map[string]any {
	values, ok := value.([]string)
	if !ok {
		values = []string{asString(value)}
	}
	return map[string]any{"type": "whereString", "datasetFieldId": fieldID, "uniqueId": uniqueID, "showFilter": false, "detail": map[string]any{"operator": "in", "value": values}}
}

func aeolusDateFilter(fieldID, uniqueID, start, end string) (map[string]any, bool) {
	startTime, startOK := parseDate(start)
	endTime, endOK := parseDate(end)
	if !startOK || !endOK || endTime.Before(startTime) {
		return nil, false
	}
	values := []string{}
	for day := startTime; !day.After(endTime); day = day.AddDate(0, 0, 1) {
		values = append(values, day.Format("2006-01-02"))
		if len(values) > 3660 {
			return nil, false
		}
	}
	return map[string]any{"type": "whereString", "datasetFieldId": fieldID, "uniqueId": uniqueID, "showFilter": false, "detail": map[string]any{"operator": "in", "value": values}}, true
}

func chartWithBusinessFilters(base map[string]any, source sourceConfig, f filterRequest) (map[string]any, []string) {
	chart := cloneMap(base)
	filters := []any{}
	// ET RID 2898604 already carries its verified business predicates in the
	// saved report. Preserve those capsules (including their report-specific
	// uniqueIds) and only replace the user-controlled create_time window below.
	if source.RID == 2898604 {
		if saved, ok := chart["filters"].([]any); ok {
			for _, raw := range saved {
				filter, _ := raw.(map[string]any)
				if asString(filter["datasetFieldId"]) != source.Fields["create_date"].DimMetID {
					filters = append(filters, raw)
				}
			}
		}
	}
	// User-requested filters replace Saved Report UI defaults (for example
	// lastSync-relative filters that are invalid in Glue query_chart).
	applied := []string{}
	add := func(semantic, operator string, value any) {
		spec, ok := source.Fields[semantic]
		if !ok {
			return
		}
		fieldID, uniqueID := chartFieldRef(chart, semantic, spec)
		if fieldID == "" {
			return
		}
		filters = append(filters, aeolusFilter(fieldID, uniqueID, operator, value))
		applied = append(applied, semantic)
	}
	dateField := "p_date"
	// Some historical reports expose a dedicated partition filter that is
	// intentionally different from the business-date column returned in rows.
	// Always push the partition field when the source contract declares it.
	if _, ok := source.Fields["p_date_filter"]; ok {
		dateField = "p_date_filter"
	} else if _, ok := source.Fields["create_date"]; ok {
		dateField = "create_date"
	}
	useSavedRevenueWindow := false
	if source.RID == 2942918 && f.StartDate != "" && f.EndDate != "" {
		previousStart, previousEnd := previousCompleteWeek(time.Now())
		useSavedRevenueWindow = f.StartDate == previousStart && f.EndDate == previousEnd
	}
	if (f.StartDate != "" || f.EndDate != "") && !useSavedRevenueWindow {
		start, end := f.StartDate, f.EndDate
		if start == "" {
			start = "1970-01-01"
		}
		if end == "" {
			end = time.Now().UTC().Format("2006-01-02")
		}
		if spec, ok := source.Fields[dateField]; ok {
			fieldID, uniqueID := chartFieldRef(chart, dateField, spec)
			if dateFilter, valid := aeolusDateFilter(fieldID, uniqueID, start, end); valid && fieldID != "" {
				// Datetime/date fields must use a range filter. An IN list of YYYY-MM-DD
				// values does not match timestamp values and can silently produce zero rows.
				if dateField == "p_date_filter" || spec.ExpectedType == "datetime" || spec.ExpectedType == "date" || spec.ExpectedType == "date_string" {
					dateFilter = map[string]any{"type": "whereDate", "datasetFieldId": fieldID, "uniqueId": uniqueID, "showFilter": false, "detail": map[string]any{"startTime": map[string]any{"type": "fixed", "date": start + " 00:00:00"}, "endTime": map[string]any{"type": "fixed", "date": end + " 23:59:59"}, "dateMode": "calendar_days", "dateNullOption": "nonNull"}}
				}
				filters = append(filters, dateFilter)
				applied = append(applied, dateField)
			}
		}
	}
	if f.Region != "" {
		encoded, _ := json.Marshal([]string{f.Region})
		add("region", "EQ", string(encoded))
	}
	if f.ClientTier != "" {
		tier := strings.ToLower(strings.ReplaceAll(strings.TrimSpace(f.ClientTier), " ", "_"))
		add("client_tier", "EQ", tier)
	}
	// Authority-owned predicates are declared per source. RID 2942519 uses only
	// the requested week plus is_online=1; Business Tier stays in membership.
	if containsString(source.QueryProfile.Filters, "is_online") {
		add("is_online", "EQ", "1")
	}
	if containsString(source.QueryProfile.Filters, "trust_region") {
		add("trust_region", "EQ", "strategic_trust")
	}
	// program_type is derived, so push its source fields when possible and always
	// apply the exact derived predicate again after download.
	if f.ProgramType != "" {
		switch strings.ToUpper(f.ProgramType) {
		case "ST":
			add("type_name", "EQ", "Strategic trust apply")
		case "ET":
			if source.RID != 2898604 {
				add("type_name", "EQ", "Emerging trust apply")
				add("final_result", "EQ", "APPROVE")
			}
		case "THT":
			add("type_name", "EQ", "Protection program")
			add("protection_program_name", "EQ", thtProgram)
			add("final_result", "EQ", "APPROVE")
		}
	}
	chart["filters"] = filters
	return chart, uniqueNonEmpty(applied)
}

func splitDateRange(from, to string) (filterRequest, filterRequest, bool) {
	start, ok1 := parseDate(from)
	end, ok2 := parseDate(to)
	if !ok1 || !ok2 || !start.Before(end) {
		return filterRequest{}, filterRequest{}, false
	}
	days := int(end.Sub(start).Hours() / 24)
	mid := start.AddDate(0, 0, days/2)
	leftEnd := mid
	rightStart := mid.AddDate(0, 0, 1)
	if rightStart.After(end) {
		return filterRequest{}, filterRequest{}, false
	}
	return filterRequest{StartDate: start.Format("2006-01-02"), EndDate: leftEnd.Format("2006-01-02")}, filterRequest{StartDate: rightStart.Format("2006-01-02"), EndDate: end.Format("2006-01-02")}, true
}

func mergeFilter(base, dates filterRequest) filterRequest {
	base.StartDate, base.EndDate = dates.StartDate, dates.EndDate
	return base
}

func primaryKeyForSource(source string, row map[string]any) string {
	if source == "submission" || source == "submission_detail" || source == "protection" || source == "tht_detail" || source == "et_account_list" || source == "tht_ticket_details" {
		return asString(row["ticket_id"])
	}
	date := asString(row["p_date"])
	if date == "" {
		date = asString(row["date"])
	}
	parts := []string{date, asString(row["account_id"]), asString(row["advertiser_id"])}
	if source == "advertiser_reported_reasons" {
		parts = append(parts, asString(row["semantics_label_tier_1_2_3_4"]))
	}
	return strings.Join(parts, "\x1f")
}

func dedupeRows(source string, rows []map[string]any) []map[string]any {
	seen := map[string]bool{}
	out := make([]map[string]any, 0, len(rows))
	for i, row := range rows {
		key := primaryKeyForSource(source, row)
		if key == "" || key == "\x1f\x1f" {
			key = fmt.Sprintf("__row_%d", i)
		}
		if seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, row)
	}
	return out
}

func ratioOfSums(rows []map[string]any, numerator, denominator string) any {
	num, den := 0.0, 0.0
	for _, row := range rows {
		n, nok := number(row[numerator])
		d, dok := number(row[denominator])
		if nok && dok {
			num += n
			den += d
		}
	}
	if den == 0 {
		return nil
	}
	return num / den
}

func requestFilterFromValues(start, end, region, tier, program string) filterRequest {
	return filterRequest{StartDate: start, EndDate: end, Region: region, ClientTier: tier, ProgramType: strings.ToUpper(program)}
}

func formatDate(t time.Time) string { return t.Format("2006-01-02") }

func querySavedReportSharded(ctx context.Context, host, token string, reportID int, base map[string]any, source sourceConfig, f filterRequest, depth int) (titanProbeStep, bool) {
	step := probeQueryChart(ctx, host, token, reportID, base)
	if step.Status != "passed" || step.RowsCount < savedReportHardLimit {
		return step, false
	}
	if depth >= 16 {
		return step, true
	}
	fieldMap := buildContractFieldMap(base, step.Columns)
	for column, descriptor := range step.FieldMap {
		fieldMap[column] = descriptor
	}
	canonical := canonicalizeSavedReportDetails(step.Rows, source.Fields, fieldMap)
	if f.StartDate == "" || f.EndDate == "" {
		dateKey := "p_date"
		if _, ok := source.Fields["create_date"]; ok {
			dateKey = "create_date"
		}
		for _, row := range canonical {
			value := asString(row[dateKey])
			if _, ok := parseDate(value); !ok {
				continue
			}
			if f.StartDate == "" || value < f.StartDate {
				f.StartDate = value
			}
			if f.EndDate == "" || value > f.EndDate {
				f.EndDate = value
			}
		}
	}
	leftDates, rightDates, splittable := splitDateRange(f.StartDate, f.EndDate)
	if splittable {
		leftFilter, rightFilter := mergeFilter(f, leftDates), mergeFilter(f, rightDates)
		leftChart, leftApplied := chartWithBusinessFilters(base, source, leftFilter)
		rightChart, rightApplied := chartWithBusinessFilters(base, source, rightFilter)
		dateField := "p_date"
		if _, ok := source.Fields["p_date_filter"]; ok {
			dateField = "p_date_filter"
		} else if _, ok := source.Fields["create_date"]; ok {
			dateField = "create_date"
		}
		if !containsString(leftApplied, dateField) || !containsString(rightApplied, dateField) {
			return step, true
		}
		left, leftTruncated := querySavedReportSharded(ctx, host, token, reportID, leftChart, source, leftFilter, depth+1)
		if left.Status != "passed" {
			return left, true
		}
		right, rightTruncated := querySavedReportSharded(ctx, host, token, reportID, rightChart, source, rightFilter, depth+1)
		if right.Status != "passed" {
			return right, true
		}
		return combineQuerySteps(step, []titanProbeStep{left, right}), leftTruncated || rightTruncated
	}
	// A single day can still exceed 50k. Split next by a real dimension found in
	// that slice; submission reports use derived program type as the final split.
	for _, dimension := range []string{"region", "client_tier", "program_type"} {
		if (dimension == "region" && f.Region != "") || (dimension == "client_tier" && f.ClientTier != "") || (dimension == "program_type" && f.ProgramType != "") {
			continue
		}
		values := []string{}
		uncovered := false
		for _, row := range canonical {
			value := asString(row[dimension])
			if value == "" || value == "UNKNOWN" || value == "Unknown / Unmapped" {
				uncovered = true
				continue
			}
			values = append(values, value)
		}
		values = uniqueNonEmpty(values)
		if len(values) < 2 {
			continue
		}
		parts := make([]titanProbeStep, 0, len(values))
		truncated := uncovered
		dimensionFailed := false
		for _, value := range values {
			childFilter := f
			switch dimension {
			case "region":
				childFilter.Region = value
			case "client_tier":
				childFilter.ClientTier = value
			case "program_type":
				childFilter.ProgramType = value
			}
			childChart, applied := chartWithBusinessFilters(base, source, childFilter)
			if dimension == "program_type" {
				if !containsString(applied, "type_name") {
					dimensionFailed = true
					break
				}
			} else if !containsString(applied, dimension) {
				dimensionFailed = true
				break
			}
			child, childTruncated := querySavedReportSharded(ctx, host, token, reportID, childChart, source, childFilter, depth+1)
			if child.Status != "passed" {
				dimensionFailed = true
				break
			}
			parts = append(parts, child)
			truncated = truncated || childTruncated
		}
		if !dimensionFailed {
			return combineQuerySteps(step, parts), truncated
		}
		// A rejected dimension split must not turn a valid 50k response into a
		// false success or a total failure. Try the next dimension and, if none
		// works, return the original slice explicitly marked truncated.
	}
	return step, true
}

func combineQuerySteps(template titanProbeStep, parts []titanProbeStep) titanProbeStep {
	combined := template
	combined.Rows = nil
	combined.RowsCount = 0
	combined.Columns = nil
	combined.FieldMap = map[string]string{}
	for _, part := range parts {
		combined.Rows = append(combined.Rows, part.Rows...)
		combined.RowsCount += part.RowsCount
		combined.Columns = uniqueNonEmpty(append(combined.Columns, part.Columns...))
		for column, descriptor := range part.FieldMap {
			combined.FieldMap[column] = descriptor
		}
	}
	if len(combined.Rows) > 0 {
		combined.SampleRows = combined.Rows[0]
	}
	combined.Status = "passed"
	return combined
}

func containsString(values []string, target string) bool {
	for _, value := range values {
		if value == target {
			return true
		}
	}
	return false
}

func filterSupportedBySource(f filterRequest, source sourceConfig) filterRequest {
	out := f
	if !hasDimension(source, "date") {
		out.StartDate, out.EndDate = "", ""
	}
	if !hasDimension(source, "region") {
		out.Region = ""
	}
	if !hasDimension(source, "client_tier") {
		out.ClientTier = ""
	}
	if !hasDimension(source, "program_type") {
		out.ProgramType = ""
	}
	return out
}
