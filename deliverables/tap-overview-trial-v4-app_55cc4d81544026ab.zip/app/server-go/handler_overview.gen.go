// CODE GENERATED FROM app/api/api.yaml BY tools/gen_api.py — DO NOT EDIT
package main

import "net/http"

// 本文件由 IDL 生成，登记 overview 资源的路由契约。
// 业务逻辑写在 handler_overview.go 的 handler 函数里，不要改本文件。
func init() {
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/overview/accounts",
		Summary: "只读查询四Tier账户快照分布，不扫描、不建单、不发送",
		Handler: overviewAccountsList,
		Tags:    []string{"overview"},
		QueryParams: []Param{
			{Name: "end_date", Type: "string", Description: "截止日期 YYYY-MM-DD，默认中国时区今天，向前查找14天"},
			{Name: "region", Type: "string", Description: "源报表 Sales Region，默认Global；不响应Program或Submitter"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status":             "unavailable",
				"reason":             "",
				"requested_end_date": "",
				"data_as_of":         "",
				"region":             "Global",
				"rows":               []any{},
				"queried_at":         "",
				"attempts":           0,
				"diagnostics":        map[string]any{},
				"source": map[string]any{
					"rid":    2891943,
					"sid":    1280034,
					"app_id": 800414,
				},
			},
		},
	})
}
