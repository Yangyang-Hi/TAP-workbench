package main

// Shared casework is separate from per-user Aeolus scan caches. A single AIME
// instance shares this SQLite database. Transactions + revision checks apply to
// both web and Feishu; neither channel owns a second copy of the business state.
import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type cwField struct {
	Key      string `json:"key"`
	Label    string `json:"label"`
	Type     string `json:"type,omitempty"`
	Required bool   `json:"required"`
}
type cwOption struct {
	ID     string    `json:"id"`
	Label  string    `json:"label"`
	Status string    `json:"status"`
	Fields []cwField `json:"fields"`
}
type cwMember struct {
	Username    string `json:"username"`
	DisplayName string `json:"display_name"`
	OpenID      string `json:"open_id"`
}
type cwRecipient struct {
	ID    string `json:"id"`
	Type  string `json:"type"`
	Label string `json:"label"`
	Email string `json:"email,omitempty"`
}
type cwConfig struct {
	Version           string                `json:"version"`
	BusinessConfirmed bool                  `json:"business_confirmed"`
	Operators         []string              `json:"operators"`
	Members           []cwMember            `json:"members"`
	TestRecipients    []cwRecipient         `json:"test_recipients"`
	NotificationMode  string                `json:"notification_mode"`
	AutoSendEnabled   bool                  `json:"auto_send_enabled"`
	Workflow          map[string][]cwOption `json:"workflow"`
}
type cwAudit struct {
	ID        string            `json:"id"`
	At        string            `json:"at"`
	Actor     string            `json:"actor"`
	Source    string            `json:"source"`
	Operation string            `json:"operation"`
	Status    string            `json:"status"`
	Note      string            `json:"note"`
	Fields    map[string]string `json:"fields,omitempty"`
	Version   int               `json:"version"`
}
type cwRecheck struct {
	At        string   `json:"at"`
	Actor     string   `json:"actor"`
	Start     string   `json:"start_date"`
	End       string   `json:"end_date"`
	CCR       *float64 `json:"ccr"`
	NFS       *float64 `json:"nfs"`
	Level     string   `json:"level"`
	Status    string   `json:"status"`
	RequestID string   `json:"request_id"`
	Note      string   `json:"comparability_note"`
}
type cwCase struct {
	ApprovalRequestedBy string            `json:"approval_requested_by"`
	ID                  string            `json:"id"`
	Kind                string            `json:"kind"`
	Version             int               `json:"version"`
	Status              string            `json:"status"`
	Creator             string            `json:"creator"`
	Owner               string            `json:"owner"`
	Reviewer            string            `json:"reviewer"`
	CreatedAt           string            `json:"created_at"`
	UpdatedAt           string            `json:"updated_at"`
	ScanID              string            `json:"scan_id"`
	Row                 wbRow             `json:"row"`
	Window              wbRequest         `json:"window"`
	Rule                wbRule            `json:"rule"`
	WorkflowVersion     string            `json:"workflow_version"`
	Plan                string            `json:"plan"`
	Fields              map[string]string `json:"fields"`
	Note                string            `json:"note"`
	DueDate             string            `json:"due_date"`
	ActionCompleted     bool              `json:"action_completed"`
	EducationCompleted  bool              `json:"education_completed"`
	ReviewRequestedBy   string            `json:"review_requested_by"`
	ClosureReason       string            `json:"closure_reason"`
	ClosedAt            string            `json:"closed_at,omitempty"`
	ClosedBy            string            `json:"closed_by,omitempty"`
	History             []cwAudit         `json:"history"`
	Rechecks            []cwRecheck       `json:"rechecks"`
}
type cwCommand struct {
	ExpectedVersion int               `json:"expected_version"`
	RequestID       string            `json:"request_id"`
	Operation       string            `json:"operation"`
	Plan            string            `json:"plan"`
	Note            string            `json:"note"`
	Fields          map[string]string `json:"fields"`
	Owner           string            `json:"owner"`
	Reviewer        string            `json:"reviewer"`
	ClosureReason   string            `json:"closure_reason"`
}
type cwError struct {
	Code    int
	Message string
}

func (e *cwError) Error() string     { return e.Message }
func cwErr(code int, s string) error { return &cwError{code, s} }
func cwNow() string                  { return time.Now().UTC().Format(time.RFC3339) }
func cwLoadConfig() (cwConfig, error) {
	var c cwConfig
	b, e := os.ReadFile(filepath.Join(pluginDir, "config", "casework.json"))
	if e != nil {
		return c, e
	}
	e = json.Unmarshal(b, &c)
	if e == nil {
		e = cwApplyRuntimeNotification(&c)
	}
	if e == nil && (c.Version == "" || len(c.Workflow["customer"]) == 0) {
		e = errors.New("casework configuration incomplete")
	}
	return c, e
}
func cwSubmitterUsername(raw string) string {
	if email, ok := cwExactEmail(raw); ok {
		return strings.SplitN(email, "@", 2)[0]
	}
	db, err := cwDB()
	if err != nil {
		return ""
	}
	defer db.Close()
	mapping, err := cwReadIdentityMapping(db, raw)
	if err != nil {
		return ""
	}
	return strings.SplitN(mapping.Email, "@", 2)[0]
}
func cwOperator(c cwConfig, user string) bool {
	for _, u := range c.Operators {
		if u == user && u != "" {
			return true
		}
	}
	return false
}
func cwKnown(c cwConfig, user string) bool {
	for _, u := range c.Members {
		if u.Username == user && user != "" {
			return true
		}
	}
	return cwOperator(c, user)
}
func cwCanRead(c cwConfig, a cwCase, user string) bool {
	// Business records are shared among all authenticated App users. Role checks
	// remain on mutations through cwCanHandle/cwOperator.
	return strings.TrimSpace(user) != ""
}
func cwCanHandle(c cwConfig, a cwCase, user string) bool {
	if user == "" {
		return false
	}
	if cwOperator(c, user) || a.Owner == user {
		return true
	}
	db, err := cwDB()
	if err != nil {
		return false
	}
	defer db.Close()
	aliases, reason := wbReadIdentity(db, user)
	if reason != "" {
		return false
	}
	notices, err := cwNotices(db, a.ID)
	if err != nil {
		return false
	}
	return wbRowMatches(a.Row, &a, map[string]string{"only_mine": "true"}, aliases, notices)
}
func cwDB() (*sql.DB, error) {
	dir, e := resolveDataDir()
	if e != nil {
		return nil, e
	}
	if e = os.MkdirAll(dir, 0700); e != nil {
		return nil, e
	}
	db, e := sql.Open("sqlite", filepath.Join(dir, "tap_casework.db"))
	if e != nil {
		return nil, e
	}
	db.SetMaxOpenConns(1)
	_, e = db.Exec(`PRAGMA busy_timeout=500; PRAGMA journal_mode=WAL;
 CREATE TABLE IF NOT EXISTS tap_cases(id TEXT PRIMARY KEY, version INTEGER NOT NULL, body TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS tap_commands(case_id TEXT NOT NULL, request_id TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(case_id,request_id));
 CREATE TABLE IF NOT EXISTS tap_outbox(id TEXT PRIMARY KEY, case_id TEXT NOT NULL, recipient TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL, status TEXT NOT NULL, message_id TEXT NOT NULL DEFAULT '', attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL DEFAULT 0, error TEXT NOT NULL DEFAULT '', notification_mode TEXT NOT NULL DEFAULT '', generation INTEGER NOT NULL DEFAULT 1, idempotency_key TEXT NOT NULL DEFAULT '', original_submitter TEXT NOT NULL DEFAULT '', alert_region TEXT NOT NULL DEFAULT '', mapping_record_id TEXT NOT NULL DEFAULT '', mapping_row INTEGER NOT NULL DEFAULT 0, mapping_version TEXT NOT NULL DEFAULT '', mapping_revision TEXT NOT NULL DEFAULT '', matched_alias TEXT NOT NULL DEFAULT '', target_email TEXT NOT NULL DEFAULT '', resolved_open_id TEXT NOT NULL DEFAULT '', actual_target TEXT NOT NULL DEFAULT '', last_attempt_at TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT 'unknown', mode TEXT NOT NULL DEFAULT '', batch_id TEXT NOT NULL DEFAULT '', rule_version TEXT NOT NULL DEFAULT '', result TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS tap_notification_previews(token_hash TEXT PRIMARY KEY, body TEXT NOT NULL, expires_at INTEGER NOT NULL, consumed INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS tap_schema_migrations(name TEXT PRIMARY KEY, applied_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS tap_identity_mappings(record_id TEXT PRIMARY KEY, region TEXT NOT NULL DEFAULT '', business_name TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', aeolus_name TEXT NOT NULL DEFAULT '', match_status TEXT NOT NULL DEFAULT '', match_note TEXT NOT NULL DEFAULT '', verified_at TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 0, manual_disabled INTEGER NOT NULL DEFAULT 0, sheet_token TEXT NOT NULL DEFAULT '', sheet_id TEXT NOT NULL DEFAULT '', sheet_revision TEXT NOT NULL DEFAULT '', sheet_row INTEGER NOT NULL DEFAULT 0, record_version TEXT NOT NULL DEFAULT '', source_updated_at TEXT NOT NULL DEFAULT '', source_synced_at TEXT NOT NULL DEFAULT '', override_updated_at TEXT NOT NULL DEFAULT '', override_by TEXT NOT NULL DEFAULT '', override_note TEXT NOT NULL DEFAULT '');
 CREATE INDEX IF NOT EXISTS tap_outbox_pending ON tap_outbox(status,next_at);
 CREATE INDEX IF NOT EXISTS tap_outbox_case ON tap_outbox(case_id);`)
	if e != nil {
		db.Close()
		return nil, e
	}
	if e = cwMigrateNotificationSchema(db); e != nil {
		db.Close()
		return nil, e
	}
	return db, nil
}

func cwMigrateNotificationSchema(db *sql.DB) error {
	// Legacy identity rows were manually entered and are not authoritative. Rename
	// that shape once; the next mandatory Sheet refresh repopulates the new table.
	rows, err := db.Query("PRAGMA table_info(tap_identity_mappings)")
	if err != nil {
		return err
	}
	hasRecordID, hasSourceValue := false, false
	for rows.Next() {
		var cid, notnull, pk int
		var name, typ string
		var dflt any
		if err = rows.Scan(&cid, &name, &typ, &notnull, &dflt, &pk); err != nil {
			rows.Close()
			return err
		}
		hasRecordID = hasRecordID || name == "record_id"
		hasSourceValue = hasSourceValue || name == "source_value"
	}
	rows.Close()
	if hasSourceValue && !hasRecordID {
		if _, err = db.Exec("ALTER TABLE tap_identity_mappings RENAME TO tap_identity_mappings_legacy"); err != nil {
			return err
		}
		if _, err = db.Exec(`CREATE TABLE tap_identity_mappings(record_id TEXT PRIMARY KEY, region TEXT NOT NULL DEFAULT '', business_name TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', aeolus_name TEXT NOT NULL DEFAULT '', match_status TEXT NOT NULL DEFAULT '', match_note TEXT NOT NULL DEFAULT '', verified_at TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 0, manual_disabled INTEGER NOT NULL DEFAULT 0, sheet_token TEXT NOT NULL DEFAULT '', sheet_id TEXT NOT NULL DEFAULT '', sheet_revision TEXT NOT NULL DEFAULT '', sheet_row INTEGER NOT NULL DEFAULT 0, record_version TEXT NOT NULL DEFAULT '', source_updated_at TEXT NOT NULL DEFAULT '', source_synced_at TEXT NOT NULL DEFAULT '', override_updated_at TEXT NOT NULL DEFAULT '', override_by TEXT NOT NULL DEFAULT '', override_note TEXT NOT NULL DEFAULT '')`); err != nil {
			return err
		}
	}
	columns := []string{
		"notification_mode TEXT NOT NULL DEFAULT ''", "generation INTEGER NOT NULL DEFAULT 1", "idempotency_key TEXT NOT NULL DEFAULT ''", "original_submitter TEXT NOT NULL DEFAULT ''", "alert_region TEXT NOT NULL DEFAULT ''", "mapping_record_id TEXT NOT NULL DEFAULT ''", "mapping_row INTEGER NOT NULL DEFAULT 0", "mapping_version TEXT NOT NULL DEFAULT ''", "mapping_revision TEXT NOT NULL DEFAULT ''", "matched_alias TEXT NOT NULL DEFAULT ''", "target_email TEXT NOT NULL DEFAULT ''", "resolved_open_id TEXT NOT NULL DEFAULT ''", "actual_target TEXT NOT NULL DEFAULT ''", "last_attempt_at TEXT NOT NULL DEFAULT ''", "bot_fingerprint TEXT NOT NULL DEFAULT ''", "source TEXT NOT NULL DEFAULT 'unknown'", "mode TEXT NOT NULL DEFAULT ''", "batch_id TEXT NOT NULL DEFAULT ''", "rule_version TEXT NOT NULL DEFAULT ''", "result TEXT NOT NULL DEFAULT ''",
	}
	for _, column := range columns {
		if _, e := db.Exec("ALTER TABLE tap_outbox ADD COLUMN " + column); e != nil && !strings.Contains(strings.ToLower(e.Error()), "duplicate column") {
			return e
		}
	}
	_, err = db.Exec("CREATE UNIQUE INDEX IF NOT EXISTS tap_outbox_idempotency ON tap_outbox(idempotency_key) WHERE idempotency_key<>''; CREATE INDEX IF NOT EXISTS tap_identity_aliases ON tap_identity_mappings(business_name,aeolus_name,region)")
	if err != nil {
		return err
	}
	return cwBackfillNotificationDeadlines(db)
}

func cwBackfillNotificationDeadlines(db *sql.DB) error {
	const migration = "backfill_notification_deadline_v1"
	var applied string
	if err := db.QueryRow("SELECT applied_at FROM tap_schema_migrations WHERE name=?", migration).Scan(&applied); err == nil {
		return nil
	} else if !errors.Is(err, sql.ErrNoRows) {
		return err
	}

	rows, err := db.Query("SELECT id,body FROM tap_cases")
	if err != nil {
		return err
	}
	type update struct{ id, body string }
	updates := []update{}
	for rows.Next() {
		var id, body string
		if err = rows.Scan(&id, &body); err != nil {
			rows.Close()
			return err
		}
		var a cwCase
		if err = json.Unmarshal([]byte(body), &a); err != nil {
			rows.Close()
			return fmt.Errorf("decode case %s for deadline backfill: %w", id, err)
		}
		if !cwEnsureNotificationDeadline(&a) {
			continue
		}
		encoded, marshalErr := json.Marshal(a)
		if marshalErr != nil {
			rows.Close()
			return marshalErr
		}
		updates = append(updates, update{id: id, body: string(encoded)})
	}
	if err = rows.Err(); err != nil {
		rows.Close()
		return err
	}
	rows.Close()

	tx, err := db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	for _, item := range updates {
		if _, err = tx.Exec("UPDATE tap_cases SET body=? WHERE id=?", item.body, item.id); err != nil {
			return err
		}
	}
	if _, err = tx.Exec("INSERT INTO tap_schema_migrations(name,applied_at) VALUES(?,?)", migration, cwNow()); err != nil {
		return err
	}
	return tx.Commit()
}
func cwRead(db interface{ QueryRow(string, ...any) *sql.Row }, id string) (cwCase, error) {
	var a cwCase
	var b string
	e := db.QueryRow("SELECT body FROM tap_cases WHERE id=?", id).Scan(&b)
	if e != nil {
		return a, e
	}
	e = json.Unmarshal([]byte(b), &a)
	return a, e
}
func cwSave(tx *sql.Tx, a cwCase, previous int) error {
	b, e := json.Marshal(a)
	if e != nil {
		return e
	}
	r, e := tx.Exec("UPDATE tap_cases SET version=?,body=? WHERE id=? AND version=?", a.Version, string(b), a.ID, previous)
	if e != nil {
		return e
	}
	n, _ := r.RowsAffected()
	if n != 1 {
		return cwErr(409, "记录已更新，请刷新后重试")
	}
	return nil
}
func cwCaseID(j wbJob, row wbRow) string {
	customerID := row.Member.AccountID
	if row.Program == "THT" {
		customerID = row.Member.AdvertiserID
	}
	return "TAP-" + wbKey([]string{row.Program, customerID, row.Member.TicketID, j.Request.Start, j.Request.End, j.Rule.Version})[:24]
}
func cwCreate(j wbJob, row wbRow) (cwCase, error) {
	cfg, e := cwLoadConfig()
	if e != nil {
		return cwCase{}, e
	}
	if !wbMatched(row) || j.Status == "running" {
		return cwCase{}, cwErr(409, "仅将已完成扫描的真实命中加入处置台账")
	}
	repo, e := cwCaseworkRepositoryProvider()
	if e != nil {
		return cwCase{}, e
	}
	owner := j.Principal
	if submitter := cwSubmitterUsername(row.Member.Submitter); submitter != "" {
		owner = submitter
	}
	for _, u := range cfg.Members {
		if u.Username == row.Member.Submitter {
			owner = u.Username
		}
	}
	fields := map[string]string{
		"notification_source": "manual",
		"notification_mode":   "candidate_only",
		"notification_result": "not_requested",
		"rule_version":        j.Rule.Version,
	}
	if j.BatchID != "" {
		fields["batch_id"] = j.BatchID
	}
	if j.Principal == wbSchedulerPrincipal {
		fields["notification_source"] = "auto"
		if row.Level == "critical" {
			fields["candidate_status"] = "auto_candidate"
		} else {
			fields["candidate_status"] = "manual_review"
		}
	}
	a := cwCase{ID: cwCaseID(j, row), Kind: "customer", Version: 1, Status: "open", Creator: j.Principal, Owner: owner, CreatedAt: cwNow(), UpdatedAt: cwNow(), ScanID: j.ID, Row: row, Window: j.Request, Rule: j.Rule, WorkflowVersion: cfg.Version, Fields: fields, History: []cwAudit{}, Rechecks: []cwRecheck{}}
	cwEnsureNotificationDeadline(&a)
	a.History = append(a.History, cwAudit{ID: "create", At: a.CreatedAt, Actor: j.Principal, Source: "scan", Operation: "create", Status: "open", Version: 1, Note: "真实绝对值命中；通知待人工确认"})
	return repo.createCase(context.Background(), a)
}
func cwImportJob(j wbJob) error {
	// Persist incomplete/failed scans for diagnosis, but never turn them into
	// notification candidates. Custom read-model queries do not call this path.
	if j.Status != "ready" || !j.Complete {
		return nil
	}
	failed := 0
	for _, row := range j.Rows {
		if wbMatched(row) {
			if _, e := cwCreate(j, row); e != nil {
				failed++
			}
		}
	}
	if failed > 0 {
		logMsg("[casework] persist scan hits failed (scan remains available)", "plugin")
		return fmt.Errorf("%d条真实命中尚未写入共享处置台账，请从客户详情重试打开共享处置", failed)
	}
	return nil
}
func cwWriteRequestError(w http.ResponseWriter, r *http.Request, caseID string, err error) {
	if !errors.Is(err, sql.ErrNoRows) {
		logMsg(fmt.Sprintf("[casework] request failed request_id=%q principal=%q instance=%q case_id=%q error_type=%T", r.Header.Get("X-Request-Id"), requestUsername(r), appInstanceID, caseID, err), "plugin")
	}
	cwWriteError(w, err)
}

func cwWriteError(w http.ResponseWriter, e error) {
	var ce *cwError
	if errors.As(e, &ce) {
		writeJSON(w, ce.Code, map[string]any{"error": ce.Message})
		return
	}
	if errors.Is(e, sql.ErrNoRows) {
		writeJSON(w, 404, map[string]any{"error": "事件不存在或不可访问"})
		return
	}
	logMsg(fmt.Sprintf("[casework] storage/operation error: %T", e), "plugin")
	writeJSON(w, 503, map[string]any{"error": "处置服务暂不可用，未确认保存，请重试"})
}
func cwValidateFields(opt cwOption, fields map[string]string) error {
	for _, f := range opt.Fields {
		v := strings.TrimSpace(fields[f.Key])
		if f.Required && v == "" {
			return cwErr(400, "请填写："+f.Label)
		}
		if f.Type == "date" && v != "" {
			if _, e := time.Parse("2006-01-02", v); e != nil {
				return cwErr(400, f.Label+"请使用 YYYY-MM-DD")
			}
		}
	}
	return nil
}
func cwValidRCA(value string) bool {
	switch strings.TrimSpace(value) {
	case "客户实锤违规", "预警阈值问题", "无任何风险":
		return true
	default:
		return false
	}
}

func cwApply(a *cwCase, cmd cwCommand, actor, source string, cfg cwConfig) error {
	if !cwCanHandle(cfg, *a, actor) && !((cmd.Operation == "close" || cmd.Operation == "return") && actor != "" && a.Reviewer == actor) {
		return cwErr(403, "仅负责人或运营可处理")
	}
	if a.Status == "closed" && cmd.Operation != "reopen" {
		return cwErr(409, "已关闭事件需由运营重新打开")
	}
	if len(cmd.Note) > 8000 {
		return cwErr(400, "处理记录最多8000字节")
	}
	if len(cmd.Fields) > 30 {
		return cwErr(400, "字段过多")
	}
	for _, v := range cmd.Fields {
		if len(v) > 8000 {
			return cwErr(400, "单个字段过长")
		}
	}
	switch cmd.Operation {
	case "operator_confirm":
		if !cwOperator(cfg, actor) {
			return cwErr(403, "仅运营可确认并转交提报人")
		}
		if a.Status != "open" {
			return cwErr(409, "仅待运营确认事件可转交提报人")
		}
		a.Status = "processing"
		if strings.TrimSpace(cmd.Owner) != "" {
			if !cwKnown(cfg, cmd.Owner) && cwSubmitterUsername(a.Row.Member.Submitter) != cmd.Owner {
				return cwErr(400, "提报人身份尚未完成权威映射")
			}
			a.Owner = cmd.Owner
		}
	case "submitter_complete":
		if actor != a.Owner {
			return cwErr(403, "仅当前提报人可提交处理结果")
		}
		if a.Status != "processing" {
			return cwErr(409, "仅待提报人处理事件可提交完成")
		}
		if strings.TrimSpace(cmd.Fields["evidence"]) == "" {
			return cwErr(400, "请提供处理凭证")
		}
		if a.Fields == nil {
			a.Fields = map[string]string{}
		}
		for key, value := range cmd.Fields {
			a.Fields[key] = value
		}
		a.ActionCompleted = true
		a.Status = "pending_review"
		a.ReviewRequestedBy = actor
	case "accept":
		if a.Status != "open" {
			return cwErr(409, "当前状态无法接单")
		}
		a.Status = "processing"
	case "assign":
		if !cwOperator(cfg, actor) {
			return cwErr(403, "分派需要运营角色")
		}
		if !cwKnown(cfg, cmd.Owner) || (cmd.Reviewer != "" && !cwKnown(cfg, cmd.Reviewer)) {
			return cwErr(400, "请先配置负责人和复核人的身份")
		}
		a.Owner = cmd.Owner
		a.Reviewer = cmd.Reviewer
	case "plan":
		if a.Status == "pending_review" || a.Status == "pending_approval" {
			return cwErr(409, "待复核或待审批时，请先退回再修改方案")
		}
		var opt *cwOption
		for _, v := range cfg.Workflow[a.Kind] {
			v := v
			if v.ID == cmd.Plan {
				opt = &v
				break
			}
		}
		if opt == nil {
			return cwErr(400, "该预警类型不支持所选动作")
		}
		if e := cwValidateFields(*opt, cmd.Fields); e != nil {
			return e
		}
		if !cwValidRCA(cmd.Fields["rca"]) {
			return cwErr(400, "请选择有效 RCA；RCA 与最终动作独立记录")
		}
		a.Plan = opt.ID
		a.Fields = cmd.Fields
		a.Status = "closed"
		a.ClosedAt = cwNow()
		a.ClosedBy = actor
		a.ClosureReason = "direct_disposition"
		a.DueDate = cmd.Fields["due_date"]
		a.ActionCompleted = true
		a.EducationCompleted = false // TAP removal is not a customer education record.
	case "complete":
		if a.Status != "processing" && a.Status != "observing" {
			return cwErr(409, "当前状态无法提交完成")
		}
		if a.Plan == "" {
			return cwErr(400, "请先选择并保存处置方案")
		}
		if strings.TrimSpace(cmd.Fields["evidence"]) == "" {
			return cwErr(400, "请提供完成凭证")
		}
		if a.Fields == nil {
			a.Fields = map[string]string{}
		}
		a.Fields["completion_evidence"] = cmd.Fields["evidence"]
		a.ActionCompleted = true
		a.EducationCompleted = a.Plan == "communicate"
		a.Status = "pending_review"
		a.ReviewRequestedBy = actor
	case "approve":
		if !cwOperator(cfg, actor) || actor == a.Owner || actor == a.ApprovalRequestedBy {
			return cwErr(403, "需要另一名运营审批")
		}
		if a.Status != "pending_approval" {
			return cwErr(409, "当前不是待审批")
		}
		a.Status = "processing"
		if a.Fields == nil {
			a.Fields = map[string]string{}
		}
		a.Fields["approval_record"] = actor + " " + cwNow() + " " + cmd.Note
	case "return":
		if !cwOperator(cfg, actor) && a.Reviewer != actor {
			return cwErr(403, "需要复核角色")
		}
		if a.Status != "pending_review" && a.Status != "pending_approval" {
			return cwErr(409, "当前没有待复核事项")
		}
		a.Status = "processing"
	case "close":
		testModeSelfReview := cfg.NotificationMode == "test" && !cfg.AutoSendEnabled && cwOperator(cfg, actor) && actor == a.ReviewRequestedBy
		if (!cwOperator(cfg, actor) && a.Reviewer != actor) || (actor == a.ReviewRequestedBy && !testModeSelfReview) {
			return cwErr(403, "关闭需要另一名运营或指定复核人确认；仅 test 模式且 auto_send=false 允许当前测试用户完成闭环")
		}
		if a.Status != "pending_review" {
			return cwErr(409, "请先提交完成或无需处置并进入待复核")
		}
		if strings.TrimSpace(cmd.Fields["evidence"]) == "" {
			return cwErr(400, "关闭必须填写复核依据")
		}
		switch cmd.ClosureReason {
		case "risk_recovered":
			if len(a.Rechecks) == 0 {
				return cwErr(409, "尚无真实指标复查")
			}
			v := a.Rechecks[len(a.Rechecks)-1]
			if v.Status != "success" || v.Level != "normal" || v.CCR == nil || v.NFS == nil {
				return cwErr(409, "最新真实复查未确认恢复")
			}
			if v.Start <= a.Window.End {
				return cwErr(409, "风险恢复需要报警指标窗口结束之后的独立复查，不能用重叠QTD窗口")
			}
			for _, event := range a.History {
				at, parseErr := time.Parse(time.RFC3339, event.At)
				if (event.Operation == "plan" || event.Operation == "complete") && parseErr == nil && v.Start < at.In(cwLocation()).Format("2006-01-02") {
					return cwErr(409, "风险恢复复查必须覆盖处置后的窗口")
				}
			}
		case "false_positive", "not_applicable", "policy_exception":
		default:
			return cwErr(400, "请选择关闭依据")
		}
		a.Status = "closed"
		a.ClosedAt = cwNow()
		a.ClosedBy = actor
		a.ClosureReason = cmd.ClosureReason
	case "reopen":
		if !cwOperator(cfg, actor) || a.Status != "closed" {
			return cwErr(403, "仅运营可以重新打开已关闭事件")
		}
		a.Status = "processing"
		a.ClosedAt = ""
		a.ClosedBy = ""
		a.ClosureReason = ""
	default:
		return cwErr(400, "未知处置动作")
	}
	a.Version++
	a.UpdatedAt = cwNow()
	a.Note = cmd.Note
	a.History = append(a.History, cwAudit{ID: cmd.RequestID, At: a.UpdatedAt, Actor: actor, Source: source, Operation: cmd.Operation, Status: a.Status, Note: cmd.Note, Fields: cmd.Fields, Version: a.Version})
	return nil
}
func cwMutate(id string, cmd cwCommand, actor, source string) (cwCase, error) {
	var empty cwCase
	if cmd.RequestID == "" || len(cmd.RequestID) > 200 {
		return empty, cwErr(400, "需要幂等 request_id")
	}
	cfg, err := cwLoadConfig()
	if err != nil {
		return empty, err
	}
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		return empty, err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	a, err := repo.caseByID(ctx, id)
	if err != nil {
		return empty, err
	}
	if !cwCanRead(cfg, a, actor) {
		return empty, cwErr(403, "无法访问该事件")
	}
	fingerprint := wbKey(struct {
		Actor   string
		Source  string
		Command cwCommand
	}{actor, source, cmd})
	if prior, ok, readErr := repo.command(ctx, id, cmd.RequestID); readErr != nil {
		return empty, readErr
	} else if ok {
		if prior != fingerprint {
			return a, cwErr(409, "幂等键已用于不同操作，请刷新后重新提交")
		}
		return a, nil
	}
	if cmd.ExpectedVersion != a.Version {
		return a, cwErr(409, "记录已更新，请刷新后重试")
	}
	previous := a.Version
	if err = cwApply(&a, cmd, actor, source, cfg); err != nil {
		return a, err
	}
	if err = repo.saveCaseCAS(ctx, a, previous); err != nil {
		return a, err
	}
	if err = repo.putCommand(ctx, id, cmd.RequestID, fingerprint, a.Version); err != nil {
		// The case CAS already committed. A retry observes the new version and must not
		// repeat the command; surface an explicit availability error for reconciliation.
		return a, fmt.Errorf("case saved but command receipt failed: %w", err)
	}
	if err = repo.queueUpdates(ctx, a); err != nil {
		return a, fmt.Errorf("case saved but notification update queue failed: %w", err)
	}
	return a, nil
}
