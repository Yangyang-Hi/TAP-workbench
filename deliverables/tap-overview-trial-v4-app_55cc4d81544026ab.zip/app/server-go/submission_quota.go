package main

import (
	"bytes"
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type quotaBaseline struct {
	Version  int      `json:"version"`
	Status   string   `json:"status"`
	Period   string   `json:"period"`
	Source   string   `json:"source"`
	Warnings []string `json:"warnings"`
	Regions  []struct {
		Region string `json:"region"`
		ET     int    `json:"ET"`
		ST     int    `json:"ST"`
	} `json:"regions"`
}

type submissionMetric struct {
	ID, TicketID, Region, Date            string
	Submitters, AccountIDs, AdvertiserIDs []string
}

type stMetric struct{ Region, Brand, AccountID string }

type quotaSourceResult struct {
	Status       string
	AsOf         string
	ET           []submissionMetric
	THT          []submissionMetric
	ST           []stMetric
	STSnapshot   map[string]any
	SourceStatus map[string]string
	Diagnostics  map[string]map[string]any
	Errors       map[string]string
	Error        string
}

type quotaAeolusResult struct {
	Rows       []submissionMetric
	Diagnostic map[string]any
}

var loadQuotaSources = loadQuotaSourcesLive

func quotaStatus(ratio *float64) string {
	if ratio == nil {
		return "unavailable"
	}
	switch {
	case *ratio < 60:
		return "green"
	case *ratio < 80:
		return "yellow"
	case *ratio < 100:
		return "orange"
	default:
		return "red"
	}
}

const quotaThresholdVersion = "quota-tier-v3-et-inclusive-st-exclusive"

func quotaRatio(used, denominator int) *float64 {
	if denominator <= 0 {
		return nil
	}
	v := float64(used) * 100 / float64(denominator)
	return &v
}

func quotaAlertTriggered(tier string, ratio *float64) bool {
	if ratio == nil {
		return false
	}
	switch strings.ToUpper(strings.TrimSpace(tier)) {
	case "ET":
		return *ratio >= 100
	case "ST":
		return *ratio > 100
	default:
		return false
	}
}

func loadQuotaBaseline() (quotaBaseline, error) {
	var baseline quotaBaseline
	raw, err := os.ReadFile(filepath.Join(pluginDir, "config", "quota_baseline.json"))
	if err != nil {
		return baseline, err
	}
	if err = json.Unmarshal(raw, &baseline); err != nil {
		return baseline, err
	}
	return baseline, nil
}

func loadQuotaSourcesLive(ctx context.Context, r *http.Request, quarter, start, end string) quotaSourceResult {
	type sourceAnswer struct {
		name string
		rows []submissionMetric
		st   []stMetric
		asOf string
		meta map[string]any
		diag map[string]any
		err  error
	}
	answers := make(chan sourceAnswer, 3)
	runCtx, cancel := context.WithTimeout(ctx, 45*time.Second)
	defer cancel()
	go func() {
		result, err := quotaAeolusRows(runCtx, r, "et_quota_tickets", "ET", start, end)
		answers <- sourceAnswer{name: "ET", rows: result.Rows, diag: result.Diagnostic, err: err}
	}()
	go func() {
		result, err := quotaAeolusRows(runCtx, r, "tht_ticket_details", "THT", start, end)
		answers <- sourceAnswer{name: "THT", rows: result.Rows, diag: result.Diagnostic, err: err}
	}()
	go func() {
		rows, meta, err := loadSTFromSnapshot(quarter)
		asOf, _ := meta["synced_at"].(string)
		answers <- sourceAnswer{name: "ST", st: rows, asOf: asOf, meta: meta, err: err}
	}()

	out := quotaSourceResult{Status: "available", SourceStatus: map[string]string{"ET": "pending", "THT": "pending", "ST": "pending"}, Diagnostics: map[string]map[string]any{}, Errors: map[string]string{}}
	for received := 0; received < 3; received++ {
		select {
		case answer := <-answers:
			if answer.name == "ST" {
				out.STSnapshot = answer.meta
			}
			if answer.diag != nil {
				out.Diagnostics[answer.name] = answer.diag
			}
			if answer.err != nil {
				out.Status = "partial"
				out.SourceStatus[answer.name] = "failed"
				out.Errors[answer.name] = answer.err.Error()
				out.Error = strings.Trim(strings.TrimSpace(out.Error)+"; "+answer.name+": "+answer.err.Error(), "; ")
				continue
			}
			out.SourceStatus[answer.name] = "available"
			switch answer.name {
			case "ET":
				out.ET = answer.rows
			case "THT":
				out.THT = answer.rows
			case "ST":
				out.ST, out.AsOf, out.STSnapshot = answer.st, answer.asOf, answer.meta
			}
		case <-runCtx.Done():
			out.Status = "partial"
			for name, status := range out.SourceStatus {
				if status == "pending" {
					out.SourceStatus[name] = "failed"
					out.Errors[name] = runCtx.Err().Error()
				}
			}
			out.Error = strings.Trim(strings.TrimSpace(out.Error)+"; pending sources: "+runCtx.Err().Error(), "; ")
			return out
		}
	}
	return out
}

func quotaAeolusRows(ctx context.Context, original *http.Request, source, program, start, end string) (quotaAeolusResult, error) {
	result := quotaAeolusResult{Diagnostic: map[string]any{"source": source, "business_window": map[string]string{"start_date": start, "end_date": end}, "effective_filters": quotaExpectedFilters(program, start, end), "complete": false}}
	var sourceSpec sourceConfig
	if cfg, err := loadDataSourceConfig(); err == nil {
		if spec, ok := cfg.Sources[source]; ok {
			sourceSpec = spec
			result.Diagnostic["rid"], result.Diagnostic["sid"], result.Diagnostic["app_id"] = spec.RID, spec.SID, spec.AppID
			result.Diagnostic["id_dimension"] = spec.Identity.IDDimension
		}
	}
	q := original.URL.Query()
	q.Set("start_date", start)
	q.Set("end_date", end)
	q.Set("program_type", program)
	clone := original.Clone(ctx)
	clone.Header.Set("X-TAP-Quota-Mode", "1")
	clone.URL.RawQuery = q.Encode()
	probe, err := runTitanVQSProbe(ctx, clone, source)
	if err != nil {
		result.Diagnostic["error_code"], result.Diagnostic["error"] = "probe_error", err.Error()
		return result, err
	}
	result.Diagnostic["endpoint"] = probe["execution_endpoint"]
	result.Diagnostic["query_id"] = probe["requestId"]
	result.Diagnostic["request_id"] = probe["requestId"]
	result.Diagnostic["log_id"] = probe["logId"]
	result.Diagnostic["source_returned_rows"] = probe["rowCount"]
	result.Diagnostic["source_columns"] = probe["columns"]
	if step, ok := probe["query_result"].(titanProbeStep); ok {
		result.Diagnostic["http_status"] = step.HTTPStatus
		result.Diagnostic["business_code"] = step.GlueCode
		result.Diagnostic["business_message"] = step.GlueMessage
		result.Diagnostic["response_preview"] = step.ResponsePreview
	}
	result.Diagnostic["effective_filters"] = probe["effective_filters"]
	result.Diagnostic["partition"] = probe["partition"]
	finalResultProven := proveExactMembershipFilter(sourceSpec, "final_result", "APPROVE", probe["effective_filters"])
	etTypeProven := program != "ET" || proveExactMembershipFilter(sourceSpec, "type_name", "Emerging trust apply", probe["effective_filters"])
	thtTypeProven := program != "THT" || proveExactMembershipFilter(sourceSpec, "type_name", "Protection program", probe["effective_filters"])
	thtProgramProven := program != "THT" || proveExactMembershipFilter(sourceSpec, "protection_program_name", thtProgram, probe["effective_filters"])
	result.Diagnostic["filter_contract"] = map[string]bool{"final_result": finalResultProven, "type_name": etTypeProven && thtTypeProven, "protection_program_name": thtProgramProven}
	if asString(probe["status"]) != "ok" {
		message := probeFailure(probe)
		result.Diagnostic["error_code"], result.Diagnostic["error"] = asString(probe["status"]), message
		return result, fmt.Errorf("Aeolus query %s (%s)", asString(probe["status"]), message)
	}
	rows, ok := probe["business_rows"].([]map[string]any)
	if !ok {
		result.Diagnostic["error_code"] = "missing_business_rows"
		return result, errors.New("Aeolus response missing business_rows")
	}
	latestPDate := ""
	observed := map[string]map[string]bool{"type_name": {}, "final_result": {}, "protection_program_name": {}}
	rowsWithTicket := 0
	for _, row := range rows {
		if strings.TrimSpace(asString(row["ticket_id"])) != "" {
			rowsWithTicket++
		}
		for _, key := range []string{"type_name", "final_result", "protection_program_name"} {
			if value := strings.TrimSpace(asString(row[key])); value != "" {
				observed[key][value] = true
			}
		}
		if p := dateOnly(asString(row["p_date"])); p > latestPDate {
			latestPDate = p
		}
	}
	result.Diagnostic["rows_with_ticket_id"] = rowsWithTicket
	result.Diagnostic["observed_filter_values"] = map[string]any{"type_name": sortedKeys(observed["type_name"]), "final_result": sortedKeys(observed["final_result"]), "protection_program_name": sortedKeys(observed["protection_program_name"])}
	if latestPDate != "" {
		result.Diagnostic["partition"] = latestPDate
	}
	out := make([]submissionMetric, 0, len(rows))
	for _, row := range rows {
		if latestPDate != "" && dateOnly(asString(row["p_date"])) != latestPDate {
			continue
		}
		rowType := strings.TrimSpace(asString(row["type_name"]))
		rowFinal := strings.TrimSpace(asString(row["final_result"]))
		rowProgram := strings.TrimSpace(asString(row["protection_program_name"]))
		approved := strings.EqualFold(rowFinal, "APPROVE") || (rowFinal == "" && finalResultProven)
		if program == "ET" && !(approved && (rowType == "Emerging trust apply" || (rowType == "" && etTypeProven))) {
			continue
		}
		if program == "THT" && !(approved && (rowType == "Protection program" || (rowType == "" && thtTypeProven)) && (rowProgram == thtProgram || (rowProgram == "" && thtProgramProven))) {
			continue
		}
		ticketID := strings.TrimSpace(asString(row["ticket_id"]))
		if program == "ET" && (ticketID == "" || strings.TrimSpace(asString(row["account_id"])) == "") {
			result.Diagnostic["error_code"] = "missing_et_identity"
			result.Diagnostic["error"] = "Approved ET row missing account_id or ticket_id; account quota and ticket counts cannot be verified"
			return result, errors.New(asString(result.Diagnostic["error"]))
		}
		if ticketID == "" {
			continue
		}
		metric := submissionMetric{ID: ticketID, TicketID: ticketID, Region: strings.TrimSpace(asString(row["region"])), Date: dateOnly(asString(row["create_date"])), Submitters: uniqueNonEmpty([]string{asString(row["submitter"])}), AccountIDs: uniqueNonEmpty([]string{asString(row["account_id"])}), AdvertiserIDs: uniqueNonEmpty([]string{asString(row["advertiser_id"])})}
		for _, key := range []string{"linked_account_ids", "account_ids"} {
			metric.AccountIDs = addUnique(metric.AccountIDs, normalizeArrayScalar(asString(row[key])))
		}
		for _, key := range []string{"linked_advertiser_ids", "advertiser_ids"} {
			metric.AdvertiserIDs = addUnique(metric.AdvertiserIDs, normalizeArrayScalar(asString(row[key])))
		}
		if !exactMember(metric.Submitters, q.Get("submitter")) || !exactMember(metric.AccountIDs, q.Get("account_id")) || !exactMember(metric.AdvertiserIDs, q.Get("advertiser_id")) {
			continue
		}
		if region := strings.TrimSpace(q.Get("region")); region != "" && region != "all" && metric.Region != region {
			continue
		}
		out = append(out, metric)
	}
	result.Rows = out
	regionCounts := map[string]int{}
	tickets, customers := map[string]bool{}, map[string]bool{}
	for _, row := range out {
		region := strings.TrimSpace(row.Region)
		if region == "" {
			region = "Unknown / Unmapped"
		}
		if !tickets[row.TicketID] {
			regionCounts[region]++
			tickets[row.TicketID] = true
		}
		ids := row.AdvertiserIDs
		if program == "ET" {
			ids = row.AccountIDs
		}
		for _, id := range ids {
			if id != "" {
				customers[id] = true
			}
		}
	}
	result.Diagnostic["deduplicated_ticket_count"] = len(tickets)
	result.Diagnostic["deduplicated_customer_count"] = len(customers)
	result.Diagnostic["region_summary"] = regionCounts
	result.Diagnostic["complete"] = true
	return result, nil
}

func quotaExpectedFilters(program, start, end string) map[string]any {
	filters := map[string]any{"create_date": []string{start, end}, "final_result": "APPROVE"}
	if program == "ET" {
		filters["type_name"] = "Emerging trust apply"
	} else {
		filters["type_name"], filters["protection_program_name"] = "Protection program", thtProgram
	}
	return filters
}

func probeFailure(probe map[string]any) string {
	if q, ok := probe["query_result"].(titanProbeStep); ok && q.ErrorMessage != "" {
		return q.ErrorMessage
	}
	return "no successful result"
}

func dateOnly(value string) string {
	if len(value) >= 10 {
		return value[:10]
	}
	return value
}

func loadSTFromLark(ctx context.Context, quarter string) ([]stMetric, string, error) {
	wikiURL := strings.TrimSpace(os.Getenv("TAP_ST_WIKI_SHEET_URL"))
	if wikiURL == "" {
		wikiURL = "https://bytedance.larkoffice.com/wiki/BvySwO6zuiH9IEkzsU8c9pksnxc?sheet=wKgK4I"
	}
	title := map[string]string{"Q3": "2026 Q3 TAP 3.0 ST Application", "Q4": "2026 Q4 ST Application"}[quarter]
	// ST sheets currently use columns A:G. Read one bounded complete range so an empty
	// physical tail cannot make the request loop through thousands of blank rows.
	cellRange := "A1:G5000"
	readCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	cmd := exec.CommandContext(readCtx, "lark-cli", "sheets", "+csv-get", "--url", wikiURL, "--sheet-name", title, "--range", cellRange, "--include-row-prefix=false", "--max-chars", "500000")
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	raw, err := cmd.Output()
	if err != nil {
		return nil, "", fmt.Errorf("unavailable: lark-cli range %s read failed: %s", cellRange, strings.TrimSpace(stderr.String()))
	}
	text := extractCSVText(raw)
	if strings.TrimSpace(text) == "" {
		return nil, "", errors.New("unavailable: lark-cli returned no CSV payload")
	}
	records, err := csv.NewReader(strings.NewReader(text)).ReadAll()
	if err != nil {
		return nil, "", fmt.Errorf("unavailable: invalid Sheet CSV range %s: %w", cellRange, err)
	}
	if len(records) == 0 {
		return nil, "", errors.New("unavailable: lark-cli returned no CSV records")
	}
	headerRow := 0
	if quarter == "Q4" {
		headerRow = 1
	}
	if len(records) <= headerRow {
		return nil, "", errors.New("unavailable: Sheet does not contain configured header row")
	}
	regionCol, brandCol := -1, -1
	for i, value := range records[headerRow] {
		switch strings.TrimSpace(value) {
		case "Sales Region":
			regionCol = i
		case "Brand Name":
			brandCol = i
		}
	}
	if regionCol < 0 || brandCol < 0 {
		return nil, "", errors.New("unavailable: Sheet missing Sales Region or Brand Name column")
	}
	seen := map[string]bool{}
	out := []stMetric{}
	for _, row := range records[headerRow+1:] {
		if regionCol >= len(row) || brandCol >= len(row) {
			continue
		}
		region, brand := strings.TrimSpace(row[regionCol]), strings.TrimSpace(row[brandCol])
		key := region + "\x1f" + brand
		if region == "" || brand == "" || seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, stMetric{Region: region, Brand: brand})
	}
	return out, time.Now().UTC().Format(time.RFC3339), nil
}

func extractCSVText(raw []byte) string {
	var value any
	if json.Unmarshal(raw, &value) != nil {
		return string(raw)
	}
	var walk func(any) string
	walk = func(v any) string {
		switch x := v.(type) {
		case string:
			if strings.Contains(x, "Sales Region") || strings.Contains(x, "Brand Name") {
				return x
			}
		case map[string]any:
			for _, key := range []string{"csv", "content", "data", "value"} {
				if got := walk(x[key]); got != "" {
					return got
				}
			}
			for _, child := range x {
				if got := walk(child); got != "" {
					return got
				}
			}
		case []any:
			for _, child := range x {
				if got := walk(child); got != "" {
					return got
				}
			}
		}
		return ""
	}
	return walk(value)
}

func countTicketsForRegion(rows []submissionMetric, region string) int {
	seen := map[string]bool{}
	for _, r := range rows {
		rr := r.Region
		if rr == "" {
			rr = "Unknown / Unmapped"
		}
		if rr == region && r.TicketID != "" {
			seen[r.TicketID] = true
		}
	}
	return len(seen)
}
func nonEmptyErrors(s string) []string {
	if strings.TrimSpace(s) == "" {
		return []string{}
	}
	return []string{strings.Trim(strings.TrimSpace(s), ";")}
}

func weeklyQuota(et, tht []submissionMetric) []map[string]any {
	weeks := map[string]bool{}
	weekOf := func(s string) string {
		t, err := time.Parse("2006-01-02", s)
		if err != nil {
			return ""
		}
		wd := int(t.Weekday())
		if wd == 0 {
			wd = 7
		}
		return t.AddDate(0, 0, 1-wd).Format("2006-01-02")
	}
	for _, rows := range [][]submissionMetric{et, tht} {
		for _, r := range rows {
			if w := weekOf(r.Date); w != "" {
				weeks[w] = true
			}
		}
	}
	keys := []string{}
	for w := range weeks {
		keys = append(keys, w)
	}
	sort.Strings(keys)
	out := []map[string]any{}
	for _, w := range keys {
		es, ts := map[string]bool{}, map[string]bool{}
		for _, r := range et {
			if weekOf(r.Date) <= w && weekOf(r.Date) != "" {
				for _, id := range r.AccountIDs {
					if id = strings.TrimSpace(id); id != "" {
						es[id] = true
					}
				}
			}
		}
		for _, r := range tht {
			if weekOf(r.Date) <= w && weekOf(r.Date) != "" {
				ids := r.AdvertiserIDs
				if len(ids) == 0 {
					ids = []string{r.ID}
				}
				for _, id := range ids {
					if id != "" {
						ts[id] = true
					}
				}
			}
		}
		out = append(out, map[string]any{"week_start": w, "et_qtd": len(es), "tht_qtd": len(ts)})
	}
	return out
}

func sortedKeys(values map[string]bool) []string {
	out := make([]string, 0, len(values))
	for value := range values {
		out = append(out, value)
	}
	sort.Strings(out)
	return out
}

func aggregateQuota(baseline quotaBaseline, source quotaSourceResult, quarter string) map[string]any {
	failed := func(name string) bool { return source.SourceStatus != nil && source.SourceStatus[name] == "failed" }
	set := func(m map[string]map[string]bool, region, key string) {
		region, key = strings.TrimSpace(region), strings.TrimSpace(key)
		if region == "" {
			region = "Unknown / Unmapped"
		}
		if key == "" {
			return
		}
		if m[region] == nil {
			m[region] = map[string]bool{}
		}
		m[region][key] = true
	}
	etTickets, etAccounts := map[string]map[string]bool{}, map[string]map[string]bool{}
	thtAdvertisers, thtTickets := map[string]map[string]bool{}, map[string]map[string]bool{}
	stAccounts, stBrands := map[string]map[string]bool{}, map[string]map[string]bool{}
	globalETTickets, globalETAccounts := map[string]bool{}, map[string]bool{}
	globalTHTAdvertisers, globalTHTTickets := map[string]bool{}, map[string]bool{}
	globalSTAccounts, globalSTBrands := map[string]bool{}, map[string]bool{}
	for _, x := range source.ET {
		set(etTickets, x.Region, x.TicketID)
		if x.TicketID != "" {
			globalETTickets[x.TicketID] = true
		}
		for _, id := range x.AccountIDs {
			set(etAccounts, x.Region, id)
			if id != "" {
				globalETAccounts[id] = true
			}
		}
	}
	for _, x := range source.THT {
		set(thtTickets, x.Region, x.TicketID)
		if x.TicketID != "" {
			globalTHTTickets[x.TicketID] = true
		}
		for _, id := range x.AdvertiserIDs {
			set(thtAdvertisers, x.Region, id)
			if id != "" {
				globalTHTAdvertisers[id] = true
			}
		}
	}
	for _, x := range source.ST {
		set(stAccounts, x.Region, x.AccountID)
		if x.AccountID != "" {
			globalSTAccounts[x.AccountID] = true
		}
		set(stBrands, x.Region, x.Brand)
		if x.Brand != "" {
			globalSTBrands[x.Brand] = true
		}
	}
	quotaByRegion := map[string]struct{ ET, ST int }{}
	regions := map[string]bool{}
	for _, q := range baseline.Regions {
		quotaByRegion[q.Region] = struct{ ET, ST int }{q.ET, q.ST}
		regions[q.Region] = true
	}
	for _, maps := range []map[string]map[string]bool{etTickets, etAccounts, thtAdvertisers, thtTickets, stAccounts, stBrands} {
		for region := range maps {
			regions[region] = true
		}
	}
	names := make([]string, 0, len(regions))
	for name := range regions {
		names = append(names, name)
	}
	sort.Strings(names)
	baselineConfirmed := baseline.Status == "" || (strings.EqualFold(baseline.Status, "confirmed") && (baseline.Period == "" || strings.Contains(strings.ToUpper(baseline.Period), strings.ToUpper(quarter))))
	ratio := func(used, quota int, valid bool) *float64 {
		if !valid || quota <= 0 {
			return nil
		}
		v := float64(used) * 100 / float64(quota)
		return &v
	}
	rows := make([]map[string]any, 0, len(names))
	totalETQuota, totalSTQuota, regionalETAccounts := 0, 0, 0
	for _, region := range names {
		q, hasQuota := quotaByRegion[region]
		etUsed := len(etAccounts[region])
		etAccountCount := len(etAccounts[region])
		thtCustomerCount := len(thtAdvertisers[region])
		thtTicketCount := len(thtTickets[region])
		stAccountCount := len(stAccounts[region])
		stBrandCount := len(stBrands[region])
		quotaValid := baselineConfirmed && hasQuota
		etRate := ratio(etUsed, q.ET, quotaValid && !failed("ET"))
		etRemaining, etExceeded := any(nil), any(nil)
		if etRate != nil {
			etRemaining = maxInt(q.ET-etUsed, 0)
			etExceeded = maxInt(etUsed-q.ET, 0)
		}
		stRate := ratio(stBrandCount, q.ST, quotaValid && !failed("ST"))
		stRemaining, stExceeded := any(nil), any(nil)
		if stRate != nil {
			stRemaining = maxInt(q.ST-stBrandCount, 0)
			stExceeded = maxInt(stBrandCount-q.ST, 0)
		}
		row := map[string]any{"region": region, "tier": "ET", "regional_poc": nil, "notification_status": "not_triggered", "et": map[string]any{"used": quotaCount(etUsed, !failed("ET")), "ticket_count": quotaCount(len(etTickets[region]), !failed("ET")), "account_count": quotaCount(etAccountCount, !failed("ET")), "quota": nullableQuota(q.ET, quotaValid), "ratio": nullableRate(etRate), "remaining": etRemaining, "exceeded": etExceeded, "metric_level": "distinct_account_id", "status": quotaStatus(etRate), "complete": !failed("ET"), "alert": quotaAlertTriggered("ET", etRate)}, "st": map[string]any{"used": quotaCount(stBrandCount, !failed("ST")), "account_count": quotaCount(stAccountCount, !failed("ST")), "brand_count": quotaCount(stBrandCount, !failed("ST")), "quota": nullableQuota(q.ST, quotaValid), "ratio": nullableRate(stRate), "remaining": stRemaining, "exceeded": stExceeded, "metric_level": "distinct_brand_name", "status": quotaStatus(stRate), "complete": !failed("ST"), "alert": quotaAlertTriggered("ST", stRate)}, "tht": map[string]any{"used": quotaCount(thtCustomerCount, !failed("THT")), "distinct_advertiser_count": quotaCount(thtCustomerCount, !failed("THT")), "approved_ticket_count": quotaCount(thtTicketCount, !failed("THT")), "quota": nil, "ratio": nil, "remaining": nil, "metric_level": "distinct_advertiser_id", "status": "no_denominator", "complete": !failed("THT")}}
		if quotaAlertTriggered("ET", etRate) {
			row["notification_status"] = "pending_regional_poc"
		}
		rows = append(rows, row)
		if quotaValid {
			totalETQuota += q.ET
			totalSTQuota += q.ST
		}
		regionalETAccounts += etUsed
	}
	globalETRate := ratio(len(globalETAccounts), totalETQuota, baselineConfirmed && !failed("ET"))
	globalETRemaining, globalETExceeded := any(nil), any(nil)
	if globalETRate != nil {
		globalETRemaining = maxInt(totalETQuota-len(globalETAccounts), 0)
		globalETExceeded = maxInt(len(globalETAccounts)-totalETQuota, 0)
	}
	status := "available"
	if failed("ET") || failed("THT") || failed("ST") {
		status = "partial"
	}
	globalSTRate := ratio(len(globalSTBrands), totalSTQuota, baselineConfirmed && !failed("ST"))
	globalSTRemaining, globalSTExceeded := any(nil), any(nil)
	if globalSTRate != nil {
		globalSTRemaining = maxInt(totalSTQuota-len(globalSTBrands), 0)
		globalSTExceeded = maxInt(len(globalSTBrands)-totalSTQuota, 0)
	}
	result := map[string]any{"status": status, "quarter": quarter, "as_of": map[string]any{"submission": source.AsOf}, "quota_contract": map[string]any{"version": baseline.Version, "status": baseline.Status, "period": baseline.Period, "source": baseline.Source, "confirmed_for_quarter": baselineConfirmed}, "global": map[string]any{"et": map[string]any{"used": quotaCount(len(globalETAccounts), !failed("ET")), "ticket_count": quotaCount(len(globalETTickets), !failed("ET")), "account_count": quotaCount(len(globalETAccounts), !failed("ET")), "quota": nullableQuota(totalETQuota, baselineConfirmed), "ratio": nullableRate(globalETRate), "remaining": globalETRemaining, "exceeded": globalETExceeded, "regional_sum": regionalETAccounts, "cross_region_duplicate_account_count": regionalETAccounts - len(globalETAccounts), "metric_level": "distinct_account_id", "status": quotaStatus(globalETRate), "complete": !failed("ET")}, "st": map[string]any{"used": quotaCount(len(globalSTBrands), !failed("ST")), "account_count": quotaCount(len(globalSTAccounts), !failed("ST")), "brand_count": quotaCount(len(globalSTBrands), !failed("ST")), "quota": nullableQuota(totalSTQuota, baselineConfirmed), "ratio": nullableRate(globalSTRate), "remaining": globalSTRemaining, "exceeded": globalSTExceeded, "metric_level": "distinct_brand_name", "status": quotaStatus(globalSTRate), "complete": !failed("ST")}, "tht": map[string]any{"used": quotaCount(len(globalTHTAdvertisers), !failed("THT")), "distinct_advertiser_count": quotaCount(len(globalTHTAdvertisers), !failed("THT")), "approved_ticket_count": quotaCount(len(globalTHTTickets), !failed("THT")), "quota": nil, "ratio": nil, "remaining": nil, "metric_level": "distinct_advertiser_id", "status": "no_denominator", "complete": !failed("THT")}}, "regions": rows, "methodology": map[string]any{"ET": "APPROVE distinct account_id in selected create_date window; distinct ticket_id is a separate submission count; Account-level denominator", "ST": "quarter snapshot distinct Brand Name is formal quota usage; distinct Account ID is auxiliary; Brand-level denominator", "THT": "distinct advertiser_id is passed customer count; distinct ticket_id is passed ticket count; no denominator", "global": "global distinct keys over complete rows; never averages regional percentages"}}
	result["warnings"] = baseline.Warnings
	result["errors"] = source.Errors
	result["diagnostics"] = source.Diagnostics
	result["st_snapshot"] = source.STSnapshot
	result["as_of"] = map[string]any{"st": source.AsOf, "submission": source.AsOf}
	// Counts use global business keys, never a sum of per-region counts.
	points := weeklyQuota(source.ET, source.THT)
	for _, point := range points {
		if failed("ET") {
			point["et_qtd"] = nil
		}
		if failed("THT") {
			point["tht_qtd"] = nil
		}
	}
	result["weekly"] = points
	result["source_status"] = source.SourceStatus
	return result
}

func quotaCount(value int, available bool) any {
	if !available {
		return nil
	}
	return value
}

func nullableRate(rate *float64) any {
	if rate == nil {
		return nil
	}
	return *rate
}

func nullableQuota(value int, valid bool) any {
	if !valid || value <= 0 {
		return nil
	}
	return value
}
func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
