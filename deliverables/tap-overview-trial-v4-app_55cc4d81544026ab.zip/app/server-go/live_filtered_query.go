package main

import (
	"context"
	"net/http"
	"strings"
	"time"
)

var liveQueryBudget = 1500 * time.Millisecond

// A process-wide limiter prevents several dashboards from multiplying Aeolus
// load. Page reads never wait longer than liveQueryBudget for a missing slice.
var liveQuerySlots = make(chan struct{}, 2)
var liveQueryProbe = runTitanVQSProbe

// refreshFilteredState is snapshot-first. A verified snapshot is filtered in
// memory by the handlers, including large 117k/210k snapshots. Live Aeolus is
// only attempted for a source whose snapshot cannot answer the requested slice,
// and that attempt is both globally concurrency-limited and time-bounded.
func refreshFilteredState(r *http.Request, st snapshotState, names ...string) (snapshotState, map[string]string) {
	filter := parseFilter(r)
	if filter == (filterRequest{}) {
		return st, map[string]string{"_mode": "snapshot"}
	}
	cfg, err := loadDataSourceConfig()
	if err != nil {
		return st, map[string]string{"_mode": "snapshot", "_config": "invalid_source_configuration"}
	}
	missing := []string{}
	for _, name := range uniqueNonEmpty(names) {
		source, ok := cfg.Sources[name]
		if !ok || snapshotCanAnswer(st, name, source, filter) {
			continue
		}
		missing = append(missing, name)
	}
	if len(missing) == 0 {
		return st, map[string]string{"_mode": "snapshot"}
	}

	ctx, cancel := context.WithTimeout(r.Context(), liveQueryBudget)
	defer cancel()
	type result struct {
		name  string
		probe map[string]any
		err   error
	}
	results := make(chan result, len(missing))
	for _, sourceName := range missing {
		name := sourceName
		go func() {
			select {
			case liveQuerySlots <- struct{}{}:
				defer func() { <-liveQuerySlots }()
			case <-ctx.Done():
				results <- result{name: name, err: ctx.Err()}
				return
			}
			request := r.Clone(ctx)
			probe, probeErr := liveQueryProbe(ctx, request, name)
			results <- result{name: name, probe: probe, err: probeErr}
		}()
	}

	failures := map[string]string{"_mode": "snapshot_with_bounded_live_fallback"}
	pending := map[string]bool{}
	for _, name := range missing {
		pending[name] = true
	}
	for len(pending) > 0 {
		select {
		case item := <-results:
			delete(pending, item.name)
			if item.err != nil {
				failures[item.name] = boundedFailure(item.err)
				continue
			}
			if asString(item.probe["status"]) != "ok" {
				failures[item.name] = "aeolus_query_failed"
				continue
			}
			rows, ok := item.probe["business_rows"].([]map[string]any)
			if !ok {
				failures[item.name] = "business_rows_missing"
				continue
			}
			applyLiveProbe(&st, cfg, item.name, item.probe, rows)
		case <-ctx.Done():
			for name := range pending {
				failures[name] = "live_query_budget_exceeded"
			}
			return st, failures
		}
	}
	enrichSubmissionDimensions(st.DetailSources["submission_detail"], st.AggregateSources["tap_account"])
	enrichSubmissionDimensions(st.DetailSources["protection"], st.AggregateSources["tap_account"])
	enrichSubmissionDimensions(st.DetailSources["tht_detail"], st.AggregateSources["tap_account"])
	return st, failures
}

func snapshotCanAnswer(st snapshotState, name string, source sourceConfig, filter filterRequest) bool {
	rows := st.AggregateSources[name]
	if source.Kind == "detail" {
		rows = st.DetailSources[name]
	}
	if len(rows) == 0 || !st.Business[name].RuntimeReady {
		return false
	}
	dateKey := "p_date"
	if strings.Contains(name, "submission") || name == "protection" || name == "tht_detail" {
		dateKey = "create_date"
	}
	_, unsupported := effectiveFilterForRows(filter, rows, dateKey)
	if len(unsupported) > 0 {
		return false
	}
	return snapshotCoversDates(rows, dateKey, filter.StartDate, filter.EndDate)
}

func snapshotCoversDates(rows []map[string]any, dateKey, startRaw, endRaw string) bool {
	if startRaw == "" && endRaw == "" {
		return true
	}
	var minDate, maxDate time.Time
	for _, row := range rows {
		d, ok := parseDate(row[dateKey])
		if !ok {
			d, ok = parseDate(row["date"])
		}
		if !ok {
			continue
		}
		if minDate.IsZero() || d.Before(minDate) {
			minDate = d
		}
		if maxDate.IsZero() || d.After(maxDate) {
			maxDate = d
		}
	}
	if minDate.IsZero() {
		return false
	}
	if start, ok := parseDate(startRaw); ok && start.Before(minDate) {
		return false
	}
	if end, ok := parseDate(endRaw); ok && end.After(maxDate) {
		return false
	}
	return true
}

func applyLiveProbe(st *snapshotState, cfg dataSourceConfig, name string, probe map[string]any, rows []map[string]any) {
	source := cfg.Sources[name]
	if source.Kind == "detail" {
		st.DetailSources[name] = rows
	} else {
		st.AggregateSources[name] = rows
	}
	rowCount := asInt(probe["rowCount"])
	possiblyTruncated := rowCount >= savedReportHardLimit
	if value, exists := probe["possibly_truncated"].(bool); exists {
		possiblyTruncated = value
	}
	status := "ok"
	if possiblyTruncated {
		status = "truncated"
	}
	st.Business[name] = sourceSnapshot{Source: name, Kind: source.Kind, Grain: source.Grain, Status: status, RowCount: rowCount, Complete: !possiblyTruncated, PossiblyTruncated: possiblyTruncated, RuntimeReady: true, BusinessPayload: buildBusinessPayload(name, rows)}
}

func hasLiveQueryFailure(failures map[string]string) bool {
	for name := range failures {
		if !strings.HasPrefix(name, "_") {
			return true
		}
	}
	return false
}

func boundedFailure(err error) string {
	if err == context.DeadlineExceeded || err == context.Canceled {
		return "live_query_budget_exceeded"
	}
	return err.Error()
}
