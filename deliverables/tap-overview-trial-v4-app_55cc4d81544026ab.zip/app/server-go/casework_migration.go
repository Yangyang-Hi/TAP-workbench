package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"time"

	_ "modernc.org/sqlite"
)

type cwMigrationReport struct {
	Source   string         `json:"source"`
	Counts   map[string]int `json:"counts"`
	Verified map[string]int `json:"verified"`
}

// cwMigrateLocalCasework is an explicit, repeatable operator action. It is never
// called by service startup or request handlers. Every target table uses a
// business-key upsert and is re-counted after import.
func cwMigrateLocalCasework(ctx context.Context) (cwMigrationReport, error) {
	report := cwMigrationReport{Source: "tap_casework.db", Counts: map[string]int{}, Verified: map[string]int{}}
	dir, err := resolveDataDir()
	if err != nil {
		return report, err
	}
	path := filepath.Join(dir, "tap_casework.db")
	if _, err = os.Stat(path); err != nil {
		return report, fmt.Errorf("local casework database unavailable: %w", err)
	}
	db, err := sql.Open("sqlite", "file:"+path+"?mode=ro")
	if err != nil {
		return report, err
	}
	defer db.Close()
	repo, err := cwCloudRepo()
	if err != nil {
		return report, err
	}
	rows, err := db.QueryContext(ctx, "SELECT body FROM tap_cases")
	if err != nil {
		return report, err
	}
	records := make([]map[string]any, 0, 10)
	flushCases := func() error {
		if len(records) == 0 {
			return nil
		}
		_, flushErr := repo.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_cases/records/upsert-batch", map[string]any{"conflict_fields": []string{"case_id"}, "update_fields": []string{"version", "status", "kind", "owner", "creator", "scan_id", "updated_at", "body"}, "records": records})
		records = records[:0]
		return flushErr
	}
	for rows.Next() {
		var raw string
		if err = rows.Scan(&raw); err != nil {
			rows.Close()
			return report, err
		}
		var a cwCase
		if err = json.Unmarshal([]byte(raw), &a); err != nil {
			rows.Close()
			return report, err
		}
		records = append(records, cloudCaseRecord(a))
		report.Counts["tap_cases"]++
		if len(records) == 10 {
			if err = flushCases(); err != nil {
				rows.Close()
				return report, err
			}
		}
	}
	if err = flushCases(); err != nil {
		rows.Close()
		return report, err
	}
	if err = rows.Close(); err != nil {
		return report, err
	}
	if err = migrateCommands(ctx, db, repo, &report); err != nil {
		return report, err
	}
	if err = migrateOutbox(ctx, db, repo, &report); err != nil {
		return report, err
	}
	if err = migratePreviews(ctx, db, repo, &report); err != nil {
		return report, err
	}
	if err = migrateMappings(ctx, db, repo, &report); err != nil {
		return report, err
	}
	for _, table := range []string{"tap_cases", "tap_commands", "tap_outbox", "tap_previews", "tap_identity_mappings"} {
		recs, qerr := repo.query(ctx, table, map[string]any{"limit": 500, "offset": 0})
		if qerr != nil {
			return report, qerr
		}
		report.Verified[table] = len(recs)
		if len(recs) < report.Counts[table] {
			return report, fmt.Errorf("migration verification failed for %s: source=%d cloud=%d", table, report.Counts[table], len(recs))
		}
	}
	return report, nil
}
func migrateCommands(ctx context.Context, db *sql.DB, r *cloudCaseworkRepository, p *cwMigrationReport) error {
	rows, e := db.QueryContext(ctx, "SELECT case_id,request_id,body FROM tap_commands")
	if e != nil {
		return e
	}
	defer rows.Close()
	for rows.Next() {
		var c, q, f string
		if e = rows.Scan(&c, &q, &f); e != nil {
			return e
		}
		_, e = r.db.doJSON(ctx, "POST", cloudDBAPIPrefix+"/tables/tap_commands/records/upsert", map[string]any{"conflict_fields": []string{"case_id", "request_id"}, "data": map[string]any{"case_id": c, "request_id": q, "fingerprint": f, "result_version": 0, "created_at": cwNow()}, "update_fields": []string{"fingerprint"}})
		if e != nil {
			return e
		}
		p.Counts["tap_commands"]++
	}
	return rows.Err()
}
func migrateOutbox(ctx context.Context, db *sql.DB, r *cloudCaseworkRepository, p *cwMigrationReport) error {
	rows, e := db.QueryContext(ctx, "SELECT id,case_id,recipient,kind,status,message_id,attempts,error,created_at,updated_at,notification_mode,bot_fingerprint,mapping_version,mapping_revision,target_email,resolved_open_id,source,mode,batch_id,rule_version,result,next_at,idempotency_key FROM tap_outbox")
	if e != nil {
		return e
	}
	defer rows.Close()
	for rows.Next() {
		var n cwNotice
		var next int64
		var idem string
		if e = rows.Scan(&n.ID, &n.CaseID, &n.Recipient, &n.Kind, &n.Status, &n.MessageID, &n.Attempts, &n.Error, &n.CreatedAt, &n.UpdatedAt, &n.NotificationMode, &n.BotFingerprint, &n.MappingVersion, &n.MappingRevision, &n.TargetEmail, &n.ResolvedOpenID, &n.Source, &n.Mode, &n.BatchID, &n.RuleVersion, &n.Result, &next, &idem); e != nil {
			return e
		}
		if idem == "" {
			idem = "legacy:" + n.ID
		}
		if e = r.upsertNotice(ctx, n, idem, next); e != nil {
			return e
		}
		p.Counts["tap_outbox"]++
	}
	return rows.Err()
}
func migratePreviews(ctx context.Context, db *sql.DB, r *cloudCaseworkRepository, p *cwMigrationReport) error {
	rows, e := db.QueryContext(ctx, "SELECT token_hash,body,expires_at,consumed FROM tap_notification_previews")
	if e != nil {
		return e
	}
	defer rows.Close()
	for rows.Next() {
		var token, raw string
		var expiry int64
		var used int
		if e = rows.Scan(&token, &raw, &expiry, &used); e != nil {
			return e
		}
		var body any
		if e = json.Unmarshal([]byte(raw), &body); e != nil {
			return e
		}
		caseID := ""
		if m, ok := body.(map[string]any); ok {
			caseID = asString(m["AlertID"])
			if caseID == "" {
				caseID = asString(m["alert_id"])
			}
		}
		_, e = r.db.doJSON(ctx, "POST", cloudDBAPIPrefix+"/tables/tap_previews/records/upsert", map[string]any{"conflict_fields": []string{"token_hash"}, "data": map[string]any{"token_hash": token, "case_id": caseID, "expires_at": expiry, "consumed": used == 1, "body": body}, "update_fields": []string{"expires_at", "consumed", "body"}})
		if e != nil {
			return e
		}
		p.Counts["tap_previews"]++
	}
	return rows.Err()
}
func migrateMappings(ctx context.Context, db *sql.DB, r *cloudCaseworkRepository, p *cwMigrationReport) error {
	rows, e := db.QueryContext(ctx, "SELECT "+cwMappingColumns+" FROM tap_identity_mappings")
	if e != nil {
		return e
	}
	defer rows.Close()
	for rows.Next() {
		m, e := cwScanMapping(rows)
		if e != nil {
			return e
		}
		_, e = r.db.doJSON(ctx, "POST", cloudDBAPIPrefix+"/tables/tap_identity_mappings/records/upsert", map[string]any{"conflict_fields": []string{"record_id"}, "data": map[string]any{"record_id": m.RecordID, "region": m.Region, "business_name": m.BusinessName, "email": m.Email, "aeolus_name": m.AeolusName, "match_status": m.MatchStatus, "enabled": m.Enabled, "manual_disabled": m.ManualDisabled, "sheet_revision": m.SheetRevision, "sheet_row": m.SheetRow, "updated_at": time.Now().UTC().Format(time.RFC3339), "body": m}, "update_fields": []string{"region", "business_name", "email", "aeolus_name", "match_status", "enabled", "manual_disabled", "sheet_revision", "sheet_row", "updated_at", "body"}})
		if e != nil {
			return e
		}
		p.Counts["tap_identity_mappings"]++
	}
	return rows.Err()
}
