package main

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

const accountJobID = "account-20260927"

type accountPlan struct {
	Windows []accountWindow `json:"windows"`
}
type accountWindow struct {
	ID       string           `json:"window_id"`
	Date     string           `json:"p_date"`
	Region   string           `json:"region"`
	Tier     string           `json:"tier"`
	Expected int              `json:"expected_rows"`
	Filters  []map[string]any `json:"filters"`
}
type accountWindowState struct {
	ID        string `json:"window_id"`
	Status    string `json:"status"`
	Rows      int    `json:"row_count"`
	Expected  int    `json:"expected_rows"`
	Attempts  int    `json:"attempts"`
	Error     string `json:"error,omitempty"`
	LogID     string `json:"log_id,omitempty"`
	UpdatedAt string `json:"updated_at"`
}
type accountManifest struct {
	JobID       string                        `json:"job_id"`
	Status      string                        `json:"status"`
	Total       int                           `json:"total"`
	Success     int                           `json:"success"`
	Failed      int                           `json:"failed"`
	Remaining   int                           `json:"remaining"`
	Concurrency int                           `json:"concurrency"`
	SourceRID   int                           `json:"source_rid"`
	DataAsOf    string                        `json:"data_as_of"`
	UpdatedAt   string                        `json:"updated_at"`
	Error       string                        `json:"error,omitempty"`
	Windows     map[string]accountWindowState `json:"windows"`
}

var accountJobMu sync.Mutex
var accountJobRunning bool

func accountJobDir() (string, error) {
	d, err := resolveDataDir()
	if err != nil {
		return "", err
	}
	d = filepath.Join(d, "account_complete", "2026-09-27")
	return d, os.MkdirAll(filepath.Join(d, "windows"), 0700)
}
func accountManifestPath() (string, error) {
	d, e := accountJobDir()
	return filepath.Join(d, "manifest.json"), e
}
func loadAccountManifest() accountManifest {
	m := accountManifest{JobID: accountJobID, Status: "pending", Total: 325, Remaining: 325, Concurrency: 1, SourceRID: 2833031, DataAsOf: "2026-09-27", Windows: map[string]accountWindowState{}}
	p, e := accountManifestPath()
	if e != nil {
		return m
	}
	b, e := os.ReadFile(p)
	if e == nil {
		_ = json.Unmarshal(b, &m)
	}
	if m.Windows == nil {
		m.Windows = map[string]accountWindowState{}
	}
	return m
}
func saveAccountManifest(m accountManifest) error {
	p, e := accountManifestPath()
	if e != nil {
		return e
	}
	m.UpdatedAt = time.Now().UTC().Format(time.RFC3339)
	b, e := json.MarshalIndent(m, "", "  ")
	if e != nil {
		return e
	}
	tmp := p + ".tmp"
	if e = os.WriteFile(tmp, b, 0600); e != nil {
		return e
	}
	return os.Rename(tmp, p)
}
func loadAccountPlan() (accountPlan, error) {
	var p accountPlan
	b, e := os.ReadFile(filepath.Join(pluginDir, "config", "account_split_plan.json"))
	if e != nil {
		return p, e
	}
	e = json.Unmarshal(b, &p)
	return p, e
}

func appendPlanFilters(chart map[string]any, filters []map[string]any) map[string]any {
	out := cloneMap(chart)
	existing := []any{}
	for _, f := range filters {
		detail, _ := f["detail"].(map[string]any)
		if f["type"] == "whereDate" {
			for _, key := range []string{"startTime", "endTime"} {
				if point, ok := detail[key].(map[string]any); ok {
					date := asString(point["date"])
					if len(date) == 10 {
						point["date"] = date + " 00:00:00"
					}
				}
			}
		}
		existing = append(existing, map[string]any{"type": f["type"], "datasetFieldId": f["datasetFieldId"], "uniqueId": f["uniqueId"], "showFilter": false, "detail": detail})
	}
	out["filters"] = existing
	return out
}
func accountPlanWindow(id string) (accountWindow, bool) {
	p, e := loadAccountPlan()
	if e != nil {
		return accountWindow{}, false
	}
	for _, w := range p.Windows {
		if w.ID == id {
			return w, true
		}
	}
	return accountWindow{}, false
}

func validateAccountWindow(w accountWindow, rows []map[string]any, queryRows int) error {
	if queryRows >= savedReportHardLimit {
		return fmt.Errorf("row_count=%d reaches hard limit", queryRows)
	}
	if w.Expected > 0 && queryRows != w.Expected {
		return fmt.Errorf("query_rows=%d expected=%d", queryRows, w.Expected)
	}
	required := []string{"p_date", "account_id", "advertiser_id", "client_tier", "region"}
	for i, row := range rows {
		for _, k := range required {
			if strings.TrimSpace(asString(row[k])) == "" {
				return fmt.Errorf("row %d missing %s", i, k)
			}
		}
		if normalizeDate(asString(row["p_date"])) != "2026-09-27" {
			return fmt.Errorf("wrong date")
		}
		rowRegion, _ := canonicalRegion(asString(row["region"]))
		wantRegion, _ := canonicalRegion(w.Region)
		if rowRegion != wantRegion || normalizeTier(asString(row["client_tier"])) != normalizeTier(w.Tier) {
			return fmt.Errorf("window mismatch")
		}
		for _, k := range []string{"account_id", "advertiser_id"} {
			v := asString(row[k])
			if strings.ContainsAny(strings.ToLower(v), "e+.") {
				return fmt.Errorf("%s is not decimal string", k)
			}
		}
	}
	return nil
}
func normalizeTier(v string) string {
	return strings.ToLower(strings.ReplaceAll(strings.TrimSpace(v), " ", "_"))
}
func normalizeDate(v string) string {
	v = strings.ReplaceAll(v, "/", "-")
	if len(v) == 8 && !strings.Contains(v, "-") {
		return v[:4] + "-" + v[4:6] + "-" + v[6:]
	}
	return v
}

func saveAccountWindowCSV(w accountWindow, rows []map[string]any) error {
	d, e := accountJobDir()
	if e != nil {
		return e
	}
	p := filepath.Join(d, "windows", w.ID+".csv")
	tmp := p + ".tmp"
	f, e := os.OpenFile(tmp, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	cw := csv.NewWriter(f)
	_ = cw.Write([]string{"p_date", "account_id", "advertiser_id", "client_tier", "region"})
	for _, r := range rows {
		_ = cw.Write([]string{asString(r["p_date"]), asString(r["account_id"]), asString(r["advertiser_id"]), asString(r["client_tier"]), asString(r["region"])})
	}
	cw.Flush()
	e = cw.Error()
	if ce := f.Close(); e == nil {
		e = ce
	}
	if e != nil {
		return e
	}
	return os.Rename(tmp, p)
}

func runAccountChild(ctx context.Context, template *http.Request, w accountWindow) (accountWindowState, error) {
	state := accountWindowState{ID: w.ID, Expected: w.Expected, Status: "failed"}
	for attempt := 1; attempt <= 3; attempt++ {
		state.Attempts = attempt
		cctx, cancel := context.WithTimeout(ctx, 120*time.Second)
		req := template.Clone(cctx)
		q := req.URL.Query()
		q.Set("start_date", "2026-09-27")
		q.Set("end_date", "2026-09-27")
		q.Set("region", w.Region)
		q.Set("client_tier", w.Tier)
		q.Set("account_window_id", w.ID)
		req.URL.RawQuery = q.Encode()
		probe, e := runTitanVQSProbe(cctx, req, "tap_account")
		cancel()
		if e == nil && (probe["status"] == "ok" || probe["status"] == "passed") {
			rows, _ := probe["business_rows"].([]map[string]any)
			qr := asInt(probe["rowCount"])
			state.Rows = qr
			state.LogID = asString(probe["logId"])
			if e = validateAccountWindow(w, rows, qr); e == nil {
				e = saveAccountWindowCSV(w, rows)
			}
			if e == nil {
				state.Status = "success"
				state.UpdatedAt = time.Now().UTC().Format(time.RFC3339)
				return state, nil
			}
		} else if e == nil {
			e = fmt.Errorf("aeolus status=%s log_id=%s", asString(probe["status"]), asString(probe["logId"]))
		}
		state.Error = e.Error()
		if strings.Contains(state.Error, "429") {
			time.Sleep(time.Duration(attempt*5) * time.Second)
		} else {
			time.Sleep(time.Duration(attempt*2) * time.Second)
		}
	}
	state.UpdatedAt = time.Now().UTC().Format(time.RFC3339)
	return state, fmt.Errorf(state.Error)
}

func pauseAccountJobForIDAImport() error {
	accountJobMu.Lock()
	defer accountJobMu.Unlock()
	m := loadAccountManifest()
	m.Status = "paused_by_ida_import"
	m.Total = 325
	m.Success = 0
	m.Failed = 0
	for _, state := range m.Windows {
		if state.Status == "success" {
			m.Success++
		}
		if state.Status == "failed" {
			m.Failed++
		}
	}
	m.Remaining = m.Total - m.Success
	m.Concurrency = 0
	m.Error = "automatic resume disabled; iDA aggregate import is authoritative only for aggregate metrics; retained successful detail windows are excluded from aggregate computation"
	return saveAccountManifest(m)
}

func startAccountJob(template *http.Request) (accountManifest, error) {
	m := loadAccountManifest()
	return m, fmt.Errorf("account online sync is paused_by_ida_import; automatic resume is disabled")
}

func disabledStartAccountJob(template *http.Request) (accountManifest, error) {
	accountJobMu.Lock()
	if accountJobRunning {
		m := loadAccountManifest()
		accountJobMu.Unlock()
		return m, nil
	}
	accountJobRunning = true
	accountJobMu.Unlock()
	m := loadAccountManifest()
	m.Status = "running"
	m.Error = ""
	_ = saveAccountManifest(m)
	clone := template.Clone(context.Background())
	go func() {
		defer func() { accountJobMu.Lock(); accountJobRunning = false; accountJobMu.Unlock() }()
		p, e := loadAccountPlan()
		if e != nil {
			m := loadAccountManifest()
			m.Status = "failed"
			m.Error = e.Error()
			_ = saveAccountManifest(m)
			return
		}
		sem := make(chan struct{}, 5)
		var wg sync.WaitGroup
		for _, w := range p.Windows {
			m := loadAccountManifest()
			if s, ok := m.Windows[w.ID]; ok && s.Status == "success" {
				continue
			}
			wg.Add(1)
			go func(w accountWindow) {
				defer wg.Done()
				sem <- struct{}{}
				defer func() { <-sem }()
				s, _ := runAccountChild(context.Background(), clone, w)
				accountJobMu.Lock()
				m := loadAccountManifest()
				m.Windows[w.ID] = s
				m.Success, m.Failed = 0, 0
				for _, x := range m.Windows {
					if x.Status == "success" {
						m.Success++
					} else if x.Status == "failed" {
						m.Failed++
					}
				}
				m.Remaining = m.Total - m.Success
				m.Concurrency = cap(sem)
				_ = saveAccountManifest(m)
				accountJobMu.Unlock()
				logMsg(fmt.Sprintf("[account-job] window=%s status=%s rows=%d log_id=%s", s.ID, s.Status, s.Rows, s.LogID), "plugin")
			}(w)
		}
		wg.Wait()
		accountJobMu.Lock()
		m = loadAccountManifest()
		if m.Success == m.Total && m.Failed == 0 {
			m.Status = "complete"
		} else {
			m.Status = "partial"
			m.Error = "54 ordinary parent windows require audit expansion; successful child CSVs retained"
		}
		_ = saveAccountManifest(m)
		accountJobMu.Unlock()
	}()
	return m, nil
}

func accountJobStatus() accountManifest {
	m := loadAccountManifest()
	m.Remaining = m.Total - m.Success
	return m
}

func applyAccountPlanWindow(chart map[string]any, id string) (map[string]any, error) {
	w, ok := accountPlanWindow(id)
	if !ok {
		return chart, fmt.Errorf("unknown account window %s", id)
	}
	return appendPlanFilters(chart, w.Filters), nil
}

func accountStatusResponse() map[string]any {
	m := accountJobStatus()
	return map[string]any{"job_id": m.JobID, "status": m.Status, "total": m.Total, "success": m.Success, "failed": m.Failed, "remaining": m.Remaining, "concurrency": m.Concurrency, "source_rid": m.SourceRID, "data_as_of": m.DataAsOf, "updated_at": m.UpdatedAt, "error": m.Error, "completed_windows": strconv.Itoa(m.Success) + "/" + strconv.Itoa(m.Total), "automatic_resume": false}
}
