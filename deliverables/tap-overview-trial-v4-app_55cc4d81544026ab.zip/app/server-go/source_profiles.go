package main

import (
	"fmt"
	"sort"
	"strings"
)

func sourceIdentityKey(s sourceConfig) string {
	i := s.Identity
	return fmt.Sprintf("app=%d/dashboard=%d/sid=%d/rid=%d/tid=%d/history=%d/region=%s/mode=%s/id=%s", i.AppID, i.DashboardID, i.SID, i.RID, i.TID, i.HistoryID, i.Region, i.QueryMode, i.IDDimension)
}

func fieldDiscoveryStatus(s sourceConfig) string {
	for _, f := range s.Fields {
		if !f.Optional && strings.TrimSpace(f.DimMetID) == "" && strings.TrimSpace(f.SourceName) == "" {
			return "field_mapping_required"
		}
	}
	return "mapped"
}

func detailProbeStatus(s sourceConfig, snap sourceSnapshot) string {
	if s.Kind != "detail" {
		return "not_applicable"
	}
	if snap.Source != "" && snap.Status != "failed" {
		return "passed"
	}
	return "requires_probe"
}

func completenessStatus(snap sourceSnapshot) string {
	if snap.Source == "" {
		return "not_queried"
	}
	if snap.Complete && !snap.PossiblyTruncated {
		return "complete"
	}
	return "partial"
}

type monitoringPlan struct {
	ProgramType string            `json:"program_type"`
	IDDimension string            `json:"id_dimension"`
	ClientIDs   []string          `json:"client_ids"`
	Supported   []string          `json:"supported"`
	NotReady    map[string]string `json:"not_ready"`
}

// buildMonitoringPlan implements approved submission -> correctly typed client IDs -> downstream source plan.
func buildMonitoringPlan(program string, submissions []map[string]any, cfg dataSourceConfig) monitoringPlan {
	program = strings.ToUpper(program)
	idKey := "account_id"
	if program == "THT" {
		idKey = "advertiser_id"
	}
	seen := map[string]bool{}
	for _, row := range submissions {
		if !isApproved(row) || resolveProgramType(row) != program {
			continue
		}
		if id := strings.TrimSpace(asString(row[idKey])); id != "" {
			seen[id] = true
		}
	}
	ids := make([]string, 0, len(seen))
	for id := range seen {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	plan := monitoringPlan{ProgramType: program, IDDimension: idKey, ClientIDs: ids, Supported: []string{}, NotReady: map[string]string{}}
	for _, name := range []string{"client_account_detail", "client_risk_detail", "client_approval_detail", "client_revenue_detail"} {
		s, ok := cfg.Sources[name]
		if !ok || !s.Enabled || s.RID == 0 {
			plan.NotReady[name] = "rid_missing"
			continue
		}
		if fieldDiscoveryStatus(s) != "mapped" {
			plan.NotReady[name] = "field_mapping_required"
			continue
		}
		if s.RequiresProbe {
			plan.NotReady[name] = "detail_probe_required"
			continue
		}
		plan.Supported = append(plan.Supported, name)
	}
	return plan
}
