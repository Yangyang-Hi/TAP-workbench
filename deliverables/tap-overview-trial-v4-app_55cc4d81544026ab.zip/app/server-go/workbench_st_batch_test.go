package main

import (
	"context"
	"net/http"
	"testing"
)

func TestSTSnapshotsKeepCrossQuarterAndDedupeWithinQuarter(t *testing.T) {
	wbTestEnv(t)
	q3 := stQuarterSnapshot{Quarter: "Q3", PeriodBasis: "Full Quarter", Rows: []stSnapshotRow{
		{SalesRegion: "CNOB", BrandName: "Brand Q3", AccountID: "6876449360192733954", AdexSubmitter: "Alice", StartDate: "6.30"},
		{SalesRegion: "CNOB", BrandName: "Duplicate", AccountID: "6876449360192733954", AdexSubmitter: "Alice", StartDate: "6.30"},
	}}
	q4 := stQuarterSnapshot{Quarter: "Q4", PeriodBasis: "QTD", Rows: []stSnapshotRow{
		{SalesRegion: "APAC", BrandName: "Brand Q4", AccountID: "6876449360192733954", EndorsementReason: "reviewed", AdexSubmitter: "Bob", StartDate: "9.30"},
	}}
	state, err := saveSTSnapshots([]stQuarterSnapshot{q3, q4}, "tester")
	if err != nil {
		t.Fatal(err)
	}
	if state.Snapshots["Q3"].RowCount != 1 || state.Snapshots["Q4"].RowCount != 1 {
		t.Fatalf("within-quarter dedupe failed: %#v", state.Snapshots)
	}
	members, complete, err := loadSTMembers(wbRequest{Program: "ST", Region: "all", MemberStart: "2026-01-01", MemberEnd: "2026-12-31"})
	if err != nil || !complete || len(members) != 2 {
		t.Fatalf("cross-quarter records were not preserved: members=%#v complete=%t err=%v", members, complete, err)
	}
	if members[0].Quarter == members[1].Quarter || members[0].TicketID == members[1].TicketID {
		t.Fatalf("quarter batch identity missing: %#v", members)
	}
}

func TestSTBatchScanChunksAndPreservesQuarterRows(t *testing.T) {
	old := wbQuerySTBatch
	defer func() { wbQuerySTBatch = old }()
	calls := 0
	wbQuerySTBatch = func(_ context.Context, _ *http.Request, ids []string, _, _ string) (map[string]wbBatchMetric, error) {
		calls++
		out := map[string]wbBatchMetric{}
		for _, id := range ids {
			out[id] = wbBatchMetric{Status: "success", CCR: f64(4), NFS: f64(2)}
		}
		return out, nil
	}
	members := makeETMembers(wbSTMetricChunkSize + 1)
	members[0].Quarter, members[0].TicketID = "Q3", "ST-Q3"
	members = append(members, wbMember{AccountID: members[0].AccountID, Quarter: "Q4", TicketID: "ST-Q4"})
	rows, requestCount, err := wbRunSTBatches(context.Background(), wbReq("Alice"), members, wbRequest{Program: "ST"}, testRule())
	if err != nil || calls != 2 || requestCount != 2 || len(rows) != len(members) {
		t.Fatalf("ST batch scan failed: calls=%d requestCount=%d rows=%d err=%v", calls, requestCount, len(rows), err)
	}
	if rows[0].ID == rows[len(rows)-1].ID {
		t.Fatal("cross-quarter rows collapsed to one alert identity")
	}
}

func TestETAndTHTTierSpecificFields(t *testing.T) {
	etRows := []map[string]any{{"type_name": "Emerging trust apply", "final_result": "APPROVE", "account_id": "6876449360192733954", "create_date": "2026-10-01", "create_time": "2026-10-01 12:30:00"}}
	et, _, err := canonicalWBMembers(etRows, wbRequest{Program: "ET", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-02"}, true)
	if err != nil || len(et) != 1 || et[0].AdvertiserID != "" || et[0].Start != "2026-10-01 12:30:00" || et[0].End != "" {
		t.Fatalf("ET field semantics failed: %#v err=%v", et, err)
	}
	thtRows := []map[string]any{{"type_name": "Protection program", "protection_program_name": "Temporary High Trust (THT) - Advertiser ID", "final_result": "APPROVE", "advertiser_id": "6876449360192733954", "create_date": "2026-10-01", "ticket_id": "1", "status": "APPROVE", "protection_businessline": "Ads", "protection_estimated_spend": "100", "protection_starttime": "start", "protection_endtime": "end"}}
	tht, _, err := canonicalWBMembers(thtRows, wbRequest{Program: "THT", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-02"}, true)
	if err != nil || len(tht) != 1 || tht[0].ProtectionProgramName == "" || tht[0].ProtectionBusinessline != "Ads" || tht[0].ProtectionEstimatedSpend != "100" || tht[0].ProtectionStatus != "APPROVE" || tht[0].End != "end" {
		t.Fatalf("THT protection fields failed: %#v err=%v", tht, err)
	}
}

func TestSTBatchProgressAfterEachSuccessfulChunk(t *testing.T) {
	old := wbQuerySTBatch
	defer func() { wbQuerySTBatch = old }()
	wbQuerySTBatch = func(_ context.Context, _ *http.Request, ids []string, _, _ string) (map[string]wbBatchMetric, error) {
		out := make(map[string]wbBatchMetric, len(ids))
		for _, id := range ids {
			out[id] = wbBatchMetric{Status: "success", CCR: f64(1), NFS: f64(2)}
		}
		return out, nil
	}

	members := makeETMembers(wbSTMetricChunkSize*2 + 1)
	var progress [][3]int
	rows, requests, err := wbRunSTBatchesWithProgress(context.Background(), wbReq("Alice"), members, wbRequest{Program: "ST"}, testRule(), func(processed, completedChunks, totalChunks int, checkpointRows []wbRow) {
		if len(checkpointRows) != processed {
			t.Fatalf("checkpoint rows=%d processed=%d", len(checkpointRows), processed)
		}
		progress = append(progress, [3]int{processed, completedChunks, totalChunks})
	})
	if err != nil || requests != 3 || len(rows) != len(members) {
		t.Fatalf("ST progress scan failed: requests=%d rows=%d err=%v", requests, len(rows), err)
	}
	want := [][3]int{{wbSTMetricChunkSize, 1, 3}, {wbSTMetricChunkSize * 2, 2, 3}, {len(members), 3, 3}}
	if len(progress) != len(want) {
		t.Fatalf("progress callbacks=%v want=%v", progress, want)
	}
	for i := range want {
		if progress[i] != want[i] {
			t.Fatalf("progress[%d]=%v want=%v", i, progress[i], want[i])
		}
	}
}

func TestSTMembershipSourceUsesAuthoritativeSnapshot(t *testing.T) {
	if got := wbMembershipSource("ST"); got != "st_authoritative_sheet_snapshot" {
		t.Fatalf("ST membership source=%q", got)
	}
	if got := wbMembershipSource("ET"); got != "et_account_list" {
		t.Fatalf("ET membership source changed: %q", got)
	}
	if got := wbMembershipSource("THT"); got != "tht_ticket_details" {
		t.Fatalf("THT membership source changed: %q", got)
	}
}

func TestSTBrandAndStartDateRemainMetadataOnly(t *testing.T) {
	wbTestEnv(t)
	_, err := saveSTSnapshots([]stQuarterSnapshot{{Quarter: "Q4", PeriodBasis: "QTD", Rows: []stSnapshotRow{{SalesRegion: "APAC", BrandName: "Brand Only", AccountID: "6876449360192733954", StartDate: "9.30"}}}}, "tester")
	if err != nil {
		t.Fatal(err)
	}
	members, _, err := loadSTMembers(wbRequest{Program: "ST", Region: "all", MemberStart: "2099-01-01", MemberEnd: "2099-01-02"})
	if err != nil || len(members) != 1 {
		t.Fatalf("unconfirmed Start date filtered membership: %+v err=%v", members, err)
	}
	if members[0].Name != "" || members[0].BrandName != "Brand Only" || members[0].Start != "" || members[0].CreateDate != "" {
		t.Fatalf("ST metadata leaked into Account Name/protection dates: %+v", members[0])
	}
}

func TestETCreateTimeAcceptsOnlyTheVerifiedSameFieldAlias(t *testing.T) {
	rows := []map[string]any{{"type_name": "Emerging trust apply", "final_result": "APPROVE", "account_id": "6876449360192733954", "create_date": "2026-10-01", "protection_starttime": "2026-10-01 12:30:00"}}
	members, _, err := canonicalWBMembers(rows, wbRequest{Program: "ET", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-02"}, true)
	if err != nil || len(members) != 1 || members[0].Start != "2026-10-01 12:30:00" {
		t.Fatalf("verified create_time alias was not retained: %#v err=%v", members, err)
	}
}
