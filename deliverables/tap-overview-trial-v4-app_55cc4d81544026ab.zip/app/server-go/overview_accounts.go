package main

// Overview is a read-only consumer of Saved Reports. No scan, Case, notification
// or Cloud DB write is used on this path.
import (
	"context"
	"fmt"
	"math"
	"net/http"
	"strings"
	"time"
)

const overviewAccountSource = "overview_account_tiers"

var overviewTierKeys = []string{"strategic_trust", "high_trust", "building_trust", "emerging_trust"}
var overviewTierLabels = []string{"ST", "HT", "BT", "ET"}
var overviewQueryReport = runTitanVQSProbe

type overviewAccountTier struct {
	Tier       string   `json:"tier"`
	SourceTier string   `json:"source_tier"`
	Count      *float64 `json:"account_count"`
	Share      *float64 `json:"account_share"`
}

type overviewAccounts struct {
	Status       string                `json:"status"`
	Reason       string                `json:"reason,omitempty"`
	RequestedEnd string                `json:"requested_end_date"`
	AsOf         string                `json:"data_as_of"`
	Region       string                `json:"region"`
	Total        *float64              `json:"tier_membership_total"`
	Rows         []overviewAccountTier `json:"rows"`
	QueriedAt    string                `json:"queried_at"`
	Attempts     int                   `json:"attempts"`
	Trace        map[string]any        `json:"diagnostics"`
	Source       map[string]any        `json:"source"`
}

func overviewEmpty(end, region string) overviewAccounts {
	o := overviewAccounts{Status: "unavailable", RequestedEnd: end, Region: region, Rows: []overviewAccountTier{},
		QueriedAt: time.Now().UTC().Format(time.RFC3339), Trace: map[string]any{},
		Source: map[string]any{"rid": 2891943, "sid": 1280034, "app_id": 800414, "unit": "Account", "time_semantics": "latest_nonempty_snapshot_within_14_days", "lookback_days": 14, "share_denominator": "sum_of_four_tier_counts_not_verified_global_distinct"}}
	for i, k := range overviewTierKeys {
		o.Rows = append(o.Rows, overviewAccountTier{Tier: overviewTierLabels[i], SourceTier: k})
	}
	return o
}

// Validate shape before calculating shares. Missing tiers are not silently 0;
// repeated aggregate rows are never summed, even if values happen to agree.
func overviewParseAccounts(o overviewAccounts, rows []map[string]any) overviewAccounts {
	seen := map[string]bool{}
	invalid := false
	for _, row := range rows {
		key := strings.ToLower(strings.TrimSpace(asString(row["client_tier"])))
		index := -1
		for i, k := range overviewTierKeys {
			if k == key {
				index = i
				break
			}
		}
		if index < 0 {
			invalid = true
			continue
		}
		if seen[key] {
			o.Status, o.Reason = "unavailable", "同一 Tier 返回多行，未对聚合账户数重复求和；请核对报表维度。"
			return o
		}
		seen[key] = true
		n, ok := number(row["account_count"])
		if !ok || math.IsNaN(n) || math.IsInf(n, 0) || n < 0 || math.Trunc(n) != n || n > 9007199254740991 {
			invalid = true
			continue
		}
		o.Rows[index].Count = &n
	}
	if len(seen) != 4 || invalid {
		o.Status, o.Reason = "partial", "存在缺失 Tier、未知分类或无效数量，仅展示返回值；占比暂不可用。"
		return o
	}
	total := 0.0
	for _, row := range o.Rows {
		total += *row.Count
	}
	if total > 9007199254740991 {
		o.Status, o.Reason = "unavailable", "账户数合计超出安全数值范围。"
		return o
	}
	o.Total = &total
	o.Status = "available"
	if total == 0 {
		o.Reason = "源返回四个 Tier 均为 0，不计算占比。"
		return o
	}
	for i := range o.Rows {
		share := *o.Rows[i].Count / total * 100
		o.Rows[i].Share = &share
	}
	return o
}

func overviewLoadAccounts(ctx context.Context, request *http.Request, end, region string) overviewAccounts {
	o := overviewEmpty(end, region)
	day, _ := time.Parse("2006-01-02", end)
	for offset := 0; offset < 14; offset++ {
		if ctx.Err() != nil {
			o.Reason = "查询已取消或超时，请重试或缩小排查范围。"
			return o
		}
		date := day.AddDate(0, 0, -offset).Format("2006-01-02")
		r := request.Clone(ctx)
		u := *r.URL
		q := u.Query()
		// Never forward Program, Submitter, client IDs or Tier to the full
		// distribution. Avoid accidental inherited query/body filters.
		for key := range q {
			q.Del(key)
		}
		q.Set("start_date", date)
		q.Set("end_date", date)
		if region != "Global" {
			q.Set("region", region)
		}
		u.RawQuery = q.Encode()
		r.URL = &u
		r.Form = nil
		r.PostForm = nil
		probe, err := overviewQueryReport(ctx, r, overviewAccountSource)
		o.Attempts++
		if err != nil {
			o.Reason = "风神查询未完成；请按本次时间检查 plugin.log 中的 overview_accounts 记录。"
			logMsg(fmt.Sprintf("overview_accounts error=%s", sanitizeAuditText(err.Error())), "plugin")
			return o
		}
		o.Trace = map[string]any{"audit_id": probe["audit_id"], "request_id": probe["requestId"], "log_id": probe["logId"], "status": probe["status"], "blocked_stage": probe["blocked_stage"], "failure_classification": probe["failure_classification"], "columns": probe["columns"], "queried_date": date}
		if asString(probe["status"]) != "ok" {
			o.Reason = "风神鉴权、报表定义、过滤或字段映射未通过，请查看查询诊断及服务日志。"
			return o
		}
		if truncated, _ := probe["possibly_truncated"].(bool); truncated {
			o.Reason = "报表返回可能截断，未生成占比。"
			return o
		}
		rows, ok := probe["business_rows"].([]map[string]any)
		if !ok {
			o.Reason = "报表未返回预期结果结构。"
			return o
		}
		if len(rows) == 0 {
			continue
		}
		o.AsOf = date
		return overviewParseAccounts(o, rows)
	}
	o.Status, o.Reason = "no_data", "截止日及此前 13 天没有返回账户快照；未使用未来数据，也未补成 0。"
	return o
}

func overviewAccountsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	end := strings.TrimSpace(r.URL.Query().Get("end_date"))
	if end == "" {
		end = time.Now().In(cwLocation()).Format("2006-01-02")
	}
	date, err := time.Parse("2006-01-02", end)
	if err != nil || date.Format("2006-01-02") != end || end > time.Now().In(cwLocation()).Format("2006-01-02") {
		writeJSON(w, 400, map[string]any{"error": "截止日期必须为不晚于今天的 YYYY-MM-DD。"})
		return
	}
	region := strings.TrimSpace(r.URL.Query().Get("region"))
	if region == "" || region == "all" {
		region = "Global"
	}
	if !containsString([]string{"Global", "APAC", "CNOB", "EUI", "LATAM", "METAP", "NA", "NEA", "GA", "Scaled Growth", "SMB", "Other"}, region) {
		writeJSON(w, 400, map[string]any{"error": "Region 不在该报表的 Sales Region 范围内。"})
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()
	writeJSON(w, 200, map[string]any{"data": overviewLoadAccounts(ctx, r, end, region)})
}
