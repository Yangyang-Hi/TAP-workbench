package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

func withAuditTemp(t *testing.T) string {
	t.Helper()
	dir := t.TempDir()
	oldDir, oldNow := queryAuditDataDir, queryAuditNow
	queryAuditDataDir = func() (string, error) { return dir, nil }
	queryAuditNow = time.Now
	t.Cleanup(func() { queryAuditDataDir, queryAuditNow = oldDir, oldNow })
	return dir
}

func TestQueryAuditConcurrentJSONLAndStringIDs(t *testing.T) {
	dir := withAuditTemp(t)
	const n = 40
	var wg sync.WaitGroup
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if err := appendQueryAudit(queryAuditRecord{AuditID: newAuditID(), RID: "2979783123456789012", StartedAt: time.Now().UTC().Format(time.RFC3339Nano), SQLStatus: "not_returned"}); err != nil {
				t.Errorf("append: %v", err)
			}
		}()
	}
	wg.Wait()
	path := filepath.Join(dir, "query-audit", time.Now().UTC().Format("2006-01-02")+".jsonl")
	f, err := os.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	count := 0
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		var got map[string]any
		if json.Unmarshal(scanner.Bytes(), &got) != nil {
			t.Fatalf("invalid jsonl")
		}
		if got["rid"] != "2979783123456789012" {
			t.Fatalf("19 digit ID changed: %#v", got["rid"])
		}
		count++
	}
	if count != n {
		t.Fatalf("got %d records", count)
	}
}

func TestQueryAuditRedactionAndWriteFailureDoesNotAffectResult(t *testing.T) {
	withAuditTemp(t)
	redacted := redactAuditValue(map[string]any{"Authorization": "Bearer secret", "clientSecret": "secret", "email": "person@example.com", "query": map[string]any{"id": "123"}}).(map[string]any)
	raw, _ := json.Marshal(redacted)
	text := string(raw)
	for _, secret := range []string{"Bearer secret", "person@example.com", "\"clientSecret\":\"secret\""} {
		if strings.Contains(text, secret) {
			t.Fatalf("secret leaked: %s", text)
		}
	}
	old := queryAuditDataDir
	queryAuditDataDir = func() (string, error) { return "", errors.New("disk unavailable") }
	defer func() { queryAuditDataDir = old }()
	req := httptest.NewRequest("GET", "/?start_date=2026-10-01&end_date=2026-10-07", nil)
	span := newQueryAudit(req, "source", sourceConfig{RID: 123})
	result := map[string]any{"status": "failed"}
	span.finish(result, errors.New("query failed"))
	if result["audit_id"] == "" {
		t.Fatal("missing audit correlation after write failure")
	}
}

func TestQueryAuditRetentionCleanup(t *testing.T) {
	dir := withAuditTemp(t)
	auditDir := filepath.Join(dir, "query-audit")
	if err := os.MkdirAll(auditDir, 0700); err != nil {
		t.Fatal(err)
	}
	old := filepath.Join(auditDir, "2026-08-01.jsonl")
	recent := filepath.Join(auditDir, "2026-10-22.jsonl")
	_ = os.WriteFile(old, []byte("x"), 0600)
	_ = os.WriteFile(recent, []byte("x"), 0600)
	queryAuditNow = func() time.Time { return time.Date(2026, 10, 23, 0, 0, 0, 0, time.UTC) }
	cleanupQueryAuditsLocked(auditDir, queryAuditNow())
	if _, err := os.Stat(old); !os.IsNotExist(err) {
		t.Fatal("expired audit not removed")
	}
	if _, err := os.Stat(recent); err != nil {
		t.Fatal("recent audit removed")
	}
}

func TestQueryAuditDiagnosticsCorrelationAndContract(t *testing.T) {
	withAuditTemp(t)
	req := httptest.NewRequest("GET", "/?program=ET&tier=Top&region=NA&start_date=2026-10-01&end_date=2026-10-07", nil)
	span := newQueryAudit(req, "et_current_ccr_nfs", sourceConfig{AppID: 800414, RID: 2979783, SID: 1139137, TID: 999})
	span.setDefinition(map[string]any{"query": map[string]any{
		"dimensions": []any{map[string]any{"datasetFieldId": "1700017763323"}},
		"whereList":  []any{map[string]any{"id": "1700017763323", "op": "in", "val": []any{"7462465462811770896"}}},
	}})
	result := map[string]any{"status": "failed", "query_result": titanProbeStep{Status: "failed", RequestID: "req", QueryHistoryID: "history", HTTPStatus: 500, ErrorType: "upstream", ErrorMessage: "boom", QueuePollCount: 2, Columns: []string{"1700017763323"}}}
	span.finish(result, nil)
	for _, key := range []string{"audit_id", "query_history_id", "query_definition_hash"} {
		if strings.TrimSpace(asString(result[key])) == "" {
			t.Fatalf("missing %s", key)
		}
	}
}

func TestFirstDeepStringFindsHistoryAndSQL(t *testing.T) {
	payload := map[string]any{"data": map[string]any{"queryHistoryId": "1234567890123456789", "sql": "select 1"}}
	if got := firstDeepString(payload, "queryHistoryId"); got != "1234567890123456789" {
		t.Fatal(got)
	}
	if got := firstDeepString(payload, "sql"); got != "select 1" {
		t.Fatal(got)
	}
}
