// handler_sync.go — sync 资源的业务逻辑。
// 路由契约在 handler_sync.gen.go（由 IDL 生成，勿改）；此文件由你填实现。
//
// stub 目前直接返回 IDL 里的 response，让契约先跑通；
// Agent B 请用真实 store 读写替换每个 handler 内部。
package main

import "net/http"

// adminSyncCreate 处理 POST /api/admin/sync：按数据源和运行时筛选触发同步
func adminSyncCreate(w http.ResponseWriter, r *http.Request) {
	// TODO(Agent B): 替换为真实业务逻辑（读写 store、校验参数等）。
	writeJSON(w, http.StatusOK, map[string]any{
		"data": map[string]any{
			"status": "partial",
			"runs":   []any{},
		},
	})
}
