package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"testing"
	"time"
)

func makeETMembers(count int) []wbMember {
	members := make([]wbMember, 0, count)
	for i := 0; i < count; i++ {
		members = append(members, wbMember{AccountID: fmt.Sprintf("77%016d", i), TicketID: fmt.Sprintf("ticket-%d", i)})
	}
	return members
}

func TestETMoreThan1000UsesChunkedBatchAndMapsMissingFacts(t *testing.T) {
	wbTestEnv(t)
	oldMembers, oldBatch := wbLoadMembers, wbQueryETBatch
	defer func() { wbLoadMembers = oldMembers; wbQueryETBatch = oldBatch }()

	members := makeETMembers(2150)
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return members, true, nil
	}
	requests := 0
	wbQueryETBatch = func(_ context.Context, _ *http.Request, ids []string, _, _ string) (map[string]wbBatchMetric, error) {
		requests++
		if len(ids) > wbETMetricChunkSize {
			t.Fatalf("chunk too large: %d", len(ids))
		}
		out := make(map[string]wbBatchMetric, len(ids))
		for i, id := range ids {
			if i == 0 {
				out[id] = wbBatchMetric{Status: "no_data", Message: "no fact row"}
			} else {
				out[id] = wbBatchMetric{Status: "success", CCR: f64(4), NFS: f64(1)}
			}
		}
		return out, nil
	}
	config, _ := loadWBConfig()
	if config.MaxClients != 6000 {
		t.Fatalf("fixture must exercise the verified 5400-member THT production budget with a finite guard: %d", config.MaxClients)
	}
	request := wbRequest{Program: "ET", Start: "2026-10-01", End: "2026-10-21"}
	wbRunning["large-et"] = &wbJob{ID: "large-et", Principal: "Alice", Request: request, Rule: testRule(), Status: "running"}
	wbRunJob(wbReq("Alice"), "large-et", config)

	job, err := wbLookup("large-et", "Alice")
	if err != nil {
		t.Fatal(err)
	}
	if job.Status != "partial" || job.Members != 2150 || job.Done != 2150 || len(job.Rows) != 2150 || !job.Complete {
		t.Fatalf("large ET scan was truncated or blocked: status=%s members=%d done=%d rows=%d complete=%t error=%s", job.Status, job.Members, job.Done, len(job.Rows), job.Complete, job.Error)
	}
	if requests != 22 {
		t.Fatalf("expected 22 VQS chunks, got %d", requests)
	}
	noData := 0
	for _, row := range job.Rows {
		if row.MetricStatus == "no_data" {
			noData++
			if row.DataStatus != "No Fact" || row.CCR != nil || row.NFS != nil {
				t.Fatalf("missing fact was not explicit: %+v", row)
			}
		}
	}
	if noData != 22 {
		t.Fatalf("missing rows were not mapped per chunk: %d", noData)
	}
}

func TestETBatchErrorFailsScanExplicitlyAndKeepsMembershipSnapshot(t *testing.T) {
	wbTestEnv(t)
	oldMembers, oldBatch := wbLoadMembers, wbQueryETBatch
	defer func() { wbLoadMembers = oldMembers; wbQueryETBatch = oldBatch }()

	members := makeETMembers(101)
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return members, true, nil
	}
	calls := 0
	wbQueryETBatch = func(_ context.Context, _ *http.Request, ids []string, _, _ string) (map[string]wbBatchMetric, error) {
		calls++
		if calls == 2 {
			return nil, errors.New("VQS upstream failed")
		}
		out := map[string]wbBatchMetric{}
		for _, id := range ids {
			out[id] = wbBatchMetric{Status: "success", CCR: f64(1), NFS: f64(1)}
		}
		return out, nil
	}
	config, _ := loadWBConfig()
	wbRunning["failed-et"] = &wbJob{ID: "failed-et", Principal: "Alice", Request: wbRequest{Program: "ET"}, Rule: testRule(), Status: "running"}
	wbRunJob(wbReq("Alice"), "failed-et", config)

	job, err := wbLookup("failed-et", "Alice")
	if err != nil {
		t.Fatal(err)
	}
	if job.Status != "failed" || job.Members != 101 || !job.Complete || job.Error == "" || calls != 2 {
		t.Fatalf("query error was not explicit: %+v calls=%d", job, calls)
	}
}

func TestETBatchMappingRejectsMissingMapEntry(t *testing.T) {
	members := makeETMembers(2)
	_, err := wbRowsFromETBatch(members, map[string]wbBatchMetric{members[0].AccountID: {Status: "no_data"}}, wbRequest{Program: "ET"}, testRule())
	if err == nil {
		t.Fatal("missing account mapping was silently accepted")
	}
}

func TestETMetricMetadataDoesNotInventAdvertiserID(t *testing.T) {
	member := wbMember{AccountID: "7244006541899137025"}
	metrics := map[string]wbBatchMetric{
		member.AccountID: {Status: "success", CCR: f64(1), NFS: f64(2), AdvertiserID: "7000000000000000001", Region: "CNOB"},
	}
	rows, err := wbRowsFromETBatch([]wbMember{member}, metrics, wbRequest{Program: "ET"}, testRule())
	if err != nil || len(rows) != 1 {
		t.Fatalf("metadata mapping failed: rows=%#v err=%v", rows, err)
	}
	if rows[0].Member.AdvertiserID != "" || rows[0].Member.Region != "CNOB" {
		t.Fatalf("ET exposed an inapplicable advertiser_id or lost region: %+v", rows[0].Member)
	}

	member.Region = "NA"
	rows, err = wbRowsFromETBatch([]wbMember{member}, metrics, wbRequest{Program: "ET"}, testRule())
	if err != nil || rows[0].Member.Region != member.Region {
		t.Fatalf("explicit membership metadata was overwritten: rows=%#v err=%v", rows, err)
	}
}

func TestAuthoritativeAccountReportConfiguration(t *testing.T) {
	wbTestEnv(t)
	cfg, err := loadDataSourceConfig()
	if err != nil {
		t.Fatal(err)
	}
	for _, sourceName := range []string{"et_current_ccr_nfs", "st_current_ccr_nfs"} {
		source := cfg.Sources[sourceName]
		if source.RID != 2979783 || source.SID != 1139137 || source.Grain != "account_week" || source.Identity.IDDimension != "account_id" {
			t.Fatalf("%s is not Account authority: %+v", sourceName, source)
		}
		if _, hasAdvertiser := source.Fields["advertiser_id"]; hasAdvertiser {
			t.Fatalf("%s unexpectedly requires advertiser mapping", sourceName)
		}
	}
	revenue := cfg.Sources["account_current_revenue"]
	if revenue.RID != 2980054 || revenue.SID != 1139137 || revenue.Grain != "account_week" {
		t.Fatalf("Account Revenue authority mismatch: %+v", revenue)
	}
	if field := revenue.Fields["account_id"]; field.DimMetID != "1700017763323" || field.UniqueID != "261021155920059" {
		t.Fatalf("Account Revenue filter must use the report-local account_id field: %+v", field)
	}
	if cfg.Sources["weekly_pair_ccr_nfs"].RID != 2942519 || cfg.Sources["weekly_pair_revenue"].RID != 2942918 {
		t.Fatal("Advertiser detail reports changed")
	}
}

func TestETCurrentAPIExposesAuthoritativeAccountMetricsAndTrace(t *testing.T) {
	old := wbQueryETBatch
	defer func() { wbQueryETBatch = old }()
	const accountID = "7462465462811770896"
	wbQueryETBatch = func(_ context.Context, _ *http.Request, ids []string, start, end string) (map[string]wbBatchMetric, error) {
		if len(ids) != 1 || ids[0] != accountID || start != "2026-10-12" || end != "2026-10-18" {
			t.Fatalf("unexpected query: ids=%v window=%s..%s", ids, start, end)
		}
		return map[string]wbBatchMetric{accountID: {
			Status: "success", CCR: f64(8.552188750450918), NFS: f64(61), Revenue: f64(4080.989999999989),
			RequestID: "req-ccr", LogID: "log-ccr", RevenueRequestID: "req-revenue", RevenueLogID: "log-revenue",
			Source: map[string]any{"rid": 2979783, "sid": 1139137, "grain": "account_week", "revenue": map[string]any{"rid": 2980054}},
		}}, nil
	}
	data, status := queryETCurrent(context.Background(), wbReq("tester"), etCCRDiagnosticRequest{AccountID: accountID, StartDate: "2026-10-12", EndDate: "2026-10-18"})
	if status != http.StatusOK || data["status"] != "success" || data["authority_grain"] != "account_week" || data["request_id"] != "req-ccr" || data["log_id"] != "log-ccr" || data["revenue_request_id"] != "req-revenue" || data["revenue_log_id"] != "log-revenue" {
		t.Fatalf("API authority/trace mismatch: status=%d data=%+v", status, data)
	}
	if ccr, _ := data["dynamic_p0_ccr"].(*float64); ccr == nil || *ccr != 8.552188750450918 {
		t.Fatalf("CCR mismatch: %#v", data["dynamic_p0_ccr"])
	}
	if nfs, _ := data["p0_nfs"].(*float64); nfs == nil || *nfs != 61 {
		t.Fatalf("NFS mismatch: %#v", data["p0_nfs"])
	}
	if revenue, _ := data["revenue"].(*float64); revenue == nil || *revenue != 4080.989999999989 {
		t.Fatalf("Revenue mismatch: %#v", data["revenue"])
	}
}

func TestETCurrentAPIRejectsInvalidDateRangeWithoutQuery(t *testing.T) {
	old := wbQueryETBatch
	defer func() { wbQueryETBatch = old }()
	called := false
	wbQueryETBatch = func(context.Context, *http.Request, []string, string, string) (map[string]wbBatchMetric, error) {
		called = true
		return nil, nil
	}
	_, status := queryETCurrent(context.Background(), wbReq("tester"), etCCRDiagnosticRequest{AccountID: "7462465462811770896", StartDate: "2026-10-18", EndDate: "2026-10-12"})
	if status != http.StatusBadRequest || called {
		t.Fatalf("invalid date range status=%d called=%t", status, called)
	}
}

func TestETProgressIsPersistedAfterEachChunk(t *testing.T) {
	wbTestEnv(t)
	oldMembers, oldBatch := wbLoadMembers, wbQueryETBatch
	defer func() { wbLoadMembers = oldMembers; wbQueryETBatch = oldBatch }()

	members := makeETMembers(201)
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return members, true, nil
	}
	secondChunkStarted := make(chan struct{})
	releaseSecondChunk := make(chan struct{})
	calls := 0
	wbQueryETBatch = func(_ context.Context, _ *http.Request, ids []string, _, _ string) (map[string]wbBatchMetric, error) {
		calls++
		if calls == 2 {
			close(secondChunkStarted)
			<-releaseSecondChunk
		}
		out := make(map[string]wbBatchMetric, len(ids))
		for _, id := range ids {
			out[id] = wbBatchMetric{Status: "success", CCR: f64(1), NFS: f64(1)}
		}
		return out, nil
	}
	config, _ := loadWBConfig()
	request := wbRequest{Program: "ET", Start: "2026-10-01", End: "2026-10-21"}
	wbRunning["progress-et"] = &wbJob{ID: "progress-et", Principal: "Alice", Request: request, Rule: testRule(), Status: "running", Stage: "loading_members"}
	finished := make(chan struct{})
	go func() {
		wbRunJob(wbReq("Alice"), "progress-et", config)
		close(finished)
	}()

	select {
	case <-secondChunkStarted:
	case <-time.After(2 * time.Second):
		t.Fatal("second ET chunk did not start")
	}
	disk, err := wbReadDisk()
	if err != nil {
		t.Fatal(err)
	}
	persisted := disk.Jobs["progress-et"]
	if persisted.Members != 201 || persisted.Done != 100 || persisted.Stage != "querying_metrics:1/3" {
		t.Fatalf("cross-instance progress is stale: members=%d done=%d stage=%s", persisted.Members, persisted.Done, persisted.Stage)
	}
	close(releaseSecondChunk)
	select {
	case <-finished:
	case <-time.After(2 * time.Second):
		t.Fatal("ET scan did not finish after releasing the chunk")
	}
}

func TestAccountReportsRunInParallelWithinChunk(t *testing.T) {
	oldProbe := accountVQSProbe
	defer func() { accountVQSProbe = oldProbe }()

	started := make(chan string, 2)
	release := make(chan struct{})
	accountVQSProbe = func(_ context.Context, _ *http.Request, source string) (map[string]any, error) {
		started <- source
		<-release
		row := map[string]any{"account_id": "7462465462811770896"}
		if source == "account_current_revenue" {
			row["revenue"] = 10.0
		} else {
			row["dynamic_p0_ccr"] = 1.0
			row["p0_nfs"] = 2.0
		}
		return map[string]any{"status": "ok", "business_rows": []map[string]any{row}}, nil
	}

	type queryResult struct {
		metrics map[string]wbBatchMetric
		err     error
	}
	result := make(chan queryResult, 1)
	go func() {
		metrics, err := queryETCurrentBatch(context.Background(), wbReq("Alice"), []string{"7462465462811770896"}, "2026-10-12", "2026-10-18")
		result <- queryResult{metrics: metrics, err: err}
	}()
	seen := map[string]bool{}
	for i := 0; i < 2; i++ {
		select {
		case source := <-started:
			seen[source] = true
		case <-time.After(time.Second):
			t.Fatal("Account Saved Reports were queried serially")
		}
	}
	close(release)
	got := <-result
	if got.err != nil {
		t.Fatal(got.err)
	}
	metric := got.metrics["7462465462811770896"]
	if !seen["et_current_ccr_nfs"] || !seen["account_current_revenue"] || metric.CCR == nil || metric.NFS == nil || metric.Revenue == nil {
		t.Fatalf("parallel Account query result incomplete: seen=%v metric=%+v", seen, metric)
	}
}

func TestAccountRevenueFailureDoesNotBlockCCRNFS(t *testing.T) {
	oldProbe := accountVQSProbe
	defer func() { accountVQSProbe = oldProbe }()
	accountVQSProbe = func(_ context.Context, _ *http.Request, source string) (map[string]any, error) {
		if source == "account_current_revenue" {
			return map[string]any{"status": "failed", "requestId": "revenue-request"}, errors.New("revenue unavailable")
		}
		return map[string]any{"status": "ok", "report_id": 2979783, "business_rows": []map[string]any{{"account_id": "7462465462811770896", "dynamic_p0_ccr": 1.0, "p0_nfs": 2.0}}}, nil
	}
	got, err := queryETCurrentBatch(context.Background(), wbReq("Alice"), []string{"7462465462811770896"}, "2026-10-12", "2026-10-18")
	if err != nil {
		t.Fatal(err)
	}
	metric := got["7462465462811770896"]
	if metric.Status != "success" || metric.CCR == nil || metric.NFS == nil || metric.Revenue != nil || metric.RevenueStatus != "source_error" || metric.RevenueError == "" {
		t.Fatalf("Revenue failure blocked or hid CCR/NFS: %+v", metric)
	}
}

func TestETCurrentAPIReturns200WhenOnlyRevenueFails(t *testing.T) {
	old := wbQueryETBatch
	defer func() { wbQueryETBatch = old }()
	wbQueryETBatch = func(context.Context, *http.Request, []string, string, string) (map[string]wbBatchMetric, error) {
		return map[string]wbBatchMetric{"7462465462811770896": {Status: "success", CCR: f64(1), NFS: f64(2), RevenueStatus: "source_error", RevenueError: "revenue unavailable"}}, nil
	}
	data, status := queryETCurrent(context.Background(), wbReq("tester"), etCCRDiagnosticRequest{AccountID: "7462465462811770896", StartDate: "2026-10-12", EndDate: "2026-10-18"})
	if status != http.StatusOK || data["status"] != "success" || data["revenue_status"] != "source_error" || data["revenue_error"] == "" {
		t.Fatalf("independent Revenue failure changed API status: status=%d data=%+v", status, data)
	}
}
