package main

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"sort"
	"strings"
	"time"
)

const reportVersionsTable = "tap_report_versions"
const reportContentChunksTable = "tap_report_content_chunks"
const reportContentChunkSize = 240

type reportVersion struct {
	ReportID    string `json:"report_id"`
	Version     string `json:"version"`
	Owner       string `json:"owner"`
	CreatedAt   string `json:"created_at"`
	GeneratedAt string `json:"generated_at"`
	DataAsOf    string `json:"data_as_of"`
	FiltersJSON string `json:"filters_json"`
	ContentHTML string `json:"content_html"`
	ContentHash string `json:"content_hash"`
	Title       string `json:"title"`
	Period      string `json:"period"`
	SharePath   string `json:"share_path,omitempty"`
}

func newReportID() (string, error) {
	buf := make([]byte, 18)
	if _, err := rand.Read(buf); err != nil {
		return "", err
	}
	return "rpt_" + hex.EncodeToString(buf), nil
}

func reportCloudStore() (*cloudStore, error) {
	store, err := newCloudStore()
	if err != nil {
		return nil, fmt.Errorf("Cloud DB 不可用，报告未保存：%w", err)
	}
	return store, nil
}

func encodeReportHTML(raw string) (string, error) {
	var compressed bytes.Buffer
	zw := gzip.NewWriter(&compressed)
	if _, err := zw.Write([]byte(raw)); err != nil {
		return "", err
	}
	if err := zw.Close(); err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(compressed.Bytes()), nil
}

func decodeReportHTML(encoded string) (string, error) {
	payload, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return "", err
	}
	zr, err := gzip.NewReader(bytes.NewReader(payload))
	if err != nil {
		return "", err
	}
	defer zr.Close()
	plain, err := io.ReadAll(zr)
	return string(plain), err
}

func insertReportVersion(ctx context.Context, store *cloudStore, v reportVersion) error {
	encoded, err := encodeReportHTML(v.ContentHTML)
	if err != nil {
		return fmt.Errorf("报告内容压缩失败: %w", err)
	}
	parts := make([]string, 0, (len(encoded)+reportContentChunkSize-1)/reportContentChunkSize)
	for start := 0; start < len(encoded); start += reportContentChunkSize {
		end := start + reportContentChunkSize
		if end > len(encoded) {
			end = len(encoded)
		}
		parts = append(parts, encoded[start:end])
	}
	for index, part := range parts {
		body := map[string]any{"report_id": v.ReportID, "chunk_index": index, "content_chunk": part}
		if _, err = store.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+reportContentChunksTable+"/records", body); err != nil {
			return fmt.Errorf("报告内容分片 %d/%d 保存失败: %w", index+1, len(parts), err)
		}
	}
	body := map[string]any{"report_id": v.ReportID, "owner": v.Owner, "created_at": v.CreatedAt, "generated_at": v.GeneratedAt, "data_as_of": v.DataAsOf, "filters_json": v.FiltersJSON, "content_html": "", "content_encoding": "gzip-base64-chunks", "content_parts": len(parts), "content_hash": v.ContentHash, "title": v.Title, "period": v.Period}
	_, err = store.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+reportVersionsTable+"/records", body)
	return err
}

func getReportVersion(ctx context.Context, store *cloudStore, reportID string) (reportVersion, error) {
	resp, err := store.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+reportVersionsTable+"/query", map[string]any{"filters": []any{map[string]any{"field": "report_id", "operator": "eq", "value": reportID}}, "limit": 1, "offset": 0})
	if err != nil {
		return reportVersion{}, err
	}
	data, _ := resp["data"].(map[string]any)
	records, _ := data["records"].([]any)
	if len(records) == 0 {
		return reportVersion{}, errors.New("report not found")
	}
	m, ok := toMap(records[0])
	if !ok {
		return reportVersion{}, errors.New("invalid report record")
	}
	contentHTML := asString(m["content_html"])
	encoding := asString(m["content_encoding"])
	if encoding == "gzip-base64-chunks" {
		chunkResp, chunkErr := store.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+reportContentChunksTable+"/query", map[string]any{"filters": []any{map[string]any{"field": "report_id", "operator": "eq", "value": reportID}}, "limit": 1000, "offset": 0})
		if chunkErr != nil {
			return reportVersion{}, fmt.Errorf("报告内容分片读取失败: %w", chunkErr)
		}
		chunkData, _ := chunkResp["data"].(map[string]any)
		chunkRecords, _ := chunkData["records"].([]any)
		type indexedChunk struct {
			index int
			value string
		}
		chunks := make([]indexedChunk, 0, len(chunkRecords))
		for _, record := range chunkRecords {
			chunk, ok := toMap(record)
			if ok {
				chunks = append(chunks, indexedChunk{index: int(asInt64(chunk["chunk_index"])), value: asString(chunk["content_chunk"])})
			}
		}
		sort.Slice(chunks, func(i, j int) bool { return chunks[i].index < chunks[j].index })
		var joined strings.Builder
		for _, chunk := range chunks {
			joined.WriteString(chunk.value)
		}
		decoded, decodeErr := decodeReportHTML(joined.String())
		if decodeErr != nil {
			return reportVersion{}, fmt.Errorf("报告内容解压失败: %w", decodeErr)
		}
		contentHTML = decoded
	} else if encoding == "gzip-base64" {
		decoded, decodeErr := decodeReportHTML(contentHTML)
		if decodeErr != nil {
			return reportVersion{}, fmt.Errorf("报告内容解压失败: %w", decodeErr)
		}
		contentHTML = decoded
	}
	v := reportVersion{ReportID: asString(m["report_id"]), Owner: asString(m["owner"]), CreatedAt: asString(m["created_at"]), GeneratedAt: asString(m["generated_at"]), DataAsOf: asString(m["data_as_of"]), FiltersJSON: asString(m["filters_json"]), ContentHTML: contentHTML, ContentHash: asString(m["content_hash"]), Title: asString(m["title"]), Period: asString(m["period"])}
	v.Version = v.ReportID
	v.SharePath = "/reports/" + v.ReportID
	return v, nil
}

func workbenchAnalyticsReportsCreateHandler(w http.ResponseWriter, r *http.Request) {
	if !cwAnalyticsAuthorized(w, r) {
		return
	}
	x, err := cwAnalyticsBuild(cwAnalyticsFilters(r))
	if err != nil {
		cwWriteError(w, err)
		return
	}
	cwAttachQuota(&x, r)
	now := time.Now().UTC().Format(time.RFC3339)
	x.GeneratedAt = now
	content := cwAnalyticsHTML(x)
	hash := sha256.Sum256([]byte(content))
	filters, err := json.Marshal(x.Filters)
	if err != nil {
		cwWriteError(w, err)
		return
	}
	id, err := newReportID()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	owner := strings.TrimSpace(requestUsername(r))
	period := x.Filters.Start + " 至 " + x.Filters.End
	v := reportVersion{ReportID: id, Version: id, Owner: owner, CreatedAt: now, GeneratedAt: now, DataAsOf: x.AsOf, FiltersJSON: string(filters), ContentHTML: content, ContentHash: hex.EncodeToString(hash[:]), Title: "TAP 初步治理分析报告", Period: period, SharePath: "/reports/" + id}
	store, err := reportCloudStore()
	if err != nil {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": err.Error()})
		return
	}
	if err = insertReportVersion(r.Context(), store, v); err != nil {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": "Cloud DB 保存失败，未创建本地替代版本：" + err.Error()})
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{"data": v})
}

func workbenchAnalyticsReportsByReportIdGetHandler(w http.ResponseWriter, r *http.Request) {
	if !cwAnalyticsAuthorized(w, r) {
		return
	}
	id := strings.TrimSpace(r.PathValue("report_id"))
	if id == "" {
		id = strings.TrimPrefix(r.URL.Path, "/api/workbench/analytics/reports/")
	}
	store, err := reportCloudStore()
	if err != nil {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": err.Error()})
		return
	}
	v, err := getReportVersion(r.Context(), store, id)
	if err != nil {
		if strings.Contains(err.Error(), "not found") {
			writeJSON(w, http.StatusNotFound, map[string]any{"error": "报告版本不存在"})
			return
		}
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": "Cloud DB 读取失败：" + err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"data": v})
}
