package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
)

type wbReportedReasonsRefreshRequest struct {
	AccountID    string `json:"account_id"`
	AdvertiserID string `json:"advertiser_id"`
	BatchID      string `json:"batch_id"`
}

type wbReportedReasonTarget struct {
	JobID      string
	BatchID    string
	StartDate  string
	EndDate    string
	AccountID  string
	Advertiser string
}

func wbFindReportedReasonTarget(state wbDisk, accountID, advertiserID, batchID string) (wbReportedReasonTarget, error) {
	var selected wbReportedReasonTarget
	for jobID, job := range state.Jobs {
		if !strings.EqualFold(job.Request.Program, "ET") || batchID != "" && job.BatchID != batchID {
			continue
		}
		found := false
		for _, row := range job.Rows {
			if row.Member.AccountID != accountID {
				continue
			}
			for _, item := range append(append([]wbAdvertiserEvidence(nil), row.Advertisers...), row.AdvertiserTop10...) {
				if item.AccountID == accountID && item.AdvertiserID == advertiserID {
					found = true
					break
				}
			}
			if found {
				break
			}
		}
		if !found {
			continue
		}
		candidate := wbReportedReasonTarget{JobID: jobID, BatchID: job.BatchID, StartDate: job.Request.Start, EndDate: job.Request.End, AccountID: accountID, Advertiser: advertiserID}
		if selected.JobID == "" || candidate.StartDate > selected.StartDate || candidate.StartDate == selected.StartDate && job.AsOf > state.Jobs[selected.JobID].AsOf {
			selected = candidate
		}
	}
	if selected.JobID == "" {
		return wbReportedReasonTarget{}, fmt.Errorf("ET Account/Advertiser pair not found in persisted weekly rows")
	}
	if !validDate(selected.StartDate) || !validDate(selected.EndDate) || selected.EndDate < selected.StartDate {
		return wbReportedReasonTarget{}, fmt.Errorf("persisted Current Time Window is invalid")
	}
	return selected, nil
}

func wbUpdateReasonEvidence(items []wbAdvertiserEvidence, accountID, advertiserID string, refreshed wbAdvertiserEvidence) (int, []wbAdvertiserEvidence) {
	out := append([]wbAdvertiserEvidence(nil), items...)
	updated := 0
	for i := range out {
		if out[i].AccountID != accountID || out[i].AdvertiserID != advertiserID {
			continue
		}
		if refreshed.ReportedReasonsStatus == metricFailed && out[i].ReportedReasonsStatus == metricAvailable {
			// Keep the last successful Top3 while making the newest query failure explicit.
			out[i].ReportedReasonsStatus = metricFailed
			out[i].ReportedReasonsError = refreshed.ReportedReasonsError
		} else {
			out[i].ReportedReasons = append([]reportedReason(nil), refreshed.ReportedReasons...)
			out[i].ReportedReasonsStatus = refreshed.ReportedReasonsStatus
			out[i].ReportedReasonsError = refreshed.ReportedReasonsError
			out[i].ReportedReasonsBasis = refreshed.ReportedReasonsBasis
		}
		updated++
	}
	return updated, out
}

func wbPersistTargetedReportedReasons(target wbReportedReasonTarget, refreshed wbAdvertiserEvidence) (int, error) {
	wbMu.Lock()
	defer wbMu.Unlock()
	state, err := wbReadDisk()
	if err != nil {
		return 0, err
	}
	job, ok := state.Jobs[target.JobID]
	if !ok {
		return 0, fmt.Errorf("target ET job no longer exists")
	}
	updatedRows := 0
	for i := range job.Rows {
		if job.Rows[i].Member.AccountID != target.AccountID {
			continue
		}
		advertiserCount, advertisers := wbUpdateReasonEvidence(job.Rows[i].Advertisers, target.AccountID, target.Advertiser, refreshed)
		top10Count, top10 := wbUpdateReasonEvidence(job.Rows[i].AdvertiserTop10, target.AccountID, target.Advertiser, refreshed)
		if advertiserCount+top10Count > 0 {
			job.Rows[i].Advertisers = advertisers
			job.Rows[i].AdvertiserTop10 = top10
			updatedRows++
		}
	}
	if updatedRows == 0 {
		return 0, fmt.Errorf("target ET pair disappeared before persistence")
	}
	state.Jobs[target.JobID] = job
	if err := wbWriteDisk(state); err != nil {
		return 0, err
	}
	return updatedRows, nil
}

func wbRefreshReportedReasons(ctx context.Context, request *http.Request, body wbReportedReasonsRefreshRequest) (map[string]any, error) {
	body.AccountID = strings.TrimSpace(body.AccountID)
	body.AdvertiserID = strings.TrimSpace(body.AdvertiserID)
	body.BatchID = strings.TrimSpace(body.BatchID)
	if !decimalID.MatchString(body.AccountID) || !decimalID.MatchString(body.AdvertiserID) || body.AdvertiserID == "0" {
		return nil, fmt.Errorf("account_id and advertiser_id must be valid decimal IDs")
	}
	wbMu.Lock()
	state, err := wbReadDisk()
	wbMu.Unlock()
	if err != nil {
		return nil, err
	}
	target, err := wbFindReportedReasonTarget(state, body.AccountID, body.AdvertiserID, body.BatchID)
	if err != nil {
		return nil, err
	}
	rows, complete, queryReason := queryReportedReasonRows(ctx, request, []string{body.AdvertiserID}, "advertiser_id", target.StartDate, target.EndDate)
	evidence := map[string][]wbAdvertiserEvidence{body.AccountID: {{AccountID: body.AccountID, AdvertiserID: body.AdvertiserID}}}
	if err := attachReportedReasons(evidence, rows, complete, queryReason); err != nil {
		return nil, err
	}
	refreshed := evidence[body.AccountID][0]
	updatedRows, persistErr := wbPersistTargetedReportedReasons(target, refreshed)
	if persistErr != nil {
		return nil, persistErr
	}
	basis := ""
	if refreshed.ReportedReasonsBasis == "p0_ccr_desc" {
		basis = "CCR"
	} else if refreshed.ReportedReasonsBasis == "nfs_fallback_all_ccr_null" {
		basis = "NFS"
	}
	result := map[string]any{
		"status": refreshed.ReportedReasonsStatus, "account_id": body.AccountID, "advertiser_id": body.AdvertiserID,
		"batch_id": target.BatchID, "current_window": map[string]string{"start_date": target.StartDate, "end_date": target.EndDate},
		"reason_status": refreshed.ReportedReasonsStatus, "reason_error": refreshed.ReportedReasonsError,
		"valid_reason_count": len(refreshed.ReportedReasons), "sort_basis": basis, "reported_reasons": refreshed.ReportedReasons,
		"updated_rows": updatedRows, "targeted_only": true,
		"side_effects": map[string]bool{"case_status": false, "actions": false, "notifications": false},
	}
	if !complete {
		return result, fmt.Errorf("%s", queryReason)
	}
	return result, nil
}

func wbReportedReasonsRefreshHandler(w http.ResponseWriter, r *http.Request) {
	var body wbReportedReasonsRefreshRequest
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "invalid JSON body"})
		return
	}
	result, err := wbRefreshReportedReasons(r.Context(), r, body)
	if err != nil {
		logMsg(fmt.Sprintf("[reported-reasons-refresh] account_id=%s advertiser_id=%s targeted_only=true error=%s", sanitizeLogText(body.AccountID), sanitizeLogText(body.AdvertiserID), sanitizeLogText(err.Error())), "plugin")
		status := http.StatusUnprocessableEntity
		if result != nil {
			status = http.StatusBadGateway
		}
		writeJSON(w, status, map[string]any{"error": err.Error(), "data": result})
		return
	}
	logMsg(fmt.Sprintf("[reported-reasons-refresh] account_id=%s advertiser_id=%s window=%s..%s count=%v basis=%v targeted_only=true", body.AccountID, body.AdvertiserID, result["current_window"].(map[string]string)["start_date"], result["current_window"].(map[string]string)["end_date"], result["valid_reason_count"], result["sort_basis"]), "plugin")
	writeJSON(w, http.StatusOK, map[string]any{"data": result})
}
