package main

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/mail"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type cwRuntimeNotification struct {
	NotificationMode string        `json:"notification_mode"`
	TestRecipients   []cwRecipient `json:"test_recipients"`
	UpdatedAt        string        `json:"updated_at"`
	UpdatedBy        string        `json:"updated_by"`
}

var cwRuntimeMu sync.Mutex

func cwRuntimePath() (string, error) {
	d := strings.TrimSpace(os.Getenv("AIME_PLUGIN_DATA_DIR"))
	if d == "" {
		return "", errors.New("AIME_PLUGIN_DATA_DIR 未设置")
	}
	return filepath.Join(d, "casework_notification.json"), nil
}
func cwLoadRuntimeNotification() (cwRuntimeNotification, error) {
	var x cwRuntimeNotification
	p, e := cwRuntimePath()
	if e != nil {
		return x, e
	}
	b, e := os.ReadFile(p)
	if os.IsNotExist(e) {
		return x, nil
	}
	if e != nil {
		return x, e
	}
	e = json.Unmarshal(b, &x)
	return x, e
}
func cwApplyRuntimeNotification(c *cwConfig) error {
	x, e := cwLoadRuntimeNotification()
	if e != nil {
		return e
	}
	if x.NotificationMode != "" {
		c.NotificationMode = x.NotificationMode
	}
	if x.TestRecipients != nil {
		c.TestRecipients = x.TestRecipients
	}
	return nil
}
func cwSaveRuntimeNotification(x cwRuntimeNotification) error {
	cwRuntimeMu.Lock()
	defer cwRuntimeMu.Unlock()
	p, e := cwRuntimePath()
	if e != nil {
		return e
	}
	if e = os.MkdirAll(filepath.Dir(p), 0700); e != nil {
		return e
	}
	b, _ := json.MarshalIndent(x, "", "  ")
	tmp, e := os.OpenFile(p+".tmp", os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	ok := false
	defer func() {
		tmp.Close()
		if !ok {
			os.Remove(tmp.Name())
		}
	}()
	if _, e = tmp.Write(b); e != nil {
		return e
	}
	if e = tmp.Sync(); e != nil {
		return e
	}
	if e = tmp.Close(); e != nil {
		return e
	}
	if e = os.Rename(tmp.Name(), p); e != nil {
		return e
	}
	ok = true
	return os.Chmod(p, 0600)
}
func resolveSingleOpenID(ctx context.Context, email string) (string, error) {
	id, status := cwResolveOpenID(ctx, email)
	if status != "resolved" {
		return "", errors.New("邮箱未解析到唯一 Bot 用户；请检查应用可用范围、通讯录权限及账号状态：" + status)
	}
	return id, nil
}

func feishuTestRecipientHandler(w http.ResponseWriter, r *http.Request) {
	if _, ok := requireCredentialAdmin(w, r); !ok {
		return
	}
	var in struct {
		Email string `json:"email"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 2048)).Decode(&in) != nil {
		cwWriteError(w, cwErr(400, "无效请求"))
		return
	}
	rawEmails := strings.FieldsFunc(strings.ToLower(strings.TrimSpace(in.Email)), func(r rune) bool { return r == ',' || r == ';' || r == '\n' || r == '\r' })
	if len(rawEmails) == 0 || len(rawEmails) > 20 {
		cwWriteError(w, cwErr(400, "请输入 1–20 个完整企业邮箱"))
		return
	}
	emails := []string{}
	for _, raw := range rawEmails {
		raw = strings.TrimSpace(raw)
		a, err := mail.ParseAddress(raw)
		if err != nil || a.Address != raw {
			cwWriteError(w, cwErr(400, "请输入完整企业邮箱，多个邮箱用逗号或换行分隔"))
			return
		}
		emails = append(emails, a.Address)
	}
	ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
	defer cancel()
	x, _ := cwLoadRuntimeNotification()
	x.NotificationMode = "test"
	x.UpdatedAt = cwNow()
	x.UpdatedBy = requestUsername(r)
	seen := map[string]bool{}
	for _, recipient := range x.TestRecipients {
		seen[recipient.ID] = true
	}
	masked := []string{}
	for _, email := range emails {
		id, err := resolveSingleOpenID(ctx, email)
		if err != nil {
			cwWriteError(w, cwErr(400, email+": "+err.Error()))
			return
		}
		if !seen[id] {
			x.TestRecipients = append(x.TestRecipients, cwRecipient{ID: id, Type: "open_id", Label: "测试：" + cwMaskEmail(email)})
			seen[id] = true
		}
		masked = append(masked, cwMaskEmail(email))
	}
	if e := cwSaveRuntimeNotification(x); e != nil {
		cwWriteError(w, cwErr(500, "测试接收人解析成功，但持久化失败"))
		return
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"notification_mode": "test", "recipient_count": len(x.TestRecipients), "recipient_type": "open_id", "emails_masked": masked, "submitter_fallback": false, "group_targets": 0, "updated_at": x.UpdatedAt}})
}

// feishuTestMessageHandler sends a fixed, non-sensitive plain-text probe only to
// the single recipient stored by the backend test-recipient flow.
func feishuTestMessageHandler(w http.ResponseWriter, r *http.Request) {
	cfg, err := cwLoadConfig()
	if err != nil || !cwOperator(cfg, requestUsername(r)) {
		cwWriteError(w, cwErr(http.StatusForbidden, "仅运营可执行飞书测试消息"))
		return
	}
	if cfg.NotificationMode != "test" || cfg.AutoSendEnabled {
		cwWriteError(w, cwErr(http.StatusConflict, "必须处于 test 模式且 auto_send_enabled=false"))
		return
	}
	var body struct {
		Email string `json:"email"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		cwWriteError(w, cwErr(http.StatusBadRequest, "请求体无效"))
		return
	}
	address, err := mail.ParseAddress(strings.TrimSpace(body.Email))
	if err != nil || !strings.Contains(address.Address, "@") {
		cwWriteError(w, cwErr(http.StatusBadRequest, "测试接收人邮箱无效"))
		return
	}
	openID, resolution := cwResolveOpenID(r.Context(), address.Address)
	if resolution != "resolved" {
		cwWriteError(w, cwErr(http.StatusBadGateway, "测试接收人 open_id 解析失败: "+resolution))
		return
	}
	allowed := false
	for _, recipient := range cfg.TestRecipients {
		if recipient.Type == "open_id" && recipient.ID == openID {
			allowed = true
			break
		}
	}
	if !allowed {
		cwWriteError(w, cwErr(http.StatusForbidden, "解析出的接收人不在后端测试白名单中"))
		return
	}
	token, err := cwAccessToken(r.Context())
	if err != nil {
		cwWriteError(w, cwErr(http.StatusBadGateway, "Bot token 获取失败"))
		return
	}
	sentAt := time.Now().UTC().Format(time.RFC3339)
	contentBytes, _ := json.Marshal(map[string]string{"text": "[TEST] TAP Governance Workbench 飞书通知链路测试。该消息不包含客户信息。发送时间：" + sentAt})
	apiResponse, err := cwHTTP(r.Context(), http.MethodPost, "/open-apis/im/v1/messages?receive_id_type=open_id", token, map[string]any{
		"receive_id": openID,
		"msg_type":   "text",
		"content":    string(contentBytes),
	})
	if err != nil {
		cwWriteError(w, cwErr(http.StatusBadGateway, "飞书测试消息发送失败: "+cwSafeAPIMessage(err.Error(), token)))
		return
	}
	data, _ := apiResponse["data"].(map[string]any)
	messageID := strings.TrimSpace(asString(data["message_id"]))
	if messageID == "" {
		cwWriteError(w, cwErr(http.StatusBadGateway, "飞书返回成功但缺少 message_id"))
		return
	}
	logMsg("[feishu-test-message] sent message_id="+cwMaskID(messageID)+" recipient="+cwMaskID(openID), "plugin")
	writeJSON(w, http.StatusOK, map[string]any{"data": map[string]any{
		"mode":       "test",
		"message_id": messageID,
		"sent_at":    sentAt,
		"recipient": map[string]any{
			"email_masked":    cwMaskEmail(address.Address),
			"open_id_masked":  cwMaskID(openID),
			"whitelist_match": true,
		},
		"api_response": map[string]any{"code": apiResponse["code"], "msg": apiResponse["msg"]},
	}})
}
