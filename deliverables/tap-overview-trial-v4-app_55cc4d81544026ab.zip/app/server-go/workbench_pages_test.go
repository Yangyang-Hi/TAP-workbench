package main

import (
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"testing"
)

func TestPageHistoryScopeAndLimit(t *testing.T) {
	wbTestEnv(t)
	disk := wbDisk{Jobs: map[string]wbJob{}, Actions: map[string]wbAction{}}
	for i := 0; i < 12; i++ {
		id := fmt.Sprintf("a-%02d", i)
		disk.Jobs[id] = wbJob{ID: id, Principal: "Alice", StartedAt: fmt.Sprintf("2026-10-%02dT01:00:00Z", i+1), Rows: []wbRow{{ID: id}}}
		disk.Actions[id] = wbAction{AlertID: id, Principal: "Alice", Note: "own"}
	}
	disk.Jobs["private"] = wbJob{ID: "private", Principal: "Bob", StartedAt: "2026-10-19T01:00:00Z", Rows: []wbRow{{ID: "private"}}}
	disk.Actions["private"] = wbAction{AlertID: "private", Principal: "Bob", Note: "not visible"}
	if err := wbWriteDisk(disk); err != nil {
		t.Fatal(err)
	}
	w := httptest.NewRecorder()
	wbHistoryHandler(w, wbReq("Alice"))
	var response struct {
		Data struct {
			Scans   []wbJob             `json:"scans"`
			Actions map[string]wbAction `json:"actions"`
		}
	}
	if err := json.Unmarshal(w.Body.Bytes(), &response); err != nil {
		t.Fatal(err)
	}
	if w.Code != 200 || len(response.Data.Scans) != 10 || len(response.Data.Actions) != 10 {
		t.Fatalf("bad history: %s", w.Body.String())
	}
	if response.Data.Scans[0].ID != "private" {
		t.Fatal("history is not newest first")
	}
	foundShared := false
	for _, j := range response.Data.Scans {
		if j.Principal != "Alice" {
			foundShared = true
		}
	}
	if !foundShared {
		t.Fatal("shared scan missing")
	}
	if _, ok := response.Data.Actions["private"]; !ok {
		t.Fatal("shared action missing")
	}
}
func TestQuotaPageUsesConfirmedQ4BaselineWithoutInventingUsage(t *testing.T) {
	wbTestEnv(t)
	quota, ok := wbQuotaBaseline().(map[string]any)
	if !ok {
		t.Fatal("quota baseline missing")
	}
	if quota["status"] != "confirmed" || quota["period"] != "2026 Q4" {
		t.Fatalf("confirmed Q4 baseline missing: %#v", quota)
	}
	if _, exists := quota["used"]; exists {
		t.Fatal("quota usage invented")
	}
}
