// CODE GENERATED FROM app/api/api.yaml BY tools/gen_api.py — DO NOT EDIT
package main

import "net/http"

// 本文件由 IDL 生成，登记 casework 资源的路由契约。
// 业务逻辑写在 handler_casework.go 的 handler 函数里，不要改本文件。
func init() {
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/integrations/feishu/card-callback",
		Summary: "飞书新版加密卡片回调，独立签名和身份校验，不要求浏览器JWT",
		Handler: integrationsFeishuCardCallbackCreate,
		Public:  true,
		Tags:    []string{"casework", "feishu"},
		BodyParams: []Param{
			{Name: "encrypt", Type: "string", Required: true},
		},
		Response: map[string]any{
			"toast": map[string]any{},
			"card":  map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/integrations/feishu/config-status",
		Summary: "管理员读取飞书 Bot 凭证配置状态（永不返回 Secret 或 Token）",
		Handler: integrationsFeishuConfigStatusList,
		Tags:    []string{"integrations", "feishu"},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/integrations/feishu/credentials",
		Summary: "管理员验证并原子保存飞书 Bot 凭证",
		Handler: integrationsFeishuCredentialsCreate,
		Tags:    []string{"integrations", "feishu"},
		BodyParams: []Param{
			{Name: "app_id", Type: "string", Required: true},
			{Name: "app_secret", Type: "string", Required: true},
		},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/integrations/feishu/test-message",
		Summary: "管理员仅向后端测试白名单中的指定邮箱发送无客户信息纯文本测试消息",
		Handler: integrationsFeishuTestMessageCreate,
		Tags:    []string{"integrations", "feishu"},
		BodyParams: []Param{
			{Name: "email", Type: "string", Required: true},
		},
		Response: map[string]any{
			"data": map[string]any{
				"mode":         "test",
				"message_id":   "",
				"sent_at":      "",
				"recipient":    map[string]any{},
				"api_response": map[string]any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/integrations/feishu/test-recipient",
		Summary: "管理员按完整企业邮箱解析并保存唯一测试接收人，启用 test 模式",
		Handler: integrationsFeishuTestRecipientCreate,
		Tags:    []string{"integrations", "feishu"},
		BodyParams: []Param{
			{Name: "email", Type: "string", Required: true},
		},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/analytics",
		Summary: "运营按共享事件台账查询治理分析",
		Handler: workbenchAnalyticsList,
		Tags:    []string{"casework"},
		QueryParams: []Param{
			{Name: "time_mode", Type: "string", Description: "weekly 或 custom；custom 不创建事件，因此报告返回空事件范围"},
			{Name: "batch_id", Type: "string"},
			{Name: "case_scope", Type: "string"},
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
			{Name: "program", Type: "string"},
			{Name: "tier", Type: "string"},
			{Name: "submitter", Type: "string"},
			{Name: "owner", Type: "string"},
			{Name: "advertiser_id", Type: "string"},
			{Name: "account_id", Type: "string"},
			{Name: "search", Type: "string"},
			{Name: "date_field", Type: "string"},
			{Name: "level", Type: "string"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"summary":             map[string]any{},
				"notification":        map[string]any{},
				"notification_source": map[string]any{},
				"outcomes": map[string]any{
					"notification_complete": map[string]any{},
					"case_closed":           map[string]any{},
					"risk_improved":         map[string]any{},
				},
				"effect_status":    map[string]any{},
				"rule_summaries":   []any{},
				"priority_clients": []any{},
				"top20_candidates": []any{},
				"batch_status": map[string]any{
					"label":      "阶段性结果",
					"incomplete": true,
					"programs":   []any{},
				},
				"quota_alerts": map[string]any{
					"et": map[string]any{},
					"st": map[string]any{},
				},
				"cases":              []any{},
				"case_presentations": map[string]any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/analytics/export",
		Summary: "运营按同一筛选口径导出治理分析Excel",
		Handler: workbenchAnalyticsExportList,
		Tags:    []string{"casework"},
		QueryParams: []Param{
			{Name: "time_mode", Type: "string"},
			{Name: "batch_id", Type: "string"},
			{Name: "case_scope", Type: "string"},
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
			{Name: "program", Type: "string"},
			{Name: "tier", Type: "string"},
			{Name: "submitter", Type: "string"},
			{Name: "owner", Type: "string"},
			{Name: "advertiser_id", Type: "string"},
			{Name: "account_id", Type: "string"},
			{Name: "search", Type: "string"},
			{Name: "date_field", Type: "string"},
			{Name: "level", Type: "string"},
		},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/analytics/export-html",
		Summary: "导出与当前筛选和数据版本一致的独立只读HTML治理报告",
		Handler: workbenchAnalyticsExportHtmlList,
		Tags:    []string{"casework"},
		QueryParams: []Param{
			{Name: "time_mode", Type: "string"},
			{Name: "batch_id", Type: "string"},
			{Name: "case_scope", Type: "string"},
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
			{Name: "program", Type: "string"},
			{Name: "tier", Type: "string"},
			{Name: "submitter", Type: "string"},
			{Name: "owner", Type: "string"},
			{Name: "advertiser_id", Type: "string"},
			{Name: "account_id", Type: "string"},
			{Name: "search", Type: "string"},
			{Name: "date_field", Type: "string"},
			{Name: "level", Type: "string"},
		},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/analytics/reports",
		Summary: "按当前真实统计与筛选生成不可变治理报告版本并保存到 Cloud DB",
		Handler: workbenchAnalyticsReportsCreate,
		Tags:    []string{"casework", "reports"},
		QueryParams: []Param{
			{Name: "time_mode", Type: "string"},
			{Name: "batch_id", Type: "string"},
			{Name: "case_scope", Type: "string"},
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
			{Name: "program", Type: "string"},
			{Name: "tier", Type: "string"},
			{Name: "submitter", Type: "string"},
			{Name: "owner", Type: "string"},
			{Name: "advertiser_id", Type: "string"},
			{Name: "account_id", Type: "string"},
			{Name: "search", Type: "string"},
			{Name: "date_field", Type: "string"},
			{Name: "level", Type: "string"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"report_id":    "rpt_x",
				"version":      "rpt_x",
				"title":        "TAP 初步治理分析报告",
				"period":       "2026-10-01 至 2026-10-07",
				"generated_at": "2026-10-26T05:00:00Z",
				"data_as_of":   "2026-10-26T04:59:00Z",
				"share_path":   "/reports/rpt_x",
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/analytics/reports/{report_id}",
		Summary: "只读获取 Cloud DB 中固定ID对应的不可变治理报告",
		Handler: workbenchAnalyticsReportsByReportIdGet,
		Tags:    []string{"casework", "reports", "readonly"},
		Response: map[string]any{
			"data": map[string]any{
				"report_id":    "rpt_x",
				"version":      "rpt_x",
				"title":        "TAP 初步治理分析报告",
				"period":       "2026-10-01 至 2026-10-07",
				"owner":        "user",
				"created_at":   "2026-10-26T05:00:00Z",
				"generated_at": "2026-10-26T05:00:00Z",
				"data_as_of":   "2026-10-26T04:59:00Z",
				"filters_json": "{}",
				"content_html": "<!doctype html>...",
				"content_hash": "sha256",
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/backfills",
		Summary: "运营查看回填任务状态、进度、checkpoint、请求ID和分Program结果",
		Handler: workbenchBackfillsList,
		Tags:    []string{"casework", "backfill", "readonly"},
		Response: map[string]any{
			"data": map[string]any{
				"tasks": []any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/backfills",
		Summary: "运营显式创建 enrichment 定向回填任务；dry-run 仅预览，禁止全量 membership、建 case 或通知",
		Handler: workbenchBackfillsCreate,
		Tags:    []string{"casework", "backfill"},
		BodyParams: []Param{
			{Name: "request_id", Type: "string", Required: true},
			{Name: "dry_run", Type: "boolean", Required: true},
			{Name: "program", Type: "string", Description: "ET/THT/ST 或空"},
			{Name: "batch_id", Type: "string"},
			{Name: "case_id", Type: "string"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"id":              "backfill-id",
				"status":          "preview_ready",
				"dry_run":         true,
				"fingerprint":     "sha256",
				"progress":        map[string]any{},
				"program_results": map[string]any{},
				"errors":          []any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/backfills/{id}",
		Summary: "运营查看单个回填任务详情",
		Handler: workbenchBackfillsByIdGet,
		Tags:    []string{"casework", "backfill", "readonly"},
		Response: map[string]any{
			"data": map[string]any{
				"id":       "backfill-id",
				"status":   "running",
				"progress": map[string]any{},
				"errors":   []any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/backfills/{id}/retry",
		Summary: "运营显式从 checkpoint 重试失败或中断的回填任务",
		Handler: workbenchBackfillsByIdRetryCreate,
		Tags:    []string{"casework", "backfill"},
		BodyParams: []Param{
			{Name: "request_id", Type: "string", Required: true},
		},
		Response: map[string]any{
			"data": map[string]any{
				"id":     "backfill-id",
				"status": "queued",
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/batches",
		Summary: "只读返回真实持久化周度批次；无历史时返回空列表",
		Handler: workbenchBatchesList,
		Tags:    []string{"casework", "readonly"},
		Response: map[string]any{
			"data": map[string]any{
				"status": "available",
				"batches": []any{
					map[string]any{
						"batch_id":          "TAP-WEEK-2026-10-12-2026-10-18",
						"week_name":         "2026-W42",
						"generated_at":      "2026-10-19T01:00:00Z",
						"metric_start_date": "2026-10-12",
						"metric_end_date":   "2026-10-18",
						"timezone":          "Asia/Shanghai",
						"rule_versions":     map[string]any{},
						"programs": []any{
							"ET",
						},
						"status":       "available",
						"completeness": "complete",
					},
				},
				"timezone": "Asia/Shanghai",
				"source":   "persisted_scans",
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/cases",
		Summary: "所有已登录使用者共享业务事件；收件箱可默认限定最新一致指标窗口，完整集合过滤后服务端分页",
		Handler: workbenchCasesList,
		Tags:    []string{"casework"},
		QueryParams: []Param{
			{Name: "case_scope", Type: "string", Description: "current=最新一致指标窗口；all=全部历史，默认 all 以兼容既有调用"},
			{Name: "program", Type: "string", Description: "ET/THT/ST"},
			{Name: "tier", Type: "string", Description: "真实客户 Tier；源字段缺失时结果明确标记"},
			{Name: "region", Type: "string", Description: "提报标准区域"},
			{Name: "submitter", Type: "string", Description: "原提报人，多值任一命中"},
			{Name: "owner", Type: "string", Description: "当前负责人"},
			{Name: "advertiser_id", Type: "string", Description: "精确命中主 ID 或 linked_advertiser_ids"},
			{Name: "account_id", Type: "string", Description: "精确命中主 ID 或 linked_account_ids"},
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "date_field", Type: "string", Description: "created_at/updated_at/submission_date/protection_start/protection_end"},
			{Name: "alert_start_date", Type: "string", Description: "预警产生开始日期 YYYY-MM-DD"},
			{Name: "alert_end_date", Type: "string", Description: "预警产生结束日期 YYYY-MM-DD（含整日）"},
			{Name: "alert_level", Type: "string", Description: "critical/watch/normal"},
			{Name: "status", Type: "string", Description: "open/processing/observing/pending_approval/pending_review/closed"},
			{Name: "mine", Type: "string", Description: "todo=我的待办；submitted=我的提报"},
			{Name: "search", Type: "string"},
			{Name: "page", Type: "integer"},
			{Name: "page_size", Type: "integer"},
		},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/cases",
		Summary: "从当前用户真实命中扫描幂等建立事件，不自动发送",
		Handler: workbenchCasesCreate,
		Tags:    []string{"casework"},
		BodyParams: []Param{
			{Name: "scan_id", Type: "string", Required: true},
			{Name: "row_id", Type: "string", Required: true},
		},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/cases/{id}",
		Summary: "共享事件的初始快照、结构化处置、审计、复查和通知；权限由当前鉴权身份与已验证人员映射服务端计算",
		Handler: workbenchCasesByIdGet,
		Tags:    []string{"casework"},
		Response: map[string]any{
			"data":          map[string]any{},
			"notifications": []any{},
			"permissions": map[string]any{
				"can_handle": true,
				"can_review": false,
			},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/cases/{id}/commands",
		Summary: "带版本和幂等键的统一分派、处置、复核状态机",
		Handler: workbenchCasesByIdCommandsCreate,
		Tags:    []string{"casework"},
		BodyParams: []Param{
			{Name: "expected_version", Type: "int", Required: true},
			{Name: "request_id", Type: "string", Required: true},
			{Name: "operation", Type: "string", Required: true, Description: "operator_confirm/submitter_complete/close（推荐治理闭环）或兼容动作 accept/assign/plan/complete/approve/return/reopen；服务端严格校验状态与角色"},
			{Name: "plan", Type: "string"},
			{Name: "note", Type: "string", Required: true},
			{Name: "fields", Type: "object"},
			{Name: "owner", Type: "string"},
			{Name: "reviewer", Type: "string"},
			{Name: "closure_reason", Type: "string"},
		},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/cases/{id}/notification-preview",
		Summary: "刷新权威人员映射并解析 Bot 域目标的无发送预览",
		Handler: workbenchCasesByIdNotificationPreviewCreate,
		Tags:    []string{"casework", "feishu"},
		BodyParams: []Param{
			{Name: "mode", Type: "string", Description: "test 或 formal；必须与当前服务配置一致"},
			{Name: "recipient_id", Type: "string", Description: "test 模式下指定测试白名单目标；formal 模式忽略"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"dry_run":                         true,
				"will_send":                       false,
				"alert_id":                        "TAP-alert",
				"original_submitter":              "name",
				"region":                          "APAC",
				"case_version":                    1,
				"confirmation_token":              "",
				"confirmation_expires_in_seconds": 600,
				"presentation": map[string]any{
					"submitter":        "name",
					"alert_type":       "CCR/NFS absolute threshold",
					"alert_level":      "watch",
					"status":           "processing",
					"time_window":      "2026-10-19 to 2026-10-25",
					"region":           "APAC",
					"account_id":       "",
					"account_name":     "",
					"advertiser_id":    "",
					"p0_ccr":           "None",
					"p0_nfs":           "None",
					"revenue":          "None",
					"reported_reasons": []any{},
					"trigger_criteria": []any{},
				},
				"mapping_result": map[string]any{},
				"mapping_source": map[string]any{
					"status":            "fresh",
					"source_error":      "",
					"revision":          "",
					"source_synced_at":  "",
					"cache_age_seconds": 0,
				},
				"bot_resolution": map[string]any{
					"status": "resolved",
					"diagnostic": map[string]any{
						"stage":                "batch_get_id",
						"status":               "resolved",
						"app_id_fingerprint":   "",
						"response_has_user_id": true,
						"response_has_open_id": true,
						"cached":               false,
					},
				},
				"actual_target": map[string]any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/cases/{id}/notify",
		Summary: "显式向白名单测试人员发送卡片；要求确认 token 并保持 test 模式",
		Handler: workbenchCasesByIdNotifyCreate,
		Tags:    []string{"casework", "feishu"},
		BodyParams: []Param{
			{Name: "expected_version", Type: "int", Required: true},
			{Name: "mode", Type: "string", Required: true, Description: "test 或 formal；测试成功不占用正式幂等键"},
			{Name: "recipient_id", Type: "string", Description: "test 模式必填白名单 open_id；formal 模式忽略"},
			{Name: "preview_token", Type: "string", Required: true, Description: "notification-preview 返回的短期票据；绑定事件、模式、模板和实际收件人快照"},
			{Name: "confirmation_token", Type: "string", Description: "兼容旧前端；与 preview_token 等价"},
			{Name: "resend", Type: "boolean", Description: "仅 Operator 可用；对已成功发送的正式通知创建独立重发记录，不覆盖原审计"},
			{Name: "resend_request_id", Type: "string", Description: "受控重发必填；作为本次重发的独立幂等键"},
			{Name: "confirmation_note", Type: "string", Description: "受控重发必填；记录人工重发原因"},
		},
		Response: map[string]any{
			"data":            map[string]any{},
			"notification_id": "",
			"notification": map[string]any{
				"id":         "",
				"status":     "",
				"message_id": "",
				"updated_at": "",
			},
			"deduplicated": false,
			"idempotent":   false,
			"reused":       false,
			"message":      "",
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/cases/{id}/rechecks",
		Summary: "以当前AIME身份查询独立窗口真实CCR/NFS并保存复查",
		Handler: workbenchCasesByIdRechecksCreate,
		Tags:    []string{"casework"},
		BodyParams: []Param{
			{Name: "expected_version", Type: "int", Required: true},
			{Name: "start_date", Type: "string", Required: true},
			{Name: "end_date", Type: "string", Required: true},
			{Name: "comparability_note", Type: "string", Required: true},
		},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/casework/config",
		Summary: "处置模板、当前角色、测试接收目标和飞书配置状态",
		Handler: workbenchCaseworkConfigList,
		Tags:    []string{"casework"},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/comparisons/refresh",
		Summary: "按 account_id 与 program 定向刷新当前持久化行的比较窗口，不触发全量扫描、处置或通知",
		Handler: workbenchComparisonsRefreshCreate,
		Tags:    []string{"casework", "comparison"},
		BodyParams: []Param{
			{Name: "account_id", Type: "string", Required: true, Description: "精确 Account ID，仅刷新该账号"},
			{Name: "program", Type: "string", Required: true, Description: "ET（预留 ST）；当前仅允许 ET"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status":     "success",
				"account_id": "7000000000000000001",
				"program":    "ET",
				"anchor":     "2026-10-07",
				"windows": map[string]any{
					"pre": []any{
						"2026-09-30",
						"2026-10-06",
					},
					"post": []any{
						"2026-10-07",
						"2026-10-13",
					},
				},
				"comparison": map[string]any{
					"pre_ccr":  1,
					"post_ccr": 2,
					"pre_ccr_fact": map[string]any{
						"value":  1,
						"status": "available",
						"reason": "",
					},
					"post_ccr_fact": map[string]any{
						"value":  2,
						"status": "available",
						"reason": "",
					},
					"increase_fact": map[string]any{
						"value":  100,
						"status": "available",
						"reason": "",
					},
					"ccr_growth_pct":            100,
					"legacy_wow_ccr_growth_pct": "None",
					"status":                    "available",
				},
				"updated_rows":  1,
				"updated_jobs":  1,
				"targeted_only": true,
				"side_effects": map[string]any{
					"case_status":   false,
					"actions":       false,
					"notifications": false,
				},
				"completeness": "complete",
				"audit":        map[string]any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/history",
		Summary: "所有已登录使用者共享的最近十次扫描与处理记录",
		Handler: workbenchHistoryList,
		Tags:    []string{"casework"},
		Response: map[string]any{
			"data": map[string]any{
				"scans":   []any{},
				"actions": map[string]any{},
				"scope":   "shared_recent_scans",
				"limit":   10,
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/identity-mappings",
		Summary: "刷新并列出权威人员映射（敏感字段脱敏）",
		Handler: workbenchIdentityMappingsList,
		Tags:    []string{"casework", "feishu"},
		Response: map[string]any{
			"data": map[string]any{
				"mappings": []any{},
				"source": map[string]any{
					"status":            "fresh",
					"source_error":      "",
					"revision":          "",
					"source_synced_at":  "",
					"cache_age_seconds": 0,
				},
				"auto_send_enabled": false,
			},
		},
	})
	Register(Route{
		Method:  http.MethodPut,
		Path:    "/api/workbench/identity-mappings/{record_id}/enabled",
		Summary: "运营启用或停用人员映射；人工停用不会被后续 Sheet 同步覆盖",
		Handler: workbenchIdentityMappingsByRecordIdEnabledUpdate,
		Tags:    []string{"casework", "feishu"},
		BodyParams: []Param{
			{Name: "enabled", Type: "boolean", Required: true},
			{Name: "confirmation_note", Type: "string", Required: true},
		},
		Response: map[string]any{
			"data": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/notifications/batch",
		Summary: "使用统一通知服务批量预览或排队；默认 dry_run，正式执行要求每条独立有效 preview_token",
		Handler: workbenchNotificationsBatchCreate,
		Tags:    []string{"casework", "feishu"},
		BodyParams: []Param{
			{Name: "mode", Type: "string", Required: true, Description: "test 或 formal"},
			{Name: "dry_run", Type: "boolean", Required: true},
			{Name: "items", Type: "array", Required: true, Description: "每项包含 alert_id、recipient_id（test）和 preview_token（执行时）"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"dry_run": true,
				"results": []any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/read-model",
		Summary: "四个主 Tab 共用的只读批次、筛选、卡片、事件与榜单契约",
		Handler: workbenchReadModelList,
		Tags:    []string{"casework", "readonly"},
		QueryParams: []Param{
			{Name: "time_mode", Type: "string", Required: true, Description: "weekly 或 custom"},
			{Name: "batch_id", Type: "string", Description: "weekly 模式真实批次 ID；空值取最新真实批次"},
			{Name: "start_date", Type: "string", Description: "custom 模式开始日期 YYYY-MM-DD"},
			{Name: "end_date", Type: "string", Description: "custom 模式结束日期 YYYY-MM-DD"},
			{Name: "program", Type: "string", Description: "ET/THT/ST"},
			{Name: "tier", Type: "string"},
			{Name: "region", Type: "string"},
			{Name: "submitter", Type: "string"},
			{Name: "account_id", Type: "string"},
			{Name: "advertiser_id", Type: "string"},
			{Name: "search", Type: "string"},
			{Name: "only_mine", Type: "boolean", Description: "必须由当前鉴权身份唯一命中权威人员映射"},
			{Name: "stage", Type: "string", Description: "pending_operator/pending_submitter/closed"},
			{Name: "ranking", Type: "string", Description: "combined/absolute/growth"},
			{Name: "page", Type: "integer"},
			{Name: "page_size", Type: "integer"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status":  "available",
				"reason":  "",
				"time":    map[string]any{},
				"filters": map[string]any{},
				"cards":   map[string]any{},
				"funnel": map[string]any{
					"ET": map[string]any{
						"status":       "available",
						"distinct_key": "account_id",
						"mapping_success": map[string]any{
							"value":  1994,
							"status": "known",
						},
						"current_ccr_complete": map[string]any{
							"value":  0,
							"status": "known",
						},
						"advertiser_pairs": map[string]any{
							"value":  15807,
							"status": "known",
						},
						"advertiser_pair_ccr_complete": map[string]any{
							"value":  15807,
							"status": "known",
						},
						"advertiser_pair_nfs_complete": map[string]any{
							"value":  15807,
							"status": "known",
						},
						"advertiser_pair_rule_eligible": map[string]any{
							"value":  15807,
							"status": "known",
						},
					},
					"THT": map[string]any{
						"status":       "available",
						"distinct_key": "advertiser_id",
						"comparison_protection_time_valid": map[string]any{
							"value":  4096,
							"status": "known",
						},
						"comparison_window_complete": map[string]any{
							"value":  4096,
							"status": "known",
						},
						"comparison_queried": map[string]any{
							"value":  4096,
							"status": "known",
						},
						"comparison_success": map[string]any{
							"value":  100,
							"status": "known",
						},
						"comparison_no_data": map[string]any{
							"value":  3996,
							"status": "known",
						},
						"comparison_failed": map[string]any{
							"value":  0,
							"status": "known",
						},
						"comparison_budget_skipped": map[string]any{
							"value":  0,
							"status": "known",
						},
						"growth_ranking_status": "complete",
					},
					"ST": map[string]any{
						"status": "not_scanned",
						"distinct_clients": map[string]any{
							"value":  "None",
							"status": "unknown",
						},
					},
				},
				"policy": map[string]any{
					"policy_version":                 "TAP-20261021-v2",
					"snapshot_levels_are_historical": true,
				},
				"rows": []any{
					map[string]any{
						"program": "THT",
						"comparison": map[string]any{
							"pre_ccr":  0.4,
							"post_ccr": 0.8,
							"pre_ccr_fact": map[string]any{
								"value":  0.4,
								"status": "available",
								"reason": "",
							},
							"post_ccr_fact": map[string]any{
								"value":  0.8,
								"status": "available",
								"reason": "",
							},
							"increase_fact": map[string]any{
								"value":  100,
								"status": "available",
								"reason": "",
							},
							"pre_nfs":      1,
							"post_nfs":     2,
							"pre_revenue":  "None",
							"post_revenue": "None",
							"status":       "available",
							"source": map[string]any{
								"rid":             2942519,
								"grain":           "account_advertiser_window",
								"window_complete": true,
								"request_ids":     map[string]any{},
							},
						},
					},
				},
				"rankings":         map[string]any{},
				"pagination":       map[string]any{},
				"contract_version": "2026-10-26",
				"side_effects":     false,
			},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/reported-reasons/refresh",
		Summary: "按 ET Account 与 Advertiser 定向刷新 Current Window 原因 Top3，仅更新关联持久化行",
		Handler: workbenchReportedReasonsRefreshCreate,
		Tags:    []string{"casework", "reported-reasons"},
		BodyParams: []Param{
			{Name: "account_id", Type: "string", Required: true, Description: "19 位 ET Account ID，按字符串处理"},
			{Name: "advertiser_id", Type: "string", Required: true, Description: "19 位 Advertiser ID，按字符串处理"},
			{Name: "batch_id", Type: "string", Description: "可选周度批次；空值取包含该 pair 的最新 ET 批次"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status":        "success",
				"account_id":    "7000000000000000001",
				"advertiser_id": "7100000000000000001",
				"batch_id":      "TAP-WEEK-2026-10-19-2026-10-25",
				"current_window": map[string]any{
					"start_date": "2026-10-19",
					"end_date":   "2026-10-25",
				},
				"reason_status":      "available",
				"reason_error":       "",
				"valid_reason_count": 3,
				"sort_basis":         "CCR",
				"reported_reasons":   []any{},
				"updated_rows":       1,
				"targeted_only":      true,
				"side_effects": map[string]any{
					"case_status":   false,
					"actions":       false,
					"notifications": false,
				},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/risk-policy",
		Summary: "获取后端权威生效阈值、版本、权限与最近自动重判状态",
		Handler: workbenchRiskPolicyList,
		Tags:    []string{"casework", "risk-policy", "readonly"},
		Response: map[string]any{
			"data": map[string]any{
				"version":            1,
				"version_label":      "TAP-RISK-1",
				"config_hash":        "sha256",
				"rules":              []any{},
				"is_operator":        true,
				"updated_by":         "operator",
				"updated_at":         "2026-10-26T14:00:00Z",
				"latest_rejudgement": map[string]any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodPut,
		Path:    "/api/workbench/risk-policy",
		Summary: "运营使用预览票据、CAS 与幂等键确认并提交新阈值配置，自动创建当前周重判任务",
		Handler: workbenchRiskPolicyUpdate,
		Tags:    []string{"casework", "risk-policy"},
		BodyParams: []Param{
			{Name: "expected_version", Type: "integer", Required: true},
			{Name: "preview_token", Type: "string", Required: true},
			{Name: "request_id", Type: "string", Required: true},
			{Name: "confirmation_note", Type: "string", Required: true},
			{Name: "rules", Type: "array", Required: true},
		},
		Response: map[string]any{
			"data": map[string]any{
				"version":       2,
				"version_label": "TAP-RISK-2",
				"config_hash":   "sha256",
				"rules":         []any{},
				"warnings":      []any{},
				"rejudgement":   map[string]any{},
				"idempotent":    false,
				"unchanged":     false,
			},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/workbench/risk-policy/preview",
		Summary: "运营基于当前周持久化 ET/ST/THT 指标只读预览阈值草稿影响，不查询 Aeolus 或产生写副作用",
		Handler: workbenchRiskPolicyPreviewCreate,
		Tags:    []string{"casework", "risk-policy", "readonly"},
		BodyParams: []Param{
			{Name: "expected_version", Type: "integer", Required: true},
			{Name: "rules", Type: "array", Required: true},
		},
		Response: map[string]any{
			"data": map[string]any{
				"expected_version": 1,
				"draft_hash":       "sha256",
				"preview_token":    "token",
				"warnings":         []any{},
				"programs":         map[string]any{},
				"total":            map[string]any{},
				"source_batch_ids": []any{},
				"data_freshness":   map[string]any{},
				"partial":          false,
				"failure_reasons":  []any{},
				"side_effects": map[string]any{
					"jobs":   false,
					"cases":  false,
					"outbox": false,
					"aeolus": false,
				},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/risk-policy/rejudgements",
		Summary: "获取阈值配置自动重判任务状态与历史，供前端轮询",
		Handler: workbenchRiskPolicyRejudgementsList,
		Tags:    []string{"casework", "risk-policy", "readonly"},
		Response: map[string]any{
			"data": map[string]any{
				"tasks": []any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/workbench/risk-policy/versions",
		Summary: "获取阈值配置版本与变更审计列表",
		Handler: workbenchRiskPolicyVersionsList,
		Tags:    []string{"casework", "risk-policy", "readonly"},
		Response: map[string]any{
			"data": map[string]any{
				"versions": []any{},
			},
		},
	})
}
