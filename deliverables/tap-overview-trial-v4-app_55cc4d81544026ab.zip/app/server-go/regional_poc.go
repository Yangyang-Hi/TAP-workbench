package main

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"
)

const cwRegionalPOCSheetID = "9zaKsD"

type cwRegionalPOC struct {
	Region string `json:"region"`
	Name   string `json:"name"`
	Email  string `json:"email"`
}

var cwRegionalPOCCache struct {
	sync.Mutex
	Rows      map[string]cwRegionalPOC
	Revision  string
	FetchedAt time.Time
}

func cwRegionalPOCKeys(region string) []string {
	r := strings.ToUpper(strings.TrimSpace(region))
	switch r {
	case "KR+JP", "KR / JP", "KR&JP":
		return []string{"KR", "JP"}
	case "MET":
		return []string{"MET", "METAP"}
	case "SCALED GROWTH AGENCY", "SGA":
		return []string{"SCALED GROWTH AGENCY"}
	default:
		return []string{r}
	}
}

func cwLoadRegionalPOCs(ctx context.Context) (map[string]cwRegionalPOC, string, error) {
	cwRegionalPOCCache.Lock()
	defer cwRegionalPOCCache.Unlock()
	if len(cwRegionalPOCCache.Rows) > 0 && time.Since(cwRegionalPOCCache.FetchedAt) < 5*time.Minute {
		return cwRegionalPOCCache.Rows, cwRegionalPOCCache.Revision, nil
	}
	token, err := cwAccessToken(ctx)
	if err != nil {
		return nil, "", fmt.Errorf("regional_poc_refresh_failed: bot credentials: %w", err)
	}
	sheetRange := cwRegionalPOCSheetID + "!A1:C200"
	path := "/open-apis/sheets/v2/spreadsheets/" + cwMappingSheetToken + "/values/" + url.PathEscape(sheetRange)
	out, err := cwHTTP(ctx, http.MethodGet, path, token, nil)
	if err != nil {
		return nil, "", fmt.Errorf("regional_poc_refresh_failed: sheet read: %w", err)
	}
	data, _ := out["data"].(map[string]any)
	valueRange, _ := data["valueRange"].(map[string]any)
	values, _ := valueRange["values"].([]any)
	if len(values) == 0 {
		values, _ = data["values"].([]any)
	}
	rows := make([][]string, 0, len(values))
	for _, raw := range values {
		items, _ := raw.([]any)
		row := make([]string, len(items))
		for i, item := range items {
			row[i] = strings.TrimSpace(asString(item))
		}
		rows = append(rows, row)
	}
	if len(rows) < 2 || strings.TrimSpace(cwCell(rows[0], 0)) != "Region" || strings.TrimSpace(cwCell(rows[0], 1)) != "姓名" || strings.TrimSpace(cwCell(rows[0], 2)) != "企业邮箱" {
		return nil, "", fmt.Errorf("regional_poc_refresh_failed: unexpected sheet headers")
	}
	mapped := map[string]cwRegionalPOC{}
	for _, row := range rows[1:] {
		region, name, email := cwCell(row, 0), cwCell(row, 1), strings.ToLower(cwCell(row, 2))
		if region == "" && name == "" && email == "" {
			continue
		}
		if region == "" || name == "" || email == "" {
			return nil, "", fmt.Errorf("regional_poc_refresh_failed: incomplete row for region %q", region)
		}
		if !strings.Contains(email, "@") || strings.HasPrefix(email, "@") || strings.HasSuffix(email, "@") {
			return nil, "", fmt.Errorf("regional_poc_refresh_failed: invalid email for region %q", region)
		}
		poc := cwRegionalPOC{Region: region, Name: name, Email: email}
		for _, key := range cwRegionalPOCKeys(region) {
			if _, exists := mapped[key]; exists {
				return nil, "", fmt.Errorf("regional_poc_refresh_failed: duplicate region mapping %q", key)
			}
			mapped[key] = poc
		}
	}
	revision := strings.TrimSpace(cwParseRevision(data["revision"]))
	if revision == "" {
		revision = strings.TrimSpace(cwParseRevision(out["revision"]))
	}
	cwRegionalPOCCache.Rows, cwRegionalPOCCache.Revision, cwRegionalPOCCache.FetchedAt = mapped, revision, time.Now()
	return mapped, revision, nil
}

var cwLoadRegionalPOCsForQuota = cwLoadRegionalPOCs

func cwDecorateQuotaRegionalPOCs(ctx context.Context, data map[string]any) {
	pocs, revision, err := cwLoadRegionalPOCsForQuota(ctx)
	if err != nil {
		data["regional_poc_status"] = "unavailable"
		data["regional_poc_error"] = err.Error()
		return
	}
	data["regional_poc_status"] = "available"
	data["regional_poc_revision"] = revision
	regions, _ := data["regions"].([]map[string]any)
	for _, row := range regions {
		key := strings.ToUpper(strings.TrimSpace(asString(row["region"])))
		if poc, ok := pocs[key]; ok {
			row["regional_poc"] = poc.Name
			row["regional_poc_email"] = poc.Email
			row["regional_poc_status"] = "mapped"
		} else {
			row["regional_poc"] = nil
			row["regional_poc_email"] = nil
			row["regional_poc_status"] = "unmapped"
		}
	}
}
