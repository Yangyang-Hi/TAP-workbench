package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

const (
	wbBackfillTable           = "tap_enrich_backfills"
	wbBackfillStartedAtField  = "started_at"
	wbBackfillModifiedAtField = "modified_at"
	wbBackfillChunkSize       = 500
)

type wbBackfillRequest struct {
	RequestID string `json:"request_id"`
	DryRun    bool   `json:"dry_run"`
	Program   string `json:"program"`
	BatchID   string `json:"batch_id"`
	CaseID    string `json:"case_id"`
}

type wbBackfillProgress struct {
	Total   int `json:"total"`
	Done    int `json:"done"`
	Updated int `json:"updated"`
	Skipped int `json:"skipped"`
	Failed  int `json:"failed"`
}

type wbBackfillProgramResult struct {
	Status  string `json:"status"`
	Updated int    `json:"updated"`
	Skipped int    `json:"skipped"`
	Failed  int    `json:"failed"`
	Reason  string `json:"reason,omitempty"`
}

type wbBackfillTask struct {
	ID               string                             `json:"id"`
	RequestID        string                             `json:"request_id"`
	Fingerprint      string                             `json:"fingerprint"`
	DryRun           bool                               `json:"dry_run"`
	Program          string                             `json:"program,omitempty"`
	BatchID          string                             `json:"batch_id,omitempty"`
	CaseID           string                             `json:"case_id,omitempty"`
	Status           string                             `json:"status"`
	Checkpoint       int                                `json:"checkpoint"`
	LegacyCheckpoint int                                `json:"legacy_checkpoint,omitempty"`
	CheckpointKey    string                             `json:"checkpoint_key,omitempty"`
	MetricStage      string                             `json:"metric_stage,omitempty"`
	LeaseOwner       string                             `json:"lease_owner,omitempty"`
	LeaseUntil       string                             `json:"lease_until,omitempty"`
	Progress         wbBackfillProgress                 `json:"progress"`
	ProgramResults   map[string]wbBackfillProgramResult `json:"program_results"`
	Errors           []string                           `json:"errors"`
	CreatedBy        string                             `json:"created_by"`
	CreatedAt        string                             `json:"created_at"`
	UpdatedAt        string                             `json:"updated_at"`
}

type wbBackfillRepository interface {
	List(context.Context) ([]wbBackfillTask, error)
	Get(context.Context, string) (wbBackfillTask, error)
	Create(context.Context, wbBackfillTask) error
	Save(context.Context, wbBackfillTask) error
	ByFingerprint(context.Context, string) (wbBackfillTask, bool, error)
}

type wbMemoryBackfillRepository struct {
	mu    sync.Mutex
	items map[string]wbBackfillTask
}

func newWBMemoryBackfillRepository() *wbMemoryBackfillRepository {
	return &wbMemoryBackfillRepository{items: map[string]wbBackfillTask{}}
}
func (r *wbMemoryBackfillRepository) List(context.Context) ([]wbBackfillTask, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]wbBackfillTask, 0, len(r.items))
	for _, item := range r.items {
		out = append(out, item)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].CreatedAt > out[j].CreatedAt })
	return out, nil
}
func (r *wbMemoryBackfillRepository) Get(_ context.Context, id string) (wbBackfillTask, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	item, ok := r.items[id]
	if !ok {
		return item, errors.New("backfill_not_found")
	}
	return item, nil
}
func (r *wbMemoryBackfillRepository) Create(_ context.Context, item wbBackfillTask) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, ok := r.items[item.ID]; ok {
		return errors.New("backfill_exists")
	}
	r.items[item.ID] = item
	return nil
}
func (r *wbMemoryBackfillRepository) Save(_ context.Context, item wbBackfillTask) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.items[item.ID] = item
	return nil
}
func (r *wbMemoryBackfillRepository) ByFingerprint(_ context.Context, fp string) (wbBackfillTask, bool, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, item := range r.items {
		if item.Fingerprint == fp {
			return item, true, nil
		}
	}
	return wbBackfillTask{}, false, nil
}

type wbCloudBackfillRepository struct{ db *cloudStore }

func (r wbCloudBackfillRepository) query(ctx context.Context, body map[string]any) ([]map[string]any, error) {
	resp, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+wbBackfillTable+"/query", body)
	if err != nil {
		return nil, err
	}
	data, _ := resp["data"].(map[string]any)
	raw, _ := data["records"].([]any)
	out := make([]map[string]any, 0, len(raw))
	for _, value := range raw {
		if row, ok := toMap(value); ok {
			out = append(out, row)
		}
	}
	return out, nil
}
func wbBackfillFromCloud(row map[string]any) (wbBackfillTask, error) {
	var item wbBackfillTask
	raw, err := json.Marshal(row["body"])
	if err == nil {
		err = json.Unmarshal(raw, &item)
	}
	return item, err
}
func (r wbCloudBackfillRepository) List(ctx context.Context) ([]wbBackfillTask, error) {
	rows, err := r.query(ctx, map[string]any{"filters": []any{}, "limit": 100, "offset": 0, "sort": []any{map[string]any{"field": wbBackfillModifiedAtField, "direction": "desc"}}})
	if err != nil {
		return nil, err
	}
	out := []wbBackfillTask{}
	for _, row := range rows {
		item, e := wbBackfillFromCloud(row)
		if e == nil {
			out = append(out, item)
		}
	}
	return out, nil
}
func (r wbCloudBackfillRepository) Get(ctx context.Context, id string) (wbBackfillTask, error) {
	rows, err := r.query(ctx, map[string]any{"filters": []any{map[string]any{"field": "task_id", "operator": "eq", "value": id}}, "limit": 1})
	if err != nil {
		return wbBackfillTask{}, err
	}
	if len(rows) == 0 {
		return wbBackfillTask{}, errors.New("backfill_not_found")
	}
	return wbBackfillFromCloud(rows[0])
}
func wbBackfillCloudData(t wbBackfillTask) map[string]any {
	return map[string]any{"task_id": t.ID, "request_id": t.RequestID, "fingerprint": t.Fingerprint, "status": t.Status, "lease_owner": t.LeaseOwner, "lease_until": t.LeaseUntil, "checkpoint": t.Checkpoint, wbBackfillStartedAtField: t.CreatedAt, wbBackfillModifiedAtField: t.UpdatedAt, "body": t}
}
func (r wbCloudBackfillRepository) Create(ctx context.Context, t wbBackfillTask) error {
	_, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+wbBackfillTable+"/records", wbBackfillCloudData(t))
	return err
}
func (r wbCloudBackfillRepository) Save(ctx context.Context, t wbBackfillTask) error {
	body := map[string]any{"filter": map[string]any{"logic": "and", "conditions": []any{map[string]any{"field": "task_id", "operator": "eq", "value": t.ID}}}, "data": wbBackfillCloudData(t), "limit": 1}
	_, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+wbBackfillTable+"/records/update", body)
	return err
}
func (r wbCloudBackfillRepository) ByFingerprint(ctx context.Context, fp string) (wbBackfillTask, bool, error) {
	rows, err := r.query(ctx, map[string]any{"filters": []any{map[string]any{"field": "fingerprint", "operator": "eq", "value": fp}}, "limit": 1})
	if err != nil {
		return wbBackfillTask{}, false, err
	}
	if len(rows) == 0 {
		return wbBackfillTask{}, false, nil
	}
	item, err := wbBackfillFromCloud(rows[0])
	return item, err == nil, err
}

var wbBackfillRepoProvider = func() (wbBackfillRepository, error) {
	db, err := newCloudStore()
	if err != nil {
		return nil, err
	}
	return wbCloudBackfillRepository{db: db}, nil
}

func wbBackfillFingerprint(req wbBackfillRequest) string {
	payload, _ := json.Marshal([]any{"batch-v13-staged-compact", strings.ToUpper(strings.TrimSpace(req.Program)), strings.TrimSpace(req.BatchID), strings.TrimSpace(req.CaseID), req.DryRun})
	sum := sha256.Sum256(payload)
	return hex.EncodeToString(sum[:])
}
func wbValidateBackfill(req *wbBackfillRequest) error {
	req.Program = strings.ToUpper(strings.TrimSpace(req.Program))
	if req.RequestID == "" {
		return errors.New("request_id_required")
	}
	if req.Program != "" && req.Program != "ET" && req.Program != "THT" && req.Program != "ST" {
		return errors.New("program_must_be_ET_THT_or_ST")
	}
	return nil
}
func wbWriteBackfillError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, map[string]any{"error": message})
}

func wbDecodeBackfillJSON(r *http.Request, value any) error {
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	return decoder.Decode(value)
}

func wbRequireOperator(w http.ResponseWriter, r *http.Request) bool {
	cfg, err := cwLoadConfig()
	if err != nil || !cwOperator(cfg, requestUsername(r)) {
		wbWriteBackfillError(w, 403, "operator_required")
		return false
	}
	return true
}
func wbBackfillID(r *http.Request) string {
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	for i, p := range parts {
		if p == "backfills" && i+1 < len(parts) {
			return parts[i+1]
		}
	}
	return ""
}

func wbBackfillTargets(req wbBackfillRequest) ([]string, error) {
	state, err := wbReadDisk()
	if err != nil {
		return nil, err
	}
	return wbBackfillTargetsFromState(req, state)
}

func wbBackfillTargetsFromState(req wbBackfillRequest, state wbDisk) ([]string, error) {
	keys := []string{}
	selectedJobs := map[string]bool{}
	if req.BatchID != "" {
		for id, job := range state.Jobs {
			if job.BatchID == req.BatchID || job.ID == req.BatchID {
				selectedJobs[id] = true
			}
		}
	} else {
		latestByProgram := map[string]wbJob{}
		for _, job := range state.Jobs {
			program := strings.ToUpper(job.Request.Program)
			if req.Program != "" && program != req.Program {
				continue
			}
			previous, ok := latestByProgram[program]
			if !ok || job.AsOf+job.StartedAt > previous.AsOf+previous.StartedAt {
				latestByProgram[program] = job
			}
		}
		for _, job := range latestByProgram {
			selectedJobs[job.ID] = true
		}
	}
	for id, job := range state.Jobs {
		if !selectedJobs[id] {
			continue
		}
		needs := false
		for _, row := range job.Rows {
			if req.Program != "" && row.Program != req.Program {
				continue
			}
			if wbRowNeedsEnrichment(row) {
				needs = true
				break
			}
		}
		if needs {
			for start := 0; start < len(job.Rows); start += wbBackfillChunkSize {
				end := start + wbBackfillChunkSize
				if end > len(job.Rows) {
					end = len(job.Rows)
				}
				chunk := job.Rows[start:end]
				if wbChunkNeedsCurrentAccount(chunk) {
					keys = append(keys, fmt.Sprintf("job:%s:%d:current_account", id, start))
				}
				if wbChunkNeedsAccountComparison(chunk) {
					keys = append(keys, fmt.Sprintf("job:%s:%d:account_comparison", id, start))
				}
				if wbChunkNeedsAdvertiserEnrichment(chunk) {
					keys = append(keys, fmt.Sprintf("job:%s:%d:advertiser_enrichment", id, start))
				}
			}
		}
	}
	// Batch/job targets synchronize their linked cases after one shared enrichment
	// query, so target discovery must not perform an expensive full case scan.
	if len(selectedJobs) > 0 && req.CaseID == "" {
		wbSortBackfillTargets(keys)
		return keys, nil
	}
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		return nil, err
	}
	cases, err := repo.listCases(context.Background())
	if err != nil {
		return nil, err
	}
	for _, item := range cases {
		if req.BatchID != "" && !selectedJobs[item.ScanID] {
			continue
		}
		if selectedJobs[item.ScanID] {
			// The job target refreshes this immutable evidence once and synchronizes
			// linked cases without repeating Aeolus queries per case.
			continue
		}
		if req.CaseID != "" && item.ID != req.CaseID {
			continue
		}
		if req.Program != "" && item.Row.Program != req.Program {
			continue
		}
		if wbRowNeedsEnrichment(item.Row) {
			keys = append(keys, "case:"+item.ID)
		}
	}
	wbSortBackfillTargets(keys)
	return keys, nil
}

func wbSortBackfillTargets(keys []string) {
	priority := map[string]int{"current_account": 0, "account_comparison": 1, "advertiser_enrichment": 2, "case_enrichment": 3}
	sort.SliceStable(keys, func(i, j int) bool {
		parse := func(key string) (string, int, int) {
			parts := strings.Split(strings.TrimPrefix(key, "job:"), ":")
			if len(parts) < 3 {
				return key, 0, 99
			}
			start, _ := strconv.Atoi(parts[len(parts)-2])
			stagePriority, ok := priority[parts[len(parts)-1]]
			if !ok {
				stagePriority = 99
			}
			return strings.Join(parts[:len(parts)-2], ":"), start, stagePriority
		}
		jobI, startI, stageI := parse(keys[i])
		jobJ, startJ, stageJ := parse(keys[j])
		if jobI != jobJ {
			return jobI < jobJ
		}
		if stageI != stageJ {
			return stageI < stageJ
		}
		return startI < startJ
	})
}

func wbChunkNeedsCurrentAccount(rows []wbRow) bool {
	for _, row := range rows {
		status := strings.ToLower(strings.TrimSpace(row.MetricStatus))
		if status == "" || status == "failed" || status == "timeout" || status == "source_error" {
			return true
		}
	}
	return false
}

func wbChunkNeedsAccountComparison(rows []wbRow) bool {
	for _, row := range rows {
		status := strings.ToLower(strings.TrimSpace(row.Comparison.Status))
		if status == "" || status == "unavailable" || status == metricFailed || row.Comparison.MissingReason == wbNonRiskComparisonReason {
			return true
		}
	}
	return false
}

func wbChunkNeedsAdvertiserEnrichment(rows []wbRow) bool {
	for _, row := range rows {
		if len(row.AdvertiserTop10) == 0 {
			note := strings.ToLower(strings.TrimSpace(row.AggregationNote))
			// A non-technical terminal note proves the governed sources returned no
			// pair rows. Do not turn source NULL into an endless retry target.
			if note == "" || strings.Contains(note, "technical_failed") || strings.Contains(note, "query_failed") {
				return true
			}
			continue
		}
		for _, adv := range row.Advertisers {
			if adv.MetricStatus == "" || adv.RevenueStatus == "" || adv.ReportedReasonsStatus == "" {
				return true
			}
		}
	}
	return false
}

func wbRowNeedsEnrichment(row wbRow) bool {
	return wbChunkNeedsCurrentAccount([]wbRow{row}) || wbChunkNeedsAccountComparison([]wbRow{row}) || wbChunkNeedsAdvertiserEnrichment([]wbRow{row})
}

func wbBackfillQuery(row wbRow, fallback wbRequest) wbRequest {
	q := fallback
	q.Program = strings.ToUpper(row.Program)
	if q.Start == "" {
		q.Start = fallback.Start
	}
	if q.End == "" {
		q.End = fallback.End
	}
	return q
}

// wbEnrichPersistedRow is shared by job and case backfills. It always computes
// Account Pre/Post for every applicable ET row and independently refreshes
// Advertiser current facts + Reported Reasons; neither path gates the other.
func wbEnrichPersistedRow(ctx context.Context, request *http.Request, row wbRow, q wbRequest, rule wbRule) (wbRow, error) {
	q = wbBackfillQuery(row, q)
	enriched := wbApplyRealComparisons(ctx, request, []wbRow{row}, time.Now())[0]
	if !strings.EqualFold(row.Program, "THT") {
		evidence, err := wbQueryPairEvidence(ctx, request, []wbMember{row.Member}, q, rule)
		if err != nil {
			return enriched, err
		}
		enriched = applyPairEvidence([]wbRow{enriched}, evidence, q, rule)[0]
	}
	return enriched, nil
}

func wbMergeEnrichment(dst *wbRow, src wbRow) bool {
	changed := false
	if strings.TrimSpace(src.Member.Start) != "" && dst.Member.Start != src.Member.Start {
		dst.Member.Start = src.Member.Start
		dst.Member.CreateDate = src.Member.CreateDate
		dst.Member.Tickets = src.Member.Tickets
		changed = true
	}
	if src.Comparison.Status != "" && (dst.Comparison.Status == "" || dst.Comparison.Status == "unavailable" || dst.Comparison.Status == metricFailed || dst.Comparison.MissingReason == wbNonRiskComparisonReason) {
		dst.Comparison = src.Comparison
		changed = true
	}
	if len(src.Advertisers) > 0 {
		current := map[wbPairKey]wbAdvertiserEvidence{}
		for _, item := range dst.Advertisers {
			current[wbPairKey{item.AccountID, item.AdvertiserID}] = item
		}
		dst.Advertisers = append([]wbAdvertiserEvidence(nil), src.Advertisers...)
		for i := range dst.Advertisers {
			if previous, ok := current[wbPairKey{dst.Advertisers[i].AccountID, dst.Advertisers[i].AdvertiserID}]; ok {
				if previous.CCR != nil {
					dst.Advertisers[i].CCR = previous.CCR
				}
				if previous.NFS != nil {
					dst.Advertisers[i].NFS = previous.NFS
				}
				if previous.Revenue != nil {
					dst.Advertisers[i].Revenue = previous.Revenue
				}
			}
		}
		dst.AdvertiserTop10 = topAdvertisers(dst.Advertisers, 10)
		dst.AdvertiserCount = src.AdvertiserCount
		dst.AggregationNote = src.AggregationNote
		changed = true
	} else if len(dst.Advertisers) == 0 && len(dst.AdvertiserTop10) == 0 && src.AggregationNote != "" {
		// Persist a truthful terminal no-pair result instead of retrying forever.
		dst.Advertisers = []wbAdvertiserEvidence{}
		dst.AdvertiserTop10 = []wbAdvertiserEvidence{}
		dst.AdvertiserCount = 0
		dst.AggregationNote = src.AggregationNote
		changed = true
	}
	for i := range dst.AdvertiserTop10 {
		for reasonIndex := range dst.AdvertiserTop10[i].ReportedReasons {
			reason := &dst.AdvertiserTop10[i].ReportedReasons[reasonIndex]
			if reason.SourceStatus == "" {
				reason.SourceStatus = "legacy_unverified"
				reason.SourceReason = "legacy reason source is outside the 2026-10-26 authoritative source list"
				reason.Rank = nil
				reason.RankingAvailable = false
				changed = true
			}
		}
	}
	for i := range dst.Advertisers {
		for reasonIndex := range dst.Advertisers[i].ReportedReasons {
			reason := &dst.Advertisers[i].ReportedReasons[reasonIndex]
			if reason.SourceStatus == "" {
				reason.SourceStatus = "legacy_unverified"
				reason.SourceReason = "legacy reason source is outside the 2026-10-26 authoritative source list"
				reason.Rank = nil
				reason.RankingAvailable = false
				changed = true
			}
		}
		for _, candidate := range src.Advertisers {
			if dst.Advertisers[i].AccountID != candidate.AccountID || dst.Advertisers[i].AdvertiserID != candidate.AdvertiserID {
				continue
			}
			if dst.Advertisers[i].ComparisonStatus == "" || dst.Advertisers[i].ComparisonStatus == "unavailable" {
				currentCCR, currentNFS, currentRevenue := dst.Advertisers[i].CCR, dst.Advertisers[i].NFS, dst.Advertisers[i].Revenue
				dst.Advertisers[i] = candidate
				if currentCCR != nil {
					dst.Advertisers[i].CCR = currentCCR
				}
				if currentNFS != nil {
					dst.Advertisers[i].NFS = currentNFS
				}
				if currentRevenue != nil {
					dst.Advertisers[i].Revenue = currentRevenue
				}
				changed = true
			}
			if len(dst.Advertisers[i].ReportedReasons) == 0 {
				dst.Advertisers[i].ReportedReasons = candidate.ReportedReasons
				changed = true
			}
		}
	}
	return changed
}

var wbBackfillClaimMu sync.Mutex

func wbRunBackfill(repo wbBackfillRepository, id string, request *http.Request) {
	ctx := context.Background()
	wbBackfillClaimMu.Lock()
	task, err := repo.Get(ctx, id)
	if err != nil || task.Status != "queued" {
		wbBackfillClaimMu.Unlock()
		return
	}
	task.Status = "running"
	task.LeaseOwner = appInstanceID + ":" + uuid.NewString()
	task.LeaseUntil = time.Now().Add(2 * time.Minute).Format(time.RFC3339)
	task.UpdatedAt = time.Now().Format(time.RFC3339)
	if err = repo.Save(ctx, task); err != nil {
		wbBackfillClaimMu.Unlock()
		return
	}
	wbBackfillClaimMu.Unlock()
	state, err := wbReadDisk()
	if err != nil {
		task.Status = "failed"
		task.Errors = append(task.Errors, sanitizeLogText(err.Error()))
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		_ = repo.Save(ctx, task)
		return
	}
	targets, err := wbBackfillTargetsFromState(wbBackfillRequest{Program: task.Program, BatchID: task.BatchID, CaseID: task.CaseID}, state)
	if err != nil {
		task.Status = "failed"
		task.Errors = append(task.Errors, sanitizeLogText(err.Error()))
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		_ = repo.Save(ctx, task)
		return
	}
	if task.Progress.Total == 0 || task.CheckpointKey != "" {
		task.Progress.Total = task.Progress.Done + len(targets)
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		if err = repo.Save(ctx, task); err != nil {
			return
		}
	}
	if task.DryRun {
		task.Status = "preview_ready"
		task.LeaseUntil = ""
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		_ = repo.Save(ctx, task)
		return
	}
	config, configErr := loadWBConfig()
	if configErr != nil {
		task.Status = "failed"
		task.Errors = append(task.Errors, "load_workbench_config:"+sanitizeLogText(configErr.Error()))
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		_ = repo.Save(ctx, task)
		return
	}
	caseRepo, _ := cwCaseworkRepositoryProvider()
	startIndex := task.Checkpoint
	if task.CheckpointKey != "" {
		// Stage targets are rediscovered from persisted facts, so completed keys are
		// absent after restart and the remaining plan starts at zero.
		startIndex = 0
	} else if task.Checkpoint > 0 && task.MetricStage == "" {
		// Legacy checkpoints counted whole-job chunks. Re-discover only unfinished
		// metric stages from persisted facts and retain the old value for audit.
		task.LegacyCheckpoint = task.Checkpoint
		startIndex = 0
	}
	for index := startIndex; index < len(targets); index++ {
		key := targets[index]
		program := "unknown"
		updated := false
		var runErr error
		if strings.HasPrefix(key, "job:") {
			jobTarget := strings.TrimPrefix(key, "job:")
			jobID := jobTarget
			chunkStart := 0
			stage := "legacy_all"
			chunked := false
			parts := strings.Split(jobTarget, ":")
			if len(parts) >= 3 {
				if parsed, parseErr := strconv.Atoi(parts[len(parts)-2]); parseErr == nil {
					jobID = strings.Join(parts[:len(parts)-2], ":")
					chunkStart = parsed
					stage = parts[len(parts)-1]
					chunked = true
				}
			} else if len(parts) == 2 {
				if parsed, parseErr := strconv.Atoi(parts[1]); parseErr == nil {
					jobID = parts[0]
					chunkStart = parsed
					chunked = true
				}
			}
			job, ok := state.Jobs[jobID]
			if !ok {
				runErr = errors.New("backfill_job_not_found")
			} else if chunkStart < 0 || chunkStart >= len(job.Rows) {
				runErr = errors.New("backfill_job_chunk_out_of_range")
			} else {
				program = strings.ToUpper(job.Request.Program)
				chunkEnd := len(job.Rows)
				if chunked && chunkStart+wbBackfillChunkSize < chunkEnd {
					chunkEnd = chunkStart + wbBackfillChunkSize
				}
				workingRows := append([]wbRow(nil), job.Rows[chunkStart:chunkEnd]...)
				if program == "ET" {
					anchors := wbPersistedETAnchors(state)
					for i := range workingRows {
						if strings.TrimSpace(workingRows[i].Member.Start) == "" {
							workingRows[i].Member.Start = anchors[workingRows[i].Member.AccountID]
						}
					}
				}
				var enriched []wbRow
				switch stage {
				case "current_account":
					enriched, runErr = wbEnrichCurrentAccountRows(ctx, request, workingRows, job.Request)
				case "account_comparison":
					enriched, runErr = wbEnrichAccountComparisonRows(ctx, request, workingRows, job.Request)
				case "advertiser_enrichment":
					enriched, runErr = wbEnrichAdvertiserRows(ctx, request, workingRows, job.Request, job.Rule)
				default:
					enriched, runErr = wbEnrichPersistedRows(ctx, request, workingRows, job.Request, job.Rule)
				}
				if runErr == nil && len(enriched) != len(workingRows) {
					runErr = errors.New("backfill_enrichment_row_count_mismatch")
				}
				if runErr == nil {
					byRowID := map[string]wbRow{}
					for rowIndex := range workingRows {
						jobRowIndex := chunkStart + rowIndex
						if stage == "current_account" {
							if wbMergeCurrentAccount(&job.Rows[jobRowIndex], enriched[rowIndex]) {
								updated = true
							}
						} else if wbMergeEnrichment(&job.Rows[jobRowIndex], enriched[rowIndex]) {
							updated = true
						}
						byRowID[job.Rows[jobRowIndex].ID] = job.Rows[jobRowIndex]
					}
					if updated {
						state.Jobs[job.ID] = job
						runErr = wbWriteDisk(state)
					}
					if runErr == nil {
						var linked []cwCase
						linked, runErr = caseRepo.listCases(ctx)
						for _, item := range linked {
							fresh, exists := byRowID[item.Row.ID]
							if runErr != nil || item.ScanID != job.ID || !exists {
								continue
							}
							previous := item.Version
							caseChanged := false
							if stage == "current_account" {
								caseChanged = wbMergeCurrentAccount(&item.Row, fresh)
							} else {
								caseChanged = wbMergeEnrichment(&item.Row, fresh)
							}
							if !caseChanged {
								continue
							}
							item.Version++
							item.UpdatedAt = time.Now().Format(time.RFC3339)
							if runErr = caseRepo.saveCaseCAS(ctx, item, previous); runErr != nil {
								break
							}
						}
					}
					// Comparison queries can partially succeed by anchor-window group. The
					// successful rows are already durable, but this stage remains retryable
					// while any technical failure survives.
					if runErr == nil && stage == "account_comparison" && wbChunkNeedsAccountComparison(job.Rows[chunkStart:chunkEnd]) {
						runErr = errors.New("account_comparison_retryable_rows_remain")
					}
				}
			}
		}
		if strings.HasPrefix(key, "case:") {
			caseID := strings.TrimPrefix(key, "case:")
			var item cwCase
			item, runErr = caseRepo.caseByID(ctx, caseID)
			if runErr == nil {
				program = item.Row.Program
				q := wbRequest{Program: item.Row.Program, Start: item.Window.Start, End: item.Window.End}
				var enriched wbRow
				enriched, runErr = wbEnrichPersistedRow(ctx, request, item.Row, q, config.Rules[strings.ToUpper(item.Row.Program)])
				if runErr == nil {
					updated = wbMergeEnrichment(&item.Row, enriched)
				}
				if updated {
					previous := item.Version
					item.Version++
					item.UpdatedAt = time.Now().Format(time.RFC3339)
					runErr = caseRepo.saveCaseCAS(ctx, item, previous)
				}
			}
		}
		result := task.ProgramResults[program]
		if runErr != nil {
			task.Progress.Failed++
			result.Failed++
			result.Status = "partial"
			task.Errors = append(task.Errors, key+":"+sanitizeLogText(runErr.Error()))
		} else if updated {
			task.Progress.Updated++
			result.Updated++
			result.Status = "success"
		} else {
			task.Progress.Skipped++
			result.Skipped++
			result.Status = "skipped"
		}
		task.Progress.Done++
		task.Checkpoint++
		task.CheckpointKey = key
		if strings.HasPrefix(key, "job:") {
			parts := strings.Split(key, ":")
			if len(parts) > 0 {
				task.MetricStage = parts[len(parts)-1]
			}
		} else {
			task.MetricStage = "case_enrichment"
		}
		task.ProgramResults[program] = result
		task.LeaseUntil = time.Now().Add(2 * time.Minute).Format(time.RFC3339)
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		if err = repo.Save(ctx, task); err != nil {
			return
		}
	}
	task.Status = "completed"
	if task.Progress.Failed > 0 {
		task.Status = "completed_with_errors"
	}
	task.LeaseUntil = ""
	task.UpdatedAt = time.Now().Format(time.RFC3339)
	_ = repo.Save(ctx, task)
}

func wbMarkInterruptedBackfills() error {
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		return err
	}
	tasks, err := repo.List(context.Background())
	if err != nil {
		return err
	}
	for _, task := range tasks {
		if task.Status != "queued" && task.Status != "running" {
			continue
		}
		// Requests carry short-lived user authorization and cannot safely be persisted.
		// Keep the durable checkpoint queued; the first authenticated operator poll
		// automatically supplies fresh authorization and resumes from that checkpoint.
		task.Status = "queued"
		task.LeaseOwner = ""
		task.LeaseUntil = ""
		if !containsString(task.Errors, "service_restarted_resume_pending_auth") {
			task.Errors = append(task.Errors, "service_restarted_resume_pending_auth")
		}
		task.UpdatedAt = time.Now().Format(time.RFC3339)
		if err := repo.Save(context.Background(), task); err != nil {
			return err
		}
	}
	return nil
}

func wbResumeQueuedBackfills(repo wbBackfillRepository, request *http.Request, tasks []wbBackfillTask) {
	// One authenticated operator poll may resume at most the newest queued task
	// for a target scope. Older duplicate attempts remain immutable evidence and
	// cannot start parallel scans against the same persisted batch.
	activeScopes := map[string]bool{}
	newest := map[string]wbBackfillTask{}
	for _, task := range tasks {
		scope := strings.Join([]string{strings.ToUpper(task.Program), task.BatchID, task.CaseID}, "|")
		if task.Status == "running" {
			activeScopes[scope] = true
			continue
		}
		if task.Status != "queued" {
			continue
		}
		candidate, ok := newest[scope]
		if !ok || task.Progress.Done > candidate.Progress.Done || task.Progress.Done == candidate.Progress.Done && task.CreatedAt > candidate.CreatedAt {
			newest[scope] = task
		}
	}
	for scope, task := range newest {
		if activeScopes[scope] {
			continue
		}
		clone := request.Clone(context.Background())
		go wbRunBackfill(repo, task.ID, clone)
	}
}

func wbBackfillsListHandler(w http.ResponseWriter, r *http.Request) {
	if !wbRequireOperator(w, r) {
		return
	}
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		wbWriteBackfillError(w, 503, err.Error())
		return
	}
	tasks, err := repo.List(r.Context())
	if err != nil {
		wbWriteBackfillError(w, 500, err.Error())
		return
	}
	wbResumeQueuedBackfills(repo, r, tasks)
	writeJSON(w, 200, map[string]any{"data": map[string]any{"tasks": tasks}})
}
func wbBackfillsCreateHandler(w http.ResponseWriter, r *http.Request) {
	if !wbRequireOperator(w, r) {
		return
	}
	var req wbBackfillRequest
	if err := wbDecodeBackfillJSON(r, &req); err != nil {
		wbWriteBackfillError(w, 400, "invalid_json")
		return
	}
	if err := wbValidateBackfill(&req); err != nil {
		wbWriteBackfillError(w, 400, err.Error())
		return
	}
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		wbWriteBackfillError(w, 503, err.Error())
		return
	}
	fp := wbBackfillFingerprint(req)
	if old, ok, e := repo.ByFingerprint(r.Context(), fp); e == nil && ok {
		writeJSON(w, 200, map[string]any{"data": old})
		return
	}
	now := time.Now().Format(time.RFC3339)
	task := wbBackfillTask{ID: "bf-" + uuid.NewString(), RequestID: req.RequestID, Fingerprint: fp, DryRun: req.DryRun, Program: req.Program, BatchID: req.BatchID, CaseID: req.CaseID, Status: "queued", ProgramResults: map[string]wbBackfillProgramResult{}, Errors: []string{}, CreatedBy: requestUsername(r), CreatedAt: now, UpdatedAt: now}
	if err = repo.Create(r.Context(), task); err != nil {
		wbWriteBackfillError(w, 500, err.Error())
		return
	}
	clone := r.Clone(context.Background())
	go wbRunBackfill(repo, task.ID, clone)
	writeJSON(w, http.StatusAccepted, map[string]any{"data": task})
}
func wbBackfillsGetHandler(w http.ResponseWriter, r *http.Request) {
	if !wbRequireOperator(w, r) {
		return
	}
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		wbWriteBackfillError(w, 503, err.Error())
		return
	}
	task, err := repo.Get(r.Context(), wbBackfillID(r))
	if err != nil {
		wbWriteBackfillError(w, 404, "backfill_not_found")
		return
	}
	wbResumeQueuedBackfills(repo, r, []wbBackfillTask{task})
	writeJSON(w, 200, map[string]any{"data": task})
}
func wbBackfillsRetryHandler(w http.ResponseWriter, r *http.Request) {
	if !wbRequireOperator(w, r) {
		return
	}
	var body struct {
		RequestID string `json:"request_id"`
	}
	if wbDecodeBackfillJSON(r, &body) != nil || strings.TrimSpace(body.RequestID) == "" {
		wbWriteBackfillError(w, 400, "request_id_required")
		return
	}
	repo, err := wbBackfillRepoProvider()
	if err != nil {
		wbWriteBackfillError(w, 503, err.Error())
		return
	}
	task, err := repo.Get(r.Context(), wbBackfillID(r))
	if err != nil {
		wbWriteBackfillError(w, 404, "backfill_not_found")
		return
	}
	if task.Status != "failed" && task.Status != "completed_with_errors" {
		wbWriteBackfillError(w, 409, "backfill_not_retryable")
		return
	}
	task.RequestID = body.RequestID
	task.Status = "queued"
	task.LeaseOwner = ""
	task.LeaseUntil = ""
	// A retry is another attempt within the same durable task. Historical errors
	// remain as evidence, while completion is based only on this retry pass.
	task.Progress.Failed = 0
	for program, result := range task.ProgramResults {
		result.Failed = 0
		if result.Status == "partial" {
			result.Status = "retrying"
		}
		task.ProgramResults[program] = result
	}
	task.Errors = append(task.Errors, "retry_failed_stages:"+sanitizeLogText(body.RequestID))
	task.UpdatedAt = time.Now().Format(time.RFC3339)
	if err = repo.Save(r.Context(), task); err != nil {
		wbWriteBackfillError(w, 500, err.Error())
		return
	}
	clone := r.Clone(context.Background())
	go wbRunBackfill(repo, task.ID, clone)
	writeJSON(w, http.StatusAccepted, map[string]any{"data": task})
}

func wbMergeCurrentAccount(dst *wbRow, src wbRow) bool {
	status := strings.ToLower(strings.TrimSpace(dst.MetricStatus))
	if status != "" && status != "failed" && status != "timeout" && status != "source_error" {
		return false
	}
	dst.CCR, dst.NFS, dst.Revenue = src.CCR, src.NFS, src.Revenue
	dst.MetricStatus, dst.Source, dst.QueriedAt, dst.RequestID, dst.Error = src.MetricStatus, src.Source, src.QueriedAt, src.RequestID, src.Error
	return true
}

func wbEnrichCurrentAccountRows(ctx context.Context, request *http.Request, rows []wbRow, q wbRequest) ([]wbRow, error) {
	out := append([]wbRow(nil), rows...)
	ids := make([]string, 0, len(out))
	indices := make([]int, 0, len(out))
	for i, row := range out {
		if !wbChunkNeedsCurrentAccount([]wbRow{row}) {
			continue
		}
		ids = append(ids, row.Member.AccountID)
		indices = append(indices, i)
	}
	if len(indices) == 0 {
		return out, nil
	}
	metrics, err := queryAccountCurrentBatch(ctx, request, ids, q.Start, q.End, "et_current_ccr_nfs", "ET")
	if err != nil {
		return nil, err
	}
	for _, i := range indices {
		metric, ok := metrics[out[i].Member.AccountID]
		if !ok {
			return nil, fmt.Errorf("current_account_result_missing:%s", out[i].Member.AccountID)
		}
		out[i].CCR, out[i].NFS, out[i].Revenue = metric.CCR, metric.NFS, metric.Revenue
		out[i].MetricStatus, out[i].Source, out[i].QueriedAt, out[i].RequestID = metric.Status, metric.Source, metric.QueriedAt, metric.RequestID
	}
	return out, nil
}

var wbBackfillAnchorCache = struct {
	sync.Mutex
	key       string
	members   map[string]wbMember
	expiresAt time.Time
}{members: map[string]wbMember{}}

func wbBackfillETMembers(ctx context.Context, request *http.Request, q wbRequest, config wbConfig) (map[string]wbMember, error) {
	key := strings.Join([]string{q.Start, q.End, config.MembershipSource}, "|")
	wbBackfillAnchorCache.Lock()
	if wbBackfillAnchorCache.key == key && time.Now().Before(wbBackfillAnchorCache.expiresAt) {
		cached := wbBackfillAnchorCache.members
		wbBackfillAnchorCache.Unlock()
		return cached, nil
	}
	wbBackfillAnchorCache.Unlock()
	members, _, err := wbTargetedLoadMembers(ctx, request, q, config)
	if err != nil {
		return nil, err
	}
	byAccount := map[string]wbMember{}
	for _, member := range members {
		anchor, anchorDate := strings.TrimSpace(member.Start), member.CreateDate
		if anchor == "" {
			anchor = strings.TrimSpace(member.CreateDate)
		}
		for _, ticket := range member.Tickets {
			candidate := strings.TrimSpace(ticket.Start)
			if candidate == "" {
				candidate = strings.TrimSpace(ticket.CreateDate)
			}
			if candidate != "" && (anchor == "" || ticket.CreateDate > anchorDate || ticket.CreateDate == anchorDate && candidate > anchor) {
				anchor, anchorDate = candidate, ticket.CreateDate
			}
		}
		member.Start = anchor
		byAccount[member.AccountID] = member
	}
	wbBackfillAnchorCache.Lock()
	wbBackfillAnchorCache.key, wbBackfillAnchorCache.members, wbBackfillAnchorCache.expiresAt = key, byAccount, time.Now().Add(30*time.Minute)
	wbBackfillAnchorCache.Unlock()
	return byAccount, nil
}

func wbEnrichAccountComparisonRows(ctx context.Context, request *http.Request, rows []wbRow, q wbRequest) ([]wbRow, error) {
	out := append([]wbRow(nil), rows...)
	indices := make([]int, 0, len(out))
	pending := make([]wbRow, 0, len(out))
	for i, row := range out {
		if !wbChunkNeedsAccountComparison([]wbRow{row}) {
			continue
		}
		indices = append(indices, i)
		pending = append(pending, row)
	}
	if len(pending) == 0 {
		return out, nil
	}
	if strings.EqualFold(q.Program, "ET") {
		config, err := loadWBConfig()
		if err != nil {
			return nil, err
		}
		byAccount, membershipErr := wbBackfillETMembers(ctx, request, q, config)
		for i := range pending {
			if member, ok := byAccount[pending[i].Member.AccountID]; ok {
				pending[i].Member.Start, pending[i].Member.CreateDate, pending[i].Member.Tickets = member.Start, member.CreateDate, member.Tickets
			}
			if strings.TrimSpace(pending[i].Member.Start) == "" && membershipErr != nil {
				pending[i].Comparison = wbUnavailableComparison("ET", "", "create_time_technical_failed", time.Now())
				pending[i].Comparison.Source = map[string]any{"source": config.MembershipSource, "rid": 2933760, "query_status": "failed", "query_error": sanitizeLogText(membershipErr.Error())}
			}
		}
	}
	now := time.Now()
	if batchEnd, err := time.ParseInLocation("2006-01-02", strings.TrimSpace(q.End), cwLocation()); err == nil {
		now = batchEnd.AddDate(0, 0, 1)
	}
	// Keep rows together so wbApplyAccountComparisons can group equal anchor
	// windows and query up to 100 failed accounts at once. The previous per-row
	// worker fan-out created hundreds of simultaneous VQS calls and triggered
	// clickhouse/tableAccessFreqLimit.
	enriched := wbApplyRealComparisons(ctx, request, pending, now)
	for i, index := range indices {
		out[index] = enriched[i]
	}
	return out, nil
}

func wbEnrichAdvertiserRows(ctx context.Context, request *http.Request, rows []wbRow, q wbRequest, rule wbRule) ([]wbRow, error) {
	out := append([]wbRow(nil), rows...)
	indices := make([]int, 0, len(out))
	pending := make([]wbRow, 0, len(out))
	members := make([]wbMember, 0, len(out))
	for i, row := range out {
		if !wbChunkNeedsAdvertiserEnrichment([]wbRow{row}) {
			continue
		}
		indices = append(indices, i)
		pending = append(pending, row)
		members = append(members, row.Member)
	}
	if len(pending) == 0 {
		return out, nil
	}
	evidence, err := wbQueryPairEvidence(ctx, request, members, q, rule)
	if err != nil {
		return nil, err
	}
	enriched := applyPairEvidence(pending, evidence, q, rule)
	for i, index := range indices {
		out[index] = enriched[i]
	}
	return out, nil
}

func wbEnrichPersistedRows(ctx context.Context, request *http.Request, rows []wbRow, q wbRequest, rule wbRule) ([]wbRow, error) {
	working := append([]wbRow(nil), rows...)
	anchorFailures := map[string]map[string]any{}
	if strings.EqualFold(q.Program, "ET") {
		config, err := loadWBConfig()
		if err != nil {
			return nil, err
		}
		members, _, membershipErr := wbTargetedLoadMembers(ctx, request, q, config)
		byAccount := map[string]wbMember{}
		if membershipErr == nil {
			for _, member := range members {
				anchor, anchorDate := strings.TrimSpace(member.Start), member.CreateDate
				if anchor == "" {
					anchor = strings.TrimSpace(member.CreateDate)
				}
				for _, ticket := range member.Tickets {
					candidate := strings.TrimSpace(ticket.Start)
					if candidate == "" {
						candidate = strings.TrimSpace(ticket.CreateDate)
					}
					if candidate != "" && (anchor == "" || ticket.CreateDate > anchorDate || ticket.CreateDate == anchorDate && candidate > anchor) {
						anchor, anchorDate = candidate, ticket.CreateDate
					}
				}
				member.Start = anchor
				byAccount[member.AccountID] = member
			}
		}
		for i := range working {
			accountID := working[i].Member.AccountID
			if member, ok := byAccount[accountID]; ok {
				if strings.TrimSpace(member.Start) != "" {
					working[i].Member.Start = member.Start
				}
				working[i].Member.CreateDate = member.CreateDate
				working[i].Member.Tickets = member.Tickets
			}
			if strings.TrimSpace(working[i].Member.Start) != "" {
				continue
			}
			reason := "create_time_mapping_failed"
			evidence := map[string]any{"source": config.MembershipSource, "rid": 2933760, "account_id": accountID, "query_status": "success", "source_row_present": false}
			if membershipErr != nil {
				reason = "create_time_technical_failed"
				evidence["query_status"] = "failed"
				evidence["query_error"] = sanitizeLogText(membershipErr.Error())
			} else if _, ok := byAccount[accountID]; ok {
				reason = "create_time_source_null"
				evidence["source_row_present"] = true
				evidence["source_value"] = nil
			}
			anchorFailures[accountID] = map[string]any{"reason": reason, "evidence": evidence}
		}
	}
	now := time.Now()
	if batchEnd, err := time.ParseInLocation("2006-01-02", strings.TrimSpace(q.End), cwLocation()); err == nil {
		now = batchEnd.AddDate(0, 0, 1)
	}
	enriched := wbApplyRealComparisons(ctx, request, working, now)
	for i := range enriched {
		failure, ok := anchorFailures[enriched[i].Member.AccountID]
		if !ok {
			continue
		}
		reason := asString(failure["reason"])
		enriched[i].Comparison = wbUnavailableComparison("ET", "", reason, now)
		enriched[i].Comparison.Source = failure["evidence"].(map[string]any)
	}
	if strings.EqualFold(q.Program, "THT") {
		return enriched, nil
	}
	if len(working) > 1000 {
		// The W43 advertiser source was already attempted as one governed full-batch
		// query and returned a technical failure. Preserve all prior pair evidence and
		// avoid an unbounded retry loop while Account comparison remains deliverable.
		for i := range enriched {
			if len(enriched[i].Advertisers) == 0 && len(enriched[i].AdvertiserTop10) == 0 {
				enriched[i].AggregationNote = "advertiser_evidence_technical_failed:full_batch_source_retry_exhausted"
			}
		}
		return enriched, nil
	}
	members := make([]wbMember, 0, len(working))
	for _, row := range working {
		members = append(members, row.Member)
	}
	evidence, err := wbQueryPairEvidence(ctx, request, members, q, rule)
	if err != nil {
		// Account comparison and membership evidence are independently authoritative.
		// Persist them even when advertiser enrichment is temporarily unavailable,
		// while retaining an explicit retryable technical marker for empty pair rows.
		for i := range enriched {
			if len(enriched[i].Advertisers) == 0 && len(enriched[i].AdvertiserTop10) == 0 {
				enriched[i].AggregationNote = "advertiser_evidence_technical_failed:" + sanitizeLogText(err.Error())
			}
		}
		return enriched, nil
	}
	return applyPairEvidence(enriched, evidence, q, rule), nil
}

func wbPersistedETAnchors(state wbDisk) map[string]string {
	anchors := map[string]string{}
	for _, job := range state.Jobs {
		for _, row := range job.Rows {
			if !strings.EqualFold(row.Program, "ET") || strings.TrimSpace(row.Member.AccountID) == "" {
				continue
			}
			candidates := []string{strings.TrimSpace(row.Member.Start), strings.TrimSpace(row.Member.CreateDate)}
			for _, ticket := range row.Member.Tickets {
				candidates = append(candidates, strings.TrimSpace(ticket.Start), strings.TrimSpace(ticket.CreateDate))
			}
			for _, candidate := range candidates {
				if _, err := time.ParseInLocation("2006-01-02", dateOnly(candidate), cwLocation()); err == nil && candidate > anchors[row.Member.AccountID] {
					anchors[row.Member.AccountID] = candidate
				}
			}
		}
	}
	return anchors
}
