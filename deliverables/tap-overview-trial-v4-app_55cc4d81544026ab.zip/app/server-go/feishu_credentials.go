package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

var feishuSecretsMu sync.Mutex

type feishuCredentials struct {
	AppID     string `json:"app_id"`
	AppSecret string `json:"app_secret"`
}
type feishuBotSecret struct {
	AppID                string `json:"app_id"`
	AppSecret            string `json:"app_secret"`
	LastValidatedAt      string `json:"last_validated_at,omitempty"`
	LastValidationResult string `json:"last_validation_result,omitempty"`
}

func feishuSecretsPath() (string, error) {
	d := strings.TrimSpace(os.Getenv("AIME_PLUGIN_DATA_DIR"))
	if d == "" {
		return "", errors.New("AIME_PLUGIN_DATA_DIR 未设置，拒绝回退到临时或源码目录")
	}
	return filepath.Join(d, "secrets.json"), nil
}
func loadFeishuCredentials() (feishuCredentials, string, error) {
	if id, sec := strings.TrimSpace(os.Getenv("TAP_FEISHU_APP_ID")), strings.TrimSpace(os.Getenv("TAP_FEISHU_APP_SECRET")); id != "" || sec != "" {
		if id == "" || sec == "" {
			return feishuCredentials{}, "environment", errors.New("环境变量凭证配置不完整")
		}
		return feishuCredentials{id, sec}, "environment", nil
	}
	p, e := feishuSecretsPath()
	if e != nil {
		return feishuCredentials{}, "none", e
	}
	b, e := os.ReadFile(p)
	if os.IsNotExist(e) {
		return feishuCredentials{}, "none", nil
	}
	if e != nil {
		return feishuCredentials{}, "file", e
	}
	var root map[string]json.RawMessage
	if json.Unmarshal(b, &root) != nil {
		return feishuCredentials{}, "file", errors.New("secrets.json 已损坏，拒绝覆盖")
	}
	var s feishuBotSecret
	if v := root["feishu_bot"]; len(v) > 0 && json.Unmarshal(v, &s) != nil {
		return feishuCredentials{}, "file", errors.New("feishu_bot 配置损坏")
	}
	return feishuCredentials{s.AppID, s.AppSecret}, "file", nil
}
func maskAppID(s string) string {
	s = strings.TrimSpace(s)
	if len(s) < 9 {
		return "***"
	}
	return s[:4] + "***" + s[len(s)-4:]
}
func validateCredentialInput(s string) bool {
	if len(s) < 6 || len(s) > 512 {
		return false
	}
	for _, r := range s {
		if r < 32 || r == 127 {
			return false
		}
	}
	return true
}
func validateFeishuCredentials(ctx context.Context, c feishuCredentials) error {
	out, e := cwHTTP(ctx, "POST", "/open-apis/auth/v3/tenant_access_token/internal", "", map[string]string{"app_id": c.AppID, "app_secret": c.AppSecret})
	if e != nil {
		return e
	}
	if t, _ := out["tenant_access_token"].(string); t == "" {
		return errors.New("飞书返回成功但 token 为空")
	}
	return nil
}
func saveFeishuCredentials(c feishuCredentials) error {
	feishuSecretsMu.Lock()
	defer feishuSecretsMu.Unlock()
	p, e := feishuSecretsPath()
	if e != nil {
		return e
	}
	if e = os.MkdirAll(filepath.Dir(p), 0700); e != nil {
		return e
	}
	root := map[string]json.RawMessage{}
	if b, er := os.ReadFile(p); er == nil {
		if json.Unmarshal(b, &root) != nil {
			return errors.New("secrets.json 已损坏，拒绝覆盖")
		}
	} else if !os.IsNotExist(er) {
		return er
	}
	old := map[string]any{}
	if v := root["feishu_bot"]; len(v) > 0 && json.Unmarshal(v, &old) != nil {
		return errors.New("feishu_bot 配置损坏，拒绝覆盖")
	}
	old["app_id"] = c.AppID
	old["app_secret"] = c.AppSecret
	old["last_validated_at"] = cwNow()
	old["last_validation_result"] = "success"
	v, _ := json.Marshal(old)
	root["feishu_bot"] = v
	b, _ := json.MarshalIndent(root, "", "  ")
	tmp, e := os.OpenFile(p+".tmp", os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
	if e != nil {
		return e
	}
	ok := false
	defer func() {
		tmp.Close()
		if !ok {
			os.Remove(tmp.Name())
		}
	}()
	if _, e = tmp.Write(b); e != nil {
		return e
	}
	if e = tmp.Sync(); e != nil {
		return e
	}
	if e = tmp.Close(); e != nil {
		return e
	}
	if e = os.Rename(tmp.Name(), p); e != nil {
		return e
	}
	if e = os.Chmod(p, 0600); e != nil {
		return e
	}
	ok = true
	return nil
}
func clearFeishuTokenCache() {
	cwTokenMu.Lock()
	defer cwTokenMu.Unlock()
	cwTokenValue = ""
	cwTokenApp = ""
	cwTokenUntil = time.Time{}
}
func feishuConfigStatusData() map[string]any {
	c, source, e := loadFeishuCredentials()
	status := "not_configured"
	result := ""
	at := ""
	if e != nil {
		status = "validation_failed"
		result = e.Error()
	} else if c.AppID != "" && c.AppSecret != "" {
		status = "configured"
	}
	if source == "file" {
		p, _ := feishuSecretsPath()
		b, _ := os.ReadFile(p)
		var root map[string]json.RawMessage
		var s feishuBotSecret
		if json.Unmarshal(b, &root) == nil {
			_ = json.Unmarshal(root["feishu_bot"], &s)
			at = s.LastValidatedAt
			result = s.LastValidationResult
		}
	}
	return map[string]any{"status": status, "configured": status == "configured", "app_id_masked": maskAppID(c.AppID), "source": source, "environment_override": source == "environment", "last_validated_at": at, "last_validation_result": result}
}
func safeFeishuError(e error) error {
	if e == nil {
		return nil
	}
	return fmt.Errorf("凭证验证失败：%s", e.Error())
}

func requireCredentialAdmin(w http.ResponseWriter, r *http.Request) (cwConfig, bool) {
	cfg, e := cwLoadConfig()
	if e != nil {
		cwWriteError(w, e)
		return cfg, false
	}
	if !cwOperator(cfg, requestUsername(r)) {
		cwWriteError(w, cwErr(403, "仅凭证管理员可操作飞书 Bot 配置"))
		return cfg, false
	}
	return cfg, true
}
func feishuConfigStatusHandler(w http.ResponseWriter, r *http.Request) {
	if _, ok := requireCredentialAdmin(w, r); !ok {
		return
	}
	writeJSON(w, 200, map[string]any{"data": feishuConfigStatusData()})
}
func feishuCredentialsHandler(w http.ResponseWriter, r *http.Request) {
	if _, ok := requireCredentialAdmin(w, r); !ok {
		return
	}
	if strings.TrimSpace(os.Getenv("TAP_FEISHU_APP_ID")) != "" || strings.TrimSpace(os.Getenv("TAP_FEISHU_APP_SECRET")) != "" {
		cwWriteError(w, cwErr(409, "当前由环境变量覆盖凭证；页面保存会被忽略，已阻止保存。请先移除 TAP_FEISHU_APP_ID/TAP_FEISHU_APP_SECRET 并重启服务"))
		return
	}
	var in struct {
		AppID     string `json:"app_id"`
		AppSecret string `json:"app_secret"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 2048)).Decode(&in) != nil {
		cwWriteError(w, cwErr(400, "无效请求"))
		return
	}
	in.AppID = strings.TrimSpace(in.AppID)
	in.AppSecret = strings.TrimSpace(in.AppSecret)
	if !validateCredentialInput(in.AppID) || !validateCredentialInput(in.AppSecret) {
		cwWriteError(w, cwErr(400, "App ID 或 App Secret 为空、长度异常或含控制字符"))
		return
	}
	c := feishuCredentials{in.AppID, in.AppSecret}
	ctx, cancel := context.WithTimeout(r.Context(), 8*time.Second)
	defer cancel()
	if e := validateFeishuCredentials(ctx, c); e != nil {
		cwWriteError(w, cwErr(400, safeFeishuError(e).Error()))
		return
	}
	if e := saveFeishuCredentials(c); e != nil {
		cwWriteError(w, cwErr(500, "凭证有效，但持久化保存失败；旧配置保持不变"))
		return
	}
	clearFeishuTokenCache()
	writeJSON(w, 200, map[string]any{"data": feishuConfigStatusData()})
}
