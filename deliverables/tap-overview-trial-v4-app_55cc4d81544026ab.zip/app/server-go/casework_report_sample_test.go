package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// TestGenerateAnalyticsHTMLSample renders an explicitly supplied real analytics
// response through the same report builder used by live and immutable reports.
// It is skipped during normal test runs.
func TestGenerateAnalyticsHTMLSample(t *testing.T) {
	input := os.Getenv("TAP_REPORT_SAMPLE_INPUT")
	output := os.Getenv("TAP_REPORT_SAMPLE_OUTPUT")
	if input == "" || output == "" {
		t.Skip("sample input/output not requested")
	}
	raw, err := os.ReadFile(input)
	if err != nil {
		t.Fatal(err)
	}
	raw = bytes.TrimSpace(raw)
	raw = bytes.TrimPrefix(raw, []byte("<output>"))
	raw = bytes.TrimSuffix(bytes.TrimSpace(raw), []byte("</output>"))
	var response struct {
		Data cwAnalytics `json:"data"`
	}
	if err := json.Unmarshal(bytes.TrimSpace(raw), &response); err != nil {
		t.Fatal(err)
	}
	response.Data.GeneratedAt = response.Data.AsOf
	cwEnrichAnalytics(&response.Data)
	cwAttachQuotaAlerts(&response.Data)
	if err := os.MkdirAll(filepath.Dir(output), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(output, []byte(cwAnalyticsHTML(response.Data)), 0o644); err != nil {
		t.Fatal(err)
	}
}
