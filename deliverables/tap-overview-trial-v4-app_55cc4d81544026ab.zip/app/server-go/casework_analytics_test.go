package main

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"strings"
	"testing"
)

func putAnalyticsCase(t *testing.T, a cwCase) {
	t.Helper()
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	body, _ := json.Marshal(a)
	if _, err = db.Exec("INSERT OR REPLACE INTO tap_cases(id,version,body) VALUES(?,?,?)", a.ID, a.Version, string(body)); err != nil {
		t.Fatal(err)
	}
}

func TestAnalyticsFilteringDedupAndPersistence(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	base := cwCase{ID: "A1", Version: 1, Status: "open", Owner: "owner-a", CreatedAt: "2026-10-19T01:00:00Z", UpdatedAt: "2026-10-19T01:00:00Z", Row: wbRow{Program: "ET", Level: "critical", Member: wbMember{AccountID: "100", Region: "APAC"}}, Fields: map[string]string{}}
	putAnalyticsCase(t, base)
	second := base
	second.ID = "A2"
	second.Status = "pending_review"
	second.Version = 2
	putAnalyticsCase(t, second)
	x, err := cwAnalyticsBuild(cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-19", Region: "APAC", Program: "ET", Owner: "owner-a", Level: "critical"})
	if err != nil {
		t.Fatal(err)
	}
	if x.Summary["alerts"] != 2 || x.Summary["clients"] != 1 || x.Summary["pending_review"] != 1 || x.EffectStatus["waiting_recheck"] != 0 {
		t.Fatalf("unexpected summary/effect status: %#v %#v", x.Summary, x.EffectStatus)
	}
	second.Status = "closed"
	second.ClosedAt = "2026-10-19T04:00:00Z"
	second.Version = 3
	putAnalyticsCase(t, second)
	x, err = cwAnalyticsBuild(cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-19"})
	if err != nil {
		t.Fatal(err)
	}
	if x.Summary["closed"] != 1 || x.Summary["pending_review"] != 0 {
		t.Fatalf("status update not reflected: %#v", x.Summary)
	}
	// cwAnalyticsBuild opens a fresh database handle, proving persisted data survives reconnects.
}

func TestAnalyticsExcelUsesFilteredCases(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	putAnalyticsCase(t, cwCase{ID: "ONLY", Version: 1, Status: "open", Owner: "owner", CreatedAt: "2026-10-19T01:00:00Z", UpdatedAt: "2026-10-19T01:00:00Z", Row: wbRow{Program: "THT", Level: "watch", Member: wbMember{AdvertiserID: "200", Region: "NA"}}, Fields: map[string]string{}})
	x, err := cwAnalyticsBuild(cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-19", Program: "THT"})
	if err != nil {
		t.Fatal(err)
	}
	r := httptest.NewRecorder()
	if err = cwWriteXLSX(r, x); err != nil {
		t.Fatal(err)
	}
	zr, err := zip.NewReader(bytes.NewReader(r.Body.Bytes()), int64(r.Body.Len()))
	if err != nil {
		t.Fatal(err)
	}
	if len(zr.File) < 7 {
		t.Fatalf("invalid workbook, files=%d", len(zr.File))
	}
	if r.Header().Get("Content-Type") != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" {
		t.Fatal("wrong excel content type")
	}
}

func TestAnalyticsWeeklyClosedCaseUsesBatchScopeAndDedupesProcessedClients(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	job := readModelFixture(t, 1)
	closed := cwCase{
		ID: "TAP-ff4e02e70f1f4998ca1d0c3c", Version: 2, Status: "closed",
		Creator: "heyangyang.31", ScanID: job.ID,
		CreatedAt: "2026-10-19T01:00:00Z", UpdatedAt: "2026-10-23T07:30:18Z",
		Row:    wbRow{ID: job.Rows[0].ID, Program: "THT", Level: "critical", Member: wbMember{AccountID: "account-1", AdvertiserID: "advertiser-1", Tier: "THT", Region: "APAC"}},
		Fields: map[string]string{},
	}
	putAnalyticsCase(t, closed)
	duplicateCustomer := closed
	duplicateCustomer.ID = "TAP-second-closed-event"
	putAnalyticsCase(t, duplicateCustomer)

	req := httptest.NewRequest("GET", "/api/workbench/analytics?time_mode=weekly&batch_id="+job.BatchID+"&case_scope=all", nil).WithContext(wbReq("reader").Context())
	rr := httptest.NewRecorder()
	cwAnalyticsHandler(rr, req)
	var body struct {
		Data cwAnalytics `json:"data"`
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	if rr.Code != 200 || body.Data.Summary["closed"] != 2 || body.Data.Summary["processed_clients"] != 1 || len(body.Data.Cases) != 2 {
		t.Fatalf("closed weekly cases missing from analytics: %s", rr.Body.String())
	}
	if body.Data.Filters.CaseScope != "all" || body.Data.Filters.BatchID != job.BatchID || body.Data.Filters.Start != "2026-10-12" || body.Data.Filters.End != "2026-10-18" {
		t.Fatalf("weekly filter explanation mismatch: %+v", body.Data.Filters)
	}
}

func TestAnalyticsIncludesMatchedSourceAlertsWithoutCreatingCases(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	f := cwAnalyticsFilter{
		TimeMode: "weekly", Start: "2026-10-19", End: "2026-10-25",
		ScanIDs: map[string]bool{"scan-source": true},
		Jobs:    []wbJob{{ID: "scan-source", BatchID: "TAP-WEEK-2026-10-19-2026-10-25", AsOf: "2026-10-26T03:00:00Z", Status: "partial", Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rule: wbRule{Version: "ET-rule"}, Rows: []wbRow{{ID: "risk-row", Program: "ET", Level: "critical", Member: wbMember{AccountID: "100", Region: "APAC"}}}}},
	}
	x, err := cwAnalyticsBuild(f)
	if err != nil {
		t.Fatal(err)
	}
	if x.Summary["alerts"] != 1 || x.Summary["source_alerts"] != 1 || len(x.Cases) != 1 {
		t.Fatalf("source alert was not included: summary=%v cases=%d", x.Summary, len(x.Cases))
	}
	if x.Cases[0].Status != "source_alert" {
		t.Fatalf("source alert must remain read-only and untriaged: %+v", x.Cases[0])
	}
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	var n int
	if err = db.QueryRow("SELECT count(*) FROM tap_cases").Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 0 {
		t.Fatalf("report read must not create business cases, got %d", n)
	}
}

func TestAnalyticsMappingMetadataAndHTMLArchitecture(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	x, err := cwAnalyticsBuild(cwAnalyticsFilter{
		TimeMode: "weekly", Start: "2026-10-19", End: "2026-10-25",
		ScanIDs: map[string]bool{"scan": true},
		Jobs: []wbJob{{
			ID:      "scan",
			Rule:    wbRule{Enabled: true, BusinessConfirmed: true, WatchCCR: 7, WatchNFS: 300, CriticalCCR: 45},
			Request: wbRequest{Program: "ET"},
			Rows:    []wbRow{{ID: "row", Program: "ET", Level: "critical", CCR: f64(50), NFS: f64(400), Reasons: []string{"CCR 50 and NFS 400 long description must not become a bar"}, Member: wbMember{AccountID: "7462465462811770896", Region: "APAC"}}},
		}},
	})
	if err != nil {
		t.Fatal(err)
	}
	if x.Meta.LevelBasis == "" || x.Meta.CaseworkBasis == "" || len(x.RiskSource) != 1 || x.RiskSource[0].Key != "absolute" {
		t.Fatalf("mapping contract missing: %+v %+v", x.Meta, x.RiskSource)
	}
	x.Quota = map[string]any{"status": "available", "quarter": "Q4", "global": map[string]any{}, "regions": []map[string]any{}}
	cwAttachQuotaAlerts(&x)
	html := cwAnalyticsHTML(x)
	for _, heading := range []string{"A1 本期风险概况", "重点风险客户", "A2 通知与处置", "A3 核查结论与动作", "A4 处理后观察", "ET Quota Alerts", "ST Quota Alerts"} {
		if !bytes.Contains([]byte(html), []byte(heading)) {
			t.Fatalf("missing heading %s", heading)
		}
	}
	for _, styleContract := range []string{"@media print", "display:table-header-group", "break-inside:avoid", "grid-template-columns:repeat(5", "class=formula", "class=mini-track", "rule-facts"} {
		if !bytes.Contains([]byte(html), []byte(styleContract)) {
			t.Fatalf("missing report style contract %s", styleContract)
		}
	}
	for _, removed := range []string{"优先跟进清单", "数据缺口与口径", "超额数量"} {
		if bytes.Contains([]byte(html), []byte(removed)) {
			t.Fatalf("removed report content still present: %s", removed)
		}
	}
	if !bytes.Contains([]byte(html), []byte("CCR 50 and NFS 400 long description must not become a bar")) {
		t.Fatal("trigger criteria missing from structured evidence")
	}
	if bytes.Contains([]byte(html), []byte("<span>CCR 50 and NFS 400 long description must not become a bar</span>")) {
		t.Fatal("free-text trigger criteria leaked into report chart labels")
	}
}

func TestAnalyticsRuleMissingDoesNotGuessFromReason(t *testing.T) {
	x := cwAnalytics{Filters: cwAnalyticsFilter{}, Cases: []cwCase{{ID: "A", ScanID: "S", Row: wbRow{ID: "R", Program: "ET", Level: "critical", CCR: f64(99), NFS: f64(999), Reasons: []string{"pretend top20"}, Member: wbMember{AccountID: "1"}}}}, SourceByCase: map[string][]string{}}
	cwEnrichAnalytics(&x)
	if x.RuleSummaries[0].Condition != "规则说明待补齐" || len(x.SourceByCase["A"]) != 1 || x.SourceByCase["A"][0] != "unidentified" {
		t.Fatalf("missing snapshot must stay explicit and must not parse reason/metrics: %+v %+v", x.RuleSummaries, x.SourceByCase)
	}
}

func TestPriorityClientsMergeExtremeAllAndWatchFill(t *testing.T) {
	cases := []cwCase{}
	sources := map[string][]string{}
	for i := 0; i < 12; i++ {
		level := "watch"
		if i < 7 {
			level = "critical"
		}
		ccr, nfs := float64(20-i), float64(200-i)
		caseID := fmt.Sprintf("C%d", i)
		cases = append(cases, cwCase{ID: caseID, Status: "open", Row: wbRow{Program: "ET", Level: level, CCR: &ccr, NFS: &nfs, Member: wbMember{AccountID: fmt.Sprintf("%02d", i)}}})
		sources[caseID] = []string{"absolute"}
	}
	// Same Program + customer must merge and preserve all types/event count.
	duplicate := cases[0]
	duplicate.ID = "duplicate"
	duplicate.Status = "closed"
	cases = append(cases, duplicate)
	sources[duplicate.ID] = []string{"growth_top20"}
	rows := cwPriorityClients(cases, sources)
	if len(rows) != 10 || rows[0].EventCount != 2 || len(rows[0].AlertTypes) != 2 {
		t.Fatalf("merge/fill mismatch: %+v", rows)
	}
	for i := 0; i < 7; i++ {
		if rows[i].Severity != "critical" {
			t.Fatalf("extreme customer omitted: %+v", rows)
		}
	}
	// More than 10 extreme customers means all are returned.
	for i := 12; i < 17; i++ {
		ccr := float64(i)
		nfs := float64(i)
		cases = append(cases, cwCase{ID: fmt.Sprint(i), Status: "open", Row: wbRow{Program: "ET", Level: "critical", CCR: &ccr, NFS: &nfs, Member: wbMember{AccountID: fmt.Sprint(i)}}})
	}
	if got := cwPriorityClients(cases, sources); len(got) != 12 {
		t.Fatalf("all extreme customers must remain, got %d", len(got))
	}
}

func TestQuotaSectionsSeparateAndBoundary(t *testing.T) {
	q := map[string]any{"quarter": "Q4", "global": map[string]any{"et": map[string]any{"account_count": 100, "quota": 6356, "ratio": 1.6}, "st": map[string]any{"brand_count": 100, "quota": 817, "ratio": 12.2}}, "regions": []map[string]any{{"region": "A", "et": map[string]any{"account_count": 10, "quota": 10, "ratio": float64(100), "exceeded": 0}, "st": map[string]any{"brand_count": 11, "quota": 10, "ratio": float64(110), "exceeded": 1}}}}
	et, st := cwBuildQuotaSection("ET", q, cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-25"}), cwBuildQuotaSection("ST", q, cwAnalyticsFilter{})
	if et.FullRegions != 1 || et.ExceededRegions != 0 || st.FullRegions != 0 || st.ExceededRegions != 1 || *et.Quota != 6356 || *st.Quota != 817 {
		t.Fatalf("quota boundary/scope mismatch: %+v %+v", et, st)
	}
	if et.Rows[0].CaseStatus != "—" || st.Rows[0].CaseStatus != "未关联事件" {
		t.Fatalf("quota case linkage mismatch")
	}
}

func TestAnalyticsThreeSurfacesShareSections(t *testing.T) {
	x := cwAnalytics{Summary: map[string]int{}, Filters: cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-25"}, Meta: cwAnalyticsMeta{}, Notification: map[string]map[string]int{"formal": {}, "test": {}}, Effects: map[string]int{}, EffectStatus: map[string]int{}, Quota: map[string]any{"status": "available"}, QuotaAlerts: cwQuotaAlerts{ET: cwQuotaAlertSection{Title: "ET Quota Alerts"}, ST: cwQuotaAlertSection{Title: "ST Quota Alerts"}}}
	h := cwAnalyticsHTML(x)
	for _, text := range []string{"预警类型与触发规则", "重点风险客户", "ET Quota Alerts", "ST Quota Alerts", "Notification Status", "Case Status"} {
		if !strings.Contains(h, text) {
			t.Fatalf("shared HTML section missing %q", text)
		}
	}
}
