package main

import "strings"

func classifyTitanVQSFailure(step titanProbeStep, diag chartDiagnostics) string {
	if step.HTTPStatus >= 500 && strings.Contains(step.ResponsePreview, "toUpperCase") {
		if len(diag.OriginalVsSentDiffs) > 0 {
			return "chart_mutation_error"
		}
		if len(diag.LikelyProblemPaths) > 0 || len(diag.SuspiciousPaths) > 0 {
			return "simple_chart_schema_error"
		}
		return "unsupported_report_type"
	}
	if step.ErrorType == "rows_not_found" && step.HTTPStatus >= 500 {
		return "aeolus_server_error"
	}
	if step.ErrorType == "non_json_response" || step.ErrorType == "network_error" {
		return "aeolus_server_error"
	}
	return "unknown"
}
