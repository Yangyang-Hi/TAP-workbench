package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"
)

func TestCloudCaseworkCrossInstanceReadAndConcurrentCAS(t *testing.T) {
	var mu sync.Mutex
	current := cwCase{ID: "TAP-cross-instance", Version: 2, Status: "open", Kind: "customer", Owner: "owner", UpdatedAt: "2026-10-26T11:00:00Z"}
	updateCalls := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		if r.URL.Path == "/api/v2/tables/tap_cases/query" {
			_ = json.NewEncoder(w).Encode(map[string]any{"code": 0, "data": map[string]any{"records": []any{cloudCaseRecord(current)}}})
			return
		}
		if r.URL.Path == "/api/v2/tables/tap_cases/records/update" {
			var body map[string]any
			_ = json.NewDecoder(r.Body).Decode(&body)
			data := body["data"].(map[string]any)
			next := int(asInt64(data["version"]))
			updated := int64(0)
			if updateCalls == 0 && next == current.Version+1 {
				raw, _ := json.Marshal(data["body"])
				_ = json.Unmarshal(raw, &current)
				updated = 1
			}
			updateCalls++
			_ = json.NewEncoder(w).Encode(map[string]any{"code": 0, "data": map[string]any{"updated_count": updated}})
			return
		}
		http.NotFound(w, r)
	}))
	defer srv.Close()
	newRepo := func() *cloudCaseworkRepository {
		return &cloudCaseworkRepository{db: &cloudStore{baseURL: srv.URL, appID: "app", apiKey: "key"}}
	}
	a, err := newRepo().caseByID(context.Background(), current.ID)
	if err != nil || a.Version != 2 {
		t.Fatalf("cross-instance read: %#v %v", a, err)
	}
	a.Version = 3
	if err = newRepo().saveCaseCAS(context.Background(), a, 2); err != nil {
		t.Fatal(err)
	}
	stale := a
	stale.Version = 4
	if err = newRepo().saveCaseCAS(context.Background(), stale, 2); err == nil {
		t.Fatal("stale concurrent update must conflict")
	}
}

func TestCloudOutboxUpsertKeepsNotificationIdempotencyKey(t *testing.T) {
	calls := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls++
		var body map[string]any
		_ = json.NewDecoder(r.Body).Decode(&body)
		fields := body["conflict_fields"].([]any)
		if len(fields) != 1 || fields[0] != "outbox_id" {
			t.Errorf("unexpected conflict fields: %#v", fields)
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"code": 0, "data": map[string]any{}})
	}))
	defer srv.Close()
	repo := &cloudCaseworkRepository{db: &cloudStore{baseURL: srv.URL, appID: "app", apiKey: "key"}}
	n := cwNotice{ID: "notice-1", CaseID: "TAP-1", Kind: "send", Status: "pending", UpdatedAt: "2026-10-26T11:00:00Z"}
	if err := repo.upsertNotice(context.Background(), n, "idem-1", 0); err != nil {
		t.Fatal(err)
	}
	if err := repo.upsertNotice(context.Background(), n, "idem-1", 0); err != nil {
		t.Fatal(err)
	}
	if calls != 2 {
		t.Fatalf("expected repeatable upsert, got %d", calls)
	}
}

func TestProductionCloudRepositoryFailsFastWithoutCredentials(t *testing.T) {
	t.Setenv("DB_APP_ID", "")
	t.Setenv("DB_API_KEY", "")
	if _, err := newCloudCaseworkRepository(); err == nil {
		t.Fatal("production repository must not fall back when Cloud credentials are missing")
	}
}

type failingCaseworkRepository struct{ err error }

func (r failingCaseworkRepository) listCases(context.Context) ([]cwCase, error) { return nil, r.err }
func (r failingCaseworkRepository) caseByID(context.Context, string) (cwCase, error) {
	return cwCase{}, r.err
}
func (r failingCaseworkRepository) createCase(context.Context, cwCase) (cwCase, error) {
	return cwCase{}, r.err
}
func (r failingCaseworkRepository) saveCaseCAS(context.Context, cwCase, int) error { return r.err }
func (r failingCaseworkRepository) command(context.Context, string, string) (string, bool, error) {
	return "", false, r.err
}
func (r failingCaseworkRepository) putCommand(context.Context, string, string, string, int) error {
	return r.err
}
func (r failingCaseworkRepository) listNotices(context.Context) ([]cwNotice, error) {
	return nil, r.err
}
func (r failingCaseworkRepository) notices(context.Context, string) ([]cwNotice, error) {
	return nil, r.err
}
func (r failingCaseworkRepository) upsertNotice(context.Context, cwNotice, string, int64) error {
	return r.err
}
func (r failingCaseworkRepository) queueUpdates(context.Context, cwCase) error { return r.err }

func TestSharedCloudStoreOmitsOnlyInstancePartitionHeader(t *testing.T) {
	t.Setenv("DB_APP_ID", "app-boundary-a")
	t.Setenv("DB_API_KEY", "secret")
	t.Setenv("DB_BASE_URL", "https://db.example.test")
	shared, err := newSharedCloudStore()
	if err != nil {
		t.Fatal(err)
	}
	shared.instanceID = "instance-b"
	if got := shared.headers().Get("X-App-Instance-Id"); got != "" {
		t.Fatalf("shared casework leaked instance partition header: %q", got)
	}
	if got := shared.headers().Get("X-App-Id"); got != "app-boundary-a" {
		t.Fatalf("shared store crossed App boundary: %q", got)
	}
	isolated, err := newCloudStore()
	if err != nil {
		t.Fatal(err)
	}
	isolated.instanceID = "instance-a"
	if got := isolated.headers().Get("X-App-Instance-Id"); got != "instance-a" {
		t.Fatalf("non-casework domain lost instance isolation: %q", got)
	}
}

func TestCaseDetailCloudFailureIsNotNotFound(t *testing.T) {
	wbTestEnv(t)
	old := cwCaseworkRepositoryProvider
	cwCaseworkRepositoryProvider = func() (caseworkRepository, error) {
		return failingCaseworkRepository{err: errors.New("cloud unavailable")}, nil
	}
	t.Cleanup(func() { cwCaseworkRepositoryProvider = old })
	req := httptest.NewRequest(http.MethodGet, "/api/workbench/cases/TAP-failure", nil)
	req.SetPathValue("id", "TAP-failure")
	req = req.WithContext(context.WithValue(req.Context(), ctxKeyUser, authResult{Username: "owner"}))
	res := httptest.NewRecorder()
	cwGetHandler(res, req)
	if res.Code < 500 || res.Code == http.StatusNotFound {
		t.Fatalf("Cloud error was disguised as 404: status=%d body=%s", res.Code, res.Body.String())
	}
}

func TestCaseDetailReturns404OnlyForMissingSharedCase(t *testing.T) {
	wbTestEnv(t)
	old := cwCaseworkRepositoryProvider
	cwCaseworkRepositoryProvider = func() (caseworkRepository, error) {
		return failingCaseworkRepository{err: sql.ErrNoRows}, nil
	}
	t.Cleanup(func() { cwCaseworkRepositoryProvider = old })
	req := httptest.NewRequest(http.MethodGet, "/api/workbench/cases/TAP-missing", nil)
	req.SetPathValue("id", "TAP-missing")
	req = req.WithContext(context.WithValue(req.Context(), ctxKeyUser, authResult{Username: "owner"}))
	res := httptest.NewRecorder()
	cwGetHandler(res, req)
	if res.Code != http.StatusNotFound {
		t.Fatalf("missing shared case status=%d body=%s", res.Code, res.Body.String())
	}
}
