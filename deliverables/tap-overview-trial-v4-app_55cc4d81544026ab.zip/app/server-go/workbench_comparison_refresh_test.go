package main

import (
	"context"
	"net/http"
	"testing"
	"time"
)

func TestComparisonWindowUsesTwoCompleteSevenDayWindows(t *testing.T) {
	now := time.Date(2026, 10, 14, 0, 0, 0, 0, cwLocation())
	window, err := wbBuildComparisonWindow("ET", "2026-10-07 14:51:28", now)
	if err != nil {
		t.Fatal(err)
	}
	if window.PreStart != "2026-09-30" || window.PreEnd != "2026-10-06" || window.PostStart != "2026-10-07" || window.PostEnd != "2026-10-13" || !window.Complete {
		t.Fatalf("unexpected boundaries: %+v", window)
	}
}

func TestTargetedComparisonRefreshOnlyMutatesMatchingRows(t *testing.T) {
	wbTestEnv(t)
	accountID := "7244006541899137025"
	otherID := "7000000000000000001"
	status := "handled"
	state := wbDisk{Jobs: map[string]wbJob{
		"et-current": {ID: "et-current", BatchID: "TAP-WEEK-2026-10-12-2026-10-18", Request: wbRequest{Program: "ET", Start: "2026-10-12", End: "2026-10-18", MemberStart: "2026-10-01", MemberEnd: "2026-10-18"}, Rows: []wbRow{{ID: "target", Program: "ET", Member: wbMember{AccountID: accountID}}, {ID: "other", Program: "ET", Member: wbMember{AccountID: otherID}}}},
	}, Actions: map[string]wbAction{"case": {AlertID: "case", Status: status}}}
	if err := wbWriteDisk(state); err != nil {
		t.Fatal(err)
	}
	oldLoad, oldQuery := wbTargetedLoadMembers, wbTargetedQueryAccount
	defer func() { wbTargetedLoadMembers, wbTargetedQueryAccount = oldLoad, oldQuery }()
	wbTargetedLoadMembers = func(_ context.Context, request *http.Request, q wbRequest, _ wbConfig) ([]wbMember, bool, error) {
		if request.URL.Query().Get("account_id") != accountID || request.URL.Query().Get("client_ids") != accountID {
			t.Fatalf("membership was not account-targeted: %s", request.URL.RawQuery)
		}
		return []wbMember{{AccountID: accountID, Start: "2026-10-07 14:51:28"}}, true, nil
	}
	calls := 0
	wbTargetedQueryAccount = func(_ context.Context, _ *http.Request, ids []string, start, end, source, program string) (map[string]wbBatchMetric, error) {
		calls++
		if len(ids) != 1 || ids[0] != accountID || source != "et_current_ccr_nfs" || program != "ET" {
			t.Fatalf("query was not targeted: ids=%v source=%s program=%s", ids, source, program)
		}
		value := 140.41670219720874
		if start == "2026-10-07" && end == "2026-10-13" {
			value = 326.25199201937437
		} else if start != "2026-09-30" || end != "2026-10-06" {
			t.Fatalf("unexpected window %s..%s", start, end)
		}
		return map[string]wbBatchMetric{accountID: {Status: "success", CCR: &value, RequestID: start + "-request", LogID: start + "-log"}}, nil
	}
	result, err := wbRefreshComparison(context.Background(), wbReq("operator"), accountID, "ET", time.Date(2026, 10, 26, 12, 0, 0, 0, cwLocation()))
	if err != nil {
		t.Fatal(err)
	}
	if calls != 2 || result["updated_rows"] != 1 || result["targeted_only"] != true {
		t.Fatalf("unexpected refresh result: %#v calls=%d", result, calls)
	}
	after, err := wbReadDisk()
	if err != nil {
		t.Fatal(err)
	}
	job := after.Jobs["et-current"]
	if job.Rows[0].Member.Start != "2026-10-07 14:51:28" || job.Rows[0].Comparison.PreCCR == nil || job.Rows[0].Comparison.PostCCR == nil || job.Rows[0].Comparison.ProtectionCCRGrowthPct == nil {
		t.Fatalf("target comparison not persisted: %+v", job.Rows[0])
	}
	if delta := *job.Rows[0].Comparison.ProtectionCCRGrowthPct - 132.3455735067532; delta < -1e-12 || delta > 1e-12 {
		t.Fatalf("growth precision changed: %.15f", *job.Rows[0].Comparison.ProtectionCCRGrowthPct)
	}
	if job.Rows[1].Member.Start != "" || job.Rows[1].Comparison.Status != "" {
		t.Fatalf("non-target row mutated: %+v", job.Rows[1])
	}
	if after.Actions["case"].Status != status {
		t.Fatalf("case action changed: %+v", after.Actions["case"])
	}
}
