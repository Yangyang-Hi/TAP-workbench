package main

import (
	"encoding/json"
	"strings"
	"testing"
)

func presentationFixture() cwCase {
	ccrValue, nfsValue, revenueValue := 2890.173410404624, float64(1), 12345.6
	return cwCase{
		ID: "TAP-fixture", Status: "processing",
		Window: wbRequest{Start: "2026-10-19", End: "2026-10-25"},
		Rule:   wbRule{Enabled: true, WatchCCR: 1, WatchNFS: 0, CriticalCCR: 9999},
		Row: wbRow{
			Program: "ET", Level: "watch", CCR: &ccrValue, NFS: &nfsValue, Revenue: &revenueValue,
			Member:          wbMember{AccountID: "7000000000000000001", Name: "Account Fixture", Submitter: "submitter", Region: "APAC"},
			Reasons:         []string{"CCR >= threshold AND NFS > threshold"},
			AdvertiserTop10: []wbAdvertiserEvidence{{AdvertiserID: "7100000000000000001", ReportedReasons: []reportedReason{{OriginalLabel: "Violence", DisplayNameEN: "Violence", MappingStatus: "draft", RankingUnavailable: "label-level P0 CCR is null or invalid"}}}},
		},
	}
}

func TestPresentationSeparatesReportedReasonsFromTriggerCriteria(t *testing.T) {
	view := cwPresentation(presentationFixture())
	if view.AlertType != "CCR/NFS absolute threshold" || len(view.TriggerCriteria) != 1 || view.TriggerCriteria[0] == view.ReportedReasons[0].Reasons[0].DisplayNameEN {
		t.Fatalf("presentation sources were mixed: %+v", view)
	}
	if got := cwReportedReasonsText(view.ReportedReasons); !strings.Contains(got, "Violence (unranked)") || strings.Contains(got, "threshold") {
		t.Fatalf("reported reasons text reused trigger criteria: %q", got)
	}
}

func TestFeishuCardUsesUnifiedFieldsAndFormats(t *testing.T) {
	raw, err := json.Marshal(cwCard(presentationFixture(), cwConfig{NotificationMode: "test"}))
	if err != nil {
		t.Fatal(err)
	}
	body := string(raw)
	for _, expected := range []string{"Submitter:", "Alert Type:", "Alert Level:", "Status:", "Time Window:", "Region:", "Account ID:", "Account Name:", "Advertiser ID:", "P0 CCR: 2,890.17", "P0 NFS: 1", "Revenue: 12,345.60", "Reported Reasons: 7100000000000000001: Violence (unranked)", "Trigger Criteria: CCR \\u003e= threshold AND NFS \\u003e threshold"} {
		if !strings.Contains(body, expected) {
			t.Fatalf("card missing %q: %s", expected, body)
		}
	}
}

func TestDeadlineBackfillIsPersistentIdempotentAndStableForRendering(t *testing.T) {
	wbTestEnv(t)
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	legacy := presentationFixture()
	legacy.ID = "TAP-legacy-deadline"
	legacy.Version = 7
	legacy.CreatedAt = "2026-10-20T23:30:00Z"
	legacy.Fields = nil
	body, _ := json.Marshal(legacy)
	if _, err = db.Exec("INSERT INTO tap_cases(id,version,body) VALUES(?,?,?)", legacy.ID, legacy.Version, string(body)); err != nil {
		t.Fatal(err)
	}
	if _, err = db.Exec("DELETE FROM tap_schema_migrations WHERE name='backfill_notification_deadline_v1'"); err != nil {
		t.Fatal(err)
	}
	if err = cwBackfillNotificationDeadlines(db); err != nil {
		t.Fatal(err)
	}
	persisted, err := cwRead(db, legacy.ID)
	if err != nil {
		t.Fatal(err)
	}
	if got := cwEventDeadline(persisted); got != "2026-10-27" {
		t.Fatalf("deadline=%q", got)
	}
	if persisted.Version != legacy.Version {
		t.Fatalf("backfill changed workflow version: %d", persisted.Version)
	}
	firstCard, _ := json.Marshal(cwCard(persisted, cwConfig{NotificationMode: "formal"}))

	// Re-running the migration and rendering a resend must read the persisted value,
	// never move the SLA window forward.
	if _, err = db.Exec("DELETE FROM tap_schema_migrations WHERE name='backfill_notification_deadline_v1'"); err != nil {
		t.Fatal(err)
	}
	if err = cwBackfillNotificationDeadlines(db); err != nil {
		t.Fatal(err)
	}
	again, err := cwRead(db, legacy.ID)
	if err != nil {
		t.Fatal(err)
	}
	secondCard, _ := json.Marshal(cwCard(again, cwConfig{NotificationMode: "formal"}))
	if cwEventDeadline(again) != "2026-10-27" || string(firstCard) != string(secondCard) {
		t.Fatalf("deadline or rendered resend changed: deadline=%q", cwEventDeadline(again))
	}
}

func TestDeadlineUsesAlertDateWhenLegacyCreationTimeIsUnavailable(t *testing.T) {
	a := presentationFixture()
	a.CreatedAt = ""
	a.Window = wbRequest{Start: "2026-10-01", End: "2026-10-08"}
	if !cwEnsureNotificationDeadline(&a) || cwEventDeadline(a) != "2026-10-15" {
		t.Fatalf("unexpected alert-date fallback: %q", cwEventDeadline(a))
	}
	if cwEnsureNotificationDeadline(&a) {
		t.Fatal("existing deadline must not be recalculated")
	}
}

func TestAnalyticsHTMLUsesUnifiedStructuredEvidence(t *testing.T) {
	a := presentationFixture()
	x := cwAnalytics{Cases: []cwCase{a}, CasePresentations: map[string]cwCasePresentation{a.ID: cwPresentation(a)}, Summary: map[string]int{}, Notification: map[string]map[string]int{"formal": {}, "test": {}}, Effects: map[string]int{}, EffectStatus: map[string]int{}, QuotaAlerts: cwQuotaAlerts{}}
	html := cwAnalyticsHTML(x)
	for _, expected := range []string{"Structured Alert Evidence", "Submitter", "Alert Type", "Alert Level", "Time Window", "Account ID / Account Name", "Reported Reasons", "Violence (unranked)", "Trigger Criteria", "2,890.17", "12,345.60"} {
		if !strings.Contains(html, expected) {
			t.Fatalf("HTML missing %q", expected)
		}
	}
}
