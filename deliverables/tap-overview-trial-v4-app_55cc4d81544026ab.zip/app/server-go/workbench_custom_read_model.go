package main

import (
	"context"
	"net/http"
	"strconv"
	"strings"
	"time"
)

func wbCustomReadModelHandler(w http.ResponseWriter, r *http.Request, start, end string) {
	config, err := loadWBConfig()
	if err != nil {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": err.Error()})
		return
	}
	programFilter := strings.ToUpper(strings.TrimSpace(r.URL.Query().Get("program")))
	programs := []string{"ET", "ST", "THT"}
	if programFilter != "" && programFilter != "ALL" {
		if programFilter != "ET" && programFilter != "ST" && programFilter != "THT" {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": "program must be ET, ST or THT"})
			return
		}
		programs = []string{programFilter}
	}
	// A custom range may cover thousands of customers. Programs are independent,
	// so run them concurrently and cap the request to avoid an endless UI wait.
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()
	type programResult struct {
		index int
		job   wbJob
		err   error
	}
	resultCh := make(chan programResult, len(programs))
	for index, program := range programs {
		go func(index int, program string) {
			started := time.Now()
			job, queryErr := wbCustomQueryProgram(ctx, r.Clone(ctx), program, start, end, strings.TrimSpace(r.URL.Query().Get("region")), config)
			logMsg("[custom-read] "+program+" completed in "+time.Since(started).Round(time.Millisecond).String(), "plugin")
			resultCh <- programResult{index: index, job: job, err: queryErr}
		}(index, program)
	}
	ordered := make([]programResult, len(programs))
	for range programs {
		result := <-resultCh
		ordered[result.index] = result
	}
	jobs := make([]wbJob, 0, len(programs))
	warnings := []string{}
	for _, result := range ordered {
		program := programs[result.index]
		if result.err != nil {
			warnings = append(warnings, program+": "+result.err.Error())
			logMsg("[custom-read] "+program+" failed: "+sanitizeLogText(result.err.Error()), "plugin")
			continue
		}
		jobs = append(jobs, result.job)
	}
	if len(jobs) == 0 {
		writeJSON(w, http.StatusBadGateway, map[string]any{"error": "custom authoritative query failed", "warnings": warnings, "side_effects": false})
		return
	}

	aliases := []string{}
	if wbBoolQuery(r.URL.Query().Get("only_mine")) {
		db, dbErr := cwDB()
		if dbErr != nil {
			cwWriteError(w, dbErr)
			return
		}
		var reason string
		aliases, reason = wbReadIdentity(db, requestUsername(r))
		db.Close()
		if reason != "" {
			writeJSON(w, http.StatusUnprocessableEntity, map[string]any{"status": "needs_selection", "error": reason})
			return
		}
	}
	q := map[string]string{}
	for _, key := range []string{"program", "tier", "region", "submitter", "account_id", "advertiser_id", "search"} {
		q[key] = strings.TrimSpace(r.URL.Query().Get(key))
	}
	q["only_mine"] = strconv.FormatBool(wbBoolQuery(r.URL.Query().Get("only_mine")))
	all := []wbReadRow{}
	queried := map[string]bool{}
	for _, job := range jobs {
		for _, row := range job.Rows {
			if !wbRowMatches(row, nil, q, aliases, nil) {
				continue
			}
			view := wbToReadRow(job, row, nil, nil, time.Now())
			view.EventStage = "not_applicable_custom_query"
			view.Notification = wbNotificationView{Status: "not_applicable_custom_query", History: []cwNotice{}}
			all = append(all, view)
			queried[wbCustomerKey(row)] = true
		}
	}
	ranking := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("ranking")))
	if ranking == "" {
		ranking = "combined"
	}
	if ranking != "combined" && ranking != "absolute" && ranking != "growth" {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "ranking must be combined, absolute or growth"})
		return
	}
	riskPool := wbRiskList(all, ranking)
	wbSortRows(riskPool, ranking)
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	size, _ := strconv.Atoi(r.URL.Query().Get("page_size"))
	if size < 1 {
		size = 50
	}
	if size > 500 {
		size = 500
	}
	from, to := (page-1)*size, page*size
	if from > len(riskPool) {
		from = len(riskPool)
	}
	if to > len(riskPool) {
		to = len(riskPool)
	}
	cards := map[string]wbCardValue{
		"queried_customers": wbCard(len(queried), "available", "自定义窗口权威来源实际查询客户去重数"),
		"risk_customers":    wbCard(len(riskPool), "available", "自定义窗口命中风险客户去重数"),
		"auto_alerted":      wbNullCard("not_applicable", "不适用于自定义查询；未读取或改变正式通知台账"),
		"pending":           wbNullCard("not_applicable", "不适用于自定义查询；不会创建 casework 事件"),
		"handled":           wbNullCard("not_applicable", "不适用于自定义查询；保留周度正式台账"),
		"closed":            wbNullCard("not_applicable", "不适用于自定义查询；保留周度正式台账"),
	}
	status, reason := "available", "custom_authoritative_read_only"
	if len(warnings) > 0 {
		status, reason = "partial", "custom_authoritative_partial"
	}
	writeJSON(w, http.StatusOK, map[string]any{"data": map[string]any{"status": status, "reason": reason, "warnings": warnings, "time": map[string]any{"mode": "custom", "start_date": start, "end_date": end}, "filters": q, "cards": cards, "rows": riskPool[from:to], "rankings": map[string]any{"selected": ranking, "scope": "custom_full_filtered_set_before_pagination"}, "pagination": map[string]int{"page": page, "page_size": size, "total": len(riskPool)}, "contract_version": wbReadContractVersion, "side_effects": false}})
}
