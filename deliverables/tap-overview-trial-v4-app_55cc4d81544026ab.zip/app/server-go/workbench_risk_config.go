package main

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net/http"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

const wbDefaultPolicyLabel = "TAP-20261021-v2"

type wbRiskCondition struct {
	Metric   string  `json:"metric"`
	Operator string  `json:"operator"`
	Value    float64 `json:"value"`
}

type wbRankingConditions struct {
	TopN         int  `json:"top_n"`
	PositiveOnly bool `json:"positive_only"`
}

// wbLegacyRiskConditions is read-only compatibility for Cloud versions and job.Policy
// persisted before the generic condition schema was introduced.
type wbLegacyRiskConditions struct {
	CCRGTE       *float64 `json:"ccr_gte,omitempty"`
	CCRGT        *float64 `json:"ccr_gt,omitempty"`
	NFSGT        *float64 `json:"nfs_gt,omitempty"`
	NFSGTE       *float64 `json:"nfs_gte,omitempty"`
	GrowthGT     *float64 `json:"growth_gt,omitempty"`
	CurrentCCRGT *float64 `json:"current_ccr_gt,omitempty"`
	TopN         *int     `json:"top_n,omitempty"`
	PositiveOnly bool     `json:"positive_only,omitempty"`
}

type wbRiskScope struct {
	Tiers   []string `json:"tiers,omitempty"`
	Regions []string `json:"regions,omitempty"`
}

type wbRiskRuleConfig struct {
	ID         string               `json:"id"`
	Name       string               `json:"name"`
	Program    string               `json:"program"`
	Kind       string               `json:"kind"`
	MatchMode  string               `json:"match_mode,omitempty"`
	Conditions []wbRiskCondition    `json:"conditions,omitempty"`
	Ranking    *wbRankingConditions `json:"ranking,omitempty"`
	RiskLevel  string               `json:"risk_level"`
	Scope      wbRiskScope          `json:"scope"`
	Enabled    bool                 `json:"enabled"`
}

func (r *wbRiskRuleConfig) UnmarshalJSON(data []byte) error {
	type alias wbRiskRuleConfig
	var raw struct {
		ID         string               `json:"id"`
		Name       string               `json:"name"`
		Program    string               `json:"program"`
		Kind       string               `json:"kind"`
		MatchMode  string               `json:"match_mode"`
		RiskLevel  string               `json:"risk_level"`
		Conditions json.RawMessage      `json:"conditions"`
		Ranking    *wbRankingConditions `json:"ranking"`
		Scope      wbRiskScope          `json:"scope"`
		Enabled    bool                 `json:"enabled"`
	}
	if err := json.Unmarshal(data, &raw); err != nil {
		return err
	}
	r.ID, r.Name, r.Program, r.Kind, r.MatchMode, r.RiskLevel = raw.ID, raw.Name, raw.Program, raw.Kind, raw.MatchMode, raw.RiskLevel
	r.Ranking, r.Scope, r.Enabled = raw.Ranking, raw.Scope, raw.Enabled
	if len(raw.Conditions) > 0 && string(raw.Conditions) != "null" {
		if raw.Conditions[0] == '[' {
			if err := json.Unmarshal(raw.Conditions, &r.Conditions); err != nil {
				return err
			}
		} else {
			var old wbLegacyRiskConditions
			if err := json.Unmarshal(raw.Conditions, &old); err != nil {
				return err
			}
			r.Conditions, r.Ranking = wbLegacyConditions(r.Kind, old)
		}
	}
	wbNormalizeRule(r)
	return nil
}

func wbLegacyConditions(kind string, old wbLegacyRiskConditions) ([]wbRiskCondition, *wbRankingConditions) {
	out := []wbRiskCondition{}
	add := func(metric, op string, v *float64) {
		if v != nil {
			out = append(out, wbRiskCondition{Metric: metric, Operator: op, Value: *v})
		}
	}
	add("p0_ccr", ">=", old.CCRGTE)
	add("p0_ccr", ">", old.CCRGT)
	add("p0_nfs", ">=", old.NFSGTE)
	add("p0_nfs", ">", old.NFSGT)
	add("growth_pct", ">", old.GrowthGT)
	add("current_p0_ccr", ">", old.CurrentCCRGT)
	if strings.EqualFold(kind, "ranking") && old.TopN != nil {
		return nil, &wbRankingConditions{TopN: *old.TopN, PositiveOnly: old.PositiveOnly}
	}
	return out, nil
}

func wbNormalizeRule(r *wbRiskRuleConfig) {
	r.ID = strings.TrimSpace(r.ID)
	r.Name = strings.TrimSpace(r.Name)
	r.Program = strings.ToUpper(strings.TrimSpace(r.Program))
	r.Kind = strings.ToLower(strings.TrimSpace(r.Kind))
	r.MatchMode = strings.ToLower(strings.TrimSpace(r.MatchMode))
	r.RiskLevel = strings.ToLower(strings.TrimSpace(r.RiskLevel))
	if r.MatchMode == "" && r.Kind != "ranking" {
		r.MatchMode = "all"
	}
	if r.Name == "" {
		r.Name = r.ID
	}
	for i := range r.Conditions {
		r.Conditions[i].Metric = strings.ToLower(strings.TrimSpace(r.Conditions[i].Metric))
		r.Conditions[i].Operator = strings.TrimSpace(r.Conditions[i].Operator)
	}
	sort.SliceStable(r.Conditions, func(i, j int) bool {
		if r.Conditions[i].Metric != r.Conditions[j].Metric {
			return r.Conditions[i].Metric < r.Conditions[j].Metric
		}
		if r.Conditions[i].Operator != r.Conditions[j].Operator {
			return r.Conditions[i].Operator < r.Conditions[j].Operator
		}
		return r.Conditions[i].Value < r.Conditions[j].Value
	})
}

func wbNormalizePolicy(p wbResolvedPolicy) wbResolvedPolicy {
	for i := range p.Rules {
		wbNormalizeRule(&p.Rules[i])
	}
	if p.ConfigHash == "" {
		p.ConfigHash = wbPolicyHash(p.Rules)
	}
	return p
}

type wbResolvedPolicy struct {
	Version      int                `json:"version"`
	VersionLabel string             `json:"version_label"`
	ConfigHash   string             `json:"config_hash"`
	Rules        []wbRiskRuleConfig `json:"rules"`
	UpdatedBy    string             `json:"updated_by"`
	UpdatedAt    string             `json:"updated_at"`
	ChangeNote   string             `json:"change_note,omitempty"`
	RequestID    string             `json:"request_id,omitempty"`
}

type wbRejudgeProgramResult struct {
	Program     string `json:"program"`
	Status      string `json:"status"`
	BatchID     string `json:"batch_id,omitempty"`
	JobID       string `json:"job_id,omitempty"`
	Rows        int    `json:"rows"`
	UpdatedRows int    `json:"updated_rows"`
	Reason      string `json:"reason,omitempty"`
}

type wbRejudgeTask struct {
	ID             string                            `json:"id"`
	Fingerprint    string                            `json:"fingerprint"`
	PolicyVersion  int                               `json:"policy_version"`
	VersionLabel   string                            `json:"version_label"`
	ConfigHash     string                            `json:"config_hash"`
	Status         string                            `json:"status"`
	Progress       int                               `json:"progress"`
	ProgramResults map[string]wbRejudgeProgramResult `json:"program_results"`
	FailureReason  string                            `json:"failure_reason,omitempty"`
	CreatedAt      string                            `json:"created_at"`
	StartedAt      string                            `json:"started_at,omitempty"`
	FinishedAt     string                            `json:"finished_at,omitempty"`
	LeaseOwner     string                            `json:"lease_owner,omitempty"`
	LeaseUntil     string                            `json:"lease_until,omitempty"`
	BatchIDs       []string                          `json:"batch_ids"`
}

func wbDefaultPolicy() wbResolvedPolicy {
	rules := []wbRiskRuleConfig{
		{ID: "absolute-watch", Name: "绝对值观察线", Program: "ALL", Kind: "absolute", MatchMode: "all", Conditions: []wbRiskCondition{{Metric: "p0_ccr", Operator: ">=", Value: 3}, {Metric: "p0_nfs", Operator: ">", Value: 50}}, RiskLevel: "watch", Enabled: true},
		{ID: "absolute-extreme", Name: "绝对值极高线", Program: "ALL", Kind: "absolute", MatchMode: "all", Conditions: []wbRiskCondition{{Metric: "p0_ccr", Operator: ">=", Value: 45}, {Metric: "p0_nfs", Operator: ">=", Value: 300}}, RiskLevel: "extreme", Enabled: true},
		{ID: "growth-extreme", Name: "增长极高线", Program: "ALL", Kind: "growth", MatchMode: "all", Conditions: []wbRiskCondition{{Metric: "growth_pct", Operator: ">", Value: 100}, {Metric: "current_p0_ccr", Operator: ">", Value: 6}}, RiskLevel: "extreme", Enabled: true},
		{ID: "growth-ranking", Name: "正增长 Top20", Program: "ALL", Kind: "ranking", Ranking: &wbRankingConditions{TopN: 20, PositiveOnly: true}, RiskLevel: "watch", Enabled: true},
	}
	p := wbResolvedPolicy{Version: 0, VersionLabel: wbDefaultPolicyLabel, Rules: rules, UpdatedBy: "system_seed"}
	p.ConfigHash = wbPolicyHash(rules)
	return p
}

func wbPolicyHash(rules []wbRiskRuleConfig) string {
	copyRules := append([]wbRiskRuleConfig(nil), rules...)
	for i := range copyRules {
		wbNormalizeRule(&copyRules[i])
	}
	sort.Slice(copyRules, func(i, j int) bool { return copyRules[i].ID < copyRules[j].ID })
	b, _ := json.Marshal(copyRules)
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:])
}

func wbValidatePolicyRules(rules []wbRiskRuleConfig) error {
	_, err := wbValidatePolicy(rules)
	return err
}
func wbValidatePolicy(rules []wbRiskRuleConfig) ([]string, error) {
	if len(rules) == 0 || len(rules) > 100 {
		return nil, errors.New("规则数量必须在 1 到 100 之间")
	}
	seen, signatures := map[string]bool{}, map[string]string{}
	hasAbsolute := false
	for i := range rules {
		r := &rules[i]
		wbNormalizeRule(r)
		if r.ID == "" || seen[r.ID] {
			return nil, errors.New("规则 ID 不能为空或重复")
		}
		seen[r.ID] = true
		if r.Program != "ALL" && r.Program != "ET" && r.Program != "ST" && r.Program != "THT" {
			return nil, fmt.Errorf("规则 %s 的 Program 无效", r.ID)
		}
		if r.Kind != "absolute" && r.Kind != "growth" && r.Kind != "ranking" {
			return nil, fmt.Errorf("规则 %s 的类型无效", r.ID)
		}
		if r.RiskLevel != "watch" && r.RiskLevel != "extreme" {
			return nil, fmt.Errorf("规则 %s 的风险等级无效", r.ID)
		}
		if r.Kind == "ranking" {
			if r.Ranking == nil || r.Ranking.TopN < 1 || r.Ranking.TopN > 500 {
				return nil, fmt.Errorf("排名规则 %s 的 top_n 必须在 1 到 500 之间", r.ID)
			}
			if len(r.Conditions) != 0 {
				return nil, fmt.Errorf("排名规则 %s 不接受通用条件", r.ID)
			}
		} else {
			if r.MatchMode != "all" && r.MatchMode != "any" {
				return nil, fmt.Errorf("规则 %s 的 match_mode 必须为 all 或 any", r.ID)
			}
			if len(r.Conditions) == 0 {
				return nil, fmt.Errorf("规则 %s 条件不能为空", r.ID)
			}
			allowed := map[string]bool{"p0_ccr": true, "p0_nfs": true}
			if r.Kind == "growth" {
				allowed = map[string]bool{"growth_pct": true, "current_p0_ccr": true}
			}
			for _, c := range r.Conditions {
				if !allowed[c.Metric] {
					return nil, fmt.Errorf("规则 %s 的指标 %s 不适用于 %s", r.ID, c.Metric, r.Kind)
				}
				if c.Operator != ">" && c.Operator != ">=" && c.Operator != "<" && c.Operator != "<=" {
					return nil, fmt.Errorf("规则 %s 含非法 operator", r.ID)
				}
				if math.IsNaN(c.Value) || math.IsInf(c.Value, 0) || c.Value < 0 || c.Value > 1e9 {
					return nil, fmt.Errorf("规则 %s 含无效阈值", r.ID)
				}
			}
		}
		if r.Enabled && r.Kind == "absolute" {
			hasAbsolute = true
		}
		for _, s := range append(append([]string{}, r.Scope.Tiers...), r.Scope.Regions...) {
			if strings.TrimSpace(s) == "" {
				return nil, fmt.Errorf("规则 %s 的范围含空值", r.ID)
			}
		}
		copyRule := *r
		copyRule.ID, copyRule.Name = "", ""
		b, _ := json.Marshal(copyRule)
		sig := string(b)
		if other, ok := signatures[sig]; ok {
			return nil, fmt.Errorf("规则 %s 与 %s 完全重复", r.ID, other)
		}
		signatures[sig] = r.ID
	}
	if !hasAbsolute {
		return nil, errors.New("至少保留一条启用的 absolute 安全规则")
	}
	warnings := []string{}
	for i := 0; i < len(rules); i++ {
		for j := i + 1; j < len(rules); j++ {
			a, b := rules[i], rules[j]
			if !a.Enabled || !b.Enabled || a.Kind != b.Kind {
				continue
			}
			if (a.Program == "ALL" || b.Program == "ALL" || a.Program == b.Program) && wbScopesOverlap(a.Scope, b.Scope) {
				warnings = append(warnings, fmt.Sprintf("规则 %s 与 %s 的适用范围重叠，请确认优先级与阈值符合预期", a.ID, b.ID))
			}
		}
	}
	return warnings, nil
}
func wbScopesOverlap(a, b wbRiskScope) bool {
	overlap := func(x, y []string) bool {
		if len(x) == 0 || len(y) == 0 {
			return true
		}
		for _, i := range x {
			for _, j := range y {
				if strings.EqualFold(strings.TrimSpace(i), strings.TrimSpace(j)) {
					return true
				}
			}
		}
		return false
	}
	return overlap(a.Tiers, b.Tiers) && overlap(a.Regions, b.Regions)
}

func wbRuleApplies(r wbRiskRuleConfig, program, tier, region string) bool {
	if !r.Enabled || r.Program != "ALL" && !strings.EqualFold(r.Program, program) {
		return false
	}
	contains := func(values []string, value string) bool {
		if len(values) == 0 {
			return true
		}
		for _, item := range values {
			if strings.EqualFold(strings.TrimSpace(item), strings.TrimSpace(value)) {
				return true
			}
		}
		return false
	}
	return contains(r.Scope.Tiers, tier) && contains(r.Scope.Regions, region)
}

func wbRiskRank(level string) int {
	if level == "extreme" || level == "critical" {
		return 2
	}
	if level == "watch" {
		return 1
	}
	return 0
}
func wbHigherRisk(current, next string) string {
	if wbRiskRank(next) > wbRiskRank(current) {
		return next
	}
	return current
}
func wbCompare(value float64, op string, threshold float64) bool {
	switch op {
	case ">":
		return value > threshold
	case ">=":
		return value >= threshold
	case "<":
		return value < threshold
	case "<=":
		return value <= threshold
	}
	return false
}
func wbMetricValue(row wbRow, metric string) (*float64, bool) {
	switch metric {
	case "p0_ccr", "current_p0_ccr":
		return row.CCR, row.CCR != nil
	case "p0_nfs":
		return row.NFS, row.NFS != nil
	case "growth_pct":
		v := wbComparisonGrowth(row.Program, row.Comparison)
		return v, v != nil && wbComparisonGrowthAvailable(row.Program, row.Comparison)
	}
	return nil, false
}
func wbMatchRule(row wbRow, r wbRiskRuleConfig) (bool, bool) {
	available, matched := 0, 0
	for _, c := range r.Conditions {
		v, ok := wbMetricValue(row, c.Metric)
		if !ok || v == nil {
			continue
		}
		available++
		if wbCompare(*v, c.Operator, c.Value) {
			matched++
		}
	}
	if r.MatchMode == "any" {
		if matched > 0 {
			return true, true
		}
		return false, available > 0
	}
	if matched < len(r.Conditions) {
		if available == len(r.Conditions) || available > matched {
			return false, true
		}
		return false, false
	}
	return true, true
}
func wbRuleReason(r wbRiskRuleConfig, row wbRow) string {
	parts := []string{}
	for _, c := range r.Conditions {
		if v, ok := wbMetricValue(row, c.Metric); ok && v != nil {
			parts = append(parts, fmt.Sprintf("%s %s %g（当前 %g）", c.Metric, c.Operator, c.Value, *v))
		}
	}
	return fmt.Sprintf("%s：%s", r.ID, strings.Join(parts, "；"))
}
func wbEvaluateRow(row wbRow, policy wbResolvedPolicy) (string, []string) {
	policy = wbNormalizePolicy(policy)
	level := "normal"
	reasons := []string{}
	applicable, decidable := 0, 0
	for _, r := range policy.Rules {
		if r.Kind == "ranking" || !wbRuleApplies(r, row.Program, row.Member.Tier, row.Member.Region) {
			continue
		}
		applicable++
		match, available := wbMatchRule(row, r)
		if available {
			decidable++
		}
		if match {
			level = wbHigherRisk(level, r.RiskLevel)
			reasons = append(reasons, wbRuleReason(r, row))
		}
	}
	if len(reasons) == 0 && applicable > decidable {
		level = "unavailable"
	}
	if level == "extreme" {
		level = "critical"
	}
	return level, reasons
}
func wbEvaluateAbsolute(ccr, nfs *float64, program, tier, region string, policy wbResolvedPolicy) (string, []string) {
	level, reasons := wbEvaluateRow(wbRow{Program: program, Member: wbMember{Tier: tier, Region: region}, CCR: ccr, NFS: nfs}, wbPolicyOnlyKind(policy, "absolute"))
	if level == "critical" {
		level = "extreme"
	}
	return level, reasons
}

func wbPolicyFromJob(job wbJob) wbResolvedPolicy {
	if len(job.Policy.Rules) > 0 {
		return wbNormalizePolicy(job.Policy)
	}
	return wbDefaultPolicy()
}

// riskPolicyRepository is injectable. Production uses Cloud DB and fails fast;
// tests use the deterministic memory implementation below.
type riskPolicyRepository interface {
	Active(context.Context) (wbResolvedPolicy, error)
	Versions(context.Context) ([]wbResolvedPolicy, error)
	PutCAS(context.Context, int, string, string, []wbRiskRuleConfig, string) (wbResolvedPolicy, bool, bool, error)
	EnsureTask(context.Context, wbRejudgeTask) (wbRejudgeTask, bool, error)
	Tasks(context.Context) ([]wbRejudgeTask, error)
	Claim(context.Context, string, string, time.Time) (wbRejudgeTask, bool, error)
	SaveTask(context.Context, wbRejudgeTask) error
}

var wbRiskRepoProvider = func() (riskPolicyRepository, error) { return newCloudRiskPolicyRepository() }

func wbActivePolicy(ctx context.Context) (wbResolvedPolicy, error) {
	repo, err := wbRiskRepoProvider()
	if err != nil {
		return wbResolvedPolicy{}, err
	}
	p, err := repo.Active(ctx)
	if errors.Is(err, sql.ErrNoRows) {
		return wbDefaultPolicy(), nil
	}
	return p, err
}

type cloudRiskPolicyRepository struct{ db *cloudStore }

func newCloudRiskPolicyRepository() (*cloudRiskPolicyRepository, error) {
	if configuredMode != "cloud" {
		return nil, errors.New("risk policy requires cloud store mode")
	}
	db, err := newCloudStore()
	if err != nil {
		return nil, err
	}
	return &cloudRiskPolicyRepository{db: db}, nil
}
func cloudRecords(resp map[string]any) []map[string]any {
	data, _ := resp["data"].(map[string]any)
	raw, _ := data["records"].([]any)
	out := []map[string]any{}
	for _, v := range raw {
		if m, ok := toMap(v); ok {
			out = append(out, m)
		}
	}
	return out
}
func decodePolicy(row map[string]any) (wbResolvedPolicy, error) {
	var p wbResolvedPolicy
	b, e := json.Marshal(row["body"])
	if e == nil {
		e = json.Unmarshal(b, &p)
	}
	return wbNormalizePolicy(p), e
}
func decodeTask(row map[string]any) (wbRejudgeTask, error) {
	var t wbRejudgeTask
	b, e := json.Marshal(row["body"])
	if e == nil {
		e = json.Unmarshal(b, &t)
	}
	return t, e
}
func (r *cloudRiskPolicyRepository) Active(ctx context.Context) (wbResolvedPolicy, error) {
	resp, e := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_risk_policy_versions/query", map[string]any{"sort": []any{map[string]any{"field": "version", "direction": "desc"}}, "limit": 1})
	if e != nil {
		return wbResolvedPolicy{}, e
	}
	rows := cloudRecords(resp)
	if len(rows) == 0 {
		return wbResolvedPolicy{}, sql.ErrNoRows
	}
	return decodePolicy(rows[0])
}
func (r *cloudRiskPolicyRepository) Versions(ctx context.Context) ([]wbResolvedPolicy, error) {
	resp, e := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_risk_policy_versions/query", map[string]any{"sort": []any{map[string]any{"field": "version", "direction": "desc"}}, "limit": 100})
	if e != nil {
		return nil, e
	}
	out := []wbResolvedPolicy{}
	for _, row := range cloudRecords(resp) {
		p, err := decodePolicy(row)
		if err != nil {
			return nil, err
		}
		out = append(out, p)
	}
	return out, nil
}
func (r *cloudRiskPolicyRepository) PutCAS(ctx context.Context, expected int, requestID, actor string, rules []wbRiskRuleConfig, note string) (wbResolvedPolicy, bool, bool, error) {
	resp, e := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_risk_policy_versions/query", map[string]any{"filters": []any{map[string]any{"field": "request_id", "operator": "eq", "value": requestID}}, "limit": 1})
	if e != nil {
		return wbResolvedPolicy{}, false, false, e
	}
	if rows := cloudRecords(resp); len(rows) > 0 {
		p, er := decodePolicy(rows[0])
		return p, true, false, er
	}
	active, e := r.Active(ctx)
	if errors.Is(e, sql.ErrNoRows) {
		active = wbDefaultPolicy()
		e = nil
	}
	if e != nil {
		return wbResolvedPolicy{}, false, false, e
	}
	if active.Version != expected {
		return wbResolvedPolicy{}, false, false, cwErr(409, "配置版本已更新，请刷新后重试")
	}
	hash := wbPolicyHash(rules)
	if hash == active.ConfigHash {
		return active, false, true, nil
	}
	now := time.Now().UTC().Format(time.RFC3339)
	p := wbResolvedPolicy{Version: expected + 1, VersionLabel: fmt.Sprintf("TAP-RISK-%d", expected+1), ConfigHash: hash, Rules: rules, UpdatedBy: actor, UpdatedAt: now, ChangeNote: note, RequestID: requestID}
	_, e = r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_risk_policy_versions/records", map[string]any{"version": p.Version, "version_label": p.VersionLabel, "config_hash": hash, "request_id": requestID, "updated_by": actor, "updated_at": now, "body": p})
	if e != nil && strings.Contains(e.Error(), "409") {
		resp, queryErr := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_risk_policy_versions/query", map[string]any{"filters": []any{map[string]any{"field": "request_id", "operator": "eq", "value": requestID}}, "limit": 1})
		if queryErr == nil {
			if rows := cloudRecords(resp); len(rows) > 0 {
				stored, decodeErr := decodePolicy(rows[0])
				return stored, true, false, decodeErr
			}
		}
		return wbResolvedPolicy{}, false, false, cwErr(409, "配置版本已更新，请刷新后重试")
	}
	return p, false, false, e
}
func (r *cloudRiskPolicyRepository) EnsureTask(ctx context.Context, t wbRejudgeTask) (wbRejudgeTask, bool, error) {
	_, e := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_risk_rejudge_tasks/records/upsert", map[string]any{"conflict_fields": []string{"fingerprint"}, "data": map[string]any{"task_id": t.ID, "fingerprint": t.Fingerprint, "policy_version": t.PolicyVersion, "status": t.Status, "created_at": t.CreatedAt, "lease_until": "1970-01-01T00:00:00Z", "body": t}, "update_fields": []string{}})
	if e != nil && !strings.Contains(e.Error(), "409") {
		return t, false, e
	}
	tasks, er := r.Tasks(ctx)
	if er != nil {
		return t, false, er
	}
	for _, x := range tasks {
		if x.Fingerprint == t.Fingerprint {
			return x, x.ID == t.ID, nil
		}
	}
	return t, true, nil
}
func (r *cloudRiskPolicyRepository) Tasks(ctx context.Context) ([]wbRejudgeTask, error) {
	resp, e := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_risk_rejudge_tasks/query", map[string]any{"sort": []any{map[string]any{"field": "created_at", "direction": "desc"}}, "limit": 100})
	if e != nil {
		return nil, e
	}
	out := []wbRejudgeTask{}
	for _, row := range cloudRecords(resp) {
		t, er := decodeTask(row)
		if er != nil {
			return nil, er
		}
		out = append(out, t)
	}
	return out, nil
}
func (r *cloudRiskPolicyRepository) Claim(ctx context.Context, id, owner string, now time.Time) (wbRejudgeTask, bool, error) {
	tasks, e := r.Tasks(ctx)
	if e != nil {
		return wbRejudgeTask{}, false, e
	}
	var t wbRejudgeTask
	found := false
	for _, x := range tasks {
		if x.ID == id {
			t = x
			found = true
			break
		}
	}
	if !found {
		return t, false, sql.ErrNoRows
	}
	expiry, _ := time.Parse(time.RFC3339, t.LeaseUntil)
	if t.Status != "pending" && (t.Status != "running" || expiry.After(now)) {
		return t, false, nil
	}
	conditions := []any{map[string]any{"field": "task_id", "operator": "eq", "value": id}, map[string]any{"field": "status", "operator": "eq", "value": t.Status}}
	if t.Status == "running" {
		conditions = append(conditions, map[string]any{"field": "lease_owner", "operator": "eq", "value": t.LeaseOwner}, map[string]any{"field": "lease_until", "operator": "eq", "value": t.LeaseUntil})
	}
	previousStatus := t.Status
	t.Status = "running"
	t.LeaseOwner = owner
	t.LeaseUntil = now.Add(2 * time.Minute).UTC().Format(time.RFC3339)
	if t.StartedAt == "" {
		t.StartedAt = now.UTC().Format(time.RFC3339)
	}
	body := map[string]any{"filter": map[string]any{"logic": "and", "conditions": conditions}, "data": map[string]any{"status": "running", "lease_owner": owner, "lease_until": t.LeaseUntil, "body": t}, "limit": 1}
	resp, e := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_risk_rejudge_tasks/records/update", body)
	if e != nil {
		return t, false, e
	}
	data, _ := resp["data"].(map[string]any)
	claimed := asInt64(data["updated_count"]) == 1
	if !claimed {
		t.Status = previousStatus
	}
	return t, claimed, nil
}
func (r *cloudRiskPolicyRepository) SaveTask(ctx context.Context, t wbRejudgeTask) error {
	resp, e := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_risk_rejudge_tasks/records/update", map[string]any{"filter": map[string]any{"logic": "and", "conditions": []any{map[string]any{"field": "task_id", "operator": "eq", "value": t.ID}, map[string]any{"field": "lease_owner", "operator": "eq", "value": t.LeaseOwner}}}, "data": map[string]any{"status": t.Status, "lease_until": t.LeaseUntil, "body": t}, "limit": 1})
	if e != nil {
		return e
	}
	data, _ := resp["data"].(map[string]any)
	if asInt64(data["updated_count"]) != 1 {
		return errors.New("rejudge task lease lost")
	}
	return nil
}

func wbTaskFingerprint(policy wbResolvedPolicy, batchIDs []string) string {
	sort.Strings(batchIDs)
	return wbKey(struct {
		V int
		H string
		B []string
	}{policy.Version, policy.ConfigHash, batchIDs})
}
func wbCurrentBatchIDs() []string {
	batches, _, err := wbPersistedBatches()
	if err != nil || len(batches) == 0 {
		return nil
	}
	return []string{batches[0].BatchID}
}
func wbNewRejudgeTask(p wbResolvedPolicy) wbRejudgeTask {
	ids := wbCurrentBatchIDs()
	now := time.Now().UTC().Format(time.RFC3339)
	return wbRejudgeTask{ID: uuid.NewString(), Fingerprint: wbTaskFingerprint(p, append([]string(nil), ids...)), PolicyVersion: p.Version, VersionLabel: p.VersionLabel, ConfigHash: p.ConfigHash, Status: "pending", ProgramResults: map[string]wbRejudgeProgramResult{}, CreatedAt: now, BatchIDs: ids}
}

func wbRunRejudgeTask(taskID string) {
	repo, err := wbRiskRepoProvider()
	if err != nil {
		logMsg("[risk-rejudge] repository: "+err.Error(), "plugin")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	owner := appInstanceID + ":" + uuid.NewString()
	task, claimed, err := repo.Claim(ctx, taskID, owner, time.Now())
	if err != nil || !claimed {
		return
	}
	versions, err := repo.Versions(ctx)
	if err != nil {
		task.Status = "failed"
		task.FailureReason = err.Error()
		task.FinishedAt = time.Now().UTC().Format(time.RFC3339)
		_ = repo.SaveTask(ctx, task)
		return
	}
	policy := wbDefaultPolicy()
	for _, p := range versions {
		if p.Version == task.PolicyVersion {
			policy = p
			break
		}
	}
	programs := []string{"ET", "ST", "THT"}
	partial := false
	for i, program := range programs {
		result := wbRejudgeProgram(program, policy, task.BatchIDs)
		task.ProgramResults[program] = result
		if result.Status != "success" {
			partial = true
		}
		task.Progress = (i + 1) * 100 / len(programs)
		task.LeaseUntil = time.Now().Add(2 * time.Minute).UTC().Format(time.RFC3339)
		if e := repo.SaveTask(ctx, task); e != nil {
			return
		}
	}
	if partial {
		task.Status = "partial"
	} else {
		task.Status = "success"
	}
	task.Progress = 100
	task.FinishedAt = time.Now().UTC().Format(time.RFC3339)
	task.LeaseUntil = task.FinishedAt
	_ = repo.SaveTask(ctx, task)
}

func wbRejudgeProgram(program string, policy wbResolvedPolicy, batchIDs []string) wbRejudgeProgramResult {
	result := wbRejudgeProgramResult{Program: program, Status: "failed"}
	if len(batchIDs) == 0 {
		result.Reason = "当前周没有已持久化批次；未触发全量查询"
		return result
	}
	wbMu.Lock()
	defer wbMu.Unlock()
	disk, err := wbReadDisk()
	if err != nil {
		result.Reason = "读取持久化周度任务失败：" + err.Error()
		return result
	}
	var selected *wbJob
	for id, j := range disk.Jobs {
		if !strings.EqualFold(j.Request.Program, program) || j.BatchID != batchIDs[0] {
			continue
		}
		copy := j
		if selected == nil || copy.StartedAt > selected.StartedAt {
			selected = &copy
			_ = id
		}
	}
	if selected == nil {
		result.Reason = "当前周缺少 " + program + " 持久化任务；未触发 Aeolus 补查"
		return result
	}
	result.BatchID = selected.BatchID
	result.JobID = selected.ID
	result.Rows = len(selected.Rows)
	if len(selected.Rows) == 0 {
		result.Reason = "当前周任务没有已持久化指标行；未触发 Aeolus 补查"
		return result
	}
	missing := 0
	for _, row := range selected.Rows {
		if row.CCR == nil || row.NFS == nil {
			missing++
		}
	}
	selected.Rows = wbApplyGovernanceRowsPolicy(selected.Rows, policy)
	selected.RuleVersion = policy.VersionLabel
	selected.Rule.RiskPolicy = policy.VersionLabel
	selected.Rule.Version = policy.VersionLabel
	selected.Policy = policy
	selected.AsOf = time.Now().UTC().Format(time.RFC3339)
	selected.Matched = 0
	for _, row := range selected.Rows {
		if wbMatched(row) {
			selected.Matched++
		}
	}
	disk.Jobs[selected.ID] = *selected
	if err = wbWriteDisk(disk); err != nil {
		result.Reason = "原子保存重判结果失败：" + err.Error()
		return result
	}
	result.UpdatedRows = len(selected.Rows) - missing
	if missing > 0 {
		result.Status = "partial"
		result.Reason = fmt.Sprintf("%d 行缺少 CCR/NFS，已仅重判其余持久化指标；未触发 Aeolus 补查", missing)
	} else {
		result.Status = "success"
	}
	return result
}

type wbPolicyImpact struct {
	BeforeMatched int      `json:"before_matched"`
	AfterMatched  int      `json:"after_matched"`
	Added         int      `json:"added"`
	Removed       int      `json:"removed"`
	Upgraded      int      `json:"upgraded"`
	Downgraded    int      `json:"downgraded"`
	Unavailable   int      `json:"unavailable"`
	Insufficient  int      `json:"insufficient"`
	SampleIDs     []string `json:"sample_ids"`
}

type wbPolicyPreview struct {
	ExpectedVersion int                       `json:"expected_version"`
	DraftHash       string                    `json:"draft_hash"`
	PreviewToken    string                    `json:"preview_token"`
	Warnings        []string                  `json:"warnings"`
	Programs        map[string]wbPolicyImpact `json:"programs"`
	Total           wbPolicyImpact            `json:"total"`
	SourceBatchIDs  []string                  `json:"source_batch_ids"`
	DataFreshness   map[string]string         `json:"data_freshness"`
	Partial         bool                      `json:"partial"`
	FailureReasons  []string                  `json:"failure_reasons"`
	SideEffects     map[string]bool           `json:"side_effects"`
}

func wbPreviewToken(version int, hash string) string {
	h := sha256.Sum256([]byte(fmt.Sprintf("risk-preview:%d:%s", version, hash)))
	return hex.EncodeToString(h[:])
}
func wbValidSampleID(id string) bool {
	if len(id) != 19 {
		return false
	}
	for _, r := range id {
		if r < '0' || r > '9' {
			return false
		}
	}
	return true
}
func wbAddSample(stat *wbPolicyImpact, row wbRow) {
	if len(stat.SampleIDs) >= 10 {
		return
	}
	id := row.Member.AccountID
	if row.Program == "THT" && row.Member.AdvertiserID != "" {
		id = row.Member.AdvertiserID
	}
	if wbValidSampleID(id) {
		stat.SampleIDs = append(stat.SampleIDs, id)
	}
}
func wbAccumulateImpact(stat *wbPolicyImpact, before, after wbRow) {
	bm, am := wbMatched(before), wbMatched(after)
	if bm {
		stat.BeforeMatched++
	}
	if am {
		stat.AfterMatched++
	}
	changed := false
	if !bm && am {
		stat.Added++
		changed = true
	}
	if bm && !am {
		stat.Removed++
		changed = true
	}
	if bm && am && wbRiskRank(after.Level) > wbRiskRank(before.Level) {
		stat.Upgraded++
		changed = true
	}
	if bm && am && wbRiskRank(after.Level) < wbRiskRank(before.Level) {
		stat.Downgraded++
		changed = true
	}
	if after.Level == "unavailable" {
		stat.Unavailable++
	}
	if changed {
		wbAddSample(stat, after)
	}
}
func wbMergeImpact(dst *wbPolicyImpact, src wbPolicyImpact) {
	dst.BeforeMatched += src.BeforeMatched
	dst.AfterMatched += src.AfterMatched
	dst.Added += src.Added
	dst.Removed += src.Removed
	dst.Upgraded += src.Upgraded
	dst.Downgraded += src.Downgraded
	dst.Unavailable += src.Unavailable
	dst.Insufficient += src.Insufficient
	for _, id := range src.SampleIDs {
		if len(dst.SampleIDs) < 10 {
			dst.SampleIDs = append(dst.SampleIDs, id)
		}
	}
}

func wbBuildPolicyPreview(expected int, rules []wbRiskRuleConfig) (wbPolicyPreview, error) {
	warnings, err := wbValidatePolicy(rules)
	if err != nil {
		return wbPolicyPreview{}, err
	}
	for i := range rules {
		wbNormalizeRule(&rules[i])
	}
	hash := wbPolicyHash(rules)
	out := wbPolicyPreview{ExpectedVersion: expected, DraftHash: hash, PreviewToken: wbPreviewToken(expected, hash), Warnings: warnings, Programs: map[string]wbPolicyImpact{}, DataFreshness: map[string]string{}, SideEffects: map[string]bool{"jobs": false, "cases": false, "outbox": false, "aeolus": false}}
	wbMu.Lock()
	disk, err := wbReadDisk()
	wbMu.Unlock()
	if err != nil {
		return out, fmt.Errorf("读取当前周持久化任务失败: %w", err)
	}
	batches, _, err := wbPersistedBatches()
	if err != nil {
		return out, fmt.Errorf("读取当前周批次失败: %w", err)
	}
	currentBatch := ""
	if len(batches) > 0 {
		currentBatch = batches[0].BatchID
	}
	draft := wbResolvedPolicy{Version: expected, Rules: rules, ConfigHash: hash}
	batchSet := map[string]bool{}
	for _, program := range []string{"ET", "ST", "THT"} {
		stat := wbPolicyImpact{}
		var selected *wbJob
		for _, job := range disk.Jobs {
			if !strings.EqualFold(job.Request.Program, program) || (currentBatch != "" && job.BatchID != currentBatch) {
				continue
			}
			copyJob := job
			if selected == nil || copyJob.StartedAt > selected.StartedAt {
				selected = &copyJob
			}
		}
		if selected == nil || len(selected.Rows) == 0 {
			stat.Insufficient++
			out.Partial = true
			reason := "当前周缺少 " + program + " 持久化任务"
			if selected != nil {
				reason = "当前周 " + program + " 持久化任务没有指标行"
			}
			out.FailureReasons = append(out.FailureReasons, reason)
			out.Programs[program] = stat
			wbMergeImpact(&out.Total, stat)
			continue
		}
		batchSet[selected.BatchID] = true
		out.DataFreshness[program] = selected.AsOf
		before := wbApplyGovernanceRowsPolicy(selected.Rows, wbPolicyFromJob(*selected))
		after := wbApplyGovernanceRowsPolicy(selected.Rows, draft)
		for i := range after {
			wbAccumulateImpact(&stat, before[i], after[i])
		}
		out.Programs[program] = stat
		wbMergeImpact(&out.Total, stat)
	}
	for id := range batchSet {
		out.SourceBatchIDs = append(out.SourceBatchIDs, id)
	}
	sort.Strings(out.SourceBatchIDs)
	return out, nil
}

func wbRiskPolicyPreviewHandler(w http.ResponseWriter, r *http.Request) {
	cfg, err := cwLoadConfig()
	if err != nil || !cwOperator(cfg, requestUsername(r)) {
		cwWriteError(w, cwErr(403, "仅运营可预览阈值配置"))
		return
	}
	var in struct {
		ExpectedVersion int                `json:"expected_version"`
		Rules           []wbRiskRuleConfig `json:"rules"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&in) != nil {
		cwWriteError(w, cwErr(400, "无效预览请求"))
		return
	}
	repo, err := wbRiskRepoProvider()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	active, err := repo.Active(r.Context())
	if errors.Is(err, sql.ErrNoRows) {
		active = wbDefaultPolicy()
		err = nil
	}
	if err != nil {
		cwWriteError(w, err)
		return
	}
	if active.Version != in.ExpectedVersion {
		cwWriteError(w, cwErr(409, "配置版本已更新，请刷新后重新预览"))
		return
	}
	preview, err := wbBuildPolicyPreview(in.ExpectedVersion, in.Rules)
	if err != nil {
		cwWriteError(w, cwErr(400, err.Error()))
		return
	}
	writeJSON(w, 200, map[string]any{"data": preview})
}

func wbRiskPolicyListHandler(w http.ResponseWriter, r *http.Request) {
	repo, err := wbRiskRepoProvider()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	p, err := repo.Active(r.Context())
	if errors.Is(err, sql.ErrNoRows) {
		p = wbDefaultPolicy()
		err = nil
	}
	if err != nil {
		cwWriteError(w, err)
		return
	}
	tasks, err := repo.Tasks(r.Context())
	if err != nil {
		cwWriteError(w, err)
		return
	}
	cfg, err := cwLoadConfig()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	var latest any
	if len(tasks) > 0 {
		latest = tasks[0]
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"version": p.Version, "version_label": p.VersionLabel, "config_hash": p.ConfigHash, "rules": p.Rules, "updated_by": p.UpdatedBy, "updated_at": p.UpdatedAt, "is_operator": cwOperator(cfg, requestUsername(r)), "latest_rejudgement": latest}})
}
func wbRiskPolicyVersionsHandler(w http.ResponseWriter, r *http.Request) {
	repo, err := wbRiskRepoProvider()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	v, err := repo.Versions(r.Context())
	if err != nil {
		cwWriteError(w, err)
		return
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"versions": v}})
}
func wbRiskPolicyTasksHandler(w http.ResponseWriter, r *http.Request) {
	repo, err := wbRiskRepoProvider()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	v, err := repo.Tasks(r.Context())
	if err != nil {
		cwWriteError(w, err)
		return
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"tasks": v}})
}
func wbRiskPolicyUpdateHandler(w http.ResponseWriter, r *http.Request) {
	cfg, err := cwLoadConfig()
	if err != nil || !cwOperator(cfg, requestUsername(r)) {
		cwWriteError(w, cwErr(403, "仅运营可修改阈值配置"))
		return
	}
	var in struct {
		ExpectedVersion  int                `json:"expected_version"`
		PreviewToken     string             `json:"preview_token"`
		RequestID        string             `json:"request_id"`
		ConfirmationNote string             `json:"confirmation_note"`
		Rules            []wbRiskRuleConfig `json:"rules"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&in) != nil {
		cwWriteError(w, cwErr(400, "无效配置请求"))
		return
	}
	in.PreviewToken = strings.TrimSpace(in.PreviewToken)
	in.RequestID = strings.TrimSpace(in.RequestID)
	in.ConfirmationNote = strings.TrimSpace(in.ConfirmationNote)
	if in.PreviewToken == "" || in.RequestID == "" || len(in.RequestID) > 200 || in.ConfirmationNote == "" || len(in.ConfirmationNote) > 1000 {
		cwWriteError(w, cwErr(400, "preview_token、request_id 与确认说明必填"))
		return
	}
	warnings, validationErr := wbValidatePolicy(in.Rules)
	if validationErr != nil {
		cwWriteError(w, cwErr(400, validationErr.Error()))
		return
	}
	for i := range in.Rules {
		wbNormalizeRule(&in.Rules[i])
	}
	if in.PreviewToken != wbPreviewToken(in.ExpectedVersion, wbPolicyHash(in.Rules)) {
		cwWriteError(w, cwErr(409, "草稿已变化或预览已失效，请重新预览"))
		return
	}
	repo, err := wbRiskRepoProvider()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	p, idem, unchanged, err := repo.PutCAS(r.Context(), in.ExpectedVersion, in.RequestID, requestUsername(r), in.Rules, in.ConfirmationNote)
	if err != nil {
		cwWriteError(w, err)
		return
	}
	var task wbRejudgeTask
	if !unchanged {
		task, created, taskErr := repo.EnsureTask(r.Context(), wbNewRejudgeTask(p))
		if taskErr != nil {
			cwWriteError(w, taskErr)
			return
		}
		if created {
			go wbRunRejudgeTask(task.ID)
		}
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"version": p.Version, "version_label": p.VersionLabel, "config_hash": p.ConfigHash, "rules": p.Rules, "warnings": warnings, "rejudgement": task, "idempotent": idem, "unchanged": unchanged}})
}

func wbResumeRiskPolicyTasks() error {
	repo, err := wbRiskRepoProvider()
	if err != nil {
		return err
	}
	if _, err = repo.Active(context.Background()); err != nil && !errors.Is(err, sql.ErrNoRows) {
		return err
	}
	tasks, err := repo.Tasks(context.Background())
	if err != nil {
		return err
	}
	for _, t := range tasks {
		if t.Status == "pending" || t.Status == "running" {
			go wbRunRejudgeTask(t.ID)
		}
	}
	return nil
}

// memoryRiskPolicyRepository provides deterministic CAS/idempotency/lease tests.
type memoryRiskPolicyRepository struct {
	mu       sync.Mutex
	versions []wbResolvedPolicy
	tasks    map[string]wbRejudgeTask
}

func newMemoryRiskPolicyRepository() *memoryRiskPolicyRepository {
	return &memoryRiskPolicyRepository{tasks: map[string]wbRejudgeTask{}}
}
func (m *memoryRiskPolicyRepository) Active(context.Context) (wbResolvedPolicy, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.versions) == 0 {
		return wbResolvedPolicy{}, sql.ErrNoRows
	}
	return m.versions[len(m.versions)-1], nil
}
func (m *memoryRiskPolicyRepository) Versions(context.Context) ([]wbResolvedPolicy, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := append([]wbResolvedPolicy(nil), m.versions...)
	sort.Slice(out, func(i, j int) bool { return out[i].Version > out[j].Version })
	return out, nil
}
func (m *memoryRiskPolicyRepository) PutCAS(_ context.Context, expected int, requestID, actor string, rules []wbRiskRuleConfig, note string) (wbResolvedPolicy, bool, bool, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, p := range m.versions {
		if p.RequestID == requestID {
			return p, true, false, nil
		}
	}
	active := wbDefaultPolicy()
	if len(m.versions) > 0 {
		active = m.versions[len(m.versions)-1]
	}
	if active.Version != expected {
		return wbResolvedPolicy{}, false, false, cwErr(409, "配置版本已更新，请刷新后重试")
	}
	hash := wbPolicyHash(rules)
	if hash == active.ConfigHash {
		return active, false, true, nil
	}
	p := wbResolvedPolicy{Version: expected + 1, VersionLabel: fmt.Sprintf("TAP-RISK-%d", expected+1), ConfigHash: hash, Rules: rules, UpdatedBy: actor, UpdatedAt: time.Now().UTC().Format(time.RFC3339), ChangeNote: note, RequestID: requestID}
	m.versions = append(m.versions, p)
	return p, false, false, nil
}
func (m *memoryRiskPolicyRepository) EnsureTask(_ context.Context, t wbRejudgeTask) (wbRejudgeTask, bool, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, x := range m.tasks {
		if x.Fingerprint == t.Fingerprint {
			return x, false, nil
		}
	}
	m.tasks[t.ID] = t
	return t, true, nil
}
func (m *memoryRiskPolicyRepository) Tasks(context.Context) ([]wbRejudgeTask, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := []wbRejudgeTask{}
	for _, t := range m.tasks {
		out = append(out, t)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].CreatedAt > out[j].CreatedAt })
	return out, nil
}
func (m *memoryRiskPolicyRepository) Claim(_ context.Context, id, owner string, now time.Time) (wbRejudgeTask, bool, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	t, ok := m.tasks[id]
	if !ok {
		return t, false, sql.ErrNoRows
	}
	expiry, _ := time.Parse(time.RFC3339, t.LeaseUntil)
	if t.Status != "pending" && (t.Status != "running" || expiry.After(now)) {
		return t, false, nil
	}
	t.Status = "running"
	t.LeaseOwner = owner
	t.LeaseUntil = now.Add(time.Minute).Format(time.RFC3339)
	t.StartedAt = now.Format(time.RFC3339)
	m.tasks[id] = t
	return t, true, nil
}
func (m *memoryRiskPolicyRepository) SaveTask(_ context.Context, t wbRejudgeTask) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	current, ok := m.tasks[t.ID]
	if !ok {
		return sql.ErrNoRows
	}
	if current.LeaseOwner != "" && current.LeaseOwner != t.LeaseOwner {
		return errors.New("lease lost")
	}
	m.tasks[t.ID] = t
	return nil
}
