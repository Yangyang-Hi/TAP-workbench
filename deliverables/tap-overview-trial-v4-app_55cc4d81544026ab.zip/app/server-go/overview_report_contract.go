package main

import (
	"fmt"
	"strings"
)

// Aggregate rows must not pass through normalizeDetailRow: that detail-only
// function removes account_count and normalizes source Tier labels.
func overviewCanonicalAccounts(rows []map[string]any, fieldMap map[string]string) ([]map[string]any, error) {
	out := make([]map[string]any, 0, len(rows))
	fields := overviewAccountSourceConfig().Fields
	for _, raw := range rows {
		mapped := map[string]any{}
		for _, semantic := range []string{"client_tier", "account_count"} {
			spec := fields[semantic]
			matches := 0
			for column, value := range raw {
				descriptor := strings.ToLower(column + " " + fieldMap[column])
				for _, alias := range []string{semantic, spec.SourceName, spec.DimMetID} {
					if alias != "" && strings.Contains(descriptor, strings.ToLower(alias)) {
						mapped[semantic] = value
						matches++
						break
					}
				}
			}
			if matches != 1 {
				return nil, fmt.Errorf("overview column contract: %s matched %d columns; verify Saved Report schema", semantic, matches)
			}
		}
		out = append(out, mapped)
	}
	return out, nil
}

func overviewAccountSourceConfig() sourceConfig {
	return sourceConfig{Kind: "aggregate", Grain: "tier_snapshot", Enabled: true, AppID: 800414, SID: 1280034, RID: 2891943,
		Identity:            sourceIdentity{AppID: 800414, SID: 1280034, RID: 2891943, Region: "sg", QueryMode: "aggregate"},
		SupportedDimensions: []string{"date", "region", "client_tier"},
		Fields: map[string]fieldConfig{
			"p_date":        {DimMetID: "10000002555291", UniqueID: "10000002555291", SourceName: "p_date", ExpectedType: "date"},
			"region":        {DimMetID: "10000016013590", UniqueID: "10000016013590", SourceName: "Sales region-8.6"},
			"client_tier":   {DimMetID: "10000012645665", UniqueID: "10000012645665", SourceName: "tier_v3_name"},
			"account_count": {SourceName: "TAP Accounts", ExpectedType: "number"},
		}}
}

func overviewAccountBase(raw map[string]any, f filterRequest) map[string]any {
	base := cloneMap(raw)
	query, _ := base["query"].(map[string]any)
	where, _ := query["whereList"].([]any)
	kept := []any{}
	for _, item := range where {
		node, _ := item.(map[string]any)
		if f.Region == "" && firstNonEmpty(node, "id", "datasetFieldId", "fieldId", "originId") == "10000016013590" {
			continue
		}
		kept = append(kept, item)
	}
	query["whereList"] = kept
	return base
}

// The IDs below come from the supplied iDA migration document. Verify them
// against the actual executable Saved Report before executing a query.
func overviewAccountChart(raw, chart map[string]any, source sourceConfig, f filterRequest) (map[string]any, error) {
	ids := map[string]bool{}
	var walk func(any)
	walk = func(v any) {
		switch n := v.(type) {
		case map[string]any:
			for _, key := range []string{"id", "originId", "datasetFieldId", "dimMetId"} {
				ids[contractIDString(n[key])] = true
			}
			for _, child := range n {
				walk(child)
			}
		case []any:
			for _, child := range n {
				walk(child)
			}
		}
	}
	walk(raw)
	for _, semantic := range []string{"p_date", "client_tier", "region"} {
		if semantic == "region" && f.Region == "" {
			continue
		}
		if !ids[source.Fields[semantic].DimMetID] {
			return nil, fmt.Errorf("overview Saved Report lacks documented %s field; actual metadata must be verified", semantic)
		}
	}
	filters, _ := chart["filters"].([]any)
	kept := []any{}
	for _, item := range filters {
		m, _ := item.(map[string]any)
		id := asString(m["datasetFieldId"])
		if id != source.Fields["region"].DimMetID && id != source.Fields["client_tier"].DimMetID {
			kept = append(kept, item)
		}
	}
	tier := source.Fields["client_tier"]
	kept = append(kept, aeolusFilter(tier.DimMetID, tier.UniqueID, "IN", overviewTierKeys))
	if f.Region != "" {
		region := source.Fields["region"]
		kept = append(kept, aeolusFilter(region.DimMetID, region.UniqueID, "IN", []string{f.Region}))
	}
	// Global removes only a saved Region UI filter. All other fixed source
	// predicates remain on the executable request through savedReportVQSRequest.
	chart = cloneMap(chart)
	chart["filters"] = kept
	return chart, nil
}
