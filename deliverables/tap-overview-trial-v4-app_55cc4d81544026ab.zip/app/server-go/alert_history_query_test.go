package main

import (
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestAlertHistoryCustomQuery(t *testing.T) {
	wbTestEnv(t)
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())

	// Fixtures
	// Event 1: 2026-10-15 (Shanghai)
	c1 := cwCase{
		ID: "ALERT-1", Version: 1, Status: "open", CreatedAt: "2026-10-14T20:00:00Z", // 2026-10-15 04:00 Shanghai
		Row: wbRow{Program: "ET", Level: "critical", Member: wbMember{AccountID: "ACC1", Region: "APAC"}},
	}
	// Event 2: 2026-10-20 (Shanghai)
	c2 := cwCase{
		ID: "ALERT-2", Version: 1, Status: "processing", CreatedAt: "2026-10-19T20:00:00Z", // 2026-10-20 04:00 Shanghai
		Row: wbRow{Program: "THT", Level: "watch", Member: wbMember{AdvertiserID: "ADV1", Region: "EMEA"}},
	}
	// Event 3: 2026-10-21 (Shanghai)
	c3 := cwCase{
		ID: "ALERT-3", Version: 1, Status: "closed", CreatedAt: "2026-10-20T20:00:00Z", // 2026-10-21 04:00 Shanghai
		Row: wbRow{Program: "ET", Level: "critical", Member: wbMember{AccountID: "ACC1", Region: "APAC"}},
	}

	// Event 4: 2026-11-01 (Shanghai), used to verify a cross-month range.
	c4 := cwCase{
		ID: "ALERT-4", Version: 1, Status: "open", CreatedAt: "2026-10-31T20:00:00Z",
		Row: wbRow{Program: "ST", Level: "watch", Member: wbMember{AccountID: "ACC2", Region: "APAC"}},
	}

	putAnalyticsCase(t, c1)
	putAnalyticsCase(t, c2)
	putAnalyticsCase(t, c3)
	putAnalyticsCase(t, c4)

	t.Run("DateRangeFilterInclusive", func(t *testing.T) {
		// Filter 10-15 to 10-20 (inclusive) -> Should get ALERT-1 and ALERT-2
		req := wbReq("test-user")
		req.URL.Path = "/api/workbench/cases"
		req.URL.RawQuery = "alert_start_date=2026-10-15&alert_end_date=2026-10-20"
		rr := httptest.NewRecorder()
		cwListHandler(rr, req)

		var body struct {
			Data struct {
				Cases []cwCase `json:"cases"`
				Total int      `json:"total"`
			} `json:"data"`
		}
		json.Unmarshal(rr.Body.Bytes(), &body)

		if body.Data.Total != 2 {
			t.Errorf("Expected 2 cases, got %d", body.Data.Total)
		}
	})

	t.Run("JointFiltering", func(t *testing.T) {
		// Filter 10-15 to 10-21, Program=ET, Status=closed -> Should get ALERT-3
		req := wbReq("test-user")
		req.URL.Path = "/api/workbench/cases"
		req.URL.RawQuery = "alert_start_date=2026-10-15&alert_end_date=2026-10-21&program=ET&status=closed"
		rr := httptest.NewRecorder()
		cwListHandler(rr, req)

		var body struct {
			Data struct {
				Cases []cwCase `json:"cases"`
				Total int      `json:"total"`
			} `json:"data"`
		}
		json.Unmarshal(rr.Body.Bytes(), &body)

		if body.Data.Total != 1 || body.Data.Cases[0].ID != "ALERT-3" {
			t.Errorf("Expected ALERT-3, got %v", body.Data.Cases)
		}
	})

	t.Run("CrossTwoWeeks", func(t *testing.T) {
		req := wbReq("test-user")
		req.URL.Path = "/api/workbench/cases"
		req.URL.RawQuery = "alert_start_date=2026-10-15&alert_end_date=2026-10-28"
		rr := httptest.NewRecorder()
		cwListHandler(rr, req)
		var body struct {
			Data struct {
				Total int `json:"total"`
			} `json:"data"`
		}
		json.Unmarshal(rr.Body.Bytes(), &body)
		if body.Data.Total != 3 {
			t.Fatalf("expected 3 events across two weeks, got %d: %s", body.Data.Total, rr.Body.String())
		}
	})

	t.Run("CrossMonthInclusive", func(t *testing.T) {
		req := wbReq("test-user")
		req.URL.Path = "/api/workbench/cases"
		req.URL.RawQuery = "alert_start_date=2026-10-20&alert_end_date=2026-11-01"
		rr := httptest.NewRecorder()
		cwListHandler(rr, req)
		var body struct {
			Data struct {
				Total int `json:"total"`
			} `json:"data"`
		}
		json.Unmarshal(rr.Body.Bytes(), &body)
		if body.Data.Total != 3 {
			t.Fatalf("expected end date to be inclusive across month, got %d: %s", body.Data.Total, rr.Body.String())
		}
	})

	t.Run("CoverageHint", func(t *testing.T) {
		// No batches in fixture usually.
		req := wbReq("test-user")
		req.URL.Path = "/api/workbench/cases"
		req.URL.RawQuery = "alert_start_date=2026-01-01&alert_end_date=2026-01-07"
		rr := httptest.NewRecorder()
		cwListHandler(rr, req)

		var body struct {
			Data struct {
				ReportNote string `json:"report_note"`
			} `json:"data"`
		}
		json.Unmarshal(rr.Body.Bytes(), &body)

		if !strings.Contains(body.Data.ReportNote, "尚无系统扫描覆盖") {
			t.Errorf("Expected coverage hint, got: %s", body.Data.ReportNote)
		}
	})

	t.Run("InvalidDateFormatHint", func(t *testing.T) {
		note := cwAlertHistoryReportNote(businessFilter{AlertStartDate: "2026-10-01", AlertEndDate: "2026-10-31"}, []cwCase{{ID: "BAD-DATE", Version: 1, CreatedAt: "not-a-date"}})
		if !strings.Contains(note, "created_at 缺失或格式异常") {
			t.Errorf("Expected invalid date hint, got: %s", note)
		}
	})
}

func TestAlertHistoryDeduplication(t *testing.T) {
	wbTestEnv(t)
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())

	// Same ID, different versions (though DB should handle this as it's PK, but let's test logic)
	c1 := cwCase{ID: "DUP-1", Version: 1, CreatedAt: "2026-10-20T10:00:00Z", Row: wbRow{Program: "ET", Member: wbMember{AccountID: "ACC1"}}}

	// In the real DB, ALERT-1 is PK. So we can't have duplicates.
	// But let's check if the query logic handles multiple events for same client correctly.
	c2 := cwCase{ID: "DUP-2", Version: 1, CreatedAt: "2026-10-20T11:00:00Z", Row: wbRow{Program: "ET", Member: wbMember{AccountID: "ACC1"}}}

	putAnalyticsCase(t, c1)
	putAnalyticsCase(t, c2)

	req := wbReq("test-user")
	req.URL.Path = "/api/workbench/cases"
	req.URL.RawQuery = "account_id=ACC1"
	rr := httptest.NewRecorder()
	cwListHandler(rr, req)

	var body struct {
		Data struct {
			Total int `json:"total"`
		} `json:"data"`
	}
	json.Unmarshal(rr.Body.Bytes(), &body)

	if body.Data.Total != 2 {
		t.Errorf("Expected 2 events for same customer, got %d", body.Data.Total)
	}
}
