package main

import (
	"context"
	"math"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// wbLiveMetricEqual tolerates insignificant aggregation-order differences while
// preserving nil as a distinct source outcome.
func wbLiveMetricEqual(left, right *float64) bool {
	if left == nil || right == nil {
		return left == nil && right == nil
	}
	scale := math.Max(1, math.Max(math.Abs(*left), math.Abs(*right)))
	return math.Abs(*left-*right) <= 1e-12*scale
}

// TestLiveTHTMissingDiagnostic is an opt-in, read-only source comparison for
// persisted scan samples. It compares the same IDs as one batch and as single-ID
// Saved Report/VQS requests without changing any Aeolus asset.
func TestLiveTHTMissingDiagnostic(t *testing.T) {
	if os.Getenv("RUN_LIVE_THT_MISSING_DIAGNOSTIC") != "1" {
		t.Skip("set RUN_LIVE_THT_MISSING_DIAGNOSTIC=1 for read-only source comparison")
	}
	ids := uniqueNonEmpty(strings.Split(os.Getenv("LIVE_THT_ADVERTISER_IDS"), ","))
	if len(ids) == 0 {
		t.Fatal("LIVE_THT_ADVERTISER_IDS is required")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	request := httptest.NewRequest(http.MethodGet, "/api/live", nil)
	request.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	start, end := os.Getenv("LIVE_THT_START_DATE"), os.Getenv("LIVE_THT_END_DATE")
	if start == "" || end == "" {
		start, end = "2026-10-12", "2026-10-18"
	}
	query := func(label string, queryIDs []string) map[string][]wbBatchMetric {
		ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
		defer cancel()
		metrics, err := queryTHTCurrentBatch(ctx, request, queryIDs, start, end)
		if err != nil {
			t.Fatalf("%s failed: %v", label, err)
		}
		for _, id := range queryIDs {
			for _, metric := range metrics[id] {
				t.Logf("%s id=%s account_id=%s status=%s ccr=%v nfs=%v revenue=%v revenue_status=%s request_id=%s revenue_request_id=%s revenue_log_id=%s revenue_error=%s", label, id, metric.AccountID, metric.Status, wbLiveMetricValue(metric.CCR), wbLiveMetricValue(metric.NFS), wbLiveMetricValue(metric.Revenue), metric.RevenueStatus, metric.RequestID, metric.RevenueRequestID, metric.RevenueLogID, metric.RevenueError)
			}
		}
		return metrics
	}
	batch := query("batch", ids)
	for _, id := range ids {
		single := query("single", []string{id})[id]
		batched := batch[id]
		if len(single) != len(batched) {
			t.Errorf("pair count mismatch for %s: batch=%+v single=%+v", id, batched, single)
			continue
		}
		for i := range single {
			if single[i].AccountID != batched[i].AccountID || single[i].Status != batched[i].Status || !wbLiveMetricEqual(single[i].CCR, batched[i].CCR) || !wbLiveMetricEqual(single[i].NFS, batched[i].NFS) {
				t.Errorf("CCR/NFS pair mismatch for %s: batch=%+v single=%+v", id, batched, single)
			}
			if single[i].RevenueStatus != batched[i].RevenueStatus || !wbLiveMetricEqual(single[i].Revenue, batched[i].Revenue) {
				t.Errorf("Revenue pair mismatch for %s: batch=%+v single=%+v", id, batched, single)
			}
		}
	}
}

// TestLiveTHTHistoricalFailingChunk is an opt-in, read-only reproduction of the
// 2026-10-12 weekly scan. It derives chunk 33 from the governed membership
// source instead of embedding customer IDs.
func TestLiveTHTHistoricalFailingChunk(t *testing.T) {
	if os.Getenv("RUN_LIVE_THT_CHUNK33") != "1" {
		t.Skip("set RUN_LIVE_THT_CHUNK33=1 for the read-only chunk-33 regression")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	req := httptest.NewRequest(http.MethodGet, "/api/live", nil)
	req.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	q := wbRequest{Program: "THT", Start: "2026-10-12", End: "2026-10-18", MemberStart: "2026-01-01", MemberEnd: "2026-10-18"}
	ctx, cancel := context.WithTimeout(context.Background(), 180*time.Second)
	defer cancel()
	members, _, err := liveWBMembers(ctx, req, q, wbConfig{MembershipCompleteConfirmed: true})
	if err != nil {
		t.Fatal(err)
	}
	ids := make([]string, 0, len(members))
	for _, member := range members {
		ids = append(ids, member.AdvertiserID)
	}
	chunks := chunkIDs(ids, wbTHTMetricChunkSize)
	target := 32
	if len(chunks) <= target {
		target = len(chunks) - 1
		t.Logf("historical chunk 33 is no longer reconstructable; validating current final chunk %d", target+1)
	}
	if target < 0 {
		t.Fatal("current membership snapshot contains no queryable IDs")
	}
	metrics, err := queryTHTCurrentBatch(ctx, req, chunks[target], q.Start, q.End)
	if err != nil {
		t.Fatal(err)
	}
	pairCount := 0
	for _, pairs := range metrics {
		pairCount += len(pairs)
	}
	t.Logf("chunk=%d ids=%d pair_rows=%d", target+1, len(chunks[target]), pairCount)
}
