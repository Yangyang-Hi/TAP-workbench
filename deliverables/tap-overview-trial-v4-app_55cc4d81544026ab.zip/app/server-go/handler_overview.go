package main

import "net/http"

// overviewAccountsList delegates to the read-only Saved Report query.
func overviewAccountsList(w http.ResponseWriter, r *http.Request) {
	overviewAccountsHandler(w, r)
}
