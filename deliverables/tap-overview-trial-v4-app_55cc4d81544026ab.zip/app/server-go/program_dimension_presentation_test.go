package main

import (
	"encoding/json"
	"strings"
	"testing"
	"time"
)

func TestTHTReadModelUsesAdvertiserGrainAndRejectsLegacyAccountComparison(t *testing.T) {
	pre, post, current := 2.0, 3.0, 4.0
	row := wbRow{
		Program: "THT",
		Member:  wbMember{AdvertiserID: "adv-1", AccountID: "acc-1", Start: "2026-10-01"},
		CCR:     &current,
		NFS:     &current,
		Source:  map[string]any{"grain": "account_advertiser_week"},
		Comparison: wbComparison{
			PreCCR: &pre, PostCCR: &post, CCRGrowthPct: f64(50), Status: metricAvailable,
			Source: map[string]any{"grain": "account_advertiser_window"},
		},
	}
	view := wbToReadRow(wbJob{ID: "job"}, row, nil, nil, time.Date(2026, 10, 27, 0, 0, 0, 0, time.UTC))
	if view.Comparison.CCRGrowthPct == nil || *view.Comparison.CCRGrowthPct != 50 {
		t.Fatalf("advertiser relative growth lost: %+v", view.Comparison)
	}

	row.Source = map[string]any{"grain": "account_week"}
	row.Comparison.Source = map[string]any{"grain": "account_window"}
	legacy := wbToReadRow(wbJob{ID: "job"}, row, nil, nil, time.Date(2026, 10, 27, 0, 0, 0, 0, time.UTC))
	if legacy.Comparison.Status != "incompatible_legacy_grain" || legacy.Comparison.CCRGrowthPct != nil || !strings.Contains(legacy.Comparison.MissingReason, "旧记录粒度不兼容") {
		t.Fatalf("legacy account comparison was not rejected: %+v", legacy.Comparison)
	}
}

func TestProgramDimensionPresentationAndCardLabels(t *testing.T) {
	pre, post, current := 1.0, 2.0, 3.0
	for _, tc := range []struct {
		program, dimension, increase string
	}{
		{"ET", "Account Level", "WoW CCR Increase"},
		{"ST", "Account Level", "QoQ CCR Increase"},
		{"THT", "Advertiser Level", "WoW CCR Increase"},
	} {
		t.Run(tc.program, func(t *testing.T) {
			row := wbRow{Program: tc.program, Member: wbMember{AccountID: "acc", AdvertiserID: "adv", Start: "2026-10-01"}, CCR: &current, NFS: &current, Revenue: &current, Source: map[string]any{"grain": "account_advertiser_week"}, Comparison: wbComparison{PreCCR: &pre, PostCCR: &post, CCRGrowthPct: f64(100), Status: metricAvailable, Source: map[string]any{"grain": "account_advertiser_window"}}}
			view := cwPresentation(cwCase{Kind: "risk", Row: row})
			if view.DimensionLabel != tc.dimension || view.IncreaseLabel != tc.increase || view.CCRGrowthPct == nil || *view.CCRGrowthPct != 100 {
				t.Fatalf("unexpected presentation: %+v", view)
			}
			card, _ := json.Marshal(cwNotificationCard(cwCase{Kind: "risk", ID: "case", Row: row}, "formal", "owner"))
			text := string(card)
			for _, expected := range []string{tc.dimension, tc.increase, "Pre → Post P0 CCR", "100.00%"} {
				if !strings.Contains(text, expected) {
					t.Fatalf("card missing %q: %s", expected, text)
				}
			}
			for _, forbidden := range []string{"CCR Delta", "Relative Growth", "Account Current CCR", "ADV CCR"} {
				if strings.Contains(text, forbidden) {
					t.Fatalf("card contains forbidden label %q: %s", forbidden, text)
				}
			}
		})
	}
}
