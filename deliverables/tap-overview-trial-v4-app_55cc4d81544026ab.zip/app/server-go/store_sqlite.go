package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/google/uuid"
	_ "modernc.org/sqlite"
)

type sqliteStore struct {
	db *sql.DB
}

func newSQLiteStore() (*sqliteStore, error) {
	dataDir, err := resolveDataDir()
	if err != nil {
		return nil, err
	}
	if err := os.MkdirAll(dataDir, 0o755); err != nil {
		return nil, err
	}
	db, err := sql.Open("sqlite", filepath.Join(dataDir, "app.db"))
	if err != nil {
		return nil, err
	}
	if _, err := db.Exec(`CREATE TABLE IF NOT EXISTS records (
		id TEXT NOT NULL,
		collection TEXT NOT NULL,
		title TEXT NOT NULL DEFAULT '',
		description TEXT NOT NULL DEFAULT '',
		status TEXT NOT NULL DEFAULT '',
		category TEXT NOT NULL DEFAULT '',
		owner_id TEXT NOT NULL DEFAULT '',
		priority INTEGER NOT NULL DEFAULT 0,
		amount TEXT NOT NULL DEFAULT '',
		active INTEGER NOT NULL DEFAULT 0,
		due_at TEXT NOT NULL DEFAULT '',
		metadata TEXT NOT NULL DEFAULT '{}',
		createdAt TEXT NOT NULL,
		updatedAt TEXT NOT NULL,
		PRIMARY KEY (collection, id)
	)`); err != nil {
		return nil, err
	}
	st := &sqliteStore{db: db}
	if err := st.runMigrations(); err != nil {
		return nil, err
	}
	if err := st.createIndexes(); err != nil {
		return nil, err
	}
	return st, nil
}

func (s *sqliteStore) runMigrations() error {
	migrations := []string{
		// 追加 ALTER TABLE 语句；"duplicate column name" 错误会被忽略。
		`ALTER TABLE records ADD COLUMN title TEXT NOT NULL DEFAULT ''`,
		`ALTER TABLE records ADD COLUMN description TEXT NOT NULL DEFAULT ''`,
		`ALTER TABLE records ADD COLUMN status TEXT NOT NULL DEFAULT ''`,
		`ALTER TABLE records ADD COLUMN category TEXT NOT NULL DEFAULT ''`,
		`ALTER TABLE records ADD COLUMN owner_id TEXT NOT NULL DEFAULT ''`,
		`ALTER TABLE records ADD COLUMN priority INTEGER NOT NULL DEFAULT 0`,
		`ALTER TABLE records ADD COLUMN amount TEXT NOT NULL DEFAULT ''`,
		`ALTER TABLE records ADD COLUMN active INTEGER NOT NULL DEFAULT 0`,
		`ALTER TABLE records ADD COLUMN due_at TEXT NOT NULL DEFAULT ''`,
		`ALTER TABLE records ADD COLUMN metadata TEXT NOT NULL DEFAULT '{}'`,
	}
	for _, stmt := range migrations {
		if _, err := s.db.Exec(stmt); err != nil && !strings.Contains(err.Error(), "duplicate column name") {
			return err
		}
	}
	return nil
}

func (s *sqliteStore) createIndexes() error {
	indexes := []string{
		`CREATE INDEX IF NOT EXISTS idx_records_collection_status ON records (collection, status)`,
		`CREATE INDEX IF NOT EXISTS idx_records_collection_category ON records (collection, category)`,
		`CREATE INDEX IF NOT EXISTS idx_records_collection_owner ON records (collection, owner_id)`,
		`CREATE INDEX IF NOT EXISTS idx_records_collection_due ON records (collection, due_at)`,
	}
	for _, stmt := range indexes {
		if _, err := s.db.Exec(stmt); err != nil {
			return err
		}
	}
	return nil
}

func (s *sqliteStore) Mode() string { return "sqlite" }

func (s *sqliteStore) GetAll(ctx context.Context, collection string) ([]map[string]any, error) {
	rows, err := s.db.QueryContext(ctx, `SELECT id, title, description, status, category, owner_id, priority, amount, active, due_at, metadata, createdAt, updatedAt FROM records WHERE collection = ? ORDER BY createdAt DESC`, collection)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := []map[string]any{}
	for rows.Next() {
		item, err := scanRecord(rows)
		if err != nil {
			return nil, err
		}
		items = append(items, item)
	}
	return items, rows.Err()
}

func (s *sqliteStore) GetByID(ctx context.Context, collection string, id string) (map[string]any, error) {
	row := s.db.QueryRowContext(ctx, `SELECT id, title, description, status, category, owner_id, priority, amount, active, due_at, metadata, createdAt, updatedAt FROM records WHERE collection = ? AND id = ?`, collection, id)
	item, err := scanRecord(row)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return item, nil
}

func (s *sqliteStore) Create(ctx context.Context, collection string, data map[string]any) (map[string]any, error) {
	now := time.Now().Format(time.RFC3339)
	id := asString(data["id"])
	if id == "" {
		id = uuid.NewString()
	}
	data["id"] = id
	data["createdAt"] = now
	data["updatedAt"] = now
	record := mapToEnvelope(data)
	metadata, err := json.Marshal(record.Metadata)
	if err != nil {
		return nil, err
	}
	_, err = s.db.ExecContext(
		ctx,
		`INSERT INTO records (id, collection, title, description, status, category, owner_id, priority, amount, active, due_at, metadata, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		id,
		collection,
		record.Title,
		record.Description,
		record.Status,
		record.Category,
		record.OwnerID,
		record.Priority,
		record.Amount,
		record.Active,
		record.DueAt,
		string(metadata),
		now,
		now,
	)
	if err != nil {
		return nil, err
	}
	return data, nil
}

func (s *sqliteStore) Update(ctx context.Context, collection string, id string, data map[string]any) (map[string]any, error) {
	existing, err := s.GetByID(ctx, collection, id)
	if err != nil {
		return nil, err
	}
	if existing == nil {
		return nil, sql.ErrNoRows
	}
	now := time.Now().Format(time.RFC3339)
	data["id"] = id
	if data["createdAt"] == nil {
		data["createdAt"] = existing["createdAt"]
	}
	data["updatedAt"] = now
	record := mapToEnvelope(data)
	metadata, err := json.Marshal(record.Metadata)
	if err != nil {
		return nil, err
	}
	_, err = s.db.ExecContext(
		ctx,
		`UPDATE records SET title = ?, description = ?, status = ?, category = ?, owner_id = ?, priority = ?, amount = ?, active = ?, due_at = ?, metadata = ?, updatedAt = ? WHERE collection = ? AND id = ?`,
		record.Title,
		record.Description,
		record.Status,
		record.Category,
		record.OwnerID,
		record.Priority,
		record.Amount,
		record.Active,
		record.DueAt,
		string(metadata),
		now,
		collection,
		id,
	)
	if err != nil {
		return nil, err
	}
	return data, nil
}

func (s *sqliteStore) Delete(ctx context.Context, collection string, id string) error {
	result, err := s.db.ExecContext(ctx, `DELETE FROM records WHERE collection = ? AND id = ?`, collection, id)
	if err != nil {
		return err
	}
	rows, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if rows == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func scanRecord(scanner interface{ Scan(...any) error }) (map[string]any, error) {
	var record recordEnvelope
	var metadataRaw string
	var activeInt int64
	if err := scanner.Scan(
		&record.ID,
		&record.Title,
		&record.Description,
		&record.Status,
		&record.Category,
		&record.OwnerID,
		&record.Priority,
		&record.Amount,
		&activeInt,
		&record.DueAt,
		&metadataRaw,
		&record.CreatedAt,
		&record.UpdatedAt,
	); err != nil {
		return nil, err
	}
	record.Active = activeInt != 0
	if err := json.Unmarshal([]byte(metadataRaw), &record.Metadata); err != nil {
		record.Metadata = map[string]any{}
	}
	return envelopeToMap(record), nil
}
