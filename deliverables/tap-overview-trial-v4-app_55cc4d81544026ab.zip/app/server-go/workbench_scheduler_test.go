package main

import (
	"context"
	"errors"
	"net/http"
	"sync"
	"testing"
	"time"
)

func TestWeeklyScheduleDecisionUsesMondayAndIsIdempotent(t *testing.T) {
	monday := time.Date(2026, 10, 19, 9, 0, 0, 0, time.FixedZone("UTC+8", 8*60*60))
	run, batch, reason, err := wbWeeklyScheduleDecision(monday, "Asia/Shanghai", map[string]bool{})
	if err != nil || !run || batch != "TAP-WEEK-2026-10-12-2026-10-18" || reason != "missing_et" {
		t.Fatalf("unexpected Monday decision: run=%t batch=%s reason=%s err=%v", run, batch, reason, err)
	}
	complete := map[string]bool{"ET": true, "THT": true, "ST": true}
	run, _, reason, err = wbWeeklyScheduleDecision(monday, "Asia/Shanghai", complete)
	if err != nil || run || reason != "batch_complete" {
		t.Fatalf("completed batch reran: run=%t reason=%s err=%v", run, reason, err)
	}
	run, _, reason, err = wbWeeklyScheduleDecision(monday.AddDate(0, 0, 1), "Asia/Shanghai", map[string]bool{})
	if err != nil || run || reason != "outside_schedule_day" {
		t.Fatalf("off-schedule restart must not catch up: run=%t reason=%s err=%v", run, reason, err)
	}
	delayed := wbWeeklySchedulerConfig{Enabled: true, Weekday: int(time.Monday), Hour: 9, DataReadyDelayMin: 120}
	run, _, reason, err = wbWeeklyScheduleDecisionWithConfig(time.Date(2026, 10, 19, 10, 59, 0, 0, time.FixedZone("UTC+8", 8*60*60)), "Asia/Shanghai", delayed, map[string]bool{})
	if err != nil || run || reason != "data_not_ready" {
		t.Fatalf("data readiness delay ignored: run=%t reason=%s err=%v", run, reason, err)
	}
}

func TestScheduledJobCreationIsIdempotent(t *testing.T) {
	wbTestEnv(t)
	c, err := loadWBConfig()
	if err != nil {
		t.Fatal(err)
	}
	q := wbRequest{Program: "ET", Region: "all", Start: "2026-10-12", End: "2026-10-18", MemberStart: "2026-01-01", MemberEnd: "2026-10-18"}
	first, created, err := wbCreateScheduledJob(wbReq(wbSchedulerPrincipal), c, q)
	if err != nil || !created {
		t.Fatalf("first schedule failed: created=%t err=%v", created, err)
	}
	second, created, err := wbCreateScheduledJob(wbReq(wbSchedulerPrincipal), c, q)
	if err != nil || created || second.ID != first.ID {
		t.Fatalf("duplicate schedule created: first=%s second=%s created=%t err=%v", first.ID, second.ID, created, err)
	}
}

func TestScheduledSTUnavailablePersistsExplicitFailure(t *testing.T) {
	wbTestEnv(t)
	oldMembers := wbLoadMembers
	defer func() { wbLoadMembers = oldMembers }()
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return nil, false, errors.New("ST snapshot unavailable; sync Q4/Q3 Sheet with current user first")
	}
	c, err := loadWBConfig()
	if err != nil {
		t.Fatal(err)
	}
	q := wbRequest{Program: "ST", Region: "all", Start: "2026-10-12", End: "2026-10-18", MemberStart: "2026-01-01", MemberEnd: "2026-10-18"}
	job, created, err := wbCreateScheduledJob(wbReq(wbSchedulerPrincipal), c, q)
	if err != nil || !created {
		t.Fatalf("schedule create failed: %v", err)
	}
	wbRunJob(wbReq(wbSchedulerPrincipal), job.ID, c)
	stored, err := wbLookup(job.ID, wbSchedulerPrincipal)
	if err != nil || stored.Status != "blocked" || stored.Error != "ST snapshot unavailable; sync Q4/Q3 Sheet with current user first" {
		t.Fatalf("ST failure not explicit/persisted: job=%+v err=%v", stored, err)
	}
}

func TestETQuotaExcessOnlyAndSharedCaseIdempotency(t *testing.T) {
	wbTestEnv(t)
	baseline, err := loadQuotaBaseline()
	if err != nil || len(baseline.Regions) == 0 {
		t.Fatalf("baseline unavailable: %v", err)
	}
	baseline.Status = "confirmed"
	baseline.Period = "Q4"
	region := baseline.Regions[0]
	rows := make([]submissionMetric, 0, region.ET+1)
	for i := 0; i <= region.ET; i++ {
		rows = append(rows, submissionMetric{AccountIDs: []string{"account-" + time.Unix(int64(i), 0).UTC().Format("150405.000000000")}, TicketID: "et-ticket-" + time.Unix(int64(i), 0).UTC().Format("150405.000000000"), Region: region.Region})
	}
	source := quotaSourceResult{
		ET:           rows,
		THT:          []submissionMetric{{TicketID: "tht-over", Region: region.Region}},
		ST:           []stMetric{{Region: region.Region, Brand: "st-over"}},
		SourceStatus: map[string]string{"ET": "available", "THT": "available", "ST": "available"},
	}
	excesses := etQuotaExcesses(baseline, source)
	if len(excesses) != 1 || excesses[0].Region != region.Region || excesses[0].Ratio <= 100 {
		t.Fatalf("ET excess not detected exactly once: %+v", excesses)
	}
	first, err := cwCreateQuotaAlert("Q4", "2026-10-12", "2026-10-18", excesses[0])
	if err != nil || first.Kind != "quota" || first.Row.Program != "ET" {
		t.Fatalf("ET quota case invalid: %+v err=%v", first, err)
	}
	second, err := cwCreateQuotaAlert("Q4", "2026-10-12", "2026-10-18", excesses[0])
	if err != nil || second.ID != first.ID || second.Version != 1 {
		t.Fatalf("quota case was not idempotent: first=%+v second=%+v err=%v", first, second, err)
	}
	if first.Row.Program == "THT" || first.Row.Program == "ST" {
		t.Fatal("non-ET quota alert generated")
	}
}

func TestScheduledJobConcurrentAndCrossWeekPersistence(t *testing.T) {
	wbTestEnv(t)
	c, err := loadWBConfig()
	if err != nil {
		t.Fatal(err)
	}
	q := wbRequest{Program: "ET", Region: "all", Start: "2026-10-12", End: "2026-10-18", MemberStart: "2026-01-01", MemberEnd: "2026-10-18"}
	const callers = 12
	ids := make(chan string, callers)
	var wg sync.WaitGroup
	for i := 0; i < callers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			job, _, createErr := wbCreateScheduledJob(wbReq(wbSchedulerPrincipal), c, q)
			if createErr != nil {
				ids <- "error:" + createErr.Error()
				return
			}
			ids <- job.ID
		}()
	}
	wg.Wait()
	close(ids)
	first := ""
	for id := range ids {
		if first == "" {
			first = id
		}
		if id != first {
			t.Fatalf("same week created multiple jobs: %q != %q", id, first)
		}
	}
	q.Start, q.End, q.MemberEnd = "2026-10-19", "2026-10-25", "2026-10-25"
	next, created, err := wbCreateScheduledJob(wbReq(wbSchedulerPrincipal), c, q)
	if err != nil || !created || next.ID == first || next.BatchID == "TAP-WEEK-2026-10-12-2026-10-18" {
		t.Fatalf("cross-week job not separated: %+v created=%t err=%v", next, created, err)
	}
	// Simulate restart by clearing memory; persisted jobs remain idempotent.
	wbMu.Lock()
	wbRunning = map[string]*wbJob{}
	wbMu.Unlock()
	restarted, created, err := wbCreateScheduledJob(wbReq(wbSchedulerPrincipal), c, q)
	if err != nil || created || restarted.ID != next.ID {
		t.Fatalf("restart duplicated persisted weekly job: %+v created=%t err=%v", restarted, created, err)
	}
}

func TestPartialScheduledJobCreatesNoCandidates(t *testing.T) {
	wbTestEnv(t)
	row := wbRow{ID: "partial-risk", Program: "ET", Member: wbMember{AccountID: "7675782032500424721", TicketID: "ticket-partial", Region: "APAC"}, CCR: f64(80), NFS: f64(400), Level: "critical", MetricStatus: "success"}
	job := wbJob{ID: "partial-scan", BatchID: "TAP-WEEK-2026-10-12-2026-10-18", Principal: wbSchedulerPrincipal, Status: "partial", Complete: false, Request: wbRequest{Program: "ET", Start: "2026-10-12", End: "2026-10-18"}, Rule: testRule(), Rows: []wbRow{row}}
	if err := cwImportJob(job); err != nil {
		t.Fatal(err)
	}
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	var count int
	if err = db.QueryRow("SELECT COUNT(*) FROM tap_cases").Scan(&count); err != nil || count != 0 {
		t.Fatalf("partial scan created notification candidate: count=%d err=%v", count, err)
	}
	job.Status, job.Complete = "ready", true
	if err = cwImportJob(job); err != nil {
		t.Fatal(err)
	}
	created, err := cwRead(db, cwCaseID(job, row))
	if err != nil || created.Fields["candidate_status"] != "auto_candidate" || created.Fields["notification_result"] != "not_requested" {
		t.Fatalf("complete extreme was not persisted as unsent candidate: %+v err=%v", created, err)
	}
	if err = db.QueryRow("SELECT COUNT(*) FROM tap_outbox").Scan(&count); err != nil || count != 0 {
		t.Fatalf("auto candidate entered outbox with auto_send=false: count=%d err=%v", count, err)
	}
}

func TestETQuotaBoundaryAndWeeklyIdempotency(t *testing.T) {
	wbTestEnv(t)
	baseline := quotaBaseline{Regions: []struct {
		Region string `json:"region"`
		ET     int    `json:"ET"`
		ST     int    `json:"ST"`
	}{{Region: "APAC", ET: 1}}}
	source := quotaSourceResult{ET: []submissionMetric{{ID: "one", AccountIDs: []string{"one"}, TicketID: "one", Region: "APAC"}}, SourceStatus: map[string]string{"ET": "available"}}
	got := etQuotaExcesses(baseline, source)
	if len(got) != 1 || got[0].Ratio != 100 {
		t.Fatalf("ratio=100 must alert for ET: %+v", got)
	}
	source.ET = append(source.ET, submissionMetric{ID: "two", AccountIDs: []string{"two"}, TicketID: "two", Region: "APAC"})
	got = etQuotaExcesses(baseline, source)
	if len(got) != 1 || got[0].Ratio <= 100 {
		t.Fatalf("ratio>100 did not alert: %+v", got)
	}
	first, err := cwCreateQuotaAlert("Q4", "2026-10-12", "2026-10-18", got[0])
	if err != nil || first.Fields["regional_poc_status"] != "pending_regional_poc" {
		t.Fatalf("weekly quota candidate invalid: %+v err=%v", first, err)
	}
	next, err := cwCreateQuotaAlert("Q4", "2026-10-19", "2026-10-25", got[0])
	if err != nil || next.ID != first.ID {
		t.Fatalf("quota idempotency must be quarter+tier+region+threshold-version scoped: first=%s next=%s err=%v", first.ID, next.ID, err)
	}
}

func TestScheduledETUsesAuthoritativeAccountSnapshot(t *testing.T) {
	account := wbJob{Status: "partial", Request: wbRequest{Program: "ET"}, Members: 2150, Rows: []wbRow{{Member: wbMember{AccountID: "account"}, CCR: f64(4), NFS: f64(60), Revenue: f64(100)}}}
	if !wbScheduledJobComplete(account) {
		t.Fatal("completed Account-authority ET snapshot should suppress duplicate scheduling")
	}
	failed := account
	failed.Status = "failed"
	if wbScheduledJobComplete(failed) {
		t.Fatal("failed persisted scan must not suppress scheduler retry")
	}
}

func TestScheduledProgramsTreatsCompletedManualBatchAsComplete(t *testing.T) {
	wbTestEnv(t)
	batchID := "TAP-WEEK-2026-10-19-2026-10-25"
	state := wbDisk{Jobs: map[string]wbJob{
		"manual-et":  {ID: "manual-et", BatchID: batchID, Principal: "operator", Status: "partial", Request: wbRequest{Program: "ET"}},
		"manual-tht": {ID: "manual-tht", BatchID: batchID, Principal: "operator", Status: "ready", Request: wbRequest{Program: "THT"}},
		"manual-st":  {ID: "manual-st", BatchID: batchID, Principal: "operator", Status: "empty", Request: wbRequest{Program: "ST"}},
	}}
	if err := wbWriteDisk(state); err != nil {
		t.Fatal(err)
	}
	completed, err := wbScheduledPrograms(batchID)
	if err != nil {
		t.Fatal(err)
	}
	if !completed["ET"] || !completed["THT"] || !completed["ST"] {
		t.Fatalf("completed manual batch did not suppress scheduler duplicates: %+v", completed)
	}
}
