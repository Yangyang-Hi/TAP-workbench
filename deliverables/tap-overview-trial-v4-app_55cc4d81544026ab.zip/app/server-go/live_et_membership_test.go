package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// TestLiveETMembershipContract is opt-in because it executes the real
// current-user Titan -> Saved Report -> VQS chain. It is read-only, does not
// modify Aeolus assets, and never logs credentials.
func TestLiveETMembershipContract(t *testing.T) {
	if os.Getenv("RUN_LIVE_ET_MEMBERSHIP") != "1" {
		t.Skip("set RUN_LIVE_ET_MEMBERSHIP=1 for real ET membership verification")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())

	const start, end = "2026-10-01", "2026-10-20"
	req := httptest.NewRequest(http.MethodGet, "/api/live?start_date="+start+"&end_date="+end+"&client_tier=emerging_trust", nil)
	req.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	probe, err := runTitanVQSProbe(ctx, req, "et_account_list")
	if err != nil {
		t.Fatal(err)
	}
	if asString(probe["status"]) != "ok" {
		t.Fatalf("live ET VQS failed: status=%s request_id=%s log_id=%s", asString(probe["status"]), asString(probe["requestId"]), asString(probe["logId"]))
	}
	cfg, err := loadDataSourceConfig()
	if err != nil {
		t.Fatal(err)
	}
	proven, blockReason := proveETTypeNameFilterContract("et_account_list", cfg.Sources["et_account_list"], probe["effective_filters"])
	var rows []map[string]any
	encoded, _ := json.Marshal(probe["business_rows"])
	if json.Unmarshal(encoded, &rows) != nil {
		t.Fatal("live ET business rows are unavailable")
	}
	sourceRows := len(rows)
	rows, supplemented := supplementETTypeNameFromContract(rows, proven)
	members, _, err := canonicalWBMembers(rows, wbRequest{Program: "ET", Region: "all", MemberStart: start, MemberEnd: end}, true)
	proof := map[string]any{
		"source":                    "et_account_list",
		"rid":                       cfg.Sources["et_account_list"].RID,
		"request_id":                asString(probe["requestId"]),
		"log_id":                    asString(probe["logId"]),
		"type_name_contract_proven": proven,
		"block_reason":              blockReason,
		"effective_filters":         probe["effective_filters"],
		"columns":                   probe["columns"],
		"field_map":                 probe["field_map"],
		"source_rows":               sourceRows,
		"supplemented_rows":         supplemented,
		"canonical_members":         len(members),
	}
	output, _ := json.Marshal(proof)
	t.Log(string(output))
	if err != nil {
		t.Fatal(err)
	}
	if sourceRows == 0 || !proven || blockReason != "" || len(members) == 0 {
		t.Fatalf("live ET membership contract failed: %s", output)
	}
}

func TestETCreateTimeAliasSurvivesCanonicalAndPersistence(t *testing.T) {
	const accountID = "7244006541899137025"
	const sourceCreateTime = "2026-10-07 14:51:28"
	rows := []map[string]any{{
		"type_name":            "Emerging trust apply",
		"final_result":         "APPROVE",
		"account_id":           accountID,
		"create_date":          "2026-10-07",
		"create_time":          sourceCreateTime,
		"protection_starttime": "2026-09-01 00:00:00",
	}}
	members, _, err := canonicalWBMembers(rows, wbRequest{Program: "ET", Region: "all", MemberStart: "2026-10-01", MemberEnd: "2026-10-25"}, true)
	if err != nil {
		t.Fatal(err)
	}
	if len(members) != 1 || members[0].AccountID != accountID {
		t.Fatalf("19-digit account ID mapping mismatch: %#v", members)
	}
	if members[0].Start != sourceCreateTime || len(members[0].Tickets) != 1 || members[0].Tickets[0].Start != sourceCreateTime {
		t.Fatalf("internal ET anchor lost: %#v", members[0])
	}

	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	job := wbJob{ID: "et-anchor-test", Rows: []wbRow{{Program: "ET", Member: members[0]}}}
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	persisted, err := wbReadDisk()
	if err != nil {
		t.Fatal(err)
	}
	got := persisted.Jobs[job.ID].Rows[0].Member
	if got.AccountID != accountID || got.Start != sourceCreateTime || got.Tickets[0].Start != sourceCreateTime {
		t.Fatalf("persisted ET anchor mismatch: %#v", got)
	}
}
