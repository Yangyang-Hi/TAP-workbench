package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"
)

func TestQuotaWindowDefaultAndSelectedBatch(t *testing.T) {
	old := quotaPersistedBatches
	defer func() { quotaPersistedBatches = old }()
	now := time.Date(2026, 10, 23, 7, 0, 0, 0, time.UTC)
	quotaPersistedBatches = func() ([]wbBatchContract, map[string][]wbJob, error) { return nil, nil, nil }
	w, err := resolveQuotaWindow(url.Values{"time_mode": {"weekly"}, "quarter": {"Q4"}}, now)
	if err != nil || w.Start != "2026-10-01" || w.End != "2026-10-23" || w.Basis != "live_qtd_no_weekly_batch" {
		t.Fatalf("default window=%+v err=%v", w, err)
	}
	quotaPersistedBatches = func() ([]wbBatchContract, map[string][]wbJob, error) {
		return []wbBatchContract{{BatchID: "week", MetricStart: "2026-10-12", MetricEnd: "2026-10-18"}}, nil, nil
	}
	w, err = resolveQuotaWindow(url.Values{"time_mode": {"weekly"}, "batch_id": {"week"}}, now)
	if err != nil || w.Start != "2026-10-01" || w.End != "2026-10-18" || w.BatchID != "week" {
		t.Fatalf("must be QTD, not one-week quota: %+v %v", w, err)
	}
	if _, err = resolveQuotaWindow(url.Values{"batch_id": {"missing"}}, now); err == nil {
		t.Fatal("unknown batch silently replaced")
	}
}

func TestQuotaCustomWindowMustNotDefaultOrExpand(t *testing.T) {
	now := time.Date(2026, 10, 23, 0, 0, 0, 0, time.UTC)
	for _, q := range []url.Values{{"time_mode": {"custom"}}, {"start_date": {"2026-10-01"}}, {"start_date": {"2026-10-20"}, "end_date": {"2026-10-01"}}} {
		if _, e := resolveQuotaWindow(q, now); e == nil {
			t.Fatalf("accepted invalid custom window: %v", q)
		}
	}
	w, e := resolveQuotaWindow(url.Values{"quarter": {"Q4"}, "start_date": {"2026-10-05"}, "end_date": {"2026-10-09"}}, now)
	if e != nil || w.Start != "2026-10-05" || w.End != "2026-10-09" {
		t.Fatalf("custom window changed: %+v %v", w, e)
	}
}

func TestQuotaDefaultHandlerReachesSourcesWithoutURLDates(t *testing.T) {
	oldB, oldS := quotaPersistedBatches, loadQuotaSources
	defer func() { quotaPersistedBatches = oldB; loadQuotaSources = oldS }()
	quotaPersistedBatches = func() ([]wbBatchContract, map[string][]wbJob, error) {
		return []wbBatchContract{{BatchID: "week", MetricEnd: "2026-10-18"}}, nil, nil
	}
	called := false
	loadQuotaSources = func(_ context.Context, _ *http.Request, q, s, e string) quotaSourceResult {
		called = true
		if q != "Q4" || s != "2026-10-01" || e != "2026-10-18" {
			t.Fatalf("window=%s %s %s", q, s, e)
		}
		return quotaSourceResult{SourceStatus: map[string]string{"ET": "failed", "THT": "failed", "ST": "failed"}, Errors: map[string]string{"ET": "fixture unavailable"}}
	}
	r := httptest.NewRecorder()
	submissionsQuotaList(r, httptest.NewRequest("GET", "/api/submissions/quota?quarter=Q4&time_mode=weekly", nil))
	if r.Code != 200 || !called || !strings.Contains(r.Body.String(), "6356") || !strings.Contains(r.Body.String(), "start_date") {
		t.Fatalf("default request failed: %d %s", r.Code, r.Body.String())
	}
}

func TestQuotaETProjectionAndWeeklyContract(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	c, e := loadDataSourceConfig()
	if e != nil {
		t.Fatal(e)
	}
	s := c.Sources["et_quota_tickets"]
	if s.SID != 1198629 || s.Fields["ticket_id"].DimMetID != "10000000536470" {
		t.Fatalf("ticket contract missing: %+v", s)
	}
	chart := buildDetailSavedReportChart(map[string]any{}, s, effectiveSourceFields(c, "et_quota_tickets"))
	found := false
	for _, raw := range chart["dimensions"].([]any) {
		d := raw.(map[string]any)
		if asString(d["datasetFieldId"]) == "10000000536470" {
			found = true
		}
	}
	if !found {
		t.Fatal("quota query still lacks ticket_id projection")
	}
	x := submissionMetric{TicketID: "t1", AccountIDs: []string{"account1"}, Region: "APAC", Date: "2026-10-02", AdvertiserIDs: []string{"adv1"}}
	y := x
	y.Region = "CNOB"
	points := weeklyQuota([]submissionMetric{x, y}, []submissionMetric{x, y})
	if points[0]["et_qtd"] != 1 || points[0]["tht_qtd"] != 1 {
		t.Fatalf("global weekly duplicates: %#v", points)
	}
	out := aggregateQuota(quotaBaseline{}, quotaSourceResult{ET: []submissionMetric{x}, THT: []submissionMetric{x}, SourceStatus: map[string]string{"ET": "available", "THT": "failed", "ST": "available"}, AsOf: "fixture-sync"}, "Q4")
	if out["weekly"].([]map[string]any)[0]["tht_qtd"] != nil || out["as_of"].(map[string]any)["st"] != "fixture-sync" {
		t.Fatalf("missing contract or failure shown as zero: %#v", out)
	}
}
