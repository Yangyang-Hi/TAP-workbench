package main

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"
)

// wbCustomQueryProgram executes the existing authoritative membership and batch
// readers without registering a weekly job. It deliberately has no persistence,
// casework import, outbox, or notification path.
func wbCustomQueryProgram(ctx context.Context, request *http.Request, program, start, end, region string, config wbConfig) (wbJob, error) {
	program = strings.ToUpper(strings.TrimSpace(program))
	q := wbRequest{Program: program, Region: region, Start: start, End: end, MemberStart: "2026-01-01", MemberEnd: end}
	if q.Region == "" {
		q.Region = "all"
	}
	if err := validateWBRequest(&q); err != nil {
		return wbJob{}, err
	}
	rule, ok := config.Rules[program]
	if !ok || !rule.Enabled {
		return wbJob{}, fmt.Errorf("%s absolute rule disabled or not configured", program)
	}
	members, complete, err := wbLoadMembers(ctx, request, q, config)
	if err != nil {
		return wbJob{}, err
	}
	if len(members) > config.MaxClients {
		return wbJob{}, fmt.Errorf("%d clients exceed max_clients_per_scan=%d; no silent truncation", len(members), config.MaxClients)
	}
	var rows []wbRow
	switch program {
	case "ET":
		rows, _, err = wbRunETBatches(ctx, request, members, q, rule)
	case "ST":
		rows, _, err = wbRunSTBatches(ctx, request, members, q, rule)
	case "THT":
		rows, _, err = wbRunTHTBatchesWithProgress(ctx, request, members, q, rule, nil)
	}
	if err != nil {
		return wbJob{}, err
	}
	if program != "THT" {
		if evidence, evidenceErr := wbQueryPairEvidence(ctx, request, members, q, rule); evidenceErr == nil {
			rows = applyPairEvidence(rows, evidence, q, rule)
		}
	}
	if rule.RiskPolicy == wbGovernancePolicyVersion {
		rows = wbApplyGovernanceRows(rows, rule)
	}
	job := wbJob{ID: "custom-" + wbKey([]string{program, start, end, region})[:16], AsOf: time.Now().UTC().Format(time.RFC3339), RuleVersion: rule.Version, Principal: requestUsername(request), Request: q, Rule: rule, Status: "ready", Stage: "finished", StartedAt: time.Now().UTC().Format(time.RFC3339), FinishedAt: time.Now().UTC().Format(time.RFC3339), Members: len(members), Done: len(rows), Rows: rows, Complete: complete, MembershipSource: wbMembershipSource(program), RankBy: "custom_read_only"}
	for _, row := range rows {
		if wbMatched(row) {
			job.Matched++
		}
	}
	if len(members) == 0 {
		job.Status = "empty"
	} else if !complete {
		job.Status = "partial"
	}
	return job, nil
}
