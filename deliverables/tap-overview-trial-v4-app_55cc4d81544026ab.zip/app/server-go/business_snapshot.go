package main

import (
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"
	"time"
)

type sourceSnapshot struct {
	Source            string          `json:"source"`
	SourceType        string          `json:"source_type,omitempty"`
	ImportedAt        string          `json:"imported_at,omitempty"`
	Coverage          map[string]any  `json:"coverage,omitempty"`
	Completeness      string          `json:"completeness,omitempty"`
	Kind              string          `json:"kind"`
	Grain             string          `json:"grain"`
	Mode              string          `json:"mode"`
	Status            string          `json:"status"`
	ReportID          int             `json:"reportId"`
	DatasetID         int             `json:"datasetId"`
	ContractHash      string          `json:"contractHash"`
	AuthMode          string          `json:"authMode"`
	DataAsOf          string          `json:"dataAsOf,omitempty"`
	DataAsOfCanonical string          `json:"data_as_of,omitempty"`
	QueriedAt         string          `json:"queriedAt"`
	GeneratedAt       string          `json:"generated_at,omitempty"`
	LastSuccessAt     string          `json:"lastSuccessAt"`
	RowCount          int             `json:"rowCount"`
	RowCountCanonical int             `json:"row_count,omitempty"`
	SourceRID         int             `json:"source_rid,omitempty"`
	Complete          bool            `json:"complete"`
	Partial           bool            `json:"partial"`
	Truncated         bool            `json:"truncated"`
	PossiblyTruncated bool            `json:"possiblyTruncated"`
	RequestID         string          `json:"requestId,omitempty"`
	LogID             string          `json:"logId,omitempty"`
	IdentityKey       string          `json:"identityKey,omitempty"`
	RuntimeReady      bool            `json:"runtimeReady"`
	FilterIntegrity   filterIntegrity `json:"filterIntegrity,omitempty"`
	RawSchema         map[string]any  `json:"rawSchema"`
	BusinessPayload   map[string]any  `json:"businessPayload"`
}

func persistProbeSnapshot(probe map[string]any) error {
	source := asString(probe["source"])
	rows, ok := probe["business_rows"].([]map[string]any)
	if source == "" || !ok {
		return fmt.Errorf("probe response missing business rows")
	}
	freeze, _ := probe["contract_freeze"].(map[string]any)
	queriedAt := asString(probe["queriedAt"])
	if queriedAt == "" {
		queriedAt = time.Now().UTC().Format(time.RFC3339)
	}
	rowCount := asInt(probe["rowCount"])
	possiblyTruncated := rowCount >= savedReportHardLimit
	if value, exists := probe["possibly_truncated"].(bool); exists {
		possiblyTruncated = value
	}
	config, err := loadDataSourceConfig()
	if err != nil {
		return err
	}
	sourceConfig, exists := config.Sources[source]
	if !exists {
		return fmt.Errorf("unknown source: %s", source)
	}
	snapshot := sourceSnapshot{
		Source: source, Kind: sourceConfig.Kind, Grain: sourceConfig.Grain,
		Mode: asString(probe["mode"]), Status: "ok",
		ReportID: asInt(probe["report_id"]), DatasetID: asInt(probe["dataset_id"]),
		ContractHash: asString(freeze["contractHash"]), AuthMode: asString(probe["auth_mode"]),
		DataAsOf: deriveDataAsOf(rows), QueriedAt: queriedAt, LastSuccessAt: queriedAt,
		RowCount: rowCount, Complete: !possiblyTruncated, PossiblyTruncated: possiblyTruncated,
		RequestID: asString(probe["requestId"]), LogID: asString(probe["logId"]),
		IdentityKey:     sourceIdentityKey(sourceConfig),
		RuntimeReady:    true,
		RawSchema:       map[string]any{"columns": probe["columns"], "fieldMap": probe["field_map"], "contract": freeze},
		BusinessPayload: buildBusinessPayload(source, rows),
	}
	if integrity, ok := probe["filter_integrity"].(filterIntegrity); ok {
		snapshot.FilterIntegrity = integrity
		if integrity.Status != "verified" {
			return fmt.Errorf("filter_contract_failed: returned IDs do not match requested IDs")
		}
	}
	if sourceConfig.Kind == "detail" {
		required := []string{}
		switch source {
		case "submission_detail":
			required = []string{"create_date", "program_type", "final_result", "ticket_id", "account_id", "advertiser_id"}
		case "client_account_detail":
			required = []string{"p_date", "account_id"}
		}
		if ready, _ := detailReady(rows, required...); len(required) > 0 && !ready {
			snapshot.Complete = false
			snapshot.Status = "partial"
		}
	}
	if snapshot.PossiblyTruncated {
		snapshot.Complete = false
		snapshot.Status = "truncated"
	}
	stateMu.Lock()
	defer stateMu.Unlock()
	path, err := snapshotPath()
	if err != nil {
		return err
	}
	st := snapshotState{Sources: map[string][]map[string]any{}, AggregateSources: map[string][]map[string]any{}, DetailSources: map[string][]map[string]any{}, UpdatedAt: map[string]string{}, Business: map[string]sourceSnapshot{}}
	if raw, readErr := os.ReadFile(path); readErr == nil {
		_ = json.Unmarshal(raw, &st)
	}
	if st.Sources == nil {
		st.Sources = map[string][]map[string]any{}
	}
	if st.AggregateSources == nil {
		st.AggregateSources = map[string][]map[string]any{}
	}
	if st.DetailSources == nil {
		st.DetailSources = map[string][]map[string]any{}
	}
	if st.UpdatedAt == nil {
		st.UpdatedAt = map[string]string{}
	}
	if st.Business == nil {
		st.Business = map[string]sourceSnapshot{}
	}
	if old, exists := st.Business[source]; exists && old.ReportID == snapshot.ReportID && old.Kind != "" && old.ContractHash != "" && snapshot.ContractHash != old.ContractHash {
		return fmt.Errorf("contract_changed: %s", source)
	}
	if sourceConfig.Kind == "detail" {
		st.DetailSources[source] = rows
	} else {
		st.AggregateSources[source] = rows
	}
	st.UpdatedAt[source] = queriedAt
	st.Business[source] = snapshot
	encoded, err := json.MarshalIndent(st, "", "  ")
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err = os.WriteFile(tmp, encoded, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func buildBusinessPayload(source string, rows []map[string]any) map[string]any {
	payload := map[string]any{"rows": rows}
	switch source {
	case "submission":
		byDate, byResult := map[string]float64{}, map[string]float64{}
		seen := map[string]bool{}
		total := 0.0
		for _, row := range rows {
			count := 1.0
			id := strings.TrimSpace(asString(row["ticket_id"]))
			if id != "" {
				if seen[id] {
					continue
				}
				seen[id] = true
			} else if value, ok := number(row["ticket_count"]); ok {
				count = value
			} else {
				continue
			}
			total += count
			if date := asString(row["create_date"]); date != "" {
				byDate[date] += count
			}
			if result := strings.ToUpper(strings.TrimSpace(asString(row["final_result"]))); result != "" {
				byResult[result] += count
			}
		}
		payload["ticketVolumeTotal"] = total
		payload["byDate"] = orderedSeries(byDate, "date")
		payload["byFinalResult"] = orderedSeries(byResult, "final_result")
		payload["approvedTicketCount"] = resultCount(byResult, "APPROVE", "APPROVED", "PASS", "PASSED")
		payload["rejectedTicketCount"] = resultCount(byResult, "REJECT", "REJECTED", "FAIL", "FAILED")
		payload["pendingTicketCount"] = total - payload["approvedTicketCount"].(float64) - payload["rejectedTicketCount"].(float64)
	case "tap_account":
		if distinct := distinctCount(rows, "account_id", nil); distinct > 0 {
			payload["accountCount"] = distinct
		} else if valid, status := validAccountRows(rows); status == "verified" {
			payload["accountCount"] = sumField(valid, "account_count")
		} else {
			payload["accountCount"] = nil
			payload["mappingStatus"] = "mapping_invalid"
		}
	case "revenue":
		payload["revenue"] = sumField(rows, "revenue")
	case "approval":
		payload["approvalRate"], payload["aggregationMethod"] = approvalRate(rows)
	case "client_ccr_nfs_detail", "client_ccr_nfs_detail_rows":
		payload["p0Nfs"] = nullableSumField(rows, "p0_nfs")
		payload["p0Ccr"] = ratioOfSumsScaled(rows, "p0_nfs", "total_show_count", 1000000)
		payload["ccrUnit"] = "per_million_impressions"
		payload["nfsStatus"] = func() string {
			if payload["p0Nfs"] == nil {
				return "no_data"
			}
			return "ready"
		}()
	case "p0_risk":
		p0 := ratioOfSums(rows, "p0_ccr_num", "ccr_den")
		p1 := ratioOfSums(rows, "p1_ccr_num", "ccr_den")
		payload["p0Ccr"] = p0
		payload["p1Ccr"] = p1
		payload["p0Nfs"] = nil
		payload["p1Nfs"] = nil
		payload["nfsStatus"] = "pending_contract"
	}
	return payload
}

func deriveDataAsOf(rows []map[string]any) string {
	latest := ""
	for _, row := range rows {
		for _, key := range []string{"p_date", "create_date", "date"} {
			if value := asString(row[key]); value > latest {
				latest = value
			}
		}
	}
	return latest
}

func orderedSeries(groups map[string]float64, key string) []map[string]any {
	keys := make([]string, 0, len(groups))
	for value := range groups {
		keys = append(keys, value)
	}
	sort.Strings(keys)
	out := make([]map[string]any, 0, len(keys))
	for _, value := range keys {
		out = append(out, map[string]any{key: value, "count": groups[value]})
	}
	return out
}

func resultCount(groups map[string]float64, names ...string) float64 {
	total := 0.0
	for _, name := range names {
		total += groups[name]
	}
	return total
}

func sumField(rows []map[string]any, key string) float64 {
	total := 0.0
	for _, row := range rows {
		if value, ok := number(row[key]); ok {
			total += value
		}
	}
	return total
}

func nullableSumField(rows []map[string]any, key string) any {
	total := 0.0
	found := false
	for _, row := range rows {
		if value, ok := number(row[key]); ok {
			total += value
			found = true
		}
	}
	if !found {
		return nil
	}
	return total
}

func ratioOfSumsScaled(rows []map[string]any, numerator, denominator string, scale float64) any {
	value := ratioOfSums(rows, numerator, denominator)
	if value == nil {
		return nil
	}
	return value.(float64) * scale
}

func approvalRate(rows []map[string]any) (any, string) {
	approved, total := 0.0, 0.0
	for _, row := range rows {
		a, aok := number(row["approval_num"])
		t, tok := number(row["approval_den"])
		if aok && tok {
			approved += a
			total += t
		}
	}
	if total > 0 {
		return approved / total, "ratio_of_sums"
	}
	return nil, "not_ready"
}

func asInt(value any) int {
	if n, ok := number(value); ok {
		return int(n)
	}
	return 0
}

func latestNumericValue(rows []map[string]any, key string) any {
	latestDate := ""
	var latest any
	for _, row := range rows {
		value, ok := number(row[key])
		if !ok {
			continue
		}
		date := asString(row["p_date"])
		if latest == nil || date >= latestDate {
			latestDate = date
			latest = value
		}
	}
	return latest
}
