package main

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	etCCRDatasetID = 1139137
	etCCRReportID  = 2898470
)

type etCCRDiagnosticRequest struct {
	AccountID string `json:"account_id"`
	StartDate string `json:"start_date"`
	EndDate   string `json:"end_date"`
}

type etCCRCacheEntry struct {
	Data     map[string]any
	CachedAt time.Time
}

var etCCRCache = struct {
	sync.RWMutex
	Rows map[string]etCCRCacheEntry
}{Rows: map[string]etCCRCacheEntry{}}

func runtimeBusinessRows(rows []map[string]any, fieldMap map[string]string) ([]map[string]any, error) {
	return runtimeBusinessRowsForSource(rows, fieldMap, sourceConfig{Fields: map[string]fieldConfig{"account_id": {DimMetID: "10000000032791"}, "dynamic_p0_ccr": {DimMetID: "10000000032693"}, "p0_nfs": {DimMetID: "10000000032674"}}})
}
func runtimeBusinessRowsForSource(rows []map[string]any, fieldMap map[string]string, source sourceConfig) ([]map[string]any, error) {
	idField := "account_id"
	if source.Fields[idField].DimMetID == "" {
		idField = "advertiser_id"
	}
	accountField, ccrField, nfsField := source.Fields[idField].DimMetID, source.Fields["dynamic_p0_ccr"].DimMetID, source.Fields["p0_nfs"].DimMetID
	if accountField == "" || ccrField == "" || nfsField == "" {
		return nil, fmt.Errorf("ET metric field IDs missing from source configuration")
	}
	columns := map[string]string{}
	for runtimeID, descriptorRaw := range fieldMap {
		var descriptor map[string]any
		if json.Unmarshal([]byte(descriptorRaw), &descriptor) != nil {
			continue
		}
		fieldID := asString(descriptor["datasetfieldid"])
		if fieldID == "" {
			fieldID = asString(descriptor["datasetFieldId"])
		}
		columns[fieldID] = runtimeID
	}
	required := []string{accountField, ccrField, nfsField}
	for _, fieldID := range required {
		if columns[fieldID] == "" {
			return nil, fmt.Errorf("runtime field mapping missing dataset field %s", fieldID)
		}
	}
	out := make([]map[string]any, 0, len(rows))
	for _, raw := range rows {
		rawID := raw[columns[accountField]]
		if _, unsafe := rawID.(float64); unsafe {
			return nil, fmt.Errorf("Account ID arrived as a floating point number; precision cannot be trusted")
		}
		accountID := strings.TrimSpace(asString(rawID))
		if accountID == "" {
			return nil, fmt.Errorf("raw row missing Account ID")
		}
		ccrRaw := strings.TrimSpace(asString(raw[columns[ccrField]]))
		nfsRaw := strings.TrimSpace(asString(raw[columns[nfsField]]))
		parseMetric := func(value string) (any, error) {
			if value == "" || strings.EqualFold(value, "NULL") {
				return nil, nil
			}
			number, e := strconv.ParseFloat(value, 64)
			if e != nil || math.IsNaN(number) || math.IsInf(number, 0) || number < 0 {
				return nil, fmt.Errorf("metric must be a finite nonnegative number or NULL")
			}
			return number, nil
		}
		ccr, err := parseMetric(ccrRaw)
		if err != nil {
			return nil, fmt.Errorf("invalid CCR value: %w", err)
		}
		nfs, err := parseMetric(nfsRaw)
		if err != nil {
			return nil, fmt.Errorf("invalid NFS value: %w", err)
		}
		out = append(out, map[string]any{
			idField:              accountID,
			"account_id":         accountID,
			"dynamic_p0_ccr":     ccr,
			"dynamic_p0_ccr_raw": ccrRaw,
			"p0_nfs":             nfs,
			"p0_nfs_raw":         nfsRaw,
			"raw_row":            raw,
			"runtime_columns":    columns,
		})
	}
	return out, nil
}

func diagnosticStage(name string, started time.Time, status string, evidence any) map[string]any {
	return map[string]any{
		"name": name, "status": status,
		"started_at":  started.UTC().Format(time.RFC3339Nano),
		"ended_at":    time.Now().UTC().Format(time.RFC3339Nano),
		"duration_ms": time.Since(started).Milliseconds(),
		"evidence":    evidence,
	}
}

func chartHasContract(chart map[string]any, values ...string) map[string]bool {
	raw, _ := json.Marshal(chart)
	text := strings.ToLower(string(raw))
	out := map[string]bool{}
	for _, value := range values {
		out[value] = strings.Contains(text, strings.ToLower(value))
	}
	return out
}

func runCCRDiagnostic(parent context.Context, r *http.Request, input etCCRDiagnosticRequest, sourceKey, idField string) map[string]any {
	result := map[string]any{
		"status": "failed", "dataset_id": etCCRDatasetID, "report_id": etCCRReportID,
		"account_id": strings.TrimSpace(input.AccountID), "start_date": input.StartDate, "end_date": input.EndDate,
		"stages": []map[string]any{}, "row_count": 0,
	}
	stages := result["stages"].([]map[string]any)
	appendStage := func(stage map[string]any) { stages = append(stages, stage); result["stages"] = stages }

	if _, err := time.Parse("2006-01-02", input.StartDate); err != nil {
		result["error"] = "invalid start_date"
		return result
	}
	if _, err := time.Parse("2006-01-02", input.EndDate); err != nil {
		result["error"] = "invalid end_date"
		return result
	}
	if input.StartDate > input.EndDate {
		result["error"] = "start_date must not be after end_date"
		return result
	}

	ctx, cancel := context.WithTimeout(parent, 25*time.Second)
	defer cancel()
	config, err := loadDataSourceConfig()
	if err != nil {
		result["error"] = err.Error()
		return result
	}
	source, ok := config.Sources[sourceKey]
	if !ok {
		result["error"] = sourceKey + " source missing"
		return result
	}
	result["report_id"] = source.RID
	result["dataset_id"] = source.SID
	result["legacy_config"] = map[string]any{"report_id": 2832374, "dataset_id": 1139137, "explanation": "历史客户端 CCR/NFS 明细保存报告配置；ET Current 使用独立数据源，不覆盖历史配置"}

	started := time.Now()
	jwt, identity := resolveProbeByteCloudJWT(ctx, r)
	if jwt == "" {
		appendStage(diagnosticStage("aime_cloud_jwt", started, "failed", identity))
		result["error"] = "AIME Cloud JWT unavailable"
		return result
	}
	appendStage(diagnosticStage("aime_cloud_jwt", started, "passed", identity))

	started = time.Now()
	titanToken, titanStep := exchangeProbeTitan(ctx, jwt)
	appendStage(diagnosticStage("titan_exchange", started, titanStep.Status, titanStep))
	if titanStep.Status != "passed" {
		result["error"] = "Titan token exchange failed"
		return result
	}

	started = time.Now()
	sessionStep := probeTitanSession(ctx, firstNonEmptySourceHost(source), source.AppID, titanToken)
	appendStage(diagnosticStage("aeolus_session", started, sessionStep.Status, sessionStep))
	if sessionStep.Status != "passed" {
		result["error"] = "Aeolus session probe failed"
		return result
	}

	started = time.Now()
	chart, chartStep := probeToSimpleChart(ctx, firstNonEmptySourceHost(source), titanToken, source.RID)
	appendStage(diagnosticStage("chart_definition", started, chartStep.Status, chartStep))
	if chartStep.Status != "passed" {
		result["error"] = "RID 2898470 chart definition unavailable"
		return result
	}
	result["saved_report_filters"] = chart["filters"]
	contract := chartHasContract(chart,
		"10000000032791", "10000003854360", "10000000032693", "10000000032674",
		"Dynamic P0 Content CCR", "P0: Negative Feedback Show", "p_date", "account_id")
	result["field_contract_presence"] = contract
	for _, required := range []string{source.Fields[idField].DimMetID, source.Fields["p_date"].DimMetID, source.Fields["dynamic_p0_ccr"].DimMetID, source.Fields["p0_nfs"].DimMetID} {
		if required == "" {
			result["status"] = "contract_mismatch"
			result["error"] = "ET metric/date field IDs missing"
			return result
		}
		contract[required] = chartHasContract(chart, required)[required]
		if !contract[required] {
			result["status"] = "contract_mismatch"
			result["error"] = fmt.Sprintf("target chart does not contain required field %s", required)
			return result
		}
	}
	result["contract_freeze"] = buildContractFreeze(source.RID, source.SID, chart, chartStep.TestedAt)
	if strings.TrimSpace(input.AccountID) == "" {
		result["status"] = "contract_verified"
		result["message"] = "Chart contract verified; account_id is required for the data query"
		return result
	}

	filtered, pushed := chartWithBusinessFilters(cloneMap(chart), source, filterRequest{StartDate: input.StartDate, EndDate: input.EndDate})
	exact, filterErr := exactIDFilter(source, idField, []string{strings.TrimSpace(input.AccountID)})
	if filterErr != nil {
		result["error"] = filterErr.Error()
		return result
	}
	filters, _ := filtered["filters"].([]any)
	filtered["filters"] = append(filters, exact)
	result["effective_filters"] = filtered["filters"]
	result["pushed_filter_dimensions"] = pushed

	started = time.Now()
	queryStep := probeQueryChart(ctx, firstNonEmptySourceHost(source), titanToken, source.RID, filtered)
	appendStage(diagnosticStage("vqs_query", started, queryStep.Status, queryStep))
	result["columns"] = queryStep.Columns
	result["row_count"] = queryStep.RowsCount
	result["request_id"] = queryStep.RequestID
	result["log_id"] = queryStep.LogID
	if queryStep.Status == "no_fact_row" {
		result["status"] = "no_data"
		result["raw_rows"] = []map[string]any{}
		result["business_rows"] = []map[string]any{}
		return result
	}
	if queryStep.Status != "passed" {
		if ctx.Err() != nil {
			result["status"] = "timeout"
			result["error"] = "Aeolus query exceeded 25 seconds"
		} else {
			result["error"] = queryStep.ErrorMessage
		}
		return result
	}

	rows, mappingErr := runtimeBusinessRowsForSource(queryStep.Rows, queryStep.FieldMap, source)
	if mappingErr != nil {
		result["status"] = "field_mapping_failed"
		result["error"] = mappingErr.Error()
		result["raw_rows"] = queryStep.Rows
		result["runtime_field_map"] = queryStep.FieldMap
		return result
	}
	integrity := verifyReturnedIDs(source, idField, []string{strings.TrimSpace(input.AccountID)}, rows)
	result["filter_integrity"] = integrity
	if integrity.Status != "verified" {
		result["status"] = "filter_contract_failed"
		result["error"] = "returned rows do not prove the requested Account ID filter"
		return result
	}
	result["raw_rows"] = queryStep.Rows
	result["business_rows"] = rows
	result["row_count_after_validation"] = len(rows)
	result["status"] = "passed"
	return result
}

func queryCurrent(ctx context.Context, r *http.Request, input etCCRDiagnosticRequest, sourceKey, idField string) (map[string]any, int) {
	accountID := strings.TrimSpace(input.AccountID)
	if !decimalID.MatchString(accountID) {
		return map[string]any{"status": "invalid_request", "error": "account_id must be a 16–20 digit string"}, http.StatusBadRequest
	}

	sourceCfg, cfgErr := loadDataSourceConfig()
	if cfgErr != nil {
		return map[string]any{"status": "configuration_error", "error": cfgErr.Error()}, http.StatusServiceUnavailable
	}
	source := sourceCfg.Sources[sourceKey]
	fingerprint, _ := json.Marshal(source)
	principal := sha256.Sum256([]byte(requestUsername(r) + "|" + extractJWT(r, false)))
	cacheKey := fmt.Sprintf("%x|%x|%s|%s|%s", principal, sha256.Sum256(fingerprint), accountID, input.StartDate, input.EndDate)
	etCCRCache.RLock()
	cached, ok := etCCRCache.Rows[cacheKey]
	etCCRCache.RUnlock()
	if ok && time.Since(cached.CachedAt) < 5*time.Minute {
		copy := cloneMap(cached.Data)
		copy["cached"] = true
		copy["cached_at"] = cached.CachedAt.UTC().Format(time.RFC3339)
		return copy, http.StatusOK
	}

	started := time.Now()
	diagnostic := runCCRDiagnostic(ctx, r, input, sourceKey, idField)
	status := asString(diagnostic["status"])
	if status == "no_data" {
		return map[string]any{
			"status": "no_data", "account_id": accountID,
			"start_date": input.StartDate, "end_date": input.EndDate,
			"data_source":       map[string]any{"app_id": source.AppID, "sid": source.SID, "rid": source.RID},
			"query_duration_ms": time.Since(started).Milliseconds(),
			"last_queried_at":   time.Now().UTC().Format(time.RFC3339), "cached": false,
			"message": "该 Account ID 在所选日期范围内没有返回事实行",
		}, http.StatusOK
	}
	if status != "passed" {
		httpStatus := http.StatusBadGateway
		if status == "timeout" {
			httpStatus = http.StatusGatewayTimeout
		}
		if status == "contract_verified" || status == "invalid_request" {
			httpStatus = http.StatusBadRequest
		}
		return map[string]any{
			"status":               status,
			"account_id":           accountID,
			"start_date":           input.StartDate,
			"end_date":             input.EndDate,
			"error":                diagnostic["error"],
			"saved_report_filters": diagnostic["saved_report_filters"],
			"raw_rows":             diagnostic["raw_rows"],
			"query_duration_ms":    time.Since(started).Milliseconds(),
			"last_queried_at":      time.Now().UTC().Format(time.RFC3339),
		}, httpStatus

	}
	rows, _ := diagnostic["business_rows"].([]map[string]any)
	if len(rows) == 0 {
		return map[string]any{
			"status": "no_data", "account_id": accountID,
			"start_date": input.StartDate, "end_date": input.EndDate,
			"data_source":       map[string]any{"app_id": source.AppID, "sid": source.SID, "rid": source.RID},
			"query_duration_ms": time.Since(started).Milliseconds(),
			"last_queried_at":   time.Now().UTC().Format(time.RFC3339), "cached": false,
		}, http.StatusOK
	}
	if len(rows) != 1 {
		return map[string]any{"status": "aggregation_contract_failed", "error": "ET query must return exactly one aggregate row per account/window; multiple rows cannot be averaged or added"}, http.StatusBadGateway
	}
	row := rows[0]
	data := map[string]any{
		"status":             "success",
		idField:              asString(row[idField]),
		"account_id":         asString(row["account_id"]),
		"start_date":         input.StartDate,
		"end_date":           input.EndDate,
		"dynamic_p0_ccr":     row["dynamic_p0_ccr"],
		"dynamic_p0_ccr_raw": row["dynamic_p0_ccr_raw"],
		"p0_nfs":             row["p0_nfs"],
		"p0_nfs_raw":         row["p0_nfs_raw"],
		"data_source":        map[string]any{"app_id": source.AppID, "sid": source.SID, "rid": source.RID},
		"query_duration_ms":  time.Since(started).Milliseconds(),
		"last_queried_at":    time.Now().UTC().Format(time.RFC3339),
		"cached":             false,
		"trace": map[string]any{
			"raw_rows":          diagnostic["raw_rows"],
			"runtime_columns":   row["runtime_columns"],
			"effective_filters": diagnostic["effective_filters"],
			"filter_integrity":  diagnostic["filter_integrity"],
			"request_id":        diagnostic["request_id"],
			"log_id":            diagnostic["log_id"],
		},
	}
	etCCRCache.Lock()
	etCCRCache.Rows[cacheKey] = etCCRCacheEntry{Data: cloneMap(data), CachedAt: time.Now()}
	etCCRCache.Unlock()
	return data, http.StatusOK
}

func queryETCurrent(ctx context.Context, r *http.Request, input etCCRDiagnosticRequest) (map[string]any, int) {
	accountID := strings.TrimSpace(input.AccountID)
	if !decimalID.MatchString(accountID) {
		return map[string]any{"status": "invalid_request", "error": "account_id must be a 16–20 digit string"}, http.StatusBadRequest
	}
	if start, ok := parseDate(input.StartDate); !ok {
		return map[string]any{"status": "invalid_request", "error": "start_date must be YYYY-MM-DD"}, http.StatusBadRequest
	} else if end, endOK := parseDate(input.EndDate); !endOK || end.Before(start) {
		return map[string]any{"status": "invalid_request", "error": "end_date must be YYYY-MM-DD and not before start_date"}, http.StatusBadRequest
	}
	started := time.Now()
	metrics, err := wbQueryETBatch(ctx, r, []string{accountID}, input.StartDate, input.EndDate)
	if err != nil {
		logMsg(fmt.Sprintf("[monitoring-et-current] account_id=%s window=%s..%s failed: %v", accountID, input.StartDate, input.EndDate, err), "plugin")
		return map[string]any{"status": "upstream_error", "error": sanitizeLogText(err.Error()), "account_id": accountID, "start_date": input.StartDate, "end_date": input.EndDate}, http.StatusBadGateway
	}
	metric := metrics[accountID]
	data := map[string]any{"status": metric.Status, "account_id": accountID, "start_date": input.StartDate, "end_date": input.EndDate, "dynamic_p0_ccr": metric.CCR, "p0_nfs": metric.NFS, "revenue": metric.Revenue, "revenue_status": metric.RevenueStatus, "revenue_error": metric.RevenueError, "data_source": metric.Source, "authority_grain": "account_week", "request_id": metric.RequestID, "log_id": metric.LogID, "revenue_request_id": metric.RevenueRequestID, "revenue_log_id": metric.RevenueLogID, "query_duration_ms": time.Since(started).Milliseconds(), "last_queried_at": time.Now().UTC().Format(time.RFC3339), "cached": false}
	logMsg(fmt.Sprintf("[monitoring-et-current] account_id=%s window=%s..%s status=%s request_id=%s log_id=%s revenue_request_id=%s revenue_log_id=%s", accountID, input.StartDate, input.EndDate, metric.Status, metric.RequestID, metric.LogID, metric.RevenueRequestID, metric.RevenueLogID), "plugin")
	return data, http.StatusOK
}

func queryTHTCurrent(ctx context.Context, r *http.Request, input etCCRDiagnosticRequest) (map[string]any, int) {
	return queryCurrent(ctx, r, input, "tht_current_ccr_nfs", "advertiser_id")
}
