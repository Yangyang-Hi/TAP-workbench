package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"
)

// TestP0LiveQuotaDiagnostics is opt-in because it executes the real current-user
// Titan -> Saved Report -> VQS chain. It never logs credentials.
func TestP0LiveQuotaDiagnostics(t *testing.T) {
	if os.Getenv("RUN_LIVE_AEOLUS_P0") != "1" {
		t.Skip("set RUN_LIVE_AEOLUS_P0=1 for real Aeolus verification")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	req := httptest.NewRequest(http.MethodGet, "/api/submissions/quota?start_date=2026-10-01&end_date=2026-10-18", nil)
	req.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	live := quotaSourceResult{Status: "available", SourceStatus: map[string]string{"ET": "available", "THT": "available", "ST": "available"}, Diagnostics: map[string]map[string]any{}, Errors: map[string]string{}}
	for _, tc := range []struct{ name, source string }{{"ET", "et_quota_tickets"}, {"THT", "tht_ticket_details"}} {
		result, err := quotaAeolusRows(ctx, req, tc.source, tc.name, "2026-10-01", "2026-10-18")
		payload := map[string]any{"tier": tc.name, "diagnostic": result.Diagnostic, "rows": len(result.Rows)}
		live.Diagnostics[tc.name] = result.Diagnostic
		if tc.name == "ET" {
			live.ET = result.Rows
		} else {
			live.THT = result.Rows
		}
		if err != nil {
			payload["error"] = err.Error()
		}
		raw, _ := json.Marshal(payload)
		t.Log(string(raw))
		if err != nil {
			t.Errorf("%s live query failed: %v", tc.name, err)
		}
	}
	if t.Failed() {
		return
	}

	// Exercise the same final aggregation used by the API so the live probe
	// verifies both VQS retrieval and the user-visible ticket/customer semantics.
	result := aggregateQuota(quotaBaseline{}, live, "Q4")
	global := result["global"].(map[string]any)
	et := global["et"].(map[string]any)
	tht := global["tht"].(map[string]any)
	etAccounts, thtTickets, advertisers := map[string]bool{}, map[string]bool{}, map[string]bool{}
	for _, row := range live.ET {
		for _, id := range row.AccountIDs {
			if id != "" {
				etAccounts[id] = true
			}
		}
	}
	for _, row := range live.THT {
		if row.TicketID != "" {
			thtTickets[row.TicketID] = true
		}
		for _, advertiser := range row.AdvertiserIDs {
			if advertiser != "" {
				advertisers[advertiser] = true
			}
		}
	}
	if et["used"] != len(etAccounts) {
		t.Fatalf("ET final aggregation mismatch: used=%v accounts=%d", et["used"], len(etAccounts))
	}
	if tht["approved_ticket_count"] != len(thtTickets) || tht["distinct_advertiser_count"] != len(advertisers) {
		t.Fatalf("THT final aggregation mismatch: aggregate=%#v tickets=%d advertisers=%d", tht, len(thtTickets), len(advertisers))
	}
	raw, _ := json.Marshal(map[string]any{"final_global": global, "regions": result["regions"]})
	t.Log(string(raw))
}
