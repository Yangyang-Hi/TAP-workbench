package main

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
)

func cwMap(v any) map[string]any { m, _ := v.(map[string]any); return m }
func cwNum(v any) string {
	if v == nil {
		return "—"
	}
	switch n := v.(type) {
	case float64:
		if n == float64(int64(n)) {
			return strconv.FormatInt(int64(n), 10)
		}
		return strconv.FormatFloat(n, 'f', 1, 64)
	case int:
		return strconv.Itoa(n)
	default:
		return fmt.Sprint(v)
	}
}
func cwRatio(v any) string {
	n, ok := v.(float64)
	if !ok {
		return "—"
	}
	return fmt.Sprintf("%.1f%%", n)
}
func cwQuotaUsed(program string, m map[string]any) any {
	if program == "ET" && m["account_count"] != nil {
		return m["account_count"]
	}
	if program == "ST" && m["brand_count"] != nil {
		return m["brand_count"]
	}
	return m["used"]
}

type cwQuotaRow struct {
	Region, Tier, Unit, Owner, Follow string
	Used, Quota                       any
	Rate                              float64
	Known                             bool
}

func cwQuotaRows(q map[string]any) []cwQuotaRow {
	out := []cwQuotaRow{}
	regions, _ := q["regions"].([]map[string]any)
	for _, r := range regions {
		for _, tier := range []string{"ET", "ST"} {
			m := cwMap(r[strings.ToLower(tier)])
			rate, known := m["ratio"].(float64)
			if m["quota"] == nil && cwQuotaUsed(tier, m) == nil {
				continue
			}
			unit := "Account"
			if tier == "ST" {
				unit = "Brand"
			}
			out = append(out, cwQuotaRow{Region: fmt.Sprint(r["region"]), Tier: tier, Unit: unit, Used: cwQuotaUsed(tier, m), Quota: m["quota"], Rate: rate, Known: known, Owner: fmt.Sprint(r["regional_poc"]), Follow: fmt.Sprint(r["notification_status"])})
		}
	}
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].Rate != out[j].Rate {
			return out[i].Rate > out[j].Rate
		}
		if out[i].Region != out[j].Region {
			return out[i].Region < out[j].Region
		}
		return out[i].Tier < out[j].Tier
	})
	return out
}
func cwQuotaHTML(q map[string]any) string {
	if q == nil || fmt.Sprint(q["status"]) == "unavailable" {
		return "<section><h2>B. Quota 配额治理分析</h2><div class=empty><strong>查询失败 / 数据不可用</strong><p>Quota 服务未返回可核实统计，未以 0 代替。</p></div></section>"
	}
	global := cwMap(q["global"])
	et, st := cwMap(global["et"]), cwMap(global["st"])
	rows := cwQuotaRows(q)
	full, exceeded := 0, 0
	var body strings.Builder
	for _, r := range rows {
		state := "未返回"
		if r.Known {
			switch {
			case r.Rate > 100:
				state = "已超额"
				exceeded++
			case r.Rate == 100:
				state = "已满额"
				full++
			default:
				state = "未满额"
			}
		}
		body.WriteString("<tr><td>" + cwH(r.Region) + "</td><td>" + r.Tier + "</td><td>" + r.Unit + "</td><td>" + cwNum(r.Used) + "</td><td>" + cwNum(r.Quota) + "</td><td>" + cwRatio(func() any {
			if r.Known {
				return r.Rate
			}
			return nil
		}()) + "<small>" + state + "</small></td><td>" + cwH(emptyFallback(r.Owner, "待补负责人")) + "</td></tr>")
	}
	return "<section><h2>B1 配额压力</h2><div class=kpis><div><span>ET Account</span><strong>" + cwNum(cwQuotaUsed("ET", et)) + " / " + cwNum(et["quota"]) + "</strong><small>" + cwRatio(et["ratio"]) + " · 去重 Account</small></div><div><span>ST Brand</span><strong>" + cwNum(cwQuotaUsed("ST", st)) + " / " + cwNum(st["quota"]) + "</strong><small>" + cwRatio(st["ratio"]) + " · 去重 Brand</small></div><div><span>已满额 Region×Tier</span><strong>" + strconv.Itoa(full) + "</strong><small>Rate = 100.0%</small></div><div><span>超额 Region×Tier</span><strong>" + strconv.Itoa(exceeded) + "</strong><small>严格 Rate &gt; 100.0%</small></div></div><p class=note>THT 无 Quota 分母，仅辅助展示真实返回的通过数量；未返回时显示“未返回”，不补 0。</p></section>" +
		"<section><h2>B2 超额区域</h2><div class=scroll><table><thead><tr><th>Region</th><th>Tier</th><th>计数单位</th><th>Used</th><th>Quota</th><th>Rate / 状态</th><th>负责人</th></tr></thead><tbody>" + body.String() + "</tbody></table></div><p class=note>按超额程度降序；100%=已满额，严格 &gt;100%=超额。百分比保留 1 位且可超过 100%。</p></section>" +
		"<section><h2>B3 超额跟进</h2><p>配额状态、治理事件关联、通知和处理状态分别表达；未关联事件不等于未处理，关闭事件也不等于配额已回落。</p><div class=empty><strong>关联状态按服务端可核实记录展示</strong><p>ST 区域合计 817 与既有截图总计 816 存在 1 条差异，保留该来源差异，不擅自修正。无历史序列，因此不绘制趋势。</p></div></section>"
}
func emptyFallback(v, fallback string) string {
	if strings.TrimSpace(v) == "" || v == "<nil>" {
		return fallback
	}
	return v
}
