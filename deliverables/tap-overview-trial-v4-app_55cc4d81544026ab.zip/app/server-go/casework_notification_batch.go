package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
)

// cwNotificationBatchHandler deliberately delegates every item to the same
// preview/send handlers as the single-item UI. It never has a second recipient
// resolver, renderer, validation rule or delivery path.
func cwNotificationBatchHandler(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Mode   string `json:"mode"`
		DryRun bool   `json:"dry_run"`
		Items  []struct {
			AlertID         string `json:"alert_id"`
			RecipientID     string `json:"recipient_id"`
			ExpectedVersion int    `json:"expected_version"`
			PreviewToken    string `json:"preview_token"`
		} `json:"items"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&in) != nil || len(in.Items) == 0 || len(in.Items) > 100 {
		cwWriteError(w, cwErr(400, "items 必须包含 1-100 条通知"))
		return
	}
	if in.Mode != "test" && in.Mode != "formal" {
		cwWriteError(w, cwErr(400, "mode 必须为 test 或 formal"))
		return
	}
	if in.Mode == "formal" && !in.DryRun {
		writeJSON(w, http.StatusForbidden, map[string]any{"error": "formal_batch_disabled", "reason": "正式批量发送默认禁用；请逐条生成正式预览并由有权限用户显式确认"})
		return
	}
	results := make([]any, 0, len(in.Items))
	for _, item := range in.Items {
		if strings.TrimSpace(item.AlertID) == "" {
			results = append(results, map[string]any{"status": 400, "error": "alert_id_required"})
			continue
		}
		var body []byte
		if in.DryRun {
			body, _ = json.Marshal(map[string]any{"mode": in.Mode, "recipient_id": item.RecipientID})
		} else {
			if item.PreviewToken == "" {
				results = append(results, map[string]any{"alert_id": item.AlertID, "status": 400, "error": "preview_token_required"})
				continue
			}
			body, _ = json.Marshal(map[string]any{"mode": in.Mode, "recipient_id": item.RecipientID, "expected_version": item.ExpectedVersion, "preview_token": item.PreviewToken})
		}
		req := httptest.NewRequest(http.MethodPost, "/", bytes.NewReader(body)).WithContext(r.Context())
		req.Header = r.Header.Clone()
		req.SetPathValue("id", item.AlertID)
		recorder := httptest.NewRecorder()
		if in.DryRun {
			cwNotificationPreviewHandler(recorder, req)
		} else {
			cwNotifyHandler(recorder, req)
		}
		var payload any
		if json.Unmarshal(recorder.Body.Bytes(), &payload) != nil {
			payload = map[string]any{"error": "invalid_internal_response"}
		}
		results = append(results, map[string]any{"alert_id": item.AlertID, "status": recorder.Code, "response": payload})
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"dry_run": in.DryRun, "mode": in.Mode, "results": results}})
}
