package main

import (
	"context"
	"errors"
	"fmt"
	"regexp"
	"strings"
	"time"
)

const wbMetricMaxAttempts = 3

var wbMetricRetryBaseDelay = 100 * time.Millisecond

var wbMetricTracePattern = regexp.MustCompile(`(?:^|\s)(audit_id|request_id)=([^\s]*)`)

type wbMetricQueryError struct {
	message   string
	retryable bool
	auditID   string
	requestID string
}

func (e *wbMetricQueryError) Error() string { return e.message }

func wbProbeQueryError(label string, probe map[string]any, detail string) error {
	message := fmt.Sprintf("%s VQS query failed: status=%s audit_id=%s query_history_id=%s query_definition_hash=%s request_id=%s log_id=%s%s", label, asString(probe["status"]), asString(probe["audit_id"]), asString(probe["query_history_id"]), asString(probe["query_definition_hash"]), asString(probe["requestId"]), asString(probe["logId"]), detail)
	retryable := false
	if step, ok := probe["query_result"].(titanProbeStep); ok && !step.ForbiddenDetected {
		switch strings.ToLower(strings.TrimSpace(step.ErrorType)) {
		case "", "network_error", "read_error", "timeout", "temporary_error":
			retryable = true
		case "http_error":
			retryable = step.HTTPStatus == 408 || step.HTTPStatus == 429 || step.HTTPStatus >= 500
		case "vqs_business_error":
			code := strings.ToLower(strings.TrimSpace(asString(step.GlueCode)))
			retryable = strings.Contains(code, "needtoqueue") || strings.Contains(code, "busy") || strings.Contains(code, "timeout")
		}
	}
	return &wbMetricQueryError{message: message, retryable: retryable, auditID: asString(probe["audit_id"]), requestID: asString(probe["requestId"])}
}

func wbMetricErrorTrace(err error) (retryable bool, auditID, requestID string) {
	var queryErr *wbMetricQueryError
	if errors.As(err, &queryErr) {
		return queryErr.retryable, queryErr.auditID, queryErr.requestID
	}
	if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
		return false, "", ""
	}
	message := strings.ToLower(err.Error())
	permanent := []string{"filter_contract", "filter integrity", "invalid ", "unrequested", "contract failed", "hard limit", "truncat", "forbidden", "unauthorized", "permission", "source_not_configured", "unknown source", "missing_req_json", "schema_mapping"}
	for _, marker := range permanent {
		if strings.Contains(message, marker) {
			return false, traceField(err.Error(), "audit_id"), traceField(err.Error(), "request_id")
		}
	}
	retryableMarkers := []string{"status=failed", "network", "connection reset", "temporar", "timeout", "http 408", "http 429", "http 500", "http 502", "http 503", "http 504", "needtoqueue", "busy"}
	for _, marker := range retryableMarkers {
		if strings.Contains(message, marker) {
			return true, traceField(err.Error(), "audit_id"), traceField(err.Error(), "request_id")
		}
	}
	return false, traceField(err.Error(), "audit_id"), traceField(err.Error(), "request_id")
}

func traceField(message, key string) string {
	for _, match := range wbMetricTracePattern.FindAllStringSubmatch(message, -1) {
		if len(match) == 3 && match[1] == key {
			return match[2]
		}
	}
	return ""
}

func wbRunMetricChunkWithRetry[T any](ctx context.Context, program string, chunk, total int, query func(context.Context) (T, error)) (T, error) {
	var zero T
	for attempt := 1; attempt <= wbMetricMaxAttempts; attempt++ {
		if err := ctx.Err(); err != nil {
			logMsg(fmt.Sprintf("[risk-scan-retry] program=%s chunk=%d/%d attempt=%d audit_id= request_id= error=%s", program, chunk, total, attempt, sanitizeLogText(err.Error())), "plugin")
			return zero, err
		}
		result, err := query(ctx)
		if err == nil {
			logMsg(fmt.Sprintf("[risk-scan-retry] program=%s chunk=%d/%d attempt=%d audit_id= request_id= error=", program, chunk, total, attempt), "plugin")
			return result, nil
		}
		retryable, auditID, requestID := wbMetricErrorTrace(err)
		logMsg(fmt.Sprintf("[risk-scan-retry] program=%s chunk=%d/%d attempt=%d audit_id=%s request_id=%s error=%s", program, chunk, total, attempt, auditID, requestID, sanitizeLogText(err.Error())), "plugin")
		if !retryable || attempt == wbMetricMaxAttempts {
			return zero, err
		}
		delay := wbMetricRetryBaseDelay * time.Duration(1<<(attempt-1))
		timer := time.NewTimer(delay)
		select {
		case <-ctx.Done():
			if !timer.Stop() {
				<-timer.C
			}
			return zero, ctx.Err()
		case <-timer.C:
		}
	}
	return zero, errors.New("metric retry attempts exhausted")
}
