package main

import (
	"context"
	"fmt"
	"net/http"
	"time"
)

const wbSTMetricChunkSize = defaultIDBatchSize

var wbQuerySTBatch = querySTCurrentBatch

// querySTCurrentBatch uses the same Account-grain authority as ET. ST
// membership remains the authoritative ST Sheet snapshot; only verified Account
// IDs from that membership are queried, and no THT advertiser is mapped here.
func querySTCurrentBatch(ctx context.Context, request *http.Request, ids []string, startDate, endDate string) (map[string]wbBatchMetric, error) {
	return queryAccountCurrentBatch(ctx, request, ids, startDate, endDate, "st_current_ccr_nfs", "ST")
}

func wbRunSTBatches(ctx context.Context, request *http.Request, members []wbMember, q wbRequest, rule wbRule) ([]wbRow, int, error) {
	return wbRunSTBatchesWithProgress(ctx, request, members, q, rule, nil)
}

func wbRunSTBatchesWithProgress(ctx context.Context, request *http.Request, members []wbMember, q wbRequest, rule wbRule, onChunkDone func(processed, completedChunks, totalChunks int, rows []wbRow)) ([]wbRow, int, error) {
	ids := make([]string, 0, len(members))
	for _, member := range members {
		ids = append(ids, member.AccountID)
	}
	all := make(map[string]wbBatchMetric, len(ids))
	requestCount := 0
	processed := 0
	checkpointRows := make([]wbRow, 0, len(members))
	chunks := chunkIDs(ids, wbSTMetricChunkSize)
	for index, chunk := range chunks {
		chunkCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
		metrics, err := wbRunMetricChunkWithRetry(chunkCtx, q.Program, index+1, len(chunks), func(attemptCtx context.Context) (map[string]wbBatchMetric, error) {
			return wbQuerySTBatch(attemptCtx, request, chunk, q.Start, q.End)
		})
		cancel()
		requestCount++
		if err != nil {
			return nil, requestCount, fmt.Errorf("ST metric chunk %d/%d failed after at most %d attempts: %w", requestCount, len(chunks), wbMetricMaxAttempts, err)
		}
		for id, metric := range metrics {
			if _, duplicate := all[id]; duplicate {
				return nil, requestCount, fmt.Errorf("ST metric account_id %s appeared in multiple chunks", id)
			}
			all[id] = metric
		}
		chunkMembers := members[processed : processed+len(chunk)]
		chunkRows, rowErr := wbRowsFromETBatch(chunkMembers, metrics, q, rule)
		if rowErr != nil {
			return nil, requestCount, rowErr
		}
		checkpointRows = append(checkpointRows, chunkRows...)
		processed += len(chunk)
		if onChunkDone != nil {
			onChunkDone(processed, requestCount, len(chunks), append([]wbRow(nil), checkpointRows...))
		}
	}
	rows, err := wbRowsFromETBatch(members, all, q, rule)
	return rows, requestCount, err
}
