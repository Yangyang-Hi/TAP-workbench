package main

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/google/uuid"
)

type cloudStore struct {
	baseURL               string
	appID                 string
	apiKey                string
	instanceID            string
	includeInstanceHeader bool
}

type cloudStoreOptions struct {
	// sharedAcrossInstances is reserved for App-owned shared business domains.
	// Authentication still binds every request to DB_APP_ID and DB_API_KEY; it
	// only removes installation-instance partitioning within that same App.
	sharedAcrossInstances bool
}

const cloudDBAPIPrefix = "/api/v2"

func newCloudStore() (*cloudStore, error) {
	return newCloudStoreWithOptions(cloudStoreOptions{})
}

func newSharedCloudStore() (*cloudStore, error) {
	return newCloudStoreWithOptions(cloudStoreOptions{sharedAcrossInstances: true})
}

func newCloudStoreWithOptions(options cloudStoreOptions) (*cloudStore, error) {
	appID := strings.TrimSpace(os.Getenv("DB_APP_ID"))
	apiKey := strings.TrimSpace(os.Getenv("DB_API_KEY"))
	baseURL := strings.TrimSpace(os.Getenv("DB_BASE_URL"))
	if baseURL == "" {
		if os.Getenv("IRIS_RUNTIME_AIME_API_HOST") == "aime.byted.org" {
			baseURL = "https://elfzl04s.sg-fn.bytedance.net"
		} else {
			baseURL = "https://ju82g6bb.fn.bytedance.net"
		}
	}
	if appID == "" || apiKey == "" {
		return nil, errors.New("cloud db credentials missing")
	}
	st := &cloudStore{
		baseURL:               strings.TrimRight(baseURL, "/"),
		appID:                 appID,
		apiKey:                apiKey,
		instanceID:            appInstanceID,
		includeInstanceHeader: !options.sharedAcrossInstances,
	}
	logMsg(fmt.Sprintf("[store] 使用云端 DB (DB_APP_ID=%s...)", appID[:min(8, len(appID))]), "plugin")
	return st, nil
}

func (s *cloudStore) Mode() string { return "cloud" }

// currentUsername returns the authenticated username injected by authMiddleware.
// Cloud DB is shared by all installed user instances of the same App; business
// data that should be private to the current user must write and query an
// owner/username field explicitly instead of relying on local instance isolation.
func currentUsername(ctx context.Context) string {
	user, _ := ctx.Value(ctxKeyUser).(authResult)
	return strings.TrimSpace(user.Username)
}

// scopeToCurrentUser is an opt-in helper for user-private Cloud DB records.
// Use it in handlers or typed stores before Create/Update when the table's
// schema contains an owner_id/user_id field for data isolation. The server
// should overwrite ownership from auth context instead of trusting request body.
func scopeToCurrentUser(ctx context.Context, data map[string]any) map[string]any {
	username := currentUsername(ctx)
	if username == "" {
		return data
	}
	data["ownerId"] = username
	data["owner_id"] = username
	return data
}

// currentUserFilter returns a Cloud DB query filter that handlers can include
// in structured queries for user-private tables.
func currentUserFilter(ctx context.Context, field string) map[string]any {
	if field == "" {
		field = "owner_id"
	}
	return map[string]any{"field": field, "operator": "eq", "value": currentUsername(ctx)}
}

func (s *cloudStore) headers() http.Header {
	h := make(http.Header)
	h.Set("Content-Type", "application/json")
	h.Set("X-App-Id", s.appID)
	h.Set("X-Api-Key", s.apiKey)
	if s.includeInstanceHeader && s.instanceID != "" {
		h.Set("X-App-Instance-Id", s.instanceID)
	}
	return h
}

func (s *cloudStore) doJSON(ctx context.Context, method string, path string, body any) (map[string]any, error) {
	var reqBody io.Reader
	if body != nil {
		payload, err := json.Marshal(body)
		if err != nil {
			return nil, err
		}
		reqBody = bytes.NewReader(payload)
	}
	request, err := http.NewRequestWithContext(ctx, method, s.baseURL+path, reqBody)
	if err != nil {
		return nil, err
	}
	request.Header = s.headers()
	resp, err := httpClient.Do(request)
	if err != nil {
		return nil, err
	}
	data, err := decodeHTTPBody(resp)
	if err != nil {
		return nil, err
	}
	var parsed map[string]any
	if len(data) > 0 {
		if err := json.Unmarshal(data, &parsed); err != nil {
			return nil, err
		}
	} else {
		parsed = map[string]any{}
	}
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("db status=%d body=%s", resp.StatusCode, string(data))
	}
	if code, ok := parsed["code"].(float64); ok && int(code) != 0 && int(code) != 200 {
		return nil, fmt.Errorf("db code=%d body=%s", int(code), string(data))
	}
	return parsed, nil
}

func (s *cloudStore) GetAll(ctx context.Context, collection string) ([]map[string]any, error) {
	return s.Query(ctx, collection, nil)
}

func (s *cloudStore) Query(ctx context.Context, collection string, filters []any) ([]map[string]any, error) {
	if filters == nil {
		filters = []any{}
	}
	query := map[string]any{"limit": 100, "offset": 0, "filters": filters, "sort": []any{}}
	resp, err := s.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+collection+"/query", query)
	if err != nil {
		return nil, err
	}
	data, _ := resp["data"].(map[string]any)
	records, _ := data["records"].([]any)
	items := make([]map[string]any, 0, len(records))
	for _, record := range records {
		if m, ok := toMap(record); ok {
			items = append(items, s.decodeRecord(m))
		}
	}
	return items, nil
}

func (s *cloudStore) GetByID(ctx context.Context, collection string, id string) (map[string]any, error) {
	resp, err := s.doJSON(ctx, http.MethodGet, cloudDBAPIPrefix+"/tables/"+collection+"/records/"+id, nil)
	if err != nil {
		if strings.Contains(err.Error(), "404") {
			return nil, nil
		}
		return nil, err
	}
	if m, ok := toMap(resp["data"]); ok {
		return s.decodeRecord(m), nil
	}
	return nil, nil
}

func (s *cloudStore) Create(ctx context.Context, collection string, data map[string]any) (map[string]any, error) {
	now := time.Now().Format(time.RFC3339)
	if data["id"] == nil || asString(data["id"]) == "" {
		data["id"] = uuid.NewString()
	}
	if data["createdAt"] == nil {
		data["createdAt"] = now
	}
	if data["updatedAt"] == nil {
		data["updatedAt"] = now
	}
	requestData, err := envelopeToCloudFields(mapToEnvelope(data))
	if err != nil {
		return nil, err
	}
	resp, err := s.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+collection+"/records", requestData)
	if err != nil {
		return nil, err
	}
	if m, ok := toMap(resp["data"]); ok {
		return s.decodeRecord(m), nil
	}
	return data, nil
}

func (s *cloudStore) Update(ctx context.Context, collection string, id string, data map[string]any) (map[string]any, error) {
	existing, err := s.GetByID(ctx, collection, id)
	if err != nil {
		return nil, err
	}
	if existing == nil {
		return nil, sql.ErrNoRows
	}
	data["id"] = id
	if data["createdAt"] == nil {
		data["createdAt"] = existing["createdAt"]
	}
	data["updatedAt"] = time.Now().Format(time.RFC3339)
	requestData, err := envelopeToCloudFields(mapToEnvelope(data))
	if err != nil {
		return nil, err
	}
	resp, err := s.doJSON(ctx, http.MethodPut, cloudDBAPIPrefix+"/tables/"+collection+"/records/"+id, requestData)
	if err != nil {
		if strings.Contains(err.Error(), "404") {
			return nil, sql.ErrNoRows
		}
		return nil, err
	}
	if m, ok := toMap(resp["data"]); ok {
		return s.decodeRecord(m), nil
	}
	return data, nil
}

func (s *cloudStore) Delete(ctx context.Context, collection string, id string) error {
	_, err := s.doJSON(ctx, http.MethodDelete, cloudDBAPIPrefix+"/tables/"+collection+"/records/"+id, nil)
	if err != nil && strings.Contains(err.Error(), "404") {
		return sql.ErrNoRows
	}
	return err
}

func (s *cloudStore) decodeRecord(record map[string]any) map[string]any {
	legacyData, _ := toMap(record["data"])
	legacyEnvelope := mapToEnvelope(legacyData)
	envelope := recordEnvelope{
		ID:          asString(record["_id"]),
		Title:       asString(record["title"]),
		Description: asString(record["description"]),
		Status:      asString(record["status"]),
		Category:    asString(record["category"]),
		OwnerID:     asString(record["owner_id"]),
		Priority:    asInt64(record["priority"]),
		Amount:      asString(record["amount"]),
		Active:      asBool(record["active"]),
		DueAt:       asString(record["due_at"]),
		CreatedAt:   asString(record["create_time"]),
		UpdatedAt:   asString(record["update_time"]),
		Metadata:    map[string]any{},
	}
	if metadata, ok := toMap(record["metadata"]); ok {
		envelope.Metadata = metadata
	}
	if _, exists := record["title"]; !exists {
		envelope.Title = legacyEnvelope.Title
	}
	if _, exists := record["description"]; !exists {
		envelope.Description = legacyEnvelope.Description
	}
	if _, exists := record["status"]; !exists {
		envelope.Status = legacyEnvelope.Status
	}
	if _, exists := record["category"]; !exists {
		envelope.Category = legacyEnvelope.Category
	}
	if _, exists := record["owner_id"]; !exists {
		envelope.OwnerID = legacyEnvelope.OwnerID
	}
	if _, exists := record["priority"]; !exists {
		envelope.Priority = legacyEnvelope.Priority
	}
	if _, exists := record["amount"]; !exists {
		envelope.Amount = legacyEnvelope.Amount
	}
	if _, exists := record["active"]; !exists {
		envelope.Active = legacyEnvelope.Active
	}
	if _, exists := record["due_at"]; !exists {
		envelope.DueAt = legacyEnvelope.DueAt
	}
	for key, value := range legacyEnvelope.Metadata {
		if _, exists := envelope.Metadata[key]; !exists {
			envelope.Metadata[key] = value
		}
	}
	if legacyEnvelope.CreatedAt != "" {
		envelope.CreatedAt = legacyEnvelope.CreatedAt
	}
	if legacyEnvelope.UpdatedAt != "" {
		envelope.UpdatedAt = legacyEnvelope.UpdatedAt
	}
	data := envelopeToMap(envelope)
	data["_id"] = record["_id"]
	data["create_time"] = record["create_time"]
	data["update_time"] = record["update_time"]
	return data
}

// normalizeCloudDateTime normalizes Cloud DB datetime values to RFC3339.
// Prefer "2026-08-14T22:01:36+08:00"; local inputs like
// "2026-08-14 22:01:36" are accepted for user/API convenience.
func normalizeCloudDateTime(value string) (string, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return "", nil
	}
	for _, layout := range []string{time.RFC3339Nano, time.RFC3339} {
		if parsed, err := time.Parse(layout, value); err == nil {
			return parsed.Format(time.RFC3339), nil
		}
	}
	for _, layout := range []string{
		"2006-01-02T15:04:05",
		"2006-01-02T15:04",
		"2006-01-02 15:04:05",
		"2006-01-02 15:04",
		"2006-01-02",
	} {
		if parsed, err := time.ParseInLocation(layout, value, time.Local); err == nil {
			return parsed.Format(time.RFC3339), nil
		}
	}
	return "", fmt.Errorf("invalid datetime %q: use RFC3339 or local format like 2006-01-02 15:04:05", value)
}

func envelopeToCloudFields(record recordEnvelope) (map[string]any, error) {
	dueAt, err := normalizeCloudDateTime(record.DueAt)
	if err != nil {
		return nil, err
	}
	return map[string]any{
		"title":       record.Title,
		"description": record.Description,
		"status":      record.Status,
		"category":    record.Category,
		"owner_id":    record.OwnerID,
		"priority":    record.Priority,
		"amount":      record.Amount,
		"active":      record.Active,
		"due_at":      dueAt,
		"metadata":    record.Metadata,
	}, nil
}

func toMap(v any) (map[string]any, bool) {
	switch val := v.(type) {
	case map[string]any:
		return val, true
	default:
		payload, err := json.Marshal(v)
		if err != nil {
			return nil, false
		}
		var m map[string]any
		if err := json.Unmarshal(payload, &m); err != nil {
			return nil, false
		}
		return m, true
	}
}
