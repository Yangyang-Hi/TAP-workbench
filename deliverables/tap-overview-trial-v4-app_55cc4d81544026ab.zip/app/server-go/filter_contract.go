package main

import (
	"fmt"
	"sort"
	"strings"
)

const defaultIDBatchSize = 100

// filterIntegrity is persisted with every by-ID snapshot. HTTP success alone is never verified.
type filterIntegrity struct {
	Status      string   `json:"status"`
	Conclusion  string   `json:"conclusion"`
	IDDimension string   `json:"id_dimension"`
	FieldID     string   `json:"filterFieldId"`
	UniqueID    string   `json:"uniqueId"`
	Operator    string   `json:"operator"`
	Requested   []string `json:"requested"`
	Returned    []string `json:"returned"`
	Matched     []string `json:"matched"`
	Unmatched   []string `json:"unmatched"`
	Wrong       []string `json:"wrong"`
	RequestedN  int      `json:"requested_count"`
	ReturnedN   int      `json:"returned_count"`
	MatchedN    int      `json:"matched_count"`
	UnmatchedN  int      `json:"unmatched_count"`
	DuplicateN  int      `json:"duplicate_count"`
	NullN       int      `json:"null_count"`
}

func exactIDFilter(s sourceConfig, dimension string, ids []string) (map[string]any, error) {
	spec, ok := s.Fields[dimension]
	if !ok || strings.TrimSpace(spec.DimMetID) == "" {
		return nil, fmt.Errorf("saved_report_unsupported: missing %s field id", dimension)
	}
	uid := strings.TrimSpace(spec.UniqueID)
	if uid == "" {
		uid = strings.TrimSpace(spec.DimMetID)
	}
	op := strings.ToUpper(strings.TrimSpace(spec.Operator))
	if op == "" {
		if len(ids) == 1 {
			op = "EQ"
		} else {
			op = "IN"
		}
	}
	values := uniqueNonEmpty(ids)
	if len(values) == 0 {
		return nil, fmt.Errorf("payload_incorrect: client ids are required")
	}
	return aeolusFilter(spec.DimMetID, uid, op, values), nil
}

func allowsRepeatedIDRows(s sourceConfig, dimension string) bool {
	// At account×advertiser grain either side of the pair can legitimately repeat:
	// one account can own many advertisers and one advertiser can be associated
	// with more than one account. Callers must still validate the complete pair
	// key before consuming facts; this only relaxes cardinality, never ID scope.
	return (dimension == "account_id" || dimension == "advertiser_id") && strings.Contains(s.Grain, "account_advertiser")
}

func verifyReturnedIDs(s sourceConfig, dimension string, requested []string, rows []map[string]any) filterIntegrity {
	f, err := exactIDFilter(s, dimension, requested)
	out := filterIntegrity{Status: "filter_contract_failed", Conclusion: "payload_incorrect", IDDimension: dimension, Requested: uniqueNonEmpty(requested)}
	out.RequestedN = len(out.Requested)
	if err != nil {
		if strings.Contains(err.Error(), "saved_report_unsupported") {
			out.Conclusion = "saved_report_unsupported"
		}
		return out
	}
	out.FieldID, out.UniqueID, out.Operator = asString(f["datasetFieldId"]), asString(f["uniqueId"]), "IN"
	wanted, seen := map[string]bool{}, map[string]int{}
	for _, id := range out.Requested {
		wanted[id] = true
	}
	for _, row := range rows {
		id := strings.TrimSpace(asString(row[dimension]))
		if id == "" {
			out.NullN++
			continue
		}
		seen[id]++
		if seen[id] > 1 {
			out.DuplicateN++
		}
	}
	for id := range seen {
		out.Returned = append(out.Returned, id)
		if wanted[id] {
			out.Matched = append(out.Matched, id)
		} else {
			out.Wrong = append(out.Wrong, id)
		}
	}
	for _, id := range out.Requested {
		if seen[id] == 0 {
			out.Unmatched = append(out.Unmatched, id)
		}
	}
	sort.Strings(out.Returned)
	sort.Strings(out.Matched)
	sort.Strings(out.Wrong)
	out.ReturnedN, out.MatchedN, out.UnmatchedN = len(out.Returned), len(out.Matched), len(out.Unmatched)
	if len(out.Wrong) == 0 && out.NullN == 0 && out.MatchedN == out.RequestedN {
		out.Status, out.Conclusion = "verified", "verified"
	}
	return out
}

func uniqueNonEmpty(ids []string) []string {
	seen := map[string]bool{}
	out := []string{}
	for _, id := range ids {
		id = strings.TrimSpace(id)
		if id != "" && !seen[id] {
			seen[id] = true
			out = append(out, id)
		}
	}
	return out
}

func chunkIDs(ids []string, size int) [][]string {
	ids = uniqueNonEmpty(ids)
	if size <= 0 {
		size = defaultIDBatchSize
	}
	out := [][]string{}
	for len(ids) > 0 {
		n := size
		if len(ids) < n {
			n = len(ids)
		}
		out = append(out, append([]string(nil), ids[:n]...))
		ids = ids[n:]
	}
	return out
}

func validAccountRows(rows []map[string]any) ([]map[string]any, string) {
	if len(rows) == 0 {
		return rows, "not_ready"
	}
	total := distinctCount(rows, "account_id", nil)
	confirmedCount := total == 0
	valid := make([]map[string]any, 0, len(rows))
	for _, row := range rows {
		// A real account_id is authoritative. Saved-report canonicalization may
		// still materialize account_count as a nil key; that must not invalidate
		// otherwise valid account rows.
		if asString(row["account_id"]) != "" {
			valid = append(valid, row)
			continue
		}
		v, ok := number(row["account_count"])
		if !ok || v < 0 || v != float64(int64(v)) || v > 10_000_000 || (!confirmedCount && int(v) > total) {
			continue
		}
		valid = append(valid, row)
	}
	if len(valid) == 0 {
		return nil, "mapping_invalid"
	}
	return valid, "verified"
}

func businessHealth(readiness map[string]bool, aggregateAvailable bool) (string, float64) {
	ready := 0
	for _, ok := range readiness {
		if ok {
			ready++
		}
	}
	pct := 0.0
	if len(readiness) > 0 {
		pct = float64(ready) / float64(len(readiness)) * 100
	}
	if ready == len(readiness) && ready > 0 {
		return "healthy", pct
	}
	if aggregateAvailable || ready > 0 {
		return "degraded", pct
	}
	return "unavailable", pct
}
