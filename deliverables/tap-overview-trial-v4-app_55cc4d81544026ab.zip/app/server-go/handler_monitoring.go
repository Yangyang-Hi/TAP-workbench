// handler_monitoring.go — monitoring 资源的业务逻辑。
package main

import (
	"encoding/json"
	"net/http"
)

// monitoringEtCurrentCreate 处理 POST /api/monitoring/et/current：查询单个 ET Account 的 Current P0 CCR/NFS 真实业务数据
func monitoringEtCurrentCreate(w http.ResponseWriter, r *http.Request) {
	var input etCCRDiagnosticRequest
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&input); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "invalid JSON body"})
		return
	}
	data, status := queryETCurrent(r.Context(), r, input)
	writeJSON(w, status, map[string]any{"data": data})
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// monitoringRiskScansCreate 处理 POST /api/monitoring/risk-scans：创建 ET/THT 高风险客户异步扫描
func monitoringRiskScansCreate(w http.ResponseWriter, r *http.Request) {
	wbStartHandler(w, r)
}

// monitoringRiskScansByIdGet 处理 GET /api/monitoring/risk-scans/{id}：查询 ET/THT 高风险客户扫描进度与完整结果
func monitoringRiskScansByIdGet(w http.ResponseWriter, r *http.Request) {
	wbGetHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// monitoringRiskScansByIdResumeMissingCreate 处理 POST /api/monitoring/risk-scans/{id}/resume-missing：在既有 ET 扫描任务内按 checkpoint 连续补齐 not_queried/failed Current 指标，不重扫 membership
func monitoringRiskScansByIdResumeMissingCreate(w http.ResponseWriter, r *http.Request) {
	wbResumeMissingHandler(w, r)
}
