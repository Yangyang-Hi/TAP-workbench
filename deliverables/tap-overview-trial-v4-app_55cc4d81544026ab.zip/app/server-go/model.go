package main

import "time"

// Item 是 demo CRUD 示例的数据模型。如果不使用 items demo，可以安全删除本 struct。
// Store 接口使用 map[string]any，不依赖此定义。
type Item struct {
	ID          string `json:"id"`
	Title       string `json:"title"`
	Description string `json:"description"`
	Status      string `json:"status"`
	CreatedAt   string `json:"createdAt"`
	UpdatedAt   string `json:"updatedAt"`
}

type storeConfig struct {
	Mode string `json:"mode"`
}

// recordEnvelope 是模板内置 Store 的 demo 记录形状，不是正式业务 Schema。
// 生成真实应用时必须按业务实体重新设计 Go struct、SQLite 表列或 Cloud DB
// 字段；不要直接沿用这些通用字段，也不要用 metadata 承载核心业务字段。
type recordEnvelope struct {
	ID          string         `json:"id"`
	Title       string         `json:"title,omitempty"`
	Description string         `json:"description,omitempty"`
	Status      string         `json:"status,omitempty"`
	Category    string         `json:"category,omitempty"`
	OwnerID     string         `json:"ownerId,omitempty"`
	Priority    int64          `json:"priority,omitempty"`
	Amount      string         `json:"amount,omitempty"` // Cloud DB decimal 推荐用字符串传输，避免 JS number 精度损失。
	Active      bool           `json:"active,omitempty"`
	DueAt       string         `json:"dueAt,omitempty"` // RFC3339 datetime，对应 Cloud DB 的 datetime 类型。
	Metadata    map[string]any `json:"metadata,omitempty"`
	CreatedAt   string         `json:"createdAt"`
	UpdatedAt   string         `json:"updatedAt"`
}

type authResult struct {
	Username  string `json:"username"`
	Valid     bool   `json:"valid"`
	HasAccess bool   `json:"has_access"`
}

type authCacheEntry struct {
	Data      authResult
	ExpiresAt time.Time
}
