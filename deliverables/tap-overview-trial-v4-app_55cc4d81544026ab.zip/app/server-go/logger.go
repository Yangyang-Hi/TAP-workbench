package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
	"unicode/utf8"
)

// maxLogBytes 单个日志文件软上限；超过后滚动为 <name>.log.1，避免无限增长。
const maxLogBytes int64 = 8 << 20 // 8 MiB

func resolveLogDir() string {
	if runtimeDir := os.Getenv("AIME_PLUGIN_RUNTIME_DIR"); runtimeDir != "" {
		return filepath.Join(runtimeDir, "logs")
	}
	workspace := os.Getenv("AIME_WORKSPACE_PATH")
	pluginDir := os.Getenv("AIME_PLUGIN_DIR")
	if workspace != "" && pluginDir != "" {
		return filepath.Join(workspace, ".aime", "plugin_runtime", filepath.Base(pluginDir), "logs")
	}
	if pluginDir != "" {
		return filepath.Join(pluginDir, "logs")
	}
	cwd, err := os.Getwd()
	if err != nil {
		return "logs"
	}
	return filepath.Join(cwd, "logs")
}

func logFilePath(name string) string {
	if name == "" {
		name = "plugin"
	}
	return filepath.Join(resolveLogDir(), name+".log")
}

// sanitizeLogText 保证日志内容是合法 UTF-8 且不含二进制型控制字符。
// 背景：外部响应被按字节截断会残留半个多字节字符，一旦落盘，整份日志会被
// 文件读取工具判定为二进制而无法查看。
func sanitizeLogText(s string) string {
	if s == "" {
		return s
	}
	if !utf8.ValidString(s) {
		s = strings.ToValidUTF8(s, "")
	}
	return strings.Map(func(r rune) rune {
		switch {
		case r == '\n' || r == '\t':
			return r
		case r < 0x20 || r == 0x7f:
			return -1 // 丢弃 NUL 等控制字符
		default:
			return r
		}
	}, s)
}

// truncateForLog 按 rune 边界截断长文本，绝不切断多字节字符。
// 打印外部 JSON / 响应体时一律用它，不要写 s[:N]。
func truncateForLog(s string, maxBytes int) string {
	if maxBytes <= 0 || len(s) <= maxBytes {
		return s
	}
	cut := maxBytes
	for cut > 0 && !utf8.RuneStart(s[cut]) {
		cut--
	}
	return s[:cut] + "…(truncated)"
}

// rotateLogIfNeeded 超过 maxLogBytes 时滚动为 <name>.log.1（只保留一份历史）。
func rotateLogIfNeeded(path string) {
	fi, err := os.Stat(path)
	if err != nil || fi.Size() < maxLogBytes {
		return
	}
	_ = os.Remove(path + ".1")
	_ = os.Rename(path, path+".1")
}

func logMsg(msg string, name string) {
	path := logFilePath(name)
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return
	}
	rotateLogIfNeeded(path)
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = fmt.Fprintf(f, "[%s] %s\n", time.Now().Format("2006-01-02 15:04:05"), sanitizeLogText(msg))
	_ = f.Sync()
}
