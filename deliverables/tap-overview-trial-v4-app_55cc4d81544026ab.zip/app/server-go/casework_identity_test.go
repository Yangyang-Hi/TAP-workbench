package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

var mappingHeader = []string{"区域", "业务表原始姓名", "已确认企业邮箱", "风神姓名", "匹配状态", "匹配依据/备注", "最近验证时间"}

func withMappingSheet(t *testing.T, revision string, rows ...[]string) {
	t.Helper()
	old := cwFetchMappingSheet
	cwFetchMappingSheet = func(context.Context) (cwSheetSnapshot, error) {
		return cwSheetSnapshot{Revision: revision, Values: append([][]string{mappingHeader}, rows...)}, nil
	}
	t.Cleanup(func() { cwFetchMappingSheet = old })
}

func configureCasework(t *testing.T, update func(*cwConfig)) {
	t.Helper()
	path := filepath.Join(pluginDir, "config", "casework.json")
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var cfg cwConfig
	if err = json.Unmarshal(b, &cfg); err != nil {
		t.Fatal(err)
	}
	update(&cfg)
	b, _ = json.Marshal(cfg)
	if err = os.WriteFile(path, b, 0600); err != nil {
		t.Fatal(err)
	}
}

func TestIdentityMappingExactDuplicateRegionConflictAndSafetyStates(t *testing.T) {
	cwFixture(t)
	withMappingSheet(t, "13",
		[]string{"APAC", "Alice", "alice@example.com", "A.Li", "已确认", "exact", "2026-10-20"},
		[]string{"EMEA", "Same", "same@example.com", "", "已确认", "same email", "2026-10-20"},
		[]string{"APAC", "Same", "same@example.com", "", "已确认", "same email", "2026-10-20"},
		[]string{"APAC", "Regional", "apac@example.com", "", "已确认", "region", "2026-10-20"},
		[]string{"EMEA", "Regional", "emea@example.com", "", "已确认", "region", "2026-10-20"},
		[]string{"APAC", "Conflict", "one@example.com", "", "已确认", "conflict", "2026-10-20"},
		[]string{"APAC", "Conflict", "two@example.com", "", "已确认", "conflict", "2026-10-20"},
		[]string{"APAC", "Pending", "pending@example.com", "", "待确认", "pending", "2026-10-20"},
		[]string{"APAC", "Invalid", "not-an-email", "", "已确认", "invalid", "2026-10-20"},
	)
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	if _, err = cwSyncIdentityMappings(context.Background(), db); err != nil {
		t.Fatal(err)
	}
	checks := []struct{ name, region, status, reason, email string }{
		{" alice ", "APAC", "matched", "confirmed_enabled_exact", "alice@example.com"},
		{" @Alice ", "APAC", "matched", "confirmed_enabled_exact", "alice@example.com"},
		{"@@Alice", "APAC", "pending", "mapping_missing", ""},
		{"Alice extra", "APAC", "pending", "mapping_missing", ""},
		{"A.LI", "APAC", "matched", "confirmed_enabled_exact", "alice@example.com"},
		{"same", "NA", "matched", "confirmed_enabled_exact", "same@example.com"},
		{"regional", "EMEA", "matched", "confirmed_enabled_exact", "emea@example.com"},
		{"regional", "NA", "conflict", "multiple_confirmed_emails_region_not_unique", ""},
		{"conflict", "APAC", "conflict", "multiple_confirmed_emails_region_not_unique", ""},
		{"pending", "APAC", "pending", "mapping_unconfirmed", ""},
		{"invalid", "APAC", "blocked", "invalid_email", "not-an-email"},
		{"unknown", "APAC", "pending", "mapping_missing", ""},
	}
	for _, tc := range checks {
		r, e := cwResolveMapping(db, tc.name, tc.region)
		if e != nil {
			t.Fatal(e)
		}
		if r.Status != tc.status || r.Reason != tc.reason {
			t.Errorf("%s got %s/%s", tc.name, r.Status, r.Reason)
		}
		if tc.email != "" && (r.Mapping == nil || r.Mapping.Email != tc.email) {
			t.Errorf("%s email mismatch", tc.name)
		}
	}
}

func TestIdentityManualDisableSurvivesRefresh(t *testing.T) {
	cwFixture(t)
	row := []string{"APAC", "Alice", "alice@example.com", "", "已确认", "ok", "2026-10-20"}
	withMappingSheet(t, "13", row)
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	if _, err = cwSyncIdentityMappings(context.Background(), db); err != nil {
		t.Fatal(err)
	}
	id := cwSheetMappingID(2)
	if _, err = db.Exec("UPDATE tap_identity_mappings SET enabled=0,manual_disabled=1,override_note='manual' WHERE record_id=?", id); err != nil {
		t.Fatal(err)
	}
	cwFetchMappingSheet = func(context.Context) (cwSheetSnapshot, error) {
		return cwSheetSnapshot{Revision: "14", Values: [][]string{mappingHeader, {"APAC", "Alice", "alice.changed@example.com", "", "已确认", "updated", "2026-10-21"}}}, nil
	}
	if _, err = cwSyncIdentityMappings(context.Background(), db); err != nil {
		t.Fatal(err)
	}
	r, err := cwResolveMapping(db, "Alice", "APAC")
	if err != nil {
		t.Fatal(err)
	}
	if r.Status != "blocked" || r.Reason != "mapping_disabled" {
		t.Fatalf("override lost: %+v", r)
	}
}

func TestNotificationPreviewRefreshFailureAndDryRunReplacement(t *testing.T) {
	a, _ := cwFixture(t)
	oldResolve := cwResolveBotOpenID
	defer func() { cwResolveBotOpenID = oldResolve }()
	cwResolveBotOpenID = func(context.Context, string) (string, string) { return "ou_formal", "resolved" }
	withMappingSheet(t, "13", []string{"APAC", "owner", "owner@example.com", "", "已确认", "ok", "2026-10-20"})
	r := cwTestRequest("owner", `{"recipient_id":"ou_owner"}`)
	r.SetPathValue("id", a.ID)
	w := httptest.NewRecorder()
	cwNotificationPreviewHandler(w, r)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"will_send":false`) || !strings.Contains(w.Body.String(), `"test_recipient_replacement":true`) || !strings.Contains(w.Body.String(), `"id_masked":"***"`) {
		t.Fatal(w.Body.String())
	}
	oldSheet := cwFetchMappingSheet
	cwFetchMappingSheet = func(context.Context) (cwSheetSnapshot, error) { return cwSheetSnapshot{}, errors.New("offline") }
	defer func() { cwFetchMappingSheet = oldSheet }()
	r = cwTestRequest("owner", `{}`)
	r.SetPathValue("id", a.ID)
	w = httptest.NewRecorder()
	cwNotificationPreviewHandler(w, r)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"status":"stale"`) || !strings.Contains(w.Body.String(), `"source_error":"offline"`) || !strings.Contains(w.Body.String(), `"sheet_revision":"13"`) {
		t.Fatal(w.Body.String())
	}
}

func TestOpenIDDiagnosticClassifiesScopeAndMissingOpenID(t *testing.T) {
	cwFixture(t)
	oldBase, oldClient := cwAPIBaseForRequest, cwHTTPClient
	defer func() {
		cwAPIBaseForRequest, cwHTTPClient = oldBase, oldClient
		cwTokenValue = ""
	}()
	response := `{"code":0,"data":{"user_list":[{"email":"owner@example.com"}]}}`
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if strings.Contains(r.URL.Path, "tenant_access_token") {
			fmt.Fprint(w, `{"code":0,"tenant_access_token":"fixture-token","expire":7200}`)
			return
		}
		fmt.Fprint(w, response)
	}))
	defer server.Close()
	cwAPIBaseForRequest = func() string { return server.URL }
	cwHTTPClient = server.Client()
	cwTokenValue = ""

	id, diagnostic := cwResolveOpenIDDiagnostic(context.Background(), "owner@example.com")
	if id != "" || diagnostic.Status != "person_not_visible_or_out_of_scope" || diagnostic.ResponseHasOpenID {
		t.Fatalf("unexpected missing-open-id diagnostic: %+v id=%q", diagnostic, id)
	}

	response = `{"code":99991672,"msg":"missing contact scope"}`
	_, diagnostic = cwResolveOpenIDDiagnostic(context.Background(), "owner@example.com")
	if diagnostic.Status != "scope_missing" || diagnostic.FeishuCode != "99991672" || diagnostic.Stage != "batch_get_id" {
		t.Fatalf("unexpected scope diagnostic: %+v", diagnostic)
	}
}

func queueTestNotice(t *testing.T, a cwCase) {
	t.Helper()
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	fingerprint, _ := cwBotFingerprint()
	_, err = db.Exec(`INSERT INTO tap_outbox(id,case_id,recipient,kind,status,notification_mode,generation,idempotency_key,original_submitter,alert_region,actual_target,created_at,updated_at) VALUES(?,?,?,'send','pending','test',1,?,?,?,?,?,?)`, "notice-"+a.ID, a.ID, "open_id:ou_owner", "idem-"+a.ID, a.Row.Member.Submitter, a.Row.Member.Region, "open_id:ou_owner", cwNow(), cwNow())
	if err != nil {
		t.Fatal(err)
	}
	_, err = db.Exec("UPDATE tap_outbox SET bot_fingerprint=?,mapping_version=?,target_email=?,resolved_open_id=? WHERE case_id=?", fingerprint, cwRowVersion([]string{"APAC", "owner", "owner@example.com", "", "已确认", "ok", "2026-10-20"}), "owner@example.com", "ou_formal", a.ID)
	if err != nil {
		t.Fatal(err)
	}
}

func TestOutboxMappingChangeOpenIDFailureAndFormalGate(t *testing.T) {
	t.Run("test target ignores real submitter mapping and remains allowlisted", func(t *testing.T) {
		a, _ := cwFixture(t)
		queueTestNotice(t, a)
		withMappingSheet(t, "14", []string{"APAC", "owner", "new@example.com", "", "待确认", "changed", "2026-10-20"})
		oldResolver, oldClient := cwResolveBotOpenID, cwHTTPClient
		cwResolveBotOpenID = func(context.Context, string) (string, string) {
			t.Fatal("test outbox must not resolve the real submitter")
			return "", ""
		}
		cwTokenValue = "fixture-token"
		cwTokenApp, _ = func() (string, error) {
			credentials, _, err := loadFeishuCredentials()
			if err != nil {
				return "", err
			}
			return wbKey([]string{credentials.AppID, credentials.AppSecret, cwAPIBase()}), nil
		}()
		cwTokenUntil = time.Now().Add(time.Hour)
		sends := 0
		cwHTTPClient = &http.Client{Transport: cwRoundTripper(func(r *http.Request) (*http.Response, error) {
			sends++
			return cwFakeResponse(`{"code":0,"data":{"message_id":"om_allowlist"}}`), nil
		})}
		defer func() { cwResolveBotOpenID = oldResolver; cwHTTPClient = oldClient; cwTokenValue = "" }()
		cwProcessOutbox()
		db, _ := cwDB()
		defer db.Close()
		var status, messageID, target string
		_ = db.QueryRow("SELECT status,message_id,actual_target FROM tap_outbox WHERE id=?", "notice-"+a.ID).Scan(&status, &messageID, &target)
		if status != "sent" || messageID != "om_allowlist" || target != "open_id:ou_owner" || sends != 1 {
			t.Fatalf("status=%s message=%s target=%s sends=%d", status, messageID, target, sends)
		}
	})
	t.Run("formal gate closed never sends", func(t *testing.T) {
		a, _ := cwFixture(t)
		configureCasework(t, func(c *cwConfig) { c.NotificationMode = "formal"; c.AutoSendEnabled = false })
		queueTestNotice(t, a)
		old := cwHTTPClient
		calls := 0
		cwHTTPClient = &http.Client{Transport: cwRoundTripper(func(*http.Request) (*http.Response, error) { calls++; return nil, errors.New("must not call") })}
		defer func() { cwHTTPClient = old }()
		cwProcessOutbox()
		if calls != 0 {
			t.Fatal("formal gate called Feishu")
		}
		db, _ := cwDB()
		defer db.Close()
		var status string
		_ = db.QueryRow("SELECT status FROM tap_outbox WHERE id=?", "notice-"+a.ID).Scan(&status)
		if status != "blocked" {
			t.Fatal(status)
		}
	})
}

func TestNotifyConfirmationAndGenerationIdempotency(t *testing.T) {
	a, _ := cwFixture(t)
	body := testConfirmedNotificationBody(t, a, "owner", "ou_owner")
	call := func(payload string) *httptest.ResponseRecorder {
		r := cwTestRequest("owner", payload)
		r.SetPathValue("id", a.ID)
		w := httptest.NewRecorder()
		cwNotifyHandler(w, r)
		return w
	}
	if w := call(`{"recipient_id":"ou_owner","expected_version":1,"confirmation_token":"invalid"}`); w.Code != 400 {
		t.Fatal(w.Body.String())
	}
	first := call(body)
	if first.Code != 202 {
		t.Fatal(first.Body.String())
	}
	second := call(body)
	if second.Code != 202 || !strings.Contains(second.Body.String(), `"deduplicated":true`) {
		t.Fatal(second.Body.String())
	}
	db, _ := cwDB()
	defer db.Close()
	var count int
	_ = db.QueryRow("SELECT COUNT(*) FROM tap_outbox WHERE case_id=? AND kind='send'", a.ID).Scan(&count)
	if count != 1 {
		t.Fatal(count)
	}
}

func testConfirmedNotificationBody(t *testing.T, a cwCase, actor, recipient string) string {
	t.Helper()
	r := cwTestRequest(actor, fmt.Sprintf(`{"recipient_id":%q}`, recipient))
	r.SetPathValue("id", a.ID)
	w := httptest.NewRecorder()
	cwNotificationPreviewHandler(w, r)
	if w.Code != 200 {
		t.Fatal("preview:", w.Body.String())
	}
	var preview struct {
		Data struct {
			ConfirmationToken string `json:"confirmation_token"`
		}
	}
	if err := json.Unmarshal(w.Body.Bytes(), &preview); err != nil || preview.Data.ConfirmationToken == "" {
		t.Fatal("preview not ready:", w.Body.String())
	}
	body, _ := json.Marshal(map[string]any{"recipient_id": recipient, "expected_version": a.Version, "confirmation_token": preview.Data.ConfirmationToken})
	return string(body)
}
