package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	credentialsFileName          = "aeolus_credentials.json"
	configFileName               = "aeolus_config.json"
	runtimeStateFileName         = "aeolus_runtime_state.json"
	sourceContractsFileName      = "aeolus_source_contracts.json"
	defaultAeolusHost            = "https://aeolus-sg.bytedance.net"
	defaultAeolusJWTPath         = "/aeolus/api/v3/openapi/jwtToken"
	defaultAeolusCurrentUserPath = "/aeolus/api/v3/open/misc/current_user"
	defaultProxyUserFallback     = "heyangyang.31"
	defaultJWTExpireSeconds      = 3600
	maxJWTExpireSeconds          = 259200
)

type aeolusCredentials struct {
	ClientID     string `json:"client_id"`
	ClientSecret string `json:"client_secret"`
	UpdatedAt    string `json:"updated_at"`
}

type aeolusInstanceConfig struct {
	Host             string `json:"host"`
	QueryPath        string `json:"query_path"`
	ProxyUser        string `json:"proxy_user"`
	JWTExpireSeconds int    `json:"jwt_expire_seconds"`
	UpdatedAt        string `json:"updated_at"`
}

type credentialStatus struct {
	CredentialsStatus string `json:"credentials_status"`
	HasClientID       bool   `json:"has_client_id"`
	HasClientSecret   bool   `json:"has_client_secret"`
	MaskedClientID    string `json:"masked_client_id"`
	Source            string `json:"source"`
	UpdatedAt         string `json:"updated_at"`
	EnvironmentLocked bool   `json:"environment_locked"`
}

var settingsMu sync.RWMutex

func settingsPath(name string) (string, error) {
	root, err := resolveDataDir()
	if err != nil {
		return "", err
	}
	dir := filepath.Join(root, "aeolus_secure")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	if err := os.Chmod(dir, 0o700); err != nil {
		return "", err
	}
	return filepath.Join(dir, name), nil
}

func readPrivateJSON(name string, out any) error {
	path, err := settingsPath(name)
	if err != nil {
		return err
	}
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return nil
	}
	if err != nil {
		return err
	}
	if err := json.Unmarshal(b, out); err != nil {
		return fmt.Errorf("invalid stored configuration")
	}
	return nil
}

func writePrivateJSON(name string, value any) error {
	path, err := settingsPath(name)
	if err != nil {
		return err
	}
	b, err := json.Marshal(value)
	if err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), ".aeolus-config-*")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	defer os.Remove(tmpName)
	if err = tmp.Chmod(0o600); err == nil {
		_, err = tmp.Write(b)
	}
	if err == nil {
		err = tmp.Sync()
	}
	if closeErr := tmp.Close(); err == nil {
		err = closeErr
	}
	if err != nil {
		return err
	}
	if err = os.Rename(tmpName, path); err != nil {
		return err
	}
	return os.Chmod(path, 0o600)
}

func loadStoredCredentials() (aeolusCredentials, error) {
	settingsMu.RLock()
	defer settingsMu.RUnlock()
	var value aeolusCredentials
	err := readPrivateJSON(credentialsFileName, &value)
	return value, err
}

func effectiveCredentials() (aeolusCredentials, string, bool, error) {
	stored, err := loadStoredCredentials()
	if err != nil {
		return aeolusCredentials{}, "not_configured", false, err
	}
	envID := strings.TrimSpace(os.Getenv("AEOLUS_CLIENT_ID"))
	envSecret := strings.TrimSpace(os.Getenv("AEOLUS_CLIENT_SECRET"))
	locked := envID != "" || envSecret != ""
	if envID != "" {
		stored.ClientID = envID
	}
	if envSecret != "" {
		stored.ClientSecret = envSecret
	}
	source := "not_configured"
	if locked {
		source = "environment"
		stored.UpdatedAt = ""
	} else if stored.ClientID != "" || stored.ClientSecret != "" {
		source = "instance_config"
	}
	return stored, source, locked, nil
}

func credentialsStatus() (credentialStatus, error) {
	value, source, locked, err := effectiveCredentials()
	if err != nil {
		return credentialStatus{}, err
	}
	status := "not_configured"
	if strings.TrimSpace(value.ClientID) != "" && strings.TrimSpace(value.ClientSecret) != "" {
		status = "configured"
	}
	return credentialStatus{
		CredentialsStatus: status,
		HasClientID:       value.ClientID != "",
		HasClientSecret:   value.ClientSecret != "",
		MaskedClientID:    maskClientID(value.ClientID),
		Source:            source,
		UpdatedAt:         value.UpdatedAt,
		EnvironmentLocked: locked,
	}, nil
}

func maskClientID(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return ""
	}
	runes := []rune(value)
	if len(runes) <= 2 {
		return "***"
	}
	if len(runes) <= 6 {
		return string(runes[:1]) + "***" + string(runes[len(runes)-1:])
	}
	return string(runes[:2]) + "***" + string(runes[len(runes)-2:])
}

func saveCredentials(clientID, clientSecret string) error {
	if _, _, locked, err := effectiveCredentials(); err != nil {
		return err
	} else if locked {
		return errors.New("environment credentials are locked")
	}
	settingsMu.Lock()
	defer settingsMu.Unlock()
	var value aeolusCredentials
	if err := readPrivateJSON(credentialsFileName, &value); err != nil {
		return err
	}
	if v := strings.TrimSpace(clientID); v != "" {
		value.ClientID = v
	}
	if v := strings.TrimSpace(clientSecret); v != "" {
		value.ClientSecret = v
	}
	if value.ClientID == "" || value.ClientSecret == "" {
		return errors.New("client ID and client secret are required")
	}
	value.UpdatedAt = time.Now().UTC().Format(time.RFC3339)
	if err := writePrivateJSON(credentialsFileName, value); err != nil {
		return err
	}
	resetAeolusTokenCache()
	return nil
}

func clearCredentials() error {
	if _, _, locked, err := effectiveCredentials(); err != nil {
		return err
	} else if locked {
		return errors.New("environment credentials are locked")
	}
	settingsMu.Lock()
	defer settingsMu.Unlock()
	path, err := settingsPath(credentialsFileName)
	if err != nil {
		return err
	}
	if err = os.Remove(path); err != nil && !errors.Is(err, os.ErrNotExist) {
		return err
	}
	resetAeolusTokenCache()
	return nil
}

func loadInstanceConfig() (aeolusInstanceConfig, error) {
	settingsMu.RLock()
	defer settingsMu.RUnlock()
	var value aeolusInstanceConfig
	err := readPrivateJSON(configFileName, &value)
	return value, err
}

func saveInstanceConfig(host, queryPath, proxyUser string, jwtExpireSeconds int) error {
	host, err := validateAeolusHost(host)
	if err != nil {
		return err
	}
	queryPath, err = normalizeQueryPath(queryPath)
	if err != nil {
		return err
	}
	proxyUser, err = validateProxyUser(proxyUser)
	if err != nil {
		return err
	}
	jwtExpireSeconds = normalizeJWTExpireSeconds(jwtExpireSeconds)
	settingsMu.Lock()
	defer settingsMu.Unlock()
	if err := writePrivateJSON(configFileName, aeolusInstanceConfig{
		Host:             host,
		QueryPath:        queryPath,
		ProxyUser:        proxyUser,
		JWTExpireSeconds: jwtExpireSeconds,
		UpdatedAt:        time.Now().UTC().Format(time.RFC3339),
	}); err != nil {
		return err
	}
	resetAeolusTokenCache()
	return nil
}

func validateAeolusHost(value string) (string, error) {
	value = strings.TrimRight(strings.TrimSpace(value), "/")
	u, err := url.Parse(value)
	if err != nil || u.Scheme != "https" || u.Hostname() == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return "", errors.New("host must be an HTTPS origin without path, query, fragment, or credentials")
	}
	return value, nil
}

func normalizeQueryPath(value string) (string, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return "", nil
	}
	if len(value) < 2 || len(value) > 512 || !strings.HasPrefix(value, "/") || strings.HasPrefix(value, "//") || strings.ContainsAny(value, "?#\\") || strings.Contains(value, "..") {
		return "", errors.New("query_path must be a safe absolute path beginning with one slash")
	}
	return value, nil
}

func validateProxyUser(value string) (string, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return "", errors.New("proxy_user is required")
	}
	if len(value) > 128 {
		return "", errors.New("proxy_user is too long")
	}
	for _, r := range value {
		switch {
		case r >= 'a' && r <= 'z':
		case r >= 'A' && r <= 'Z':
		case r >= '0' && r <= '9':
		case r == '.', r == '_', r == '-':
		default:
			return "", errors.New("proxy_user contains unsupported characters")
		}
	}
	return value, nil
}

func parseJWTExpireSeconds(raw string) (int, bool) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return 0, false
	}
	value, err := strconv.Atoi(raw)
	if err != nil {
		return 0, false
	}
	return normalizeJWTExpireSeconds(value), true
}

func normalizeJWTExpireSeconds(value int) int {
	if value <= 0 {
		return defaultJWTExpireSeconds
	}
	if value > maxJWTExpireSeconds {
		return maxJWTExpireSeconds
	}
	return value
}
