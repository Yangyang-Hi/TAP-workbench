package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"
)

const (
	aeolusProxyUserEnv        = "AEOLUS_PROXY_USER"
	aeolusJWTExpireEnv        = "AEOLUS_JWT_EXPIRE_SECONDS"
	aeolusAdminAllowlistEnv   = "TAP_ALERT_CENTER_ADMIN_ALLOWLIST"
	aeolusAuthRefreshAhead    = 5 * time.Minute
	aeolusDiscoveryPendingMsg = "Aeolus metadata/report config 契约尚未在当前项目中落地，已保留自动发现入口，等待官方契约后启用；当前不要求手工录入全部 dimMetId。"
)

type aeolusRuntimeConfig struct {
	Host             string
	HostSource       string
	QueryPath        string
	QueryPathSource  string
	ProxyUser        string
	ProxyUserSource  string
	JWTExpireSeconds int
	JWTExpireSource  string
	JWTPath          string
	CurrentUserPath  string
	ClientID         string
	ClientSecret     string
	Credentials      credentialStatus
}

type aeolusRedirectInfo struct {
	StatusCode int    `json:"status_code"`
	Location   string `json:"location,omitempty"`
}

type aeolusHTTPDiagnostic struct {
	Stage                string               `json:"stage,omitempty"`
	RequestURL           string               `json:"request_url,omitempty"`
	OriginalURL          string               `json:"original_url,omitempty"`
	HTTPStatus           int                  `json:"http_status,omitempty"`
	ResponseContentType  string               `json:"response_content_type,omitempty"`
	FinalURL             string               `json:"final_url,omitempty"`
	RedirectHistory      []aeolusRedirectInfo `json:"redirect_history,omitempty"`
	ResponseBodyPreview  string               `json:"response_body_preview,omitempty"`
	HTMLResponseReceived bool                 `json:"html_response_received,omitempty"`
}

type aeolusProbeError struct {
	HTTPStatus int                   `json:"http_status,omitempty"`
	AeolusCode string                `json:"aeolus_code,omitempty"`
	ErrorType  string                `json:"error_type"`
	Message    string                `json:"message"`
	Diagnostic *aeolusHTTPDiagnostic `json:"diagnostic,omitempty"`
}

type aeolusProbeStepState struct {
	Status              string                `json:"status"`
	RequestURL          string                `json:"request_url,omitempty"`
	HTTPStatus          int                   `json:"http_status,omitempty"`
	AeolusCode          string                `json:"aeolus_code,omitempty"`
	JWTObtained         bool                  `json:"jwt_obtained,omitempty"`
	TokenObtainedAt     string                `json:"token_obtained_at,omitempty"`
	TokenExpireSeconds  int                   `json:"token_expire_seconds,omitempty"`
	ResponseContentType string                `json:"response_content_type,omitempty"`
	ResponseType        string                `json:"response_type,omitempty"`
	TestedAt            string                `json:"tested_at,omitempty"`
	Error               *aeolusProbeError     `json:"error,omitempty"`
	Diagnostic          *aeolusHTTPDiagnostic `json:"diagnostic,omitempty"`
}

type aeolusAuthenticationState struct {
	Status                  string               `json:"status"`
	JWTObtained             bool                 `json:"jwt_obtained"`
	ProxyUser               string               `json:"proxy_user,omitempty"`
	TokenExpireSeconds      int                  `json:"token_expire_seconds,omitempty"`
	CurrentUser             string               `json:"current_user,omitempty"`
	LastTestedAt            string               `json:"last_tested_at,omitempty"`
	LastSucceededAt         string               `json:"last_succeeded_at,omitempty"`
	JWTTokenExchange        aeolusProbeStepState `json:"jwt_token_exchange,omitempty"`
	CurrentUserVerification aeolusProbeStepState `json:"current_user_verification,omitempty"`
	Error                   *aeolusProbeError    `json:"error,omitempty"`
}

type aeolusDataQueryState struct {
	Status       string            `json:"status"`
	LastTestedAt string            `json:"last_tested_at,omitempty"`
	LastSyncedAt string            `json:"last_synced_at,omitempty"`
	Error        *aeolusProbeError `json:"error,omitempty"`
}

type aeolusDiscoveryState struct {
	Status           string `json:"status"`
	MatchedCount     int    `json:"matched_count"`
	AmbiguousCount   int    `json:"ambiguous_count"`
	MissingCount     int    `json:"missing_count"`
	LastAttemptedAt  string `json:"last_attempted_at,omitempty"`
	LastDiscoveredAt string `json:"last_discovered_at,omitempty"`
	Message          string `json:"message,omitempty"`
}

type aeolusRuntimeState struct {
	Authentication aeolusAuthenticationState       `json:"authentication"`
	DataQuery      map[string]aeolusDataQueryState `json:"data_query,omitempty"`
	Discovery      map[string]aeolusDiscoveryState `json:"discovery,omitempty"`
}

type aeolusFieldContract struct {
	FieldName   string `json:"field_name"`
	DisplayName string `json:"display_name,omitempty"`
	DimMetID    string `json:"dim_met_id,omitempty"`
	Type        string `json:"type,omitempty"`
	Aggregation string `json:"aggregation,omitempty"`
	SourceTable string `json:"source_table,omitempty"`
	SourceName  string `json:"source_name,omitempty"`
	Status      string `json:"status,omitempty"`
	Confirmed   bool   `json:"confirmed,omitempty"`
}

type aeolusSourceContract struct {
	Status           string                         `json:"status"`
	Fields           map[string]aeolusFieldContract `json:"fields,omitempty"`
	MatchedCount     int                            `json:"matched_count"`
	AmbiguousCount   int                            `json:"ambiguous_count"`
	MissingCount     int                            `json:"missing_count"`
	LastAttemptedAt  string                         `json:"last_attempted_at,omitempty"`
	LastDiscoveredAt string                         `json:"last_discovered_at,omitempty"`
	Message          string                         `json:"message,omitempty"`
}

type aeolusSourceContracts struct {
	Sources map[string]aeolusSourceContract `json:"sources"`
}

type aeolusTokenCache struct {
	Token             string
	ExpireAt          time.Time
	Host              string
	ProxyUser         string
	JWTExpireSeconds  int
	CredentialsSource string
}

var (
	aeolusTokenMu     sync.Mutex
	aeolusTokenState  aeolusTokenCache
	aeolusLastJWTSync sync.Mutex
	aeolusLastJWTStep aeolusProbeStepState
)

func resetAeolusTokenCache() {
	aeolusTokenMu.Lock()
	defer aeolusTokenMu.Unlock()
	aeolusTokenState = aeolusTokenCache{}
	aeolusLastJWTSync.Lock()
	aeolusLastJWTStep = aeolusProbeStepState{}
	aeolusLastJWTSync.Unlock()
}

func loadRuntimeState() (aeolusRuntimeState, error) {
	settingsMu.RLock()
	defer settingsMu.RUnlock()
	state := aeolusRuntimeState{
		Authentication: aeolusAuthenticationState{Status: "not_tested"},
		DataQuery:      map[string]aeolusDataQueryState{},
		Discovery:      map[string]aeolusDiscoveryState{},
	}
	if err := readPrivateJSON(runtimeStateFileName, &state); err != nil {
		return aeolusRuntimeState{}, err
	}
	if state.Authentication.Status == "" {
		state.Authentication.Status = "not_tested"
	}
	if state.DataQuery == nil {
		state.DataQuery = map[string]aeolusDataQueryState{}
	}
	if state.Discovery == nil {
		state.Discovery = map[string]aeolusDiscoveryState{}
	}
	return state, nil
}

func saveRuntimeState(state aeolusRuntimeState) error {
	settingsMu.Lock()
	defer settingsMu.Unlock()
	if state.Authentication.Status == "" {
		state.Authentication.Status = "not_tested"
	}
	if state.DataQuery == nil {
		state.DataQuery = map[string]aeolusDataQueryState{}
	}
	if state.Discovery == nil {
		state.Discovery = map[string]aeolusDiscoveryState{}
	}
	return writePrivateJSON(runtimeStateFileName, state)
}

func loadSourceContracts() (aeolusSourceContracts, error) {
	settingsMu.RLock()
	defer settingsMu.RUnlock()
	contracts := aeolusSourceContracts{Sources: map[string]aeolusSourceContract{}}
	if err := readPrivateJSON(sourceContractsFileName, &contracts); err != nil {
		return aeolusSourceContracts{}, err
	}
	if contracts.Sources == nil {
		contracts.Sources = map[string]aeolusSourceContract{}
	}
	return contracts, nil
}

func saveSourceContracts(contracts aeolusSourceContracts) error {
	settingsMu.Lock()
	defer settingsMu.Unlock()
	if contracts.Sources == nil {
		contracts.Sources = map[string]aeolusSourceContract{}
	}
	return writePrivateJSON(sourceContractsFileName, contracts)
}

func requestUsername(r *http.Request) string {
	user, _ := r.Context().Value(ctxKeyUser).(authResult)
	return strings.TrimSpace(user.Username)
}

func adminAllowlist() map[string]struct{} {
	raw := strings.TrimSpace(os.Getenv(aeolusAdminAllowlistEnv))
	if raw == "" {
		raw = defaultProxyUserFallback
	}
	items := strings.FieldsFunc(raw, func(r rune) bool {
		switch r {
		case ',', ';', ' ', '\n', '\t':
			return true
		default:
			return false
		}
	})
	allowlist := make(map[string]struct{}, len(items))
	for _, item := range items {
		if v := strings.TrimSpace(item); v != "" {
			allowlist[strings.ToLower(v)] = struct{}{}
		}
	}
	return allowlist
}

func isAdminUsername(username string) bool {
	if strings.TrimSpace(username) == "" {
		return false
	}
	_, ok := adminAllowlist()[strings.ToLower(strings.TrimSpace(username))]
	return ok
}

func requireAdmin(w http.ResponseWriter, r *http.Request) bool {
	if isAdminUsername(requestUsername(r)) {
		return true
	}
	writeJSON(w, http.StatusForbidden, map[string]any{"error": "当前账号无权管理 Aeolus 数据源配置"})
	return false
}

func effectiveRuntimeConfig(c dataSourceConfig, username string) (aeolusRuntimeConfig, error) {
	creds, _, _, err := effectiveCredentials()
	if err != nil {
		return aeolusRuntimeConfig{}, err
	}
	credStatus, err := credentialsStatus()
	if err != nil {
		return aeolusRuntimeConfig{}, err
	}
	override, err := loadInstanceConfig()
	if err != nil {
		return aeolusRuntimeConfig{}, err
	}
	cfg := aeolusRuntimeConfig{
		Host:             strings.TrimRight(strings.TrimSpace(c.Aeolus.Host), "/"),
		HostSource:       "default",
		QueryPath:        strings.TrimSpace(c.Aeolus.QueryPath),
		QueryPathSource:  "not_configured",
		ProxyUser:        strings.TrimSpace(username),
		ProxyUserSource:  "default",
		JWTExpireSeconds: defaultJWTExpireSeconds,
		JWTExpireSource:  "default",
		JWTPath:          strings.TrimSpace(c.Aeolus.Auth.JWTPath),
		CurrentUserPath:  defaultAeolusCurrentUserPath,
		ClientID:         strings.TrimSpace(creds.ClientID),
		ClientSecret:     strings.TrimSpace(creds.ClientSecret),
		Credentials:      credStatus,
	}
	if cfg.Host == "" {
		cfg.Host = defaultAeolusHost
	}
	if cfg.JWTPath == "" {
		cfg.JWTPath = defaultAeolusJWTPath
	}
	if cfg.ProxyUser == "" {
		cfg.ProxyUser = defaultProxyUserFallback
	}
	if strings.TrimSpace(override.Host) != "" {
		cfg.Host = strings.TrimRight(strings.TrimSpace(override.Host), "/")
		cfg.HostSource = "instance_config"
	}
	if strings.TrimSpace(override.QueryPath) != "" {
		cfg.QueryPath = strings.TrimSpace(override.QueryPath)
		cfg.QueryPathSource = "instance_config"
	} else if strings.TrimSpace(c.Aeolus.QueryPath) != "" {
		cfg.QueryPathSource = "package_default"
	}
	if strings.TrimSpace(override.ProxyUser) != "" {
		cfg.ProxyUser = strings.TrimSpace(override.ProxyUser)
		cfg.ProxyUserSource = "instance_config"
	}
	if override.JWTExpireSeconds > 0 {
		cfg.JWTExpireSeconds = normalizeJWTExpireSeconds(override.JWTExpireSeconds)
		cfg.JWTExpireSource = "instance_config"
	}
	if envHost := strings.TrimSpace(os.Getenv(envOr(c.Aeolus.HostEnv, "AEOLUS_HOST"))); envHost != "" {
		cfg.Host = strings.TrimRight(envHost, "/")
		cfg.HostSource = "environment"
	}
	if envProxy := strings.TrimSpace(os.Getenv(aeolusProxyUserEnv)); envProxy != "" {
		cfg.ProxyUser = envProxy
		cfg.ProxyUserSource = "environment"
	}
	if envExpire, ok := parseJWTExpireSeconds(os.Getenv(aeolusJWTExpireEnv)); ok {
		cfg.JWTExpireSeconds = envExpire
		cfg.JWTExpireSource = "environment"
	}
	if cfg.ProxyUser == "" {
		cfg.ProxyUser = defaultProxyUserFallback
	}
	cfg.JWTExpireSeconds = normalizeJWTExpireSeconds(cfg.JWTExpireSeconds)
	return cfg, nil
}

func authenticationSummary(c dataSourceConfig, username string) (map[string]any, error) {
	cfg, err := effectiveRuntimeConfig(c, username)
	if err != nil {
		return nil, err
	}
	state, err := loadRuntimeState()
	if err != nil {
		return nil, err
	}
	authState := state.Authentication
	if authState.JWTObtained && authState.JWTTokenExchange.Status == "" {
		authState.JWTTokenExchange = aeolusProbeStepState{
			Status:              "passed",
			RequestURL:          cfg.Host + cfg.JWTPath,
			HTTPStatus:          http.StatusOK,
			AeolusCode:          "aeolus/ok",
			JWTObtained:         true,
			TokenExpireSeconds:  cfg.JWTExpireSeconds,
			ResponseContentType: "application/json",
			ResponseType:        "json",
			TestedAt:            authState.LastTestedAt,
		}
	}
	if authState.Status == "" {
		authState.Status = "not_tested"
	}
	result := map[string]any{
		"credentials_status":        cfg.Credentials.CredentialsStatus,
		"authentication_status":     authState.Status,
		"data_query_status":         overallDataQueryStatus(c, state),
		"jwt_obtained":              authState.JWTObtained,
		"proxy_user":                cfg.ProxyUser,
		"token_expire_seconds":      cfg.JWTExpireSeconds,
		"last_tested_at":            authState.LastTestedAt,
		"last_succeeded_at":         authState.LastSucceededAt,
		"jwt_token_exchange":        authState.JWTTokenExchange,
		"current_user_verification": authState.CurrentUserVerification,
	}
	if authState.Status == "token_obtained_verification_pending" {
		result["authentication_label"] = "Token Obtained / Secondary Verification Failed"
	}
	if authState.Error != nil {
		result["authentication_error"] = authState.Error
	} else {
		result["authentication_error"] = map[string]any{}
	}
	return result, nil
}

func overallDataQueryStatus(c dataSourceConfig, state aeolusRuntimeState) string {
	anyConfigured := false
	allPassed := true
	anyFailed := false
	for name, source := range c.Sources {
		if !source.Enabled {
			continue
		}
		status := sourceDataQueryStatus(c, name, state)
		switch status {
		case "not_configured":
		case "passed":
			anyConfigured = true
		case "failed":
			anyConfigured = true
			anyFailed = true
			allPassed = false
		case "not_tested":
			anyConfigured = true
			allPassed = false
		default:
			allPassed = false
		}
	}
	if !anyConfigured {
		return "not_configured"
	}
	if anyFailed {
		return "failed"
	}
	if allPassed {
		return "passed"
	}
	return "not_tested"
}

func usesSavedReportQuery(source sourceConfig) bool {
	mode := strings.ToLower(strings.TrimSpace(source.Identity.QueryMode))
	return source.RID > 0 && (mode == "aggregate" || mode == "detail" || mode == "by_id" || mode == "saved_report")
}

func authenticationCanQuery(state aeolusAuthenticationState) bool {
	// current_user is a secondary diagnostic. A successful token exchange is
	// sufficient for Saved Report/Titan VQS and must not be downgraded by a
	// flaky current_user endpoint.
	return state.Status == "passed" || state.Status == "token_obtained_verification_pending" || state.JWTObtained || state.JWTTokenExchange.Status == "passed"
}

func sourceDataQueryStatus(c dataSourceConfig, name string, state aeolusRuntimeState) string {
	source, ok := c.Sources[name]
	if !ok || !source.Enabled {
		return "not_configured"
	}
	runtimeCfg, err := effectiveRuntimeConfig(c, "")
	if err != nil {
		return "not_configured"
	}
	if usesSavedReportQuery(source) {
		if source.RID <= 0 {
			return "not_configured"
		}
	} else {
		if strings.TrimSpace(runtimeCfg.QueryPath) == "" {
			return "not_configured"
		}
		for _, field := range effectiveSourceFields(c, name) {
			if !field.Optional && strings.TrimSpace(field.DimMetID) == "" {
				return "not_configured"
			}
		}
	}
	entry := state.DataQuery[name]
	if entry.Status == "passed" || entry.Status == "failed" {
		return entry.Status
	}
	if !authenticationCanQuery(state.Authentication) {
		return "not_tested"
	}
	return "not_tested"
}

func queryContractView(c dataSourceConfig, name string, state aeolusRuntimeState, contracts aeolusSourceContracts) (string, int, int, int, string, string) {
	source, ok := c.Sources[name]
	if !ok {
		return "not_configured", 0, 0, 0, "", "unknown source"
	}
	entry, hasContract := contracts.Sources[name]
	if hasContract && entry.Status == "contract_pending" {
		discovery := state.Discovery[name]
		attemptedAt := discovery.LastAttemptedAt
		if attemptedAt == "" {
			attemptedAt = entry.LastAttemptedAt
		}
		message := discovery.Message
		if message == "" {
			message = entry.Message
		}
		if message == "" {
			message = aeolusDiscoveryPendingMsg
		}
		return "contract_pending", entry.MatchedCount, entry.AmbiguousCount, entry.MissingCount, attemptedAt, message
	}
	fields := effectiveSourceFields(c, name)
	matched := 0
	for _, field := range fields {
		if strings.TrimSpace(field.DimMetID) != "" {
			matched++
		}
	}
	if len(fields) == 0 || matched == 0 {
		discovery := state.Discovery[name]
		message := discovery.Message
		if message == "" {
			message = aeolusDiscoveryPendingMsg
		}
		return "contract_pending", 0, 0, 0, discovery.LastAttemptedAt, message
	}
	missing := 0
	for _, field := range fields {
		if !field.Optional && strings.TrimSpace(field.DimMetID) == "" {
			missing++
		}
	}
	if missing > 0 {
		if usesSavedReportQuery(source) {
			return "partial", matched, 0, missing, "", "Saved Report 可查询；缺失字段仅降级相关能力。"
		}
		return "not_configured", matched, 0, missing, "", "仍有字段映射缺失，暂不能执行真实数据查询。"
	}
	return "configured", matched, 0, 0, "", source.Label
}

func effectiveSourceFields(c dataSourceConfig, name string) map[string]fieldConfig {
	source, ok := c.Sources[name]
	if !ok {
		return map[string]fieldConfig{}
	}
	base := effectiveFields(c, source)
	fields := make(map[string]fieldConfig, len(base))
	for key, value := range base {
		fields[key] = value
	}
	contracts, err := loadSourceContracts()
	if err != nil {
		return fields
	}
	entry, ok := contracts.Sources[name]
	if !ok {
		return fields
	}
	for fieldName, contract := range entry.Fields {
		spec := fields[fieldName]
		if strings.TrimSpace(contract.DimMetID) != "" {
			spec.DimMetID = strings.TrimSpace(contract.DimMetID)
		}
		if strings.TrimSpace(contract.SourceName) != "" {
			spec.SourceName = strings.TrimSpace(contract.SourceName)
		}
		fields[fieldName] = spec
	}
	return fields
}

func aeolusOverallHealth(credentialsStatus, authenticationStatus, dataQueryStatus string) string {
	switch {
	case authenticationStatus == "passed" && dataQueryStatus != "failed":
		return "healthy"
	case credentialsStatus == "configured" || authenticationStatus == "failed" || dataQueryStatus == "failed":
		return "degraded"
	default:
		return "unavailable"
	}
}

func buildPublicSourcesView(r *http.Request) (map[string]any, error) {
	c, err := loadDataSourceConfig()
	if err != nil {
		return nil, err
	}
	state, err := loadRuntimeState()
	if err != nil {
		return nil, err
	}
	contracts, err := loadSourceContracts()
	if err != nil {
		return nil, err
	}
	authSummary, err := authenticationSummary(c, requestUsername(r))
	if err != nil {
		return nil, err
	}
	rows := make([]map[string]any, 0, len(c.Sources))
	snapshots, _ := loadSnapshots()
	for name, source := range c.Sources {
		queryContractStatus, _, _, _, _, contractMessage := queryContractView(c, name, state, contracts)
		dataQueryStatus := sourceDataQueryStatus(c, name, state)
		snapshot := snapshots.Business[name]
		rows = append(rows, map[string]any{
			"source":                 name,
			"label":                  source.Label,
			"kind":                   source.Kind,
			"grain":                  source.Grain,
			"consumers":              source.Consumers,
			"health_status":          aeolusOverallHealth(authSummary["credentials_status"].(string), authSummary["authentication_status"].(string), dataQueryStatus),
			"authentication_status":  authSummary["authentication_status"].(string),
			"data_query_status":      dataQueryStatus,
			"query_contract_status":  queryContractStatus,
			"last_synced_at":         snapshots.UpdatedAt[name],
			"synced_at":              snapshot.QueriedAt,
			"data_as_of":             snapshot.DataAsOf,
			"error":                  nil,
			"message":                contractMessage,
			"enabled":                source.Enabled,
			"rid":                    source.RID,
			"identity":               source.Identity,
			"query_profile":          source.QueryProfile,
			"live_connection_status": dataQueryStatus,
			"snapshot_status":        map[bool]string{true: snapshots.Business[name].Status, false: "not_available"}[snapshots.Business[name].Source != ""],
			"field_discovery":        fieldDiscoveryStatus(source),
			"detail_probe":           detailProbeStatus(source, snapshots.Business[name]),
			"completeness":           completenessStatus(snapshots.Business[name]),
			"capability":             capabilityFor(name, source, snapshots.Business[name]),
			"row_count":              snapshots.Business[name].RowCount,
			"source_type":            snapshot.SourceType,
			"report_id":              snapshot.ReportID,
			"dataset_id":             snapshot.DatasetID,
			"imported_at":            snapshot.ImportedAt,
			"coverage":               snapshot.Coverage,
			"remaining_windows": func() any {
				if snapshot.SourceType == "file_import" && name == "submission_detail" {
					return 71
				}
				return nil
			}(),
		})
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i]["source"].(string) < rows[j]["source"].(string) })
	return map[string]any{
		"data":                  rows,
		"total":                 len(rows),
		"overall_status":        aeolusOverallHealth(authSummary["credentials_status"].(string), authSummary["authentication_status"].(string), authSummary["data_query_status"].(string)),
		"viewer_role":           map[bool]string{true: "admin", false: "operator"}[isAdminUsername(requestUsername(r))],
		"viewer_can_manage":     isAdminUsername(requestUsername(r)),
		"credentials_status":    authSummary["credentials_status"],
		"authentication_status": authSummary["authentication_status"],
		"data_query_status":     authSummary["data_query_status"],
		"last_tested_at":        authSummary["last_tested_at"],
	}, nil
}

func buildAdminSourceConfigView(r *http.Request) (map[string]any, error) {
	c, err := loadDataSourceConfig()
	if err != nil {
		return nil, err
	}
	cfg, err := effectiveRuntimeConfig(c, requestUsername(r))
	if err != nil {
		return nil, err
	}
	state, err := loadRuntimeState()
	if err != nil {
		return nil, err
	}
	contracts, err := loadSourceContracts()
	if err != nil {
		return nil, err
	}
	snapshots, _ := loadSnapshots()
	authSummary, err := authenticationSummary(c, requestUsername(r))
	if err != nil {
		return nil, err
	}
	rows := make([]map[string]any, 0, len(c.Sources))
	for name, source := range c.Sources {
		queryContractStatus, matchedCount, ambiguousCount, missingCount, lastDiscoveredAt, message := queryContractView(c, name, state, contracts)
		rows = append(rows, map[string]any{
			"source":                name,
			"label":                 source.Label,
			"kind":                  source.Kind,
			"grain":                 source.Grain,
			"consumers":             source.Consumers,
			"enabled":               source.Enabled,
			"app_id":                source.AppID,
			"sid":                   source.SID,
			"rid":                   source.RID,
			"tid":                   source.TID,
			"identity":              source.Identity,
			"query_profile":         source.QueryProfile,
			"requires_probe":        source.RequiresProbe,
			"contract_status":       source.ContractStatus,
			"contract_note":         source.ContractNote,
			"field_discovery":       fieldDiscoveryStatus(source),
			"detail_probe":          detailProbeStatus(source, snapshots.Business[name]),
			"completeness":          completenessStatus(snapshots.Business[name]),
			"data_query_status":     sourceDataQueryStatus(c, name, state),
			"query_contract_status": queryContractStatus,
			"matched_count":         matchedCount,
			"ambiguous_count":       ambiguousCount,
			"missing_count":         missingCount,
			"last_synced_at":        snapshots.UpdatedAt[name],
			"last_discovered_at":    lastDiscoveredAt,
			"message":               message,
		})
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i]["source"].(string) < rows[j]["source"].(string) })
	return map[string]any{
		"host":                      cfg.Host,
		"host_source":               cfg.HostSource,
		"proxy_user":                cfg.ProxyUser,
		"proxy_user_source":         cfg.ProxyUserSource,
		"jwt_expire_seconds":        cfg.JWTExpireSeconds,
		"jwt_expire_source":         cfg.JWTExpireSource,
		"query_path":                cfg.QueryPath,
		"query_path_source":         cfg.QueryPathSource,
		"credentials_status":        authSummary["credentials_status"],
		"authentication_status":     authSummary["authentication_status"],
		"data_query_status":         authSummary["data_query_status"],
		"jwt_obtained":              authSummary["jwt_obtained"],
		"last_tested_at":            authSummary["last_tested_at"],
		"last_succeeded_at":         authSummary["last_succeeded_at"],
		"authentication_label":      authSummary["authentication_label"],
		"jwt_token_exchange":        authSummary["jwt_token_exchange"],
		"current_user_verification": authSummary["current_user_verification"],
		"authentication_error":      authSummary["authentication_error"],
		"sources":                   rows,
	}, nil
}

func saveAuthenticationState(state aeolusAuthenticationState) error {
	runtimeState, err := loadRuntimeState()
	if err != nil {
		return err
	}
	runtimeState.Authentication = state
	return saveRuntimeState(runtimeState)
}

func saveJWTStep(step aeolusProbeStepState) {
	aeolusLastJWTSync.Lock()
	defer aeolusLastJWTSync.Unlock()
	aeolusLastJWTStep = step
}

func lastJWTStep() aeolusProbeStepState {
	aeolusLastJWTSync.Lock()
	defer aeolusLastJWTSync.Unlock()
	return aeolusLastJWTStep
}

func saveDataQueryState(name, status string, errInfo *aeolusProbeError, synced bool) {
	runtimeState, err := loadRuntimeState()
	if err != nil {
		return
	}
	entry := runtimeState.DataQuery[name]
	entry.Status = status
	entry.LastTestedAt = time.Now().UTC().Format(time.RFC3339)
	entry.Error = errInfo
	if synced {
		entry.LastSyncedAt = entry.LastTestedAt
	}
	runtimeState.DataQuery[name] = entry
	_ = saveRuntimeState(runtimeState)
}

func runAuthenticationProbe(ctx context.Context, username string) (map[string]any, error) {
	c, err := loadDataSourceConfig()
	if err != nil {
		return nil, err
	}
	cfg, err := effectiveRuntimeConfig(c, username)
	if err != nil {
		return nil, err
	}
	now := time.Now().UTC().Format(time.RFC3339)
	state := aeolusAuthenticationState{
		Status:                  "failed",
		JWTObtained:             false,
		ProxyUser:               cfg.ProxyUser,
		TokenExpireSeconds:      cfg.JWTExpireSeconds,
		LastTestedAt:            now,
		JWTTokenExchange:        aeolusProbeStepState{Status: "not_tested"},
		CurrentUserVerification: aeolusProbeStepState{Status: "not_tested"},
	}
	saveJWTStep(aeolusProbeStepState{})
	if cfg.Credentials.CredentialsStatus != "configured" {
		missing := []string{}
		if strings.TrimSpace(cfg.ClientID) == "" {
			missing = append(missing, "Client ID")
		}
		if strings.TrimSpace(cfg.ClientSecret) == "" {
			missing = append(missing, "Client Secret")
		}
		if strings.TrimSpace(cfg.ProxyUser) == "" {
			missing = append(missing, "Proxy User")
		}
		if len(missing) == 0 {
			missing = append(missing, "Client ID / Client Secret")
		}
		message := "未发起请求：缺少 " + strings.Join(missing, ", ")
		state.JWTTokenExchange = aeolusProbeStepState{Status: "failed", RequestURL: cfg.Host + cfg.JWTPath, JWTObtained: false, TestedAt: now, Error: &aeolusProbeError{ErrorType: "not_configured", Message: message}}
		state.Error = &aeolusProbeError{ErrorType: "not_configured", Message: message}
		if err := saveAuthenticationState(state); err != nil {
			return nil, err
		}
		return authenticationSummary(c, username)
	}
	token, errInfo := getAeolusJWT(ctx, cfg, true)
	state.JWTTokenExchange = lastJWTStep()
	if errInfo != nil {
		if state.JWTTokenExchange.Status == "" {
			state.JWTTokenExchange = aeolusProbeStepState{Status: "failed", RequestURL: cfg.Host + cfg.JWTPath, HTTPStatus: errInfo.HTTPStatus, AeolusCode: errInfo.AeolusCode, JWTObtained: false, TestedAt: now, Error: errInfo, Diagnostic: errInfo.Diagnostic}
			if errInfo.Diagnostic != nil {
				state.JWTTokenExchange.RequestURL = errInfo.Diagnostic.RequestURL
				state.JWTTokenExchange.HTTPStatus = errInfo.Diagnostic.HTTPStatus
				state.JWTTokenExchange.ResponseContentType = errInfo.Diagnostic.ResponseContentType
			}
		}
		state.JWTTokenExchange.Status = "failed"
		state.JWTTokenExchange.Error = errInfo
		state.Error = errInfo
		if err := saveAuthenticationState(state); err != nil {
			return nil, err
		}
		return authenticationSummary(c, username)
	}
	state.JWTObtained = token != ""
	if state.JWTTokenExchange.Status == "" {
		state.JWTTokenExchange = aeolusProbeStepState{Status: "passed", RequestURL: cfg.Host + cfg.JWTPath, JWTObtained: true, TokenObtainedAt: now, TokenExpireSeconds: cfg.JWTExpireSeconds, TestedAt: now}
	}
	if state.JWTTokenExchange.TestedAt == "" {
		state.JWTTokenExchange.TestedAt = now
	}
	currentUserBody, errInfo := fetchCurrentUserWithRetry(ctx, cfg)
	if errInfo != nil {
		state.Status = "passed"
		state.CurrentUserVerification = aeolusProbeStepState{Status: "warning", RequestURL: cfg.Host + cfg.CurrentUserPath, Error: errInfo, Diagnostic: errInfo.Diagnostic, TestedAt: now}
		if errInfo.Diagnostic != nil {
			state.CurrentUserVerification.HTTPStatus = errInfo.Diagnostic.HTTPStatus
			state.CurrentUserVerification.ResponseContentType = errInfo.Diagnostic.ResponseContentType
			if errInfo.Diagnostic.HTMLResponseReceived {
				state.CurrentUserVerification.ResponseType = "html_response_received"
			}
		}
		state.Error = errInfo
		if err := saveAuthenticationState(state); err != nil {
			return nil, err
		}
		return authenticationSummary(c, username)
	}
	if currentUser := strings.TrimSpace(extractCurrentUserIdentity(currentUserBody)); currentUser != "" {
		state.CurrentUser = currentUser
		if !strings.EqualFold(currentUser, cfg.ProxyUser) {
			state.Error = &aeolusProbeError{
				ErrorType:  "proxy_user_mismatch",
				Message:    sanitizeProbeMessage(fmt.Sprintf("current_user=%s 与配置的 Proxy User 不一致", currentUser), cfg),
				HTTPStatus: http.StatusOK,
			}
			if err := saveAuthenticationState(state); err != nil {
				return nil, err
			}
			return authenticationSummary(c, username)
		}
	}
	state.Status = "passed"
	state.CurrentUserVerification = aeolusProbeStepState{Status: "passed", RequestURL: cfg.Host + cfg.CurrentUserPath, HTTPStatus: http.StatusOK, ResponseType: "json", TestedAt: now}
	state.LastSucceededAt = now
	state.Error = nil
	if err := saveAuthenticationState(state); err != nil {
		return nil, err
	}
	return authenticationSummary(c, username)
}

func saveDiscoveryPlaceholder(name string) (map[string]any, error) {
	contracts, err := loadSourceContracts()
	if err != nil {
		return nil, err
	}
	runtimeState, err := loadRuntimeState()
	if err != nil {
		return nil, err
	}
	now := time.Now().UTC().Format(time.RFC3339)
	contracts.Sources[name] = aeolusSourceContract{
		Status:          "contract_pending",
		MatchedCount:    0,
		AmbiguousCount:  0,
		MissingCount:    0,
		LastAttemptedAt: now,
		Message:         aeolusDiscoveryPendingMsg,
	}
	runtimeState.Discovery[name] = aeolusDiscoveryState{
		Status:          "contract_pending",
		MatchedCount:    0,
		AmbiguousCount:  0,
		MissingCount:    0,
		LastAttemptedAt: now,
		Message:         aeolusDiscoveryPendingMsg,
	}
	if err := saveSourceContracts(contracts); err != nil {
		return nil, err
	}
	if err := saveRuntimeState(runtimeState); err != nil {
		return nil, err
	}
	return map[string]any{
		"source":            name,
		"status":            "contract_pending",
		"matched_count":     0,
		"ambiguous_count":   0,
		"missing_count":     0,
		"last_attempted_at": now,
		"message":           aeolusDiscoveryPendingMsg,
		"discovered_fields": []any{},
	}, nil
}

func getAeolusJWT(ctx context.Context, cfg aeolusRuntimeConfig, forceRefresh bool) (string, *aeolusProbeError) {
	aeolusTokenMu.Lock()
	if !forceRefresh && aeolusTokenState.Token != "" && time.Until(aeolusTokenState.ExpireAt) > aeolusAuthRefreshAhead && aeolusTokenState.Host == cfg.Host && aeolusTokenState.ProxyUser == cfg.ProxyUser && aeolusTokenState.JWTExpireSeconds == cfg.JWTExpireSeconds {
		token := aeolusTokenState.Token
		aeolusTokenMu.Unlock()
		return token, nil
	}
	aeolusTokenMu.Unlock()
	token, errInfo := exchangeAeolusJWT(ctx, cfg)
	if errInfo != nil {
		return "", errInfo
	}
	aeolusTokenMu.Lock()
	aeolusTokenState = aeolusTokenCache{
		Token:             token,
		ExpireAt:          time.Now().Add(time.Duration(cfg.JWTExpireSeconds) * time.Second),
		Host:              cfg.Host,
		ProxyUser:         cfg.ProxyUser,
		JWTExpireSeconds:  cfg.JWTExpireSeconds,
		CredentialsSource: cfg.Credentials.Source,
	}
	aeolusTokenMu.Unlock()
	return token, nil
}

func exchangeAeolusJWT(ctx context.Context, cfg aeolusRuntimeConfig) (string, *aeolusProbeError) {
	body, _ := json.Marshal(map[string]any{
		"metadata": map[string]any{
			"clientId":     cfg.ClientID,
			"clientSecret": cfg.ClientSecret,
			"proxyUser":    cfg.ProxyUser,
			"expire":       cfg.JWTExpireSeconds,
		},
		"userPayload": map[string]any{},
	})
	requestURL := cfg.Host + cfg.JWTPath
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, requestURL, bytes.NewReader(body))
	if err != nil {
		return "", &aeolusProbeError{ErrorType: "network_error", Message: sanitizeProbeMessage(err.Error(), cfg), Diagnostic: &aeolusHTTPDiagnostic{Stage: "jwt_token", RequestURL: requestURL, OriginalURL: requestURL}}
	}
	req.Header.Set("Content-Type", "application/json")
	resp, raw, diag, err := doAeolusProbeRequest(req, "jwt_token")
	if err != nil {
		pe := classifyTransportError(err, cfg)
		pe.Diagnostic = diag
		return "", pe
	}
	defer resp.Body.Close()
	if diag != nil {
		diag.ResponseBodyPreview = sanitizeResponsePreview(raw, cfg)
		diag.HTMLResponseReceived = looksLikeHTML(raw)
	}
	if !isJSONContentType(resp.Header.Get("Content-Type")) {
		step := aeolusProbeStepState{Status: "failed", RequestURL: requestURL, HTTPStatus: resp.StatusCode, ResponseContentType: resp.Header.Get("Content-Type"), ResponseType: map[bool]string{true: "html_response_received", false: "non_json"}[diag != nil && diag.HTMLResponseReceived], Diagnostic: diag}
		saveJWTStep(step)
		return "", &aeolusProbeError{ErrorType: "non_json_response", Message: "upstream returned non-JSON response", HTTPStatus: resp.StatusCode, Diagnostic: diag}
	}
	payload, parseErr := parseAeolusJSON(raw)
	if resp.StatusCode/100 != 2 {
		pe := buildProbeError(resp.StatusCode, payload, parseErr, cfg, "authentication_failed")
		pe.Diagnostic = diag
		return "", pe
	}
	if parseErr != nil {
		return "", &aeolusProbeError{ErrorType: "invalid_response", Message: sanitizeProbeMessage(parseErr.Error(), cfg), HTTPStatus: resp.StatusCode, Diagnostic: diag}
	}
	if code := aeolusCode(payload); code != "aeolus/ok" {
		pe := buildProbeError(resp.StatusCode, payload, nil, cfg, classifyAeolusFailure(resp.StatusCode, code, aeolusMessage(payload)))
		pe.Diagnostic = diag
		return "", pe
	}
	token := nestedString(payload, "data", "jwtToken")
	if strings.TrimSpace(token) == "" {
		return "", &aeolusProbeError{ErrorType: "invalid_response", Message: "响应缺少 data.jwtToken", HTTPStatus: resp.StatusCode, AeolusCode: aeolusCode(payload), Diagnostic: diag}
	}
	saveJWTStep(aeolusProbeStepState{Status: "passed", RequestURL: requestURL, HTTPStatus: resp.StatusCode, AeolusCode: aeolusCode(payload), JWTObtained: true, TokenObtainedAt: time.Now().UTC().Format(time.RFC3339), TokenExpireSeconds: cfg.JWTExpireSeconds, ResponseContentType: resp.Header.Get("Content-Type"), ResponseType: "json", TestedAt: time.Now().UTC().Format(time.RFC3339), Diagnostic: diag})
	return token, nil
}

func doAeolusProbeRequest(req *http.Request, stage string) (*http.Response, []byte, *aeolusHTTPDiagnostic, error) {
	diag := &aeolusHTTPDiagnostic{Stage: stage, RequestURL: req.URL.String(), OriginalURL: req.URL.String()}
	redirects := []aeolusRedirectInfo{}
	client := *httpClient
	client.CheckRedirect = func(next *http.Request, via []*http.Request) error {
		return http.ErrUseLastResponse
	}
	resp, err := client.Do(req)
	if err != nil {
		diag.RedirectHistory = redirects
		return nil, nil, diag, err
	}
	diag.HTTPStatus = resp.StatusCode
	diag.ResponseContentType = resp.Header.Get("Content-Type")
	if resp.Request != nil && resp.Request.URL != nil {
		diag.FinalURL = resp.Request.URL.String()
	}
	if diag.FinalURL == "" {
		diag.FinalURL = req.URL.String()
	}
	if resp.StatusCode >= 300 && resp.StatusCode < 400 {
		redirects = append(redirects, aeolusRedirectInfo{StatusCode: resp.StatusCode, Location: resp.Header.Get("Location")})
	}
	diag.RedirectHistory = redirects
	raw, readErr := io.ReadAll(resp.Body)
	if readErr != nil {
		return resp, nil, diag, readErr
	}
	resp.Body = io.NopCloser(bytes.NewReader(raw))
	return resp, raw, diag, nil
}

func isJSONContentType(contentType string) bool {
	ct := strings.ToLower(strings.TrimSpace(strings.Split(contentType, ";")[0]))
	return ct == "application/json" || strings.HasSuffix(ct, "+json")
}

func looksLikeHTML(raw []byte) bool {
	prefix := strings.TrimSpace(strings.ToLower(string(raw)))
	return strings.HasPrefix(prefix, "<") || strings.HasPrefix(prefix, "<!doctype")
}

func sanitizeResponsePreview(raw []byte, cfg aeolusRuntimeConfig) string {
	text := sanitizeLogText(string(raw))
	text = regexp.MustCompile(`(?i)("jwtToken"\s*:\s*")[^"]*(")`).ReplaceAllString(text, `$1***REDACTED***$2`)
	text = regexp.MustCompile(`(?i)("jwtToken"\s*:\s*")[^,}\s]+`).ReplaceAllString(text, `$1***REDACTED***`)
	text = regexp.MustCompile(`(?i)("clientSecret"\s*:\s*")[^"]*(")`).ReplaceAllString(text, `$1***REDACTED***$2`)
	preview := truncateForLog(text, 300)
	preview = sanitizeProbeMessage(preview, cfg)
	return preview
}

func fetchCurrentUserWithRetry(ctx context.Context, cfg aeolusRuntimeConfig) (map[string]any, *aeolusProbeError) {
	token, errInfo := getAeolusJWT(ctx, cfg, false)
	if errInfo != nil {
		return nil, errInfo
	}
	payload, errInfo := fetchCurrentUserOnce(ctx, cfg, token)
	if errInfo == nil {
		return payload, nil
	}
	if errInfo.HTTPStatus >= 500 && errInfo.HTTPStatus <= 599 {
		return fetchCurrentUserOnce(ctx, cfg, token)
	}
	if errInfo.HTTPStatus != http.StatusUnauthorized && errInfo.HTTPStatus != http.StatusForbidden {
		return nil, errInfo
	}
	token, refreshErr := getAeolusJWT(ctx, cfg, true)
	if refreshErr != nil {
		return nil, refreshErr
	}
	return fetchCurrentUserOnce(ctx, cfg, token)
}

func fetchCurrentUserOnce(ctx context.Context, cfg aeolusRuntimeConfig, token string) (map[string]any, *aeolusProbeError) {
	requestURL := cfg.Host + cfg.CurrentUserPath
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, requestURL, nil)
	if err != nil {
		return nil, &aeolusProbeError{ErrorType: "network_error", Message: sanitizeProbeMessage(err.Error(), cfg), Diagnostic: &aeolusHTTPDiagnostic{Stage: "current_user", RequestURL: requestURL, OriginalURL: requestURL}}
	}
	req.Header.Set("Authorization", "Bearer "+token)
	resp, raw, diag, err := doAeolusProbeRequest(req, "current_user")
	if err != nil {
		pe := classifyTransportError(err, cfg)
		pe.Diagnostic = diag
		return nil, pe
	}
	defer resp.Body.Close()
	if diag != nil {
		diag.ResponseBodyPreview = sanitizeResponsePreview(raw, cfg)
		diag.HTMLResponseReceived = looksLikeHTML(raw)
	}
	if !isJSONContentType(resp.Header.Get("Content-Type")) {
		errorType := "non_json_response"
		message := "upstream returned non-JSON response"
		if resp.StatusCode >= 500 && resp.StatusCode <= 599 {
			errorType = "upstream_server_error"
			message = "upstream server returned 5xx non-JSON response"
		}
		return nil, &aeolusProbeError{ErrorType: errorType, Message: message, HTTPStatus: resp.StatusCode, Diagnostic: diag}
	}
	payload, parseErr := parseAeolusJSON(raw)
	if resp.StatusCode/100 != 2 {
		pe := buildProbeError(resp.StatusCode, payload, parseErr, cfg, classifyAeolusFailure(resp.StatusCode, aeolusCode(payload), aeolusMessage(payload)))
		pe.Diagnostic = diag
		return nil, pe
	}
	if parseErr != nil {
		return nil, &aeolusProbeError{ErrorType: "invalid_response", Message: sanitizeProbeMessage(parseErr.Error(), cfg), HTTPStatus: resp.StatusCode, Diagnostic: diag}
	}
	if code := aeolusCode(payload); code != "" && code != "aeolus/ok" {
		pe := buildProbeError(resp.StatusCode, payload, nil, cfg, classifyAeolusFailure(resp.StatusCode, code, aeolusMessage(payload)))
		pe.Diagnostic = diag
		return nil, pe
	}
	return payload, nil
}

func postAeolusJSONWithRetry(ctx context.Context, cfg aeolusRuntimeConfig, path string, payload map[string]any) ([]byte, *aeolusProbeError) {
	token, errInfo := getAeolusJWT(ctx, cfg, false)
	if errInfo != nil {
		return nil, errInfo
	}
	raw, status, retryable, errInfo := postAeolusJSONOnce(ctx, cfg, path, token, payload)
	if errInfo == nil {
		return raw, nil
	}
	if !retryable || (status != http.StatusUnauthorized && status != http.StatusForbidden) {
		return nil, errInfo
	}
	token, refreshErr := getAeolusJWT(ctx, cfg, true)
	if refreshErr != nil {
		return nil, refreshErr
	}
	raw, _, _, errInfo = postAeolusJSONOnce(ctx, cfg, path, token, payload)
	if errInfo != nil {
		return nil, errInfo
	}
	return raw, nil
}

func postAeolusJSONOnce(ctx context.Context, cfg aeolusRuntimeConfig, path, token string, payload map[string]any) ([]byte, int, bool, *aeolusProbeError) {
	body, _ := json.Marshal(payload)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, cfg.Host+path, bytes.NewReader(body))
	if err != nil {
		return nil, 0, false, &aeolusProbeError{ErrorType: "network_error", Message: sanitizeProbeMessage(err.Error(), cfg)}
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+token)
	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, 0, false, classifyTransportError(err, cfg)
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, resp.StatusCode, false, &aeolusProbeError{ErrorType: "invalid_response", Message: sanitizeProbeMessage(err.Error(), cfg), HTTPStatus: resp.StatusCode}
	}
	if resp.StatusCode/100 != 2 {
		payload, parseErr := parseAeolusJSON(raw)
		return nil, resp.StatusCode, resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden, buildProbeError(resp.StatusCode, payload, parseErr, cfg, classifyAeolusFailure(resp.StatusCode, aeolusCode(payload), aeolusMessage(payload)))
	}
	return raw, resp.StatusCode, false, nil
}

func classifyTransportError(err error, cfg aeolusRuntimeConfig) *aeolusProbeError {
	message := sanitizeProbeMessage(err.Error(), cfg)
	var netErr net.Error
	switch {
	case errors.Is(err, context.DeadlineExceeded), errors.Is(err, context.Canceled):
		return &aeolusProbeError{ErrorType: "timeout", Message: message}
	case errors.As(err, &netErr) && netErr.Timeout():
		return &aeolusProbeError{ErrorType: "timeout", Message: message}
	default:
		return &aeolusProbeError{ErrorType: "network_error", Message: message}
	}
}

func buildProbeError(httpStatus int, payload map[string]any, parseErr error, cfg aeolusRuntimeConfig, fallbackType string) *aeolusProbeError {
	if parseErr != nil {
		return &aeolusProbeError{HTTPStatus: httpStatus, ErrorType: "invalid_response", Message: sanitizeProbeMessage(parseErr.Error(), cfg)}
	}
	code := aeolusCode(payload)
	message := aeolusMessage(payload)
	errType := fallbackType
	if errType == "" {
		errType = classifyAeolusFailure(httpStatus, code, message)
	}
	return &aeolusProbeError{HTTPStatus: httpStatus, AeolusCode: code, ErrorType: errType, Message: sanitizeProbeMessage(message, cfg)}
}

func classifyAeolusFailure(httpStatus int, code, message string) string {
	combined := strings.ToLower(strings.TrimSpace(code + " " + message))
	switch {
	case strings.Contains(combined, "proxy") && strings.Contains(combined, "user"):
		return "proxy_user_mismatch"
	case httpStatus == http.StatusUnauthorized || strings.Contains(combined, "credential") || strings.Contains(combined, "clientsecret") || strings.Contains(combined, "client id") || strings.Contains(combined, "secret") || strings.Contains(combined, "unauthorized"):
		return "invalid_credentials"
	case httpStatus == http.StatusForbidden || strings.Contains(combined, "permission") || strings.Contains(combined, "forbidden") || strings.Contains(combined, "denied"):
		return "permission_denied"
	case code == "aeolus/ok":
		return "invalid_response"
	case code != "":
		return "authentication_failed"
	default:
		return "authentication_failed"
	}
}

func sanitizeProbeMessage(message string, cfg aeolusRuntimeConfig) string {
	message = strings.TrimSpace(message)
	if message == "" {
		return "下游返回空错误信息"
	}
	for _, secret := range []string{cfg.ClientID, cfg.ClientSecret, aeolusTokenState.Token} {
		secret = strings.TrimSpace(secret)
		if secret != "" {
			message = strings.ReplaceAll(message, secret, "[REDACTED]")
		}
	}
	message = strings.ReplaceAll(message, "Bearer ", "Bearer [REDACTED]")
	runes := []rune(message)
	if len(runes) > 240 {
		message = string(runes[:240]) + "…"
	}
	return message
}

func parseAeolusJSON(raw []byte) (map[string]any, error) {
	var payload map[string]any
	if err := json.Unmarshal(raw, &payload); err != nil {
		return nil, err
	}
	return payload, nil
}

func aeolusCode(payload map[string]any) string {
	return strings.TrimSpace(asString(payload["code"]))
}

func aeolusMessage(payload map[string]any) string {
	for _, key := range []string{"message", "msg", "error", "detail"} {
		if value := strings.TrimSpace(asString(payload[key])); value != "" {
			return value
		}
	}
	if data, ok := payload["data"].(map[string]any); ok {
		for _, key := range []string{"message", "msg", "error", "detail"} {
			if value := strings.TrimSpace(asString(data[key])); value != "" {
				return value
			}
		}
	}
	return "下游未提供可解析的错误信息"
}

func extractCurrentUserIdentity(payload map[string]any) string {
	candidates := [][]string{
		{"data", "username"},
		{"data", "user_name"},
		{"data", "proxyUser"},
		{"data", "email_prefix"},
		{"username"},
		{"user_name"},
	}
	for _, path := range candidates {
		value := nestedString(payload, path...)
		if value != "" {
			return value
		}
	}
	return ""
}
