package main

import (
	"reflect"
	"testing"
)

func TestRegionalPOCRegionAliases(t *testing.T) {
	cases := map[string][]string{
		"KR+JP": {"KR", "JP"},
		"MET":   {"MET", "METAP"},
		"EUI":   {"EUI"},
	}
	for input, want := range cases {
		if got := cwRegionalPOCKeys(input); !reflect.DeepEqual(got, want) {
			t.Fatalf("cwRegionalPOCKeys(%q)=%v want %v", input, got, want)
		}
	}
}
