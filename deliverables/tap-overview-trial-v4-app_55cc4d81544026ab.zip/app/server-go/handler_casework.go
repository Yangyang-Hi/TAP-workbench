package main

import "net/http"

// Typed route wrappers; business state is handled by the shared casework service.
func workbenchCaseworkConfigList(w http.ResponseWriter, r *http.Request)      { cwConfigHandler(w, r) }
func workbenchCasesList(w http.ResponseWriter, r *http.Request)               { cwListHandler(w, r) }
func workbenchCasesByIdGet(w http.ResponseWriter, r *http.Request)            { cwGetHandler(w, r) }
func workbenchCasesCreate(w http.ResponseWriter, r *http.Request)             { cwCreateHandler(w, r) }
func workbenchCasesByIdCommandsCreate(w http.ResponseWriter, r *http.Request) { cwActionHandler(w, r) }
func workbenchCasesByIdRechecksCreate(w http.ResponseWriter, r *http.Request) { cwRecheckHandler(w, r) }
func workbenchCasesByIdNotifyCreate(w http.ResponseWriter, r *http.Request)   { cwNotifyHandler(w, r) }
func integrationsFeishuCardCallbackCreate(w http.ResponseWriter, r *http.Request) {
	cwCallbackHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchCasesByIdNotificationPreviewCreate 处理 POST /api/workbench/cases/{id}/notification-preview：测试模式正式通知对象解析预览与实际测试目标 Dry Run，不发送消息
func workbenchCasesByIdNotificationPreviewCreate(w http.ResponseWriter, r *http.Request) {
	cwNotificationPreviewHandler(w, r)
}

// workbenchIdentityMappingsBySourceValueUpdate 处理 PUT /api/workbench/identity-mappings/{source_value}：由运营确认并持久维护提报人原始值到完整邮箱的身份映射
func workbenchIdentityMappingsBySourceValueUpdate(w http.ResponseWriter, r *http.Request) {
	cwIdentityMappingHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// integrationsFeishuConfigStatusList 处理 GET /api/integrations/feishu/config-status：管理员读取飞书 Bot 凭证配置状态（永不返回 Secret 或 Token）
func integrationsFeishuConfigStatusList(w http.ResponseWriter, r *http.Request) {
	feishuConfigStatusHandler(w, r)
}

// integrationsFeishuCredentialsCreate 处理 POST /api/integrations/feishu/credentials：管理员验证并原子保存飞书 Bot 凭证
func integrationsFeishuCredentialsCreate(w http.ResponseWriter, r *http.Request) {
	feishuCredentialsHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// integrationsFeishuTestRecipientCreate 处理 POST /api/integrations/feishu/test-recipient：管理员按完整企业邮箱解析并保存唯一测试接收人，启用 test 模式
func integrationsFeishuTestRecipientCreate(w http.ResponseWriter, r *http.Request) {
	feishuTestRecipientHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchAnalyticsList 处理 GET /api/workbench/analytics：运营按共享事件台账查询治理分析
func workbenchAnalyticsList(w http.ResponseWriter, r *http.Request) {
	cwAnalyticsHandler(w, r)
}

// workbenchAnalyticsExportList 处理 GET /api/workbench/analytics/export：运营按同一筛选口径导出治理分析Excel
func workbenchAnalyticsExportList(w http.ResponseWriter, r *http.Request) {
	cwAnalyticsExportHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchHistoryList 处理 GET /api/workbench/history：所有已登录使用者共享的最近十次扫描与处理记录
func workbenchHistoryList(w http.ResponseWriter, r *http.Request) {
	wbHistoryHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchIdentityMappingsList 处理 GET /api/workbench/identity-mappings：刷新并列出权威人员映射（敏感字段脱敏）
func workbenchIdentityMappingsList(w http.ResponseWriter, r *http.Request) {
	cwIdentityMappingsHandler(w, r)
}

// workbenchIdentityMappingsByRecordIdEnabledUpdate 处理 PUT /api/workbench/identity-mappings/{record_id}/enabled：运营启用或停用人员映射；人工停用不会被后续 Sheet 同步覆盖
func workbenchIdentityMappingsByRecordIdEnabledUpdate(w http.ResponseWriter, r *http.Request) {
	cwIdentityMappingEnabledHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// integrationsFeishuTestMessageCreate 处理 POST /api/integrations/feishu/test-message：管理员仅向后端测试白名单中的指定邮箱发送无客户信息纯文本测试消息
func integrationsFeishuTestMessageCreate(w http.ResponseWriter, r *http.Request) {
	feishuTestMessageHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchBatchesList 处理 GET /api/workbench/batches：只读返回真实持久化周度批次；无历史时返回空列表
func workbenchBatchesList(w http.ResponseWriter, r *http.Request) {
	wbBatchesHandler(w, r)
}

// workbenchReadModelList 处理 GET /api/workbench/read-model：四个主 Tab 共用的只读批次、筛选、卡片、事件与榜单契约
func workbenchReadModelList(w http.ResponseWriter, r *http.Request) {
	wbReadModelHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchAnalyticsExportHtmlList 处理 GET /api/workbench/analytics/export-html：导出与当前筛选和数据版本一致的独立只读HTML治理报告
func workbenchAnalyticsExportHtmlList(w http.ResponseWriter, r *http.Request) {
	cwAnalyticsHTMLExportHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchAnalyticsReportsCreate 处理 POST /api/workbench/analytics/reports：按当前真实统计与筛选生成不可变治理报告版本并保存到 Cloud DB
func workbenchAnalyticsReportsCreate(w http.ResponseWriter, r *http.Request) {
	workbenchAnalyticsReportsCreateHandler(w, r)
}

// workbenchAnalyticsReportsByReportIdGet 处理 GET /api/workbench/analytics/reports/{report_id}：只读获取 Cloud DB 中固定ID对应的不可变治理报告
func workbenchAnalyticsReportsByReportIdGet(w http.ResponseWriter, r *http.Request) {
	workbenchAnalyticsReportsByReportIdGetHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchNotificationsBatchCreate 处理 POST /api/workbench/notifications/batch：使用统一通知服务批量预览或排队；默认 dry_run，正式执行要求每条独立有效 preview_token
func workbenchNotificationsBatchCreate(w http.ResponseWriter, r *http.Request) {
	cwNotificationBatchHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchComparisonsRefreshCreate 处理 POST /api/workbench/comparisons/refresh：按 account_id 与 program 定向刷新当前持久化行的比较窗口，不触发全量扫描、处置或通知
func workbenchComparisonsRefreshCreate(w http.ResponseWriter, r *http.Request) {
	wbComparisonRefreshHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchRiskPolicyList 处理 GET /api/workbench/risk-policy：获取后端权威生效阈值、版本、权限与最近自动重判状态
func workbenchRiskPolicyList(w http.ResponseWriter, r *http.Request) {
	wbRiskPolicyListHandler(w, r)
}

// workbenchRiskPolicyUpdate 处理 PUT /api/workbench/risk-policy：运营使用 CAS 与幂等键确认并提交新阈值配置，自动创建当前周重判任务
func workbenchRiskPolicyUpdate(w http.ResponseWriter, r *http.Request) {
	wbRiskPolicyUpdateHandler(w, r)
}

// workbenchRiskPolicyRejudgementsList 处理 GET /api/workbench/risk-policy/rejudgements：获取阈值配置自动重判任务状态与历史，供前端轮询
func workbenchRiskPolicyRejudgementsList(w http.ResponseWriter, r *http.Request) {
	wbRiskPolicyTasksHandler(w, r)
}

// workbenchRiskPolicyVersionsList 处理 GET /api/workbench/risk-policy/versions：获取阈值配置版本与变更审计列表
func workbenchRiskPolicyVersionsList(w http.ResponseWriter, r *http.Request) {
	wbRiskPolicyVersionsHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchRiskPolicyPreviewCreate 处理 POST /api/workbench/risk-policy/preview：运营基于当前周持久化 ET/ST/THT 指标只读预览阈值草稿影响，不查询 Aeolus 或产生写副作用
func workbenchRiskPolicyPreviewCreate(w http.ResponseWriter, r *http.Request) {
	wbRiskPolicyPreviewHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchBackfillsList 处理 GET /api/workbench/backfills：运营查看回填任务状态、进度、checkpoint、请求ID和分Program结果
func workbenchBackfillsList(w http.ResponseWriter, r *http.Request) {
	wbBackfillsListHandler(w, r)
}

// workbenchBackfillsCreate 处理 POST /api/workbench/backfills：运营显式创建 enrichment 定向回填任务；dry-run 仅预览，禁止全量 membership、建 case 或通知
func workbenchBackfillsCreate(w http.ResponseWriter, r *http.Request) {
	wbBackfillsCreateHandler(w, r)
}

// workbenchBackfillsByIdGet 处理 GET /api/workbench/backfills/{id}：运营查看单个回填任务详情
func workbenchBackfillsByIdGet(w http.ResponseWriter, r *http.Request) {
	wbBackfillsGetHandler(w, r)
}

// workbenchBackfillsByIdRetryCreate 处理 POST /api/workbench/backfills/{id}/retry：运营显式从 checkpoint 重试失败或中断的回填任务
func workbenchBackfillsByIdRetryCreate(w http.ResponseWriter, r *http.Request) {
	wbBackfillsRetryHandler(w, r)
}

// ── 以下由 gen_api.py 自动追加（IDL 新增接口） ──

// workbenchReportedReasonsRefreshCreate 处理 POST /api/workbench/reported-reasons/refresh：按 ET Account 与 Advertiser 定向刷新 Current Window 原因 Top3，仅更新关联持久化行
func workbenchReportedReasonsRefreshCreate(w http.ResponseWriter, r *http.Request) {
	wbReportedReasonsRefreshHandler(w, r)
}
