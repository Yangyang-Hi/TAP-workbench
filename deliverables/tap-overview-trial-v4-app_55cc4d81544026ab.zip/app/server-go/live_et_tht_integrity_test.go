package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// TestLiveFocusedETMetric is opt-in and executes a read-only Saved Report/VQS
// query for the account supplied by LIVE_ET_ACCOUNT_ID.
func TestLiveFocusedETMetric(t *testing.T) {
	if os.Getenv("RUN_LIVE_ET_FOCUSED") != "1" {
		t.Skip("set RUN_LIVE_ET_FOCUSED=1 for a real focused ET metric verification")
	}
	id := os.Getenv("LIVE_ET_ACCOUNT_ID")
	if !decimalID.MatchString(id) {
		t.Fatal("LIVE_ET_ACCOUNT_ID must be a decimal string")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	req := httptest.NewRequest(http.MethodGet, "/api/live", nil)
	req.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	metrics, err := queryETCurrentBatch(ctx, req, []string{id}, "2026-10-01", "2026-10-21")
	if err != nil {
		t.Fatal(err)
	}
	metric := metrics[id]
	value := func(v *float64) any {
		if v == nil {
			return nil
		}
		return *v
	}
	t.Logf("account_id=%s status=%s advertiser_id=%s region=%s ccr=%v nfs=%v request_id=%s", id, metric.Status, metric.AdvertiserID, metric.Region, value(metric.CCR), value(metric.NFS), metric.RequestID)
	if metric.Status != "success" {
		t.Fatalf("focused ET fact is unavailable: %+v", metric)
	}
}

// TestLiveTHTMembershipProjection is opt-in and read-only. It fails closed when
// the governed Saved Report does not project the advertiser join key.
func TestLivePrePostWindowContracts(t *testing.T) {
	if os.Getenv("RUN_LIVE_PRE_POST") != "1" {
		t.Skip("set RUN_LIVE_PRE_POST=1 for real read-only ET/THT window verification")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	etID, thtID := os.Getenv("LIVE_ET_ACCOUNT_ID"), os.Getenv("LIVE_THT_ADVERTISER_ID")
	if !decimalID.MatchString(etID) || !decimalID.MatchString(thtID) {
		t.Fatal("LIVE_ET_ACCOUNT_ID and LIVE_THT_ADVERTISER_ID must be decimal strings")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	req := httptest.NewRequest(http.MethodGet, "/api/live", nil)
	req.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	ctx, cancel := context.WithTimeout(context.Background(), 180*time.Second)
	defer cancel()
	type window struct{ name, start, end string }
	windows := []window{{"pre", "2026-10-07", "2026-10-13"}, {"post", "2026-10-14", "2026-10-20"}}
	for _, current := range windows {
		etRows, err := queryEvidenceRows(ctx, req, "weekly_pair_ccr_nfs", []string{etID}, "account_id", current.start, current.end)
		if err != nil {
			t.Fatalf("ET %s window failed: %v", current.name, err)
		}
		revenueRows, revenueErr := queryEvidenceRows(ctx, req, "weekly_pair_revenue", []string{etID}, "account_id", current.start, current.end)
		t.Logf("ET %s window=%s..%s grain=account_advertiser_window rows=%d sample=%v revenue_rows=%d revenue_error=%v", current.name, current.start, current.end, len(etRows), firstBusinessRow(etRows), len(revenueRows), revenueErr)
		tht, err := queryTHTCurrentBatch(ctx, req, []string{thtID}, current.start, current.end)
		if err != nil {
			t.Fatalf("THT %s window failed: %v", current.name, err)
		}
		metrics := tht[thtID]
		for _, metric := range metrics {
			t.Logf("THT %s window=%s..%s grain=account_advertiser_window account_id=%s status=%s ccr=%v nfs=%v request_id=%s", current.name, current.start, current.end, metric.AccountID, metric.Status, wbLiveMetricValue(metric.CCR), wbLiveMetricValue(metric.NFS), metric.RequestID)
		}
	}
}

func wbLiveMetricValue(value *float64) any {
	if value == nil {
		return nil
	}
	return *value
}

func firstBusinessRow(rows []map[string]any) map[string]any {
	if len(rows) == 0 {
		return nil
	}
	return rows[0]
}

func TestLiveTHTMembershipProjection(t *testing.T) {
	if os.Getenv("RUN_LIVE_THT_MEMBERSHIP") != "1" {
		t.Skip("set RUN_LIVE_THT_MEMBERSHIP=1 for real THT membership verification")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("AIME_USER_CLOUD_JWT is unavailable")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	t.Cleanup(func() { pluginDir = oldPluginDir })
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	req := httptest.NewRequest(http.MethodGet, "/api/live?start_date=2026-10-01&end_date=2026-10-21&program_type=THT", nil)
	req.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	probe, err := runTitanVQSProbe(ctx, req, "tht_ticket_details")
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("status=%s rows=%v columns=%v field_map=%v sample=%v effective_filters=%v request_id=%s log_id=%s", asString(probe["status"]), probe["rowCount"], probe["columns"], probe["field_map"], func() any {
		if rows, ok := probe["rows"].([]map[string]any); ok && len(rows) > 0 {
			return rows[0]
		}
		return nil
	}(), probe["effective_filters"], asString(probe["requestId"]), asString(probe["logId"]))
	if asString(probe["status"]) != "ok" {
		t.Fatalf("THT Saved Report/VQS failed: status=%s", asString(probe["status"]))
	}
	rows, _ := probe["business_rows"].([]map[string]any)
	for _, row := range rows {
		if decimalID.MatchString(asString(row["advertiser_id"])) {
			return
		}
	}
	t.Fatal("THT Saved Report does not project a usable advertiser_id")
}

func TestLiveRevenueFilterIsolation(t *testing.T) {
	if os.Getenv("RUN_LIVE_REVENUE_ISOLATION") != "1" {
		t.Skip("opt-in")
	}
	jwt := os.Getenv("AIME_USER_CLOUD_JWT")
	if jwt == "" {
		t.Fatal("missing jwt")
	}
	oldPluginDir := pluginDir
	pluginDir = filepath.Clean("../..")
	defer func() { pluginDir = oldPluginDir }()
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	base := httptest.NewRequest(http.MethodGet, "/api/probe", nil)
	base.Header.Set("Authorization", "Byte-Cloud-JWT "+jwt)
	base.Header.Set("X-Aime-User", "heyangyang.31")
	cases := []string{"", "client_ids=6825581090564997125&id_dimension=advertiser_id", "start_date=2026-10-12&end_date=2026-10-18", "client_ids=6825581090564997125&id_dimension=advertiser_id&start_date=2026-10-12&end_date=2026-10-18"}
	for _, raw := range cases {
		r := base.Clone(context.Background())
		u := *base.URL
		u.RawQuery = raw
		r.URL = &u
		result, err := runTitanVQSProbe(context.Background(), r, "weekly_pair_revenue")
		if err != nil {
			t.Fatalf("%s: %v", raw, err)
		}
		t.Logf("case=%q status=%v request=%v log=%v filters=%v partition=%v result=%+v", raw, result["status"], result["requestId"], result["logId"], result["effective_filters"], result["partition"], result["query_result"])
	}
}
