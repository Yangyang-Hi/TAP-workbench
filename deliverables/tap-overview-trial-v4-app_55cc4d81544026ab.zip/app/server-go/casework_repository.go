package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
)

// caseworkRepository is injectable so unit tests can explicitly use isolated
// SQLite while production always uses the fail-fast Cloud implementation.
type caseworkRepository interface {
	listCases(context.Context) ([]cwCase, error)
	caseByID(context.Context, string) (cwCase, error)
	createCase(context.Context, cwCase) (cwCase, error)
	saveCaseCAS(context.Context, cwCase, int) error
	command(context.Context, string, string) (string, bool, error)
	putCommand(context.Context, string, string, string, int) error
	listNotices(context.Context) ([]cwNotice, error)
	notices(context.Context, string) ([]cwNotice, error)
	upsertNotice(context.Context, cwNotice, string, int64) error
	queueUpdates(context.Context, cwCase) error
}

var cwCaseworkRepositoryProvider = func() (caseworkRepository, error) { return cwCloudRepo() }

type localCaseworkRepository struct{}

func (localCaseworkRepository) listCases(_ context.Context) ([]cwCase, error) {
	db, e := cwDB()
	if e != nil {
		return nil, e
	}
	defer db.Close()
	rows, e := db.Query("SELECT body FROM tap_cases")
	if e != nil {
		return nil, e
	}
	defer rows.Close()
	out := []cwCase{}
	for rows.Next() {
		var raw string
		if e = rows.Scan(&raw); e != nil {
			return nil, e
		}
		var a cwCase
		if e = json.Unmarshal([]byte(raw), &a); e != nil {
			return nil, e
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

func (localCaseworkRepository) caseByID(_ context.Context, id string) (cwCase, error) {
	db, e := cwDB()
	if e != nil {
		return cwCase{}, e
	}
	defer db.Close()
	return cwRead(db, id)
}
func (localCaseworkRepository) createCase(_ context.Context, a cwCase) (cwCase, error) {
	db, e := cwDB()
	if e != nil {
		return cwCase{}, e
	}
	defer db.Close()
	b, _ := json.Marshal(a)
	_, e = db.Exec("INSERT OR IGNORE INTO tap_cases(id,version,body) VALUES(?,?,?)", a.ID, a.Version, string(b))
	if e != nil {
		return a, e
	}
	return cwRead(db, a.ID)
}
func (localCaseworkRepository) saveCaseCAS(_ context.Context, a cwCase, previous int) error {
	db, e := cwDB()
	if e != nil {
		return e
	}
	defer db.Close()
	b, e := json.Marshal(a)
	if e != nil {
		return e
	}
	result, e := db.Exec("UPDATE tap_cases SET version=?,body=? WHERE id=? AND version=?", a.Version, string(b), a.ID, previous)
	if e != nil {
		return e
	}
	n, _ := result.RowsAffected()
	if n != 1 {
		return cwErr(409, "记录已更新，请刷新后重试")
	}
	return nil
}
func (localCaseworkRepository) command(_ context.Context, caseID, requestID string) (string, bool, error) {
	db, e := cwDB()
	if e != nil {
		return "", false, e
	}
	defer db.Close()
	var f string
	e = db.QueryRow("SELECT body FROM tap_commands WHERE case_id=? AND request_id=?", caseID, requestID).Scan(&f)
	if errors.Is(e, sql.ErrNoRows) {
		return "", false, nil
	}
	return f, e == nil, e
}
func (localCaseworkRepository) putCommand(_ context.Context, caseID, requestID, fingerprint string, _ int) error {
	db, e := cwDB()
	if e != nil {
		return e
	}
	defer db.Close()
	_, e = db.Exec("INSERT INTO tap_commands(case_id,request_id,body) VALUES(?,?,?)", caseID, requestID, fingerprint)
	return e
}
func (localCaseworkRepository) listNotices(_ context.Context) ([]cwNotice, error) {
	db, e := cwDB()
	if e != nil {
		return nil, e
	}
	defer db.Close()
	rows, e := db.Query("SELECT DISTINCT case_id FROM tap_outbox")
	if e != nil {
		return nil, e
	}
	defer rows.Close()
	ids := []string{}
	for rows.Next() {
		var id string
		if e = rows.Scan(&id); e != nil {
			return nil, e
		}
		ids = append(ids, id)
	}
	out := []cwNotice{}
	for _, id := range ids {
		items, err := cwNotices(db, id)
		if err != nil {
			return nil, err
		}
		out = append(out, items...)
	}
	return out, rows.Err()
}
func (localCaseworkRepository) notices(_ context.Context, caseID string) ([]cwNotice, error) {
	db, e := cwDB()
	if e != nil {
		return nil, e
	}
	defer db.Close()
	return cwNotices(db, caseID)
}

func (localCaseworkRepository) upsertNotice(context.Context, cwNotice, string, int64) error {
	return nil
}
func (localCaseworkRepository) queueUpdates(_ context.Context, a cwCase) error {
	db, err := cwDB()
	if err != nil {
		return err
	}
	defer db.Close()
	tx, err := db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if err = cwQueueUpdates(tx, a); err != nil {
		return err
	}
	return tx.Commit()
}
