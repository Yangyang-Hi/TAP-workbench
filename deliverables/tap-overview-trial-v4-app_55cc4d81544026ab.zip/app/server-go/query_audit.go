package main

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"
)

const queryAuditRetentionDays = 30

var (
	queryAuditMu      sync.Mutex
	queryAuditNow     = time.Now
	queryAuditDataDir = resolveDataDir
)

type queryAuditRecord struct {
	AuditID             string            `json:"audit_id"`
	RequestID           string            `json:"request_id,omitempty"`
	Trigger             string            `json:"trigger"`
	Program             string            `json:"program,omitempty"`
	Tier                string            `json:"tier,omitempty"`
	SourceKey           string            `json:"source_key"`
	AppID               string            `json:"app_id,omitempty"`
	RID                 string            `json:"rid,omitempty"`
	SID                 string            `json:"sid,omitempty"`
	TID                 string            `json:"tid,omitempty"`
	Region              string            `json:"region,omitempty"`
	BusinessWindow      map[string]string `json:"business_time_window,omitempty"`
	EffectiveFilters    any               `json:"effective_filters,omitempty"`
	ProjectionFields    []string          `json:"projection_fields,omitempty"`
	QueryDefinitionHash string            `json:"query_definition_hash,omitempty"`
	QueryDefinitionRef  string            `json:"query_definition_ref,omitempty"`
	QueryHistoryID      string            `json:"query_history_id,omitempty"`
	SQLStatus           string            `json:"sql_status"`
	SQLRef              string            `json:"sql_ref,omitempty"`
	StartedAt           string            `json:"started_at"`
	EndedAt             string            `json:"ended_at"`
	DurationMS          int64             `json:"duration_ms"`
	HTTPStatus          int               `json:"http_status,omitempty"`
	BusinessStatus      string            `json:"business_status,omitempty"`
	RowCount            int               `json:"row_count"`
	Chunk               map[string]int    `json:"chunk,omitempty"`
	QueuePollCount      int               `json:"need_to_queue_poll_count"`
	Complete            bool              `json:"complete"`
	ErrorCode           string            `json:"error_code,omitempty"`
	ErrorMessage        string            `json:"error_message,omitempty"`
	SourceColumns       []string          `json:"source_columns,omitempty"`
	ContractDiagnostics any               `json:"contract_diagnostics,omitempty"`
}

type queryAuditSpan struct {
	record     queryAuditRecord
	started    time.Time
	definition map[string]any
}

func newQueryAudit(r *http.Request, sourceKey string, source sourceConfig) *queryAuditSpan {
	now := queryAuditNow().UTC()
	q := r.URL.Query()
	trigger := strings.TrimSpace(r.Header.Get("X-TAP-Query-Trigger"))
	if trigger == "" {
		switch {
		case r.Header.Get("X-TAP-Quota-Mode") == "1":
			trigger = "quota"
		case strings.Contains(strings.ToLower(r.URL.Path), "weekly"):
			trigger = "weekly"
		case q.Get("start_date") != "" || q.Get("end_date") != "":
			trigger = "custom"
		default:
			trigger = "manual"
		}
	}
	return &queryAuditSpan{started: now, record: queryAuditRecord{
		AuditID: newAuditID(), Trigger: trigger, Program: q.Get("program"), Tier: q.Get("tier"), SourceKey: sourceKey,
		AppID: fmt.Sprint(source.AppID), RID: fmt.Sprint(source.RID), SID: fmt.Sprint(source.SID), TID: fmt.Sprint(source.TID), Region: q.Get("region"),
		BusinessWindow: map[string]string{"start": q.Get("start_date"), "end": q.Get("end_date")}, StartedAt: now.Format(time.RFC3339Nano), SQLStatus: "not_returned",
	}}
}

func (s *queryAuditSpan) setDefinition(body map[string]any) {
	s.definition = redactAuditValue(body).(map[string]any)
	raw, _ := json.Marshal(s.definition)
	sum := sha256.Sum256(raw)
	s.record.QueryDefinitionHash = hex.EncodeToString(sum[:])
	s.record.EffectiveFilters = describeVQSFilters(body)
	s.record.ProjectionFields = auditProjectionFields(body)
	s.record.Chunk = map[string]int{}
	if query, ok := body["query"].(map[string]any); ok {
		if limit := asInt(query["limit"]); limit > 0 {
			s.record.Chunk["limit"] = limit
		}
	}
	for _, filter := range describeVQSFilters(body) {
		if values, ok := filter["val"].([]any); ok && len(values) > 0 {
			s.record.Chunk["items"] = len(values)
		}
	}
	if len(s.record.Chunk) == 0 {
		s.record.Chunk = nil
	}
}

func (s *queryAuditSpan) finish(result map[string]any, callErr error) {
	if result == nil {
		result = map[string]any{}
	}
	if step, ok := result["query_result"].(titanProbeStep); ok {
		s.record.RequestID, s.record.QueryHistoryID = step.RequestID, step.QueryHistoryID
		s.record.HTTPStatus, s.record.BusinessStatus, s.record.RowCount = step.HTTPStatus, asString(step.GlueCode), step.RowsCount
		s.record.QueuePollCount, s.record.SourceColumns = step.QueuePollCount, append([]string(nil), step.Columns...)
		s.record.ErrorCode, s.record.ErrorMessage = step.ErrorType, sanitizeAuditText(step.ErrorMessage)
		if step.SQL != "" {
			s.record.SQLStatus = "returned"
			s.persistLarge("sql", []byte(step.SQL), &s.record.SQLRef)
		}
	}
	if s.record.RequestID == "" {
		s.record.RequestID = asString(result["requestId"])
	}
	if s.record.BusinessStatus == "" {
		s.record.BusinessStatus = asString(result["status"])
	}
	if callErr != nil {
		s.record.ErrorCode = "call_error"
		s.record.ErrorMessage = sanitizeAuditText(callErr.Error())
	}
	s.record.ContractDiagnostics = redactAuditValue(map[string]any{"filter_integrity": result["filter_integrity"], "failure_classification": result["failure_classification"], "likely_problem_paths": result["likely_problem_paths"]})
	s.record.Complete = s.record.BusinessStatus == "ok" && !asBool(result["possibly_truncated"])
	ended := queryAuditNow().UTC()
	s.record.EndedAt = ended.Format(time.RFC3339Nano)
	s.record.DurationMS = ended.Sub(s.started).Milliseconds()
	if s.definition != nil {
		raw, _ := json.Marshal(s.definition)
		s.persistLarge("definition", raw, &s.record.QueryDefinitionRef)
	}
	if err := appendQueryAudit(s.record); err != nil {
		logMsg(fmt.Sprintf("query_audit_write_failed audit_id=%s hash=%s error=%s", s.record.AuditID, s.record.QueryDefinitionHash, sanitizeAuditText(err.Error())), "plugin")
	} else {
		logMsg(fmt.Sprintf("query_audit audit_id=%s request_id=%s status=%s hash=%s index=%s", s.record.AuditID, s.record.RequestID, s.record.BusinessStatus, s.record.QueryDefinitionHash, filepath.Base(s.record.QueryDefinitionRef)), "plugin")
	}
	result["audit_id"], result["query_history_id"], result["query_definition_hash"] = s.record.AuditID, s.record.QueryHistoryID, s.record.QueryDefinitionHash
}

func (s *queryAuditSpan) persistLarge(kind string, raw []byte, target *string) {
	dir, err := queryAuditDataDir()
	if err != nil {
		return
	}
	dir = filepath.Join(dir, "query-audit", "payloads", s.started.Format("2006-01-02"))
	if os.MkdirAll(dir, 0700) != nil {
		return
	}
	name := s.record.AuditID + "-" + kind + ".json"
	if kind == "sql" {
		name = s.record.AuditID + ".sql"
	}
	path := filepath.Join(dir, name)
	if os.WriteFile(path, raw, 0600) == nil {
		*target = filepath.ToSlash(filepath.Join("payloads", s.started.Format("2006-01-02"), name))
	}
}

func appendQueryAudit(record queryAuditRecord) error {
	queryAuditMu.Lock()
	defer queryAuditMu.Unlock()
	dir, err := queryAuditDataDir()
	if err != nil {
		return err
	}
	dir = filepath.Join(dir, "query-audit")
	if err = os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	cleanupQueryAuditsLocked(dir, queryAuditNow().UTC())
	raw, err := json.Marshal(record)
	if err != nil {
		return err
	}
	f, err := os.OpenFile(filepath.Join(dir, record.startedDate()+".jsonl"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.Write(append(raw, '\n'))
	return err
}
func (r queryAuditRecord) startedDate() string {
	t, _ := time.Parse(time.RFC3339Nano, r.StartedAt)
	return t.UTC().Format("2006-01-02")
}
func cleanupQueryAuditsLocked(dir string, now time.Time) {
	entries, _ := os.ReadDir(dir)
	cutoff := now.AddDate(0, 0, -queryAuditRetentionDays)
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		if t, err := time.Parse("2006-01-02.jsonl", e.Name()); err == nil && t.Before(cutoff) {
			_ = os.Remove(filepath.Join(dir, e.Name()))
		}
	}
}
func newAuditID() string {
	b := make([]byte, 12)
	_, _ = rand.Read(b)
	return "qa_" + hex.EncodeToString(b)
}
func auditProjectionFields(body map[string]any) []string {
	set := map[string]bool{}
	raw, _ := json.Marshal(body)
	re := regexp.MustCompile(`"(?:datasetFieldId|dimMetId|uniqueId|originId)"\s*:\s*"([0-9]+)"`)
	for _, m := range re.FindAllStringSubmatch(string(raw), -1) {
		set[m[1]] = true
	}
	out := make([]string, 0, len(set))
	for k := range set {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
func sanitizeAuditText(v string) string {
	v = sanitizeLogText(v)
	v = regexp.MustCompile(`(?i)(authorization|cookie|clientsecret|x-titan-token|jwt)(\s*[:=]\s*)[^\s,;]+`).ReplaceAllString(v, "$1$2[REDACTED]")
	v = regexp.MustCompile(`[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}`).ReplaceAllString(v, "[REDACTED_EMAIL]")
	return v
}
func redactAuditValue(v any) any {
	switch n := v.(type) {
	case map[string]any:
		out := map[string]any{}
		for k, x := range n {
			lower := strings.ToLower(k)
			if strings.Contains(lower, "authorization") || strings.Contains(lower, "cookie") || strings.Contains(lower, "secret") || strings.Contains(lower, "token") || strings.Contains(lower, "email") {
				out[k] = "[REDACTED]"
			} else {
				out[k] = redactAuditValue(x)
			}
		}
		return out
	case []any:
		out := make([]any, len(n))
		for i, x := range n {
			out[i] = redactAuditValue(x)
		}
		return out
	case string:
		return sanitizeAuditText(n)
	default:
		return v
	}
}
