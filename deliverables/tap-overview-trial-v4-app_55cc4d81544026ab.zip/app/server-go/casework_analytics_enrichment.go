package main

import (
	"fmt"
	"sort"
	"strings"
)

type cwRuleSummary struct {
	Key       string `json:"key"`
	Name      string `json:"name"`
	Category  string `json:"category"`
	Condition string `json:"condition"`
	Details   string `json:"details"`
	Status    string `json:"status"`
	Events    int    `json:"events"`
	Clients   int    `json:"clients"`
	Overlap   bool   `json:"overlap"`
}

type cwBatchProgramStatus struct {
	Program  string `json:"program"`
	Status   string `json:"status"`
	Stage    string `json:"stage"`
	Error    string `json:"error,omitempty"`
	Complete bool   `json:"complete"`
}

type cwBatchStatus struct {
	Label      string                 `json:"label"`
	Incomplete bool                   `json:"incomplete"`
	Programs   []cwBatchProgramStatus `json:"programs"`
}

type cwPriorityClient struct {
	CaseID          string   `json:"case_id"`
	Dimension       string   `json:"dimension"`
	ClientID        string   `json:"client_id"`
	Name            string   `json:"name"`
	Program         string   `json:"program"`
	Region          string   `json:"region"`
	Nominator       string   `json:"nominator"`
	Severity        string   `json:"severity"`
	CaseStatus      string   `json:"case_status"`
	AlertTypes      []string `json:"alert_types"`
	EventCount      int      `json:"event_count"`
	CCR             *float64 `json:"p0_ccr"`
	NFS             *float64 `json:"p0_nfs"`
	Revenue         *float64 `json:"revenue"`
	ProvisionalRank bool     `json:"provisional_rank"`
}

type cwTop20Candidate struct {
	CaseID           string   `json:"case_id,omitempty"`
	ClientID         string   `json:"client_id"`
	Name             string   `json:"name"`
	Program          string   `json:"program"`
	Region           string   `json:"region"`
	Tier             string   `json:"tier"`
	ComparisonWindow string   `json:"comparison_window"`
	GrowthPct        *float64 `json:"growth_pct"`
	CCR              *float64 `json:"p0_ccr"`
	NFS              *float64 `json:"p0_nfs"`
	Revenue          *float64 `json:"revenue"`
	FormalEvent      bool     `json:"formal_event"`
}

type cwQuotaAlertRow struct {
	Region             string   `json:"region"`
	Status             string   `json:"status"`
	Owner              string   `json:"owner"`
	NotificationStatus string   `json:"notification_status"`
	CaseStatus         string   `json:"case_status"`
	Used               *float64 `json:"used"`
	Quota              *float64 `json:"quota"`
	Exceeded           *float64 `json:"exceeded"`
	UsageRate          *float64 `json:"usage_rate"`
}

type cwQuotaAlertSection struct {
	Program         string            `json:"program"`
	Title           string            `json:"title"`
	Unit            string            `json:"unit"`
	Window          string            `json:"window"`
	Methodology     string            `json:"methodology"`
	Note            string            `json:"note"`
	Used            *float64          `json:"used"`
	Quota           *float64          `json:"quota"`
	UsageRate       *float64          `json:"usage_rate"`
	FullRegions     int               `json:"full_regions"`
	ExceededRegions int               `json:"exceeded_regions"`
	Rows            []cwQuotaAlertRow `json:"rows"`
}

type cwQuotaAlerts struct {
	ET cwQuotaAlertSection `json:"et"`
	ST cwQuotaAlertSection `json:"st"`
}

func cwCaseKey(a cwCase) string { return a.ScanID + "|" + a.Row.ID }

func cwTop20Index(f cwAnalyticsFilter) (map[string]bool, []cwTop20Candidate) {
	selected := map[string]bool{}
	candidates := []cwTop20Candidate{}
	for _, job := range f.Jobs {
		groups := map[string][]wbRow{}
		for _, row := range job.Rows {
			g := wbComparisonGrowth(row.Program, row.Comparison)
			if !wbComparisonGrowthAvailable(row.Program, row.Comparison) || g == nil || *g <= 0 {
				continue
			}
			a := cwCase{Row: row, ScanID: job.ID}
			bf := businessFilter{Region: f.Region, Program: strings.ToUpper(f.Program), Tier: f.Tier, Submitter: f.Submitter, Owner: f.Owner, AdvertiserID: f.AdvertiserID, AccountID: f.AccountID, Search: f.Search, DateField: f.DateField}
			if !matchBusinessCase(a, bf, "") || (f.Level != "" && f.Level != "all" && row.Level != f.Level) {
				continue
			}
			key := wbGrowthGroupKey(row.Program, row.Member.Tier, row.Member.Region)
			groups[key] = append(groups[key], row)
		}
		for _, rows := range groups {
			sort.SliceStable(rows, func(i, j int) bool {
				a, b := wbComparisonGrowth(rows[i].Program, rows[i].Comparison), wbComparisonGrowth(rows[j].Program, rows[j].Comparison)
				if *a != *b {
					return *a > *b
				}
				return rows[i].ID < rows[j].ID
			})
			if len(rows) > 20 {
				rows = rows[:20]
			}
			for _, row := range rows {
				selected[job.ID+"|"+row.ID] = true
				id := row.Member.AccountID
				if row.Program == "THT" {
					id = row.Member.AdvertiserID
				}
				window := row.Comparison.PreStart + " ~ " + row.Comparison.PreEndExclusive + " vs " + row.Comparison.PostStart + " ~ " + row.Comparison.PostEndExclusive
				if strings.Trim(window, " ~vs") == "" {
					window = "规则说明待补齐"
				}
				candidates = append(candidates, cwTop20Candidate{ClientID: id, Name: emptyFallback(row.Member.Name, "Not available"), Program: row.Program, Region: row.Member.Region, Tier: row.Member.Tier, ComparisonWindow: window, GrowthPct: wbComparisonGrowth(row.Program, row.Comparison), CCR: row.CCR, NFS: row.NFS, Revenue: row.Revenue, FormalEvent: wbMatched(row)})
			}
		}
	}
	sort.SliceStable(candidates, func(i, j int) bool {
		if candidates[i].GrowthPct == nil {
			return false
		}
		if candidates[j].GrowthPct == nil {
			return true
		}
		return *candidates[i].GrowthPct > *candidates[j].GrowthPct
	})
	return selected, candidates
}

func cwSavedRuleCondition(rule wbRule) (string, string) {
	parts := []string{}
	if rule.CriticalCCR > 0 {
		parts = append(parts, fmt.Sprintf("极端：P0 CCR > %g", rule.CriticalCCR))
	}
	if rule.WatchCCR > 0 && rule.WatchNFS > 0 {
		parts = append(parts, fmt.Sprintf("观察：P0 CCR ≥ %g 且 P0 NFS > %g", rule.WatchCCR, rule.WatchNFS))
	}
	if len(parts) == 0 {
		return "规则说明待补齐", "missing_snapshot_fields"
	}
	return strings.Join(parts, "；") + "。未在快照中保存的阈值不补猜。", "partial_snapshot"
}

func cwRuleSummaries(x *cwAnalytics, top20 map[string]bool) []cwRuleSummary {
	type bucket struct {
		events  int
		clients map[string]bool
	}
	buckets := map[string]*bucket{}
	for _, key := range []string{"absolute", "growth_top20", "extreme", "watch"} {
		buckets[key] = &bucket{clients: map[string]bool{}}
	}
	for _, a := range x.Cases {
		client := cwClientKey(a)
		level, _ := evaluateWBAbsolute(a.Row.CCR, a.Row.NFS, a.Rule)
		if level == "critical" || level == "watch" {
			buckets["absolute"].events++
			buckets["absolute"].clients[client] = true
		}
		if top20[cwCaseKey(a)] {
			buckets["growth_top20"].events++
			buckets["growth_top20"].clients[client] = true
		}
		if a.Row.Level == "critical" {
			buckets["extreme"].events++
			buckets["extreme"].clients[client] = true
		}
		if a.Row.Level == "watch" {
			buckets["watch"].events++
			buckets["watch"].clients[client] = true
		}
	}
	condition, status := "规则说明待补齐", "missing_snapshot_fields"
	versions := []string{}
	for _, job := range x.Filters.Jobs {
		if c, s := cwSavedRuleCondition(job.Rule); c != "规则说明待补齐" {
			condition, status = c, s
		}
		if job.Rule.Version != "" {
			versions = append(versions, job.Request.Program+" "+job.Rule.Version)
		}
	}
	// Cases retain the batch rule snapshot even when a historical job is no longer
	// available in the current process. Use that structured snapshot as a fallback;
	// never infer a rule from reasons or metric values.
	for _, a := range x.Cases {
		if c, s := cwSavedRuleCondition(a.Rule); c != "规则说明待补齐" && condition == "规则说明待补齐" {
			condition, status = c, s
		}
		if a.Rule.Version != "" {
			versions = append(versions, a.Row.Program+" "+a.Rule.Version)
		}
	}
	versionNote := "规则版本：" + strings.Join(uniqueNonEmpty(versions), "；")
	if len(versions) == 0 {
		versionNote = "规则版本待补齐"
	}
	makeRule := func(key, name, category, cond, details, st string) cwRuleSummary {
		b := buckets[key]
		return cwRuleSummary{Key: key, Name: name, Category: category, Condition: cond, Details: details, Status: st, Events: b.events, Clients: len(b.clients), Overlap: true}
	}
	return []cwRuleSummary{
		makeRule("absolute", "绝对值预警", "类型", condition, versionNote, status),
		makeRule("growth_top20", "P0 CCR增幅预警／Top20", "类型", "按保存的结构化前后窗口计算 P0 CCR 增幅；进入条件与排序字段快照不足时不补猜。", "增幅=(后窗P0 CCR-前窗P0 CCR)/前窗P0 CCR×100%；具体窗口见候选榜单。适用项目来自批次实际 Program。", "partial_snapshot"),
		makeRule("extreme", "极端预警", "等级", "真实等级来自保存的 row.level=critical；完整判断条件："+condition, "等级与类型可重叠；不从描述或 CCR 数值反推来源。", status),
		makeRule("watch", "观察预警", "等级", "真实等级来自保存的 row.level=watch；完整判断条件："+condition, "等级与类型可重叠；不从描述或 CCR 数值反推来源。", status),
	}
}

func cwMaxMetric(a, b *float64) *float64 {
	if a == nil {
		return b
	}
	if b == nil {
		return a
	}
	if *b > *a {
		return b
	}
	return a
}

func cwPriorityClients(cases []cwCase, source map[string][]string) []cwPriorityClient {
	merged := map[string]*cwPriorityClient{}
	statuses := map[string]map[string]bool{}
	alertTypes := map[string]map[string]bool{}
	for _, a := range cases {
		key := cwClientKey(a)
		p := merged[key]
		id := a.Row.Member.AccountID
		dimension := "Account Level"
		if a.Row.Program == "THT" {
			id = a.Row.Member.AdvertiserID
			dimension = "Advertiser Level"
		}
		if p == nil {
			p = &cwPriorityClient{CaseID: a.ID, Dimension: dimension, ClientID: id, Name: emptyFallback(a.Row.Member.Name, "Not available"), Program: a.Row.Program, Region: a.Row.Member.Region, Nominator: a.Row.Member.Submitter, Severity: a.Row.Level}
			merged[key] = p
			statuses[key] = map[string]bool{}
			alertTypes[key] = map[string]bool{}
		}
		p.EventCount++
		p.CCR = cwMaxMetric(p.CCR, a.Row.CCR)
		p.NFS = cwMaxMetric(p.NFS, a.Row.NFS)
		p.Revenue = cwMaxMetric(p.Revenue, a.Row.Revenue)
		if a.Row.Level == "critical" {
			p.Severity = "critical"
		}
		statuses[key][a.Status] = true
		for _, v := range source[a.ID] {
			alertTypes[key][v] = true
		}
	}
	extreme, watch := []cwPriorityClient{}, []cwPriorityClient{}
	for key, p := range merged {
		for v := range statuses[key] {
			p.CaseStatus = emptyFallback(p.CaseStatus+func() string {
				if p.CaseStatus != "" {
					return " + "
				}
				return ""
			}()+v, v)
		}
		for v := range alertTypes[key] {
			p.AlertTypes = append(p.AlertTypes, v)
		}
		sort.Strings(p.AlertTypes)
		p.ProvisionalRank = p.CCR == nil || p.NFS == nil
		if p.Severity == "critical" {
			extreme = append(extreme, *p)
		} else if p.Severity == "watch" {
			watch = append(watch, *p)
		}
	}
	sortRisk := func(rows []cwPriorityClient) {
		sort.SliceStable(rows, func(i, j int) bool {
			for _, pair := range [][2]*float64{{rows[i].CCR, rows[j].CCR}, {rows[i].NFS, rows[j].NFS}} {
				if pair[0] == nil && pair[1] != nil {
					return false
				}
				if pair[0] != nil && pair[1] == nil {
					return true
				}
				if pair[0] != nil && pair[1] != nil && *pair[0] != *pair[1] {
					return *pair[0] > *pair[1]
				}
			}
			return rows[i].ClientID < rows[j].ClientID
		})
	}
	sortRisk(extreme)
	sortRisk(watch)
	if len(extreme) >= 10 {
		return extreme
	}
	need := 10 - len(extreme)
	if need > len(watch) {
		need = len(watch)
	}
	return append(extreme, watch[:need]...)
}

func cwFloatAny(v any) *float64 {
	if n, ok := number(v); ok {
		return &n
	}
	return nil
}

func cwBuildQuotaSection(program string, q map[string]any, f cwAnalyticsFilter) cwQuotaAlertSection {
	unit, title, window, method := "Account", "ET Quota Alerts", f.Start+" 至 "+f.End, "Used 按获批 account_id 去重；Account-level 区域配额"
	if program == "ST" {
		unit, title, window, method = "Brand", "ST Quota Alerts", fmt.Sprint(q["quarter"])+" 季度累计", "Used 按季度权威名单 Brand Name 去重；Brand-level 区域配额"
	}
	s := cwQuotaAlertSection{Program: program, Title: title, Unit: unit, Window: window, Methodology: method}
	global := cwMap(cwMap(q["global"])[strings.ToLower(program)])
	s.Used = cwFloatAny(cwQuotaUsed(program, global))
	s.Quota = cwFloatAny(global["quota"])
	s.UsageRate = cwFloatAny(global["ratio"])
	regions, _ := q["regions"].([]map[string]any)
	for _, r := range regions {
		m := cwMap(r[strings.ToLower(program)])
		used, quota, rate := cwFloatAny(cwQuotaUsed(program, m)), cwFloatAny(m["quota"]), cwFloatAny(m["ratio"])
		if used == nil && quota == nil {
			continue
		}
		exceeded := cwFloatAny(m["exceeded"])
		status := "未返回"
		if rate != nil {
			if *rate > 100 {
				status = "超额"
				s.ExceededRegions++
			} else if *rate == 100 {
				status = "已满额"
				s.FullRegions++
			} else {
				status = "未满额"
			}
		}
		caseStatus := "—"
		if rate != nil && *rate > 100 {
			caseStatus = "未关联事件"
		}
		s.Rows = append(s.Rows, cwQuotaAlertRow{Region: fmt.Sprint(r["region"]), Status: status, Owner: emptyFallback(fmt.Sprint(r["regional_poc"]), "待补负责人"), NotificationStatus: emptyFallback(fmt.Sprint(r["notification_status"]), "未发起"), CaseStatus: caseStatus, Used: used, Quota: quota, Exceeded: exceeded, UsageRate: rate})
	}
	sort.SliceStable(s.Rows, func(i, j int) bool {
		rank := func(v string) int {
			if v == "超额" {
				return 2
			}
			if v == "已满额" {
				return 1
			}
			return 0
		}
		if rank(s.Rows[i].Status) != rank(s.Rows[j].Status) {
			return rank(s.Rows[i].Status) > rank(s.Rows[j].Status)
		}
		ai, aj := -1.0, -1.0
		if s.Rows[i].UsageRate != nil {
			ai = *s.Rows[i].UsageRate
		}
		if s.Rows[j].UsageRate != nil {
			aj = *s.Rows[j].UsageRate
		}
		if ai != aj {
			return ai > aj
		}
		return s.Rows[i].Region < s.Rows[j].Region
	})
	if program == "ST" {
		s.Note = "区域配额合计 817；原表总计 816，保留 1 条来源差异。禁止使用 Account 分母 1925。无可靠历史数据，不绘制趋势。"
	} else {
		s.Note = "全球 Account-level 区域配额合计 6356；THT 无分母，不纳入。无可靠历史数据，不绘制趋势。"
	}
	return s
}

func cwEnrichAnalytics(x *cwAnalytics) {
	top, candidates := cwTop20Index(x.Filters)
	x.Top20Candidates = candidates
	riskSources := map[string]int{}
	for _, a := range x.Cases {
		sources := []string{}
		level, _ := evaluateWBAbsolute(a.Row.CCR, a.Row.NFS, a.Rule)
		if level == "critical" || level == "watch" {
			sources = append(sources, "absolute")
		}
		if top[cwCaseKey(a)] {
			sources = append(sources, "growth_top20")
		}
		if len(sources) == 0 {
			sources = []string{"unidentified"}
		}
		x.SourceByCase[a.ID] = sources
		for _, source := range sources {
			cwAdd(riskSources, source)
		}
	}
	x.RiskSource = cwCounts(riskSources)
	x.RuleSummaries = cwRuleSummaries(x, top)
	x.PriorityClients = cwPriorityClients(x.Cases, x.SourceByCase)
	x.BatchStatus = cwBatchStatus{Label: "完整批次"}
	if len(x.Filters.Jobs) == 0 {
		x.BatchStatus.Label = "阶段性结果"
		x.BatchStatus.Incomplete = true
	}
	for _, job := range x.Filters.Jobs {
		complete := job.Status == "ready" && job.Complete
		x.BatchStatus.Programs = append(x.BatchStatus.Programs, cwBatchProgramStatus{Program: job.Request.Program, Status: job.Status, Stage: job.Stage, Error: job.Error, Complete: complete})
		if !complete {
			x.BatchStatus.Label = "阶段性结果"
			x.BatchStatus.Incomplete = true
		}
	}
}

func cwAttachQuotaAlerts(x *cwAnalytics) {
	if x.Quota == nil {
		return
	}
	x.QuotaAlerts = cwQuotaAlerts{ET: cwBuildQuotaSection("ET", x.Quota, x.Filters), ST: cwBuildQuotaSection("ST", x.Quota, x.Filters)}
}
