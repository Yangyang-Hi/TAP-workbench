// CODE GENERATED FROM app/api/api.yaml BY tools/gen_api.py — DO NOT EDIT
package main

import "net/http"

// 本文件由 IDL 生成，登记 submissions 资源的路由契约。
// 业务逻辑写在 handler_submissions.go 的 handler 函数里，不要改本文件。
func init() {
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/submissions",
		Summary: "查询最近成功快照中的提报数据",
		Handler: submissionsList,
		Tags:    []string{"submissions"},
		QueryParams: []Param{
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
			{Name: "tier", Type: "string"},
			{Name: "ticket", Type: "string"},
			{Name: "limit", Type: "integer"},
		},
		Response: map[string]any{
			"data":   []any{},
			"total":  0,
			"status": "unavailable",
			"reason": "pending source",
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/submissions/quota",
		Summary: "按季度和时间窗聚合 ET、THT、ST 提报及 Quota 使用率",
		Handler: submissionsQuotaList,
		Tags:    []string{"submissions", "quota"},
		QueryParams: []Param{
			{Name: "quarter", Type: "string", Required: true, Description: "Q3 或 Q4"},
			{Name: "time_mode", Type: "string", Description: "weekly 或 custom；weekly 按批次截止日期计算季度累计，无批次时显式返回当前 QTD"},
			{Name: "batch_id", Type: "string", Description: "真实周度批次 ID；仅作为 Quota 累计截止日期，不使用单周起点"},
			{Name: "start_date", Type: "string", Description: "ET/THT 开始日期 YYYY-MM-DD"},
			{Name: "end_date", Type: "string", Description: "ET/THT 结束日期 YYYY-MM-DD"},
			{Name: "program", Type: "string", Description: "ET/THT/ST"},
			{Name: "region", Type: "string", Description: "提报标准区域"},
			{Name: "submitter", Type: "string", Description: "原提报人精确匹配，支持多提报人"},
			{Name: "advertiser_id", Type: "string", Description: "精确匹配 advertiser_id 或 linked_advertiser_ids"},
			{Name: "account_id", Type: "string", Description: "精确匹配 account_id 或 linked_account_ids"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status":        "partial",
				"quarter":       "Q4",
				"time":          map[string]any{},
				"side_effects":  false,
				"as_of":         map[string]any{},
				"st_snapshot":   map[string]any{},
				"global":        map[string]any{},
				"regions":       []any{},
				"weekly":        []any{},
				"errors":        map[string]any{},
				"source_status": map[string]any{},
				"diagnostics":   map[string]any{},
				"methodology":   map[string]any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/submissions/st-snapshots",
		Summary: "使用当前用户 JWT 运行时读取 ST Q4/Q3 权威 Sheet，校验后持久化快照",
		Handler: submissionsStSnapshotsCreate,
		Tags:    []string{"submissions", "st"},
		Response: map[string]any{
			"data": map[string]any{
				"status":       "success",
				"snapshots":    []any{},
				"last_attempt": map[string]any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/submissions/status",
		Summary: "查询提报数据质量与快照状态",
		Handler: submissionsStatusList,
		Tags:    []string{"submissions"},
		Response: map[string]any{
			"data": map[string]any{
				"status": "unavailable",
				"reason": "pending source",
			},
		},
	})
}
