package main

import (
	"errors"
	"fmt"
	"net/url"
	"strings"
	"time"
)

// Quota is a read-only live query. A weekly risk batch supplies its cutoff,
// not its one-week start: quota usage is cumulative from the quarter start.
type quotaWindow struct {
	Mode     string `json:"mode"`
	Basis    string `json:"basis"`
	BatchID  string `json:"batch_id,omitempty"`
	Quarter  string `json:"quarter"`
	Start    string `json:"start_date"`
	End      string `json:"end_date"`
	Timezone string `json:"timezone"`
}

var quotaPersistedBatches = wbPersistedBatches

func resolveQuotaWindow(q url.Values, now time.Time) (quotaWindow, error) {
	w := quotaWindow{Mode: strings.ToLower(strings.TrimSpace(q.Get("time_mode"))), Timezone: "Asia/Shanghai"}
	quarter := strings.ToUpper(strings.TrimSpace(q.Get("quarter")))
	if quarter != "" && quarter != "Q3" && quarter != "Q4" {
		return w, errors.New("quarter must be Q3 or Q4")
	}
	w.Start, w.End = strings.TrimSpace(q.Get("start_date")), strings.TrimSpace(q.Get("end_date"))
	if w.Mode != "" && w.Mode != "weekly" && w.Mode != "custom" {
		return w, errors.New("time_mode must be weekly or custom")
	}
	if w.Start != "" || w.End != "" || w.Mode == "custom" {
		if w.Start == "" || w.End == "" {
			return w, errors.New("自定义查询必须同时提供 start_date 和 end_date")
		}
		if _, ok := parseDate(w.Start); !ok {
			return w, errors.New("invalid start_date")
		}
		if _, ok := parseDate(w.End); !ok || w.End < w.Start {
			return w, errors.New("invalid end_date")
		}
		w.Mode, w.Basis = "custom", "selected_window"
		w.Quarter = quarter
		if w.Quarter == "" {
			t, _ := time.Parse("2006-01-02", w.End)
			w.Quarter = fmt.Sprintf("Q%d", (int(t.Month())-1)/3+1)
		}
	} else {
		w.Mode = "weekly"
		batches, _, err := quotaPersistedBatches()
		if err != nil {
			return w, fmt.Errorf("读取周度批次截止日期失败: %w", err)
		}
		wanted := strings.TrimSpace(q.Get("batch_id"))
		var selected *wbBatchContract
		for i := range batches {
			if wanted == "" || batches[i].BatchID == wanted {
				selected = &batches[i]
				break
			}
		}
		cutoff := now.In(cwLocation())
		w.Basis = "live_qtd_no_weekly_batch"
		if selected != nil {
			cutoff, err = time.ParseInLocation("2006-01-02", selected.MetricEnd, cwLocation())
			if err != nil {
				return w, errors.New("周度批次的 metric_end_date 无效")
			}
			w.BatchID, w.Basis = selected.BatchID, "quarter_to_batch_cutoff"
		} else if wanted != "" {
			return w, errors.New("指定周度批次不存在，请刷新批次列表")
		}
		month := (int(cutoff.Month())-1)/3*3 + 1
		w.Quarter = fmt.Sprintf("Q%d", (month-1)/3+1)
		w.Start = time.Date(cutoff.Year(), time.Month(month), 1, 0, 0, 0, 0, cwLocation()).Format("2006-01-02")
		w.End = cutoff.Format("2006-01-02")
	}
	if w.Quarter != "Q3" && w.Quarter != "Q4" {
		return w, errors.New("当前 ST 季度来源只配置 Q3/Q4，所选日期不在支持范围")
	}
	return w, nil
}
