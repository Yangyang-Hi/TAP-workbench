package main

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"gopkg.in/yaml.v3"
)

const thtProgram = "Temporary High Trust (THT) - Advertiser ID"

type fieldConfig struct {
	DimMetID     string `yaml:"dim_met_id" json:"column_id,omitempty"`
	UniqueID     string `yaml:"unique_id" json:"unique_id,omitempty"`
	Operator     string `yaml:"operator" json:"operator,omitempty"`
	Optional     bool   `yaml:"optional" json:"optional,omitempty"`
	Nullable     bool   `yaml:"nullable" json:"nullable"`
	SourceName   string `yaml:"source_name" json:"alias,omitempty"`
	ExpectedType string `yaml:"expected_type" json:"expected_type,omitempty"`
	Meaning      string `yaml:"meaning" json:"meaning,omitempty"`
	Status       string `yaml:"status" json:"status,omitempty"`
}
type sourceIdentity struct {
	AppID       int    `yaml:"app_id" json:"app_id"`
	DashboardID int    `yaml:"dashboard_id" json:"dashboard_id,omitempty"`
	SID         int    `yaml:"sid" json:"sid"`
	RID         int    `yaml:"rid" json:"rid"`
	TID         int    `yaml:"tid" json:"tid,omitempty"`
	HistoryID   int    `yaml:"history_id" json:"history_id,omitempty"`
	Region      string `yaml:"region" json:"region,omitempty"`
	BaseURL     string `yaml:"base_url" json:"base_url,omitempty"`
	QueryMode   string `yaml:"query_mode" json:"query_mode"`
	IDDimension string `yaml:"id_dimension" json:"id_dimension,omitempty"`
}
type queryProfile struct {
	GroupBy  []string `yaml:"group_by" json:"group_by,omitempty"`
	Filters  []string `yaml:"filters" json:"filters,omitempty"`
	Metrics  []string `yaml:"metrics" json:"metrics,omitempty"`
	Fallback string   `yaml:"fallback" json:"fallback,omitempty"`
}
type windowAuditConfig struct {
	ReportID   int      `yaml:"report_id" json:"report_id"`
	HardLimit  int      `yaml:"hard_limit" json:"hard_limit"`
	SplitOrder []string `yaml:"split_order" json:"split_order"`
}

type sourceConfig struct {
	Kind                string                 `yaml:"kind"`
	Grain               string                 `yaml:"grain"`
	Consumers           []string               `yaml:"consumers"`
	FieldRoles          map[string]string      `yaml:"field_roles"`
	SupportedDimensions []string               `yaml:"supported_dimensions"`
	Aggregation         map[string]string      `yaml:"aggregation"`
	TimeSemantics       string                 `yaml:"time_semantics"`
	Enabled             bool                   `yaml:"enabled"`
	Label               string                 `yaml:"label"`
	AppID               int                    `yaml:"app_id"`
	SID                 int                    `yaml:"sid"`
	RID                 int                    `yaml:"rid"`
	TID                 int                    `yaml:"tid"`
	Identity            sourceIdentity         `yaml:"identity" json:"identity"`
	QueryProfile        queryProfile           `yaml:"query_profile" json:"query_profile"`
	RequiresProbe       bool                   `yaml:"requires_probe" json:"requires_probe"`
	ContractStatus      string                 `yaml:"contract_status" json:"contract_status,omitempty"`
	ContractNote        string                 `yaml:"contract_note" json:"contract_note,omitempty"`
	ReuseFieldsFrom     string                 `yaml:"reuse_fields_from"`
	WindowAudit         windowAuditConfig      `yaml:"window_audit" json:"window_audit"`
	Fields              map[string]fieldConfig `yaml:"fields"`
}
type dataSourceConfig struct {
	Aeolus struct {
		Host      string `yaml:"-"`
		HostEnv   string `yaml:"host_env"`
		QueryPath string `yaml:"query_path"`
		Auth      struct {
			ClientIDEnv     string `yaml:"client_id_env"`
			ClientSecretEnv string `yaml:"client_secret_env"`
			JWTPath         string `yaml:"jwt_path"`
			AuthHeader      string `yaml:"auth_header"`
			AuthScheme      string `yaml:"auth_scheme"`
		} `yaml:"auth"`
	} `yaml:"aeolus"`
	Sources map[string]sourceConfig `yaml:"sources"`
}
type snapshotState struct {
	Sources          map[string][]map[string]any `json:"sources,omitempty"` // legacy read compatibility
	AggregateSources map[string][]map[string]any `json:"aggregate_sources,omitempty"`
	DetailSources    map[string][]map[string]any `json:"detail_sources,omitempty"`
	UpdatedAt        map[string]string           `json:"updated_at"`
	Business         map[string]sourceSnapshot   `json:"business,omitempty"`
}
type sourceStatus struct {
	Source                string   `json:"source"`
	Label                 string   `json:"label"`
	Enabled               bool     `json:"enabled"`
	AppID                 int      `json:"app_id"`
	SID                   int      `json:"sid"`
	RID                   int      `json:"rid"`
	MissingDimMetIDs      []string `json:"missing_dim_met_ids"`
	QueryPathConfigured   bool     `json:"query_path_configured"`
	CredentialsConfigured bool     `json:"credentials_configured"`
	ReadyForLiveQuery     bool     `json:"ready_for_live_query"`
	LastSyncedAt          string   `json:"last_synced_at,omitempty"`
}

var stateMu sync.RWMutex

// snapshotCache avoids decoding and normalizing a large JSON snapshot on every
// dashboard read. The file is atomically replaced by sync jobs, so mtime and
// size form a cheap cache version key.
var snapshotCacheMu sync.Mutex
var snapshotCache snapshotState
var snapshotCachePath string
var snapshotCacheModTime int64
var snapshotCacheSize int64
var snapshotCacheValid bool

func loadDataSourceConfig() (dataSourceConfig, error) {
	var c dataSourceConfig
	b, err := os.ReadFile(filepath.Join(pluginDir, "config", "data_sources.yaml"))
	if err != nil {
		return c, err
	}
	if err = yaml.Unmarshal(b, &c); err != nil {
		return c, err
	}
	// Identity is the canonical key; mirror legacy top-level IDs for old callers/configs.
	for name, source := range c.Sources {
		if source.Identity.AppID == 0 {
			source.Identity.AppID = source.AppID
		}
		if source.Identity.SID == 0 {
			source.Identity.SID = source.SID
		}
		if source.Identity.RID == 0 {
			source.Identity.RID = source.RID
		}
		if source.Identity.TID == 0 {
			source.Identity.TID = source.TID
		}
		if source.Identity.QueryMode == "" {
			source.Identity.QueryMode = source.Kind
		}
		source.AppID, source.SID, source.RID, source.TID = source.Identity.AppID, source.Identity.SID, source.Identity.RID, source.Identity.TID
		c.Sources[name] = source
	}
	override, err := loadInstanceConfig()
	if err != nil {
		return c, err
	}
	if override.Host != "" {
		c.Aeolus.Host = override.Host
	}
	if override.QueryPath != "" {
		c.Aeolus.QueryPath = override.QueryPath
	}
	return c, nil
}
func loadRules() map[string]any {
	var v map[string]any
	b, err := os.ReadFile(filepath.Join(pluginDir, "config", "rules.yaml"))
	if err == nil {
		_ = yaml.Unmarshal(b, &v)
	}
	return v
}
func effectiveFields(c dataSourceConfig, s sourceConfig) map[string]fieldConfig {
	if s.ReuseFieldsFrom != "" {
		return c.Sources[s.ReuseFieldsFrom].Fields
	}
	return s.Fields
}
func sourceReadiness(c dataSourceConfig, name string) (sourceStatus, error) {
	s, ok := c.Sources[name]
	if !ok {
		return sourceStatus{}, errors.New("unknown source")
	}
	miss := []string{}
	for n, f := range effectiveSourceFields(c, name) {
		if !f.Optional && strings.TrimSpace(f.DimMetID) == "" {
			miss = append(miss, n)
		}
	}
	sort.Strings(miss)
	runtimeCfg, err := effectiveRuntimeConfig(c, "")
	if err != nil {
		return sourceStatus{}, err
	}
	state, err := loadRuntimeState()
	if err != nil {
		return sourceStatus{}, err
	}
	qp := strings.TrimSpace(runtimeCfg.QueryPath) != ""
	credentialsConfigured := runtimeCfg.Credentials.CredentialsStatus == "configured"
	st := sourceStatus{Source: name, Label: s.Label, Enabled: s.Enabled, AppID: s.AppID, SID: s.SID, RID: s.RID, MissingDimMetIDs: miss, QueryPathConfigured: qp, CredentialsConfigured: credentialsConfigured}
	if usesSavedReportQuery(s) {
		st.ReadyForLiveQuery = st.Enabled && st.RID > 0
	} else {
		st.ReadyForLiveQuery = st.Enabled && authenticationCanQuery(state.Authentication) && sourceDataQueryStatus(c, name, state) != "not_configured"
	}
	snap, _ := loadSnapshots()
	st.LastSyncedAt = snap.UpdatedAt[name]
	return st, nil
}
func envOr(v, f string) string {
	if strings.TrimSpace(v) == "" {
		return f
	}
	return v
}
func snapshotPath() (string, error) {
	d, err := resolveDataDir()
	if err != nil {
		return "", err
	}
	if err = os.MkdirAll(d, 0700); err != nil {
		return "", err
	}
	return filepath.Join(d, "tap_snapshots.json"), nil
}
func loadSnapshots() (snapshotState, error) {
	p, e := snapshotPath()
	if e != nil {
		return emptySnapshotState(), e
	}
	stateMu.RLock()
	defer stateMu.RUnlock()
	info, e := os.Stat(p)
	if errors.Is(e, os.ErrNotExist) {
		return emptySnapshotState(), nil
	}
	if e != nil {
		return emptySnapshotState(), e
	}

	snapshotCacheMu.Lock()
	defer snapshotCacheMu.Unlock()
	modTime := info.ModTime().UnixNano()
	if snapshotCacheValid && snapshotCachePath == p && snapshotCacheModTime == modTime && snapshotCacheSize == info.Size() {
		return cloneSnapshotState(snapshotCache), nil
	}

	b, e := os.ReadFile(p)
	if e != nil {
		return emptySnapshotState(), e
	}
	st := emptySnapshotState()
	if e = json.Unmarshal(b, &st); e != nil {
		return st, e
	}
	initializeSnapshotState(&st)
	// A snapshot is consumable only for the exact configured identity. Config
	// changes must not leave old RID/SID data looking ready. Keep unrelated
	// cached sources intact; stale entries are replaced by the next source sync.
	if cfg, cfgErr := loadDataSourceConfig(); cfgErr == nil {
		for name, snapshot := range st.Business {
			source, configured := cfg.Sources[name]
			if !configured {
				continue
			}
			expected := sourceIdentityKey(source)
			stale := snapshot.IdentityKey != expected
			if snapshot.ReportID != 0 && snapshot.ReportID != source.RID {
				stale = true
			}
			if snapshot.DatasetID != 0 && snapshot.DatasetID != source.SID {
				stale = true
			}
			if !stale {
				continue
			}
			snapshot.Status = "stale"
			snapshot.RuntimeReady = false
			snapshot.Complete = false
			snapshot.BusinessPayload = nil
			st.Business[name] = snapshot
			delete(st.AggregateSources, name)
			delete(st.DetailSources, name)
			delete(st.Sources, name)
		}
	}
	for _, name := range []string{"tap_account", "submission", "revenue", "p0_risk", "client_ccr_nfs_detail", "approval"} {
		if _, exists := st.AggregateSources[name]; !exists && len(st.Sources[name]) > 0 {
			st.AggregateSources[name] = st.Sources[name]
		}
		rows := st.AggregateSources[name]
		for index, row := range rows {
			raw, ok := row["_raw"].(map[string]any)
			if ok {
				rows[index] = fillAggregateSemanticFallback(name, raw, row)
			}
		}
		st.AggregateSources[name] = rows
		if snapshot, exists := st.Business[name]; exists {
			snapshot.Kind = "aggregate"
			snapshot.BusinessPayload = buildBusinessPayload(name, rows)
			st.Business[name] = snapshot
		}
	}
	for name, rows := range st.DetailSources {
		for i, row := range rows {
			rows[i] = normalizeDetailRow(row)
		}
		st.DetailSources[name] = rows
	}
	enrichSubmissionDimensions(st.DetailSources["submission_detail"], st.AggregateSources["tap_account"])
	enrichSubmissionDimensions(st.DetailSources["protection"], st.AggregateSources["tap_account"])
	enrichSubmissionDimensions(st.DetailSources["tht_detail"], st.AggregateSources["tap_account"])

	snapshotCache = st
	snapshotCachePath = p
	snapshotCacheModTime = modTime
	snapshotCacheSize = info.Size()
	snapshotCacheValid = true
	return cloneSnapshotState(st), nil
}

func emptySnapshotState() snapshotState {
	return snapshotState{
		Sources:          map[string][]map[string]any{},
		AggregateSources: map[string][]map[string]any{},
		DetailSources:    map[string][]map[string]any{},
		UpdatedAt:        map[string]string{},
		Business:         map[string]sourceSnapshot{},
	}
}

func initializeSnapshotState(st *snapshotState) {
	if st.Sources == nil {
		st.Sources = map[string][]map[string]any{}
	}
	if st.AggregateSources == nil {
		st.AggregateSources = map[string][]map[string]any{}
	}
	if st.DetailSources == nil {
		st.DetailSources = map[string][]map[string]any{}
	}
	if st.UpdatedAt == nil {
		st.UpdatedAt = map[string]string{}
	}
	if st.Business == nil {
		st.Business = map[string]sourceSnapshot{}
	}
}

// cloneSnapshotState copies mutable top-level maps. Normalized row slices are
// immutable during snapshot reads and are intentionally shared.
func cloneSnapshotState(st snapshotState) snapshotState {
	clone := emptySnapshotState()
	for name, rows := range st.Sources {
		clone.Sources[name] = rows
	}
	for name, rows := range st.AggregateSources {
		clone.AggregateSources[name] = rows
	}
	for name, rows := range st.DetailSources {
		clone.DetailSources[name] = rows
	}
	for name, updatedAt := range st.UpdatedAt {
		clone.UpdatedAt[name] = updatedAt
	}
	for name, business := range st.Business {
		clone.Business[name] = business
	}
	return clone
}

func saveSource(name string, rows []map[string]any) error {
	stateMu.Lock()
	defer stateMu.Unlock()
	p, e := snapshotPath()
	if e != nil {
		return e
	}
	st := snapshotState{Sources: map[string][]map[string]any{}, AggregateSources: map[string][]map[string]any{}, DetailSources: map[string][]map[string]any{}, UpdatedAt: map[string]string{}, Business: map[string]sourceSnapshot{}}
	if b, er := os.ReadFile(p); er == nil {
		_ = json.Unmarshal(b, &st)
	}
	if st.Sources == nil {
		st.Sources = map[string][]map[string]any{}
	}
	if st.AggregateSources == nil {
		st.AggregateSources = map[string][]map[string]any{}
	}
	if st.DetailSources == nil {
		st.DetailSources = map[string][]map[string]any{}
	}
	if st.UpdatedAt == nil {
		st.UpdatedAt = map[string]string{}
	}
	config, configErr := loadDataSourceConfig()
	if configErr != nil {
		return configErr
	}
	source, exists := config.Sources[name]
	if !exists {
		return fmt.Errorf("unknown source: %s", name)
	}
	if source.Kind == "detail" {
		st.DetailSources[name] = rows
	} else {
		st.AggregateSources[name] = rows
	}
	st.UpdatedAt[name] = time.Now().UTC().Format(time.RFC3339)
	b, e := json.MarshalIndent(st, "", "  ")
	if e != nil {
		return e
	}
	return os.WriteFile(p, b, 0600)
}

func queryAeolus(ctx context.Context, name string) ([]map[string]any, error) {
	c, e := loadDataSourceConfig()
	if e != nil {
		return nil, e
	}
	status, e := sourceReadiness(c, name)
	if e != nil {
		return nil, e
	}
	if !status.ReadyForLiveQuery {
		return nil, fmt.Errorf("source %s is not configured for live data query", name)
	}
	s := c.Sources[name]
	runtimeCfg, err := effectiveRuntimeConfig(c, "")
	if err != nil {
		return nil, err
	}
	ids := []string{}
	for _, f := range effectiveSourceFields(c, name) {
		if strings.TrimSpace(f.DimMetID) != "" {
			ids = append(ids, strings.TrimSpace(f.DimMetID))
		}
	}
	payload := map[string]any{"appId": s.AppID, "sid": s.SID, "rid": s.RID, "fields": ids, "filters": map[string]any{}}
	raw, errInfo := postAeolusJSONWithRetry(ctx, runtimeCfg, runtimeCfg.QueryPath, payload)
	if errInfo != nil {
		return nil, fmt.Errorf("aeolus query failed: %s", errInfo.ErrorType)
	}
	var body any
	if err = json.Unmarshal(raw, &body); err != nil {
		return nil, err
	}
	rows := findRows(body)
	if rows == nil {
		return nil, errors.New("aeolus response does not expose rows in a recognized shape")
	}
	canonical := canonicalize(rows, effectiveSourceFields(c, name))
	if s.Kind == "detail" {
		for i, row := range canonical {
			canonical[i] = normalizeDetailRow(row)
		}
	}
	return canonical, nil
}
func nestedString(v map[string]any, path ...string) string {
	var cur any = v
	for _, p := range path {
		m, ok := cur.(map[string]any)
		if !ok {
			return ""
		}
		cur = m[p]
	}
	return asString(cur)
}
func findRows(v any) []map[string]any {
	m, ok := v.(map[string]any)
	if !ok {
		return nil
	}
	for _, candidate := range []any{m["rows"], m["data"]} {
		if a, ok := candidate.([]any); ok {
			return mapsFromAny(a)
		}
		if mm, ok := candidate.(map[string]any); ok {
			if a, ok := mm["rows"].([]any); ok {
				return mapsFromAny(a)
			}
		}
	}
	return nil
}
func mapsFromAny(a []any) []map[string]any {
	out := make([]map[string]any, 0, len(a))
	for _, v := range a {
		if m, ok := v.(map[string]any); ok {
			out = append(out, m)
		}
	}
	return out
}
func canonicalize(rows []map[string]any, fields map[string]fieldConfig) []map[string]any {
	out := make([]map[string]any, 0, len(rows))
	for _, row := range rows {
		r := map[string]any{}
		for key, spec := range fields {
			for _, candidate := range []string{key, spec.SourceName, spec.DimMetID} {
				if candidate != "" {
					if v, ok := row[candidate]; ok {
						r[key] = v
						break
					}
				}
			}
		}
		out = append(out, r)
	}
	return out
}

func isApproved(r map[string]any) bool {
	v := strings.ToUpper(strings.TrimSpace(asString(r["final_result"])))
	return v == "APPROVE" || v == "PASS"
}
func tierMatches(r map[string]any, tier string) bool {
	if !isApproved(r) {
		return false
	}
	program := strings.ToUpper(asString(r["program_type"]))
	if program == "" || program == "UNKNOWN" {
		program = resolveProgramType(r)
	}
	return program == strings.ToUpper(tier)
}
func distinctCount(rows []map[string]any, key string, pred func(map[string]any) bool) int {
	seen := map[string]bool{}
	for _, r := range rows {
		if pred == nil || pred(r) {
			if v := asString(r[key]); v != "" {
				seen[v] = true
			}
		}
	}
	return len(seen)
}
func number(v any) (float64, bool) {
	switch x := v.(type) {
	case float64:
		return x, true
	case int:
		return float64(x), true
	case json.Number:
		n, e := x.Float64()
		return n, e == nil
	case string:
		n, e := strconv.ParseFloat(strings.TrimSpace(x), 64)
		return n, e == nil
	}
	return 0, false
}
func meanSum(rows []map[string]any, key string, mean bool) any {
	sum := 0.0
	n := 0
	for _, r := range rows {
		if v, ok := number(r[key]); ok {
			sum += v
			n++
		}
	}
	if n == 0 {
		return nil
	}
	if mean {
		return sum / float64(n)
	}
	return sum
}
func readQuota() []map[string]any {
	f, e := os.Open(filepath.Join(pluginDir, "data", "quota_config.csv"))
	if e != nil {
		return nil
	}
	defer f.Close()
	rr := csv.NewReader(f)
	headers, e := rr.Read()
	if e != nil {
		return nil
	}
	out := []map[string]any{}
	for {
		row, e := rr.Read()
		if e == io.EOF {
			break
		}
		if e != nil {
			break
		}
		m := map[string]any{}
		for i, h := range headers {
			m[h] = row[i]
		}
		out = append(out, m)
	}
	return out
}
func parseDate(v any) (time.Time, bool) {
	s := strings.TrimSpace(asString(v))
	for _, layout := range []string{time.RFC3339, "2006-01-02 15:04:05", "2006-01-02"} {
		if t, e := time.Parse(layout, s); e == nil {
			return t, true
		}
	}
	// Aeolus custom-week labels look like 2026-W38(09/21~09/27).
	if len(s) >= 14 && len(s) >= 4 {
		year := s[:4]
		if open := strings.Index(s, "("); open >= 0 && len(s) >= open+6 {
			monthDay := strings.ReplaceAll(s[open+1:open+6], "/", "-")
			if t, e := time.Parse("2006-01-02", year+"-"+monthDay); e == nil {
				return t, true
			}
		}
	}
	return time.Time{}, false
}
func ruleTopN(tier string) int {
	rules := loadRules()
	root, _ := rules["rules"].(map[string]any)
	section, _ := root[strings.ToLower(tier)].(map[string]any)
	key := "high_ccr_rank"
	if tier == "THT" {
		key = "weekly_rank"
	}
	rank, _ := section[key].(map[string]any)
	if n, ok := number(rank["top_n"]); ok {
		return int(n)
	}
	return 20
}
func rankRisk(rows []map[string]any, tier string) []map[string]any {
	idKey := "account_id"
	metric := "p0_ccr"
	if tier == "THT" {
		idKey = "advertiser_id"
		metric = "p0_nfs"
	}
	type item struct {
		r map[string]any
		v float64
	}
	groups := map[string][]item{}
	for _, r := range rows {
		if asString(r[idKey]) == "" {
			continue
		}
		v, ok := number(r[metric])
		if !ok {
			continue
		}
		region := asString(r["region"])
		groups[region] = append(groups[region], item{r, v})
	}
	out := []map[string]any{}
	for region, items := range groups {
		sort.Slice(items, func(i, j int) bool { return items[i].v > items[j].v })
		for i, x := range items {
			if i >= ruleTopN(tier) {
				break
			}
			cp := map[string]any{}
			for k, v := range x.r {
				cp[k] = v
			}
			cp["region"] = region
			cp["rank"] = i + 1
			out = append(out, cp)
		}
	}
	return out
}
