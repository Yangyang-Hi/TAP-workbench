package main

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func resetWBComparisonCache() {
	wbComparisonCache.Lock()
	defer wbComparisonCache.Unlock()
	wbComparisonCache.items = map[string]wbComparisonCacheEntry{}
}

func TestComparisonWindowUsesHalfOpenPolicyAndInclusiveSourceFilters(t *testing.T) {
	window, err := wbBuildComparisonWindow("THT", "2026-10-14 00:00:00", time.Date(2026, 10, 22, 0, 0, 0, 0, cwLocation()))
	if err != nil {
		t.Fatal(err)
	}
	if window.PreStart != "2026-10-07" || window.PreEnd != "2026-10-13" || window.PreEndExclusive != "2026-10-14" || window.PostStart != "2026-10-14" || window.PostEnd != "2026-10-20" || window.PostEndExclusive != "2026-10-21" || !window.Complete {
		t.Fatalf("unexpected window: %+v", window)
	}
}

func TestTHTRealComparisonPersistsMetricsAndTrace(t *testing.T) {
	resetWBComparisonCache()
	old := wbQueryTHTBatch
	defer func() { wbQueryTHTBatch = old; resetWBComparisonCache() }()
	calls := 0
	wbQueryTHTBatch = func(_ context.Context, _ *http.Request, ids []string, start, end string) (map[string][]wbBatchMetric, error) {
		calls++
		ccr, nfs := 5.0, 10.0
		if start == "2026-10-14" {
			ccr, nfs = 12, 20
		}
		return map[string][]wbBatchMetric{ids[0]: {{Status: "success", CCR: &ccr, NFS: &nfs, RequestID: start + ":request"}}}, nil
	}
	row := wbRow{ID: "row", Program: "THT", Level: "critical", Member: wbMember{AdvertiserID: "7563583641067143184", Start: "2026-10-14"}}
	now := time.Date(2026, 10, 22, 0, 0, 0, 0, cwLocation())
	out := wbApplyRealComparisons(context.Background(), httptest.NewRequest(http.MethodGet, "/api/live", nil), []wbRow{row}, now)
	comparison := out[0].Comparison
	if comparison.Status != "available" || comparison.ProtectionCCRGrowthPct == nil || *comparison.ProtectionCCRGrowthPct != 140 || comparison.WoWGrowthPct != nil || comparison.PreNFS == nil || *comparison.PreNFS != 10 || comparison.PostNFS == nil || *comparison.PostNFS != 20 {
		t.Fatalf("unexpected comparison: %+v", comparison)
	}
	if comparison.Source["grain"] != "account_advertiser_window" || calls != 2 {
		t.Fatalf("missing source audit or calls=%d: %+v", calls, comparison.Source)
	}
	if comparison.Source["query_status"] != "success" {
		t.Fatalf("missing terminal comparison query status: %+v", comparison.Source)
	}
}

func TestETAndSTComparisonsUseExplicitIncompleteWindows(t *testing.T) {
	now := time.Date(2026, 10, 22, 0, 0, 0, 0, cwLocation())
	rows := []wbRow{{Program: "ET", Level: "critical", Member: wbMember{Start: "2026-10-20"}}, {Program: "ST", Level: "critical", Member: wbMember{Start: "2026-10-01"}}}
	out := wbApplyRealComparisons(context.Background(), httptest.NewRequest(http.MethodGet, "/api/live", nil), rows, now)
	if out[0].Comparison.Status != "window_incomplete" || out[1].Comparison.Status != "unavailable" || out[1].Comparison.MissingReason != "st_q3_end_date_business_definition_unconfirmed" {
		t.Fatalf("incomplete and unconfirmed windows were not explicit: %+v", out)
	}
}

func TestTHTComparisonsQueryOnlyMatchedRowsAndPreserveNonRiskCurrentMetrics(t *testing.T) {
	old := wbQueryTHTBatch
	defer func() { wbQueryTHTBatch = old }()
	calls := 0
	queried := map[string]int{}
	wbQueryTHTBatch = func(_ context.Context, _ *http.Request, ids []string, start, end string) (map[string][]wbBatchMetric, error) {
		calls++
		out := map[string][]wbBatchMetric{}
		for _, id := range ids {
			queried[id]++
			value := 7.0
			if start == "2026-10-14" {
				value = 15
			}
			nfs := 60.0
			out[id] = []wbBatchMetric{{Status: "success", CCR: &value, NFS: &nfs, RequestID: start + ":" + id}}
		}
		return out, nil
	}
	rows := make([]wbRow, 0, 5402)
	for i := 0; i < 5402; i++ {
		id := fmt.Sprintf("77%017d", i)
		level := "healthy"
		if i < 33 {
			level = "critical"
		}
		rows = append(rows, wbRow{
			Program: "THT", Level: level, CCR: f64(42), NFS: f64(84), Revenue: f64(126),
			Member:      wbMember{AdvertiserID: id, TicketID: "ticket-" + id, Start: "2026-10-14"},
			Advertisers: []wbAdvertiserEvidence{{AdvertiserID: id}},
		})
	}
	out := wbApplyRealComparisons(context.Background(), httptest.NewRequest(http.MethodGet, "/api/live", nil), rows, time.Date(2026, 10, 22, 0, 0, 0, 0, cwLocation()))
	if calls != 2 { // 33 matched rows fit one chunk; pre + post.
		t.Fatalf("calls=%d want=2", calls)
	}
	for i, row := range out {
		id := row.Member.AdvertiserID
		if i < 33 {
			if queried[id] != 2 || row.Comparison.Status != "available" {
				t.Fatalf("matched row %d was not completely queried: count=%d comparison=%+v", i, queried[id], row.Comparison)
			}
			continue
		}
		if queried[id] != 0 || row.CCR == nil || *row.CCR != 42 || row.NFS == nil || *row.NFS != 84 || row.Revenue == nil || *row.Revenue != 126 {
			t.Fatalf("non-risk current metrics changed or row was queried: row=%d queried=%d value=%+v", i, queried[id], row)
		}
		if row.Comparison.Status != metricNotApplicable || row.Comparison.MissingReason != wbNonRiskComparisonReason || row.Comparison.PreCCR != nil || row.Comparison.PostCCR != nil || row.Comparison.ProtectionCCRGrowthPct != nil {
			t.Fatalf("non-risk comparison was fabricated: row=%d comparison=%+v", i, row.Comparison)
		}
	}
}

func TestTHTComparisonCancellationStopsImmediately(t *testing.T) {
	old := wbQueryTHTBatch
	defer func() { wbQueryTHTBatch = old }()
	ctx, cancel := context.WithCancel(context.Background())
	calls := 0
	wbQueryTHTBatch = func(queryCtx context.Context, _ *http.Request, _ []string, _, _ string) (map[string][]wbBatchMetric, error) {
		calls++
		cancel()
		<-queryCtx.Done()
		return nil, queryCtx.Err()
	}
	row := wbRow{Program: "THT", Level: "critical", Member: wbMember{AdvertiserID: "7100000000000000001", Start: "2026-10-14"}}
	started := time.Now()
	out := wbApplyRealComparisons(ctx, httptest.NewRequest(http.MethodGet, "/api/live", nil), []wbRow{row}, time.Date(2026, 10, 22, 0, 0, 0, 0, cwLocation()))
	if elapsed := time.Since(started); elapsed > time.Second {
		t.Fatalf("cancellation took too long: %s", elapsed)
	}
	if calls != 1 || out[0].Comparison.Status != metricFailed || out[0].Comparison.MissingReason != "comparison_source_error" {
		t.Fatalf("cancellation was retried or not recorded: calls=%d comparison=%+v", calls, out[0].Comparison)
	}
}

func TestComparisonCacheKeyIncludesAuthorityGrainWindowAndIDSet(t *testing.T) {
	a := wbComparisonCacheKey("tht_current_ccr_nfs", 2942519, "account_advertiser_window", "advertiser_id", []string{"2", "1"}, "2026-10-01", "2026-10-07")
	b := wbComparisonCacheKey("tht_current_ccr_nfs", 2942519, "account_advertiser_window", "advertiser_id", []string{"1", "2"}, "2026-10-01", "2026-10-07")
	c := wbComparisonCacheKey("weekly_pair_revenue", 2942918, "account_advertiser_window", "advertiser_id", []string{"1", "2"}, "2026-10-01", "2026-10-07")
	if a != b || a == c {
		t.Fatalf("cache key omitted identity dimensions: a=%q b=%q c=%q", a, b, c)
	}
}

func TestSuccessfulComparisonMetricFactsCoverNullZeroAndMinusHundred(t *testing.T) {
	now := time.Date(2026, 10, 22, 0, 0, 0, 0, cwLocation())
	anchor := "2026-10-14"
	nullPre := wbSuccessfulComparison("ET", anchor, nil, f64(2), now)
	if nullPre.PreCCRFact.Status != metricSourceNull || nullPre.PostCCRFact.Status != metricAvailable || nullPre.IncreaseFact.Status != metricSourceNull || nullPre.IncreaseFact.Reason != "源指标缺失" {
		t.Fatalf("success null semantics failed: %+v", nullPre)
	}
	zeroPre := wbSuccessfulComparison("ET", anchor, f64(0), f64(2), now)
	if zeroPre.PreCCRFact.Status != metricAvailable || zeroPre.IncreaseFact.Status != metricNotApplicable || zeroPre.IncreaseFact.Reason != "基数为零、无法计算增幅" {
		t.Fatalf("zero baseline semantics failed: %+v", zeroPre)
	}
	zeroPost := wbSuccessfulComparison("ET", anchor, f64(2), f64(0), now)
	if zeroPost.IncreaseFact.Status != metricAvailable || zeroPost.IncreaseFact.Value == nil || *zeroPost.IncreaseFact.Value != -100 {
		t.Fatalf("positive-to-zero semantics failed: %+v", zeroPost)
	}
	failed := wbUnavailableComparison("ET", anchor, "permanent field parse failure", now)
	if failed.PreCCRFact.Status != metricFailed || failed.PreCCRFact.Status == metricSourceNull {
		t.Fatalf("parse failure disguised as source null: %+v", failed)
	}
}

func TestETComparisonsCoverAllApplicableRowsInWindowBatches(t *testing.T) {
	old := wbAccountComparisonQuery
	defer func() { wbAccountComparisonQuery = old }()
	calls := 0
	wbAccountComparisonQuery = func(_ context.Context, _ *http.Request, ids []string, start, _ string, _, program string) (map[string]wbBatchMetric, error) {
		calls++
		if program != "ET" || len(ids) != 2 {
			t.Fatalf("unexpected grouped query program=%s ids=%v", program, ids)
		}
		out := map[string]wbBatchMetric{}
		for _, id := range ids {
			value := 100.0
			if start == "2026-10-10" {
				value = 250
			}
			out[id] = wbBatchMetric{Status: "success", CCR: &value, RequestID: start + ":request"}
		}
		return out, nil
	}
	rows := []wbRow{
		{Program: "ET", Level: "healthy", Member: wbMember{AccountID: "7100000000000000001", Start: "2026-10-10"}},
		{Program: "ET", Level: "critical", Member: wbMember{AccountID: "7100000000000000002", Start: "2026-10-10"}},
	}
	out := wbApplyRealComparisons(context.Background(), httptest.NewRequest(http.MethodGet, "/api/live", nil), rows, time.Date(2026, 10, 18, 0, 0, 0, 0, cwLocation()))
	if calls != 2 {
		t.Fatalf("all ET accounts with the same window must use one pre and one post batch, calls=%d", calls)
	}
	for i, row := range out {
		if row.Comparison.Status != metricAvailable || row.Comparison.CCRGrowthPct == nil || *row.Comparison.CCRGrowthPct != 150 {
			t.Fatalf("ET row %d was not enriched independently of risk gate: %+v", i, row.Comparison)
		}
	}
}

func TestETComparisonPersistsSourceNullAsTerminal(t *testing.T) {
	old := wbAccountComparisonQuery
	defer func() { wbAccountComparisonQuery = old }()
	wbAccountComparisonQuery = func(_ context.Context, _ *http.Request, ids []string, _, _ string, _, _ string) (map[string]wbBatchMetric, error) {
		return map[string]wbBatchMetric{ids[0]: {Status: "no_data", RequestID: "source-null"}}, nil
	}
	row := wbRow{Program: "ET", Level: "healthy", Member: wbMember{AccountID: "7100000000000000001", Start: "2026-10-10"}}
	out := wbApplyRealComparisons(context.Background(), httptest.NewRequest(http.MethodGet, "/api/live", nil), []wbRow{row}, time.Date(2026, 10, 18, 0, 0, 0, 0, cwLocation()))[0]
	if out.Comparison.Status != metricSourceNull || out.Comparison.PreCCRFact.Status != metricSourceNull || out.Comparison.PostCCRFact.Status != metricSourceNull || out.Comparison.Source["query_status"] != metricSourceNull {
		t.Fatalf("source null was not persisted as a terminal fact: %+v", out.Comparison)
	}
}

func TestETIncompleteWindowPersistsObservedPostWithoutGrowth(t *testing.T) {
	old := wbAccountComparisonQuery
	defer func() { wbAccountComparisonQuery = old }()
	wbAccountComparisonQuery = func(_ context.Context, _ *http.Request, ids []string, start, end, _, _ string) (map[string]wbBatchMetric, error) {
		metric := wbBatchMetric{Status: "no_data"}
		if start == "2026-10-21" && end == "2026-10-26" {
			metric.Status = "success"
			metric.CCR = f64(2.60598542732949)
		}
		return map[string]wbBatchMetric{ids[0]: metric}, nil
	}
	row := wbRow{Program: "ET", Member: wbMember{AccountID: "7306081938064867329", Start: "2026-10-21 03:50:06"}}
	out := wbApplyAccountComparisons(context.Background(), httptest.NewRequest(http.MethodGet, "/api/live", nil), []wbRow{row}, time.Date(2026, 10, 27, 20, 0, 0, 0, cwLocation()))
	comparison := out[0].Comparison
	if comparison.Status != "window_incomplete" || comparison.PreCCR != nil || comparison.PostCCR == nil || *comparison.PostCCR != 2.60598542732949 || comparison.CCRGrowthPct != nil || comparison.Source["query_status"] != "window_incomplete" {
		t.Fatalf("observed incomplete comparison was not explicit: %+v", comparison)
	}
}

func TestAccountComparisonBatchNeverQueriesRevenue(t *testing.T) {
	old := accountVQSProbe
	defer func() { accountVQSProbe = old }()
	calls := []string{}
	accountVQSProbe = func(_ context.Context, _ *http.Request, source string) (map[string]any, error) {
		calls = append(calls, source)
		if source == "account_current_revenue" {
			t.Fatal("Pre/Post comparison must not query Account Revenue")
		}
		return map[string]any{
			"status":        "ok",
			"business_rows": []map[string]any{{"account_id": "7100000000000000001", "dynamic_p0_ccr": 12.5, "p0_nfs": 8.0}},
			"requestId":     "comparison-request",
			"logId":         "comparison-log",
			"report_id":     2979783,
			"dataset_id":    1139137,
		}, nil
	}
	metrics, err := queryAccountComparisonBatch(context.Background(), httptest.NewRequest(http.MethodGet, "/api/live", nil), []string{"7100000000000000001"}, "2026-10-01", "2026-10-07", "et_current_ccr_nfs", "ET")
	if err != nil {
		t.Fatal(err)
	}
	metric := metrics["7100000000000000001"]
	if len(calls) != 1 || calls[0] != "et_current_ccr_nfs" {
		t.Fatalf("unexpected comparison sources: %v", calls)
	}
	if metric.CCR == nil || metric.NFS == nil || metric.Revenue != nil || metric.RevenueStatus != "" {
		t.Fatalf("comparison result contains unexpected revenue data: %+v", metric)
	}
}
