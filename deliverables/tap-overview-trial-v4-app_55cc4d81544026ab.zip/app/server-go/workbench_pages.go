package main

import (
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
	"sort"
)

// A bounded, authenticated view over existing persisted scans. It never queries Aeolus.
// The original scan, field mapping, aggregation and threshold paths remain unchanged.
func wbHistoryHandler(w http.ResponseWriter, r *http.Request) {
	wbMu.Lock()
	state, err := wbReadDisk()
	wbMu.Unlock()
	if err != nil {
		writeJSON(w, 503, map[string]any{"error": err.Error()})
		return
	}
	scans := []wbJob{}
	for _, job := range state.Jobs {
		scans = append(scans, job)
	}
	sort.Slice(scans, func(i, j int) bool { return scans[i].StartedAt > scans[j].StartedAt })
	if len(scans) > 10 {
		scans = scans[:10]
	}
	ids := map[string]bool{}
	for _, job := range scans {
		for _, row := range job.Rows {
			ids[row.ID] = true
		}
	}
	actions := map[string]wbAction{}
	for _, action := range state.Actions {
		if ids[action.AlertID] {
			actions[action.AlertID] = action
		}
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"scans": scans, "actions": actions, "scope": "shared_recent_scans", "limit": 10}})
}

func wbQuotaBaseline() any {
	raw, err := os.ReadFile(filepath.Join(pluginDir, "config", "quota_baseline.json"))
	if err != nil {
		return nil
	}
	var config map[string]any
	if json.Unmarshal(raw, &config) != nil {
		return nil
	}
	return config
}
