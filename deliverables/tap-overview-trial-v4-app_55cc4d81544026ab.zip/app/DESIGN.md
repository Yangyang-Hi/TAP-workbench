# TAP Governance Workbench V6 Live — 设计说明

## 查询可观测性

### 统一入口

所有 Aeolus Saved Report / Titan VQS 数据查询经 `runTitanVQSProbe` 进入统一审计层，覆盖 Saved Report 定义读取、Quota、weekly/custom risk、CCR/NFS/Revenue、ET/THT batch，以及 submission 相关查询。ST membership 本身来自持久化 Lark snapshot，不伪装为 VQS 查询；当 ST 流程继续查询 Account CCR/NFS/Revenue 时同样进入统一审计层。

### 审计模型

每次 VQS 执行生成独立 `audit_id`，记录 trigger、program/tier、source key、App/RID/SID/TID（ID 始终按字符串序列化）、region、业务时间窗、最终 filters、投影字段 ID、请求定义 SHA-256、VQS request/query-history ID、SQL 返回状态、起止时间、耗时、HTTP/业务状态、行数、轮询次数、完整性、错误、source columns 和结果合同诊断。

VQS 未返回底层 SQL 时明确记录 `sql_status=not_returned`。若返回 SQL，则正文仅写入受限审计 payload 文件；服务日志只打印 audit ID、request ID、状态、定义 hash 与相对索引。请求定义也只在 payload 文件保存脱敏版本。

### 安全与持久化

- 审计数据写入 `AIME_PLUGIN_DATA_DIR/query-audit`，按 UTC 日期生成 JSONL，重启后保留。
- JSONL append 由进程级互斥锁保护；审计写失败仅写摘要错误日志，不改变业务查询结果。
- 每次写入顺带清理超过 30 天的日文件。
- Authorization、Cookie、Cloud/Titan JWT、token、clientSecret、邮箱等字段和值在落盘前统一脱敏。
- 不向普通前端提供 SQL/请求正文读取接口；现有 diagnostics/error 只关联 `audit_id`、`query_history_id`、`query_definition_hash`。

### 排障方式

页面或 API 报错中的三个关联字段可用于定位同一条 JSONL 审计记录，再根据记录中的相对 payload 索引由管理员/开发人员读取脱敏后的查询定义或 SQL。普通用户响应不会包含 SQL 正文或持久化目录绝对路径。

## 数据域与存储选型

| 数据域 | 权威来源 | App 是否维护 | 作用域 | 持久化 | 选择 |
|---|---|---:|---|---|---|
| Aeolus 查询结果 | Aeolus/VQS | 否 | 实时请求 | 按既有 snapshot 策略 | 外部权威源 |
| 查询审计 JSONL/payload | App 运行时 | 是 | 当前 App 实例 | 重启保留、30 天 | `AIME_PLUGIN_DATA_DIR` 文件存储 |

审计是实例内开发排障数据，不需要跨实例共享，也不适合 Cloud DB 的请求体和敏感正文边界，因此使用并发安全的本地滚动文件。

## Quota 报警与 Regional POC 路由（2026-10-23）

- 阈值版本 `quota-tier-v3-et-inclusive-st-exclusive`：ET 区域使用率 `>=100%` 报警；ST 仅 `>100%` 报警；THT 无分母不报警。
- Quota 事件以 `季度 + Tier + Region + 阈值版本` 作为幂等键。同一季度持续命中或回落后再次升至阈值均复用同一事件；新季度或阈值版本变化才新建。
- 自动扫描仅创建/更新事件和通知待办，`auto_send_enabled=false`，不发送真实通知。
- 收件人只允许来自 Regional POC 映射；KR+JP 与 MET/METAP 沿用别名展开。缺少映射时阻断并显示“待补负责人”，不回退提报人。
- 通知状态统一为 `pending regional POC`、`ready in test mode`、`sent`、`blocked missing POC`。

## Casework 跨实例权威存储（2026-10-26）

| 数据域 | 权威来源 | App 是否维护 | 作用域 | 持久化 | 选择 |
|---|---|---:|---|---|---|
| Casework 事件与版本 | App | 是 | 跨用户实例共享 | 长期 | Cloud DB `tap_cases`，`case_id` 唯一，`version` 条件更新 |
| 命令幂等回执 | App | 是 | 跨用户实例共享 | 长期 | Cloud DB `tap_commands`，`case_id + request_id` 唯一 |
| 通知 outbox/投递结果 | App | 是 | 跨用户实例共享 | 长期 | Cloud DB `tap_outbox`，outbox ID 与幂等键唯一 |
| 通知预览确认 | App | 是 | 跨用户实例共享 | 短期但需持久化 | Cloud DB `tap_previews`，token hash 唯一 |
| 身份映射快照与人工禁用 | Lark Sheet + App override | 是 | 跨用户实例共享 | 长期 | Cloud DB `tap_identity_mappings`，record ID 唯一 |
| Aeolus 查询结果/审计缓存 | Aeolus/VQS | 否 | 当前实例 | 可重建/滚动保留 | 保持本地缓存与文件存储 |

Cloud Schema 和索引只通过发布前 DDL 创建，服务启动与普通请求不执行 DDL。Cloud DB 初始化失败、表缺失或请求失败时，核心 casework 路径直接失败，不回退本地业务状态。事件更新使用 `case_id + version` 条件更新实现乐观并发控制；通知创建和迁移使用唯一业务键 upsert。现有 SQLite 数据通过显式 `migrate-casework-to-cloud` 运维动作迁移，支持重复执行并在结束时逐表校验数量。
