import { Alert, Button, Input, Spin, Tag } from '@arco-design/web-react';
import { Activity, Clock3, Database, SearchCheck } from 'lucide-react';
import { useState } from 'react';
import { monitoringEtCurrentCreate, type MonitoringEtCurrentCreateResponse } from '../../api/client.gen';

type ETResult = MonitoringEtCurrentCreateResponse['data'];
const SAMPLE_IDS = ['7675782032500424721', '7244006541899137025', '6917996275652625154'];

export function ETCurrentPanel() {
  const [accountId, setAccountId] = useState(SAMPLE_IDS[0]);
  const [startDate, setStartDate] = useState('2026-10-01');
  const [endDate, setEndDate] = useState('2026-10-14');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ETResult>();
  const [error, setError] = useState('');
  async function query() {
    if (!/^\d{16,20}$/.test(accountId.trim())) return setError('请输入有效的 ET Account ID（16–20 位数字）');
    if (!startDate || !endDate || startDate > endDate) return setError('请选择有效的起止日期');
    setLoading(true); setError('');
    try { const response = await monitoringEtCurrentCreate({ account_id: accountId.trim(), start_date: startDate, end_date: endDate }); setResult(response.data); }
    catch (err) { setError(err instanceof Error ? err.message : '真实风神查询失败'); }
    finally { setLoading(false); }
  }
  const success = result?.status === 'success';
  return <section className="et-current-panel">
    <div className="et-current-head"><div><span className="eyebrow">LIVE · AEOLUS</span><h2>ET Current P0 CCR / NFS</h2><p>单客户只读查询 · SID 1139137 / RID 2898470 · 不触发正式预警</p></div><Tag color={success ? 'green' : 'gray'}>{loading ? 'QUERYING' : success ? 'SUCCESS' : 'READY'}</Tag></div>
    <div className="et-current-form"><label><span>ET Account ID</span><Input value={accountId} onChange={setAccountId} allowClear /></label><label><span>Start date</span><input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} /></label><label><span>End date</span><input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} /></label><Button type="primary" icon={<SearchCheck size={16}/>} loading={loading} onClick={query}>查询真实数据</Button></div>
    <div className="et-samples"><span>已验收账号</span>{SAMPLE_IDS.map(id => <button type="button" key={id} onClick={() => setAccountId(id)}>{id}</button>)}</div>
    {error && <Alert type="error" content={error} showIcon />}
    {loading && <div className="et-loading"><Spin/><span>正在执行 AIME Go Service → Aeolus VQS，通常需要 8–20 秒…</span></div>}
    {!loading && result && <div className="et-result-grid"><div className="et-result-primary"><span>Current P0 CCR</span><strong>{success ? Number(result.dynamic_p0_ccr).toFixed(6) : '—'}</strong><small>风神原始聚合值，未转换单位</small></div><div className="et-result-primary"><span>Current P0 NFS</span><strong>{success ? result.p0_nfs : '—'}</strong><small>P0: Negative Feedback Show</small></div><dl className="et-result-meta"><div><dt><Activity size={14}/>Account ID</dt><dd>{result.account_id}</dd></div><div><dt><Clock3 size={14}/>Query window</dt><dd>{result.start_date} → {result.end_date}</dd></div><div><dt><Database size={14}/>Data source</dt><dd>SID {result.data_source?.sid} / RID {result.data_source?.rid}</dd></div><div><dt>Query duration</dt><dd>{result.query_duration_ms} ms{result.cached ? ' · cached' : ''}</dd></div><div><dt>Last queried</dt><dd>{result.last_queried_at}</dd></div><div><dt>Data status</dt><dd>{result.status}</dd></div></dl></div>}
    {!loading && !result && <div className="et-empty">输入 ET Account ID 与日期窗口，查询真实 Current 指标。其他模块仍为 Demo / Pending。</div>}
  </section>;
}
