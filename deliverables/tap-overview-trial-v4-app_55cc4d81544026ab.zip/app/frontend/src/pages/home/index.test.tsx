import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import Workbench from "./index";
const clients = vi.hoisted(() => ({ batches: vi.fn(), read: vi.fn(), config: vi.fn(), cases: vi.fn(), detail: vi.fn() }));
vi.mock("../../api/client.gen", async (original) => ({
  ...(await original<typeof import("../../api/client.gen")>()),
  workbenchBatchesList: clients.batches,
  workbenchReadModelList: clients.read,
  workbenchCaseworkConfigList: clients.config,
  workbenchCasesList: clients.cases,
  workbenchCasesByIdGet: clients.detail,
}));
vi.mock("../governance/casework", () => ({
  CaseworkInbox: () => <div>共享事件操作</div>,
  CaseActions: () => <div>事件操作</div>,
  WorkbenchSettings: () => <div>工作台配置</div>,
}));
vi.mock("../governance/submission-quota", () => ({ SubmissionQuota: () => <div>Submission Quota 真实数据</div> }));
const batch = { batch_id: "b1", week_name: "2026-W42", generated_at: "2026-10-19T01:00:00Z", metric_start_date: "2026-10-12", metric_end_date: "2026-10-18", timezone: "Asia/Shanghai", programs: ["ET"], status: "available", completeness: "complete" };
const model = { status: "available", reason: "", time: { mode: "weekly", selected_batch: batch, batches: [batch] }, filters: {}, cards: { queried_customers: { value: 2, status: "available", description: "完整客户池" }, auto_alerted: { value: null, status: "unavailable", description: "来源不可区分" }, pending: { value: 1, status: "available", description: "待发送" }, handled: { value: 0, status: "available", description: "成功通知" } }, rows: [], rankings: {}, pagination: { page: 1, page_size: 50, total: 0 }, contract_version: "test" };

beforeEach(() => {
  clients.batches.mockResolvedValue({ data: { status: "available", batches: [batch], timezone: "Asia/Shanghai", source: "persisted" } });
  clients.read.mockResolvedValue({ data: model });
  clients.config.mockResolvedValue({ data: { actor: "submitter", is_operator: false, workflow: {} } });
  clients.cases.mockResolvedValue({ data: { cases: [] } });
  clients.detail.mockImplementation(() => new Promise(() => undefined));
});
afterEach(() => { cleanup(); vi.clearAllMocks(); history.replaceState(null, "", "/"); });

describe("共享治理工作台入口", () => {
  it("打开页面只读加载批次和 read-model，并显示 null 卡片", async () => {
    render(<Workbench />);
    expect(await screen.findByText("完整客户池")).toBeTruthy();
    expect(clients.batches).toHaveBeenCalledTimes(1);
    expect(clients.read).toHaveBeenCalled();
    expect(screen.getByText("来源不可区分")).toBeTruthy();
  });
  it("固定四个主 Tab 且切页保留筛选", async () => {
    render(<Workbench />); await screen.findByText("完整客户池");
    fireEvent.change(screen.getByLabelText("共享客户搜索"), { target: { value: "1001" } });
    fireEvent.click(screen.getByText("治理效果分析"));
    expect(screen.getByLabelText("共享客户搜索")).toHaveProperty("value", "1001");
    expect(screen.queryByText("运营视角")).toBeNull();
    await waitFor(() => expect(clients.read).toHaveBeenLastCalledWith(expect.objectContaining({ search: "1001" })));
  });
  it("自定义查询只在显式点击后执行并展示只读统计", async () => {
    clients.read.mockResolvedValue({ data: { ...model, time: { mode: "custom", start_date: "2026-10-01", end_date: "2026-10-07" }, reason: "custom_authoritative_read_only", cards: { queried_customers: { value: 2, status: "available", description: "自定义查询客户" }, risk_customers: { value: 1, status: "available", description: "自定义风险客户" }, auto_alerted: { value: null, status: "not_applicable", description: "不适用于自定义查询" } } } });
    history.replaceState(null, "", "/?time_mode=custom&start_date=2026-10-01&end_date=2026-10-07");
    render(<Workbench />);
    expect(await screen.findByText("自定义时间已就绪")).toBeTruthy();
    expect(clients.read).not.toHaveBeenCalled();
    fireEvent.click(screen.getByText("执行自定义查询"));
    expect(await screen.findByText("自定义查询客户")).toBeTruthy();
    expect(screen.getByText("命中风险客户")).toBeTruthy();
    expect(clients.read).toHaveBeenCalledTimes(1);
  });

  it("直接打开旧卡片链接时显示两个任务导航，并保留事件进入风险页", async () => {
    history.replaceState(null, "", "/?view=tasks&alert_id=TAP-old-card&installed_first=1");
    render(<Workbench />);

    const tasks = screen.getByRole("button", { name: "我的待办" });
    const enter = screen.getByRole("button", { name: "进入工作台" });
    expect(document.body.contains(tasks)).toBe(true);
    expect(document.body.contains(enter)).toBe(true);
    expect(getComputedStyle(tasks).display).not.toBe("none");
    expect(getComputedStyle(enter).visibility).not.toBe("hidden");

    fireEvent.click(enter);
    await waitFor(() => expect(screen.getByTestId("governance-workbench")).toBeTruthy());
    const params = new URLSearchParams(location.search);
    expect(params.get("alert_id")).toBe("TAP-old-card");
    expect(params.get("view")).toBeNull();
    expect(params.get("tab")).toBe("risk");
    expect(params.get("installed_first")).toBe("1");
  });

  it("已打开页面后对 pushState、replaceState 和 popstate 立即切换任务路由", async () => {
    const nativeReplace = history.replaceState;
    render(<Workbench />);
    await screen.findByTestId("governance-workbench");

    history.pushState(null, "", "/?view=tasks&alert_id=TAP-push");
    expect(await screen.findByRole("button", { name: "进入工作台" })).toBeTruthy();

    history.replaceState(null, "", "/?alert_id=TAP-push&tab=risk");
    expect(await screen.findByTestId("governance-workbench")).toBeTruthy();

    history.replaceState(null, "", "/?view=tasks&alert_id=TAP-replace");
    expect(await screen.findByRole("button", { name: "我的待办" })).toBeTruthy();

    nativeReplace.call(history, null, "", "/?alert_id=TAP-pop&tab=risk");
    window.dispatchEvent(new PopStateEvent("popstate"));
    expect(await screen.findByTestId("governance-workbench")).toBeTruthy();
  });
});
