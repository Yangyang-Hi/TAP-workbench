import { describe, expect, it } from "vitest";
import { semanticsLabelFact } from "./read-model";

describe("semanticsLabelFact", () => {
  it("distinguishes legacy absence from a present but empty source field", () => {
    expect(semanticsLabelFact(undefined, "legacy_not_captured")).toBe("历史事件未采集该字段");
    expect(semanticsLabelFact(undefined, "source_empty")).toBe("源字段为空");
    expect(semanticsLabelFact(undefined, "field_not_returned")).toBe("本次源响应未返回该字段");
  });

  it("prefers persisted and backfilled values", () => {
    expect(semanticsLabelFact("content_issues - sensitive_content - unsure_violence -", "backfilled_available")).toBe("content_issues - sensitive_content - unsure_violence -");
  });
});
