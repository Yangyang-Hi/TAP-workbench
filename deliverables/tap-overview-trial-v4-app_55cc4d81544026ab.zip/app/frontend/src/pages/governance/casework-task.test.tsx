import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";
import type { Case } from "./casework";
import { SubmitterCasework } from "./casework-task";

const client = vi.hoisted(() => ({
  config: vi.fn(),
  list: vi.fn(),
  detail: vi.fn(),
  command: vi.fn(),
}));

vi.mock("../../api/client.gen", () => ({
  workbenchCaseworkConfigList: client.config,
  workbenchCasesList: client.list,
  workbenchCasesByIdGet: client.detail,
  workbenchCasesByIdCommandsCreate: client.command,
}));
vi.mock("../../auth", () => ({ apiFetch: vi.fn() }));

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

const event = {
  id: "TAP-alert-1",
  version: 3,
  kind: "customer",
  status: "processing",
  owner: "submitter",
  creator: "operator",
  reviewer: "operator",
  row: {
    id: "row-1",
    program: "ET",
    member: { account_id: "123", advertiser_id: "", account_name: "客户甲", region: "APAC", submitter: "submitter" },
    ccr: 12.5,
    nfs: 8,
    revenue: 900,
    metric_status: "available",
    advertiser_count: 2,
    advertiser_top10: [{ advertiser_id: "7655963361028571144", ccr: 2890.173410404624, nfs: 1, revenue: null, reported_reasons: [{ original_label: "Violence", display_name_en: "Violence", description: "暴力内容", mapping_status: "draft", p0_ccr: null, rank: null, ranking_available: false, ranking_unavailable_reason: "Reason ranking unavailable" }, { original_label: "Non-negative Feedback", display_name_en: "Non-negative Feedback", description: "非负反馈", mapping_status: "draft", p0_ccr: null, rank: null, ranking_available: false, ranking_unavailable_reason: "Reason ranking unavailable" }] }],
    advertisers: [],
    level: "watch",
    reasons: ["CCR 命中阈值"],
    queried_at: "2026-10-22T06:00:00Z",
  },
  window: { start_date: "2026-10-01", end_date: "2026-10-14" },
  created_at: "",
  updated_at: "",
  plan: "continue_observe",
  note: "",
  due_date: "",
  fields: {},
  action_completed: false,
  education_completed: false,
  review_requested_by: "",
  closure_reason: "",
  history: [{ id: "h1", at: "2026-10-22", actor: "operator", source: "web", operation: "notify", status: "processing", note: "已通知提报人", version: 2 }],
  rechecks: [],
} as unknown as Case;

it("从飞书深链直接定位事件，并展示三阶段进度和 Account-level 口径", async () => {
  client.config.mockResolvedValue({ data: { actor: "submitter", is_operator: false, workflow: { customer: [{ id: "continue_observe", label: "继续观察", status: "observing", fields: [] }] } } });
  client.list.mockResolvedValue({ data: { cases: [event] } });
  client.detail.mockResolvedValue({ data: event });

  render(<SubmitterCasework alertId="TAP-alert-1" />);

  expect(await screen.findByRole("heading", { name: "客户甲", level: 1 })).toBeTruthy();
  expect(client.detail).toHaveBeenCalledWith("TAP-alert-1");
  const progress = screen.getByRole("list", { name: "治理进度" });
  expect(progress.textContent).toContain("待运营确认");
  expect(progress.textContent).toContain("待提报人处理");
  expect(progress.textContent).toContain("已关闭");
  expect(screen.getByRole("button", { name: "进入工作台" })).toBeTruthy();
  expect(screen.queryByRole("button", { name: "进入运营工作台" })).toBeNull();
  expect(screen.getByText("P0 CCR")).toBeTruthy();
  expect(screen.getByText(/关联 Advertiser 仅作为证据明细/)).toBeTruthy();
  expect(screen.getByText("Alert Type")).toBeTruthy();
  expect(screen.getAllByText("Trigger Criteria").length).toBeGreaterThan(0);
  expect(screen.getByText("Reported Reasons")).toBeTruthy();
  expect(screen.getAllByText("Violence").length).toBeGreaterThan(0);
  expect(screen.getAllByText("Non-negative Feedback").length).toBeGreaterThan(0);
  expect(screen.getAllByText("Reason ranking unavailable").length).toBe(2);
});


it("404 时说明事件尚未同步，并允许原地重试且不触发写操作", async () => {
  client.config.mockResolvedValue({ data: { actor: "submitter", is_operator: false, workflow: { customer: [] } } });
  client.list.mockResolvedValue({ data: { cases: [] } });
  client.detail
    .mockRejectedValueOnce(new Error("GET /api/workbench/cases/TAP-missing failed: HTTP 404"))
    .mockResolvedValueOnce({ data: event });

  render(<SubmitterCasework alertId="TAP-missing" />);

  const recovery = await screen.findByTestId("case-not-synced");
  expect(recovery.textContent).toContain("该事件暂未同步到当前运行环境");
  expect(screen.getByRole("button", { name: "返回风险预警列表" })).toBeTruthy();
  fireEvent.click(screen.getByRole("button", { name: "重试" }));

  expect(await screen.findByRole("heading", { name: "客户甲", level: 1 })).toBeTruthy();
  expect(client.detail).toHaveBeenCalledTimes(2);
  expect(client.command).not.toHaveBeenCalled();
});

it("非 404 详情错误保留可诊断信息", async () => {
  client.config.mockResolvedValue({ data: { actor: "submitter", is_operator: false, workflow: { customer: [] } } });
  client.list.mockResolvedValue({ data: { cases: [] } });
  client.detail.mockRejectedValue(new Error("GET /api/workbench/cases/TAP-error failed: HTTP 503"));

  render(<SubmitterCasework alertId="TAP-error" />);

  await waitFor(() =>
    expect(screen.getByRole("alert").textContent).toContain(
      "事件读取失败：GET /api/workbench/cases/TAP-error failed: HTTP 503",
    ),
  );
  expect(screen.queryByTestId("case-not-synced")).toBeNull();
  expect(client.command).not.toHaveBeenCalled();
});

it("配置接口失败时导航始终可见，并显示失败提示且可重试", async () => {
  client.config
    .mockRejectedValueOnce(new Error("GET /api/workbench/casework/config failed: HTTP 503"))
    .mockResolvedValueOnce({ data: { actor: "submitter", is_operator: false, workflow: { customer: [] } } });
  client.list.mockResolvedValue({ data: { cases: [] } });
  client.detail.mockResolvedValue({ data: event });

  render(<SubmitterCasework alertId="TAP-alert-1" />);

  const tasks = screen.getByRole("button", { name: "我的待办" });
  const workbench = screen.getByRole("button", { name: "进入工作台" });
  expect(document.body.contains(tasks)).toBe(true);
  expect(document.body.contains(workbench)).toBe(true);
  expect(tasks.hidden).toBe(false);
  expect(workbench.hidden).toBe(false);
  expect(getComputedStyle(tasks).display).not.toBe("none");
  expect(getComputedStyle(workbench).visibility).not.toBe("hidden");
  expect((await screen.findByRole("alert")).textContent).toContain("配置读取失败");

  fireEvent.click(screen.getByRole("button", { name: "重试" }));
  expect(await screen.findByRole("heading", { name: "客户甲", level: 1 })).toBeTruthy();
  expect(client.config).toHaveBeenCalledTimes(2);
});
