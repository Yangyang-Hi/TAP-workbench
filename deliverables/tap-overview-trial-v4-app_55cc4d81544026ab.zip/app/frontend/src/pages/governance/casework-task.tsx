import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  workbenchCasesByIdCommandsCreate,
  workbenchCasesByIdGet,
  workbenchCasesList,
  workbenchCaseworkConfigList,
} from "../../api/client.gen";
import { caseLabels, rcaByPlan, type Case } from "./casework";
import { navigateQuery } from "../../route-state";
import { ccr, nfs, revenue } from "./read-model";
import { ReportedReasonsView, reportedReasonGroups } from "./reported-reasons";
import "./casework.css";

type Field = { key: string; label: string; type?: string; required: boolean };
type Option = { id: string; label: string; status: string; fields: Field[] };
type CaseConfig = {
  actor: string;
  is_operator: boolean;
  workflow: Record<string, Option[]>;
};
type Bundle = { cases: Case[] };
const requestId = () => globalThis.crypto?.randomUUID?.() || `web-${Date.now()}`;
const errorText = (e: unknown) => (e instanceof Error ? e.message : "请求失败");
const isNotFoundError = (e: unknown) =>
  e instanceof Error && /(?:^|\s)HTTP 404(?:\s|$)/.test(e.message);
const operationLabels: Record<string, string> = {
  create: "建立预警事件",
  accept: "接受任务",
  plan: "保存处理记录",
  complete: "提交运营复核",
  return: "运营退回补充",
  close: "运营复核关闭",
  reopen: "重新打开",
  assign: "调整负责人",
  approve: "运营审批通过",
  recheck: "指标复查",
  notify: "发送通知",
};
const workflowStage = (status: string) =>
  status === "closed"
    ? 2
    : ["processing", "observing", "pending_approval", "pending_review"].includes(status)
      ? 1
      : 0;

function go(params: Record<string, string>) {
  navigateQuery((query) => {
    for (const [key, value] of Object.entries(params)) query.set(key, value);
  });
}

function openWorkbench(alertId: string) {
  navigateQuery((query) => {
    query.delete("view");
    query.set("tab", "risk");
    if (alertId) query.set("alert_id", alertId);
  });
}

function openTasks() {
  navigateQuery((query) => {
    query.set("view", "tasks");
    query.delete("tab");
    query.delete("alert_id");
  });
}

export function SubmitterCasework({ alertId = "" }: { alertId?: string }) {
  const [config, setConfig] = useState<CaseConfig>();
  const [cases, setCases] = useState<Case[]>([]);
  const [selected, setSelected] = useState(alertId);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    try {
      const [c, b] = await Promise.all([
        workbenchCaseworkConfigList<{ data: CaseConfig }>(),
        workbenchCasesList<{ data: Bundle }>(),
      ]);
      setConfig(c.data);
      setCases(b.data.cases || []);
      setError("");
    } catch (e) {
      setError(errorText(e));
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  useEffect(() => {
    setSelected(alertId);
  }, [alertId]);

  if (!config) {
    return (
      <main className="cw-task-page">
        <TaskHeader alertId={alertId} />
        <section className="cw-task-card" aria-live="polite">
          {error ? (
            <>
              <p className="cw-error" role="alert">配置读取失败：{error}</p>
              <div className="cw-buttons">
                <button type="button" className="tg-btn primary" onClick={() => void load()}>重试</button>
              </div>
            </>
          ) : (
            <p>正在加载预警处理配置…</p>
          )}
        </section>
      </main>
    );
  }

  if (selected) {
    return (
      <main className="cw-task-page">
        <TaskHeader alertId={selected} onTasks={() => setSelected("")} />
        <SubmitterCaseDetail id={selected} config={config} onSaved={load} />
      </main>
    );
  }
  const mine = cases.filter((item) =>
    [item.owner, item.creator, item.reviewer].includes(config.actor),
  );
  return (
    <main className="cw-task-page">
      <TaskHeader />
      <section className="cw-task-hero">
        <p className="cw-eyebrow">个人处理视角</p>
        <h1>我的待办</h1>
        <p>仅展示与你有关且后端已授权的预警事件。</p>
      </section>
      {error && <p className="cw-error">{error}</p>}
      <section className="cw-task-list">
        {mine.map((item) => (
          <button key={item.id} onClick={() => setSelected(item.id)}>
            <span>
              <strong>{item.row.member.account_name || item.row.member.account_id || item.row.member.advertiser_id}</strong>
              <small>{item.id} · {item.row.program} · {item.row.member.region || "区域待补"}</small>
            </span>
            <span className="tg-badge">{caseLabels[item.status] || item.status}</span>
          </button>
        ))}
        {mine.length === 0 && <p className="tg-empty">当前没有需要你处理的预警。</p>}
      </section>
    </main>
  );
}

function TaskHeader({ alertId, onTasks }: { alertId?: string; onTasks?: () => void }) {
  return (
    <nav className="cw-task-nav" aria-label="任务视角导航">
      <strong>TAP 预警处理</strong>
      <div>
        <button className="tg-btn" onClick={() => onTasks ? onTasks() : openTasks()}>我的待办</button>
        <button className="tg-btn" onClick={() => openWorkbench(alertId || new URLSearchParams(window.location.search).get("alert_id") || "")}>进入工作台</button>
      </div>
    </nav>
  );
}

function SubmitterCaseDetail({ id, config, onSaved }: { id: string; config: CaseConfig; onSaved: () => void }) {
  const [item, setItem] = useState<Case>();
  const [error, setError] = useState("");
  const [notFound, setNotFound] = useState(false);
  const [success, setSuccess] = useState("");
  const [busy, setBusy] = useState(false);
  const [plan, setPlan] = useState("");
  const [fields, setFields] = useState<Record<string, string>>({});
  const [note, setNote] = useState("");
  const [version, setVersion] = useState(0);
  const initialize = useCallback((next: Case) => {
    setItem(next);
    const selectedPlan = next.plan || config.workflow[next.kind]?.[0]?.id || "";
    setPlan(selectedPlan);
    setFields({ ...(next.fields || {}), ...(rcaByPlan[selectedPlan] ? { rca: rcaByPlan[selectedPlan] } : {}) });
    setNote(next.note || "");
    setVersion(next.version);
  }, [config.workflow]);
  const load = useCallback(async () => {
    setError("");
    setNotFound(false);
    try {
      const res = await workbenchCasesByIdGet<{ data: Case }>(id);
      initialize(res.data);
    } catch (e) {
      setNotFound(isNotFoundError(e));
      setError(errorText(e));
    }
  }, [id, initialize]);
  useEffect(() => { void load(); }, [load]);
  const options = item ? config.workflow[item.kind] || [] : [];
  const chosen = options.find((option) => option.id === plan);
  const returned = useMemo(() => item?.history.slice().reverse().find((event) => event.operation === "return"), [item]);
  const canHandle = !!item && (config.is_operator || config.actor === item.owner);
  async function command(operation: "accept" | "plan" | "complete") {
    if (!item) return;
    setBusy(true); setError(""); setSuccess("");
    try {
      const res = await workbenchCasesByIdCommandsCreate<{ data: Case }>(item.id, {
        expected_version: version,
        request_id: requestId(),
        operation,
        plan,
        note,
        fields: operation === "complete" ? { ...fields, evidence: fields.evidence || fields.completion_evidence || "" } : fields,
        owner: item.owner,
        reviewer: item.reviewer,
      });
      initialize(res.data);
      setSuccess(operation === "complete" ? "已提交运营复核。事件不会因此自动关闭。" : "处理记录已保存。");
      await onSaved();
    } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
  }
  if (!item) {
    if (notFound) {
      return (
        <section className="cw-task-card" role="alert" data-testid="case-not-synced">
          <header><span>!</span><h2>暂时无法打开此事件</h2></header>
          <p>该事件暂未同步到当前运行环境。你可以返回风险预警列表查看当前环境中的事件，或稍后重试。</p>
          <div className="cw-buttons">
            <button type="button" className="tg-btn" onClick={() => go({ view: "operations", tab: "risk" })}>返回风险预警列表</button>
            <button type="button" className="tg-btn primary" onClick={() => void load()}>重试</button>
          </div>
        </section>
      );
    }
    return <section className="cw-task-card">{error ? <p className="cw-error" role="alert">事件读取失败：{error}</p> : <p>正在加载预警事件…</p>}</section>;
  }
  const member = item.row.member;
  const stale = version !== item.version;
  return (
    <>
      <section className="cw-task-hero">
        <p className="cw-eyebrow">预警处理任务</p>
        <div className="cw-task-title"><div><h1>{member.account_name || member.account_id || member.advertiser_id}</h1><p>{item.id}</p></div><span className="tg-badge">{caseLabels[item.status] || item.status}</span></div>
      </section>
      <WorkflowProgress current={workflowStage(item.status)} />
      {error && <p className="cw-error" role="alert">{error}</p>}
      {success && <p className="cw-success" role="status">{success}</p>}
      {returned && item.status === "processing" && <section className="cw-return"><strong>运营已退回，请补充</strong><p>{returned.note}</p></section>}
      <TaskSection number="01" title="预警摘要">
        <div className="cw-facts">
          <Fact label="Submitter" value={member.submitter || "—"} />
          <Fact label="Alert Type" value={["watch", "critical"].includes(item.row.level) ? "CCR/NFS absolute threshold" : "Unidentified alert type"} />
          <Fact label="Alert Level" value={item.row.level || "—"} />
          <Fact label="Status" value={caseLabels[item.status] || item.status || "—"} />
          <Fact label="Time Window" value={`${item.window.start_date || "—"} 至 ${item.window.end_date || "—"}`} />
          <Fact label="Region" value={member.region || "—"} />
          <Fact label="Account ID / Account Name" value={[member.account_id, member.account_name].filter(Boolean).join(" / ") || "—"} />
          <Fact label="Advertiser ID" value={member.advertiser_id || "—"} />
          <Fact label="P0 CCR" value={ccr(item.row.ccr)} />
          <Fact label="P0 NFS" value={nfs(item.row.nfs)} />
          <Fact label="Revenue" value={revenue(item.row.revenue)} />
          <Fact label="Trigger Criteria" value={item.row.reasons?.join("；") || "—"} />
        </div>
        <div className="cw-evidence"><strong>Reported Reasons</strong><ReportedReasonsView groups={reportedReasonGroups(item.row.advertiser_top10 || item.row.advertisers)} /></div>
      </TaskSection>
      <TaskSection number="02" title={item.row.program === "THT" ? "Advertiser Level" : "Account Level"}>
        <p className="cw-grain-note"><strong>统计粒度：{item.row.program === "THT" ? "Advertiser-level" : "Account-level"}</strong>。P0 CCR、P0 NFS 与 Revenue 均为当前事件主体在指标窗口内的聚合值；{item.row.program === "THT" ? "关联 Account 仅作为补充信息，不改变指标粒度。" : "关联 Advertiser 仅作为证据明细，不与 Account 聚合值直接相加。"}</p>
        <details className="cw-evidence"><summary>查看详细依据</summary><p><strong>Trigger Criteria</strong>：{item.row.reasons?.join("；") || "—"}</p></details>
      </TaskSection>
      <TaskSection number="03" title="我需要做什么">
        {!canHandle && <p className="cw-hint">你可以查看该事件，但当前处理负责人是 {item.owner}。如需处理，请联系治理运营调整负责人。</p>}
        <div className="cw-form">
          <label>风险归因与处置动作<select aria-label="风险归因与处置动作" value={plan} disabled={!canHandle || item.status === "closed"} onChange={(e) => { const nextPlan = e.target.value; setPlan(nextPlan); setFields(rcaByPlan[nextPlan] ? { rca: rcaByPlan[nextPlan] } : {}); }}>{options.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}</select></label>
          {chosen?.fields.map((field) => <label key={field.key}>{field.label}{field.required ? " *" : ""}<input aria-label={field.label} type={field.type === "date" ? "date" : "text"} value={fields[field.key] || ""} disabled={!canHandle || item.status === "closed" || field.key === "rca"} onChange={(e) => setFields((old) => ({ ...old, [field.key]: e.target.value }))} /></label>)}
          <label>核查说明与后续计划 *<textarea aria-label="核查说明与后续计划" value={note} disabled={!canHandle || item.status === "closed"} onChange={(e) => setNote(e.target.value)} placeholder="说明风险原因、已完成动作、后续计划和需要运营协助的事项" /></label>
          <label>证据链接或说明<input aria-label="证据链接或说明" value={fields.evidence || fields.completion_evidence || ""} disabled={!canHandle || item.status === "closed"} onChange={(e) => setFields((old) => ({ ...old, evidence: e.target.value }))} /></label>
          {stale && <p className="cw-hint">事件已在其他入口更新，请刷新后继续，避免覆盖最新记录。</p>}
          <div className="cw-buttons">
            {item.status === "open" && <button className="tg-btn" disabled={busy || stale || !canHandle} onClick={() => void command("accept")}>接受任务</button>}
            <button className="tg-btn primary" disabled={busy || stale || !canHandle || item.status === "closed"} onClick={() => void command("plan")}>保存处理记录</button>
            <button className="tg-btn" disabled={busy || stale || !canHandle || !["processing", "observing"].includes(item.status)} onClick={() => void command("complete")}>提交运营复核</button>
          </div>
          <p className="tg-muted">提交复核不会自动关闭事件，也不代表风险已经恢复。</p>
        </div>
      </TaskSection>
      {item.status === "closed" && <section className="cw-closed-next" aria-label="关闭后查看"><div><strong>事件已关闭并进入治理统计</strong><p>总览展示关闭进度；效果分析会区分“已关闭”与“真实复查改善”，不会把关闭直接视为风险改善。</p></div><div className="cw-buttons"><button className="tg-btn" onClick={() => go({ view: "operations", tab: "overview", alert_id: item.id })}>查看治理总览</button><button className="tg-btn primary" onClick={() => go({ view: "operations", tab: "analysis", alert_id: item.id })}>查看效果分析</button></div></section>}
      <TaskSection number="04" title="处理进展">
        <div className="cw-timeline">{item.history.slice().reverse().map((event, index) => <article key={`${event.id}-${index}`}><span>{event.at}</span><strong>{operationLabels[event.operation] || event.operation}</strong><p>{event.note}</p><small>{event.actor} · {caseLabels[event.status] || event.status}</small></article>)}</div>
      </TaskSection>
    </>
  );
}

function WorkflowProgress({ current }: { current: number }) {
  const stages = [
    ["待运营确认", "运营确认事件与通知对象"],
    ["待提报人处理", "提报人核查 Account-level 信息并完成处置"],
    ["已关闭", "纳入治理总览与效果分析"],
  ];
  return <ol className="cw-workflow" aria-label="治理进度">{stages.map(([label, description], index) => <li key={label} className={index < current ? "done" : index === current ? "current" : "pending"}><span>{index < current ? "✓" : index + 1}</span><div><strong>{label}</strong><small>{description}</small></div></li>)}</ol>;
}

function TaskSection({ number, title, children }: { number: string; title: string; children: ReactNode }) {
  return <section className="cw-task-card"><header><span>{number}</span><h2>{title}</h2></header>{children}</section>;
}
function Fact({ label, value }: { label: string; value: string }) {
  return <div><span>{label}</span><strong>{value}</strong></div>;
}
