import { useMemo, useState } from "react";
import { SubmissionQuota } from "./submission-quota";
import {
  type Action,
  type Config,
  type PageName,
  type RiskRow,
  type Scan,
  type ScanRequest,
  entityId,
  fmt,
  matched,
  statusLabels,
  latestScopedScans,
} from "./api";

export type PageProps = {
  scans: Scan[];
  actions: Record<string, Action>;
  query?: ScanRequest;
  config?: Config;
  onNavigate: (page: PageName, program?: string) => void;
  onOpen: (row: RiskRow, scan: Scan) => void;
  historyError?: string;
};
const unknown = "—";
const levelNames: Record<string, string> = {
  critical: "高风险",
  watch: "风险观察",
  normal: "未触发",
  unavailable: "不可评估",
};
export function Badge({
  children,
  tone = "",
}: {
  children: React.ReactNode;
  tone?: string;
}) {
  return <span className={"tg-badge " + tone}>{children}</span>;
}
export function Metrics({
  items,
}: {
  items: {
    label: string;
    value: React.ReactNode;
    hint: string;
    tone?: string;
  }[];
}) {
  return (
    <div className="tg-kpis">
      {items.map((i) => (
        <div className={"tg-kpi " + (i.tone || "")} key={i.label}>
          <span>{i.label}</span>
          <strong>{i.value}</strong>
          <small>{i.hint}</small>
        </div>
      ))}
    </div>
  );
}
function Empty({ children }: { children: React.ReactNode }) {
  return <div className="tg-empty">{children}</div>;
}
function Meter({
  label,
  count,
  total,
  tone = "blue",
  onClick,
}: {
  label: string;
  count: number;
  total: number;
  tone?: string;
  onClick?: () => void;
}) {
  return (
    <div className="tg-meter">
      <div>
        <span>{label}</span>
        <b>{count}</b>
      </div>
      <button
        type="button"
        aria-label={`${label} ${count}`}
        className="tg-metertrack"
        disabled={!onClick}
        onClick={onClick}
      >
        <i
          className={tone}
          style={{
            width: count
              ? `${Math.max(2, (count / Math.max(total, 1)) * 100)}%`
              : "0%",
          }}
        />
      </button>
    </div>
  );
}
export function OverviewPage(props: PageProps) {
  const scoped = latestScopedScans(props.scans, props.query),
    rows = scoped.flatMap((s) => s.rows),
    risks = rows.filter(matched),
    known = scoped.some((s) => s.rows.length > 0);
  const quality = rows.filter(
    (r) => r.ccr === null || r.nfs === null || r.metric_status !== "success",
  );
  const todo = risks.filter(
    (r) => (props.actions[r.id]?.status || "open") !== "closed",
  );
  const regions = [...new Set(rows.map((r) => r.member.region || "区域待补"))]
    .map((region) => ({
      name: region,
      count: risks.filter((r) => (r.member.region || "区域待补") === region)
        .length,
    }))
    .sort((a, b) => b.count - a.count);
  const top = risks
    .slice()
    .sort((a, b) => (b.ccr ?? -1) - (a.ccr ?? -1))
    .slice(0, 5);
  const scopeNote = "当前用户 · 所选范围内各项目最近一次扫描";
  return (
    <div data-testid="overview-page">
      <section className="tg-overviewhero">
        <div>
          <span className="tg-eyebrow">GOVERNANCE OVERVIEW</span>
          <h2>从风险发现，到治理跟进</h2>
          <p>集中查看客户风险、待办进展与数据覆盖。</p>
          <div className="tg-inline">
            <Badge>
              {props.query?.start_date || unknown} —{" "}
              {props.query?.end_date || unknown}
            </Badge>
            <Badge>{scopeNote}</Badge>
          </div>
        </div>
        <button
          className="tg-btn primary"
          onClick={() => props.onNavigate("risk")}
        >
          进入预警工作台 →
        </button>
      </section>
      <Metrics
        items={[
          {
            label: "已纳入监控客户",
            value: known
              ? scoped.reduce((n, s) => n + s.member_count, 0)
              : unknown,
            hint: "按各项目去重；跨项目分别计数",
          },
          {
            label: "高风险客户",
            value: known
              ? risks.filter((r) => r.level === "critical").length
              : unknown,
            hint: "当前扫描命中 CCR 绝对门槛",
            tone: "danger",
          },
          {
            label: "待跟进风险",
            value: known ? todo.length : unknown,
            hint: "待处理、处理中与待复核",
          },
          {
            label: "指标待补齐",
            value: known ? quality.length : unknown,
            hint: "缺失或失败的已返回客户",
          },
        ]}
      />
      <div className="tg-projectgrid">
        {["ET", "THT", "ST"].map((program) => {
          const scan = scoped.find((s) => s.request.program === program);
          return (
            <section className="tg-card tg-project" key={program}>
              <div className="tg-cardhead">
                <div className="tg-projectname">
                  <span>{program}</span>
                  <div>
                    <h2>{program} 客户监控</h2>
                    <small>
                      {program === "THT" ? "Advertiser ID" : "Account ID"} 粒度
                    </small>
                  </div>
                </div>
                <Badge tone={scan?.complete ? "good" : ""}>
                  {scan
                    ? scan.status === "running"
                      ? "查询中"
                      : scan.complete
                        ? "已完成"
                        : "部分覆盖"
                    : "尚未扫描"}
                </Badge>
              </div>
              <div className="tg-projectnumbers">
                <div>
                  <strong>{scan ? scan.member_count : unknown}</strong>
                  <small>监控客户</small>
                </div>
                <div>
                  <strong>
                    {scan ? scan.rows.filter(matched).length : unknown}
                  </strong>
                  <small>命中预警</small>
                </div>
                <div>
                  <strong>{scan ? scan.done : unknown}</strong>
                  <small>已查询</small>
                </div>
              </div>
              <button
                className="tg-link"
                onClick={() => props.onNavigate("data", program)}
              >
                查看 {program} 数据 →
              </button>
            </section>
          );
        })}
      </div>
      <div className="tg-two">
        <section className="tg-card">
          <div className="tg-cardhead">
            <h2>区域风险分布</h2>
            <Badge>按提报区域</Badge>
          </div>
          {regions.length ? (
            regions.map((r) => (
              <Meter
                key={r.name}
                label={r.name}
                count={r.count}
                total={risks.length}
              />
            ))
          ) : (
            <Empty>完成扫描后展示区域分布</Empty>
          )}
        </section>
        <section className="tg-card">
          <div className="tg-cardhead">
            <h2>风险处理进展</h2>
            <button
              className="tg-link"
              onClick={() => props.onNavigate("analysis")}
            >
              查看分析 →
            </button>
          </div>
          {Object.entries(statusLabels).map(([key, label]) => (
            <Meter
              key={key}
              label={label}
              count={
                risks.filter(
                  (r) => (props.actions[r.id]?.status || "open") === key,
                ).length
              }
              total={risks.length}
              tone={
                key === "closed" ? "green" : key === "open" ? "orange" : "blue"
              }
            />
          ))}
          {!known && <p className="tg-muted">暂无扫描记录，进度尚不可评估。</p>}
        </section>
      </div>
      <section className="tg-card">
        <div className="tg-cardhead">
          <h2>重点关注客户</h2>
          <button className="tg-link" onClick={() => props.onNavigate("risk")}>
            查看全部风险 →
          </button>
        </div>
        <div className="tg-tablewrap">
          <table>
            <thead>
              <tr>
                <th>客户 / ID</th>
                <th>项目 / 区域</th>
                <th>CCR / NFS</th>
                <th>提报人</th>
                <th>跟进状态</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              {top.map((r) => (
                <tr key={r.id}>
                  <td>
                    <strong>{r.member.account_name || entityId(r)}</strong>
                    <small>{entityId(r)}</small>
                  </td>
                  <td>
                    {r.program}
                    <small>{r.member.region || "区域待补"}</small>
                  </td>
                  <td>
                    {fmt(r.ccr)} / {fmt(r.nfs)}
                  </td>
                  <td>{r.member.submitter || "待补充"}</td>
                  <td>{statusLabels[props.actions[r.id]?.status || "open"]}</td>
                  <td>
                    <button
                      className="tg-link"
                      onClick={() =>
                        props.onOpen(
                          r,
                          scoped.find((s) => s.request.program === r.program)!,
                        )
                      }
                    >
                      查看详情 →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!top.length && (
            <Empty>
              {known
                ? "当前已返回范围暂无命中客户；请结合覆盖状态判断。"
                : "尚无真实扫描结果"}
            </Empty>
          )}
        </div>
      </section>
      <div className="tg-guidegrid">
        {[
          ["01", "检查业务数据", "查看名单、客户级指标与数据质量", "data"],
          ["02", "核查并处理风险", "按提报人关联客户，记录归因与措施", "risk"],
          [
            "03",
            "复盘治理进展",
            "查看处置状态、归因分布与操作时间线",
            "analysis",
          ],
        ].map(([n, title, desc, page]) => (
          <button
            className="tg-guidecard"
            key={n}
            onClick={() => props.onNavigate(page as PageName)}
          >
            <span>{n}</span>
            <h3>{title}</h3>
            <p>{desc}</p>
            <b>进入查看 →</b>
          </button>
        ))}
      </div>
      <p className="tg-footnote">
        {scopeNote}。未扫描项目显示“—”；部分覆盖不代表全量排名。
        {props.historyError}
      </p>
    </div>
  );
}
export function AnalysisPage(props: PageProps) {
  const [period, setPeriod] = useState("day"),
    [program, setProgram] = useState("all"),
    [region, setRegion] = useState("all"),
    [from, setFrom] = useState(""),
    [to, setTo] = useState("");
  // Keep one newest occurrence of an Alert ID. Repeated scans are observations, not new alerts.
  const observations = useMemo(() => {
    const map = new Map<string, { row: RiskRow; scan: Scan; first: string }>();
    for (const scan of [...props.scans].sort((a, b) =>
      a.started_at.localeCompare(b.started_at),
    )) {
      for (const row of scan.rows.filter(matched)) {
        const old = map.get(row.id);
        map.set(row.id, { row, scan, first: old?.first || scan.started_at });
      }
    }
    return [...map.values()];
  }, [props.scans]);
  const timezone = props.config?.config.timezone || "Etc/UTC";
  const dateOf = (raw: string) => {
    const d = new Date(raw);
    if (!Number.isFinite(d.getTime())) return "";
    try {
      return new Intl.DateTimeFormat("en-CA", {
        timeZone: timezone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      }).format(d);
    } catch {
      return raw.slice(0, 10);
    }
  };
  const filtered = observations.filter(
    (x) =>
      (program === "all" || x.row.program === program) &&
      (region === "all" || (x.row.member.region || "区域待补") === region) &&
      (!from || dateOf(x.first) >= from) &&
      (!to || dateOf(x.first) <= to),
  );
  const invalid = !!from && !!to && from > to;
  const rows = invalid ? [] : filtered;
  const closed = rows.filter(
    (x) => props.actions[x.row.id]?.status === "closed",
  ).length;
  const acted = rows.filter((x) => props.actions[x.row.id]);
  const events = acted
    .flatMap((x) =>
      (props.actions[x.row.id].history || []).map((event) => ({
        ...event,
        row: x.row,
        scan: x.scan,
      })),
    )
    .sort((a, b) => b.time.localeCompare(a.time));
  const bucket = (time: string) => {
    const date = dateOf(time);
    if (period === "month") return date.slice(0, 7);
    if (period === "week") {
      const d = new Date(date + "T00:00:00Z");
      d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
      return d.toISOString().slice(0, 10) + " 周";
    }
    return date;
  };
  const groups = new Map<string, number>();
  for (const x of rows) {
    const key = bucket(x.first);
    groups.set(key, (groups.get(key) || 0) + 1);
  }
  const trend = [...groups].sort(([a], [b]) => a.localeCompare(b));
  const max = Math.max(1, ...trend.map(([, n]) => n));
  const causes = [
    ...new Set(acted.map((x) => props.actions[x.row.id]?.cause || "待归因")),
  ].map((cause) => ({
    cause,
    count: acted.filter(
      (x) => (props.actions[x.row.id]?.cause || "待归因") === cause,
    ).length,
  }));
  return (
    <div data-testid="analysis-page">
      <section className="tg-card tg-analysisfilters">
        <div>
          <h2>治理周期与范围</h2>
          <p className="tg-muted">
            当前用户最近10次已保存扫描；按 Alert ID
            去重，首次出现时间为本地发现时间。
          </p>
        </div>
        <div className="tg-filtergrid">
          <label>
            统计粒度
            <select value={period} onChange={(e) => setPeriod(e.target.value)}>
              <option value="day">按日</option>
              <option value="week">按周</option>
              <option value="month">按月</option>
            </select>
          </label>
          <label>
            分析项目
            <select
              value={program}
              onChange={(e) => setProgram(e.target.value)}
            >
              <option value="all">全部项目</option>
              {["ET", "THT", "ST"].map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </label>
          <label>
            分析区域
            <select value={region} onChange={(e) => setRegion(e.target.value)}>
              <option value="all">全部区域</option>
              {[
                ...new Set(
                  observations.map((x) => x.row.member.region || "区域待补"),
                ),
              ].map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </label>
          <label>
            发现开始日期
            <input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
            />
          </label>
          <label>
            发现结束日期
            <input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
            />
          </label>
          <button
            className="tg-btn"
            onClick={() => {
              setFrom("");
              setTo("");
              setProgram("all");
              setRegion("all");
              setPeriod("day");
            }}
          >
            重置分析条件
          </button>
        </div>
        {invalid && (
          <p role="alert" className="tg-error">
            发现开始日期不能晚于结束日期
          </p>
        )}
      </section>
      <Metrics
        items={[
          {
            label: "去重预警事件",
            value: rows.length,
            hint: "同一 Alert ID 重复扫描不重复计数",
          },
          {
            label: "已关闭事件",
            value: closed,
            hint: "根据真实保存的处理状态",
          },
          {
            label: "处置完成率",
            value: rows.length
              ? ((closed / rows.length) * 100).toFixed(1) + "%"
              : unknown,
            hint: "已关闭 / 当前范围预警事件",
          },
          {
            label: "复测改善率",
            value: unknown,
            hint: "复测指标源尚未接入，不推算改善",
          },
        ]}
      />
      <div className="tg-two">
        <section className="tg-card">
          <div className="tg-cardhead">
            <h2>风险发现分布</h2>
            <Badge>
              {period === "week" ? "周" : period === "month" ? "月" : "日"} ·{" "}
              {timezone}
            </Badge>
          </div>
          {trend.length ? (
            <div
              className="tg-barchart"
              role="img"
              aria-label="按首次发现时间聚合的去重预警事件数"
            >
              {trend.map(([day, n]) => (
                <div className="tg-chartcol" key={day}>
                  <b>{n}</b>
                  <div>
                    <i style={{ height: `${Math.max(4, (n / max) * 100)}%` }} />
                  </div>
                  <small>{day}</small>
                </div>
              ))}
            </div>
          ) : (
            <Empty>所选范围暂无预警事件</Empty>
          )}
          <p className="tg-footnote">
            历史仅覆盖当前保留的扫描，不代表平台全量报警趋势。统计时区：
            {timezone}。
          </p>
        </section>
        <section className="tg-card">
          <div className="tg-cardhead">
            <h2>归因分布</h2>
            <Badge>已保存记录</Badge>
          </div>
          {causes.length ? (
            causes.map((x) => (
              <Meter
                key={x.cause}
                label={x.cause}
                count={x.count}
                total={acted.length}
              />
            ))
          ) : (
            <Empty>处理风险后，这里会展示实际归因。</Empty>
          )}
        </section>
      </div>
      <div className="tg-two">
        <section className="tg-card">
          <h2>处理状态分布</h2>
          {Object.entries(statusLabels).map(([status, label]) => (
            <Meter
              key={status}
              label={label}
              count={
                rows.filter(
                  (x) => (props.actions[x.row.id]?.status || "open") === status,
                ).length
              }
              total={rows.length}
              tone={status === "closed" ? "green" : "blue"}
            />
          ))}
        </section>
        <section className="tg-card tg-review">
          <Badge>待接入</Badge>
          <h2>客户教育与复测效果</h2>
          <p>
            处置记录已连通。教育完成情况、复测时间和前后 CCR/NFS
            需要真实执行记录与复测数据源。
          </p>
          <div className="tg-reviewmetrics">
            <span>
              教育完成数<strong>—</strong>
            </span>
            <span>
              完成复测数<strong>—</strong>
            </span>
            <span>
              CCR 改善率<strong>—</strong>
            </span>
          </div>
        </section>
      </div>
      <section className="tg-card">
        <div className="tg-cardhead">
          <h2>处置记录与复查跟进</h2>
          <span className="tg-muted">{acted.length} 条已记录事件</span>
        </div>
        <div className="tg-tablewrap">
          <table>
            <thead>
              <tr>
                <th>客户 / 项目</th>
                <th>提报人</th>
                <th>归因</th>
                <th>状态</th>
                <th>处理措施</th>
                <th>最近更新</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              {acted.map((x) => {
                const a = props.actions[x.row.id];
                return (
                  <tr key={x.row.id}>
                    <td>
                      {entityId(x.row)}
                      <small>{x.row.program}</small>
                    </td>
                    <td>{x.row.member.submitter || "待补充"}</td>
                    <td>{a.cause || "待归因"}</td>
                    <td>{statusLabels[a.status]}</td>
                    <td className="tg-notecell">{a.note}</td>
                    <td>
                      {a.updated_at?.replace("T", " ").slice(0, 19) || unknown}
                    </td>
                    <td>
                      <button
                        className="tg-link"
                        onClick={() => props.onOpen(x.row, x.scan)}
                      >
                        查看 / 跟进 →
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!acted.length && <Empty>暂无保存的处理记录</Empty>}
        </div>
      </section>
      <section className="tg-card">
        <h2>操作时间线</h2>
        {events.slice(0, 12).map((event, i) => (
          <div className="tg-event" key={i}>
            <strong>
              {statusLabels[event.status]} · {event.actor}
            </strong>
            <p>
              {entityId(event.row)} · {event.note}
            </p>
            <small>{event.time}</small>
          </div>
        ))}
        {!events.length && <Empty>保存处理记录后生成真实操作时间线</Empty>}
      </section>
      {props.historyError && <p className="tg-warning">{props.historyError}</p>}
    </div>
  );
}

export function DataTabs({
  tab,
  onChange,
}: {
  tab: string;
  onChange: (tab: string) => void;
}) {
  return (
    <div className="tg-subtabs" role="tablist" aria-label="数据中心模块">
      {[
        ["submission", "Submission & Quota"],
        ["THT", "THT 客户监控"],
        ["ST", "ST 客户监控"],
        ["ET", "ET 客户监控"],
      ].map(([key, label]) => (
        <button
          key={key}
          role="tab"
          aria-selected={tab === key}
          onClick={() => onChange(key)}
          className={tab === key ? "active" : ""}
        >
          {label}
        </button>
      ))}
    </div>
  );
}
export function SubmissionPage({ query }: Pick<PageProps, "query">) {
  return <SubmissionQuota query={query} />;
}
export function LegacySubmissionPage({
  config,
  onNavigate,
}: Pick<PageProps, "config" | "onNavigate">) {
  const [program, setProgram] = useState("all"),
    [region, setRegion] = useState("all");
  const quota = config?.quota_baseline;
  const rows = (quota?.regions || [])
    .flatMap((r) =>
      ["ET", "ST"].map((p) => ({
        region: r.region,
        program: p,
        total: r[p as "ET" | "ST"],
      })),
    )
    .filter(
      (r) =>
        (region === "all" || r.region === region) &&
        (program === "all" || r.program === program),
    );
  return (
    <div data-testid="submission-page">
      <Metrics
        items={[
          {
            label: "ET 配额基线",
            value: quota ? fmt(quota.totals.ET) : unknown,
            hint: quota?.period || "尚无配置",
          },
          {
            label: "ST 配额基线",
            value: quota ? fmt(quota.totals.ST) : unknown,
            hint: quota?.period || "尚无配置",
          },
          {
            label: "配额使用率",
            value: unknown,
            hint: "待全量成功提报工单与有效季度确认",
          },
          {
            label: "THT 配额",
            value: "无分母",
            hint: "仅统计通过客户，不计算配额使用率",
          },
        ]}
      />
      <section className="tg-card">
        <div className="tg-cardhead">
          <div>
            <h2>Submission & Quota · 区域配额</h2>
            <p className="tg-muted">
              已提供的配额基线 · {quota?.period || "待配置"}
              ；未将客户扫描数当作已使用工单数。
            </p>
          </div>
          <Badge>参考基线</Badge>
        </div>
        <div className="tg-inline tg-localfilters">
          <label>
            配额项目
            <select
              value={program}
              onChange={(e) => setProgram(e.target.value)}
            >
              <option value="all">全部项目</option>
              <option>ET</option>
              <option>ST</option>
            </select>
          </label>
          <label>
            配额区域
            <select value={region} onChange={(e) => setRegion(e.target.value)}>
              <option value="all">全部区域</option>
              {quota?.regions.map((r) => (
                <option key={r.region}>{r.region}</option>
              ))}
            </select>
          </label>
          <span className="tg-muted">
            使用率：&lt;60% 正常 · ≥60% 关注 · ≥80% 预警 · ≥100% 超额
          </span>
        </div>
        <div className="tg-tablewrap">
          <table>
            <thead>
              <tr>
                <th>区域</th>
                <th>项目</th>
                <th>配额基线</th>
                <th>已使用</th>
                <th>剩余</th>
                <th>使用率</th>
                <th>区域负责人</th>
                <th>接入状态</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.region + r.program}>
                  <td>{r.region}</td>
                  <td>{r.program}</td>
                  <td>{fmt(r.total)}</td>
                  <td>—</td>
                  <td>—</td>
                  <td>{r.total === 0 ? "不适用" : "—"}</td>
                  <td>待配置</td>
                  <td>
                    <Badge>工单明细待接入</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!rows.length && <Empty>当前范围暂无配额配置</Empty>}
        </div>
        <p className="tg-footnote">
          {quota?.source || "配额配置待提供"}。Used 应为有效范围内 APPROVE
          的去重 ticket_id；客户名单可能按 Account ID 去重，二者不可混用。
        </p>
      </section>
      <div className="tg-two">
        <section className="tg-card">
          <h2>成功提报与客户名单</h2>
          <p>
            ET / THT 已接入客户候选与提报人。完整提报量、申请通过率和 Quota
            用量需独立工单明细。
          </p>
          <div className="tg-inline">
            <button className="tg-btn" onClick={() => onNavigate("data", "ET")}>
              查看 ET 名单 →
            </button>
            <button
              className="tg-btn"
              onClick={() => onNavigate("data", "THT")}
            >
              查看 THT 名单 →
            </button>
          </div>
        </section>
        <section className="tg-card">
          <h2>配额预警与区域负责人</h2>
          <p>
            有效季度、完整用量与区域 POC
            尚待确认。接入完成后，在此展示区域配额命中与提醒对象。
          </p>
          <Badge>当前未生成配额风险</Badge>
        </section>
      </div>
    </div>
  );
}
export function DataProgramPage(
  props: PageProps & {
    program: string;
    scan?: Scan;
    singlePanel: React.ReactNode;
    table: React.ReactNode;
    loading: boolean;
    onQuery: () => void;
  },
) {
  const rows = props.scan?.rows || [];
  const selected = props.scan;
  const [customer, setCustomer] = useState("");
  const choice = rows.find((r) => entityId(r) === customer) || rows[0];
  const ccrMissing = rows.filter((r) => r.ccr == null).length,
    nfsMissing = rows.filter((r) => r.nfs == null).length;
  const groups = [
    ["CCR <3", rows.filter((r) => r.ccr != null && r.ccr < 3).length],
    [
      "3 ≤ CCR ≤45",
      rows.filter((r) => r.ccr != null && r.ccr >= 3 && r.ccr <= 45).length,
    ],
    ["CCR >45", rows.filter((r) => r.ccr != null && r.ccr > 45).length],
    ["CCR 缺失", ccrMissing],
  ] as [string, number][];
  return (
    <div data-testid="data-program-page">
      <section className="tg-card tg-dataprogram">
        <div className="tg-cardhead">
          <div>
            <span className="tg-eyebrow">
              CUSTOMER METRICS / {props.program}
            </span>
            <h2>{props.program} · CCR / NFS 指标概览</h2>
            <p className="tg-muted">
              客户级源端聚合 ·{" "}
              {props.program === "THT" ? "Advertiser ID" : "Account ID"}{" "}
              关联提报信息
            </p>
          </div>
          <button
            className="tg-btn primary"
            disabled={props.loading}
            onClick={props.onQuery}
          >
            {props.loading ? "正在扫描…" : `执行 ${props.program} 扫描`}
          </button>
        </div>
        <div className="tg-data-summary">
          <div className="tg-selectedmetric">
            <label>
              查看已返回客户
              <select
                aria-label="指标客户"
                value={choice ? entityId(choice) : ""}
                onChange={(e) => setCustomer(e.target.value)}
              >
                {!rows.length && <option value="">暂无返回客户</option>}
                {rows.map((r) => (
                  <option key={r.id} value={entityId(r)}>
                    {r.member.account_name || entityId(r)}
                  </option>
                ))}
              </select>
            </label>
            <div className="tg-metrics">
              <div>
                <span>客户 P0 CCR</span>
                <strong>{fmt(choice?.ccr)}</strong>
              </div>
              <div>
                <span>客户 P0 NFS</span>
                <strong>{fmt(choice?.nfs)}</strong>
              </div>
            </div>
            <div className="tg-inline">
              {choice && (
                <Badge tone={choice.level === "critical" ? "danger" : ""}>
                  {levelNames[choice.level] || "不可评估"}
                </Badge>
              )}
              {choice && (
                <button
                  className="tg-link"
                  onClick={() => props.onOpen(choice, selected!)}
                >
                  查看客户与风险详情 →
                </button>
              )}
            </div>
          </div>
          <div className="tg-qualitylist">
            <h3>本次数据覆盖</h3>
            <dl>
              <div>
                <dt>监控 / 已查询</dt>
                <dd>
                  {selected
                    ? `${selected.member_count} / ${selected.done}`
                    : "尚未查询"}
                </dd>
              </div>
              <div>
                <dt>CCR / NFS 缺失</dt>
                <dd>{selected ? `${ccrMissing} / ${nfsMissing}` : "—"}</dd>
              </div>
              <div>
                <dt>指标时间范围</dt>
                <dd>
                  {props.query?.start_date} 至 {props.query?.end_date}
                </dd>
              </div>
              <div>
                <dt>项目整体 CCR</dt>
                <dd>待独立聚合，不对客户 CCR 求平均</dd>
              </div>
            </dl>
            <p className="tg-footnote">
              {selected
                ? selected.complete
                  ? "名单完整性标记已确认"
                  : "本次覆盖尚未确认完整；不能宣称全量排名"
                : "尚无所选范围的扫描结果"}
            </p>
          </div>
        </div>
      </section>
      <div className="tg-two">
        <section className="tg-card">
          <h2>客户 CCR 区间分布</h2>
          {selected ? (
            groups.map(([label, count]) => (
              <Meter
                key={label}
                label={label}
                count={count}
                total={rows.length}
                tone={label === "CCR >45" ? "orange" : "blue"}
              />
            ))
          ) : (
            <Empty>查询客户指标后生成分布</Empty>
          )}
        </section>
        <section className="tg-card tg-trendpending">
          <h2>周度 CCR / NFS 趋势</h2>
          <div className="tg-trendplaceholder" aria-label="周度指标待接入">
            ▥
          </div>
          <p>
            当前接口返回所选窗口聚合值。周度趋势需要独立周粒度查询，尚未接入。
          </p>
          <Badge>待接入周度数据</Badge>
        </section>
      </div>
      {props.program === "ET" ? (
        <details className="tg-card">
          <summary>单客户实时查询</summary>
          {props.singlePanel}
        </details>
      ) : null}
      {props.table}
      <details className="tg-card">
        <summary>数据源与查询口径</summary>
        <p>{props.config?.membership_policy}</p>
        {Object.entries(props.config?.sources || {})
          .filter(([key]) =>
            key.toLowerCase().startsWith(props.program.toLowerCase()),
          )
          .map(([key, source]) => (
            <div className="tg-sourceitem" key={key}>
              <strong>{key}</strong>
              <span>
                SID {source.sid} / RID {source.rid}
              </span>
              <Badge>
                {source.configured ? "已配置 · 以实际响应验收" : "待配置"}
              </Badge>
            </div>
          ))}
      </details>
    </div>
  );
}
export function PendingProgramPage({ program }: { program: string }) {
  return (
    <div data-testid="pending-program-page">
      <Metrics
        items={[
          { label: `${program} 监控客户`, value: "—", hint: "成员源尚未接入" },
          { label: "P0 CCR", value: "—", hint: "待该项目真实指标返回" },
          { label: "P0 NFS", value: "—", hint: "待该项目真实指标返回" },
          { label: "风险预警", value: "—", hint: "未查询不代表零风险" },
        ]}
      />
      <section className="tg-card tg-connectpending">
        <Badge>待接入</Badge>
        <h2>{program} 客户监控</h2>
        <p>
          页面和字段位置已准备：成功提报名单、Account
          ID、客户名称、区域、提报人、保护时间及 CCR /
          NFS。接入本项目数据源后展示真实记录。
        </p>
        <div className="tg-tablewrap">
          <table>
            <thead>
              <tr>
                {[
                  "客户 / Account ID",
                  "区域",
                  "提报人",
                  "保护时间",
                  "P0 CCR",
                  "P0 NFS",
                  "预警判定",
                ].map((x) => (
                  <th key={x}>{x}</th>
                ))}
              </tr>
            </thead>
          </table>
          <Empty>尚无真实数据，不复用其他项目的客户与指标</Empty>
        </div>
      </section>
      <div className="tg-two">
        <section className="tg-card">
          <h2>周度风险趋势</h2>
          <Empty>等待周粒度指标源</Empty>
        </section>
        <section className="tg-card">
          <h2>风险客户 TOP20</h2>
          <Empty>完成成员与指标查询后生成</Empty>
        </section>
      </div>
    </div>
  );
}
