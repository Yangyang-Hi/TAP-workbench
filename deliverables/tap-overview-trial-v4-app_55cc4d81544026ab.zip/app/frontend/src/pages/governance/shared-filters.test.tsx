import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { SharedFilterBar, SharedFilterProvider, filterQuery, useSharedFilters } from "./shared-filters";

function Probe() { const { filters } = useSharedFilters(); return <output data-testid="probe">{JSON.stringify(filters)}</output>; }
afterEach(() => { cleanup(); history.replaceState(null, "", "/"); });

describe("共享筛选", () => {
  it("保留统一 Tier、Region、原提报人和搜索", () => {
    render(<SharedFilterProvider><SharedFilterBar /><Probe /></SharedFilterProvider>);
    expect(screen.getByLabelText("共享 Tier")).toBeTruthy();
    expect(screen.getByLabelText("共享 Region")).toBeTruthy();
    expect(screen.getByLabelText("共享提报人")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("共享客户搜索"), { target: { value: "Account 1" } });
    expect(filterQuery({ tier: "ET", region: "all", submitter: "", search: "Account 1", time_mode: "weekly", batch_id: "", start_date: "", end_date: "", only_mine: false, alert_start_date: "", alert_end_date: "", alert_level: "all", status: "all" })).toMatchObject({ program: "ET", search: "Account 1" });
    expect(screen.getByTestId("probe").textContent).toContain('"search":"Account 1"');
    expect(screen.queryByText("我的待办")).toBeNull();
    expect(screen.queryByText("我的提报")).toBeNull();
  });
  it("只看我的仅生成后端 only_mine，不猜测身份", () => {
    render(<SharedFilterProvider><SharedFilterBar /><Probe /></SharedFilterProvider>);
    fireEvent.click(screen.getAllByLabelText("只看我的")[0]);
    expect(screen.getByTestId("probe").textContent).toContain('"only_mine":true');
    expect(screen.getByText(/仅向后端传递 only_mine/)).toBeTruthy();
    expect(filterQuery(JSON.parse(screen.getByTestId("probe").textContent || "{}"))).toMatchObject({ only_mine: true });
  });
  it("周度无批次与自定义时间状态诚实展示", () => {
    render(<SharedFilterProvider><SharedFilterBar batches={[]} /><Probe /></SharedFilterProvider>);
    expect(screen.getByText("暂无历史批次")).toBeTruthy();
    fireEvent.click(screen.getByText("自定义时间"));
    expect(screen.getByText("自定义区间仅查询，不建单、不发送")).toBeTruthy();
  });
});
