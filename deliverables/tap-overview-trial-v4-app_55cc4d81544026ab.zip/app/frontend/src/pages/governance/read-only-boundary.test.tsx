import { describe, expect, it } from "vitest";
import source from "./index.tsx?raw";

describe("共享工作台读取边界", () => {
  it("页面打开、筛选、翻页和导出只使用 GET typed clients", () => {
    expect(source).toContain("workbenchBatchesList");
    expect(source).toContain("workbenchReadModelList");
    expect(source).not.toMatch(/Create\s*\(/);
    expect(source).not.toContain("fetch(");
    expect(source).not.toContain("apiFetch(");
    expect(source).not.toContain("risk-scans");
    expect(source).not.toContain("/notify");
  });
  it("不再存在 requestedView 或角色视角分支", () => {
    expect(source).not.toContain("requestedView");
    expect(source).not.toContain('params.get("view")');
    expect(source).not.toContain("运营工作台视角");
  });
});
