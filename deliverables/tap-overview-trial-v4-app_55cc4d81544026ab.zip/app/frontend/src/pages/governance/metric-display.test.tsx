import { describe, expect, it } from "vitest";
import { conservativeMetricFact, formatMetricFact } from "./metric-display";

describe("MetricDisplay status contract", () => {
  it("distinguishes source null, zero, failure and querying", () => {
    expect(formatMetricFact({ value: null, status: "source_null", reason: "源指标缺失" })).toEqual({ value: "NULL", reason: "源指标缺失" });
    expect(formatMetricFact({ value: 0, status: "available" })).toEqual({ value: "0", reason: "" });
    expect(formatMetricFact({ value: null, status: "failed", reason: "字段解析失败" })).toEqual({ value: "—", reason: "字段解析失败" });
    expect(formatMetricFact({ value: null, status: "querying" })).toEqual({ value: "查询中", reason: "查询未结束" });
  });

  it("renders increase null and zero-baseline boundaries without guessing legacy null", () => {
    expect(formatMetricFact({ value: null, status: "source_null", reason: "源指标缺失" }, "pct").value).toBe("NULL");
    expect(formatMetricFact({ value: null, status: "not_applicable", reason: "基数为零、无法计算增幅" }, "pct")).toEqual({ value: "N/A", reason: "基数为零、无法计算增幅" });
    expect(formatMetricFact({ value: -100, status: "available" }, "pct").value).toBe("-100.00%");
    expect(conservativeMetricFact(null).status).toBe("failed");
  });
});
