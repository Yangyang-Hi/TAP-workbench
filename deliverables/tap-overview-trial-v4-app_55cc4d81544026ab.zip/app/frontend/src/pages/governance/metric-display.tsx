import type { ReactNode } from "react";

export type MetricStatus = "available" | "source_null" | "failed" | "not_configured" | "querying" | "not_applicable" | "unknown";
export type MetricFact = { value: number | null; status: MetricStatus | string; reason?: string };
export type MetricFormat = "metric" | "ccr" | "nfs" | "revenue" | "pct";

const formatValue = (value: number, format: MetricFormat) => {
  if (format === "ccr" || format === "revenue") return value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (format === "nfs") return Math.round(value).toLocaleString("en-US");
  if (format === "pct") return `${value > 0 ? "+" : ""}${value.toFixed(2)}%`;
  return value.toLocaleString("en-US", { maximumFractionDigits: 6 });
};

export const conservativeMetricFact = (value: number | null | undefined, status?: string, reason?: string): MetricFact => {
  if (value != null) return { value, status: "available", reason };
  const normalized = status?.trim().toLowerCase();
  if (normalized === "source_null" || normalized === "field_null" || normalized === "success") return { value: null, status: "source_null", reason: reason || "源指标缺失" };
  if (["querying", "pending", "running", "window_incomplete"].includes(normalized || "")) return { value: null, status: "querying", reason: reason || "查询未结束" };
  if (["not_configured", "unsupported"].includes(normalized || "")) return { value: null, status: "not_configured", reason: reason || "功能未接通" };
  if (normalized === "not_applicable" || normalized === "baseline_zero") return { value: null, status: "not_applicable", reason: reason || "基数为零、无法计算增幅" };
  return { value: null, status: "failed", reason: reason || "旧批次未记录指标状态" };
};

export const formatMetricFact = (fact: MetricFact | undefined, format: MetricFormat = "metric") => {
  if (!fact) return { value: "—", reason: "指标状态未返回" };
  if (fact.status === "available") return fact.value == null ? { value: "—", reason: fact.reason || "可用状态缺少数值" } : { value: formatValue(fact.value, format), reason: fact.reason || "" };
  if (fact.status === "source_null") return { value: "NULL", reason: fact.reason || "源指标缺失" };
  if (fact.status === "querying") return { value: "查询中", reason: fact.reason || "查询未结束" };
  if (fact.status === "not_applicable") return { value: "N/A", reason: fact.reason || "基数为零、无法计算增幅" };
  return { value: "—", reason: fact.reason || (fact.status === "not_configured" ? "功能未接通" : "查询失败") };
};

export function MetricDisplay({ fact, format = "metric", className, suffix }: { fact: MetricFact | undefined; format?: MetricFormat; className?: string; suffix?: ReactNode }) {
  const display = formatMetricFact(fact, format);
  return <span className={className} title={display.reason || undefined}>{display.value}{suffix}{display.reason && fact?.status !== "available" ? <small> · {display.reason}</small> : null}</span>;
}
