import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { AccountDistribution, type AccountDistributionData } from "./overview-accounts";
const api = vi.hoisted(() => vi.fn());
vi.mock("./api", () => ({ workbenchApi: api }));
const data: AccountDistributionData = {
  status: "available", requested_end_date: "2026-10-26", data_as_of: "2026-10-25", region: "Global", tier_membership_total: 100,
  rows: ["ST", "HT", "BT", "ET"].map((tier, i) => ({ tier, source_tier: tier, account_count: (i+1)*10, account_share: (i+1)*10 })),
  queried_at: "2026-10-26T12:00:00Z", attempts: 2, diagnostics: {}, source: { rid: 2891943, sid: 1280034, app_id: 800414 },
};
beforeEach(() => { api.mockReset(); api.mockResolvedValue({ data }); });
afterEach(cleanup);
it("does not query on mount; applies only Account date and Region", async () => {
  history.replaceState(null, "", "/?program=ET&submitter=someone&tier=ET");
  render(<AccountDistribution />);
  expect(api).not.toHaveBeenCalled();
  fireEvent.change(screen.getByLabelText("账户快照截止日期"), { target: { value: "2026-10-26" } });
  fireEvent.click(screen.getByRole("button", { name: "应用筛选" }));
  expect(await screen.findByRole("img")).toBeTruthy();
  expect(api.mock.calls[0][0]).toBe("/api/overview/accounts?end_date=2026-10-26&region=Global");
  expect(screen.getByText("2026-10-25")).toBeTruthy();
  expect(screen.getByText("40.0%")).toBeTruthy();
  history.replaceState(null, "", "/");
});
it("partial result shows missing values without a misleading donut", async () => {
  api.mockResolvedValue({ data: { ...data, status: "partial", tier_membership_total: null, reason: "Tier missing", rows: data.rows.map((row, i) => ({ ...row, account_count: i === 0 ? null : row.account_count, account_share: null })) } });
  render(<AccountDistribution />); fireEvent.click(screen.getByText("应用筛选"));
  expect(await screen.findByText("Tier missing")).toBeTruthy();
  expect(screen.queryByRole("img")).toBeNull();
  expect(screen.getAllByText("—").length).toBeGreaterThan(0);
});
it("source failure stays unavailable, with retry", async () => {
  api.mockRejectedValueOnce(Error("HTTP 403"));
  render(<AccountDistribution />); fireEvent.click(screen.getByText("应用筛选"));
  expect(await screen.findByRole("alert")).toBeTruthy();
  expect(screen.queryByRole("img")).toBeNull();
  fireEvent.click(screen.getByText("应用筛选"));
  expect(await screen.findByRole("img")).toBeTruthy();
});
it("a response for an old filter cannot replace a new result", async () => {
  let resolveOld!: (value: { data: AccountDistributionData }) => void;
  api.mockImplementationOnce(() => new Promise(resolve => { resolveOld = resolve; }));
  render(<AccountDistribution />); fireEvent.click(screen.getByText("应用筛选"));
  const oldSignal = api.mock.calls[0][2] as AbortSignal;
  fireEvent.change(screen.getByLabelText("账户分布区域"), { target: { value: "APAC" } });
  expect(oldSignal.aborted).toBe(true);
  api.mockResolvedValueOnce({ data: { ...data, region: "APAC", data_as_of: "2026-10-24" } });
  fireEvent.click(screen.getByText("应用筛选"));
  await screen.findByText("2026-10-24");
  resolveOld({ data });
  await waitFor(() => expect(screen.queryByText("2026-10-25")).toBeNull());
});
it("zero denominator does not draw shares", async () => {
  api.mockResolvedValue({ data: { ...data, tier_membership_total: 0, rows: data.rows.map(row => ({ ...row, account_count: 0, account_share: null })) } });
  render(<AccountDistribution />); fireEvent.click(screen.getByText("应用筛选"));
  expect(await screen.findByText("占比暂不可用")).toBeTruthy();
  expect(screen.queryByRole("img")).toBeNull();
});
