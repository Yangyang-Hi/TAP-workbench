import { render, screen } from "@testing-library/react";
import { SharedFilterBar, SharedFilterProvider, filterQuery } from "./shared-filters";
import { describe, expect, it } from "vitest";

describe("预警历史共享筛选", () => {
  it("将预警日期、等级和状态透传到统一 query", () => {
    const query = filterQuery({
      time_mode: "weekly",
      batch_id: "batch-1",
      start_date: "",
      end_date: "",
      tier: "ET",
      region: "APAC",
      submitter: "user1",
      search: "test",
      only_mine: true,
      alert_start_date: "2026-10-01",
      alert_end_date: "2026-10-31",
      alert_level: "critical",
      status: "open",
    });
    expect(query).toMatchObject({
      program: "ET",
      region: "APAC",
      submitter: "user1",
      search: "test",
      only_mine: true,
      alert_start_date: "2026-10-01",
      alert_end_date: "2026-10-31",
      alert_level: "critical",
      status: "open",
    });
  });

  it("显示新增的预警筛选控件", () => {
    render(<SharedFilterProvider><SharedFilterBar /></SharedFilterProvider>);
    expect(screen.getByLabelText("预警等级")).toBeTruthy();
    expect(screen.getByLabelText("当前状态")).toBeTruthy();
    expect(screen.getByLabelText("预警产生日期")).toBeTruthy();
  });
});

