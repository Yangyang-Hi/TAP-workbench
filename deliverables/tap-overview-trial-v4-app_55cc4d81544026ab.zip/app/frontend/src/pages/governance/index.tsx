import { Button, Spin, Tabs } from "@arco-design/web-react";
import { Download, RefreshCw, ShieldCheck } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { workbenchBatchesList, workbenchReadModelList, unwrap } from "../../api/client.gen";
import { Analysis, DataCenter, Overview, RiskMonitor, UnsupportedState } from "./workbench-pages";
import { WorkbenchSettings } from "./casework";
import { SubmitterCasework } from "./casework-task";
import type { Batch, ReadModel } from "./read-model";
import { filterQuery, SharedFilterBar, SharedFilterProvider, useSharedFilters } from "./shared-filters";
import { isOverviewRoute, isTaskRoute, useRouteLocation } from "../../route-state";
import "./operations.css";
import { AccountDistribution, OverviewTrialPage } from "./overview-accounts";

const tabs = [
  ["overview", "数据总览 / Overview"],
  ["risk", "风险监控与预警"],
  ["analysis", "治理效果分析"],
  ["data", "运营数据中心"],
] as const;

function csvExport(model: ReadModel) {
  const values = [["Alert ID", "Account ID", "Account Name", "Tier", "Region", "Original Submitter", "CCR", "NFS", "Revenue", "Event Stage", "Notification"], ...model.rows.map((row) => [row.alert_id, row.account_id, row.account_name, row.tier || row.program, row.region, row.original_submitter, row.p0_ccr, row.p0_nfs, row.revenue, row.event_stage, row.notification.status])];
  const csv = `\uFEFF${values.map((line) => line.map((value) => `"${String(value ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n")}`;
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a"); link.href = url; link.download = "TAP_workbench_readonly.csv"; link.click(); URL.revokeObjectURL(url);
}

export default function GovernanceWorkbench() {
  const route = useRouteLocation();
  const params = route.searchParams;
  if (isOverviewRoute(params)) return <OverviewTrialPage />;
  if (isTaskRoute(params)) {
    return <SubmitterCasework alertId={params.get("alert_id") || ""} />;
  }
  return <SharedFilterProvider><WorkbenchContent /></SharedFilterProvider>;
}

function WorkbenchContent() {
  const { filters } = useSharedFilters();
  const [tab, setTab] = useState<(typeof tabs)[number][0]>(() => {
    const params = new URLSearchParams(location.search);
    const requested = params.get("tab");
    if (tabs.some(([key]) => key === requested)) return requested as (typeof tabs)[number][0];
    return params.has("alert_id") ? "risk" : "overview";
  });
  const [stage, setStage] = useState("all");
  const [ranking, setRanking] = useState<"combined" | "growth" | "absolute">("combined");
  const [page, setPage] = useState(1);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [model, setModel] = useState<ReadModel>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    workbenchBatchesList().then((response) => {
      if (!active) return;
      const data = unwrap(response);
      setBatches(data.batches as Batch[]);
    }).catch((reason) => { if (active) setError(reason instanceof Error ? reason.message : "周度批次读取失败"); });
    return () => { active = false; };
  }, []);

  const query = useMemo(() => filterQuery(filters, { stage: stage === "all" ? undefined : stage, ranking, page, page_size: 50, view: tab === "data" ? "customers" : undefined }), [filters, stage, ranking, page, tab]);
  const load = useCallback(async () => {
    if (filters.time_mode === "custom" && (!filters.start_date || !filters.end_date)) { setModel(undefined); setLoading(false); return; }
    if (filters.time_mode === "custom") setModel(undefined);
    setLoading(true); setError("");
    try { const response = await workbenchReadModelList<{ data: ReadModel }>(query); setModel(unwrap(response)); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "工作台读取失败"); setModel(undefined); }
    finally { setLoading(false); }
  }, [filters.time_mode, filters.start_date, filters.end_date, query]);
  useEffect(() => {
    if (filters.time_mode === "weekly") void load();
    else { setModel(undefined); setLoading(false); }
  }, [load, filters.time_mode]);

  const submitters = useMemo(() => [...new Set(model?.rows.map((row) => row.original_submitter).filter(Boolean) || [])], [model]);
  const regions = useMemo(() => [...new Set(model?.rows.map((row) => row.region).filter(Boolean) || [])], [model]);
  const onRanking = (value: "combined" | "growth" | "absolute") => { setRanking(value); setPage(1); };
  const body = tab === "data" ? <DataCenter model={model} /> : tab === "analysis" ? <Analysis model={model} /> : !model ? null : model.status === "unsupported" && tab !== "risk" ? <UnsupportedState model={model} /> : tab === "overview" ? <Overview model={model} /> : tab === "risk" ? <RiskMonitor model={model} stage={stage} onStage={setStage} ranking={ranking} onRanking={onRanking} page={page} onPage={setPage} onSaved={() => void load()} /> : null;

  return <main className="ops-app" data-testid="governance-workbench">
    <header className="ops-header"><div className="ops-brand"><div className="ops-brand-mark"><ShieldCheck size={22} /></div><div><span>TAP GOVERNANCE</span><h1>风险治理工作台</h1></div></div><div className="ops-header-actions"><Button icon={<RefreshCw size={14} />} onClick={() => void load()} loading={loading}>{filters.time_mode === "custom" ? (model ? "刷新自定义查询" : "执行自定义查询") : "刷新数据"}</Button><Button icon={<Download size={14} />} disabled={!model?.rows.length} onClick={() => model && csvExport(model)}>导出当前页</Button></div></header>
    <Tabs className="ops-main-tabs" activeTab={tab} onChange={(value) => setTab(value as typeof tab)}>{tabs.map(([key, label]) => <Tabs.TabPane key={key} title={label} />)}</Tabs>
    <div className="ops-content"><div className="ops-page-title"><div><h2>{tabs.find(([key]) => key === tab)?.[1]}</h2><p>{tab === "risk" ? "查看风险客户，跟进预警通知与处置。" : tab === "overview" ? "掌握风险概况与通知进度。" : tab === "analysis" ? "查看处理进度与复查记录。" : "按条件查询客户与配额数据。"}</p></div><span className="ops-live-dot">共享工作台</span></div>{tab === "overview" && <AccountDistribution />}<SharedFilterBar batches={batches} availableSubmitters={submitters} availableRegions={regions} />
      {filters.time_mode === "custom" && (!filters.start_date || !filters.end_date) && <section className="ops-state"><b>请选择自定义开始和结束日期</b><p>日期完整后点击“执行自定义查询”；查询不生成事件或发送通知。</p></section>}
      {filters.time_mode === "custom" && filters.start_date && filters.end_date && !model && !loading && <section className="ops-state"><b>自定义时间已就绪</b><p>点击“执行自定义查询”后读取权威数据；修改日期或筛选不会自动建单、发送或改动周度榜单。</p></section>}
      {tab === "risk" && <WorkbenchSettings />}
      {error && <section className="ops-state ops-state-error" role="alert"><b>读取失败</b><p>{error}</p></section>}
      {loading && !model ? <div className="ops-loading"><Spin /><span>{filters.time_mode === "custom" ? "正在查询自定义时间内的风神指标（最长 3 分钟）…" : "正在读取只读工作台…"}</span></div> : body}
      {model?.status === "empty" && <section className="ops-state"><b>暂无历史批次</b><p>{model.reason || "no_persisted_weekly_batch"}</p></section>}
    </div>
  </main>;
}
