import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { SubmissionQuota } from "./submission-quota";

const getQuota = vi.hoisted(() => vi.fn());
const syncST = vi.hoisted(() => vi.fn());
vi.mock("../../api/client.gen", () => ({
  submissionsQuotaList: getQuota,
  submissionsStSnapshotsCreate: syncST,
  unwrap: (response: { data: unknown }) => response.data,
}));

afterEach(() => {
  cleanup();
  getQuota.mockReset();
  syncST.mockReset();
});

const response = {
  data: {
    status: "ready",
    quota: {
      as_of: { st: "2026-10-20 14:00 CST" },
      global: {
        st: { quota: 100, used: 72, ratio: 72, status: "yellow" },
        et: { quota: 80, used: 84, ratio: 105, status: "red" },
        tht: { quota: null, used: 31, ratio: null, status: "no_denominator" },
      },
      regions: [
        { region: "APAC", st: { quota: 0, used: 2, ratio: null, status: "unavailable" }, et: { quota: 40, used: 24, ratio: 60, status: "yellow" }, tht: { quota: null, used: 4, ratio: null, status: "no_denominator" } },
      ],
      weekly: [{ week_start: "2026-10-05", et_qtd: 12, tht_qtd: 7 }],
    },
  },
};

describe("Submission & Quota", () => {
  it("shows independent ST controls, global ET/THT dates and the unified table", async () => {
    getQuota.mockResolvedValue(response);
    render(<SubmissionQuota query={{ program: "ET", region: "all", start_date: "2026-10-01", end_date: "2026-10-20", member_start_date: "", member_end_date: "" }} />);
    expect(await screen.findByRole("heading", { name: "提报与配额运行视图" })).toBeTruthy();
    expect(screen.getByText("由同一日期控件自动映射季度，不按天切分或折算")).toBeTruthy();
    expect(screen.getByRole("columnheader", { name: "Data As Of" })).toBeTruthy();
    expect(screen.getAllByText("N/A").length).toBeGreaterThan(0);
    expect(screen.getAllByText("72.0%").length).toBeGreaterThan(0);
    expect(screen.getByText("ET 按 Account、THT 按 Advertiser 在查询窗口内累计去重；不是各周去重数相加。")).toBeTruthy();
    await waitFor(() => expect(getQuota).toHaveBeenLastCalledWith(expect.objectContaining({ quarter: "Q4", start_date: "2026-10-01" })));
  });

  it("never presents a zero denominator or mapping failure as zero usage", async () => {
    getQuota.mockResolvedValue(response);
    render(<SubmissionQuota />);
    expect((await screen.findAllByText("APAC")).length).toBeGreaterThan(0);
    expect(screen.getAllByText("数据暂不可用").length).toBeGreaterThan(0);
    expect(screen.queryByText("0.0%")).toBeNull();
  });

  it("uses the same unavailable state for API failures", async () => {
    getQuota.mockRejectedValue(new Error("failed"));
    render(<SubmissionQuota />);
    expect((await screen.findByRole("alert")).textContent).toContain("数据暂不可用");
  });
});

it("applies ET inclusive and ST exclusive quota boundaries", async () => {
  getQuota.mockResolvedValue({data:{status:"ready",quota:{global:{et:{quota:100,used:150,ratio:150}},regions:[{region:"ET_99_9",et:{quota:1000,used:999,ratio:99.9}},{region:"BOUNDARY",regional_poc:"ET POC",notification_status:"ready_in_test_mode",et:{quota:100,used:100,ratio:100}},{region:"OVER",et:{quota:1000,used:1001,ratio:100.1}},{region:"ST_BOUNDARY",st:{quota:100,used:100,ratio:100}},{region:"ST_OVER",st:{quota:1000,used:1001,ratio:100.1}},{region:"THT_FAKE",tht:{quota:1,used:2,ratio:200}},{region:"PARTIAL",et:{quota:100,used:150,ratio:150,complete:false}}]}}});
  render(<SubmissionQuota alertsOnly />);
  await screen.findByText("OVER");
  expect(screen.getByText("BOUNDARY")).toBeTruthy();
  expect(screen.getByText("ST_OVER")).toBeTruthy();
  expect(screen.queryByText("ET_99_9")).toBeNull();
  expect(screen.queryByText("ST_BOUNDARY")).toBeNull();
  expect(screen.queryByText("THT_FAKE")).toBeNull();
  expect(screen.queryByText("PARTIAL")).toBeNull();
  expect(screen.queryByText("Global")).toBeNull();
  expect(screen.getByText("ready in test mode")).toBeTruthy();
  expect(screen.getAllByText("blocked missing POC").length).toBeGreaterThan(0);
});

it("renders API percentage points faithfully below 2 percent", async () => {
  getQuota.mockResolvedValue({data:{status:"ready",quota:{global:{et:{quota:1000,used:15,ratio:1.5}},regions:[]}}});
  render(<SubmissionQuota />);
  await screen.findAllByText("1.5%");
  expect(screen.queryByText("150.0%")).toBeNull();
});


it("renders the real available API envelope and sends only supported quota parameters", async () => {
  getQuota.mockResolvedValue({
    data: {
      status: "available",
      quarter: "Q4",
      quota_contract: { confirmed_for_quarter: true },
      global: {
        et: { used: 1755, quota: 6356, ratio: 27.61, status: "green", complete: true },
        st: { used: 793, quota: 1925, ratio: 41.19, status: "green", complete: true },
        tht: { used: 342, distinct_advertiser_count: 342, quota: null, ratio: null, status: "no_denominator", complete: true },
      },
      regions: [],
    },
  });
  render(<SubmissionQuota query={{ program: "ET", region: "all", start_date: "2026-10-01", end_date: "2026-10-23", member_start_date: "", member_end_date: "" }} />);
  expect((await screen.findAllByText("27.6%")).length).toBeGreaterThan(0);
  expect(screen.getAllByText("41.2%").length).toBeGreaterThan(0);
  expect(screen.getAllByText("342").length).toBeGreaterThan(0);
  expect(screen.queryByRole("alert")).toBeNull();
  expect(getQuota).toHaveBeenCalledWith({ quarter: "Q4", start_date: "2026-10-01", end_date: "2026-10-23" });
});

it("distinguishes a ROW gateway 403 and keeps retry available", async () => {
  getQuota.mockRejectedValue(new Error("GET /api/submissions/quota failed: HTTP 403"));
  render(<SubmissionQuota alertsOnly />);
  expect((await screen.findByRole("alert")).textContent).toContain("ROW 网关拒绝访问（HTTP 403）");
  expect(screen.getByRole("button", { name: "重试" })).toBeTruthy();
});

it("sends weekly mode instead of invalid empty dates and displays the resolved QTD window", async () => {
  getQuota.mockResolvedValue({data:{...response.data.quota,status:"available",quarter:"Q4",time:{start_date:"2026-10-01",end_date:"2026-10-23",basis:"live_qtd_no_weekly_batch"}}});
  render(<SubmissionQuota />);
  await waitFor(()=>expect(getQuota).toHaveBeenCalledWith({quarter:"Q4",time_mode:"weekly"}));
  expect(screen.getByText("2026-10-01 → 2026-10-23")).toBeTruthy();
  expect(screen.queryByText(/未设置开始日期/)).toBeNull();
});

it("does not label a failed query as zero alerts or no quota risk", async () => {
  getQuota.mockRejectedValue(new Error("GET /api/submissions/quota failed: HTTP 400"));
  render(<SubmissionQuota />);
  expect((await screen.findByRole("alert")).textContent).toContain("HTTP 400");
  expect(screen.getByText("待判定")).toBeTruthy();
  expect(screen.queryByText("当前范围无超过 100% 的 ET / ST 区域预警。")).toBeNull();
  expect(screen.queryByText("0 条")).toBeNull();
});

it("offers explicit ST snapshot synchronization and reloads after success", async () => {
  getQuota.mockResolvedValue(response);syncST.mockResolvedValue({data:{status:"success"}});
  render(<SubmissionQuota />);
  await screen.findAllByText("72.0%");
  const before=getQuota.mock.calls.length;
  fireEvent.click(screen.getByRole("button",{name:"同步 ST 权威表"}));
  await waitFor(()=>expect(syncST).toHaveBeenCalledWith({}));
  await waitFor(()=>expect(getQuota.mock.calls.length).toBeGreaterThan(before));
});


it("separates account quota from tickets and shows the brand total discrepancy", async () => {
  getQuota.mockResolvedValue({data:{global:{et:{used:1,account_count:1,ticket_count:2,quota:100,ratio:1,status:"green"},st:{used:1,brand_count:1,account_count:2,quota:817,ratio:100/817,status:"green"}},warnings:["ST Brand 配额表总计标注 816，各区域相加为 817。"]}});
  render(<SubmissionQuota />);
  expect(await screen.findByText("Account 占用 1 · 通过工单 2 · Account Quota 100")).toBeTruthy();
  expect(screen.getByText("ST Brand 配额表总计标注 816，各区域相加为 817。")).toBeTruthy();
  expect(screen.getAllByText("Account 2 · Brand 1 · Quota 817").length).toBeGreaterThan(0);
});
