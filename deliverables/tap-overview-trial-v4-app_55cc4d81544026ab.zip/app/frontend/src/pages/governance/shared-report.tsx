import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { unwrap, workbenchAnalyticsReportsByReportIdGet } from "../../api/client.gen";

type FrozenReport={report_id:string;title:string;generated_at:string;content_html:string};

export default function SharedReportPage(){
 const {reportId=""}=useParams();
 const [report,setReport]=useState<FrozenReport>();
 const [error,setError]=useState("");
 useEffect(()=>{void workbenchAnalyticsReportsByReportIdGet<{data:FrozenReport}>(reportId).then(x=>setReport(unwrap(x))).catch(e=>setError(e instanceof Error?e.message:"报告读取失败"))},[reportId]);
 if(error)return <main className="cw-report"><div className="cw-error" role="alert"><strong>报告无法读取</strong><p>{error}</p></div></main>;
 if(!report)return <main className="cw-report"><p>正在读取固定报告版本…</p></main>;
 return <main data-testid="shared-report-page" style={{height:"100vh"}}><iframe title={report.title} srcDoc={report.content_html} sandbox="allow-popups" style={{width:"100%",height:"100%",border:0}}/></main>;
}
