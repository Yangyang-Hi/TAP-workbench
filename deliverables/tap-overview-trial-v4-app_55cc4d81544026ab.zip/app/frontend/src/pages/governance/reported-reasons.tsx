import type { AdvertiserEvidence, ReportedReason } from "./read-model";
import { ccr } from "./read-model";

export type ReportedReasonGroup = {
  advertiser_id?: string;
  reasons: ReportedReason[];
  status?: string;
  error?: string;
  sortBasis?: string;
};

const basisLabel = (basis?: string) => {
  if (basis === "p0_ccr_desc" || basis === "CCR") return "CCR";
  if (basis === "nfs_fallback_all_ccr_null" || basis === "NFS") return "NFS";
  return "—";
};

export function ReportedReasonsView({ groups }: { groups: ReportedReasonGroup[] }) {
  if (!groups.length) return <span>暂无有效举报原因</span>;
  return <div className="ops-reported-reasons">
    {groups.map((group, groupIndex) => <div key={`${group.advertiser_id || "unknown"}-${groupIndex}`}>
      {group.advertiser_id && <small>Advertiser {group.advertiser_id}</small>}
      {group.status === "failed" || group.status === "query_failed"
        ? <p role="alert">举报原因查询失败：{group.error || "原因级数据源暂不可用"}</p>
        : group.reasons.length === 0
          ? <span>暂无有效举报原因</span>
          : group.reasons.map((reason, index) => <details key={`${reason.original_label}-${index}`} title={reason.description}>
            <summary>{reason.rank ? `${reason.rank}. ` : ""}{reason.mapped_name || reason.display_name_en || "Unmapped Reason"}{reason.mapping_status === "pending_confirmation" ? " · Pending confirmation" : ""}{reason.p0_ccr != null ? ` · P0 CCR ${ccr(reason.p0_ccr)}` : " · P0 CCR NULL"}{reason.p0_nfs != null ? ` · P0 NFS ${reason.p0_nfs.toLocaleString("en-US")}` : " · P0 NFS NULL"} · 排序依据 {basisLabel(reason.sort_basis || group.sortBasis)}</summary>
            {!reason.ranking_available && <span>{reason.ranking_unavailable_reason || reason.source_reason || "Reason ranking unavailable"}</span>}
            <span>{reason.description || "—"}</span><code>{reason.raw_path || reason.original_label || "—"}</code>
          </details>)}
    </div>)}
  </div>;
}

export const reportedReasonGroups = (items: AdvertiserEvidence[] | undefined): ReportedReasonGroup[] =>
  (items || []).map((item) => ({
    advertiser_id: item.advertiser_id,
    reasons: item.reported_reasons || [],
    status: item.reported_reasons_status,
    error: item.reported_reasons_error,
    sortBasis: item.reported_reasons_sort_basis,
  }));
