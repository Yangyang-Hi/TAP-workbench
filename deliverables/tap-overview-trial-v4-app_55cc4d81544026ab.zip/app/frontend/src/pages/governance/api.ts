import { apiFetch } from "../../auth";
import type { ReportedReason } from "./read-model";
export type ScanRequest = {
  program: string;
  region: string;
  start_date: string;
  end_date: string;
  member_start_date: string;
  member_end_date: string;
  force?: boolean;
};
export type Rule = {
  enabled: boolean;
  business_confirmed: boolean;
  version: string;
  watch_ccr_gte: number;
  watch_nfs_gt: number;
  critical_ccr_gt: number;
  ccr_unit: string;
};
export type AdvertiserEvidence = {
  account_id: string;
  account_name?: string;
  advertiser_id: string;
  advertiser_name?: string;
  ccr: number | null;
  nfs: number | null;
  revenue: number | null;
  allowlist_status: string;
  level: string;
  reasons: string[];
  metric_status: string;
  reported_reasons?: ReportedReason[];
};
export type RiskRow = {
  id: string;
  program: string;
  member: {
    account_id: string;
    advertiser_id: string;
    account_name: string;
    advertiser_name?: string;
    region: string;
    submitter: string;
    ticket_id: string;
    protection_starttime: string;
    protection_endtime: string;
    create_date: string;
    quarter?: string;
    endorsement_reason?: string;
    protection_program_name?: string;
    protection_businessline?: string;
    protection_estimated_spend?: string;
    protection_status?: string;
    metadata_status: string;
    tier: string;
  };
  ccr: number | null;
  nfs: number | null;
  revenue: number | null;
  account_ccr_status?: string;
  aggregation_note?: string;
  advertiser_count: number;
  advertiser_top10: AdvertiserEvidence[];
  advertisers: AdvertiserEvidence[];
  metric_status: string;
  level: string;
  reasons: string[];
  allowlist_status: string;
  data_status: string;
  error?: string;
  source: unknown;
  queried_at: string;
  message: string;
  recipient_status: string;
  request_id?: string;
};
export type Scan = {
  id: string;
  request: ScanRequest;
  rule: Rule;
  status: string;
  stage: string;
  member_count: number;
  done: number;
  rows: RiskRow[];
  complete: boolean;
  warnings: string[];
  error: string;
  matched_total: number;
  started_at: string;
  finished_at: string;
};
export type Action = {
  status: string;
  cause: string;
  note: string;
  updated_at: string;
  history: {
    time: string;
    actor: string;
    status: string;
    cause: string;
    note: string;
  }[];
};
export type QuotaBaseline = {
  status: string;
  period: string;
  source: string;
  regions: { region: string; ET: number; ST: number }[];
  totals: { ET: number; ST: number };
  usage_status: string;
};
export type Config = {
  quota_baseline?: QuotaBaseline;
  defaults: ScanRequest;
  config: {
    timezone: string;
    validation_account_ids: string[];
    membership_complete_confirmed: boolean;
    rules: Record<string, Rule>;
  };
  sources: Record<string, { configured: boolean; sid: number; rid: number }>;
  live_programs: string[];
  notification_mode: string;
  membership_policy: string;
};
export async function workbenchApi<T>(
  path: string,
  body?: unknown,
  signal?: AbortSignal,
): Promise<T> {
  const r = await apiFetch(path, {
    method: body === undefined ? "GET" : "POST",
    signal,
    ...(body === undefined
      ? {}
      : {
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        }),
  });
  let json: any;
  try {
    json = await r.json();
  } catch {
    throw Error("服务器没有返回有效数据");
  }
  if (!r.ok) throw Error(json.error || json.data?.error || `HTTP ${r.status}`);
  return json as T;
}
export const statusLabels: Record<string, string> = {
  open: "待处理",
  processing: "处理中",
  observing: "持续观察",
  pending_approval: "待审批",
  pending_review: "待复核",
  closed: "已关闭",
};
export function matched(r: RiskRow) {
  return r.level === "critical" || r.level === "watch";
}
export function fmt(v: number | null | undefined) {
  return v === null || v === undefined
    ? "—"
    : v.toLocaleString("en-US", { maximumFractionDigits: 6 });
}

export type HistoryBundle = {
  scans: Scan[];
  actions: Record<string, Action>;
  scope: string;
  limit: number;
};
export type PageName = "overview" | "risk" | "analysis" | "data";
export function entityId(row: RiskRow) {
  return row.program === "THT"
    ? row.member.advertiser_id
    : row.member.account_id;
}
export function scopeMatches(
  a: ScanRequest,
  b: ScanRequest,
  includeProgram = true,
) {
  return (
    (includeProgram ? a.program === b.program : true) &&
    [
      "region",
      "start_date",
      "end_date",
      "member_start_date",
      "member_end_date",
    ].every((k) => a[k as keyof ScanRequest] === b[k as keyof ScanRequest])
  );
}
export function latestScopedScans(
  scans: Scan[],
  query: ScanRequest | undefined,
) {
  if (!query) return [];
  const result = new Map<string, Scan>();
  for (const scan of [...scans].sort((a, b) =>
    b.started_at.localeCompare(a.started_at),
  )) {
    if (
      scopeMatches(scan.request, query, false) &&
      !result.has(scan.request.program)
    )
      result.set(scan.request.program, scan);
  }
  return [...result.values()];
}
