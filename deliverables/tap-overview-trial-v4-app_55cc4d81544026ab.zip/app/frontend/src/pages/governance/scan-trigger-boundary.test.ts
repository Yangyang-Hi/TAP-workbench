import { describe, expect, it } from "vitest";
import caseworkSource from "./casework.tsx?raw";
import workbenchSource from "./index.tsx?raw";
import pagesSource from "./workbench-pages.tsx?raw";

describe("共享工作台副作用边界", () => {
  it("初始化、筛选和只读页面只调用 batches/read-model，不创建扫描或通知", () => {
    expect(workbenchSource).toContain("workbenchBatchesList");
    expect(workbenchSource).toContain("workbenchReadModelList");
    expect(workbenchSource).not.toContain("risk-scans");
    expect(workbenchSource).not.toContain("/notify");
    expect(pagesSource).not.toContain("risk-scans");
    expect(pagesSource).not.toContain("/notify");
  });

  it("通知只能由显式预览、确认框和单条发送按钮触发", () => {
    expect(caseworkSource).toContain("/notification-preview");
    expect(caseworkSource).toContain("confirmation_token");
    expect(caseworkSource).toContain("sendConfirmed");
    expect(caseworkSource).toContain("正式模式（真实负责人，仅单条确认）");
    expect(caseworkSource).toContain("确认发送单条");
    expect(caseworkSource).toContain('preview.notification_mode === "formal"');
    expect(caseworkSource).toContain("正式批量与自动发送保持禁用");
  });

  it("失败、排队和未知状态不显示为通知成功", () => {
    expect(caseworkSource).toContain('n.status === "sent" && !!n.message_id');
    expect(pagesSource).toContain("排队、失败、未知不计入成功");
    expect(caseworkSource).toContain("排队中、发送失败均不代表通知已送达");
  });
});
