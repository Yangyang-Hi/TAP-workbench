import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { WorkbenchSettings } from "./casework";

const api = vi.hoisted(() => vi.fn());
const clients = vi.hoisted(() => ({
  list: vi.fn(), tasks: vi.fn(), versions: vi.fn(), preview: vi.fn(), update: vi.fn(), mappings: vi.fn(), mappingUpdate: vi.fn(),
}));
vi.mock("./api", async original => ({ ...(await original<typeof import("./api")>()), workbenchApi: api }));
vi.mock("../../api/client.gen", () => ({
  workbenchRiskPolicyList: clients.list,
  workbenchRiskPolicyPreviewCreate: clients.preview,
  workbenchRiskPolicyRejudgementsList: clients.tasks,
  workbenchRiskPolicyVersionsList: clients.versions,
  workbenchRiskPolicyUpdate: clients.update,
  workbenchIdentityMappingsList: clients.mappings,
  workbenchIdentityMappingsByRecordIdEnabledUpdate: clients.mappingUpdate,
}));
vi.mock("../../auth", () => ({ apiFetch: vi.fn(async () => new Response(JSON.stringify({ data: {} }), { status: 200 })) }));

const rules = [
  { id: "absolute-watch", name: "绝对值观察线", program: "ALL", kind: "absolute", match_mode: "all", enabled: true, risk_level: "watch", scope: {}, conditions: [{ metric: "p0_ccr", operator: ">=", value: 3 }, { metric: "p0_nfs", operator: ">", value: 50 }] },
];

afterEach(cleanup);
beforeEach(() => {
  Object.values(clients).forEach(mock => { mock.mockReset(); });
  api.mockReset().mockResolvedValue({ data: { is_operator: true } });
  clients.list.mockResolvedValue({ data: { version: 0, version_label: "TAP-20261021-v2", config_hash: "hash", is_operator: true, updated_by: "system_seed", updated_at: "", rules } });
  clients.tasks.mockResolvedValue({ data: { tasks: [{ id: "task-1", status: "partial", progress: 100, created_at: "2026-10-21T00:00:00Z", program_results: { ET: { status: "success", updated_rows: 10 }, ST: { status: "failed", updated_rows: 0, reason: "缺少当前周任务" } } }] } });
  clients.versions.mockResolvedValue({ data: { versions: [] } });
  clients.preview.mockResolvedValue({ data: { expected_version: 0, draft_hash: "draft", preview_token: "preview-0", warnings: ["ALL 与 ET 范围重叠"], programs: { ET: { before_matched: 1, after_matched: 2, added: 1, removed: 0, upgraded: 0, downgraded: 0, unavailable: 0, insufficient: 0 } }, total: { before_matched: 1, after_matched: 2, added: 1, removed: 0, upgraded: 0, downgraded: 0, unavailable: 0, insufficient: 0 }, source_batch_ids: ["batch"], data_freshness: {}, partial: false, failure_reasons: [] } });
  clients.update.mockResolvedValue({ data: { version: 1 } });
  clients.mappings.mockResolvedValue({ data: { mappings: [], source: {}, auto_send_enabled: false } });
});

async function openSettings() {
  render(<WorkbenchSettings />);
  fireEvent.click(await screen.findByText(/管理设置/));
  expect(await screen.findByRole("heading", { name: "阈值配置" })).toBeTruthy();
}

it("supports new, copy and deleting only unsaved drafts", async () => {
  await openSettings();
  fireEvent.click(screen.getByRole("button", { name: "复制" }));
  expect(await screen.findByText("绝对值观察线 副本")).toBeTruthy();
  const copyRow = screen.getByText("绝对值观察线 副本").closest("tr");
  fireEvent.click(within(copyRow as HTMLElement).getByRole("button", { name: "删除草稿" }));
  await waitFor(() => expect(screen.queryByText("绝对值观察线 副本")).toBeNull());
  expect(screen.queryByRole("button", { name: "删除草稿" })).toBeNull();

  fireEvent.click(screen.getByRole("button", { name: "新增规则" }));
  fireEvent.change(await screen.findByPlaceholderText("例如：ET 绝对值观察线"), { target: { value: "新增安全线" } });
  fireEvent.click(screen.getByRole("button", { name: "保存到草稿" }));
  expect(await screen.findByText("新增安全线")).toBeTruthy();
  expect(screen.getByText(/absolute-all-/)).toBeTruthy();
});

it("previews persisted impact before second confirmation and submits token", async () => {
  await openSettings();
  expect(screen.getByText(/ST：failed/)).toBeTruthy();
  fireEvent.click(screen.getByRole("button", { name: "预览影响并提交" }));
  expect(await screen.findByText("影响预览与二次确认")).toBeTruthy();
  expect(screen.getByText("ALL 与 ET 范围重叠")).toBeTruthy();
  fireEvent.change(screen.getByPlaceholderText("说明调整原因、预期影响与回滚判断"), { target: { value: "降低观察阈值" } });
  fireEvent.click(screen.getByRole("button", { name: "确认生效并自动重判" }));
  await waitFor(() => expect(clients.update).toHaveBeenCalledWith(expect.objectContaining({ expected_version: 0, preview_token: "preview-0", confirmation_note: "降低观察阈值" })));
});

it("hides management settings from non-operators", async () => {
  api.mockResolvedValue({ data: { is_operator: false } });
  render(<WorkbenchSettings />);
  await waitFor(() => expect(api).toHaveBeenCalled());
  expect(screen.queryByText(/管理设置/)).toBeNull();
});
