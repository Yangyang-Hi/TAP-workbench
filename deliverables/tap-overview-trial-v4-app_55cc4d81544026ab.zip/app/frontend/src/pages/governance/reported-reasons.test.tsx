import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import { ReportedReasonsView } from "./reported-reasons";

afterEach(cleanup);

describe("ReportedReasonsView", () => {
  it("distinguishes a successful empty result from a query failure", () => {
    const empty = render(<ReportedReasonsView groups={[{ advertiser_id: "7100000000000000001", reasons: [], status: "available" }]} />);
    expect(screen.getByText("暂无有效举报原因")).toBeTruthy();
    empty.unmount();

    render(<ReportedReasonsView groups={[{ advertiser_id: "7100000000000000002", reasons: [], status: "failed", error: "RID 3023305 timeout" }]} />);
    expect(screen.getByRole("alert").textContent).toContain("举报原因查询失败");
    expect(screen.getByRole("alert").textContent).toContain("RID 3023305 timeout");
  });

  it("shows English name, NFS, readable ranking basis and expandable raw path", () => {
    render(<ReportedReasonsView groups={[{
      advertiser_id: "7100000000000000003",
      status: "available",
      sortBasis: "nfs_fallback_all_ccr_null",
      reasons: [{
        original_label: "一级 - 二级",
        raw_path: "一级 - 二级",
        display_name_en: "Violence",
        mapped_name: "Violence",
        description: "Mapped reason",
        mapping_status: "verified",
        p0_ccr: null,
        p0_nfs: 12,
        rank: 1,
        ranking_available: true,
        sort_basis: "nfs_fallback_all_ccr_null",
      }],
    }]} />);
    expect(screen.getByText(/Violence/).textContent).toContain("P0 NFS 12");
    expect(screen.getByText(/Violence/).textContent).toContain("排序依据 NFS");
    expect(screen.getByText("一级 - 二级")).toBeTruthy();
  });
});
