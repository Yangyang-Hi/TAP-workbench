import { afterEach, describe, expect, it, vi } from 'vitest';

interface JwtServiceMock {
  _getLoginInfo: ReturnType<typeof vi.fn>;
  redirectToLogin: ReturnType<typeof vi.fn>;
}

function mockCommonLib(jwtService: JwtServiceMock) {
  vi.doMock('@bytecloud/common-lib', () => ({
    bytecloudAsyncJwtService: {
      getService: vi.fn().mockResolvedValue(jwtService),
    },
  }));
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.doUnmock('@bytecloud/common-lib');
  vi.resetModules();
});

describe('apiFetch', () => {
  it('refreshes an expired JWT and retries once with the new token', async () => {
    const jwtService = {
      _getLoginInfo: vi
        .fn()
        .mockResolvedValueOnce({ status: 200, jwt: 'old-token' })
        .mockResolvedValueOnce({ status: 200, jwt: 'new-token' }),
      redirectToLogin: vi.fn(),
    };
    mockCommonLib(jwtService);
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(new Response(null, { status: 401 }))
      .mockResolvedValueOnce(new Response('{}', { status: 200 }));
    vi.stubGlobal('fetch', fetchMock);
    const { apiFetch } = await import('./auth');

    const response = await apiFetch('/api/items');

    expect(response.status).toBe(200);
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(new Headers(fetchMock.mock.calls[0][1]?.headers).get('Authorization')).toBe('Byte-Cloud-JWT old-token');
    expect(new Headers(fetchMock.mock.calls[1][1]?.headers).get('Authorization')).toBe('Byte-Cloud-JWT new-token');
    expect(jwtService.redirectToLogin).not.toHaveBeenCalled();
  });

  it('returns a stable 401 when silent refresh cannot obtain a fresh token', async () => {
    const jwtService = {
      _getLoginInfo: vi.fn().mockResolvedValue({ status: 200, jwt: 'same-token' }),
      redirectToLogin: vi.fn(),
    };
    mockCommonLib(jwtService);
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(null, { status: 401 })));
    const { apiFetchWithJwt } = await import('./auth');

    const response = await apiFetchWithJwt('/api/items', undefined, 'same-token');

    expect(response.status).toBe(401);
    expect(jwtService.redirectToLogin).not.toHaveBeenCalled();
  });

  it('retries a transient ROW gateway 403 once', async () => {
    const jwtService = {
      _getLoginInfo: vi.fn().mockResolvedValue({ status: 200, jwt: 'valid-token' }),
      redirectToLogin: vi.fn(),
    };
    mockCommonLib(jwtService);
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(new Response('{"error":"request is rejected by ROW Operations Gateway"}', { status: 403 }))
      .mockResolvedValueOnce(new Response('{}', { status: 200 }));
    vi.stubGlobal('fetch', fetchMock);
    const { apiFetchWithJwt } = await import('./auth');

    const response = await apiFetchWithJwt('/api/workbench/read-model', undefined, 'valid-token');

    expect(response.status).toBe(200);
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(new Headers(fetchMock.mock.calls[1][1]?.headers).get('Authorization')).toBe('Byte-Cloud-JWT valid-token');
  });

  it('does not retry an application-level 403', async () => {
    const jwtService = {
      _getLoginInfo: vi.fn().mockResolvedValue({ status: 200, jwt: 'valid-token' }),
      redirectToLogin: vi.fn(),
    };
    mockCommonLib(jwtService);
    const fetchMock = vi.fn().mockResolvedValue(new Response('{"error":"forbidden"}', { status: 403 }));
    vi.stubGlobal('fetch', fetchMock);
    const { apiFetchWithJwt } = await import('./auth');

    const response = await apiFetchWithJwt('/api/items', undefined, 'valid-token');

    expect(response.status).toBe(403);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});
