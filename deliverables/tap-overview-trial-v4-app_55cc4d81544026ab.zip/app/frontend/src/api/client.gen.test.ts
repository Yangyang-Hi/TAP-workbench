import { beforeEach, describe, expect, it, vi } from 'vitest';
import { apiFetch } from '../auth';
import { submissionsList, submissionsStatusList } from './client.gen';

vi.mock('../auth', () => ({ apiFetch: vi.fn() }));
const apiFetchMock = vi.mocked(apiFetch);

beforeEach(() => { apiFetchMock.mockResolvedValue(new Response('{}', { status: 200 })); });

describe('generated API client', () => {
  it('serializes S01 filters as independent query parameters', async () => {
    await submissionsList({ start_date: '2026-09-01', end_date: '2026-09-02', submission_type: 'ET' });
    expect(apiFetchMock).toHaveBeenCalledWith('/api/submissions?start_date=2026-09-01&end_date=2026-09-02&submission_type=ET', { method: 'GET' });
  });
  it('calls isolated status endpoint without a body', async () => {
    await submissionsStatusList();
    expect(apiFetchMock).toHaveBeenCalledWith('/api/submissions/status', { method: 'GET' });
  });
});
