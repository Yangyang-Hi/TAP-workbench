import ReactDOM from "react-dom/client";
import { useEffect, useState } from "react";
import { getCurrentUser, redirectToLogin } from "./auth";
import { OverviewTrialPage } from "./pages/governance/overview-accounts";

function Root() {
  const [state, setState] = useState("loading");
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let alive = true;
    getCurrentUser().then(user => { if (alive) setState(user ? "ready" : "login"); }).catch(e => { if (alive) { setState("failed"); setError(e.message); } });
    return () => { alive = false; };
  }, [attempt]);
  if (state === "ready") return <OverviewTrialPage />;
  return <main className="ov-trial-page"><h1>TAP 数据总览</h1><p role="status">{state === "loading" ? "正在验证 AIME 访问身份…" : state === "login" ? "请登录公司账号后查询数据。" : error}</p>{state !== "loading" && <><button onClick={() => void redirectToLogin()}>登录 / 重新验证</button><button onClick={() => { setState("loading"); setAttempt(n => n+1); }}>重试</button></>}</main>;
}
const root = document.getElementById("root");
if (root) ReactDOM.createRoot(root).render(<Root />);
