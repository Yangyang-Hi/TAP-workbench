import { act, renderHook, waitFor } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { useApiData, usePageControlRefresh } from './aime-runtime';

describe('useApiData', () => {
  it('loads once for a data change and its compatibility refresh event', async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(['initial']).mockResolvedValueOnce(['updated']);
    const { result } = renderHook(() => useApiData(fetcher, 'items'));

    await waitFor(() => expect(fetcher).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(result.current.data).toEqual(['initial']));

    act(() => {
      window.dispatchEvent(new CustomEvent('aime:data-changed', { detail: { resource: 'items' } }));
      window.dispatchEvent(
        new CustomEvent('aime:page-control-refresh', {
          detail: { reason: 'data-changed', resource: 'items' },
        }),
      );
    });

    await waitFor(() => expect(fetcher).toHaveBeenCalledTimes(2));
    await waitFor(() => expect(result.current.data).toEqual(['updated']));
  });

  it('reloads for explicit page-control refreshes and matching resources only', async () => {
    const fetcher = vi.fn().mockResolvedValue(['value']);
    renderHook(() => useApiData(fetcher, 'items'));
    await waitFor(() => expect(fetcher).toHaveBeenCalledTimes(1));

    act(() => {
      window.dispatchEvent(new CustomEvent('aime:data-changed', { detail: { resource: 'other' } }));
      window.dispatchEvent(
        new CustomEvent('aime:page-control-refresh', {
          detail: { reason: 'data-changed', resource: 'other' },
        }),
      );
    });
    expect(fetcher).toHaveBeenCalledTimes(1);

    act(() => {
      window.dispatchEvent(new CustomEvent('aime:page-control-refresh', { detail: { reason: 'page-control' } }));
    });
    await waitFor(() => expect(fetcher).toHaveBeenCalledTimes(2));
  });
});

describe('usePageControlRefresh', () => {
  it('deduplicates paired events while accepting standalone legacy events', () => {
    const callback = vi.fn();
    renderHook(() => usePageControlRefresh(callback));
    const detail = { reason: 'paired' };

    act(() => {
      window.dispatchEvent(new CustomEvent('aime:page-control-refresh', { detail }));
      window.dispatchEvent(new CustomEvent('pageControlRefresh', { detail }));
    });
    expect(callback).toHaveBeenCalledTimes(1);

    act(() => {
      window.dispatchEvent(new CustomEvent('pageControlRefresh', { detail: { reason: 'legacy' } }));
    });

    expect(callback).toHaveBeenNthCalledWith(2, { reason: 'legacy' });
  });
});
