import { createAeolusClient } from '@aeolus/data-sdk';
import { AeolusProvider } from '@aeolus/data-sdk/react';
import { Alert, Spin } from '@arco-design/web-react';
import { type ReactNode, useEffect, useState } from 'react';
import { getJwtWithoutRedirect } from '../auth';

let sharedClient: ReturnType<typeof createAeolusClient> | null = null;

type SessionState = 'loading' | 'ready' | 'unauthorized' | 'failed';

async function initAeolusSession(): Promise<SessionState> {
  const jwt = await getJwtWithoutRedirect().catch(() => undefined);
  if (!jwt) return 'unauthorized';
  const region = (window.webApplicationManifest as { region?: string } | undefined)?.region;
  const response = await fetch('/aeolus/session', {
    method: 'POST',
    credentials: 'include',
    headers: { 'x-jwt-token': jwt, 'content-type': 'application/json' },
    body: JSON.stringify(region ? { region } : {}),
  }).catch(() => null);
  if (!response) return 'failed';
  if (response.ok) return 'ready';
  return response.status === 401 ? 'unauthorized' : 'failed';
}

export function AeolusDataProvider({ children }: { children: ReactNode }) {
  const [client] = useState(() => (sharedClient ??= createAeolusClient()));
  const [session, setSession] = useState<SessionState>('loading');

  useEffect(() => {
    let active = true;
    void initAeolusSession().then((value) => active && setSession(value));
    return () => {
      active = false;
    };
  }, []);

  if (session === 'loading') {
    return <div style={{ minHeight: 240, display: 'grid', placeItems: 'center' }}><Spin tip="正在建立风神数据会话…" /></div>;
  }
  if (session === 'unauthorized') {
    return <Alert type="warning" content="未取得风神访问凭证，请确认已登录且拥有对应风神图表权限。" />;
  }
  return (
    <AeolusProvider client={client}>
      {session === 'failed' && <Alert type="warning" content="风神会话初始化异常，正在尝试直接加载数据。" />}
      {children}
    </AeolusProvider>
  );
}
