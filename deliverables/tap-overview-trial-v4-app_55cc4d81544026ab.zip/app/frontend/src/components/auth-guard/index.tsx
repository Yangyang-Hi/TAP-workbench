import { Button, Result, Spin } from '@arco-design/web-react';
import { createContext, type ReactNode, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { apiFetchWithJwt, AuthError, type AuthUser, getCurrentUser, getJwtWithoutRedirect, redirectToLogin } from '../../auth';
import { useAimeText } from '../../aime-runtime';

const authMessages={zh:{loading:'正在验证登录状态...',failed:'登录验证失败',retry:'重新验证',login:'前往登录',forbidden:'当前账号无访问权限'},en:{loading:'Verifying login status...',failed:'Login verification failed',retry:'Retry',login:'Sign in',forbidden:'Access denied'}};
interface AuthContextValue{user:AuthUser|null;loading:boolean;authenticated:boolean;jwt:string|null}
const AuthContext=createContext<AuthContextValue>({user:null,loading:true,authenticated:false,jwt:null});
export function useAuth(){return useContext(AuthContext)}
export function useApiFetch(){const {jwt}=useAuth();return useCallback((input:RequestInfo|URL,init?:RequestInit)=>apiFetchWithJwt(input,init,jwt||undefined),[jwt])}

export function AuthGuard({children}:{children:ReactNode}){
  const [user,setUser]=useState<AuthUser|null>(null);const [jwt,setJwt]=useState<string|null>(null);const [loading,setLoading]=useState(true);const [error,setError]=useState<{message:string;needsLogin:boolean}|null>(null);const mounted=useRef(true);const t=useAimeText(authMessages);
  const checkAuth=useCallback(async()=>{setLoading(true);setError(null);try{const u=await getCurrentUser();if(!mounted.current)return;if(!u){setUser(null);setJwt(null);setError({message:'未检测到有效登录态，请手动登录后重试。',needsLogin:true});return}const token=await getJwtWithoutRedirect();if(!mounted.current)return;setUser(u);setJwt(token||null)}catch(e){if(!mounted.current)return;const status=e instanceof AuthError?e.status:0;setUser(null);setJwt(null);setError({message:status===403?t.forbidden:(e instanceof Error?e.message:t.failed),needsLogin:status===401})}finally{if(mounted.current)setLoading(false)}},[t.failed,t.forbidden]);
  useEffect(()=>{mounted.current=true;void checkAuth();return()=>{mounted.current=false}},[checkAuth]);
  if(loading)return <div className="auth-state"><Spin size={20}/><p>{t.loading}</p></div>;
  if(error)return <div className="auth-state"><Result status="error" title={t.failed} subTitle={error.message} extra={<div className="auth-actions"><Button type="primary" onClick={()=>void checkAuth()}>{t.retry}</Button>{error.needsLogin&&<Button onClick={()=>void redirectToLogin()}>{t.login}</Button>}</div>}/></div>;
  return <AuthContext.Provider value={{user,jwt,loading:false,authenticated:!!user}}>{children}</AuthContext.Provider>
}
