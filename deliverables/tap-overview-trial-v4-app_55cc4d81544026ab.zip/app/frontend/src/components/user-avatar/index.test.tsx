import { render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { getJwtWithoutRedirect } from '@/auth';
import { LarkUser } from './index';

vi.mock('@/auth', () => ({ getJwtWithoutRedirect: vi.fn() }));

const getJwtMock = vi.mocked(getJwtWithoutRedirect);

function userResponse(username: string, name: string): Response {
  return new Response(JSON.stringify({ data: { items: [{ username, name }] } }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  });
}

beforeEach(() => {
  getJwtMock.mockResolvedValue('jwt-token');
});

describe('LarkUser', () => {
  it('does not show the previous user while a new username is loading', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(userResponse('avatar-alice', 'Alice'))
      .mockImplementationOnce(() => new Promise<Response>(() => {}));
    vi.stubGlobal('fetch', fetchMock);
    const { rerender } = render(<LarkUser username="avatar-alice" />);
    await screen.findByText('Alice');

    rerender(<LarkUser username="avatar-bob" />);

    expect(screen.getByText('avatar-bob')).not.toBeNull();
    expect(screen.queryByText('Alice')).toBeNull();
  });

  it('retries a transient failed lookup instead of caching the failure', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(new Response(null, { status: 503 }))
      .mockResolvedValueOnce(userResponse('avatar-retry', 'Retry User'));
    vi.stubGlobal('fetch', fetchMock);
    const first = render(<LarkUser username="avatar-retry" />);
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    first.unmount();

    render(<LarkUser username="avatar-retry" />);

    await screen.findByText('Retry User');
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });
});
