import { act, render, screen } from "@testing-library/react";
import { expect, it } from "vitest";
import { useRouteLocation } from "./route-state";

function Probe({ name }: { name: string }) {
  const route = useRouteLocation();
  return <output data-testid={name}>{`${route.pathname}${route.search}`}</output>;
}

it("响应 pushState、replaceState 和 popstate，并在最后一个订阅者卸载时恢复 History", () => {
  const nativePush = history.pushState;
  const nativeReplace = history.replaceState;
  nativeReplace.call(history, null, "", "/");

  const first = render(<Probe name="first" />);
  const patchedPush = history.pushState;
  expect(patchedPush).not.toBe(nativePush);

  const second = render(<Probe name="second" />);
  expect(history.pushState).toBe(patchedPush);

  act(() => history.pushState({ step: 1 }, "", "/?view=tasks&alert_id=TAP-old"));
  expect(screen.getByTestId("first").textContent).toBe("/?view=tasks&alert_id=TAP-old");
  expect(screen.getByTestId("second").textContent).toBe("/?view=tasks&alert_id=TAP-old");

  act(() => history.replaceState({ step: 2 }, "", "/?alert_id=TAP-old&tab=risk"));
  expect(screen.getByTestId("first").textContent).toBe("/?alert_id=TAP-old&tab=risk");

  act(() => {
    nativeReplace.call(history, { step: 3 }, "", "/?view=tasks&alert_id=TAP-back");
    window.dispatchEvent(new PopStateEvent("popstate", { state: { step: 3 } }));
  });
  expect(screen.getByTestId("second").textContent).toBe("/?view=tasks&alert_id=TAP-back");

  first.unmount();
  expect(history.pushState).toBe(patchedPush);
  second.unmount();
  expect(history.pushState).toBe(nativePush);
  expect(history.replaceState).toBe(nativeReplace);
  nativeReplace.call(history, null, "", "/");
});
