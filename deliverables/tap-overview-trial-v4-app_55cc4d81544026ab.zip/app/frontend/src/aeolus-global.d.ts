import type { WebApplicationManifest } from '@aeolus/data-sdk';

declare global {
  interface Window {
    webApplicationManifest?: WebApplicationManifest & { region?: string };
    aeolusDashboardId?: number;
    aeolusSheetId?: number;
  }
}

export {};
