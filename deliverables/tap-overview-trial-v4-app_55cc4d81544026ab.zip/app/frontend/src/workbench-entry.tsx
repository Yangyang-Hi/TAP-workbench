// Standalone production entry. It preserves the uploaded bundle's ByteCloud authentication runtime.
// The standard AIME build remains available via src/main.tsx with native SDK support.
import ReactDOM from "react-dom/client";
import { useEffect, useState } from "react";
import Workbench from "./pages/governance";
import { initPageControl } from "./page-control-runtime";
import { getCurrentUser, redirectToLogin } from "./auth";
function Root() {
  const [state, setState] = useState("loading"),
    [error, setError] = useState("");
  useEffect(() => {
    let alive = true;
    void getCurrentUser()
      .then((user) => {
        if (alive) setState(user ? "ready" : "login");
      })
      .catch((err) => {
        if (alive) {
          setState("failed");
          setError(err.message);
        }
      });
    return () => {
      alive = false;
    };
  }, []);
  return state === "ready" ? (
    <Workbench />
  ) : (
    <div style={{ fontFamily: "sans-serif", padding: 50, color: "#31506f" }}>
      <h2>TAP Governance</h2>
      <p>
        {state === "loading"
          ? "正在验证 AIME 访问身份…"
          : state === "login"
            ? "请登录公司账号后进入工作台。"
            : error}
      </p>
      {state !== "loading" && (
        <button onClick={() => void redirectToLogin()}>登录 / 重新验证</button>
      )}
    </div>
  );
}
initPageControl();
const root = document.getElementById("root");
if (root) ReactDOM.createRoot(root).render(<Root />);
