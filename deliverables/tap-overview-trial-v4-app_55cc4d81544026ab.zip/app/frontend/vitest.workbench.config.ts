import { defineConfig } from "vitest/config";
export default defineConfig({
  css: { postcss: { plugins: [] } },
  resolve: {
    alias: {
      "@bytecloud/common-lib": new URL(
        "./vendor/bytecloud/index-CyHTFGrwEOXakQLE.js",
        import.meta.url,
      ).pathname,
    },
  },
  test: {
    environment: "jsdom",
    include: [
      "src/pages/home/index.test.tsx",
      "src/pages/governance/*.test.tsx",
      "src/pages/governance/*.test.ts",
    ],
  },
  esbuild: { jsx: "automatic" },
});
