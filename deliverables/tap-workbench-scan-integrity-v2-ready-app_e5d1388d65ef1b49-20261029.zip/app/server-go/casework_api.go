package main

import (
	"context"
	"encoding/json"
	"github.com/google/uuid"
	"net/http"
	"sort"
	"strings"
	"time"
)

func cwConfigHandler(w http.ResponseWriter, r *http.Request) {
	c, e := cwLoadConfig()
	if e != nil {
		cwWriteError(w, e)
		return
	}
	members := []map[string]string{}
	for _, m := range c.Members {
		members = append(members, map[string]string{"username": m.Username, "display_name": m.DisplayName})
	}
	writeJSON(w, 200, map[string]any{"data": map[string]any{"version": c.Version, "business_confirmed": c.BusinessConfirmed, "workflow": c.Workflow, "members": members, "recipients": c.TestRecipients, "notification_mode": c.NotificationMode, "auto_send_enabled": c.AutoSendEnabled, "actor": requestUsername(r), "is_operator": cwOperator(c, requestUsername(r)), "integration": cwIntegrationStatus(c.AutoSendEnabled), "scope": "shared_instance_cases"}})
}
func cwIsCompleteNaturalWeek(start, end string) bool {
	startDate, startErr := time.Parse("2006-01-02", start)
	endDate, endErr := time.Parse("2006-01-02", end)
	return startErr == nil && endErr == nil && startDate.Weekday() == time.Monday && endDate.Weekday() == time.Sunday && endDate.Equal(startDate.AddDate(0, 0, 6))
}

func cwNewerWindow(start, end, selectedStart, selectedEnd string) bool {
	return end > selectedEnd || (end == selectedEnd && start > selectedStart)
}

// cwSelectActiveWindow keeps mutable case activity (notifications, workflow edits)
// out of the decision. A persisted, completed natural-week scan is authoritative.
// If scan state is unavailable or has aged out, complete natural-week case windows
// are the deterministic fallback; arbitrary legacy windows are used only last.
func cwSelectActiveWindow(cases []cwCase) (string, string, string) {
	activeStart, activeEnd := "", ""
	if state, err := wbReadDisk(); err == nil {
		for _, job := range state.Jobs {
			if job.Status != "ready" && job.Status != "partial" && job.Status != "empty" {
				continue
			}
			start, end := job.Request.Start, job.Request.End
			if cwIsCompleteNaturalWeek(start, end) && cwNewerWindow(start, end, activeStart, activeEnd) {
				activeStart, activeEnd = start, end
			}
		}
	}
	if activeEnd != "" {
		return activeStart, activeEnd, "completed_scan"
	}
	for _, item := range cases {
		start, end := item.Window.Start, item.Window.End
		if cwIsCompleteNaturalWeek(start, end) && cwNewerWindow(start, end, activeStart, activeEnd) {
			activeStart, activeEnd = start, end
		}
	}
	if activeEnd != "" {
		return activeStart, activeEnd, "case_week_fallback"
	}
	for _, item := range cases {
		start, end := item.Window.Start, item.Window.End
		if cwNewerWindow(start, end, activeStart, activeEnd) {
			activeStart, activeEnd = start, end
		}
	}
	return activeStart, activeEnd, "legacy_window_fallback"
}

func cwListHandler(w http.ResponseWriter, r *http.Request) {
	cfg, e := cwLoadConfig()
	if e != nil {
		cwWriteError(w, e)
		return
	}
	repo, e := cwCaseworkRepositoryProvider()
	if e != nil {
		cwWriteError(w, e)
		return
	}
	allCases, e := repo.listCases(r.Context())
	if e != nil {
		cwWriteError(w, e)
		return
	}
	out := make([]cwCase, 0, len(allCases))
	for _, a := range allCases {
		if cwCanRead(cfg, a, requestUsername(r)) {
			out = append(out, a)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].UpdatedAt > out[j].UpdatedAt })
	filter := parseBusinessFilter(r)
	identityStatus, identityReason := validateIdentityFilter(filter, requestUsername(r))
	if identityStatus != "available" {
		writeJSON(w, 422, map[string]any{"error": identityReason, "status": identityStatus})
		return
	}
	caseScope := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("case_scope")))
	if caseScope == "" {
		caseScope = "all"
	}
	if caseScope != "all" && caseScope != "current" {
		writeJSON(w, 400, map[string]any{"error": "case_scope must be current or all"})
		return
	}
	activeStart, activeEnd, activeWindowSource := "", "", "not_applicable"
	if caseScope == "current" {
		activeStart, activeEnd, activeWindowSource = cwSelectActiveWindow(out)
	}
	filtered := make([]cwCase, 0, len(out))
	for _, a := range out {
		if caseScope == "current" && (a.Window.Start != activeStart || a.Window.End != activeEnd) {
			continue
		}
		if matchBusinessCase(a, filter, requestUsername(r)) {
			filtered = append(filtered, a)
		}
	}
	out = filtered
	stats := map[string]int{"total": len(out), "open": 0, "processing": 0, "observing": 0, "pending_approval": 0, "pending_review": 0, "closed": 0, "action_completed": 0, "education_completed": 0, "risk_recovered": 0, "overdue": 0, "notification_sent": 0, "notification_failed": 0}
	for _, a := range out {
		stats[a.Status]++
		if a.ActionCompleted {
			stats["action_completed"]++
		}
		if a.EducationCompleted {
			stats["education_completed"]++
		}
		if a.Status == "closed" && a.ClosureReason == "risk_recovered" {
			stats["risk_recovered"]++
		}
		if a.Status != "closed" && a.DueDate != "" && a.DueDate < time.Now().In(cwLocation()).Format("2006-01-02") {
			stats["overdue"]++
		}
	}
	allNotices, noticeErr := repo.listNotices(r.Context())
	if noticeErr != nil {
		cwWriteError(w, noticeErr)
		return
	}
	noticesByCase := map[string][]cwNotice{}
	for _, notice := range allNotices {
		noticesByCase[notice.CaseID] = append(noticesByCase[notice.CaseID], notice)
	}
	for _, a := range out {
		sent, failed := false, false
		for _, notice := range noticesByCase[a.ID] {
			if notice.Kind != "send" {
				continue
			}
			if notice.Status == "sent" && strings.TrimSpace(notice.MessageID) != "" {
				sent = true
			}
			if notice.Status == "failed" {
				failed = true
			}
		}
		if sent {
			stats["notification_sent"]++
		}
		if failed {
			stats["notification_failed"]++
		}
	}
	pageCases := paginateCases(out, filter.Page, filter.PageSize)
	reportNote := cwAlertHistoryReportNote(filter, out)
	writeJSON(w, 200, map[string]any{"data": map[string]any{"cases": pageCases, "stats": stats, "total": len(out), "page": filter.Page, "page_size": filter.PageSize, "scope": "shared_business_data", "case_scope": caseScope, "active_window": map[string]string{"start_date": activeStart, "end_date": activeEnd, "source": activeWindowSource}, "tier_status": "field_missing_when_empty", "date_field": filter.DateField, "as_of": cwNow(), "report_note": reportNote}})
}

func cwAlertHistoryReportNote(filter businessFilter, cases []cwCase) string {
	reportNote := "列表、统计与导出共享服务端筛选口径；默认读取最新完整已保存周度批次，历史周只读取对应持久化事件。"
	if filter.ProtectionStartDate != "" || filter.ProtectionEndDate != "" {
		for _, item := range cases {
			_, status := authoritativeProtectionAnchor(item)
			if status != "available" && filter.IncludeAnchorAnomalies {
				return "已包含保护开始时间缺失或存在歧义的事件；这些事件未被猜测归入任何日期。"
			}
		}
		return "保护开始时间按事件持久化权威锚点过滤，起止日均包含；时间异常事件默认排除。"
	}
	if filter.AlertStartDate == "" && filter.AlertEndDate == "" {
		return reportNote
	}
	for _, item := range cases {
		if _, ok := alertCreatedDay(item); !ok {
			return "提示：所选时段存在 created_at 缺失或格式异常的历史事件，结果可能不完整。"
		}
	}
	batches, _, err := wbPersistedBatches()
	if err != nil {
		return "提示：所选预警产生时段的扫描覆盖信息读取失败，无法据此判断是否无风险；结果仅展示已读取到的历史事件。"
	}
	covered := false
	incomplete := false
	for _, b := range batches {
		if (filter.AlertStartDate == "" || b.MetricEnd >= filter.AlertStartDate) && (filter.AlertEndDate == "" || b.MetricStart <= filter.AlertEndDate) {
			covered = true
			if b.Completeness == "partial" || b.Status == "partial" || b.Status == "unavailable" {
				incomplete = true
			}
		}
	}
	if !covered {
		return "提示：所选预警产生时段尚无系统扫描覆盖，结果仅包含手动录入事件（如有）。"
	}
	if incomplete {
		return "提示：所选时段部分扫描任务失败或不完整，预警历史数据可能缺失。"
	}
	return reportNote
}

func cwGetHandler(w http.ResponseWriter, r *http.Request) {
	cfg, e := cwLoadConfig()
	if e != nil {
		cwWriteError(w, e)
		return
	}
	caseID := strings.TrimSpace(r.PathValue("id"))
	repo, e := cwCaseworkRepositoryProvider()
	if e != nil {
		cwWriteRequestError(w, r, caseID, e)
		return
	}
	a, e := repo.caseByID(r.Context(), caseID)
	if e != nil {
		cwWriteRequestError(w, r, caseID, e)
		return
	}
	if !cwCanRead(cfg, a, requestUsername(r)) {
		cwWriteError(w, cwErr(403, "无法访问该事件"))
		return
	}
	notices, e := repo.notices(r.Context(), a.ID)
	if e != nil {
		cwWriteRequestError(w, r, caseID, e)
		return
	}
	actor := requestUsername(r)
	writeJSON(w, 200, map[string]any{
		"data":          a,
		"notifications": notices,
		"permissions": map[string]bool{
			"can_handle": cwCanHandle(cfg, a, actor),
			"can_review": actor != "" && (cwOperator(cfg, actor) || a.Reviewer == actor),
		},
	})
}
func cwPersistedCaseFallback(ctx context.Context, scanID, rowID string) (cwCase, bool) {
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		return cwCase{}, false
	}
	cases, err := repo.listCases(ctx)
	if err != nil {
		return cwCase{}, false
	}
	for _, item := range cases {
		if item.ScanID == scanID && item.Row.ID == rowID {
			return item, true
		}
	}
	return cwCase{}, false
}

func cwCreateHandler(w http.ResponseWriter, r *http.Request) {
	var in struct {
		ScanID string `json:"scan_id"`
		RowID  string `json:"row_id"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&in) != nil {
		cwWriteError(w, cwErr(400, "无效JSON"))
		return
	}
	j, e := wbLookup(in.ScanID, requestUsername(r))
	if e != nil {
		if existing, ok := cwPersistedCaseFallback(r.Context(), in.ScanID, in.RowID); ok {
			writeJSON(w, 200, map[string]any{"data": existing, "fallback": "persisted_cloud_case_snapshot"})
			return
		}
		cwWriteError(w, cwErr(404, "扫描不存在或不可访问"))
		return
	}
	for _, row := range wbApplyGovernanceRows(j.Rows, j.Rule) {
		if row.ID == in.RowID {
			a, e := cwCreate(j, row)
			if e != nil {
				cwWriteError(w, e)
				return
			}
			writeJSON(w, 200, map[string]any{"data": a})
			return
		}
	}
	if existing, ok := cwPersistedCaseFallback(r.Context(), in.ScanID, in.RowID); ok {
		writeJSON(w, 200, map[string]any{"data": existing, "fallback": "persisted_cloud_case_snapshot"})
		return
	}
	cwWriteError(w, cwErr(404, "扫描中没有该客户"))
}
func cwActionHandler(w http.ResponseWriter, r *http.Request) {
	var in cwCommand
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 128<<10)).Decode(&in) != nil {
		cwWriteError(w, cwErr(400, "无效JSON"))
		return
	}
	a, e := cwMutate(r.PathValue("id"), in, requestUsername(r), "workbench")
	if e != nil {
		cwWriteRequestError(w, r, r.PathValue("id"), e)
		return
	}
	writeJSON(w, 200, map[string]any{"data": a})
}
func cwLocation() *time.Location {
	l, e := time.LoadLocation("Asia/Shanghai")
	if e != nil {
		return time.UTC
	}
	return l
}
func cwRecheckHandler(w http.ResponseWriter, r *http.Request) {
	var in struct {
		ExpectedVersion int    `json:"expected_version"`
		Start           string `json:"start_date"`
		End             string `json:"end_date"`
		Note            string `json:"comparability_note"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 16384)).Decode(&in) != nil {
		cwWriteError(w, cwErr(400, "无效JSON"))
		return
	}
	start, e1 := time.Parse("2006-01-02", in.Start)
	end, e2 := time.Parse("2006-01-02", in.End)
	if e1 != nil || e2 != nil || end.Before(start) || end.Sub(start) > 31*24*time.Hour || in.End >= time.Now().In(cwLocation()).Format("2006-01-02") || strings.TrimSpace(in.Note) == "" {
		cwWriteError(w, cwErr(400, "复查窗口需为已结束的1至32天，并填写窗口可比性说明"))
		return
	}
	cfg, e := cwLoadConfig()
	if e != nil {
		cwWriteError(w, e)
		return
	}
	repo, e := cwCaseworkRepositoryProvider()
	if e != nil {
		cwWriteRequestError(w, r, r.PathValue("id"), e)
		return
	}
	a, e := repo.caseByID(r.Context(), r.PathValue("id"))
	if e != nil {
		cwWriteRequestError(w, r, r.PathValue("id"), e)
		return
	}
	if !cwCanHandle(cfg, a, requestUsername(r)) {
		cwWriteError(w, cwErr(403, "无复查权限"))
		return
	}
	if a.Status == "closed" || a.Version != in.ExpectedVersion {
		cwWriteError(w, cwErr(409, "事件已变化，请刷新"))
		return
	}
	id := a.Row.Member.AccountID
	query := wbQueryCurrent
	if a.Row.Program == "THT" {
		id = a.Row.Member.AdvertiserID
		query = wbQueryTHTCurrent
	}
	ctx, cancel := context.WithTimeout(r.Context(), 45*time.Second)
	defer cancel()
	result, status := query(ctx, r, etCCRDiagnosticRequest{AccountID: id, StartDate: in.Start, EndDate: in.End})
	check := cwRecheck{At: cwNow(), Actor: requestUsername(r), Start: in.Start, End: in.End, Status: asString(result["status"]), Note: in.Note, RequestID: asString(result["request_id"])}
	if status == 200 && check.Status == "success" {
		check.CCR = wbMetric(result["dynamic_p0_ccr"])
		check.NFS = wbMetric(result["p0_nfs"])
		check.Level, _ = evaluateWBAbsolute(check.CCR, check.NFS, a.Rule)
	} else {
		check.Status = "failed"
		check.Level = "unavailable"
	}
	current, e := repo.caseByID(r.Context(), a.ID)
	if e != nil {
		cwWriteRequestError(w, r, a.ID, e)
		return
	}
	if current.Version != a.Version {
		cwWriteError(w, cwErr(409, "查询期间事件已更新，请刷新后重试"))
		return
	}
	a.Rechecks = append(a.Rechecks, check)
	a.Version++
	a.UpdatedAt = cwNow()
	a.History = append(a.History, cwAudit{ID: uuid.NewString(), At: a.UpdatedAt, Actor: requestUsername(r), Source: "workbench", Operation: "recheck", Status: a.Status, Version: a.Version, Note: "真实指标复查：" + in.Start + " 至 " + in.End + "；" + check.Status})
	if e = repo.saveCaseCAS(r.Context(), a, current.Version); e == nil {
		e = repo.queueUpdates(r.Context(), a)
	}
	if e != nil {
		cwWriteRequestError(w, r, a.ID, e)
		return
	}
	writeJSON(w, 200, map[string]any{"data": a})
}
