package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"sort"
	"strings"
	"time"
)

const wbEvidenceIDBatchSize = 250

// wbAdvertiserEvidence is the immutable pair-grain evidence copied into an Alert snapshot.
// IDs stay strings so 19-digit values are never rounded by JSON/JavaScript.
type wbAdvertiserEvidence struct {
	AccountID              string           `json:"account_id"`
	AccountName            string           `json:"account_name,omitempty"`
	AdvertiserID           string           `json:"advertiser_id"`
	AdvertiserName         string           `json:"advertiser_name,omitempty"`
	CCR                    *float64         `json:"ccr"`
	NFS                    *float64         `json:"nfs"`
	Revenue                *float64         `json:"revenue"`
	CCRFact                metricFact       `json:"ccr_fact"`
	NFSFact                metricFact       `json:"nfs_fact"`
	RevenueFact            metricFact       `json:"revenue_fact"`
	PreCCR                 *float64         `json:"pre_ccr"`
	PostCCR                *float64         `json:"post_ccr"`
	PreCCRFact             metricFact       `json:"pre_ccr_fact"`
	PostCCRFact            metricFact       `json:"post_ccr_fact"`
	IncreaseFact           metricFact       `json:"increase_fact"`
	CCRDelta               *float64         `json:"ccr_delta,omitempty"`
	CCRGrowthPct           *float64         `json:"ccr_growth_pct"`
	ProtectionCCRGrowthPct *float64         `json:"protection_ccr_growth_pct,omitempty"`
	PreNFS                 *float64         `json:"pre_nfs,omitempty"`
	PostNFS                *float64         `json:"post_nfs,omitempty"`
	NFSDelta               *float64         `json:"nfs_delta,omitempty"`
	NFSGrowthPct           *float64         `json:"nfs_growth_pct,omitempty"`
	PreRevenue             *float64         `json:"pre_revenue,omitempty"`
	PostRevenue            *float64         `json:"post_revenue,omitempty"`
	RevenueDelta           *float64         `json:"revenue_delta,omitempty"`
	RevenueGrowthPct       *float64         `json:"revenue_growth_pct,omitempty"`
	CurrentSource          map[string]any   `json:"current_source,omitempty"`
	ComparisonSource       map[string]any   `json:"comparison_source,omitempty"`
	WoWGrowthPct           *float64         `json:"wow_ccr_growth_pct"`
	WoWStatus              string           `json:"wow_status"`
	WoWMissingReason       string           `json:"wow_missing_reason"`
	QoQGrowthPct           *float64         `json:"qoq_ccr_growth_pct"`
	QoQStatus              string           `json:"qoq_status"`
	QoQMissingReason       string           `json:"qoq_missing_reason"`
	ComparisonStatus       string           `json:"comparison_status"`
	ComparisonReason       string           `json:"comparison_missing_reason"`
	AllowlistStatus        string           `json:"allowlist_status"`
	AllowlistError         string           `json:"allowlist_error,omitempty"`
	AllowlistEvidence      map[string]any   `json:"allowlist_request_evidence,omitempty"`
	Level                  string           `json:"level"`
	Reasons                []string         `json:"reasons"`
	MetricStatus           string           `json:"metric_status"`
	RevenueStatus          string           `json:"revenue_status"`
	RevenueError           string           `json:"revenue_error,omitempty"`
	RevenueRequestID       string           `json:"revenue_request_id,omitempty"`
	RevenueLogID           string           `json:"revenue_log_id,omitempty"`
	SemanticsLabel         string           `json:"semantics_label_tier_1_2_3_4,omitempty"`
	SemanticsStatus        string           `json:"semantics_label_status"`
	ReportedReasons        []reportedReason `json:"reported_reasons"`
	ReportedReasonsStatus  string           `json:"reported_reasons_status"`
	ReportedReasonsError   string           `json:"reported_reasons_error,omitempty"`
	ReportedReasonsBasis   string           `json:"reported_reasons_sort_basis,omitempty"`
}

type wbPairKey struct{ AccountID, AdvertiserID string }

func semanticsLabelFact(raw map[string]any) (string, string) {
	value, present := raw["semantics_label_tier_1_2_3_4"]
	if !present {
		return "", "field_not_returned"
	}
	label := strings.TrimSpace(asString(value))
	if label == "" {
		return "", "source_empty"
	}
	return label, "available"
}

func validPair(accountID, advertiserID string) bool {
	return decimalID.MatchString(accountID) && decimalID.MatchString(advertiserID) && advertiserID != "0"
}

func nullableSum(values ...*float64) *float64 {
	var total float64
	found := false
	for _, value := range values {
		if value != nil {
			total += *value
			found = true
		}
	}
	if !found {
		return nil
	}
	return &total
}

func mergePairEvidence(bridge, metrics, revenue []map[string]any, allowlisted map[string]bool, rule wbRule) (map[string][]wbAdvertiserEvidence, error) {
	return mergePairEvidenceWithRevenueStatus(bridge, metrics, revenue, allowlisted, rule, "no_data", "")
}

func mergePairEvidenceWithRevenueStatus(bridge, metrics, revenue []map[string]any, allowlisted map[string]bool, rule wbRule, revenueStatus, revenueError string) (map[string][]wbAdvertiserEvidence, error) {
	pairs := map[wbPairKey]wbAdvertiserEvidence{}
	names := map[wbPairKey]wbAdvertiserEvidence{}
	for _, raw := range bridge {
		accountID, advertiserID := strings.TrimSpace(asString(raw["account_id"])), strings.TrimSpace(asString(raw["advertiser_id"]))
		if advertiserID == "0" {
			continue
		}
		if !validPair(accountID, advertiserID) {
			return nil, fmt.Errorf("invalid bridge pair account_id=%q advertiser_id=%q", accountID, advertiserID)
		}
		key := wbPairKey{accountID, advertiserID}
		if _, exists := names[key]; exists {
			continue
		}
		names[key] = wbAdvertiserEvidence{AccountID: accountID, AccountName: strings.TrimSpace(asString(raw["account_name"])), AdvertiserID: advertiserID, AdvertiserName: strings.TrimSpace(asString(raw["advertiser_name"]))}
	}
	seenMetrics := map[wbPairKey]bool{}
	for _, raw := range metrics {
		key := wbPairKey{strings.TrimSpace(asString(raw["account_id"])), strings.TrimSpace(asString(raw["advertiser_id"]))}
		if !validPair(key.AccountID, key.AdvertiserID) {
			return nil, fmt.Errorf("invalid metric pair account_id=%q advertiser_id=%q", key.AccountID, key.AdvertiserID)
		}
		evidence, exists := pairs[key]
		if !exists {
			evidence = wbAdvertiserEvidence{AccountID: key.AccountID, AdvertiserID: key.AdvertiserID, AllowlistStatus: "not_matched_scope_unknown", Level: "unavailable", MetricStatus: "no_data", RevenueStatus: revenueStatus, RevenueError: revenueError, Reasons: []string{}}
		}
		ccr, err := strictWBMetric(raw["dynamic_p0_ccr"])
		if err != nil {
			return nil, err
		}
		nfs, err := strictWBMetric(raw["p0_nfs"])
		if err != nil {
			return nil, err
		}
		if seenMetrics[key] { // deduplicate exact pair rows without double-counting.
			if (evidence.CCR == nil) != (ccr == nil) || (evidence.NFS == nil) != (nfs == nil) || evidence.CCR != nil && *evidence.CCR != *ccr || evidence.NFS != nil && *evidence.NFS != *nfs {
				return nil, fmt.Errorf("conflicting duplicate metric pair %s/%s", key.AccountID, key.AdvertiserID)
			}
			continue
		}
		seenMetrics[key] = true
		evidence.CCR, evidence.NFS, evidence.MetricStatus = ccr, nfs, "success"
		evidence.CurrentSource = map[string]any{"source": "advertiser_current_ccr_nfs", "rid": "2942519", "sid": "1139137", "grain": "account_advertiser_window", "fixed_filters": []string{"is_online=1"}, "status": "success", "trace": raw["_tap_trace"]}
		evidence.SemanticsLabel, evidence.SemanticsStatus = semanticsLabelFact(raw)
		evidence.Level, evidence.Reasons = evaluateWBAbsolute(ccr, nfs, rule)
		pairs[key] = evidence
	}
	seenRevenue := map[wbPairKey]bool{}
	for _, raw := range revenue {
		key := wbPairKey{strings.TrimSpace(asString(raw["account_id"])), strings.TrimSpace(asString(raw["advertiser_id"]))}
		if !validPair(key.AccountID, key.AdvertiserID) {
			return nil, fmt.Errorf("invalid revenue pair account_id=%q advertiser_id=%q", key.AccountID, key.AdvertiserID)
		}
		evidence, exists := pairs[key]
		if !exists {
			evidence = wbAdvertiserEvidence{AccountID: key.AccountID, AdvertiserID: key.AdvertiserID, AllowlistStatus: "not_matched_scope_unknown", Level: "unavailable", MetricStatus: "no_data", RevenueStatus: revenueStatus, RevenueError: revenueError, Reasons: []string{"Revenue-only：不进入高 CCR 榜"}}
		}
		value, err := strictWBMetric(raw["revenue"])
		if err != nil {
			return nil, err
		}
		if seenRevenue[key] { // Revenue SUM is already pair-grain; duplicate rows must not be added again.
			if (evidence.Revenue == nil) != (value == nil) || evidence.Revenue != nil && *evidence.Revenue != *value {
				return nil, fmt.Errorf("conflicting duplicate revenue pair %s/%s", key.AccountID, key.AdvertiserID)
			}
			continue
		}
		seenRevenue[key] = true
		evidence.Revenue = value
		evidence.RevenueStatus = "success"
		evidence.RevenueError = ""
		pairs[key] = evidence
	}
	byAccount := map[string][]wbAdvertiserEvidence{}
	for key, evidence := range pairs {
		if name, ok := names[key]; ok {
			evidence.AccountName, evidence.AdvertiserName = name.AccountName, name.AdvertiserName
		}
		if allowlisted[key.AdvertiserID] {
			evidence.AllowlistStatus = "matched_scope_unknown"
		} else if evidence.AllowlistStatus == "" {
			evidence.AllowlistStatus = "not_matched_scope_unknown"
		}
		// A pair exists only when at least one authority returned a fact row. Nil is
		// missing; a non-nil zero is a real fact and must be retained.
		if evidence.MetricStatus != "success" && evidence.RevenueStatus != "success" {
			continue
		}
		byAccount[key.AccountID] = append(byAccount[key.AccountID], evidence)
	}
	for accountID := range byAccount {
		sort.SliceStable(byAccount[accountID], func(i, j int) bool {
			a, b := byAccount[accountID][i], byAccount[accountID][j]
			if a.CCR == nil {
				return false
			}
			if b.CCR == nil {
				return true
			}
			if *a.CCR != *b.CCR {
				return *a.CCR > *b.CCR
			}
			return a.AdvertiserID < b.AdvertiserID
		})
	}
	return byAccount, nil
}

func topAdvertisers(all []wbAdvertiserEvidence, limit int) []wbAdvertiserEvidence {
	copyRows := make([]wbAdvertiserEvidence, 0, len(all))
	for _, row := range all {
		if row.MetricStatus == "success" && row.CCR != nil {
			copyRows = append(copyRows, row)
		}
	}
	sort.SliceStable(copyRows, func(i, j int) bool {
		if copyRows[i].CCR == nil {
			return false
		}
		if copyRows[j].CCR == nil {
			return true
		}
		if *copyRows[i].CCR != *copyRows[j].CCR {
			return *copyRows[i].CCR > *copyRows[j].CCR
		}
		return copyRows[i].AdvertiserID < copyRows[j].AdvertiserID
	})
	if limit >= 0 && len(copyRows) > limit {
		copyRows = copyRows[:limit]
	}
	return copyRows
}

func queryEvidenceRows(ctx context.Context, request *http.Request, source string, ids []string, idDimension, start, end string) ([]map[string]any, error) {
	if len(ids) == 0 {
		return []map[string]any{}, nil
	}
	all := []map[string]any{}
	chunks := chunkIDs(uniqueNonEmpty(ids), wbEvidenceIDBatchSize)
	for chunkIndex, chunk := range chunks {
		if chunkIndex > 0 {
			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(3 * time.Second):
			}
		}
		u := *request.URL
		r := request.Clone(ctx)
		r.URL = &u
		q := u.Query()
		q.Set("client_ids", strings.Join(chunk, ","))
		q.Set("id_dimension", idDimension)
		if start != "" {
			q.Set("start_date", start)
		}
		if end != "" {
			q.Set("end_date", end)
		}
		r.URL.RawQuery = q.Encode()
		r.Header = request.Header.Clone()
		r.Header.Set("X-TAP-Allow-Missing-IDs", "1")
		var probe map[string]any
		var err error
		for attempt := 0; attempt < 3; attempt++ {
			probe, err = runTitanVQSProbe(ctx, r, source)
			if err != nil {
				return nil, err
			}
			if asString(probe["status"]) == "ok" {
				break
			}
			detail := accountProbeError(source, probe)
			if !strings.Contains(strings.ToLower(detail.Error()), "tableaccessfreqlimit") || attempt == 2 {
				return nil, detail
			}
			select {
			case <-ctx.Done():
				return nil, ctx.Err()
			case <-time.After(time.Duration(10*(attempt+1)) * time.Second):
			}
		}
		if truncated, _ := probe["possibly_truncated"].(bool); truncated {
			return nil, errors.New(source + " result truncated")
		}
		rows, _ := probe["business_rows"].([]map[string]any)
		trace := map[string]any{"request_id": asString(probe["requestId"]), "log_id": asString(probe["logId"]), "query_history_id": asString(probe["query_history_id"]), "audit_id": asString(probe["audit_id"])}
		for _, row := range rows {
			copy := cloneMap(row)
			copy["_tap_trace"] = trace
			all = append(all, copy)
		}
	}
	return all, nil
}

func queryReportedReasonRows(ctx context.Context, request *http.Request, ids []string, idDimension, start, end string) ([]map[string]any, bool, string) {
	rows, err := queryEvidenceRows(ctx, request, "advertiser_reported_reasons", ids, idDimension, start, end)
	if err != nil {
		return nil, false, "reported reasons query failed: " + sanitizeLogText(err.Error())
	}
	return rows, true, ""
}

func wbAllowlistLabels(rows []map[string]any, dimension string) map[string][]string {
	sets := map[string]map[string]bool{}
	for _, row := range rows {
		id, label := strings.TrimSpace(asString(row[dimension])), strings.TrimSpace(asString(row["list_name"]))
		if id == "" || label == "" {
			continue
		}
		if sets[id] == nil {
			sets[id] = map[string]bool{}
		}
		sets[id][label] = true
	}
	out := map[string][]string{}
	for id, labels := range sets {
		for label := range labels {
			out[id] = append(out[id], label)
		}
		sort.Strings(out[id])
	}
	return out
}

func wbAllowlistDisplay(labels []string) string {
	if len(labels) == 0 {
		return "NO"
	}
	return strings.Join(labels, " / ")
}

func queryAuthoritativePairEvidence(ctx context.Context, request *http.Request, members []wbMember, q wbRequest, rule wbRule) (map[string][]wbAdvertiserEvidence, error) {
	if q.Program == "THT" {
		return map[string][]wbAdvertiserEvidence{}, nil
	}
	// Resolve one fresh Cloud JWT before fan-out. Letting every concurrent probe
	// refresh independently causes the ROW gateway to reject the burst with 403.
	queryRequest := request
	if auth := strings.TrimSpace(request.Header.Get("Authorization")); !strings.HasPrefix(strings.ToLower(auth), "byte-cloud-jwt ") {
		jwt, err := GetCloudJWT(ctx, true)
		if err != nil {
			return nil, fmt.Errorf("resolve enrichment Cloud JWT: %w", err)
		}
		queryRequest = request.Clone(ctx)
		queryRequest.Header = request.Header.Clone()
		queryRequest.Header.Set("Authorization", "Byte-Cloud-JWT "+strings.TrimSpace(jwt))
	}
	ids := make([]string, 0, len(members))
	for _, member := range members {
		ids = append(ids, member.AccountID)
	}
	type evidenceQueryResult struct {
		name string
		rows []map[string]any
		err  error
	}
	queries := []struct {
		name, source, dimension, start, end string
	}{
		{"metrics", "weekly_pair_ccr_nfs", "account_id", q.Start, q.End},
		{"revenue", "weekly_pair_revenue", "account_id", q.Start, q.End},
		{"bridge", "account_advertiser_bridge", "account_id", "", ""},
		{"names", "account_advertiser_names", "account_id", "", ""},
		{"reasons", "advertiser_reported_reasons", "account_id", q.Start, q.End},
	}
	results := make(chan evidenceQueryResult, len(queries))
	for _, query := range queries {
		query := query
		go func() {
			rows, queryErr := queryEvidenceRows(ctx, queryRequest, query.source, ids, query.dimension, query.start, query.end)
			results <- evidenceQueryResult{name: query.name, rows: rows, err: queryErr}
		}()
	}
	var metrics, revenue, bridge, nameRows, reasonRows []map[string]any
	var revenueErr, bridgeErr, nameErr, reasonErr error
	for range queries {
		result := <-results
		switch result.name {
		case "metrics":
			if result.err != nil {
				return nil, result.err
			}
			metrics = result.rows
		case "revenue":
			revenue, revenueErr = result.rows, result.err
		case "bridge":
			bridge, bridgeErr = result.rows, result.err
		case "names":
			nameRows, nameErr = result.rows, result.err
		case "reasons":
			reasonRows, reasonErr = result.rows, result.err
		}
	}
	revenueStatus, revenueError := "no_data", ""
	if revenueErr != nil {
		// Revenue is independent enrichment: never cancel or discard CCR/NFS.
		revenue = []map[string]any{}
		revenueStatus = "source_error"
		revenueError = sanitizeLogText(revenueErr.Error())
	}
	// S04 name enrichment is independent from the account-to-advertiser bridge.
	// Prefer the dedicated governed name report, while retaining bridge names as
	// a non-blocking fallback. Neither source may expand or gate metric pairs.
	if bridgeErr != nil {
		bridge = []map[string]any{}
		logMsg("[risk-scan] S04 bridge unavailable; preserving fact pairs: "+sanitizeLogText(bridgeErr.Error()), "plugin")
	}
	if nameErr != nil {
		nameRows = []map[string]any{}
		logMsg("[risk-scan] S04 authoritative name enrichment unavailable; using bridge fallback: "+sanitizeLogText(nameErr.Error()), "plugin")
	}
	nameRows = append(nameRows, bridge...)
	advertiserIDs := []string{}
	for _, rows := range [][]map[string]any{metrics, revenue} {
		for _, row := range rows {
			if id := strings.TrimSpace(asString(row["advertiser_id"])); id != "" && id != "0" {
				advertiserIDs = append(advertiserIDs, id)
			}
		}
	}
	allowRows, allowErr := queryEvidenceRows(ctx, queryRequest, "advertiser_allowlist", advertiserIDs, "advertiser_id", "", "")
	allowlistLabels := wbAllowlistLabels(allowRows, "advertiser_id")
	allowlisted := map[string]bool{}
	if allowErr == nil {
		for id := range allowlistLabels {
			allowlisted[id] = true
		}
	} else {
		// Allowlist is notification enrichment, not part of the CCR/NFS absolute
		// rule. Do not discard a valid bridge+metric snapshot when it is down.
		logMsg("[risk-scan] advertiser allowlist unavailable; preserving pair evidence: "+sanitizeLogText(allowErr.Error()), "plugin")
	}
	result, err := mergePairEvidenceWithRevenueStatus(nameRows, metrics, revenue, allowlisted, rule, revenueStatus, revenueError)
	if err != nil {
		return nil, err
	}
	reasonComplete, reasonUnavailable := reasonErr == nil, ""
	if reasonErr != nil {
		reasonRows = nil
		reasonUnavailable = "reported reasons query failed: " + sanitizeLogText(reasonErr.Error())
	}
	if err := attachReportedReasons(result, reasonRows, reasonComplete, reasonUnavailable); err != nil {
		return nil, fmt.Errorf("load reported reason mapping: %w", err)
	}
	if !reasonComplete {
		logMsg("[risk-scan] "+reasonUnavailable, "plugin")
	}
	for accountID, items := range result {
		for i := range items {
			if allowErr != nil {
				items[i].AllowlistStatus = "Unknown"
				items[i].AllowlistError = sanitizeLogText(allowErr.Error())
			} else {
				items[i].AllowlistStatus = wbAllowlistDisplay(allowlistLabels[items[i].AdvertiserID])
				items[i].AllowlistError = ""
			}
		}
		result[accountID] = items
	}
	return result, nil
}

func applyPairEvidence(rows []wbRow, evidence map[string][]wbAdvertiserEvidence, q wbRequest, rule wbRule) []wbRow {
	for i := range rows {
		items := evidence[rows[i].Member.AccountID]
		rows[i].Advertisers = items
		rows[i].AdvertiserTop10 = topAdvertisers(items, 10)
		rows[i].AdvertiserCount = len(items)
		if len(items) == 0 {
			rows[i].AggregationNote = "未找到有效 Account–Advertiser pair；保留 account source 指标并明确无关联明细"
			rows[i].Message = wbMessage(rows[i], q, rule)
			continue
		}
		if rows[i].Member.Name == "" {
			for _, item := range items {
				if strings.TrimSpace(item.AccountName) != "" {
					rows[i].Member.Name = item.AccountName
					break
				}
			}
		}
		revenueUnavailable := false
		for _, item := range items {
			revenueUnavailable = revenueUnavailable || item.RevenueStatus == "source_error"
		}
		rows[i].AggregationNote = "Account CCR/NFS/Revenue 来自权威 Account 粒度 Saved Reports；Advertiser 指标仅用于展开解释，不覆盖 Account 值"
		if revenueUnavailable {
			rows[i].AggregationNote += "；Advertiser Revenue 明细源失败但不影响 Account Revenue"
		}
		rows[i].Message = wbMessage(rows[i], q, rule)
	}
	return rows
}

var wbQueryPairEvidence = queryAuthoritativePairEvidence

func previousCompleteWeek(now time.Time) (string, string) {
	local := now.In(cwLocation())
	daysSinceMonday := (int(local.Weekday()) + 6) % 7
	thisMonday := time.Date(local.Year(), local.Month(), local.Day(), 0, 0, 0, 0, local.Location()).AddDate(0, 0, -daysSinceMonday)
	return thisMonday.AddDate(0, 0, -7).Format("2006-01-02"), thisMonday.AddDate(0, 0, -1).Format("2006-01-02")
}
