// handler_overview.go — overview 资源的业务逻辑。
// 路由契约在 handler_overview.gen.go（由 IDL 生成，勿改）。
package main

import "net/http"

func overviewAccountsList(w http.ResponseWriter, r *http.Request)       { overviewAccountsHandler(w, r) }
func overviewGovernanceList(w http.ResponseWriter, r *http.Request)     { overviewGovernanceHandler(w, r) }
func overviewMetricsByMetricGet(w http.ResponseWriter, r *http.Request) { overviewMetricsHandler(w, r) }
func overviewQuotaList(w http.ResponseWriter, r *http.Request)          { overviewQuotaHandler(w, r) }
