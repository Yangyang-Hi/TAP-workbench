package main

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestOverviewFeatureFlagDefaultsEnabledAndSupportsRuntimeRollback(t *testing.T) {
	t.Setenv(overviewFeatureEnv, "")
	if !overviewFeatureEnabled() {
		t.Fatal("overview draft must be enabled by default")
	}
	for _, value := range []string{"1", "true", "YES", "on", "enabled"} {
		t.Setenv(overviewFeatureEnv, value)
		if !overviewFeatureEnabled() {
			t.Fatalf("overview flag %q should enable the feature", value)
		}
	}
	for _, value := range []string{"0", "false", "NO", "off", "disabled"} {
		t.Setenv(overviewFeatureEnv, value)
		if overviewFeatureEnabled() {
			t.Fatalf("overview flag %q should restore the original homepage", value)
		}
	}
}

func TestOverviewAccountSnapshotDoesNotFillMissingTierWithZero(t *testing.T) {
	complete := overviewParseAccounts(overviewEmptyAccounts("2026-10-25", "Global"), []map[string]any{
		{"client_tier": "strategic_trust", "account_count": 10.0},
		{"client_tier": "high_trust", "account_count": 20.0},
		{"client_tier": "building_trust", "account_count": 30.0},
		{"client_tier": "emerging_trust", "account_count": 40.0},
	})
	if complete.Status != "available" || complete.Total == nil || *complete.Total != 100 || complete.Rows[0].Share == nil || *complete.Rows[0].Share != 10 {
		t.Fatalf("complete snapshot mismatch: %+v", complete)
	}
	partial := overviewParseAccounts(overviewEmptyAccounts("2026-10-25", "Global"), []map[string]any{
		{"client_tier": "strategic_trust", "account_count": 10.0},
	})
	if partial.Status != "partial" || partial.Total != nil || partial.Rows[1].Count != nil {
		t.Fatalf("missing tier must remain null: %+v", partial)
	}
}

func TestOverviewQuarterSplitAndInputValidation(t *testing.T) {
	starts := overviewQuarterStarts(overviewFilter{Start: "2026-06-29", End: "2026-10-04"})
	if len(starts) != 3 || starts[0].Format("2006-01-02") != "2026-04-01" || starts[2].Format("2006-01-02") != "2026-10-01" {
		t.Fatalf("quarter split mismatch: %+v", starts)
	}

	request := httptest.NewRequest(http.MethodGet, "/api/overview/accounts?end_date=bad", nil)
	response := httptest.NewRecorder()
	overviewAccountsHandler(response, request)
	if response.Code != http.StatusBadRequest {
		t.Fatalf("invalid date status=%d body=%s", response.Code, response.Body.String())
	}
}

func TestOverviewRoutesRemainAuthenticatedReadonlyGETs(t *testing.T) {
	want := map[string]bool{
		"/api/overview/accounts":         false,
		"/api/overview/metrics/{metric}": false,
		"/api/overview/quota":            false,
		"/api/overview/governance":       false,
	}
	for _, route := range registry {
		if _, ok := want[route.Path]; !ok {
			continue
		}
		if route.Method != http.MethodGet || route.Public {
			t.Fatalf("overview route must be authenticated GET: %+v", route)
		}
		want[route.Path] = true
	}
	for path, found := range want {
		if !found {
			t.Fatalf("overview route not registered: %s", path)
		}
	}
}

func TestOverviewFormalNoticeRequiresVerifiedSubmitterBinding(t *testing.T) {
	alert := cwCase{ID: "case-1"}
	alert.Row.Member.Submitter = "owner"
	valid := cwNotice{CaseID: "case-1", Kind: "send", Status: "sent", MessageID: "msg-1", NotificationMode: "formal", TargetEmail: "owner@example.com"}
	if !overviewFormalSubmitterNotice(alert, valid) {
		t.Fatal("verified formal submitter notice should be counted")
	}
	valid.TargetEmail = "other@example.com"
	if overviewFormalSubmitterNotice(alert, valid) {
		t.Fatal("notice to another recipient must not be counted")
	}
}

func TestOverviewQuotaClipsEachQuarterToRequestedWindow(t *testing.T) {
	oldET, oldST := overviewETQuotaRows, overviewSTQuotaRows
	defer func() { overviewETQuotaRows, overviewSTQuotaRows = oldET, oldST }()
	starts, ends := []string{}, []string{}
	overviewETQuotaRows = func(_ context.Context, _ *http.Request, _, _, start, end string) (quotaAeolusResult, error) {
		starts, ends = append(starts, start), append(ends, end)
		return quotaAeolusResult{Rows: []submissionMetric{{TicketID: "t1", AccountIDs: []string{"a1"}, Region: "EUI"}}, Diagnostic: map[string]any{}}, nil
	}
	overviewSTQuotaRows = func(string) ([]stMetric, map[string]any, error) {
		return []stMetric{{Region: "EUI", Brand: "brand-1"}}, map[string]any{}, nil
	}

	request := httptest.NewRequest(http.MethodGet, "/api/overview/quota?start_date=2026-09-28&end_date=2026-10-18&region=Global", nil)
	response := httptest.NewRecorder()
	overviewQuotaHandler(response, request)
	if response.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", response.Code, response.Body.String())
	}
	if len(starts) != 2 || starts[0] != "2026-09-28" || starts[1] != "2026-10-01" || ends[0] != "2026-09-30" || ends[1] != "2026-10-18" {
		t.Fatalf("quota windows escaped requested range: starts=%#v ends=%#v", starts, ends)
	}
	var payload struct {
		Data struct {
			Quarters []map[string]any `json:"quarters"`
		} `json:"data"`
	}
	if err := json.Unmarshal(response.Body.Bytes(), &payload); err != nil {
		t.Fatal(err)
	}
	q3 := payload.Data.Quarters[0]
	q4 := payload.Data.Quarters[1]
	q3ET := q3["et"].(map[string]any)
	q4ET := q4["et"].(map[string]any)
	if q3["baseline_policy"] != "confirmed_same_as_q4" || q3["baseline_source_period"] != "2026 Q4" || q3ET["quota"] != q4ET["quota"] || q3ET["quota"] != float64(6356) {
		t.Fatalf("Q3 must reuse the exact Q4 Program/Region baseline: q3=%#v q4=%#v", q3, q4)
	}
	usageWindow := q4["usage_window"].(map[string]any)
	quotaPeriod := q4["quota_period"].(map[string]any)
	if usageWindow["start_date"] != "2026-10-01" || usageWindow["end_date"] != "2026-10-18" || quotaPeriod["start_date"] != "2026-10-01" || quotaPeriod["end_date"] != "2026-12-31" {
		t.Fatalf("quota metadata mismatch: %#v", q4)
	}
	et := q4["et"].(map[string]any)
	st := q4["st"].(map[string]any)
	if et["usage_count"] != float64(1) || et["quota"] == nil || et["ratio"] == nil {
		t.Fatalf("ET selected-window contract mismatch: %#v", et)
	}
	if st["usage_count"] != nil || st["ratio"] != nil || st["source_quarter_usage_count"] != float64(1) || st["quarter_snapshot_count"] != float64(1) || st["quarter_snapshot_status"] != "available" {
		t.Fatalf("ST quarter snapshot must remain visible without masquerading as selected-window usage: %#v", st)
	}
}

func TestOverviewRevenueUsesSavedReport3057978Contract(t *testing.T) {
	profile := overviewMetricProfiles()["revenue"]
	if profile.RID != 3057978 || profile.SID != 1280034 || profile.DateID != "10000002555291" || profile.RegionID != "10000016014003" || profile.TierID != "10000012645665" {
		t.Fatalf("unexpected revenue source contract: %+v", profile)
	}
	if !profile.ByTier || len(profile.Metrics["revenue"]) == 0 || profile.Metrics["revenue"][0] != "TAP Revenue" {
		t.Fatalf("revenue must preserve source-native Tier aggregation: %+v", profile)
	}
}

func TestOverviewP1UsesVerifiedRegionTierAxis(t *testing.T) {
	profile := overviewMetricProfiles()["p1-weekly"]
	if profile.RID != 3058062 || profile.BlockedReason != "" || profile.Weekly || !profile.ByRegion || !profile.ByTier || profile.AxisKey != "region" {
		t.Fatalf("P1 must use the verified Region×Tier classification axis: %+v", profile)
	}
}

func TestOverviewGovernanceReportsActualPartialCoverage(t *testing.T) {
	job := wbJob{
		BatchID:  "batch-et",
		Request:  wbRequest{Program: "ET", Start: "2026-10-12", End: "2026-10-18"},
		Status:   "ready",
		Complete: true,
	}
	data := overviewGovernanceData(nil, nil, map[string][]wbJob{"batch-et": {job}}, overviewFilter{Start: "2026-10-12", End: "2026-10-18", Region: "Global"}, "", "", true)
	if data["coverage_status"] != "partial" || data["evaluated_subjects"] != 0 {
		t.Fatalf("coverage must describe the actual saved scan, not imply a complete population: %#v", data)
	}
	windows, ok := data["batch_windows"].([]map[string]any)
	if !ok || len(windows) != 1 || windows[0]["batch_id"] != "batch-et" || windows[0]["start_date"] != "2026-10-12" || windows[0]["coverage"] != "complete" {
		t.Fatalf("actual batch window metadata missing: %#v", data["batch_windows"])
	}
}

func TestOverviewVerifiedMetricContractsAndBlockedBoundaries(t *testing.T) {
	profiles := overviewMetricProfiles()
	if p := profiles["p1-weekly"]; p.RID != 3058062 || p.BlockedReason != "" || p.Weekly || !p.ByRegion || !p.ByTier {
		t.Fatalf("P1 must expose its verified Region×Tier axis: %+v", p)
	}
	if p := profiles["p0"]; p.RID != 3065818 || p.SID != 1139137 || p.TID != 336 || p.BlockedReason != "" || !p.ByRegion || p.ByTier || p.AxisKey != "region" || !p.FixedQTDToD1 {
		t.Fatalf("P0 verified contract mismatch: %+v", p)
	}
	if p := profiles["approval-summary"]; p.RID != 3061919 || p.BlockedReason != "" || p.AxisKey != "quarter" || p.ByRegion || p.ByTier {
		t.Fatalf("Approval must expose the source quarter axis without fake groups: %+v", p)
	}
	if p := profiles["approval-weekly"]; p.RID != 3061919 || p.BlockedReason != "" || p.Weekly || p.AxisKey != "quarter" {
		t.Fatalf("Approval source must use quarter rather than fake week: %+v", p)
	}
	if p := profiles["fdr-weekly"]; p.RID != 2883048 || !containsString(p.SupportedRegions, "NA") || containsString(p.SupportedRegions, "CNOB") {
		t.Fatalf("unexpected FDR Global contract: %+v", p)
	}
	if p := profiles["fdr-weekly-region"]; p.RID != 2883021 || p.RegionValues["APAC"] != "APAC Team" {
		t.Fatalf("unexpected FDR Region contract: %+v", p)
	}
	if p := profiles["region-tier-accounts"]; p.RID != 3057978 || !p.ByRegion || !p.ByTier || p.Metrics["account_count"] == nil || p.Metrics["revenue"] == nil {
		t.Fatalf("unexpected Region×Tier contract: %+v", p)
	}
	if profiles["region-tier-revenue"].BlockedReason == "" {
		t.Fatal("Revenue combination must remain blocked")
	}
	if p := profiles["overturned-weekly"]; p.RID != 2883046 || p.BlockedReason != "" || !p.Weekly || p.Metrics["overturned"] == nil {
		t.Fatalf("Overturned must query its verified contract so no_data and request failure remain distinct: %+v", p)
	}
	zero := overviewMetricValues(overviewEmptyMetric(profiles["overturned-weekly"], overviewFilter{}), profiles["overturned-weekly"], nil)
	if zero.Status != "no_data" || len(zero.Rows) != 0 {
		t.Fatalf("successful zero-row Overturned query must be no_data: %+v", zero)
	}
}

func TestOverviewUnsupportedFDRReturnsBlockedWithoutQuery(t *testing.T) {
	old := overviewQueryReport
	defer func() { overviewQueryReport = old }()
	overviewQueryReport = func(context.Context, *http.Request, string) (map[string]any, error) {
		t.Fatal("blocked contracts must not query Aeolus")
		return nil, nil
	}
	for _, path := range []string{
		"/api/overview/metrics/fdr-weekly?start_date=2026-10-01&end_date=2026-10-20&region=CNOB",
	} {
		request := httptest.NewRequest(http.MethodGet, path, nil)
		metric := path[len("/api/overview/metrics/"):]
		for i, value := range metric {
			if value == '?' {
				metric = metric[:i]
				break
			}
		}
		request.SetPathValue("metric", metric)
		response := httptest.NewRecorder()
		overviewMetricsHandler(response, request)
		if response.Code != http.StatusOK {
			t.Fatalf("%s status=%d body=%s", path, response.Code, response.Body.String())
		}
		var payload struct {
			Data overviewMetricResult `json:"data"`
		}
		if err := json.Unmarshal(response.Body.Bytes(), &payload); err != nil || payload.Data.Status != "blocked" || payload.Data.Reason == "" {
			t.Fatalf("%s must return explicit blocked state: err=%v data=%+v", path, err, payload.Data)
		}
	}
}

func TestOverviewAccountsExplicitlyExcludesStandardTrust(t *testing.T) {
	data := overviewParseAccounts(overviewEmptyAccounts("2026-10-20", "Global"), []map[string]any{
		{"client_tier": "strategic_trust", "account_count": 10.0},
		{"client_tier": "high_trust", "account_count": 20.0},
		{"client_tier": "building_trust", "account_count": 30.0},
		{"client_tier": "emerging_trust", "account_count": 40.0},
		{"client_tier": "standard_trust", "account_count": 999999.0},
	})
	if data.Status != "available" || data.Total == nil || *data.Total != 100 || !strings.Contains(data.Reason, "排除") {
		t.Fatalf("four-Tier total must exclude standard_trust with an explicit note: %+v", data)
	}
}

func TestOverviewP0LongRowsPivotToTwelveRegionsWithoutCCRAverage(t *testing.T) {
	profile := overviewMetricProfiles()["p0"]
	regions := []string{"APAC", "CNOB", "EUI", "LATAM", "METAP", "NA", "NEA", "GA", "Scaled Growth", "SMB", "Other", "Global"}
	rows := make([]map[string]any, 0, 24)
	for i, region := range regions {
		rows = append(rows,
			map[string]any{"region": region, "ccr": float64(i) + 0.25, "nfs": nil},
			map[string]any{"region": region, "ccr": nil, "nfs": float64(i + 10)},
		)
	}
	result := overviewMetricValues(overviewEmptyMetric(profile, overviewFilter{}), profile, rows)
	if result.Status != "available" || len(result.Rows) != 12 {
		t.Fatalf("P0 24 long rows must become 12 Region rows: %+v", result)
	}
	for _, row := range result.Rows {
		region := asString(row["region"])
		if region == "APAC" && (row["ccr"] != 0.25 || row["nfs"] != float64(10)) {
			t.Fatalf("P0 CCR must be the direct source value, not an average: %#v", row)
		}
	}
}

func TestOverviewP1LongRowsPivotToUniqueRegionTierWithoutCCRAverage(t *testing.T) {
	profile := overviewMetricProfiles()["p1-weekly"]
	rows := []map[string]any{
		{"region": "APAC", "tier": "strategic_trust", "ccr": 123.0, "nfs": nil},
		{"region": "APAC", "tier": "strategic_trust", "ccr": nil, "nfs": 7.0},
		{"region": "APAC", "tier": "high_trust", "ccr": 456.0, "nfs": nil},
		{"region": "APAC", "tier": "high_trust", "ccr": nil, "nfs": 8.0},
	}
	result := overviewMetricValues(overviewEmptyMetric(profile, overviewFilter{}), profile, rows)
	if result.Status != "available" || len(result.Rows) != 2 || result.Rows[0]["ccr"] != 456.0 || result.Rows[1]["ccr"] != 123.0 {
		t.Fatalf("P1 must pivot by Region×Tier and preserve direct CCR values: %+v", result)
	}
}

func TestOverviewApprovalUsesSourceQuarterAxis(t *testing.T) {
	profile := overviewMetricProfiles()["approval-weekly"]
	rows := []map[string]any{
		{"quarter": "2026-Q3", "approval_rate": 0.91, "banned": 11.0},
		{"quarter": "2026-Q4", "approval_rate": 0.93, "banned": 9.0},
	}
	result := overviewMetricValues(overviewEmptyMetric(profile, overviewFilter{}), profile, rows)
	if result.Status != "available" || len(result.Rows) != 2 || result.Rows[0]["quarter"] != "2026-Q3" || result.Rows[1]["approval_rate"] != 0.93 {
		t.Fatalf("Approval must retain source year-quarter axis: %+v", result)
	}
}

func TestOverviewCanonicalizesRuntimeLongRows(t *testing.T) {
	profile := overviewMetricProfiles()["p1-weekly"]
	fieldMap := map[string]string{
		"250827103313797": "tier_v3_name 10000013113546",
		"260904154700065": "Sales region-8.6 10000013184595",
	}
	raw := []map[string]any{
		{"10001": "P1: Negative Feedback Show", "10003": "261028154914350", "10011": 7.0, "250827103313797": "strategic_trust", "260904154700065": "APAC"},
		{"10001": "Dynamic P1 Content CCR", "10003": "261028154914143", "10011": 123.0, "250827103313797": "strategic_trust", "260904154700065": "APAC"},
	}
	canonical, err := overviewCanonicalMetrics(raw, fieldMap, profile)
	if err != nil || len(canonical) != 2 || canonical[0]["nfs"] != 7.0 || canonical[1]["ccr"] != 123.0 {
		t.Fatalf("runtime pivot rows must retain direct metric values: rows=%#v err=%v", canonical, err)
	}
	result := overviewMetricValues(overviewEmptyMetric(profile, overviewFilter{}), profile, canonical)
	if result.Status != "available" || len(result.Rows) != 1 || result.Rows[0]["ccr"] != 123.0 || result.Rows[0]["nfs"] != 7.0 {
		t.Fatalf("runtime pivot rows must merge by Region×Tier without averaging: %+v", result)
	}
}

func TestOverviewMetricPivotEmptyPartialAndDuplicateHandling(t *testing.T) {
	profile := overviewMetricProfiles()["p0"]
	empty := overviewMetricValues(overviewEmptyMetric(profile, overviewFilter{}), profile, nil)
	if empty.Status != "no_data" || len(empty.Rows) != 0 {
		t.Fatalf("empty source rows must remain no_data: %+v", empty)
	}
	partial := overviewMetricValues(overviewEmptyMetric(profile, overviewFilter{}), profile, []map[string]any{{"region": "APAC", "ccr": 1.25, "nfs": nil}})
	if partial.Status != "partial" || len(partial.Rows) != 1 || partial.Rows[0]["ccr"] != 1.25 {
		t.Fatalf("source-null metric must remain partial without zero fill: %+v", partial)
	}
	duplicate := overviewMetricValues(overviewEmptyMetric(profile, overviewFilter{}), profile, []map[string]any{
		{"region": "APAC", "ccr": 1.0, "nfs": nil},
		{"region": "APAC", "ccr": 2.0, "nfs": 5.0},
	})
	if duplicate.Status != "partial" || len(duplicate.Rows) != 0 || !strings.Contains(duplicate.Reason, "未平均") {
		t.Fatalf("conflicting duplicate must fail closed without averaging: %+v", duplicate)
	}
}
