package main

import (
	"context"
	"fmt"
	"math"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"
)

type overviewFilter struct {
	Start  string   `json:"start_date"`
	End    string   `json:"end_date"`
	Region string   `json:"region"`
	Tiers  []string `json:"tiers,omitempty"`
}
type overviewMetricProfile struct {
	Key, Source, Label       string
	RID, AppID, SID, TID     int
	DateID, RegionID, TierID string
	Metrics                  map[string][]string
	ByTier, ByRegion         bool
	Weekly, Online           bool
	DateFilter               bool
	AxisKey                  string
	AxisAliases              []string
	FixedQTDToD1             bool
	MetricUnits              map[string]string
	Unit                     string
	BlockedReason            string
	SupportedRegions         []string
	RegionValues             map[string]string
	TimeSemantics            string
}
type overviewMetricResult struct {
	Module      string           `json:"module"`
	Status      string           `json:"status"`
	Reason      string           `json:"reason,omitempty"`
	Window      overviewFilter   `json:"window"`
	Rows        []map[string]any `json:"rows"`
	Summary     map[string]any   `json:"summary"`
	Source      map[string]any   `json:"source"`
	Diagnostics map[string]any   `json:"diagnostics"`
	QueriedAt   string           `json:"queried_at"`
	SideEffects bool             `json:"side_effects"`
}

func overviewMetricProfiles() map[string]overviewMetricProfile {
	base := overviewMetricProfile{AppID: 800414, SID: 1139137, DateID: "10000003854360", RegionID: "10000016013001", TierID: "10000013113546", DateFilter: true, TimeSemantics: "business_date_window"}
	fdrBase := overviewMetricProfile{AppID: 800414, SID: 1198629, RegionID: "10000000894158", TimeSemantics: "latest_snapshot_business_week", SupportedRegions: []string{"Global", "APAC", "EUI", "LATAM", "METAP", "NA"}, RegionValues: map[string]string{"APAC": "APAC Team", "EUI": "EUI Team", "LATAM": "LATAM Team", "METAP": "METAP Team", "NA": "NA Team"}}
	profiles := []overviewMetricProfile{
		{Key: "business-summary", RID: 2892274, AppID: 800414, SID: 1280034, DateID: "10000002555291", RegionID: "10000016013590", TierID: "10000012645665", DateFilter: true, TimeSemantics: "business_date_window", Label: "TAP 原生区间总卡", Metrics: map[string][]string{"account_count": {"TAP Accounts", "account_count"}, "revenue": {"TAP Revenue", "revenue"}}},
		{Key: "revenue", RID: 3057978, AppID: 800414, SID: 1280034, DateID: "10000002555291", RegionID: "10000016014003", TierID: "10000012645665", DateFilter: true, TimeSemantics: "business_date_window", Label: "Revenue 分布", ByTier: true, Metrics: map[string][]string{"revenue": {"TAP Revenue", "revenue"}}},
		{Key: "p0", RID: 3065818, AppID: 800414, SID: 1139137, TID: 336, DateID: base.DateID, RegionID: "10000013184595", TierID: base.TierID, DateFilter: true, FixedQTDToD1: true, Online: true, ByRegion: true, AxisKey: "region", AxisAliases: []string{"Sales region-8.6", "region", "10000013184595", "260904154700065"}, TimeSemantics: "qtd_to_d_minus_1_filter_only", Label: "P0 CCR/NFS｜按Region（源报表区间趋势型展示）", MetricUnits: map[string]string{"ccr": "percent", "nfs": "count"}, Metrics: map[string][]string{"ccr": {"Dynamic P0 Content CCR", "10000000032693", "260325121636679"}, "nfs": {"P0: Negative Feedback Show", "10000000032674", "260325121636716"}}},
		{Key: "p0-weekly", RID: 3065818, AppID: 800414, SID: 1139137, TID: 336, DateID: base.DateID, RegionID: "10000013184595", TierID: base.TierID, DateFilter: true, FixedQTDToD1: true, Online: true, ByRegion: true, AxisKey: "region", AxisAliases: []string{"Sales region-8.6", "region", "10000013184595", "260904154700065"}, TimeSemantics: "qtd_to_d_minus_1_filter_only", Label: "P0 CCR/NFS｜按Region（源报表区间趋势型展示）", MetricUnits: map[string]string{"ccr": "percent", "nfs": "count"}, Metrics: map[string][]string{"ccr": {"Dynamic P0 Content CCR", "10000000032693", "260325121636679"}, "nfs": {"P0: Negative Feedback Show", "10000000032674", "260325121636716"}}},
		{Key: "p1-weekly", RID: 3058062, AppID: 800414, SID: 1139137, DateID: base.DateID, RegionID: "10000013184595", TierID: base.TierID, DateFilter: true, ByTier: true, ByRegion: true, AxisKey: "region", AxisAliases: []string{"Sales region-8.6", "region", "10000013184595", "260904154700065"}, TimeSemantics: "business_date_filter_region_tier_axis", Label: "P1 CCR/NFS｜按Region×Tier（源报表分类轴展示）", MetricUnits: map[string]string{"ccr": "ppm", "nfs": "count"}, Metrics: map[string][]string{"ccr": {"Dynamic P1 Content CCR", "P1 Content CCR", "P1 CCR", "10000000032695", "261028154914143"}, "nfs": {"P1: Negative Feedback Show", "P1 Negative Feedback Show", "P1 NFS", "10000000032677", "261028154914350"}}},
		{Key: "p1-weekly-new", RID: 3058062, AppID: 800414, SID: 1139137, DateID: base.DateID, RegionID: "10000013184595", TierID: base.TierID, DateFilter: true, ByTier: true, ByRegion: true, AxisKey: "region", AxisAliases: []string{"Sales region-8.6", "region", "10000013184595", "260904154700065"}, TimeSemantics: "business_date_filter_region_tier_axis", Label: "P1 CCR/NFS｜按Region×Tier（源报表分类轴展示）", MetricUnits: map[string]string{"ccr": "ppm", "nfs": "count"}, Metrics: map[string][]string{"ccr": {"Dynamic P1 Content CCR", "P1 Content CCR", "P1 CCR", "10000000032695", "261028154914143"}, "nfs": {"P1: Negative Feedback Show", "P1 Negative Feedback Show", "P1 NFS", "10000000032677", "261028154914350"}}},
		{Key: "approval-summary", RID: 3061919, AppID: 800414, SID: 1139137, AxisKey: "quarter", AxisAliases: []string{"year-quarter p_date", "p_date", "1700008351638", "250728142548092"}, TimeSemantics: "source_year_quarter", Label: "Approval Rate / Banned｜按源季度", MetricUnits: map[string]string{"approval_rate": "source_rate", "banned": "count"}, Metrics: map[string][]string{"approval_rate": {"Approval Rate", "1700015681443", "240514140051276"}, "banned": {"banned", "Banned", "10000000980775", "260904172024093"}}},
		{Key: "approval-weekly", RID: 3061919, AppID: 800414, SID: 1139137, AxisKey: "quarter", AxisAliases: []string{"year-quarter p_date", "p_date", "1700008351638", "250728142548092"}, TimeSemantics: "source_year_quarter", Label: "Approval Rate / Banned｜按源季度", MetricUnits: map[string]string{"approval_rate": "source_rate", "banned": "count"}, Metrics: map[string][]string{"approval_rate": {"Approval Rate", "1700015681443", "240514140051276"}, "banned": {"banned", "Banned", "10000000980775", "260904172024093"}}},
		{Key: "approval-weekly-region", RID: 3061919, Label: "Approval / Banned 周趋势", BlockedReason: "RID3061919 不支持 Region 分组，且没有 week 字段。"},
		{Key: "fdr-weekly", RID: 2883048, AppID: fdrBase.AppID, SID: fdrBase.SID, TierID: fdrBase.TierID, ByTier: true, Weekly: true, Unit: "source_rate", TimeSemantics: fdrBase.TimeSemantics, SupportedRegions: fdrBase.SupportedRegions, RegionValues: fdrBase.RegionValues, Label: "Ads FDR 周趋势（Global）", Metrics: map[string][]string{"fdr": {"Ads FDR", "FDR"}}},
		{Key: "fdr-weekly-region", RID: 2883021, AppID: fdrBase.AppID, SID: fdrBase.SID, RegionID: fdrBase.RegionID, TierID: fdrBase.TierID, ByTier: true, Weekly: true, Unit: "source_rate", TimeSemantics: fdrBase.TimeSemantics, SupportedRegions: fdrBase.SupportedRegions, RegionValues: fdrBase.RegionValues, Label: "Ads FDR 周趋势（Region）", Metrics: map[string][]string{"fdr": {"Ads FDR", "FDR"}}},
		{Key: "overturned-weekly", RID: 2883046, AppID: fdrBase.AppID, SID: fdrBase.SID, TierID: fdrBase.TierID, ByTier: true, Weekly: true, TimeSemantics: fdrBase.TimeSemantics, Label: "Overturned 周趋势", Metrics: map[string][]string{"overturned": {"Overturned Account Volume", "Overturned Accounts", "overturned"}}},
		{Key: "region-tier-accounts", RID: 3057978, AppID: 800414, SID: 1280034, DateID: "10000002555291", RegionID: "10000016014003", TierID: "10000012645665", DateFilter: true, TimeSemantics: "business_date_window", Label: "Region × Tier Account / Revenue", ByTier: true, ByRegion: true, Metrics: map[string][]string{"account_count": {"TAP Accounts", "account_count"}, "revenue": {"TAP Revenue", "revenue"}}},
		{Key: "region-tier-revenue", Label: "Region × Tier Revenue", BlockedReason: "与 RID3057978 Region×Tier 原生行共源；不另行拼接。"},
	}
	out := map[string]overviewMetricProfile{}
	for _, item := range profiles {
		if item.AppID == 0 && item.BlockedReason == "" {
			item.AppID, item.SID = base.AppID, base.SID
			if item.DateID == "" && item.TimeSemantics == "" {
				item.DateID = base.DateID
			}
			if item.RegionID == "" && !strings.Contains(item.Key, "approval-weekly") && !strings.Contains(item.Key, "fdr-weekly") {
				item.RegionID = base.RegionID
			}
			if item.TierID == "" {
				item.TierID = base.TierID
			}
		}
		item.Source = fmt.Sprintf("overview_metric_%s_%d", item.Key, item.RID)
		out[item.Key] = item
	}
	return out
}
func overviewMetricSource(name string) (overviewMetricProfile, bool) {
	for _, p := range overviewMetricProfiles() {
		if p.Source == name {
			return p, true
		}
	}
	return overviewMetricProfile{}, false
}
func (p overviewMetricProfile) config() sourceConfig {
	dateSource, regionSource := "p_date", "Sales region-8.6"
	if strings.HasPrefix(p.Key, "fdr-") {
		regionSource = "combined_sales_team_region"
	}
	fields := map[string]fieldConfig{
		"p_date":      {DimMetID: p.DateID, UniqueID: p.DateID, SourceName: dateSource, ExpectedType: "string"},
		"region":      {DimMetID: p.RegionID, UniqueID: p.RegionID, SourceName: regionSource},
		"client_tier": {DimMetID: p.TierID, UniqueID: p.TierID, SourceName: "tier_v3_name"},
	}
	if p.Key == "revenue" {
		// RID 3057978's saved request identifies TAP Revenue with this source metric.
		// Keeping it in the Overview-only source contract prevents the generic probe
		// projection from dropping a metric that remains present in selectIdList.
		fields["revenue"] = fieldConfig{DimMetID: "10000013222449", UniqueID: "260904152028189", SourceName: "TAP Revenue", ExpectedType: "number"}
	}
	return sourceConfig{Kind: "aggregate", Grain: "overview_native_aggregate", Enabled: true, AppID: p.AppID, SID: p.SID, RID: p.RID, TID: p.TID, Identity: sourceIdentity{AppID: p.AppID, SID: p.SID, RID: p.RID, TID: p.TID, Region: "sg", QueryMode: "aggregate"}, SupportedDimensions: []string{"date", "region", "client_tier"}, Fields: fields}
}

func overviewNormalizeRegion(raw string) string {
	value := strings.TrimSpace(raw)
	if value == "" || strings.EqualFold(value, "all") {
		return "Global"
	}
	return value
}
func overviewAllowedRegion(region string) bool {
	return containsString([]string{"Global", "APAC", "CNOB", "EUI", "LATAM", "METAP", "NA", "NEA", "GA", "Scaled Growth", "SMB", "Other"}, region)
}
func overviewParseWindow(v url.Values) (overviewFilter, error) {
	today := time.Now().In(cwLocation())
	end := strings.TrimSpace(v.Get("end_date"))
	if end == "" {
		end = today.Format("2006-01-02")
	}
	endDay, err := time.Parse("2006-01-02", end)
	if err != nil || endDay.Format("2006-01-02") != end {
		return overviewFilter{}, fmt.Errorf("日期必须为 YYYY-MM-DD")
	}
	start := strings.TrimSpace(v.Get("start_date"))
	if start == "" {
		start = time.Date(endDay.Year(), time.Month((int(endDay.Month())-1)/3*3+1), 1, 0, 0, 0, 0, cwLocation()).Format("2006-01-02")
	}
	startDay, err := time.Parse("2006-01-02", start)
	if err != nil || startDay.Format("2006-01-02") != start || start > end || end > today.Format("2006-01-02") {
		return overviewFilter{}, fmt.Errorf("开始日期不得晚于结束日期，结束日期不得晚于今天")
	}
	region := overviewNormalizeRegion(v.Get("region"))
	if !overviewAllowedRegion(region) {
		return overviewFilter{}, fmt.Errorf("Region 不在已声明范围")
	}
	tiers := uniqueNonEmpty(strings.Split(v.Get("tier"), ","))
	if len(tiers) == 0 {
		tiers = append([]string(nil), overviewTierLabels...)
	}
	for _, tier := range tiers {
		if !containsString(overviewTierLabels, strings.ToUpper(tier)) {
			return overviewFilter{}, fmt.Errorf("Tier 仅支持 ST/HT/BT/ET")
		}
	}
	return overviewFilter{Start: start, End: end, Region: region, Tiers: tiers}, nil
}

func overviewMetricChart(raw, chart map[string]any, p overviewMetricProfile, f filterRequest) (map[string]any, error) {
	ids := map[string]bool{}
	var walk func(any)
	walk = func(v any) {
		switch n := v.(type) {
		case map[string]any:
			for _, key := range []string{"id", "originId", "datasetFieldId", "dimMetId"} {
				if id := contractIDString(n[key]); id != "" {
					ids[id] = true
				}
			}
			for _, child := range n {
				walk(child)
			}
		case []any:
			for _, child := range n {
				walk(child)
			}
		}
	}
	walk(raw)
	for _, id := range []string{p.DateID, p.TierID} {
		if id != "" && !ids[id] {
			return nil, fmt.Errorf("overview %s 缺少固定字段 %s", p.Key, id)
		}
	}
	if f.Region != "" && p.RegionID != "" && !ids[p.RegionID] {
		return nil, fmt.Errorf("overview %s 缺少 Region 字段", p.Key)
	}
	filters := []any{}
	if p.DateFilter && p.DateID != "" {
		filters = append(filters, map[string]any{"type": "whereDate", "datasetFieldId": p.DateID, "uniqueId": p.DateID, "detail": map[string]any{"startTime": map[string]any{"type": "fixed", "date": f.StartDate + " 00:00:00"}, "endTime": map[string]any{"type": "fixed", "date": f.EndDate + " 23:59:59"}, "dateMode": "calendar_days", "dateNullOption": "nonNull"}})
	}
	if p.TierID != "" {
		tierKeys := append([]string(nil), overviewTierKeys...)
		if f.ClientTier != "" {
			tierKeys = nil
			for _, selected := range strings.Split(f.ClientTier, ",") {
				for i, label := range overviewTierLabels {
					if strings.EqualFold(strings.TrimSpace(selected), label) || strings.EqualFold(strings.TrimSpace(selected), overviewTierKeys[i]) {
						tierKeys = append(tierKeys, overviewTierKeys[i])
					}
				}
			}
		}
		filters = append(filters, aeolusFilter(p.TierID, p.TierID, "IN", tierKeys))
	}
	if f.Region != "" && p.RegionID != "" {
		regions := strings.Split(f.Region, ",")
		for i, region := range regions {
			if mapped := p.RegionValues[region]; mapped != "" {
				regions[i] = mapped
			}
		}
		filters = append(filters, aeolusFilter(p.RegionID, p.RegionID, "IN", regions))
	}
	if p.Online {
		filters = append(filters, aeolusFilter("10000000032606", "10000000032606", "IN", []string{"1"}))
	}
	out := cloneMap(chart)
	out["filters"] = filters
	return out, nil
}
func overviewMetricRequest(raw map[string]any, p overviewMetricProfile, _ filterRequest) map[string]any {
	body := cloneMap(raw)
	q, _ := body["query"].(map[string]any)
	remove := map[string]bool{}
	if p.RegionID != "" && !p.ByRegion {
		remove[p.RegionID] = true
	}
	if !p.ByTier && p.TierID != "" {
		remove[p.TierID] = true
	}
	if !p.Weekly && p.AxisKey != "quarter" && p.AxisKey != "date" && p.DateID != "" {
		remove[p.DateID] = true
	}
	fieldID := func(v any) string {
		if n, ok := v.(map[string]any); ok {
			return firstNonEmpty(n, "datasetFieldId", "dimMetId", "id", "originId")
		}
		return contractIDString(v)
	}
	for _, key := range []string{"dimensions", "groupByIdList"} {
		if items, ok := q[key].([]any); ok {
			next := []any{}
			for _, item := range items {
				if !remove[fieldID(item)] {
					next = append(next, item)
				}
			}
			q[key] = next
		}
	}
	if locations, ok := q["locations"].(map[string]any); ok {
		if items, ok := locations["dimensions"].([]any); ok {
			next := []any{}
			for _, item := range items {
				if !remove[fieldID(item)] {
					next = append(next, item)
				}
			}
			locations["dimensions"] = next
		}
	}
	return body
}
func overviewCanonicalMetrics(raw []map[string]any, fieldMap map[string]string, p overviewMetricProfile) ([]map[string]any, error) {
	aliases := map[string][]string{}
	for key, list := range p.Metrics {
		aliases[key] = list
	}
	if p.ByTier {
		aliases["tier"] = []string{"tier_v3_name", "client_tier", p.TierID}
	}
	if p.ByRegion {
		aliases["region"] = []string{"account_final_region", "Sales region-8.6", "combined_sales_team_region", p.RegionID}
	}
	if p.Weekly {
		aliases["week"] = []string{"week", "p_date", "周"}
	}
	if p.AxisKey != "" && p.AxisKey != "region" && p.AxisKey != "tier" && p.AxisKey != "week" {
		aliases[p.AxisKey] = append([]string(nil), p.AxisAliases...)
	}
	matchesAlias := func(desc string, names []string) bool {
		for _, name := range names {
			if name != "" && strings.Contains(strings.ToLower(desc), strings.ToLower(name)) {
				return true
			}
		}
		return false
	}
	out := make([]map[string]any, 0, len(raw))
	for _, row := range raw {
		next := map[string]any{}
		longMetricLabel := strings.TrimSpace(asString(row["10001"]) + " " + asString(row["20001"]))
		longMetricFound := false
		for key, names := range aliases {
			if _, isMetric := p.Metrics[key]; isMetric && longMetricLabel != "" {
				if matchesAlias(longMetricLabel, names) {
					value, ok := row["10011"]
					if !ok {
						value, ok = row[strings.TrimSpace(asString(row["10003"]))]
					}
					if !ok {
						return nil, fmt.Errorf("overview %s: 长表指标 %s 缺少值列", p.Key, key)
					}
					next[key], longMetricFound = value, true
				}
				continue
			}
			matches := 0
			for col, value := range row {
				desc := strings.ToLower(col + " " + fieldMap[col])
				if matchesAlias(desc, names) {
					matches++
					next[key] = value
				}
			}
			if matches != 1 {
				return nil, fmt.Errorf("overview %s: %s 匹配 %d 列", p.Key, key, matches)
			}
		}
		if longMetricLabel != "" && !longMetricFound {
			return nil, fmt.Errorf("overview %s: 未识别长表指标 %s", p.Key, longMetricLabel)
		}
		out = append(out, next)
	}
	return out, nil
}
func overviewEmptyMetric(p overviewMetricProfile, f overviewFilter) overviewMetricResult {
	source := map[string]any{"rid": p.RID, "sid": p.SID, "tid": p.TID, "app_id": p.AppID, "label": p.Label, "native_aggregation": true, "unit": p.Unit, "metric_units": p.MetricUnits, "axis": p.AxisKey, "time_semantics": p.TimeSemantics, "snapshot_date": nil}
	if len(p.SupportedRegions) > 0 {
		source["supported_regions"] = p.SupportedRegions
	}
	return overviewMetricResult{Module: p.Key, Status: "unavailable", Window: f, Rows: []map[string]any{}, Summary: map[string]any{}, Source: source, Diagnostics: map[string]any{}, QueriedAt: time.Now().UTC().Format(time.RFC3339)}
}
func overviewBlockedMetric(p overviewMetricProfile, f overviewFilter, reason string) overviewMetricResult {
	o := overviewEmptyMetric(p, f)
	o.Status, o.Reason = "blocked", reason
	if o.Reason == "" {
		o.Reason = p.BlockedReason
	}
	return o
}
func overviewMetricValues(o overviewMetricResult, p overviewMetricProfile, rows []map[string]any) overviewMetricResult {
	if len(rows) == 0 {
		o.Status, o.Reason = "no_data", "源报表无数据；未补零。"
		return o
	}
	if !p.ByTier && !p.ByRegion && !p.Weekly && p.AxisKey == "" && len(rows) != 1 {
		o.Reason = "原生总卡返回多行，未二次平均或累加。"
		return o
	}
	seen, rowIndex, excludedTiers, valid := map[string]bool{}, map[string]int{}, map[string]bool{}, true
	total := 0.0
	for _, raw := range rows {
		row := map[string]any{}
		key := "summary"
		if p.ByTier {
			tier := strings.ToLower(strings.TrimSpace(asString(raw["tier"])))
			idx := -1
			for i, value := range overviewTierKeys {
				if tier == value || strings.EqualFold(tier, overviewTierLabels[i]) {
					idx = i
				}
			}
			if idx < 0 {
				excludedTiers[tier] = true
				continue
			}
			row["tier"], row["source_tier"], key = overviewTierLabels[idx], tier, tier
		}
		if p.ByRegion {
			region := strings.TrimSpace(asString(raw["region"]))
			if region == "" {
				o.Reason = "源 Region 为空"
				o.Rows = []map[string]any{}
				return o
			}
			row["region"], key = region, region+"|"+key
		}
		if p.Weekly {
			week := strings.TrimSpace(asString(raw["week"]))
			if week == "" {
				o.Reason = "源周为空"
				o.Rows = []map[string]any{}
				return o
			}
			row["week"], key = week, week+"|"+key
		}
		if p.AxisKey != "" && p.AxisKey != "region" && p.AxisKey != "tier" && p.AxisKey != "week" {
			axis := strings.TrimSpace(asString(raw[p.AxisKey]))
			if axis == "" {
				o.Reason = "源分类轴为空"
				o.Rows = []map[string]any{}
				return o
			}
			row[p.AxisKey], key = axis, axis+"|"+key
		}
		if seen[key] {
			existing := o.Rows[rowIndex[key]]
			compatible := true
			for metric := range p.Metrics {
				oldValue, oldOK := number(existing[metric])
				newValue, newOK := number(raw[metric])
				switch {
				case oldOK && newOK && math.Abs(oldValue-newValue) >= 1e-12:
					compatible = false
				case !oldOK && newOK:
					existing[metric] = newValue
				}
			}
			if compatible {
				continue
			}
			o.Status = "partial"
			o.Reason = fmt.Sprintf("同 %s 唯一键返回重复且冲突的源指标；未平均、累加或补零。", p.AxisKey)
			o.Rows = []map[string]any{}
			return o
		}
		seen[key] = true
		for metric := range p.Metrics {
			n, ok := number(raw[metric])
			if !ok || math.IsNaN(n) || math.IsInf(n, 0) {
				row[metric] = nil
				valid = false
			} else {
				row[metric] = n
				if metric == "revenue" {
					total += n
				}
			}
		}
		rowIndex[key] = len(o.Rows)
		o.Rows = append(o.Rows, row)
	}
	if len(o.Rows) == 0 {
		o.Status, o.Reason = "no_data", "源报表仅返回非 ET/ST/BT/HT Tier；未回填或补零。"
		return o
	}
	valid = true
	for _, row := range o.Rows {
		for metric := range p.Metrics {
			if _, ok := number(row[metric]); !ok {
				valid = false
			}
		}
	}
	o.Status = "available"
	if !valid {
		o.Status, o.Reason = "partial", "部分指标为 source_null；未补零。"
	} else if len(excludedTiers) > 0 {
		excluded := make([]string, 0, len(excludedTiers))
		for tier := range excludedTiers {
			excluded = append(excluded, tier)
		}
		sort.Strings(excluded)
		o.Status, o.Reason = "partial", "仅展示 ET/ST/BT/HT；源端其他 Tier 已排除。"
		o.Diagnostics["excluded_tiers"] = excluded
	}
	if p.Key == "revenue" && len(seen) == 4 && valid {
		o.Summary["revenue"] = total
		if total > 0 {
			for _, row := range o.Rows {
				row["share"] = row["revenue"].(float64) / total * 100
			}
		}
	}
	if !p.ByTier && !p.ByRegion && !p.Weekly && p.AxisKey == "" {
		for metric := range p.Metrics {
			o.Summary[metric] = o.Rows[0][metric]
		}
	}
	if p.AxisKey != "" && !p.Weekly {
		sort.SliceStable(o.Rows, func(i, j int) bool {
			return fmt.Sprint(o.Rows[i][p.AxisKey], o.Rows[i]["tier"]) < fmt.Sprint(o.Rows[j][p.AxisKey], o.Rows[j]["tier"])
		})
	}
	if p.Weekly {
		sort.Slice(o.Rows, func(i, j int) bool {
			return fmt.Sprint(o.Rows[i]["week"], o.Rows[i]["tier"]) < fmt.Sprint(o.Rows[j]["week"], o.Rows[j]["tier"])
		})
		latest := ""
		for _, row := range o.Rows {
			if week := asString(row["week"]); week > latest {
				latest = week
			}
		}
		currentWindow := o.Window.End >= time.Now().In(cwLocation()).Format("2006-01-02")
		for _, row := range o.Rows {
			row["week_status"] = "complete"
			if currentWindow && asString(row["week"]) == latest {
				row["week_status"] = "in_progress"
			}
		}
	}
	return o
}
func overviewLoadMetric(r *http.Request, p overviewMetricProfile, f overviewFilter) overviewMetricResult {
	if p.FixedQTDToD1 {
		end := time.Now().In(cwLocation()).AddDate(0, 0, -1)
		f.Start = time.Date(end.Year(), time.Month((int(end.Month())-1)/3*3+1), 1, 0, 0, 0, 0, cwLocation()).Format("2006-01-02")
		f.End = end.Format("2006-01-02")
	}
	o := overviewEmptyMetric(p, f)
	if p.BlockedReason != "" {
		return overviewBlockedMetric(p, f, "")
	}
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()
	request := r.Clone(ctx)
	u := *r.URL
	q := url.Values{"start_date": {f.Start}, "end_date": {f.End}, "tier": {strings.Join(f.Tiers, ",")}, "client_tier": {strings.Join(f.Tiers, ",")}}
	if f.Region != "Global" {
		q.Set("region", f.Region)
	}
	u.RawQuery = q.Encode()
	request.URL = &u
	request.Form, request.PostForm = nil, nil
	probe, err := overviewQueryReport(ctx, request, p.Source)
	if err != nil {
		o.Reason = "风神请求未完成"
		o.Diagnostics["error"] = sanitizeAuditText(err.Error())
		return o
	}
	o.Diagnostics = map[string]any{
		"status":     probe["status"],
		"audit_id":   probe["audit_id"],
		"request_id": probe["requestId"],
		"columns":    probe["columns"],
	}
	if p.RID == 3065818 || p.RID == 3058062 || p.RID == 3061919 {
		o.Diagnostics["warnings"] = []map[string]any{{
			"code":     "dashboard_public_filter_http_403",
			"severity": "warning",
			"action":   "continued_with_saved_report_fixed_filters",
		}}
	}
	if asString(probe["status"]) != "ok" {
		o.Reason = "报表合同或查询未通过"
		return o
	}
	if asBool(probe["possibly_truncated"]) {
		o.Reason = "源结果可能截断"
		return o
	}
	rows, ok := probe["business_rows"].([]map[string]any)
	if !ok {
		o.Reason = "返回结构不符合合同"
		return o
	}
	if p.Weekly && p.TimeSemantics == "latest_snapshot_business_week" {
		filteredRows := make([]map[string]any, 0, len(rows))
		for _, row := range rows {
			if overviewWeekIntersectsWindow(asString(row["week"]), f) {
				filteredRows = append(filteredRows, row)
			}
		}
		rows = filteredRows
	}
	return overviewMetricValues(o, p, rows)
}
func overviewMetricsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	profiles := overviewMetricProfiles()
	requested := r.PathValue("metric")
	p, ok := profiles[requested]
	if !ok {
		writeJSON(w, 404, map[string]any{"error": "unknown overview metric"})
		return
	}
	f, err := overviewParseWindow(r.URL.Query())
	if err != nil {
		writeJSON(w, 400, map[string]any{"error": err.Error()})
		return
	}
	if requested == "fdr-weekly" && f.Region != "Global" {
		p = profiles["fdr-weekly-region"]
		p.Key = requested
	}
	if strings.HasPrefix(requested, "fdr-weekly") && !containsString(p.SupportedRegions, f.Region) {
		writeJSON(w, 200, map[string]any{"data": overviewBlockedMetric(p, f, fmt.Sprintf("%s 不在 FDR 已核验范围 Global/APAC/EUI/LATAM/METAP/NA；未回退 Global。", f.Region))})
		return
	}
	writeJSON(w, 200, map[string]any{"data": overviewLoadMetric(r, p, f)})
}

func overviewWeekIntersectsWindow(label string, window overviewFilter) bool {
	var year, weekNo, startMonth, startDay, endMonth, endDay int
	if _, err := fmt.Sscanf(label, "%d-W%d(%d/%d~%d/%d)", &year, &weekNo, &startMonth, &startDay, &endMonth, &endDay); err != nil {
		return true
	}
	start := time.Date(year, time.Month(startMonth), startDay, 0, 0, 0, 0, cwLocation())
	endYear := year
	if endMonth < startMonth {
		endYear++
	}
	end := time.Date(endYear, time.Month(endMonth), endDay, 23, 59, 59, 0, cwLocation())
	windowStart, startErr := time.ParseInLocation("2006-01-02", window.Start, cwLocation())
	windowEnd, endErr := time.ParseInLocation("2006-01-02", window.End, cwLocation())
	if startErr != nil || endErr != nil {
		return true
	}
	windowEnd = windowEnd.Add(24*time.Hour - time.Nanosecond)
	return !end.Before(windowStart) && !start.After(windowEnd)
}
