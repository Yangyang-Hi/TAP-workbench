package main

import (
	"fmt"
	"strconv"
	"strings"
)

func cwRevenue(v *float64) string {
	if v == nil {
		return "—"
	}
	s := fmt.Sprintf("%.2f", *v)
	parts := strings.SplitN(s, ".", 2)
	for i := len(parts[0]) - 3; i > 0; i -= 3 {
		parts[0] = parts[0][:i] + "," + parts[0][i:]
	}
	return strings.Join(parts, ".")
}

func cwRiskOverviewHTML(x cwAnalytics) string {
	var b strings.Builder
	if x.BatchStatus.Incomplete {
		b.WriteString("<div class=stage-strip><div><span class=stage-icon>!</span><span><strong>阶段性结果</strong><small>未返回项目不按 0 统计</small></span></div><div class=stage-chips>")
		for _, p := range x.BatchStatus.Programs {
			b.WriteString("<span><b>" + cwH(p.Program) + "</b> " + cwH(p.Status) + " · " + cwH(p.Stage) + "</span>")
		}
		b.WriteString("</div></div>")
	}
	b.WriteString("<div class=rule-grid>")
	for i, r := range x.RuleSummaries {
		tone, icon := "absolute", "↗"
		if r.Category == "等级" {
			icon = "!"
			if strings.Contains(r.Key, "critical") || strings.Contains(r.Name, "极端") {
				tone = "critical"
			} else {
				tone = "watch"
			}
		} else if i%2 == 1 {
			tone = "growth"
		}
		share := "不适用"
		if x.Summary["alerts"] > 0 {
			share = fmt.Sprintf("%.1f%%", float64(r.Events)*100/float64(x.Summary["alerts"]))
		}
		b.WriteString("<article class=\"rule is-" + tone + "\"><header><span class=rule-icon>" + icon + "</span><div><span class=\"pill " + cwH(r.Category) + "\">" + cwH(r.Category) + "</span><h3>" + cwH(r.Name) + "</h3></div></header><div class=formula><span>规则条件</span><strong>" + cwH(r.Condition) + "</strong></div><dl><div><dt>事件数</dt><dd>" + strconv.Itoa(r.Events) + "</dd></div><div><dt>客户数</dt><dd>" + strconv.Itoa(r.Clients) + "</dd></div></dl><div class=mini-track><i><b style=\"width:" + fmt.Sprintf("%.1f", float64(r.Events)*100/float64(cwAnalyticsMax(1, x.Summary["alerts"]))) + "%\"></b></i><span>事件占比 " + share + "</span></div><div class=rule-facts><span><b>适用范围</b>" + func() string {
			if r.Overlap {
				return "可与其他类型重叠"
			}
			return "独立标签体系"
		}() + "</span><span><b>数据状态</b>" + cwH(r.Status) + "</span></div><details><summary>展开公式 / 窗口详情</summary><p>" + cwH(r.Details) + "</p></details></article>")
	}
	b.WriteString("</div><p class=note>预警类型可重叠；风险等级为独立标签体系。Top20 候选用于排序观察，不与正式风险事件混计。</p>")
	b.WriteString("<div class=charts>" + cwCountBars("ET / ST / THT", x.Program, x.Summary["alerts"], "未返回项目不按 0 解释。") + cwCountBars("Region（降序）", cwNamedCounts(x.Region, nil), x.Summary["alerts"], "分母为同筛选范围风险事件数。") + "</div>")
	if len(x.Top20Candidates) > 0 {
		b.WriteString("<details><summary>增幅 Top20 候选客户（与重点风险客户用途不同）</summary><div class=scroll><table><thead><tr><th>客户</th><th>Program / Tier / Region</th><th>CCR 增幅</th><th>P0 CCR</th><th>P0 NFS</th><th>比较窗口</th><th>正式事件</th></tr></thead><tbody>")
		for _, c := range x.Top20Candidates {
			formal := "否（候选）"
			if c.FormalEvent {
				formal = "是"
			}
			b.WriteString("<tr><td>" + cwH(c.Name) + "<small>" + cwH(c.ClientID) + "</small></td><td>" + cwH(c.Program+" / "+c.Tier+" / "+c.Region) + "</td><td>" + cwMetric(c.GrowthPct, 2) + "%</td><td>" + cwMetric(c.CCR, 2) + "</td><td>" + cwMetric(c.NFS, 0) + "</td><td>" + cwH(c.ComparisonWindow) + "</td><td>" + formal + "</td></tr>")
		}
		b.WriteString("</tbody></table></div></details>")
	}
	return b.String()
}

func cwPriorityHTML(x cwAnalytics) string {
	var b strings.Builder
	region, program := emptyFallback(x.Filters.Region, "全部 Region"), emptyFallback(x.Filters.Program, "全部 Program")
	if strings.EqualFold(region, "all") {
		region = "全部 Region"
	}
	if strings.EqualFold(program, "all") {
		program = "全部 Program"
	}
	submitter := emptyFallback(x.Filters.Submitter, "全部 Submitter")
	protection := strings.Join(uniqueNonEmpty([]string{x.Filters.ProtectionStartDate, x.Filters.ProtectionEndDate}), " 至 ")
	if protection == "" {
		protection = "全部保护开始时间"
	}
	b.WriteString("<section><h2>2. 重点风险客户 · Top10 + 全部极端客户 · " + cwH(region) + " · " + cwH(program) + " · " + cwH(submitter) + " · " + cwH(protection) + "</h2><p>" + cwH(x.Filters.Start+" 至 "+x.Filters.End) + " 周度预警事件集合；仅从当前共同筛选后的事件聚合，实际 " + strconv.Itoa(len(x.PriorityClients)) + " 条。极端客户超过 10 个时全部展示；不足 10 个时以观察客户补足且不伪造数据。排序与风险监控 combined 模式一致：极端优先、P0 CCR 降序、NULL 置后，再按稳定事件键排序。</p><div class=scroll><table><thead><tr><th>Account / Advertiser ID</th><th>Name</th><th>Program</th><th>Region</th><th>Nominator</th><th>Alert Severity</th><th>Alert Type / 事件数</th><th>P0 CCR</th><th>P0 NFS</th><th>Revenue</th><th>Case Status</th></tr></thead><tbody>")
	for _, c := range x.PriorityClients {
		provisional := ""
		if c.ProvisionalRank {
			provisional = "<small>暂定排名</small>"
		}
		name := emptyFallback(c.Name, "Not available")
		b.WriteString("<tr><td><a href=\"/?tab=risk&amp;alert_id=" + cwH(c.CaseID) + "\">" + cwH(c.ClientID) + "</a><small>" + cwH(c.Dimension) + "</small></td><td>" + cwH(name) + "</td><td>" + cwH(c.Program) + "</td><td>" + cwH(c.Region) + "</td><td>" + cwH(emptyFallback(c.Nominator, "—")) + "</td><td><span class=\"pill level\">" + cwH(c.Severity) + "</span></td><td>" + cwH(strings.Join(c.AlertTypes, " + ")) + "<small>" + strconv.Itoa(c.EventCount) + " 个事件</small></td><td>" + cwMetric(c.CCR, 2) + provisional + "</td><td>" + cwMetric(c.NFS, 0) + "</td><td>" + cwRevenue(c.Revenue) + "</td><td>" + cwH(c.CaseStatus) + "</td></tr>")
	}
	if len(x.PriorityClients) == 0 {
		b.WriteString("<tr><td colspan=11>当前筛选范围暂无重点风险客户</td></tr>")
	}
	b.WriteString("</tbody></table></div></section>")
	return b.String()
}

func cwQuotaSectionHTML(s cwQuotaAlertSection) string {
	var b strings.Builder
	b.WriteString("<section class=chapter><h2>6." + func() string {
		if s.Program == "ET" {
			return "1 "
		}
		return "2 "
	}() + cwH(s.Title) + "</h2><p><strong>口径：</strong>" + cwH(s.Methodology) + "；<strong>窗口：</strong>" + cwH(s.Window) + "。</p><div class=kpis><div><span>Used</span><strong>" + cwMetric(s.Used, 0) + "</strong><small>" + cwH(s.Unit) + " 去重</small></div><div><span>Quota</span><strong>" + cwMetric(s.Quota, 0) + "</strong></div><div><span>Usage Rate</span><strong>" + func() string {
		if s.UsageRate == nil {
			return "—"
		}
		return cwMetric(s.UsageRate, 1) + "%"
	}() + "</strong></div><div><span>超额 Region 数</span><strong>" + strconv.Itoa(s.ExceededRegions) + "</strong><small>100%=已满额；严格 &gt;100%=超额</small></div></div><div class=scroll><table><thead><tr><th>Region</th><th>Used</th><th>Quota</th><th>Usage Rate</th><th>Exceeded</th><th>Owner</th><th>Notification Status</th><th>Case Status</th></tr></thead><tbody>")
	for _, r := range s.Rows {
		rate := "—"
		if r.UsageRate != nil {
			rate = cwMetric(r.UsageRate, 1) + "% · " + r.Status
		}
		b.WriteString("<tr><td>" + cwH(r.Region) + "</td><td>" + cwMetric(r.Used, 0) + "</td><td>" + cwMetric(r.Quota, 0) + "</td><td>" + cwH(rate) + "</td><td>" + cwMetric(r.Exceeded, 0) + "</td><td>" + cwH(r.Owner) + "</td><td>" + cwH(r.NotificationStatus) + "</td><td>" + cwH(r.CaseStatus) + "</td></tr>")
	}
	b.WriteString("</tbody></table></div><p class=note>" + cwH(s.Note) + " 配额状态、事件关联、通知状态和处理状态分开展示。</p></section>")
	return b.String()
}

func cwQuotaAlertsHTML(x cwAnalytics) string {
	if x.Quota == nil {
		return "<section><h2>Quota Alerts</h2><div class=empty>Quota 数据不可用，未以 0 代替。</div></section>"
	}
	return cwQuotaSectionHTML(x.QuotaAlerts.ET) + cwQuotaSectionHTML(x.QuotaAlerts.ST)
}
