package main

import (
	"context"
	"fmt"
	"math"
	"net/http"
	"strings"
	"time"
)

const overviewAccountSource = "overview_account_tiers"

var overviewTierKeys = []string{"strategic_trust", "high_trust", "building_trust", "emerging_trust"}
var overviewTierLabels = []string{"ST", "HT", "BT", "ET"}
var overviewQueryReport = runTitanVQSProbe

type overviewAccountTier struct {
	Tier       string   `json:"tier"`
	SourceTier string   `json:"source_tier"`
	Count      *float64 `json:"account_count"`
	Share      *float64 `json:"account_share"`
}

type overviewAccounts struct {
	Status       string                `json:"status"`
	Reason       string                `json:"reason,omitempty"`
	RequestedEnd string                `json:"requested_end_date"`
	AsOf         string                `json:"data_as_of"`
	Region       string                `json:"region"`
	Total        *float64              `json:"tier_membership_total"`
	Rows         []overviewAccountTier `json:"rows"`
	QueriedAt    string                `json:"queried_at"`
	Attempts     int                   `json:"attempts"`
	Diagnostics  map[string]any        `json:"diagnostics"`
	Source       map[string]any        `json:"source"`
	SideEffects  bool                  `json:"side_effects"`
}

func overviewAccountSourceConfig() sourceConfig {
	return sourceConfig{Kind: "aggregate", Grain: "tier_snapshot", Enabled: true, AppID: 800414, SID: 1280034, RID: 2891943,
		Identity:            sourceIdentity{AppID: 800414, SID: 1280034, RID: 2891943, Region: "sg", QueryMode: "aggregate"},
		SupportedDimensions: []string{"date", "region", "client_tier"}, Fields: map[string]fieldConfig{
			"p_date":        {DimMetID: "10000002555291", UniqueID: "10000002555291", SourceName: "p_date", ExpectedType: "date"},
			"region":        {DimMetID: "10000016013590", UniqueID: "10000016013590", SourceName: "Sales region-8.6"},
			"client_tier":   {DimMetID: "10000012645665", UniqueID: "10000012645665", SourceName: "tier_v3_name"},
			"account_count": {SourceName: "TAP Accounts", ExpectedType: "number"},
		}}
}

func overviewEmptyAccounts(end, region string) overviewAccounts {
	o := overviewAccounts{Status: "unavailable", RequestedEnd: end, Region: region, QueriedAt: time.Now().UTC().Format(time.RFC3339), Rows: []overviewAccountTier{}, Diagnostics: map[string]any{}, Source: map[string]any{"rid": 2891943, "sid": 1280034, "app_id": 800414, "grain": "tier_snapshot", "time_semantics": "latest_nonempty_snapshot_within_14_days"}}
	for i := range overviewTierKeys {
		o.Rows = append(o.Rows, overviewAccountTier{Tier: overviewTierLabels[i], SourceTier: overviewTierKeys[i]})
	}
	return o
}

func overviewParseAccounts(o overviewAccounts, rows []map[string]any) overviewAccounts {
	seen, valid, excludedStandardTrust := map[string]bool{}, true, false
	for _, row := range rows {
		key := strings.ToLower(strings.TrimSpace(asString(row["client_tier"])))
		idx := -1
		for i, tier := range overviewTierKeys {
			if key == tier {
				idx = i
				break
			}
		}
		if idx < 0 {
			if key == "standard_trust" {
				excludedStandardTrust = true
				continue
			}
			valid = false
			continue
		}
		value, ok := number(row["account_count"])
		if seen[key] || !ok || value < 0 || math.Trunc(value) != value || math.IsNaN(value) || math.IsInf(value, 0) {
			valid = false
			continue
		}
		seen[key], o.Rows[idx].Count = true, &value
	}
	if !valid || len(seen) != 4 {
		o.Status, o.Reason = "partial", "Tier 快照缺失、重复或数值无效；未补零，未计算占比。"
		return o
	}
	total := 0.0
	for _, row := range o.Rows {
		total += *row.Count
	}
	o.Total, o.Status = &total, "available"
	if total == 0 {
		o.Reason = "源端四个 Tier 均为真实 0；占比不适用。"
		return o
	}
	for i := range o.Rows {
		share := *o.Rows[i].Count / total * 100
		o.Rows[i].Share = &share
	}
	if excludedStandardTrust {
		o.Reason = "源快照包含异常巨大 standard_trust；四 Tier 总数与占比已明确排除该行。"
	}
	return o
}

func overviewLoadAccounts(ctx context.Context, request *http.Request, end, region string) overviewAccounts {
	o := overviewEmptyAccounts(end, region)
	day, _ := time.Parse("2006-01-02", end)
	for offset := 0; offset < 14; offset++ {
		date := day.AddDate(0, 0, -offset).Format("2006-01-02")
		r := request.Clone(ctx)
		u := *r.URL
		q := u.Query()
		for key := range q {
			q.Del(key)
		}
		q.Set("start_date", date)
		q.Set("end_date", date)
		if region != "Global" {
			q.Set("region", region)
		}
		u.RawQuery = q.Encode()
		r.URL = &u
		r.Form, r.PostForm = nil, nil
		probe, err := overviewQueryReport(ctx, r, overviewAccountSource)
		o.Attempts++
		if err != nil {
			o.Reason = "风神查询未完成。"
			logMsg(fmt.Sprintf("overview_accounts error=%s", sanitizeAuditText(err.Error())), "plugin")
			return o
		}
		o.Diagnostics = map[string]any{"audit_id": probe["audit_id"], "request_id": probe["requestId"], "status": probe["status"], "columns": probe["columns"], "queried_date": date}
		if asString(probe["status"]) != "ok" {
			o.Reason = "风神鉴权、固定过滤或字段合同未通过。"
			return o
		}
		if asBool(probe["possibly_truncated"]) {
			o.Reason = "源结果可能截断，未生成汇总。"
			return o
		}
		rows, ok := probe["business_rows"].([]map[string]any)
		if !ok {
			o.Reason = "源结果结构不符合合同。"
			return o
		}
		if len(rows) == 0 {
			continue
		}
		o.AsOf = date
		return overviewParseAccounts(o, rows)
	}
	o.Status, o.Reason = "no_data", "截止日及此前 13 天没有账户快照；未使用未来数据或补零。"
	return o
}

func overviewAccountsHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	end := strings.TrimSpace(r.URL.Query().Get("end_date"))
	if end == "" {
		end = time.Now().In(cwLocation()).Format("2006-01-02")
	}
	date, err := time.Parse("2006-01-02", end)
	if err != nil || date.Format("2006-01-02") != end || end > time.Now().In(cwLocation()).Format("2006-01-02") {
		writeJSON(w, 400, map[string]any{"error": "截止日期必须为不晚于今天的 YYYY-MM-DD"})
		return
	}
	region := overviewNormalizeRegion(r.URL.Query().Get("region"))
	if !overviewAllowedRegion(region) {
		writeJSON(w, 400, map[string]any{"error": "Region 不在已声明范围"})
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()
	writeJSON(w, 200, map[string]any{"data": overviewLoadAccounts(ctx, r, end, region)})
}
