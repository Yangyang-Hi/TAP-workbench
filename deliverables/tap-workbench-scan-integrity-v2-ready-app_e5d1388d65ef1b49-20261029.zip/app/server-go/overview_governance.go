package main

import (
	"context"
	"net/http"
	"sort"
	"strings"
	"time"
)

type overviewSubmitter struct {
	Submitter   string   `json:"submitter"`
	Total       int      `json:"total"`
	Pending     int      `json:"pending"`
	Progress    int      `json:"in_progress"`
	Closed      int      `json:"closed"`
	Unknown     int      `json:"unknown"`
	Notified    *int     `json:"notified_cases"`
	ClosureRate *float64 `json:"closure_rate"`
}

func overviewFormalSubmitterNotice(a cwCase, n cwNotice) bool {
	if n.CaseID != a.ID || n.Kind != "send" || n.Status != "sent" || n.MessageID == "" || n.NotificationMode != "formal" {
		return false
	}
	email, who := strings.ToLower(strings.TrimSpace(n.TargetEmail)), strings.ToLower(strings.TrimSpace(a.Row.Member.Submitter))
	return email != "" && who != "" && (who == email || (!strings.Contains(who, "@") && who == strings.SplitN(email, "@", 2)[0]))
}
func overviewCaseInScope(a cwCase, f overviewFilter, program, submitter string) bool {
	return a.Kind != "quota" && a.Window.Start != "" && a.Window.End != "" && a.Window.Start <= f.End && a.Window.End >= f.Start && (f.Region == "Global" || a.Row.Member.Region == f.Region) && (program == "" || strings.EqualFold(a.Row.Program, program)) && (submitter == "" || a.Row.Member.Submitter == submitter)
}

func overviewGovernanceData(cases []cwCase, notices []cwNotice, jobsByBatch map[string][]wbJob, f overviewFilter, program, submitter string, noticesOK bool) map[string]any {
	latestCases := map[string]cwCase{}
	for _, a := range cases {
		if old, ok := latestCases[a.ID]; !ok || a.Version > old.Version {
			latestCases[a.ID] = a
		}
	}
	noticeByCase := map[string][]cwNotice{}
	for _, n := range notices {
		noticeByCase[n.CaseID] = append(noticeByCase[n.CaseID], n)
	}
	byProgram, byRegion, byLevel := map[string]int{}, map[string]int{}, map[string]int{}
	states := map[string]int{"pending": 0, "in_progress": 0, "closed": 0, "unknown": 0}
	people := map[string]*overviewSubmitter{}
	total := 0
	latestUpdate := ""
	for _, a := range latestCases {
		if !overviewCaseInScope(a, f, program, submitter) {
			continue
		}
		total++
		byProgram[a.Row.Program]++
		region := a.Row.Member.Region
		if region == "" {
			region = "未映射"
		}
		byRegion[region]++
		if a.UpdatedAt > latestUpdate {
			latestUpdate = a.UpdatedAt
		}
		name := strings.TrimSpace(a.Row.Member.Submitter)
		if name == "" {
			name = "未映射"
		}
		row := people[name]
		if row == nil {
			row = &overviewSubmitter{Submitter: name}
			if noticesOK {
				zero := 0
				row.Notified = &zero
			}
			people[name] = row
		}
		row.Total++
		switch a.Status {
		case "closed":
			states["closed"]++
			row.Closed++
		case "open":
			states["pending"]++
			row.Pending++
		case "processing", "observing", "pending_approval", "pending_review":
			states["in_progress"]++
			row.Progress++
		default:
			states["unknown"]++
			row.Unknown++
		}
		if noticesOK && row.Notified != nil {
			bound, uncertain := false, false
			for _, n := range noticeByCase[a.ID] {
				if overviewFormalSubmitterNotice(a, n) {
					bound = true
				} else if n.Kind == "send" && n.Status == "sent" && n.MessageID != "" && n.NotificationMode == "formal" {
					uncertain = true
				}
			}
			if bound {
				*row.Notified++
			} else if uncertain {
				row.Notified = nil
			}
		}
	}
	submitters := []overviewSubmitter{}
	for _, row := range people {
		if row.Total > 0 {
			rate := float64(row.Closed) * 100 / float64(row.Total)
			row.ClosureRate = &rate
		}
		submitters = append(submitters, *row)
	}
	sort.Slice(submitters, func(i, j int) bool { return submitters[i].Submitter < submitters[j].Submitter })

	coverage := map[string]string{"ET": "not_scanned", "ST": "not_scanned", "THT": "not_scanned"}
	evaluated, riskSubjects := map[string]bool{}, map[string]bool{}
	top20 := map[string]bool{}
	latestBatches := []string{}
	batchWindows := []map[string]any{}
	selected := map[string][]wbJob{}
	for batch, jobs := range jobsByBatch {
		for _, job := range jobs {
			if job.Request.Start == "" || job.Request.Start > f.End || job.Request.End < f.Start || (program != "" && !strings.EqualFold(job.Request.Program, program)) {
				continue
			}
			selected[batch] = append(selected[batch], job)
		}
	}
	for batch, jobs := range selected {
		latestBatches = append(latestBatches, batch)
		for _, job := range jobs {
			p := strings.ToUpper(job.Request.Program)
			state := "partial"
			if job.Complete && (job.Status == "ready" || job.Status == "available") {
				state = "complete"
			}
			if coverage[p] != "partial" {
				coverage[p] = state
			}
			policy := wbDefaultPolicy()
			if len(job.Policy.Rules) > 0 {
				policy = job.Policy
			}
			all := []wbReadRow{}
			jobEvaluated := map[string]bool{}
			jobRisk := map[string]bool{}
			for _, row := range job.Rows {
				if f.Region != "Global" && row.Member.Region != f.Region || submitter != "" && row.Member.Submitter != submitter {
					continue
				}
				view := wbToReadRow(job, row, nil, nil, time.Now())
				all = append(all, view)
				key := wbReadCustomerKey(view)
				evaluated[key] = true
				jobEvaluated[key] = true
			}
			for _, risk := range wbRiskList(all, "combined", policy) {
				key := wbReadCustomerKey(risk)
				riskSubjects[key] = true
				jobRisk[key] = true
				byLevel[risk.RiskLevel]++
				for _, reason := range risk.RiskReasons {
					if strings.Contains(strings.ToLower(reason), "top20") {
						top20[key] = true
					}
				}
			}
			batchWindows = append(batchWindows, map[string]any{"batch_id": batch, "program": p, "start_date": job.Request.Start, "end_date": job.Request.End, "coverage": state, "evaluated_subjects": len(jobEvaluated), "risk_subjects": len(jobRisk)})
		}
	}
	sort.Strings(latestBatches)
	sort.Slice(batchWindows, func(i, j int) bool {
		return asString(batchWindows[i]["start_date"])+asString(batchWindows[i]["program"]) < asString(batchWindows[j]["start_date"])+asString(batchWindows[j]["program"])
	})
	complete := len(batchWindows) > 0
	for name, status := range coverage {
		if (program == "" || program == name) && status != "complete" {
			complete = false
		}
	}
	var share any
	if len(evaluated) > 0 && complete {
		share = float64(len(riskSubjects)) * 100 / float64(len(evaluated))
	}
	coverageStatus := "partial"
	if len(batchWindows) == 0 {
		coverageStatus = "no_saved_batches"
	} else if complete {
		coverageStatus = "complete"
	}
	return map[string]any{"status": "available", "window": f, "alert_events": total, "by_program": byProgram, "by_region": byRegion, "by_level": byLevel, "states": states, "submitters": submitters, "updated_at": latestUpdate, "evaluated_subjects": len(evaluated), "risk_subjects": len(riskSubjects), "risk_share": share, "risk_share_scope": map[bool]string{true: "complete_saved_range", false: "partial_saved_range"}[complete], "coverage": coverage, "coverage_status": coverageStatus, "coverage_note": "仅覆盖下列已保存扫描批次及其已评估主体；partial/no_saved_batches 不代表完整总体", "batch_windows": batchWindows, "source_batches": latestBatches, "top20_subjects": len(top20), "risk_basis": "每个合并批次使用当前后端权威 wbRiskList；包括 ST 拆分；主体按 Program+Account/Advertiser 去重；不从分页 rows 或旧 row.Level 单独推断", "notification_binding": "仅正式 sent 且有 message_id 并可核实原提报人绑定", "side_effects": false}
}

func overviewGovernanceHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	f, err := overviewParseWindow(r.URL.Query())
	if err != nil {
		writeJSON(w, 400, map[string]any{"error": err.Error()})
		return
	}
	program := strings.ToUpper(strings.TrimSpace(r.URL.Query().Get("program")))
	if program != "" && !containsString([]string{"ET", "ST", "THT"}, program) {
		writeJSON(w, 400, map[string]any{"error": "Program 必须为 ET、ST 或 THT"})
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 45*time.Second)
	defer cancel()
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		writeJSON(w, 503, map[string]any{"error": "权威 Cloud casework repository 不可用"})
		return
	}
	cases, err := repo.listCases(ctx)
	if err != nil {
		cwWriteError(w, err)
		return
	}
	config, err := cwLoadConfig()
	if err != nil {
		cwWriteError(w, err)
		return
	}
	authorized := []cwCase{}
	for _, a := range cases {
		if cwCanRead(config, a, requestUsername(r)) {
			authorized = append(authorized, a)
		}
	}
	notices, noticeErr := repo.listNotices(ctx)
	_, jobsByBatch, scanErr := wbPersistedBatches()
	if scanErr != nil {
		jobsByBatch = map[string][]wbJob{}
	}
	data := overviewGovernanceData(authorized, notices, jobsByBatch, f, program, strings.TrimSpace(r.URL.Query().Get("submitter")), noticeErr == nil)
	data["source_status"] = map[string]bool{"cases": true, "notices": noticeErr == nil, "saved_batches": scanErr == nil}
	if noticeErr != nil || scanErr != nil {
		data["status"] = "partial"
		data["reason"] = "事件已返回；通知或已保存批次读取不完整"
	}
	writeJSON(w, 200, map[string]any{"data": data})
}
