package main

import (
	"bytes"
	"compress/gzip"
	"context"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"
)

// cloudCaseworkRepository is the authoritative, cross-instance casework store.
// Schema is provisioned out-of-band; runtime code never performs DDL and never
// falls back to SQLite when Cloud DB is unavailable.
type cloudCaseworkRepository struct{ db *cloudStore }

func newCloudCaseworkRepository() (*cloudCaseworkRepository, error) {
	if configuredMode != "cloud" {
		return nil, errors.New("casework requires cloud store mode")
	}
	db, err := newSharedCloudStore()
	if err != nil {
		return nil, fmt.Errorf("casework cloud initialization: %w", err)
	}
	return &cloudCaseworkRepository{db: db}, nil
}

func cwCloudRepo() (*cloudCaseworkRepository, error) { return newCloudCaseworkRepository() }

func (r *cloudCaseworkRepository) query(ctx context.Context, table string, body map[string]any) ([]map[string]any, error) {
	resp, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/"+table+"/query", body)
	if err != nil {
		return nil, err
	}
	data, _ := resp["data"].(map[string]any)
	raw, _ := data["records"].([]any)
	out := make([]map[string]any, 0, len(raw))
	for _, item := range raw {
		if row, ok := toMap(item); ok {
			out = append(out, row)
		}
	}
	return out, nil
}

func (r *cloudCaseworkRepository) listCases(ctx context.Context) ([]cwCase, error) {
	const pageSize = 500
	out := []cwCase{}
	for offset := 0; ; offset += pageSize {
		rows, err := r.query(ctx, "tap_cases", map[string]any{
			"sort":  []any{map[string]any{"field": "updated_at", "direction": "desc"}},
			"limit": pageSize, "offset": offset,
		})
		if err != nil {
			return nil, err
		}
		for _, row := range rows {
			a, err := cloudCaseFromRecord(row)
			if err != nil {
				return nil, err
			}
			out = append(out, a)
		}
		if len(rows) < pageSize {
			break
		}
	}
	return out, nil
}

func (r *cloudCaseworkRepository) caseByID(ctx context.Context, id string) (cwCase, error) {
	var out cwCase
	rows, err := r.query(ctx, "tap_cases", map[string]any{"filters": []any{map[string]any{"field": "case_id", "operator": "eq", "value": id}}, "limit": 1, "offset": 0})
	if err != nil {
		return out, err
	}
	if len(rows) == 0 {
		return out, sql.ErrNoRows
	}
	return cloudCaseFromRecord(rows[0])
}

func cloudCaseFromRecord(row map[string]any) (cwCase, error) {
	var out cwCase
	body, ok := row["body"]
	if !ok {
		return out, errors.New("cloud case body missing")
	}
	if envelope, isMap := body.(map[string]any); isMap && asString(envelope["encoding"]) == "gzip+base64" {
		compressed, decodeErr := base64.StdEncoding.DecodeString(asString(envelope["data"]))
		if decodeErr != nil {
			return out, decodeErr
		}
		reader, gzipErr := gzip.NewReader(bytes.NewReader(compressed))
		if gzipErr != nil {
			return out, gzipErr
		}
		defer reader.Close()
		if err := json.NewDecoder(reader).Decode(&out); err != nil {
			return out, err
		}
	} else {
		payload, marshalErr := json.Marshal(body)
		if marshalErr != nil {
			return out, marshalErr
		}
		if err := json.Unmarshal(payload, &out); err != nil {
			return out, err
		}
	}
	if out.ID != asString(row["case_id"]) || out.Version != int(asInt64(row["version"])) {
		return out, errors.New("cloud case integrity mismatch")
	}
	return out, nil
}

func cloudCaseRecord(a cwCase) map[string]any {
	body := any(a)
	if raw, err := json.Marshal(a); err == nil && len(raw) > 256<<10 {
		var compressed bytes.Buffer
		zw := gzip.NewWriter(&compressed)
		if _, err = zw.Write(raw); err == nil {
			err = zw.Close()
		}
		if err == nil {
			body = map[string]any{"encoding": "gzip+base64", "data": base64.StdEncoding.EncodeToString(compressed.Bytes())}
		}
	}
	return map[string]any{"case_id": a.ID, "version": a.Version, "status": a.Status, "kind": a.Kind, "owner": a.Owner, "creator": a.Creator, "scan_id": a.ScanID, "updated_at": a.UpdatedAt, "body": body}
}

func (r *cloudCaseworkRepository) upsertCase(ctx context.Context, a cwCase) error {
	_, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_cases/records/upsert", map[string]any{"conflict_fields": []string{"case_id"}, "data": cloudCaseRecord(a), "update_fields": []string{"version", "status", "kind", "owner", "creator", "scan_id", "updated_at", "body"}})
	return err
}

func (r *cloudCaseworkRepository) createCase(ctx context.Context, a cwCase) (cwCase, error) {
	_, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_cases/records/upsert", map[string]any{"conflict_fields": []string{"case_id"}, "data": cloudCaseRecord(a), "update_fields": []string{}})
	if err != nil && !strings.Contains(err.Error(), "409") {
		return cwCase{}, err
	}
	return r.caseByID(ctx, a.ID)
}

// saveCaseCAS uses Cloud DB's conditional update as optimistic locking. Exactly
// one row must match case_id+previous version; otherwise the caller receives 409.
func (r *cloudCaseworkRepository) saveCaseCAS(ctx context.Context, a cwCase, previous int) error {
	body := map[string]any{"filter": map[string]any{"logic": "and", "conditions": []any{map[string]any{"field": "case_id", "operator": "eq", "value": a.ID}, map[string]any{"field": "version", "operator": "eq", "value": previous}}}, "data": cloudCaseRecord(a), "limit": 1}
	resp, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_cases/records/update", body)
	if err != nil {
		return err
	}
	data, _ := resp["data"].(map[string]any)
	if asInt64(data["updated_count"]) != 1 {
		return cwErr(409, "记录已更新，请刷新后重试")
	}
	return nil
}

func (r *cloudCaseworkRepository) command(ctx context.Context, caseID, requestID string) (string, bool, error) {
	rows, err := r.query(ctx, "tap_commands", map[string]any{"filters": []any{map[string]any{"field": "case_id", "operator": "eq", "value": caseID}, map[string]any{"field": "request_id", "operator": "eq", "value": requestID}}, "limit": 1})
	if err != nil {
		return "", false, err
	}
	if len(rows) == 0 {
		return "", false, nil
	}
	return asString(rows[0]["fingerprint"]), true, nil
}
func (r *cloudCaseworkRepository) putCommand(ctx context.Context, caseID, requestID, fingerprint string, version int) error {
	_, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_commands/records/upsert", map[string]any{"conflict_fields": []string{"case_id", "request_id"}, "data": map[string]any{"case_id": caseID, "request_id": requestID, "fingerprint": fingerprint, "result_version": version, "created_at": cwNow()}, "update_fields": []string{}})
	return err
}

func cloudNoticeFromRecord(row map[string]any) (cwNotice, bool) {
	b, err := json.Marshal(row["body"])
	if err != nil {
		return cwNotice{}, false
	}
	var n cwNotice
	if json.Unmarshal(b, &n) != nil {
		return cwNotice{}, false
	}
	// Delivery identity is intentionally omitted from the public notice JSON,
	// but the authoritative outbox keeps it in protected top-level columns.
	// Hydrate it only for server-side recipient revalidation/cache lookups.
	n.BotFingerprint = asString(row["bot_fingerprint"])
	n.TargetEmail = strings.ToLower(strings.TrimSpace(asString(row["target_email"])))
	n.ResolvedOpenID = strings.TrimSpace(asString(row["resolved_open_id"]))
	return n, true
}

func (r *cloudCaseworkRepository) listNotices(ctx context.Context) ([]cwNotice, error) {
	const pageSize = 500
	out := []cwNotice{}
	for offset := 0; ; offset += pageSize {
		rows, err := r.query(ctx, "tap_outbox", map[string]any{
			"sort":  []any{map[string]any{"field": "updated_at", "direction": "desc"}},
			"limit": pageSize, "offset": offset,
		})
		if err != nil {
			return nil, err
		}
		for _, row := range rows {
			if n, ok := cloudNoticeFromRecord(row); ok {
				out = append(out, n)
			}
		}
		if len(rows) < pageSize {
			break
		}
	}
	return out, nil
}

func (r *cloudCaseworkRepository) notices(ctx context.Context, caseID string) ([]cwNotice, error) {
	rows, err := r.query(ctx, "tap_outbox", map[string]any{"filters": []any{map[string]any{"field": "case_id", "operator": "eq", "value": caseID}}, "sort": []any{map[string]any{"field": "updated_at", "direction": "desc"}}, "limit": 500})
	if err != nil {
		return nil, err
	}
	out := make([]cwNotice, 0, len(rows))
	for _, row := range rows {
		if n, ok := cloudNoticeFromRecord(row); ok {
			out = append(out, n)
		}
	}
	return out, nil
}

func cwCloudGet(ctx context.Context, id string) (cwCase, error) {
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		return cwCase{}, err
	}
	return repo.caseByID(ctx, id)
}
func cwCloudNotices(ctx context.Context, id string) ([]cwNotice, error) {
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		return nil, err
	}
	return repo.notices(ctx, id)
}

// cwMirrorCloudCaseToLocal exists only as a compatibility bridge while legacy
// notification rendering is removed. It never reads local data as authority.
func cwMirrorCloudCaseToLocal(ctx context.Context, db *sql.DB, id string) (cwCase, error) {
	a, err := cwCloudGet(ctx, id)
	if err != nil {
		return a, err
	}
	b, _ := json.Marshal(a)
	_, err = db.Exec("INSERT INTO tap_cases(id,version,body) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET version=excluded.version,body=excluded.body", a.ID, a.Version, string(b))
	return a, err
}

func (r *cloudCaseworkRepository) upsertNotice(ctx context.Context, n cwNotice, idempotency string, nextAt int64) error {
	body := map[string]any{"conflict_fields": []string{"outbox_id"}, "data": map[string]any{"outbox_id": n.ID, "case_id": n.CaseID, "idempotency_key": idempotency, "kind": n.Kind, "status": n.Status, "recipient": n.Recipient, "message_id": n.MessageID, "attempts": n.Attempts, "next_at": nextAt, "updated_at": n.UpdatedAt, "body": n}, "update_fields": []string{"status", "recipient", "message_id", "attempts", "next_at", "updated_at", "body"}}
	_, err := r.db.doJSON(ctx, http.MethodPost, cloudDBAPIPrefix+"/tables/tap_outbox/records/upsert", body)
	return err
}

func cwCloudContext() (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.Background(), 10*time.Second)
}

func cwSyncNoticeFromLocal(ctx context.Context, db *sql.DB, id string) error {
	var n cwNotice
	var nextAt int64
	var idem string
	err := db.QueryRow("SELECT id,case_id,recipient,kind,status,message_id,attempts,error,created_at,updated_at,notification_mode,bot_fingerprint,mapping_version,mapping_revision,target_email,resolved_open_id,source,mode,batch_id,rule_version,result,next_at,idempotency_key FROM tap_outbox WHERE id=?", id).Scan(&n.ID, &n.CaseID, &n.Recipient, &n.Kind, &n.Status, &n.MessageID, &n.Attempts, &n.Error, &n.CreatedAt, &n.UpdatedAt, &n.NotificationMode, &n.BotFingerprint, &n.MappingVersion, &n.MappingRevision, &n.TargetEmail, &n.ResolvedOpenID, &n.Source, &n.Mode, &n.BatchID, &n.RuleVersion, &n.Result, &nextAt, &idem)
	if err != nil {
		return err
	}
	if idem == "" {
		idem = "legacy:" + n.ID
	}
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		return err
	}
	return repo.upsertNotice(ctx, n, idem, nextAt)
}

func (r *cloudCaseworkRepository) queueUpdates(ctx context.Context, a cwCase) error {
	notices, err := r.notices(ctx, a.ID)
	if err != nil {
		return err
	}
	for _, sent := range notices {
		if sent.Kind != "send" || sent.Status != "sent" || strings.TrimSpace(sent.MessageID) == "" {
			continue
		}
		id := wbKey([]string{"update", a.ID, sent.MessageID, fmt.Sprint(a.Version)})
		n := cwNotice{ID: id, CaseID: a.ID, Recipient: sent.Recipient, Kind: "update", Status: "pending", MessageID: sent.MessageID, NotificationMode: sent.NotificationMode, BotFingerprint: sent.BotFingerprint, Source: sent.Source, Mode: sent.Mode, CreatedAt: cwNow(), UpdatedAt: cwNow()}
		if err = r.upsertNotice(ctx, n, "update:"+id, 0); err != nil {
			return err
		}
	}
	return nil
}
