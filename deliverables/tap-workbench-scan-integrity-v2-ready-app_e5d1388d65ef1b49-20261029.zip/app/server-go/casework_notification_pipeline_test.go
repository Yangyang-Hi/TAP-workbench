package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
)

type cloudOnlyCaseworkRepository struct {
	caseworkRepository
	caseRecord    cwCase
	noticeRecords []cwNotice
}

func (r cloudOnlyCaseworkRepository) caseByID(_ context.Context, id string) (cwCase, error) {
	if id != r.caseRecord.ID {
		return cwCase{}, errors.New("unexpected case id")
	}
	return r.caseRecord, nil
}

func (r cloudOnlyCaseworkRepository) notices(_ context.Context, caseID string) ([]cwNotice, error) {
	out := []cwNotice{}
	for _, notice := range r.noticeRecords {
		if notice.CaseID == caseID {
			out = append(out, notice)
		}
	}
	return out, nil
}

func (r cloudOnlyCaseworkRepository) listNotices(context.Context) ([]cwNotice, error) {
	return append([]cwNotice(nil), r.noticeRecords...), nil
}

func TestNotificationPreviewMirrorsCloudOnlyCase(t *testing.T) {
	a, _ := cwFixture(t)
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	if _, err = db.Exec("DELETE FROM tap_cases WHERE id=?", a.ID); err != nil {
		t.Fatal(err)
	}
	db.Close()

	cwCaseworkRepositoryProvider = func() (caseworkRepository, error) {
		return cloudOnlyCaseworkRepository{caseworkRepository: localCaseworkRepository{}, caseRecord: a}, nil
	}
	request := cwTestRequest("owner", `{"recipient_id":"ou_owner"}`)
	request.SetPathValue("id", a.ID)
	response := httptest.NewRecorder()
	cwNotificationPreviewHandler(response, request)
	if response.Code != http.StatusOK {
		t.Fatalf("cloud-only preview failed: code=%d body=%s", response.Code, response.Body.String())
	}

	db, err = cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	mirrored, err := cwRead(db, a.ID)
	if err != nil || mirrored.ID != a.ID || mirrored.Version != a.Version {
		t.Fatalf("cloud case was not mirrored locally: case=%+v err=%v", mirrored, err)
	}
}

func TestNotificationPreviewRejectsInaccessibleCloudOnlyCase(t *testing.T) {
	a, _ := cwFixture(t)
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	if _, err = db.Exec("DELETE FROM tap_cases WHERE id=?", a.ID); err != nil {
		t.Fatal(err)
	}
	db.Close()

	cwCaseworkRepositoryProvider = func() (caseworkRepository, error) {
		return cloudOnlyCaseworkRepository{caseworkRepository: localCaseworkRepository{}, caseRecord: a}, nil
	}
	request := httptest.NewRequest(http.MethodPost, "/api/workbench/cases/"+a.ID+"/notification-preview", strings.NewReader(`{"recipient_id":"ou_owner"}`))
	request.SetPathValue("id", a.ID)
	response := httptest.NewRecorder()
	cwNotificationPreviewHandler(response, request)
	if response.Code != http.StatusForbidden {
		t.Fatalf("inaccessible cloud case was not rejected: code=%d body=%s", response.Code, response.Body.String())
	}
}

// No network leaves this process. This exercises the production Sheet reader,
// current-Bot email resolver, preview, enqueue and sender against a local server.
func TestMappingNotificationHTTPPipeline(t *testing.T) {
	a, _ := cwFixture(t)
	// Begin at the same completed absolute-value scan → shared Alert API as the UI.
	job := wbJob{ID: a.ScanID, Principal: "operator", Status: "ready", Request: a.Window, Rule: a.Rule, Rows: []wbRow{a.Row}}
	if err := wbSaveJob(&job); err != nil {
		t.Fatal(err)
	}
	create := cwTestRequest("operator", fmt.Sprintf(`{"scan_id":%q,"row_id":%q}`, job.ID, a.Row.ID))
	created := httptest.NewRecorder()
	cwCreateHandler(created, create)
	if created.Code != 200 || !strings.Contains(created.Body.String(), a.ID) {
		t.Fatal("scan → Alert failed:", created.Body.String())
	}
	oldFetch, oldResolve, oldBase, oldClient := cwFetchMappingSheet, cwResolveBotOpenID, cwAPIBaseForRequest, cwHTTPClient
	defer func() {
		cwFetchMappingSheet = oldFetch
		cwResolveBotOpenID = oldResolve
		cwAPIBaseForRequest = oldBase
		cwHTTPClient = oldClient
		cwTokenValue = ""
	}()
	cwFetchMappingSheet = cwFetchMappingSheetLive
	cwResolveBotOpenID = cwResolveOpenID
	cwTokenValue = ""
	sends, reads, resolves := 0, 0, 0
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch {
		case strings.Contains(r.URL.Path, "tenant_access_token"):
			fmt.Fprint(w, `{"code":0,"tenant_access_token":"local-fixture-token","expire":7200}`)
		case strings.HasSuffix(r.URL.Path, "/sheets/query"):
			fmt.Fprintf(w, `{"code":0,"data":{"sheets":[{"sheet_id":%q,"grid_properties":{"row_count":1100}}]}}`, cwMappingSheetID)
		case strings.Contains(r.URL.Path, "/values/"):
			reads++
			values := [][]string{}
			if strings.HasSuffix(r.URL.Path, "A1:G1000") {
				values = [][]string{mappingHeader}
			} else if strings.HasSuffix(r.URL.Path, "A1001:G1100") {
				// The relevant name is beyond the old 105-row boundary.
				values = [][]string{{"APAC", "owner", "owner@example.com", "Owner", "已确认", "HTTP fixture", "2026-10-21"}}
			} else {
				t.Errorf("unexpected read range %s", r.URL.Path)
			}
			json.NewEncoder(w).Encode(map[string]any{"code": 0, "data": map[string]any{"revision": 42, "valueRange": map[string]any{"values": values}}})
		case strings.HasSuffix(r.URL.Path, "/batch_get_id"):
			resolves++
			var body struct {
				Emails []string `json:"emails"`
			}
			json.NewDecoder(r.Body).Decode(&body)
			if len(body.Emails) != 1 || body.Emails[0] != "owner@example.com" || r.URL.Query().Get("user_id_type") != "open_id" {
				t.Errorf("wrong lookup %+v", body)
			}
			fmt.Fprint(w, `{"code":0,"data":{"user_list":[{"email":"owner@example.com","user_id":"ou_formal_fixture"}]}}`)
		case r.URL.Path == "/open-apis/im/v1/messages":
			sends++
			var body map[string]any
			json.NewDecoder(r.Body).Decode(&body)
			if body["receive_id"] != "ou_owner" || strings.Contains(asString(body["content"]), "local-fixture-token") || !strings.Contains(asString(body["content"]), "alert_id") {
				t.Errorf("wrong target or content: %+v", body)
			}
			if r.URL.Query().Get("receive_id_type") != "open_id" {
				t.Error("wrong ID domain")
			}
			fmt.Fprint(w, `{"code":0,"data":{"message_id":"om_pipeline_fixture"}}`)
		default:
			t.Errorf("unexpected request %s", r.URL.Path)
			http.Error(w, "unexpected", 500)
		}
	}))
	defer server.Close()
	cwAPIBaseForRequest = func() string { return server.URL }
	cwHTTPClient = server.Client()
	body := testConfirmedNotificationBody(t, a, "owner", "ou_owner")
	if sends != 0 {
		t.Fatal("preview sent a message")
	}
	enqueue := func() int {
		r := cwTestRequest("owner", body)
		r.SetPathValue("id", a.ID)
		w := httptest.NewRecorder()
		cwNotifyHandler(w, r)
		if w.Code != 202 {
			t.Log(w.Body.String())
		}
		return w.Code
	}
	if enqueue() != 202 || enqueue() != 202 {
		t.Fatal("enqueue or idempotent repeat failed")
	}
	cwProcessOutbox()
	cwProcessOutbox()
	if sends != 1 || resolves != 0 || reads != 2 {
		t.Fatalf("sends=%d resolves=%d sheet reads=%d", sends, resolves, reads)
	}
	db, _ := cwDB()
	defer db.Close()
	var status, message, email, resolved, target, revision, version, mode, source, persistedMode, result, ruleVersion string
	if err := db.QueryRow("SELECT status,message_id,target_email,resolved_open_id,actual_target,mapping_revision,mapping_version,notification_mode,source,mode,result,rule_version FROM tap_outbox WHERE case_id=? AND kind='send'", a.ID).Scan(&status, &message, &email, &resolved, &target, &revision, &version, &mode, &source, &persistedMode, &result, &ruleVersion); err != nil {
		t.Fatal(err)
	}
	if status != "sent" || message != "om_pipeline_fixture" || email != "owner@example.com" || resolved != "" || target != "open_id:ou_owner" || revision != "42" || version == "" || mode != "test" || source != "manual" || persistedMode != "test" || result != "sent" || ruleVersion != a.Rule.Version {
		t.Fatalf("audit mismatch status=%s message=%s source=%s mode=%s result=%s rule=%s", status, message, source, persistedMode, result, ruleVersion)
	}
}

func TestQueuedTestCannotBecomeFormal(t *testing.T) {
	a, _ := cwFixture(t)
	body := testConfirmedNotificationBody(t, a, "owner", "ou_owner")
	r := cwTestRequest("owner", body)
	r.SetPathValue("id", a.ID)
	w := httptest.NewRecorder()
	cwNotifyHandler(w, r)
	if w.Code != 202 {
		t.Fatal(w.Body.String())
	}
	configureCasework(t, func(c *cwConfig) { c.NotificationMode = "formal"; c.AutoSendEnabled = true })
	old := cwFetchMappingSheet
	cwFetchMappingSheet = func(context.Context) (cwSheetSnapshot, error) {
		t.Fatal("must not attempt network on a mode change")
		return cwSheetSnapshot{}, nil
	}
	defer func() { cwFetchMappingSheet = old }()
	cwProcessOutbox()
	db, _ := cwDB()
	defer db.Close()
	var status, reason string
	db.QueryRow("SELECT status,error FROM tap_outbox WHERE case_id=?", a.ID).Scan(&status, &reason)
	if status != "blocked" || reason != "notification_mode_changed_or_unsupported" {
		t.Fatal(status, reason)
	}
}

func TestMappingDriftAndBadPreviewAreBlocked(t *testing.T) {
	a, _ := cwFixture(t)
	body := testConfirmedNotificationBody(t, a, "owner", "ou_owner")
	var request map[string]any
	json.Unmarshal([]byte(body), &request)
	token := asString(request["confirmation_token"])
	db, _ := cwDB()
	defer db.Close()
	db.Exec("UPDATE tap_notification_previews SET expires_at=0 WHERE token_hash=?", cwPreviewHash(token))
	r := cwTestRequest("owner", body)
	r.SetPathValue("id", a.ID)
	w := httptest.NewRecorder()
	cwNotifyHandler(w, r)
	if w.Code != 409 {
		t.Fatal("expired preview accepted:", w.Body.String())
	}
	var count int
	if err := db.QueryRow("SELECT COUNT(*) FROM tap_outbox WHERE case_id=?", a.ID).Scan(&count); err != nil || count != 0 {
		t.Fatal("expired preview created an outbox job", count, err)
	}
}

func TestSheetSyncDeletesRemovedRowsWithinSameSecond(t *testing.T) {
	cwFixture(t)
	withMappingSheet(t, "1", []string{"APAC", "removed", "removed@example.com", "", "已确认", "", ""})
	db, _ := cwDB()
	defer db.Close()
	if _, err := cwSyncIdentityMappings(context.Background(), db); err != nil {
		t.Fatal(err)
	}
	cwFetchMappingSheet = func(context.Context) (cwSheetSnapshot, error) {
		return cwSheetSnapshot{Revision: "2", Values: [][]string{mappingHeader}}, nil
	}
	if _, err := cwSyncIdentityMappings(context.Background(), db); err != nil {
		t.Fatal(err)
	}
	res, err := cwResolveMapping(db, "removed", "APAC")
	if err != nil || res.Status != "pending" || res.Reason != "mapping_missing" {
		t.Fatal(res, err)
	}
}

func TestNotificationDeepLinkPreservesAIMERoute(t *testing.T) {
	for _, base := range []string{"", "https://aime.tiktok-row.net/standalone/app/app_e5d1388d65ef1b49?installed_first=1&app_location=%2F%3Fview%3Doperations", "https://workbench.example.test/"} {
		t.Run(base, func(t *testing.T) {
			t.Setenv("TAP_WORKBENCH_URL", base)
			link, err := url.Parse(cwWorkbenchURL("TAP-example-alert"))
			if err != nil {
				t.Fatal(err)
			}
			q := link.Query()
			if q.Has("app_location") {
				inner, err := url.Parse(q.Get("app_location"))
				if err != nil {
					t.Fatal(err)
				}
				q = inner.Query()
			}
			if q.Get("alert_id") != "TAP-example-alert" || q.Get("view") != "tasks" {
				t.Fatal("deep link lost event:", link)
			}
		})
	}
}

func TestNotifyReusesExistingSuccessfulCaseDelivery(t *testing.T) {
	a, _ := cwFixture(t)
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	if _, err = db.Exec(`INSERT INTO tap_outbox(id,case_id,recipient,kind,status,message_id,notification_mode,created_at,updated_at) VALUES(?,?,?,'send','sent',?,'test',?,?)`, "existing-sent", a.ID, "open_id:ou_owner", "om_existing_delivery", cwNow(), cwNow()); err != nil {
		t.Fatal(err)
	}

	body := testConfirmedNotificationBody(t, a, "owner", "ou_owner")
	r := cwTestRequest("owner", body)
	r.SetPathValue("id", a.ID)
	w := httptest.NewRecorder()
	cwNotifyHandler(w, r)
	if w.Code != http.StatusAccepted || !strings.Contains(w.Body.String(), `"idempotent":true`) || !strings.Contains(w.Body.String(), `"reused":true`) || !strings.Contains(w.Body.String(), `"message_id":"om_existing_delivery"`) {
		t.Fatal(w.Code, w.Body.String())
	}
	var count int
	if err = db.QueryRow("SELECT COUNT(*) FROM tap_outbox WHERE case_id=? AND kind='send'", a.ID).Scan(&count); err != nil || count != 1 {
		t.Fatal("successful delivery was duplicated", count, err)
	}

	transportCalls := 0
	oldClient := cwHTTPClient
	cwHTTPClient = &http.Client{Transport: cwRoundTripper(func(*http.Request) (*http.Response, error) {
		transportCalls++
		return nil, errors.New("transport must not be called")
	})}
	defer func() { cwHTTPClient = oldClient }()
	cwProcessOutbox()
	if transportCalls != 0 {
		t.Fatal("existing delivery reached transport", transportCalls)
	}
}

func TestNotifyDoesNotDuplicateEffectiveQueueWithFreshPreview(t *testing.T) {
	a, _ := cwFixture(t)
	firstBody := testConfirmedNotificationBody(t, a, "owner", "ou_owner")
	first := cwTestRequest("owner", firstBody)
	first.SetPathValue("id", a.ID)
	firstResponse := httptest.NewRecorder()
	cwNotifyHandler(firstResponse, first)
	if firstResponse.Code != http.StatusAccepted {
		t.Fatal(firstResponse.Body.String())
	}

	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	latest, err := cwRead(db, a.ID)
	if err != nil {
		t.Fatal(err)
	}
	secondBody := testConfirmedNotificationBody(t, latest, "owner", "ou_owner")
	second := cwTestRequest("owner", secondBody)
	second.SetPathValue("id", a.ID)
	secondResponse := httptest.NewRecorder()
	cwNotifyHandler(secondResponse, second)
	if secondResponse.Code != http.StatusAccepted || !strings.Contains(secondResponse.Body.String(), `"idempotent":true`) || !strings.Contains(secondResponse.Body.String(), `"reused":true`) {
		t.Fatal(secondResponse.Code, secondResponse.Body.String())
	}
	var count int
	if err = db.QueryRow("SELECT COUNT(*) FROM tap_outbox WHERE case_id=? AND kind='send'", a.ID).Scan(&count); err != nil || count != 1 {
		t.Fatal("effective queue was duplicated", count, err)
	}
}

func TestNotificationViewsAndAnalyticsDeduplicateHistoricalMessageID(t *testing.T) {
	a, _ := cwFixture(t)
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	for _, id := range []string{"historical-delivery-1", "historical-delivery-2"} {
		if _, err = db.Exec(`INSERT INTO tap_outbox(id,case_id,recipient,kind,status,message_id,notification_mode,created_at,updated_at) VALUES(?,?,?,'send','sent',?,'test',?,?)`, id, a.ID, "open_id:ou_owner", "om_same_delivery", cwNow(), cwNow()); err != nil {
			t.Fatal(err)
		}
	}
	notices, err := cwNotices(db, a.ID)
	if err != nil || len(notices) != 1 || notices[0].MessageID != "om_same_delivery" {
		t.Fatal("detail did not deduplicate delivery", notices, err)
	}

	x := cwAnalytics{Cases: []cwCase{a}, Notification: map[string]map[string]int{"test": {}, "formal": {}}}
	if err = cwAnalyticsNotifications(&x); err != nil {
		t.Fatal(err)
	}
	if x.Notification["test"]["success"] != 1 {
		t.Fatalf("analytics counted duplicate delivery: %+v", x.Notification)
	}
	if x.NotificationSource["unknown"]["success"] != 1 || x.Outcomes["notification_complete"]["complete"] != 1 {
		t.Fatalf("historical source/outcome classification invalid: source=%+v outcomes=%+v", x.NotificationSource, x.Outcomes)
	}
	listRequest := cwTestRequest("operator", "")
	listResponse := httptest.NewRecorder()
	cwListHandler(listResponse, listRequest)
	var listBody struct {
		Data struct {
			Stats map[string]int `json:"stats"`
		} `json:"data"`
	}
	if listResponse.Code != http.StatusOK || json.Unmarshal(listResponse.Body.Bytes(), &listBody) != nil || listBody.Data.Stats["notification_sent"] != 1 {
		t.Fatalf("case statistics counted duplicate delivery: code=%d body=%s", listResponse.Code, listResponse.Body.String())
	}
	rows := cwNoticeRows(x)
	if len(rows) != 2 {
		t.Fatalf("export counted duplicate delivery: %+v", rows)
	}
}

func TestTestPreviewUsesExplicitAllowlistWhenSubmitterIsNotBotVisible(t *testing.T) {
	a, _ := cwFixture(t)
	cwFetchMappingSheet = func(context.Context) (cwSheetSnapshot, error) {
		return cwSheetSnapshot{Revision: "missing-submitter", Values: [][]string{mappingHeader}}, nil
	}
	cwResolveBotOpenID = func(context.Context, string) (string, string) {
		t.Fatal("test preview must not resolve the real submitter")
		return "", "person_not_visible_or_out_of_scope"
	}
	r := cwTestRequest("owner", `{"recipient_id":"ou_owner"}`)
	r.SetPathValue("id", a.ID)
	w := httptest.NewRecorder()
	cwNotificationPreviewHandler(w, r)
	if w.Code != http.StatusOK {
		t.Fatal(w.Body.String())
	}
	var response struct {
		Data struct {
			ConfirmationToken string `json:"confirmation_token"`
			BotResolution     struct {
				Status string `json:"status"`
			} `json:"bot_resolution"`
			MappingResult struct {
				Status string `json:"status"`
			} `json:"mapping_result"`
			ActualTarget struct {
				Status string `json:"status"`
			} `json:"actual_target"`
		} `json:"data"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &response); err != nil {
		t.Fatal(err)
	}
	if response.Data.ActualTarget.Status != "ready_test_allowlist" || len(response.Data.ConfirmationToken) != 43 {
		t.Fatalf("allowlist target was blocked: %s", w.Body.String())
	}
	if response.Data.BotResolution.Status != "not_attempted" || response.Data.MappingResult.Status != "pending" {
		t.Fatalf("real submitter audit should be non-blocking: %s", w.Body.String())
	}
}

func TestFormalPreviewAllowedWhileAutoSendDisabledAndExecutionGatesRemainClosed(t *testing.T) {
	a, _ := cwFixture(t)
	configureCasework(t, func(c *cwConfig) {
		c.NotificationMode = "test"
		c.AutoSendEnabled = false
	})

	previewRequest := cwTestRequest("owner", `{"mode":"formal"}`)
	previewRequest.SetPathValue("id", a.ID)
	previewResponse := httptest.NewRecorder()
	cwNotificationPreviewHandler(previewResponse, previewRequest)
	if previewResponse.Code != http.StatusOK {
		t.Fatalf("formal preview must remain available with auto-send disabled: %s", previewResponse.Body.String())
	}
	if !strings.Contains(previewResponse.Body.String(), `"notification_mode":"formal"`) || !strings.Contains(previewResponse.Body.String(), `"will_send":false`) || !strings.Contains(previewResponse.Body.String(), `"auto_send_enabled":false`) {
		t.Fatalf("formal preview did not preserve read-only safety metadata: %s", previewResponse.Body.String())
	}
	var formalPreview struct {
		Data struct {
			PreviewToken string `json:"preview_token"`
			CaseVersion  int    `json:"case_version"`
		} `json:"data"`
	}
	if err := json.Unmarshal(previewResponse.Body.Bytes(), &formalPreview); err != nil || formalPreview.Data.PreviewToken == "" {
		t.Fatalf("formal preview token missing: %v %s", err, previewResponse.Body.String())
	}
	confirmedRequest := cwTestRequest("owner", fmt.Sprintf(`{"mode":"formal","expected_version":%d,"preview_token":%q}`, formalPreview.Data.CaseVersion, formalPreview.Data.PreviewToken))
	confirmedRequest.SetPathValue("id", a.ID)
	confirmedResponse := httptest.NewRecorder()
	cwNotifyHandler(confirmedResponse, confirmedRequest)
	if confirmedResponse.Code != http.StatusAccepted {
		t.Fatalf("explicitly confirmed single formal send was rejected: code=%d body=%s", confirmedResponse.Code, confirmedResponse.Body.String())
	}

	unconfirmedRequest := cwTestRequest("owner", fmt.Sprintf(`{"mode":"formal","expected_version":%d}`, a.Version))
	unconfirmedRequest.SetPathValue("id", a.ID)
	unconfirmedResponse := httptest.NewRecorder()
	cwNotifyHandler(unconfirmedResponse, unconfirmedRequest)
	if unconfirmedResponse.Code != http.StatusBadRequest {
		t.Fatalf("formal send without a preview token was accepted: code=%d body=%s", unconfirmedResponse.Code, unconfirmedResponse.Body.String())
	}

	batchRequest := cwTestRequest("owner", fmt.Sprintf(`{"mode":"formal","dry_run":false,"items":[{"alert_id":%q,"expected_version":%d,"preview_token":"not-a-token"}]}`, a.ID, a.Version))
	batchResponse := httptest.NewRecorder()
	cwNotificationBatchHandler(batchResponse, batchRequest)
	if batchResponse.Code != http.StatusForbidden || !strings.Contains(batchResponse.Body.String(), "formal_batch_disabled") {
		t.Fatalf("formal batch execution was not fail-closed: code=%d body=%s", batchResponse.Code, batchResponse.Body.String())
	}

	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	fingerprint, err := cwBotFingerprint()
	if err != nil {
		t.Fatal(err)
	}
	var formalSource, formalMode string
	if err = db.QueryRow("SELECT source,mode FROM tap_outbox WHERE case_id=? AND notification_mode='formal'", a.ID).Scan(&formalSource, &formalMode); err != nil || formalSource != "manual" || formalMode != "formal" {
		t.Fatalf("confirmed formal send was not isolated as manual: source=%s mode=%s err=%v", formalSource, formalMode, err)
	}
	if _, err = db.Exec("DELETE FROM tap_outbox WHERE case_id=?", a.ID); err != nil {
		t.Fatal(err)
	}
	_, err = db.Exec(`INSERT INTO tap_outbox(id,case_id,recipient,kind,status,notification_mode,bot_fingerprint,source,mode,created_at,updated_at) VALUES(?,?,?,'send','pending','formal',?,'auto','formal',?,?)`, "auto-formal-gate", a.ID, "open_id:ou_owner", fingerprint, cwNow(), cwNow())
	db.Close()
	if err != nil {
		t.Fatal(err)
	}
	oldClient := cwHTTPClient
	transportCalls := 0
	cwHTTPClient = &http.Client{Transport: cwRoundTripper(func(*http.Request) (*http.Response, error) {
		transportCalls++
		return nil, errors.New("formal auto-send must not reach transport")
	})}
	defer func() { cwHTTPClient = oldClient }()
	cwProcessOutbox()
	if transportCalls != 0 {
		t.Fatal("formal auto-send reached transport")
	}
	db, _ = cwDB()
	defer db.Close()
	var status, reason string
	if err = db.QueryRow("SELECT status,error FROM tap_outbox WHERE id='auto-formal-gate'").Scan(&status, &reason); err != nil || status != "blocked" || reason != "formal_batch_or_auto_disabled" {
		t.Fatalf("formal auto-send gate status=%s reason=%s err=%v", status, reason, err)
	}
}

func TestControlledResendAdvancesGenerationAndDeliversNewMessage(t *testing.T) {
	a, _ := cwFixture(t)
	oldClient := cwHTTPClient
	defer func() {
		cwHTTPClient = oldClient
		cwTokenValue = ""
	}()
	cwTokenValue = ""
	sends := 0
	cwHTTPClient = &http.Client{Transport: cwRoundTripper(func(r *http.Request) (*http.Response, error) {
		if strings.Contains(r.URL.Path, "tenant_access_token") {
			return cwFakeResponse(`{"code":0,"tenant_access_token":"token","expire":7200}`), nil
		}
		if r.Method != http.MethodPost || r.URL.Path != "/open-apis/im/v1/messages" {
			t.Fatalf("unexpected Feishu request: %s %s", r.Method, r.URL.String())
		}
		sends++
		return cwFakeResponse(fmt.Sprintf(`{"code":0,"data":{"message_id":"om_generation_%d"}}`, sends)), nil
	})}

	enqueueFormal := func(current cwCase, resend bool) *httptest.ResponseRecorder {
		previewRequest := cwTestRequest("operator", `{"mode":"formal"}`)
		previewRequest.SetPathValue("id", current.ID)
		previewResponse := httptest.NewRecorder()
		cwNotificationPreviewHandler(previewResponse, previewRequest)
		if previewResponse.Code != http.StatusOK {
			t.Fatalf("formal preview failed: %s", previewResponse.Body.String())
		}
		var preview struct {
			Data struct {
				PreviewToken string `json:"preview_token"`
				CaseVersion  int    `json:"case_version"`
			} `json:"data"`
		}
		if err := json.Unmarshal(previewResponse.Body.Bytes(), &preview); err != nil {
			t.Fatal(err)
		}
		body := map[string]any{"mode": "formal", "expected_version": preview.Data.CaseVersion, "preview_token": preview.Data.PreviewToken}
		if resend {
			body["resend"] = true
			body["resend_request_id"] = "controlled-resend-2"
			body["confirmation_note"] = "operator confirmed a new delivery"
		}
		payload, _ := json.Marshal(body)
		request := cwTestRequest("operator", string(payload))
		request.SetPathValue("id", current.ID)
		response := httptest.NewRecorder()
		cwNotifyHandler(response, request)
		return response
	}

	first := enqueueFormal(a, false)
	if first.Code != http.StatusAccepted {
		t.Fatalf("initial formal enqueue failed: %s", first.Body.String())
	}
	cwProcessOutbox()

	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	var firstStatus, firstMessage string
	if err = db.QueryRow("SELECT status,message_id FROM tap_outbox WHERE case_id=? AND generation=1", a.ID).Scan(&firstStatus, &firstMessage); err != nil {
		t.Fatal(err)
	}
	if firstStatus != "sent" || firstMessage != "om_generation_1" {
		t.Fatalf("initial delivery mismatch: status=%s message=%s", firstStatus, firstMessage)
	}

	latest, err := cwRead(db, a.ID)
	if err != nil {
		t.Fatal(err)
	}
	resend := enqueueFormal(latest, true)
	if resend.Code != http.StatusAccepted || !strings.Contains(resend.Body.String(), `"resend":true`) {
		t.Fatalf("controlled resend enqueue failed: code=%d body=%s", resend.Code, resend.Body.String())
	}
	cwProcessOutbox()

	var secondStatus, secondMessage string
	if err = db.QueryRow("SELECT status,message_id FROM tap_outbox WHERE case_id=? AND generation=2", a.ID).Scan(&secondStatus, &secondMessage); err != nil {
		t.Fatal(err)
	}
	if secondStatus != "sent" || secondMessage != "om_generation_2" || secondMessage == firstMessage || sends != 2 {
		t.Fatalf("controlled resend was not independently delivered: status=%s first=%s second=%s sends=%d", secondStatus, firstMessage, secondMessage, sends)
	}

	duplicateID := "ordinary-duplicate-generation-2"
	fingerprint, err := cwBotFingerprint()
	if err != nil {
		t.Fatal(err)
	}
	if _, err = db.Exec(`INSERT INTO tap_outbox(id,case_id,recipient,kind,status,notification_mode,generation,bot_fingerprint,source,mode,created_at,updated_at) VALUES(?,?,?,'send','pending','formal',2,?,'manual','formal',?,?)`, duplicateID, a.ID, "open_id:ou_formal", fingerprint, cwNow(), cwNow()); err != nil {
		t.Fatal(err)
	}
	cwProcessOutbox()
	var duplicateStatus string
	if err = db.QueryRow("SELECT status FROM tap_outbox WHERE id=?", duplicateID).Scan(&duplicateStatus); err != nil {
		t.Fatal(err)
	}
	if duplicateStatus != "pending" || sends != 2 {
		t.Fatalf("ordinary duplicate protection regressed: status=%s sends=%d", duplicateStatus, sends)
	}
}

func TestFormalPreviewReusesVerifiedCloudDeliveryWithoutBotLookup(t *testing.T) {
	a, _ := cwFixture(t)
	withMappingSheet(t, "verified-revision", []string{"APAC", "owner", "owner@example.com", "", "已确认", "ok", "2026-10-20"})
	fingerprint, err := cwBotFingerprint()
	if err != nil {
		t.Fatal(err)
	}
	oldProvider, oldResolver := cwCaseworkRepositoryProvider, cwResolveBotOpenID
	cwCaseworkRepositoryProvider = func() (caseworkRepository, error) {
		return cloudOnlyCaseworkRepository{
			caseworkRepository: localCaseworkRepository{},
			caseRecord:         a,
			noticeRecords: []cwNotice{{
				CaseID: a.ID, Kind: "send", Status: "sent", MessageID: "om_verified", NotificationMode: "formal",
				TargetEmail: "owner@example.com", ResolvedOpenID: "ou_verified", BotFingerprint: fingerprint,
			}},
		}, nil
	}
	cwResolveBotOpenID = func(context.Context, string) (string, string) {
		t.Fatal("verified delivery cache must win before Bot lookup")
		return "", ""
	}
	t.Cleanup(func() {
		cwCaseworkRepositoryProvider = oldProvider
		cwResolveBotOpenID = oldResolver
	})

	request := cwTestRequest("owner", `{"mode":"formal"}`)
	request.SetPathValue("id", a.ID)
	response := httptest.NewRecorder()
	cwNotificationPreviewHandler(response, request)
	body := response.Body.String()
	if response.Code != http.StatusOK || !strings.Contains(body, `"status":"ready_formal"`) || !strings.Contains(body, `"source":"case_verified_recipient"`) || !strings.Contains(body, `"will_send":false`) || strings.Contains(body, "ou_verified") {
		t.Fatalf("formal dry-run did not safely reuse verified recipient: code=%d body=%s", response.Code, body)
	}
}

type fallbackCaseRepository struct {
	caseworkRepository
	cases []cwCase
}

func (r fallbackCaseRepository) listCases(context.Context) ([]cwCase, error) {
	return append([]cwCase(nil), r.cases...), nil
}

func TestPersistedCaseFallbackRequiresExactScanAndRow(t *testing.T) {
	a, _ := cwFixture(t)
	oldProvider := cwCaseworkRepositoryProvider
	cwCaseworkRepositoryProvider = func() (caseworkRepository, error) {
		return fallbackCaseRepository{caseworkRepository: localCaseworkRepository{}, cases: []cwCase{a}}, nil
	}
	t.Cleanup(func() { cwCaseworkRepositoryProvider = oldProvider })

	got, ok := cwPersistedCaseFallback(context.Background(), a.ScanID, a.Row.ID)
	if !ok || got.ID != a.ID {
		t.Fatalf("exact persisted snapshot was not returned: ok=%v case=%+v", ok, got)
	}
	if _, ok = cwPersistedCaseFallback(context.Background(), a.ScanID, "different-row"); ok {
		t.Fatal("fallback must reject a different row in the same scan")
	}
	if _, ok = cwPersistedCaseFallback(context.Background(), "different-scan", a.Row.ID); ok {
		t.Fatal("fallback must reject the same row from a different scan")
	}
}
