package main

import (
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func integrityCompleteJob(program string) wbJob {
	m := wbMember{AccountID: "1001", AdvertiserID: "2001", TicketID: "ticket", Start: "2026-10-01"}
	row := wbRow{Program: program, Member: m, MetricStatus: "success", CCR: f64(5), NFS: f64(80), Comparison: wbComparison{Status: "available", CCRGrowthPct: f64(120)}}
	c := wbAssessScanCoverage(program, []wbMember{m}, []wbRow{row}, true)
	return wbJob{ID: "complete-" + program, BatchID: "TAP-WEEK-2026-10-19-2026-10-25", Status: "ready", Complete: true, Members: 1, Done: 1, Rows: []wbRow{row}, Request: wbRequest{Program: program, Region: "all", Start: "2026-10-19", End: "2026-10-25", MemberStart: "2026-01-01", MemberEnd: "2026-10-25"}, CoreCoverage: &c}
}
func TestIntegrityLateStartupCatchesOnlyLatestWeek(t *testing.T) {
	schedule := wbWeeklySchedulerConfig{Enabled: true, Weekday: 1, Hour: 9, DataReadyDelayMin: 120}
	for _, d := range []int{27, 29, 31} {
		at := time.Date(2026, 10, d, 12, 0, 0, 0, cwLocation())
		run, batch, _, err := wbWeeklyScheduleDecisionWithConfig(at, "Asia/Shanghai", schedule, map[string]bool{"ET": true, "ST": true})
		if err != nil || !run || batch != "TAP-WEEK-2026-10-19-2026-10-25" {
			t.Fatalf("%s: run=%v batch=%s err=%v", at, run, batch, err)
		}
	}
	at := time.Date(2026, 11, 2, 10, 59, 0, 0, cwLocation())
	if run, _, reason, _ := wbWeeklyScheduleDecisionWithConfig(at, "Asia/Shanghai", schedule, nil); run || reason != "data_not_ready" {
		t.Fatal("new week ran before data-ready boundary")
	}
}
func TestIntegrityCoverageRequiresEveryTargetAndNoQueryErrors(t *testing.T) {
	for _, program := range []string{"ET", "ST", "THT"} {
		job := integrityCompleteJob(program)
		m := job.Rows[0].Member
		second := m
		second.TicketID = "second"
		c := wbAssessScanCoverage(program, []wbMember{m, second}, job.Rows, true)
		if c.Status == "complete" || c.QueriedCount != 1 || c.TargetCount != 2 {
			t.Fatalf("%s: missing target claimed complete %+v", program, c)
		}
		rows := append([]wbRow(nil), job.Rows...)
		rows[0].Comparison = wbComparison{Status: "unavailable", MissingReason: "comparison_source_error", Source: map[string]any{"query_status": "failed"}}
		c = wbAssessScanCoverage(program, []wbMember{m}, rows, true)
		if c.Status == "complete" || c.QueryFailures != 1 {
			t.Fatalf("%s query failure hidden: %+v", program, c)
		}
		rows[0].Comparison = wbComparison{Status: "window_incomplete"}
		c = wbAssessScanCoverage(program, []wbMember{m}, rows, true)
		if c.Status != "complete" || c.ComparisonUnavailableRows != 1 {
			t.Fatalf("immature window caused endless retries: %+v", c)
		}
		rows[0].CCR = nil
		rows[0].NFS = nil
		rows[0].MetricStatus = "no_data"
		rows[0].Comparison = wbComparison{Status: "source_null"}
		c = wbAssessScanCoverage(program, []wbMember{m}, rows, true)
		if c.Status != "complete" || c.SourceMissingRows != 1 {
			t.Fatalf("successful source absence confused with query error: %+v", c)
		}
		c = wbAssessScanCoverage(program, []wbMember{m}, rows, false)
		if c.Status == "complete" {
			t.Fatal("unconfirmed membership promoted")
		}
	}
}
func TestIntegrityOnlyGlobalFullScopeSuppressesWeeklyScan(t *testing.T) {
	j := integrityCompleteJob("THT")
	if !wbScheduledJobComplete(j) {
		t.Fatal("complete full-scope scan rejected")
	}
	for _, scope := range []string{"regional", "short_membership", "incomplete_core", "failed"} {
		c := j
		switch scope {
		case "regional":
			c.Request.Region = "EUI"
		case "short_membership":
			c.Request.MemberStart = "2026-10-19"
		case "incomplete_core":
			coverage := *c.CoreCoverage
			coverage.QueryFailures = 1
			c.CoreCoverage = &coverage
		case "failed":
			c.Status = "failed"
		}
		if wbScheduledJobComplete(c) {
			t.Fatalf("%s suppressed global job", scope)
		}
	}
}
func TestIntegrityBoundedRetriesPersistAcrossRestart(t *testing.T) {
	now := time.Date(2026, 10, 29, 10, 0, 0, 0, time.UTC)
	j := integrityCompleteJob("THT")
	j.Principal = wbSchedulerPrincipal
	j.Status = "failed"
	j.FinishedAt = now.Add(-time.Minute).Format(time.RFC3339)
	state := map[string]wbJob{"one": j}
	if allowed, reason := wbScheduledRetryState(state, j.BatchID, "THT", now); allowed || reason != "retry_cooldown" {
		t.Fatal("no backoff", reason)
	}
	j.FinishedAt = now.Add(-time.Hour).Format(time.RFC3339)
	state["one"] = j
	if allowed, _ := wbScheduledRetryState(state, j.BatchID, "THT", now); !allowed {
		t.Fatal("eligible retry blocked")
	}
	state["two"], state["three"] = j, j
	raw, _ := json.Marshal(state)
	state = nil
	_ = json.Unmarshal(raw, &state)
	if allowed, reason := wbScheduledRetryState(state, j.BatchID, "THT", now); allowed || reason != "retry_limit_reached" {
		t.Fatal("restart reset persisted retry budget", reason)
	}
}
func TestIntegrityFailedMemoryJobDoesNotSuppressRetry(t *testing.T) {
	wbTestEnv(t)
	j := integrityCompleteJob("THT")
	j.Status = "failed"
	j.Principal = wbSchedulerPrincipal
	j.StartedAt = time.Now().Add(-2 * time.Hour).Format(time.RFC3339)
	j.FinishedAt = j.StartedAt
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{j.ID: j}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	wbMu.Lock()
	wbRunning[j.ID] = &j
	wbMu.Unlock()
	completed, err := wbScheduledPrograms(j.BatchID)
	if err != nil || completed["THT"] {
		t.Fatalf("failed memory job suppresses retry: %v %v", completed, err)
	}
	c, err := loadWBConfig()
	if err != nil {
		t.Fatal(err)
	}
	first, created, err := wbCreateScheduledJob(wbReq(wbSchedulerPrincipal), c, j.Request)
	if err != nil || !created || first.ID == j.ID {
		t.Fatalf("retry not created: %+v %v %v", first, created, err)
	}
	second, created, err := wbCreateScheduledJob(wbReq(wbSchedulerPrincipal), c, j.Request)
	if err != nil || created || second.ID != first.ID {
		t.Fatal("duplicate retry created")
	}
	// Terminal objects are retained in wbRunning; a same-key failure must still retry.
	wbMu.Lock()
	first.Status = "failed"
	first.FinishedAt = time.Now().Add(-time.Hour).Format(time.RFC3339)
	err = wbSaveJob(first)
	wbMu.Unlock()
	if err != nil {
		t.Fatal(err)
	}
	third, created, err := wbCreateScheduledJob(wbReq(wbSchedulerPrincipal), c, j.Request)
	if err != nil || !created || third.ID == first.ID {
		t.Fatalf("same-scope terminal memory object blocked retry: %v %v", created, err)
	}
}
func TestIntegrityMissingTHStillNotZeroRisks(t *testing.T) {
	wbTestEnv(t)
	job := readModelFixture(t, 1)
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	req := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly&program=THT&batch_id="+job.BatchID, nil).WithContext(wbReq("reader").Context())
	wbReadModelHandler(rr, req)
	var body struct {
		Data struct {
			Status      string                    `json:"status"`
			Reason      string                    `json:"reason"`
			Cards       map[string]wbCardValue    `json:"cards"`
			Diagnostics map[string]map[string]any `json:"scan_diagnostics"`
		}
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	if rr.Code != 200 || body.Data.Status != "unavailable" || body.Data.Cards["risk_customers"].Value != nil || body.Data.Diagnostics["THT"]["status"] != "not_scanned" || !strings.Contains(body.Data.Reason, "THT") {
		t.Fatalf("missing scan masquerades as zero: %s", rr.Body.String())
	}
}
func TestIntegrityRuleBoundaryValuesForAllPrograms(t *testing.T) {
	for _, p := range []string{"ET", "ST", "THT"} {
		tests := []struct {
			ccr, nfs, growth float64
			want             string
		}{{3, 50, 0, "normal"}, {3, 51, 0, "watch"}, {45, 300, 0, "critical"}, {45, 299, 0, "watch"}, {6, 0, 101, "normal"}, {6.01, 0, 100, "normal"}, {6.01, 0, 100.01, "critical"}}
		for _, tc := range tests {
			row := wbRow{Program: p, CCR: f64(tc.ccr), NFS: f64(tc.nfs), Comparison: wbComparison{Status: "available", CCRGrowthPct: f64(tc.growth)}}
			if p == "ST" {
				row.Comparison.Kind = "qoq"
				row.Comparison.PreStart = "2026-04-01"
				row.Comparison.PreEndExclusive = "2026-07-01"
				row.Comparison.PostStart = "2026-07-01"
				row.Comparison.PostEndExclusive = "2026-10-01"
			}
			level, _ := wbEvaluateRow(row, wbDefaultPolicy())
			if level != tc.want {
				t.Fatalf("%s CCR=%v NFS=%v growth=%v got=%s want=%s", p, tc.ccr, tc.nfs, tc.growth, level, tc.want)
			}
		}
	}
}

func TestIntegrityRunningEmptyScanHasVisibleDiagnostic(t *testing.T) {
	wbTestEnv(t)
	j := integrityCompleteJob("THT")
	j.Status = "running"
	j.Stage = "loading_members"
	j.Rows = nil
	j.Members = 0
	j.Done = 0
	j.CoreCoverage = nil
	j.Complete = false
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{j.ID: j}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	batches, jobs, err := wbPersistedBatches()
	if err != nil || len(batches) != 1 || len(jobs[j.BatchID]) != 1 {
		t.Fatalf("running task hidden: %v %v", batches, err)
	}
	status, reason, diagnostic := wbReadScanCoverage(jobs[j.BatchID], "THT")
	if status != "unavailable" || !strings.Contains(reason, "正在扫描") || diagnostic["THT"].(map[string]any)["status"] != "running" {
		t.Fatalf("bad running diagnostic: %s %s %v", status, reason, diagnostic)
	}
}
