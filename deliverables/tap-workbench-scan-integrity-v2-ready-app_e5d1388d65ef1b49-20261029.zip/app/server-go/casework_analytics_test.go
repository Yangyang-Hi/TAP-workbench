package main

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"fmt"
	"net/http/httptest"
	"strings"
	"testing"
)

func useLocalAnalyticsRepo(t *testing.T) {
	t.Helper()
	old := cwCaseworkRepositoryProvider
	cwCaseworkRepositoryProvider = func() (caseworkRepository, error) { return localCaseworkRepository{}, nil }
	t.Cleanup(func() { cwCaseworkRepositoryProvider = old })
}

func putAnalyticsCase(t *testing.T, a cwCase) {
	t.Helper()
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	body, _ := json.Marshal(a)
	if _, err = db.Exec("INSERT OR REPLACE INTO tap_cases(id,version,body) VALUES(?,?,?)", a.ID, a.Version, string(body)); err != nil {
		t.Fatal(err)
	}
}

func TestAnalyticsFilteringDedupAndPersistence(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	useLocalAnalyticsRepo(t)
	base := cwCase{ID: "A1", Version: 1, Status: "open", Owner: "owner-a", CreatedAt: "2026-10-19T01:00:00Z", UpdatedAt: "2026-10-19T01:00:00Z", Row: wbRow{Program: "ET", Level: "critical", Member: wbMember{AccountID: "100", Region: "APAC"}}, Fields: map[string]string{}}
	putAnalyticsCase(t, base)
	second := base
	second.ID = "A2"
	second.Status = "pending_review"
	second.Version = 2
	putAnalyticsCase(t, second)
	x, err := cwAnalyticsBuild(cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-19", Region: "APAC", Program: "ET", Owner: "owner-a", Level: "critical"})
	if err != nil {
		t.Fatal(err)
	}
	if x.Summary["alerts"] != 2 || x.Summary["clients"] != 1 || x.Summary["pending_review"] != 1 || x.EffectStatus["waiting_recheck"] != 0 {
		t.Fatalf("unexpected summary/effect status: %#v %#v", x.Summary, x.EffectStatus)
	}
	second.Status = "closed"
	second.ClosedAt = "2026-10-19T04:00:00Z"
	second.Version = 3
	putAnalyticsCase(t, second)
	x, err = cwAnalyticsBuild(cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-19"})
	if err != nil {
		t.Fatal(err)
	}
	if x.Summary["closed"] != 1 || x.Summary["pending_review"] != 0 {
		t.Fatalf("status update not reflected: %#v", x.Summary)
	}
	// cwAnalyticsBuild opens a fresh database handle, proving persisted data survives reconnects.
}

func TestAnalyticsExcelUsesFilteredCases(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	useLocalAnalyticsRepo(t)
	putAnalyticsCase(t, cwCase{ID: "ONLY", Version: 1, Status: "open", Owner: "owner", CreatedAt: "2026-10-19T01:00:00Z", UpdatedAt: "2026-10-19T01:00:00Z", Row: wbRow{Program: "THT", Level: "watch", Member: wbMember{AdvertiserID: "200", Region: "NA"}}, Fields: map[string]string{}})
	x, err := cwAnalyticsBuild(cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-19", Program: "THT"})
	if err != nil {
		t.Fatal(err)
	}
	r := httptest.NewRecorder()
	if err = cwWriteXLSX(r, x); err != nil {
		t.Fatal(err)
	}
	zr, err := zip.NewReader(bytes.NewReader(r.Body.Bytes()), int64(r.Body.Len()))
	if err != nil {
		t.Fatal(err)
	}
	if len(zr.File) < 7 {
		t.Fatalf("invalid workbook, files=%d", len(zr.File))
	}
	if r.Header().Get("Content-Type") != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" {
		t.Fatal("wrong excel content type")
	}
}

func TestAnalyticsWeeklyClosedCaseUsesBatchScopeAndDedupesProcessedClients(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	useLocalAnalyticsRepo(t)
	job := readModelFixture(t, 1)
	closed := cwCase{
		ID: "TAP-ff4e02e70f1f4998ca1d0c3c", Version: 2, Status: "closed",
		Creator: "heyangyang.31", ScanID: job.ID,
		CreatedAt: "2026-10-19T01:00:00Z", UpdatedAt: "2026-10-23T07:30:18Z",
		Row:    wbRow{ID: job.Rows[0].ID, Program: "THT", Level: "critical", Member: wbMember{AccountID: "account-1", AdvertiserID: "advertiser-1", Tier: "THT", Region: "APAC"}},
		Fields: map[string]string{},
	}
	putAnalyticsCase(t, closed)
	duplicateCustomer := closed
	duplicateCustomer.ID = "TAP-second-closed-event"
	putAnalyticsCase(t, duplicateCustomer)

	req := httptest.NewRequest("GET", "/api/workbench/analytics?time_mode=weekly&batch_id="+job.BatchID+"&case_scope=all", nil).WithContext(wbReq("reader").Context())
	rr := httptest.NewRecorder()
	cwAnalyticsHandler(rr, req)
	var body struct {
		Data cwAnalytics `json:"data"`
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	if rr.Code != 200 || body.Data.Summary["closed"] != 1 || body.Data.Summary["processed_clients"] != 1 || len(body.Data.Cases) != 1 {
		t.Fatalf("duplicate Cloud cases for one weekly event were not collapsed: %s", rr.Body.String())
	}
	if body.Data.Filters.CaseScope != "all" || body.Data.Filters.BatchID != job.BatchID || body.Data.Filters.Start != "2026-10-12" || body.Data.Filters.End != "2026-10-18" {
		t.Fatalf("weekly filter explanation mismatch: %+v", body.Data.Filters)
	}
}

func TestAnalyticsIncludesMatchedSourceAlertsWithoutCreatingCases(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	useLocalAnalyticsRepo(t)
	f := cwAnalyticsFilter{
		TimeMode: "weekly", Start: "2026-10-19", End: "2026-10-25",
		ScanIDs: map[string]bool{"scan-source": true},
		Jobs:    []wbJob{{ID: "scan-source", BatchID: "TAP-WEEK-2026-10-19-2026-10-25", AsOf: "2026-10-26T03:00:00Z", Status: "partial", Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rule: wbRule{Version: "ET-rule"}, Rows: []wbRow{{ID: "risk-row", Program: "ET", Level: "critical", Member: wbMember{AccountID: "100", Region: "APAC"}}}}},
	}
	x, err := cwAnalyticsBuild(f)
	if err != nil {
		t.Fatal(err)
	}
	if x.Summary["alerts"] != 1 || x.Summary["source_alerts"] != 1 || len(x.Cases) != 1 {
		t.Fatalf("source alert was not included: summary=%v cases=%d", x.Summary, len(x.Cases))
	}
	if x.Cases[0].Status != "source_alert" {
		t.Fatalf("source alert must remain read-only and untriaged: %+v", x.Cases[0])
	}
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	var n int
	if err = db.QueryRow("SELECT count(*) FROM tap_cases").Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 0 {
		t.Fatalf("report read must not create business cases, got %d", n)
	}
}

func TestAnalyticsMappingMetadataAndHTMLArchitecture(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	useLocalAnalyticsRepo(t)
	x, err := cwAnalyticsBuild(cwAnalyticsFilter{
		TimeMode: "weekly", Start: "2026-10-19", End: "2026-10-25",
		ScanIDs: map[string]bool{"scan": true},
		Jobs: []wbJob{{
			ID:      "scan",
			Rule:    wbRule{Enabled: true, BusinessConfirmed: true, WatchCCR: 7, WatchNFS: 300, CriticalCCR: 45},
			Request: wbRequest{Program: "ET"},
			Rows:    []wbRow{{ID: "row", Program: "ET", Level: "critical", CCR: f64(50), NFS: f64(400), Reasons: []string{"CCR 50 and NFS 400 long description must not become a bar"}, Member: wbMember{AccountID: "7462465462811770896", Region: "APAC"}}},
		}},
	})
	if err != nil {
		t.Fatal(err)
	}
	if x.Meta.LevelBasis == "" || x.Meta.CaseworkBasis == "" || len(x.RiskSource) != 1 || x.RiskSource[0].Key != "absolute" {
		t.Fatalf("mapping contract missing: %+v %+v", x.Meta, x.RiskSource)
	}
	x.Quota = map[string]any{"status": "available", "quarter": "Q4", "global": map[string]any{}, "regions": []map[string]any{}}
	cwAttachQuotaAlerts(&x)
	html := cwAnalyticsHTML(x)
	for _, heading := range []string{"1. 报告范围与本期结论", "2. 重点风险客户 · Top10 + 全部极端客户", "3. 风险结构", "4. 通知与处置进展", "5. 核查案例与动作", "6.1 ET Quota Alerts", "6.2 ST Quota Alerts", "7. 数据口径与限制"} {
		if !bytes.Contains([]byte(html), []byte(heading)) {
			t.Fatalf("missing heading %s", heading)
		}
	}
	for _, styleContract := range []string{"@media print", "display:table-header-group", "break-inside:avoid", "grid-template-columns:repeat(5", "class=formula", "class=mini-track", "rule-facts"} {
		if !bytes.Contains([]byte(html), []byte(styleContract)) {
			t.Fatalf("missing report style contract %s", styleContract)
		}
	}
	for _, removed := range []string{"优先跟进清单", "数据缺口与口径", "超额数量"} {
		if bytes.Contains([]byte(html), []byte(removed)) {
			t.Fatalf("removed report content still present: %s", removed)
		}
	}
	if bytes.Contains([]byte(html), []byte("Structured Alert Evidence")) {
		t.Fatal("long structured evidence appendix must not be embedded in the one-screen limitations chapter")
	}
	if bytes.Contains([]byte(html), []byte("<span>CCR 50 and NFS 400 long description must not become a bar</span>")) {
		t.Fatal("free-text trigger criteria leaked into report chart labels")
	}
}

func TestAnalyticsRuleMissingDoesNotGuessFromReason(t *testing.T) {
	x := cwAnalytics{Filters: cwAnalyticsFilter{}, Cases: []cwCase{{ID: "A", ScanID: "S", Row: wbRow{ID: "R", Program: "ET", Level: "critical", CCR: f64(99), NFS: f64(999), Reasons: []string{"pretend top20"}, Member: wbMember{AccountID: "1"}}}}, SourceByCase: map[string][]string{}}
	cwEnrichAnalytics(&x)
	if x.RuleSummaries[0].Condition != "规则说明待补齐" || len(x.SourceByCase["A"]) != 1 || x.SourceByCase["A"][0] != "unidentified" {
		t.Fatalf("missing snapshot must stay explicit and must not parse reason/metrics: %+v %+v", x.RuleSummaries, x.SourceByCase)
	}
}

func TestPriorityClientsMergeExtremeAllAndWatchFill(t *testing.T) {
	cases := []cwCase{}
	sources := map[string][]string{}
	for i := 0; i < 12; i++ {
		level := "watch"
		if i < 7 {
			level = "critical"
		}
		ccr, nfs := float64(20-i), float64(200-i)
		caseID := fmt.Sprintf("C%d", i)
		cases = append(cases, cwCase{ID: caseID, Status: "open", Row: wbRow{Program: "ET", Level: level, CCR: &ccr, NFS: &nfs, Member: wbMember{AccountID: fmt.Sprintf("%02d", i)}}})
		sources[caseID] = []string{"absolute"}
	}
	// Same Program + customer must merge and preserve all types/event count.
	duplicate := cases[0]
	duplicate.ID = "duplicate"
	duplicate.Status = "closed"
	cases = append(cases, duplicate)
	sources[duplicate.ID] = []string{"growth_top20"}
	rows := cwPriorityClients(cases, sources)
	if len(rows) != 10 || rows[0].EventCount != 2 || len(rows[0].AlertTypes) != 2 {
		t.Fatalf("merge/fill mismatch: %+v", rows)
	}
	for i := 0; i < 7; i++ {
		if rows[i].Severity != "critical" {
			t.Fatalf("extreme customer omitted: %+v", rows)
		}
	}
	// Every extreme customer remains visible even when the result exceeds ten.
	for i := 12; i < 17; i++ {
		ccr := float64(i)
		nfs := float64(i)
		caseID := fmt.Sprint(i)
		cases = append(cases, cwCase{ID: caseID, Status: "open", Row: wbRow{ID: fmt.Sprintf("row-%02d", i), Program: "ET", Level: "critical", CCR: &ccr, NFS: &nfs, Member: wbMember{AccountID: caseID}}})
		sources[caseID] = []string{"absolute"}
	}
	if got := cwPriorityClients(cases, sources); len(got) != 12 {
		t.Fatalf("all 12 extreme customers must remain visible, got %d", len(got))
	}
}

func TestPriorityClientsNullSortingAndActualCount(t *testing.T) {
	ccr := 9.0
	cases := []cwCase{
		{ID: "null", Status: "open", Row: wbRow{ID: "row-b", Program: "ET", Level: "watch", Member: wbMember{AccountID: "B"}}},
		{ID: "known", Status: "open", Row: wbRow{ID: "row-a", Program: "ET", Level: "watch", CCR: &ccr, Member: wbMember{AccountID: "A"}}},
	}
	rows := cwPriorityClients(cases, map[string][]string{"null": {"absolute"}, "known": {"absolute"}})
	if len(rows) != 2 || rows[0].ClientID != "A" || rows[1].ClientID != "B" || !rows[1].ProvisionalRank {
		t.Fatalf("NULL-last/actual-count contract mismatch: %+v", rows)
	}
}

func TestAnalyticsWeeklyEventDedupUsesScanAndRowAndProtectionFilter(t *testing.T) {
	t.Setenv("AIME_PLUGIN_DATA_DIR", t.TempDir())
	useLocalAnalyticsRepo(t)
	row := wbRow{ID: "same-row", Program: "ET", Level: "critical", CCR: f64(50), Member: wbMember{AccountID: "A", Region: "APAC", Start: "2026-10-20"}}
	putAnalyticsCase(t, cwCase{ID: "cloud-compatible", Version: 1, Status: "open", ScanID: "scan-a", CreatedAt: "2026-10-26T01:00:00Z", Row: row, Fields: map[string]string{}})
	jobs := []wbJob{
		{ID: "scan-a", BatchID: "batch", AsOf: "2026-10-26T01:00:00Z", Request: wbRequest{Program: "ET"}, Rows: []wbRow{row}},
		{ID: "scan-b", BatchID: "batch", AsOf: "2026-10-26T02:00:00Z", Request: wbRequest{Program: "ET"}, Rows: []wbRow{row}},
	}
	filtered, err := cwFilteredCases(cwAnalyticsFilter{TimeMode: "weekly", ScanIDs: map[string]bool{"scan-a": true, "scan-b": true}, Jobs: jobs, Region: "APAC", Program: "ET", ProtectionStartDate: "2026-10-20", ProtectionEndDate: "2026-10-20"})
	if err != nil {
		t.Fatal(err)
	}
	if len(filtered) != 2 {
		t.Fatalf("linked event must replace only the same scan+row, got %+v", filtered)
	}
	for _, event := range filtered {
		if event.ScanID == "scan-a" && event.Status == "source_alert" {
			t.Fatalf("linked case was double counted: %+v", filtered)
		}
	}
	outside, err := cwFilteredCases(cwAnalyticsFilter{TimeMode: "weekly", ScanIDs: map[string]bool{"scan-a": true}, Jobs: jobs[:1], ProtectionStartDate: "2026-10-21", ProtectionEndDate: "2026-10-22"})
	if err != nil || len(outside) != 0 {
		t.Fatalf("protection window must filter every derived view: err=%v rows=%+v", err, outside)
	}
}

func TestQuotaSectionsSeparateAndBoundary(t *testing.T) {
	q := map[string]any{"quarter": "Q4", "global": map[string]any{"et": map[string]any{"account_count": 100, "quota": 6356, "ratio": 1.6}, "st": map[string]any{"brand_count": 100, "quota": 817, "ratio": 12.2}}, "regions": []map[string]any{{"region": "A", "et": map[string]any{"account_count": 10, "quota": 10, "ratio": float64(100), "exceeded": 0}, "st": map[string]any{"brand_count": 11, "quota": 10, "ratio": float64(110), "exceeded": 1}}}}
	et, st := cwBuildQuotaSection("ET", q, cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-25"}), cwBuildQuotaSection("ST", q, cwAnalyticsFilter{})
	if et.FullRegions != 1 || et.ExceededRegions != 0 || st.FullRegions != 0 || st.ExceededRegions != 1 || *et.Quota != 6356 || *st.Quota != 817 {
		t.Fatalf("quota boundary/scope mismatch: %+v %+v", et, st)
	}
	if et.Rows[0].CaseStatus != "—" || st.Rows[0].CaseStatus != "未关联事件" {
		t.Fatalf("quota case linkage mismatch")
	}
}

func TestAnalyticsThreeSurfacesShareSections(t *testing.T) {
	x := cwAnalytics{Summary: map[string]int{}, Filters: cwAnalyticsFilter{Start: "2026-10-19", End: "2026-10-25"}, Meta: cwAnalyticsMeta{}, Notification: map[string]map[string]int{"formal": {}, "test": {}}, Effects: map[string]int{}, EffectStatus: map[string]int{}, Quota: map[string]any{"status": "available"}, QuotaAlerts: cwQuotaAlerts{ET: cwQuotaAlertSection{Title: "ET Quota Alerts"}, ST: cwQuotaAlertSection{Title: "ST Quota Alerts"}}}
	h := cwAnalyticsHTML(x)
	for _, text := range []string{"触发类型与风险等级", "重点风险客户 · Top10 + 全部极端客户", "ET Quota Alerts", "ST Quota Alerts", "Notification Status", "Case Status", "数据口径与限制"} {
		if !strings.Contains(h, text) {
			t.Fatalf("shared HTML section missing %q", text)
		}
	}
}

func TestPriorityClientsUsesBestCombinedEventPerCustomer(t *testing.T) {
	criticalCCR, watchCCR := 5.0, 99.0
	cases := []cwCase{
		{ID: "watch-high", Status: "open", Row: wbRow{ID: "row-a", Program: "ET", Level: "watch", CCR: &watchCCR, Member: wbMember{AccountID: "A"}}},
		{ID: "critical-low", Status: "open", Row: wbRow{ID: "row-z", Program: "ET", Level: "critical", CCR: &criticalCCR, Member: wbMember{AccountID: "A"}}},
		{ID: "critical-other", Status: "open", Row: wbRow{ID: "row-b", Program: "ET", Level: "critical", CCR: f64(6), Member: wbMember{AccountID: "B"}}},
	}
	rows := cwPriorityClients(cases, map[string][]string{"watch-high": {"absolute"}, "critical-low": {"absolute"}, "critical-other": {"absolute"}})
	if len(rows) != 2 || rows[0].ClientID != "B" || rows[1].ClientID != "A" || rows[1].CaseID != "critical-low" || rows[1].CCR == nil || *rows[1].CCR != criticalCCR {
		t.Fatalf("Top10 customer ranking must use the best combined event, got %+v", rows)
	}
}
