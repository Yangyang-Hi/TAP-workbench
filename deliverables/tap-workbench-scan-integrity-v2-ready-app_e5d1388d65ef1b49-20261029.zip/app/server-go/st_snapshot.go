package main

import (
	"bytes"
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

const stSnapshotSourceURL = "https://bytedance.larkoffice.com/wiki/BvySwO6zuiH9IEkzsU8c9pksnxc?sheet=wKgK4I"
const stApprovedSheetID = "aFNcWh"
const stApprovedSheetName = "Approved ST Clients list"

type stSnapshotRow struct {
	Quarter           string `json:"quarter"`
	SalesRegion       string `json:"sales_region"`
	BrandName         string `json:"brand_name"`
	AccountName       string `json:"account_name,omitempty"`
	AccountID         string `json:"account_id"`
	EndorsementReason string `json:"endorsement_reason"`
	AdexSubmitter     string `json:"adex_submitter"`
	StartDate         string `json:"start_date"`
}

type stQuarterSnapshot struct {
	Quarter          string            `json:"quarter"`
	PeriodBasis      string            `json:"period_basis"`
	SheetName        string            `json:"sheet_name"`
	SourceURL        string            `json:"source_url"`
	SourceModifiedAt string            `json:"source_modified_at,omitempty"`
	SourceRevision   int64             `json:"source_revision,omitempty"`
	SyncedAt         string            `json:"synced_at"`
	SyncedBy         string            `json:"synced_by,omitempty"`
	SyncResult       string            `json:"sync_result"`
	Fields           []string          `json:"fields"`
	Rows             []stSnapshotRow   `json:"rows"`
	RowCount         int               `json:"row_count"`
	MetricSemantics  string            `json:"metric_semantics"`
	FieldSemantics   map[string]string `json:"field_semantics"`
}

type stSnapshotState struct {
	Snapshots   map[string]stQuarterSnapshot `json:"snapshots"`
	LastAttempt map[string]any               `json:"last_attempt,omitempty"`
}

func stSnapshotPath() (string, error) {
	dir, err := resolveDataDir()
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	return filepath.Join(dir, "st_snapshots.json"), nil
}

func readSTSnapshotState() (stSnapshotState, error) {
	path, err := stSnapshotPath()
	if err != nil {
		return stSnapshotState{}, err
	}
	raw, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return stSnapshotState{Snapshots: map[string]stQuarterSnapshot{}}, nil
	}
	if err != nil {
		return stSnapshotState{}, err
	}
	var state stSnapshotState
	if err := json.Unmarshal(raw, &state); err != nil {
		return stSnapshotState{}, err
	}
	if state.Snapshots == nil {
		state.Snapshots = map[string]stQuarterSnapshot{}
	}
	return state, nil
}

func writeSTSnapshotState(state stSnapshotState) error {
	path, err := stSnapshotPath()
	if err != nil {
		return err
	}
	raw, err := json.MarshalIndent(state, "", "  ")
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, raw, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func readSTSheetRecords(ctx context.Context, sheetID, cellRange string) ([][]string, error) {
	readCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
	defer cancel()
	cmd := exec.CommandContext(readCtx, "lark-cli", "sheets", "+csv-get", "--url", stSnapshotSourceURL, "--sheet-id", sheetID, "--range", cellRange, "--include-row-prefix=false", "--max-chars", "1000000")
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	raw, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("user-context Sheet read failed for %s: %s", sheetID, strings.TrimSpace(stderr.String()))
	}
	records, err := csv.NewReader(strings.NewReader(extractCSVText(raw))).ReadAll()
	if err != nil {
		return nil, fmt.Errorf("invalid Sheet CSV for %s: %w", sheetID, err)
	}
	return records, nil
}

func stRecordValue(record []string, headers map[string]int, name string) string {
	idx, ok := headers[name]
	if !ok || idx >= len(record) {
		return ""
	}
	return strings.TrimSpace(record[idx])
}

func stHeaders(record []string) map[string]int {
	out := map[string]int{}
	for i, value := range record {
		out[strings.TrimSpace(value)] = i
	}
	return out
}

func stApplicationIndex(records [][]string, headerRow int) (map[string]stSnapshotRow, error) {
	if len(records) <= headerRow {
		return nil, errors.New("application Sheet has no header")
	}
	headers := stHeaders(records[headerRow])
	for _, name := range []string{"Sales Region", "Brand Name", "Account ID", "Endorsement Reason", "Adex Submitter", "Start date"} {
		if _, ok := headers[name]; !ok {
			return nil, fmt.Errorf("application Sheet missing column %s", name)
		}
	}
	out := map[string]stSnapshotRow{}
	for _, record := range records[headerRow+1:] {
		id := stRecordValue(record, headers, "Account ID")
		if !decimalID.MatchString(id) {
			continue
		}
		if _, exists := out[id]; exists {
			continue
		}
		out[id] = stSnapshotRow{SalesRegion: stRecordValue(record, headers, "Sales Region"), BrandName: stRecordValue(record, headers, "Brand Name"), AccountID: id, EndorsementReason: stRecordValue(record, headers, "Endorsement Reason"), AdexSubmitter: stRecordValue(record, headers, "Adex Submitter"), StartDate: stRecordValue(record, headers, "Start date")}
	}
	return out, nil
}

func readSTApprovedSnapshotsFromLark(ctx context.Context, actor string) ([]stQuarterSnapshot, error) {
	approved, err := readSTSheetRecords(ctx, stApprovedSheetID, "A1:H5000")
	if err != nil {
		return nil, err
	}
	q4Records, err := readSTSheetRecords(ctx, "wKgK4I", "A1:G5000")
	if err != nil {
		return nil, err
	}
	q3Records, err := readSTSheetRecords(ctx, "a4a678", "A1:F5000")
	if err != nil {
		return nil, err
	}
	q4, err := stApplicationIndex(q4Records, 1)
	if err != nil {
		return nil, fmt.Errorf("Q4 metadata: %w", err)
	}
	q3, err := stApplicationIndex(q3Records, 0)
	if err != nil {
		return nil, fmt.Errorf("Q3 metadata: %w", err)
	}
	if len(approved) < 2 {
		return nil, errors.New("approved ST client Sheet is empty")
	}
	headers := stHeaders(approved[0])
	for _, name := range []string{"Region", "Brand Name", "Account Name", "Account ID", "Type"} {
		if _, ok := headers[name]; !ok {
			return nil, fmt.Errorf("approved ST client Sheet missing column %s", name)
		}
	}
	byQuarter := map[string][]stSnapshotRow{"Q3": {}, "Q4": {}}
	seen := map[string]bool{}
	for _, record := range approved[1:] {
		id := stRecordValue(record, headers, "Account ID")
		if !decimalID.MatchString(id) || seen[id] {
			continue
		}
		seen[id] = true
		quarter := "Q3"
		if strings.EqualFold(stRecordValue(record, headers, "Type"), "Newly added") {
			quarter = "Q4"
		}
		application := q3[id]
		anchor := "2026-06-30"
		if quarter == "Q4" {
			application = q4[id]
			anchor = "2026-09-30"
		}
		row := stSnapshotRow{Quarter: quarter, SalesRegion: stRecordValue(record, headers, "Region"), BrandName: stRecordValue(record, headers, "Brand Name"), AccountName: stRecordValue(record, headers, "Account Name"), AccountID: id, EndorsementReason: application.EndorsementReason, AdexSubmitter: application.AdexSubmitter, StartDate: anchor}
		if row.SalesRegion == "" {
			row.SalesRegion = application.SalesRegion
		}
		if row.BrandName == "" {
			row.BrandName = application.BrandName
		}
		byQuarter[quarter] = append(byQuarter[quarter], row)
	}
	if len(seen) == 0 {
		return nil, errors.New("approved ST client Sheet returned no valid Account IDs")
	}
	now := time.Now().UTC().Format(time.RFC3339)
	out := make([]stQuarterSnapshot, 0, 2)
	for _, quarter := range []string{"Q3", "Q4"} {
		out = append(out, stQuarterSnapshot{Quarter: quarter, PeriodBasis: map[string]string{"Q3": "Full Quarter", "Q4": "QTD"}[quarter], SheetName: stApprovedSheetName, SourceURL: stSnapshotSourceURL, SourceModifiedAt: now, SyncedBy: actor, Rows: byQuarter[quarter]})
	}
	return out, nil
}

func readSTQuarterFromLark(ctx context.Context, quarter, actor string) (stQuarterSnapshot, error) {
	quarter = strings.ToUpper(strings.TrimSpace(quarter))
	if quarter != "Q3" && quarter != "Q4" {
		return stQuarterSnapshot{}, errors.New("quarter must be Q3 or Q4")
	}
	snapshots, err := readSTApprovedSnapshotsFromLark(ctx, actor)
	if err != nil {
		return stQuarterSnapshot{}, err
	}
	for _, snapshot := range snapshots {
		if snapshot.Quarter == quarter {
			return snapshot, nil
		}
	}
	return stQuarterSnapshot{}, errors.New("quarter snapshot unavailable")
}

func syncSTSnapshotsFromLark(ctx context.Context, actor string) (stSnapshotState, error) {
	snapshots, err := readSTApprovedSnapshotsFromLark(ctx, actor)
	if err != nil {
		return readSTSnapshotStateWithAttempt(actor, err)
	}
	return saveSTSnapshots(snapshots, actor)
}

func readSTSnapshotStateWithAttempt(actor string, cause error) (stSnapshotState, error) {
	state, _ := readSTSnapshotState()
	state.LastAttempt = map[string]any{"status": "failed", "at": time.Now().UTC().Format(time.RFC3339), "by": actor, "error": cause.Error()}
	_ = writeSTSnapshotState(state)
	return state, cause
}

func validateSTSnapshot(s *stQuarterSnapshot) error {
	s.Quarter = strings.ToUpper(strings.TrimSpace(s.Quarter))
	if s.Quarter != "Q3" && s.Quarter != "Q4" {
		return errors.New("quarter must be Q3 or Q4")
	}
	expectedBasis := map[string]string{"Q3": "Full Quarter", "Q4": "QTD"}[s.Quarter]
	if strings.TrimSpace(s.PeriodBasis) != expectedBasis {
		return fmt.Errorf("%s period_basis must be %s", s.Quarter, expectedBasis)
	}
	if strings.TrimSpace(s.SourceURL) == "" {
		s.SourceURL = stSnapshotSourceURL
	}
	if len(s.Rows) == 0 {
		return errors.New("rows must not be empty")
	}
	deduped := make([]stSnapshotRow, 0, len(s.Rows))
	seen := map[string]bool{}
	for i, row := range s.Rows {
		row.Quarter = s.Quarter
		row.AccountID = strings.TrimSpace(row.AccountID)
		if strings.TrimSpace(row.SalesRegion) == "" || strings.TrimSpace(row.BrandName) == "" || row.AccountID == "" {
			return fmt.Errorf("row %d missing Sales Region, Brand Name or Account ID", i+1)
		}
		if seen[row.AccountID] {
			continue
		}
		seen[row.AccountID] = true
		deduped = append(deduped, row)
	}
	s.Rows = deduped
	s.Fields = []string{"Sales Region", "Brand Name", "Account Name", "Account ID", "Endorsement Reason", "Adex Submitter", "Start date", "Quarter"}
	s.RowCount = len(s.Rows)
	s.SyncResult = "success"
	s.MetricSemantics = "Membership is filtered by the Approved ST Clients list and deduplicated by Account ID. Q4 newly added rows use 2026-09-30; retained approved rows use Q3 anchor 2026-06-30. Application tabs enrich submitter and endorsement reason only."
	s.FieldSemantics = map[string]string{"Brand Name": "brand metadata; not Account Name", "Account Name": "approved-list account name", "Start date": "formal quarter protection anchor", "Endorsement Reason": "application reason; not Reported Reasons"}
	return nil
}

func saveSTSnapshots(in []stQuarterSnapshot, actor string) (stSnapshotState, error) {
	state, err := readSTSnapshotState()
	if err != nil {
		return state, err
	}
	now := time.Now().UTC().Format(time.RFC3339)
	validated := make([]stQuarterSnapshot, len(in))
	copy(validated, in)
	for i := range validated {
		if err := validateSTSnapshot(&validated[i]); err != nil {
			state.LastAttempt = map[string]any{"status": "failed", "at": now, "by": actor, "error": err.Error()}
			_ = writeSTSnapshotState(state)
			return state, err
		}
		validated[i].SyncedAt, validated[i].SyncedBy = now, actor
	}
	for _, snapshot := range validated {
		state.Snapshots[snapshot.Quarter] = snapshot
	}
	state.LastAttempt = map[string]any{"status": "success", "at": now, "by": actor, "quarters": len(validated)}
	return state, writeSTSnapshotState(state)
}

func loadSTFromSnapshot(quarter string) ([]stMetric, map[string]any, error) {
	state, err := readSTSnapshotState()
	if err != nil {
		return nil, nil, fmt.Errorf("unavailable: read saved ST snapshot: %w", err)
	}
	snapshot, ok := state.Snapshots[strings.ToUpper(strings.TrimSpace(quarter))]
	if !ok || snapshot.SyncResult != "success" {
		return nil, nil, errors.New("unavailable: no successful saved ST snapshot")
	}
	metrics := make([]stMetric, 0, len(snapshot.Rows))
	for _, row := range snapshot.Rows {
		region, brand, accountID := strings.TrimSpace(row.SalesRegion), strings.TrimSpace(row.BrandName), strings.TrimSpace(row.AccountID)
		if region == "" || (brand == "" && accountID == "") {
			continue
		}
		metrics = append(metrics, stMetric{Region: region, Brand: brand, AccountID: accountID})
	}
	previewLimit := 200
	if len(snapshot.Rows) < previewLimit {
		previewLimit = len(snapshot.Rows)
	}
	preview := snapshot.Rows[:previewLimit]
	meta := map[string]any{"quarter": snapshot.Quarter, "period_basis": snapshot.PeriodBasis, "sheet_name": snapshot.SheetName, "source_url": snapshot.SourceURL, "source_modified_at": snapshot.SourceModifiedAt, "source_revision": snapshot.SourceRevision, "synced_at": snapshot.SyncedAt, "synced_by": snapshot.SyncedBy, "sync_result": snapshot.SyncResult, "fields": snapshot.Fields, "field_semantics": snapshot.FieldSemantics, "row_count": snapshot.RowCount, "metric_semantics": snapshot.MetricSemantics, "rows": preview, "rows_returned": len(preview), "last_attempt": state.LastAttempt}
	return metrics, meta, nil
}

func stSnapshotSummaries(state stSnapshotState) []map[string]any {
	keys := make([]string, 0, len(state.Snapshots))
	for key := range state.Snapshots {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	out := make([]map[string]any, 0, len(keys))
	for _, key := range keys {
		s := state.Snapshots[key]
		out = append(out, map[string]any{"quarter": s.Quarter, "period_basis": s.PeriodBasis, "row_count": s.RowCount, "source_modified_at": s.SourceModifiedAt, "synced_at": s.SyncedAt, "sync_result": s.SyncResult, "source_url": s.SourceURL})
	}
	return out
}
