package main

import (
	"bytes"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

func cwFixture(t *testing.T) (cwCase, cwConfig) {
	t.Helper()
	wbTestEnv(t)
	cfg, e := cwLoadConfig()
	if e != nil {
		t.Fatal(e)
	}
	cfg.Operators = []string{"operator"}
	cfg.Members = []cwMember{{Username: "owner", OpenID: "ou_owner"}, {Username: "operator", OpenID: "ou_operator"}, {Username: "reviewer", OpenID: "ou_reviewer"}}
	oldSheet, oldResolver := cwFetchMappingSheet, cwResolveBotOpenID
	cwFetchMappingSheet = func(context.Context) (cwSheetSnapshot, error) {
		return cwSheetSnapshot{Revision: "13", Values: [][]string{mappingHeader, {"APAC", "owner", "owner@example.com", "Owner", "已确认", "fixture", "2026-10-20"}}}, nil
	}
	cwResolveBotOpenID = func(context.Context, string) (string, string) { return "ou_formal", "resolved" }
	t.Cleanup(func() { cwFetchMappingSheet = oldSheet; cwResolveBotOpenID = oldResolver })
	cfg.NotificationMode = "test"
	cfg.TestRecipients = []cwRecipient{{ID: "oc_test", Type: "chat_id", Label: "测试群"}, {ID: "ou_owner", Type: "open_id", Label: "测试负责人"}}
	dir := t.TempDir()
	if e = os.MkdirAll(filepath.Join(dir, "config"), 0700); e != nil {
		t.Fatal(e)
	}
	b, _ := json.Marshal(cfg)
	os.WriteFile(filepath.Join(dir, "config/casework.json"), b, 0600)
	pluginDir = dir
	t.Setenv("TAP_FEISHU_APP_ID", "cli_test")
	t.Setenv("TAP_FEISHU_APP_SECRET", "secret-test")
	t.Setenv("TAP_FEISHU_VERIFICATION_TOKEN", "verify-test")
	t.Setenv("TAP_FEISHU_ENCRYPT_KEY", "encrypt-test")
	t.Setenv("TAP_FEISHU_TENANT_KEY", "tenant-test")
	row := wbRow{ID: "risk-row", Program: "ET", Member: wbMember{AccountID: "7675782032500424721", Name: "Test fixture customer", Submitter: "owner", TicketID: "ticket1", Region: "APAC"}, CCR: f64(46), NFS: f64(60), Level: "critical", MetricStatus: "success"}
	j := wbJob{ID: "scan1", Principal: "operator", Status: "ready", Request: wbRequest{Program: "ET", Start: "2026-10-01", End: "2026-10-15"}, Rule: testRule()}
	a, e := cwCreate(j, row)
	if e != nil {
		t.Fatal(e)
	}
	return a, cfg
}
func TestCaseworkGrowthRiskEligibilityMatchesReadModel(t *testing.T) {
	_, _ = cwFixture(t)
	growth := 52.5
	growthRow := wbRow{
		ID: "growth-risk-row", Program: "ET", Level: "normal", MetricStatus: "success",
		Member: wbMember{AccountID: "7000000000000000101", Submitter: "owner", TicketID: "growth-ticket", Region: "APAC", Tier: "Emerging"},
		CCR:    f64(2), NFS: f64(3), Comparison: wbComparison{Status: metricAvailable, CCRGrowthPct: &growth},
	}
	normalRow := wbRow{
		ID: "normal-row", Program: "ET", Level: "normal", MetricStatus: "success",
		Member: wbMember{AccountID: "7000000000000000102", Submitter: "owner", TicketID: "normal-ticket", Region: "APAC", Tier: "Emerging"},
		CCR:    f64(2), NFS: f64(3), Comparison: wbComparison{Status: "unavailable"},
	}
	job := wbJob{ID: "completed-growth-scan", Principal: "operator", Status: "running", Complete: false, Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rule: testRule(), Policy: wbDefaultPolicy(), Rows: []wbRow{growthRow, normalRow}}

	created, err := cwCreate(job, growthRow)
	if err != nil {
		t.Fatalf("growth risk shown by read model must be eligible for casework: %v", err)
	}
	if created.Row.Level != "watch" && created.Row.Level != "critical" {
		t.Fatalf("governed risk classification was not persisted: %+v", created.Row)
	}
	if _, err = cwCreate(job, normalRow); err == nil || !strings.Contains(err.Error(), "真实命中") {
		t.Fatalf("normal non-risk row must remain ineligible: %v", err)
	}
}

func cwTestCmd(a cwCase, id, op string) cwCommand {
	return cwCommand{ExpectedVersion: a.Version, RequestID: id, Operation: op, Note: "Verified fixture note", Fields: map[string]string{}}
}
func cwTestRequest(user, body string) *http.Request {
	r := wbReq(user)
	r.Body = io.NopCloser(strings.NewReader(body))
	return r
}
func TestCaseworkDedupSharedIdentityAndACL(t *testing.T) {
	a, cfg := cwFixture(t)
	j := wbJob{ID: "different-scan", Principal: "different-scanner", Status: "ready", Request: a.Window, Rule: a.Rule}
	b, e := cwCreate(j, a.Row)
	if e != nil || a.ID != b.ID || b.Creator != a.Creator {
		t.Fatalf("dedup %v %+v", e, b)
	}
	if !cwCanRead(cfg, b, "owner") || !cwCanRead(cfg, b, "operator") || !cwCanRead(cfg, b, "stranger") {
		t.Fatal("ACL broken")
	}
	w := httptest.NewRecorder()
	cwListHandler(w, wbReq("stranger"))
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"total":1`) {
		t.Fatal(w.Body.String())
	}
	db, _ := cwDB()
	defer db.Close()
	read, e := cwRead(db, a.ID)
	if e != nil || read.ID != a.ID {
		t.Fatal("not persisted")
	}
}
func TestCaseworkRequiredFieldsIdempotencyAndStaleRevision(t *testing.T) {
	a, _ := cwFixture(t)
	cmd := cwTestCmd(a, "p1", "plan")
	cmd.Plan = "tap_remove"
	if _, e := cwMutate(a.ID, cmd, "owner", "workbench"); e == nil {
		t.Fatal("accepted missing form fields")
	}
	cmd.Fields = map[string]string{"rca": "客户实锤违规", "explanation": "policy evidence", "result": "removed", "due_date": "2026-10-24"}
	b, e := cwMutate(a.ID, cmd, "owner", "workbench")
	if e != nil || b.Status != "closed" {
		t.Fatal(e)
	}
	if b.EducationCompleted {
		t.Fatal("TAP removal must not count as customer education")
	}
	again, e := cwMutate(a.ID, cmd, "owner", "workbench")
	if e != nil || again.Version != b.Version || len(again.History) != 2 {
		t.Fatal("duplicate mutated state", e)
	}
	cmd.Note = "changed same id"
	if _, e = cwMutate(a.ID, cmd, "owner", "workbench"); e == nil {
		t.Fatal("reused key changed payload")
	}
	stale := cwTestCmd(a, "stale", "accept")
	if _, e = cwMutate(a.ID, stale, "operator", "workbench"); e == nil {
		t.Fatal("old version overwritten")
	}
}
func TestCaseworkDirectDispositionCannotBeEditedAfterClose(t *testing.T) {
	a, _ := cwFixture(t)
	cmd := cwTestCmd(a, "p", "plan")
	cmd.Plan = "continue_observe"
	cmd.Fields = map[string]string{"rca": "无任何风险", "explanation": "weekly evidence reviewed", "result": "observe", "due_date": "2026-10-24"}
	a, e := cwMutate(a.ID, cmd, "owner", "workbench")
	if e != nil || a.Status != "closed" || a.ClosureReason != "direct_disposition" {
		t.Fatalf("direct disposition failed %+v %v", a, e)
	}
	next := cwTestCmd(a, "cannot-edit-closed", "plan")
	next.Plan = "continue_observe"
	next.Fields = cmd.Fields
	if _, e = cwMutate(a.ID, next, "owner", "workbench"); e == nil {
		t.Fatal("closed alert edited")
	}
}
func TestCaseworkReviewerAndQuotaActions(t *testing.T) {
	a, cfg := cwFixture(t)
	a.Reviewer = "reviewer"
	a.Status = "pending_review"
	a.ReviewRequestedBy = "owner"
	cmd := cwTestCmd(a, "close", "close")
	cmd.ClosureReason = "not_applicable"
	cmd.Fields["evidence"] = "reviewed"
	if e := cwApply(&a, cmd, "reviewer", "workbench", cfg); e != nil {
		t.Fatal(e)
	}
	a.Kind = "quota"
	a.Status = "open"
	cmd = cwTestCmd(a, "q", "plan")
	cmd.Plan = "tap_remove"
	cmd.Fields = map[string]string{"rca": "客户实锤违规", "explanation": "x", "result": "y"}
	if e := cwApply(&a, cmd, "owner", "workbench", cfg); e == nil {
		t.Fatal("quota case accepted customer disposition")
	}
}
func TestCaseworkRecoveryRequiresIndependentSuccessfulWindow(t *testing.T) {
	a, cfg := cwFixture(t)
	a.Status = "pending_review"
	a.ReviewRequestedBy = "owner"
	cmd := cwTestCmd(a, "close", "close")
	cmd.ClosureReason = "risk_recovered"
	cmd.Fields["evidence"] = "review"
	a.Rechecks = []cwRecheck{{Start: "2026-10-01", End: "2026-10-15", Status: "success", Level: "normal", CCR: f64(1), NFS: f64(2)}}
	if e := cwApply(&a, cmd, "operator", "workbench", cfg); e == nil {
		t.Fatal("overlapping QTD treated as recovery")
	}
	a.Rechecks[0].Start = "2026-10-16"
	a.Rechecks[0].Status = "failed"
	if e := cwApply(&a, cmd, "operator", "workbench", cfg); e == nil {
		t.Fatal("failed recheck treated as recovery")
	}
	a.Rechecks[0].Status = "success"
	if e := cwApply(&a, cmd, "operator", "workbench", cfg); e != nil || a.Status != "closed" {
		t.Fatal(e)
	}
}

type cwRoundTripper func(*http.Request) (*http.Response, error)

func (f cwRoundTripper) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func cwFakeResponse(body string) *http.Response {
	return &http.Response{StatusCode: 200, Body: io.NopCloser(strings.NewReader(body)), Header: make(http.Header)}
}
func TestCaseworkOutboxRealMessageIDUpdateAndRetry(t *testing.T) {
	a, _ := cwFixture(t)
	old := cwHTTPClient
	oldSheet, oldResolve := cwFetchMappingSheet, cwResolveBotOpenID
	defer func() { cwHTTPClient = old; cwFetchMappingSheet = oldSheet; cwResolveBotOpenID = oldResolve }()
	cwFetchMappingSheet = func(context.Context) (cwSheetSnapshot, error) {
		return cwSheetSnapshot{Revision: "13", Values: [][]string{{"区域", "业务表原始姓名", "已确认企业邮箱", "风神姓名", "匹配状态", "匹配依据/备注", "最近验证时间"}, {"APAC", "owner", "owner@example.com", "Owner", "已确认", "fixture", "2026-10-20"}}}, nil
	}
	cwResolveBotOpenID = func(context.Context, string) (string, string) { return "ou_formal", "resolved" }
	cwTokenValue = ""
	sends, patches := 0, 0
	fail := true
	cwHTTPClient = &http.Client{Transport: cwRoundTripper(func(r *http.Request) (*http.Response, error) {
		if strings.Contains(r.URL.Path, "tenant_access_token") {
			return cwFakeResponse(`{"code":0,"tenant_access_token":"token","expire":7200}`), nil
		}
		if r.Header.Get("Authorization") != "Bearer token" {
			t.Fatal("missing token")
		}
		if r.Method == "PATCH" {
			patches++
			return cwFakeResponse(`{"code":0}`), nil
		}
		sends++
		if fail {
			return nil, fmt.Errorf("simulated timeout")
		}
		var payload map[string]any
		json.NewDecoder(r.Body).Decode(&payload)
		if payload["receive_id"] != "ou_owner" || payload["msg_type"] != "interactive" || len(asString(payload["uuid"])) != 32 {
			t.Fatal(payload)
		}
		return cwFakeResponse(`{"code":0,"data":{"message_id":"om_real_fixture"}}`), nil
	})}
	body := testConfirmedNotificationBody(t, a, "owner", "ou_owner")
	r := cwTestRequest("owner", body)
	r.SetPathValue("id", a.ID)
	w := httptest.NewRecorder()
	cwNotifyHandler(w, r)
	if w.Code != 202 {
		t.Fatal(w.Body.String())
	}
	cwProcessOutbox()
	db, _ := cwDB()
	n, _ := cwNotices(db, a.ID)
	if len(n) != 1 || n[0].Status != "failed" || n[0].MessageID != "" {
		t.Fatal(n)
	}
	// A failed send cannot retry merely because time passes.
	cwProcessOutbox()
	if sends != 1 {
		t.Fatal("test notification auto-retried")
	}
	latest, _ := cwRead(db, a.ID)
	retryBody := testConfirmedNotificationBody(t, latest, "owner", "ou_owner")
	retryRequest := cwTestRequest("owner", retryBody)
	retryRequest.SetPathValue("id", a.ID)
	retryResponse := httptest.NewRecorder()
	cwNotifyHandler(retryResponse, retryRequest)
	if retryResponse.Code != 202 {
		t.Fatal(retryResponse.Body.String())
	}
	fail = false
	cwProcessOutbox()
	n, _ = cwNotices(db, a.ID)
	var rawStatus, rawMessageID string
	_ = db.QueryRow("SELECT status,message_id FROM tap_outbox WHERE case_id=? AND kind='send'", a.ID).Scan(&rawStatus, &rawMessageID)
	if rawStatus != "sent" || rawMessageID != "om_real_fixture" || n[0].MessageID != "om_real_fixture" {
		t.Fatal(n)
	}
	fresh, _ := cwRead(db, a.ID)
	cmd := cwTestCmd(fresh, "accept", "accept")
	_, e := cwMutate(a.ID, cmd, "owner", "workbench")
	if e != nil {
		t.Fatal(e)
	}
	cwProcessOutbox()
	if patches != 1 || sends != 2 {
		t.Fatalf("sends=%d patches=%d", sends, patches)
	}
	db.Close()
}
func cwSignedCallback(t *testing.T, payload any) *http.Request {
	t.Helper()
	plain, _ := json.Marshal(payload)
	padding := 16 - len(plain)%16
	plain = append(plain, bytes.Repeat([]byte{byte(padding)}, padding)...)
	h := sha256.Sum256([]byte(os.Getenv("TAP_FEISHU_ENCRYPT_KEY")))
	block, _ := aes.NewCipher(h[:])
	iv := bytes.Repeat([]byte{7}, 16)
	encrypted := make([]byte, len(plain))
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(encrypted, plain)
	envelope, _ := json.Marshal(map[string]string{"encrypt": base64.StdEncoding.EncodeToString(append(iv, encrypted...))})
	r := httptest.NewRequest("POST", "/api/integrations/feishu/card-callback", bytes.NewReader(envelope))
	ts := strconv.FormatInt(time.Now().Unix(), 10)
	nonce := "fixture-nonce"
	sum := sha256.Sum256(append([]byte(ts+nonce+os.Getenv("TAP_FEISHU_ENCRYPT_KEY")), envelope...))
	r.Header.Set("X-Lark-Request-Timestamp", ts)
	r.Header.Set("X-Lark-Request-Nonce", nonce)
	r.Header.Set("X-Lark-Signature", hex.EncodeToString(sum[:]))
	return r
}
func cwCallbackFixture(a cwCase, eventID, openID string, version int) map[string]any {
	return map[string]any{"schema": "2.0", "header": map[string]any{"event_id": eventID, "event_type": "card.action.trigger", "token": "verify-test", "app_id": "cli_test", "tenant_key": "tenant-test"}, "event": map[string]any{"operator": map[string]any{"open_id": openID}, "context": map[string]any{"open_message_id": "om_test"}, "action": map[string]any{"value": map[string]string{"alert_id": a.ID, "version": strconv.Itoa(version)}, "form_value": map[string]any{"operation": "accept", "note": "Bot accepted"}}}}
}
func TestCaseworkEncryptedCallbackIdentityIdempotencyAndOldCards(t *testing.T) {
	a, _ := cwFixture(t)
	db, _ := cwDB()
	db.Exec("INSERT INTO tap_outbox(id,case_id,recipient,kind,status,message_id,created_at,updated_at) VALUES('n',?,'chat_id:oc_test','send','sent','om_test',?,?)", a.ID, cwNow(), cwNow())
	db.Close()
	run := func(payload any) *httptest.ResponseRecorder {
		w := httptest.NewRecorder()
		cwCallbackHandler(w, cwSignedCallback(t, payload))
		return w
	}
	bad := cwSignedCallback(t, cwCallbackFixture(a, "bad", "ou_owner", 1))
	bad.Header.Set("X-Lark-Signature", "bad")
	w := httptest.NewRecorder()
	cwCallbackHandler(w, bad)
	if w.Code != 401 {
		t.Fatal("unsigned callback accepted")
	}
	w = run(map[string]string{"type": "url_verification", "token": "verify-test", "challenge": "challenge-test"})
	if !strings.Contains(w.Body.String(), `"challenge":"challenge-test"`) {
		t.Fatal(w.Body.String())
	}
	w = run(cwCallbackFixture(a, "unknown", "ou_unknown", 1))
	if !strings.Contains(w.Body.String(), "未映射") {
		t.Fatal(w.Body.String())
	}
	first := cwCallbackFixture(a, "event1", "ou_owner", 1)
	begin := time.Now()
	w = run(first)
	if w.Code != 200 || !strings.Contains(w.Body.String(), "已保存至共享台账") || time.Since(begin) > 3*time.Second {
		t.Fatal(w.Body.String())
	}
	w = run(first)
	if !strings.Contains(w.Body.String(), "已保存至共享台账") {
		t.Fatal("duplicate failed", w.Body.String())
	}
	db, _ = cwDB()
	fresh, _ := cwRead(db, a.ID)
	db.Close()
	if fresh.Version != 2 || len(fresh.History) != 2 || fresh.History[1].Source != "feishu" {
		t.Fatal(fresh)
	}
	w = run(cwCallbackFixture(a, "event2", "ou_owner", 1))
	if !strings.Contains(w.Body.String(), "记录已更新") {
		t.Fatal("old card accepted", w.Body.String())
	}
}
func TestCaseworkConcurrentCommandsOnlyOneWins(t *testing.T) {
	a, _ := cwFixture(t)
	var wg sync.WaitGroup
	var mu sync.Mutex
	won := 0
	for i := 0; i < 2; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			cmd := cwTestCmd(a, fmt.Sprintf("concurrent-%d", i), "accept")
			_, e := cwMutate(a.ID, cmd, "owner", "workbench")
			if e == nil {
				mu.Lock()
				won++
				mu.Unlock()
			}
		}(i)
	}
	wg.Wait()
	if won != 1 {
		t.Fatalf("expected one winner: %d", won)
	}
}
func TestCaseworkRecheckUsesCurrentIdentityAndRecordsMissingAsMissing(t *testing.T) {
	a, _ := cwFixture(t)
	old := wbQueryCurrent
	defer func() { wbQueryCurrent = old }()
	wbQueryCurrent = func(_ context.Context, r *http.Request, q etCCRDiagnosticRequest) (map[string]any, int) {
		if requestUsername(r) != "owner" || q.AccountID != a.Row.Member.AccountID {
			t.Fatal("wrong identity/id")
		}
		return map[string]any{"status": "no_data"}, 200
	}
	body := fmt.Sprintf(`{"expected_version":%d,"start_date":"2026-10-16","end_date":"2026-10-17","comparability_note":"fixture independent window"}`, a.Version)
	r := cwTestRequest("owner", body)
	r.SetPathValue("id", a.ID)
	w := httptest.NewRecorder()
	cwRecheckHandler(w, r)
	if w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	db, _ := cwDB()
	defer db.Close()
	b, e := cwRead(db, a.ID)
	if e != nil || len(b.Rechecks) != 1 || b.Rechecks[0].CCR != nil || b.Rechecks[0].Status != "failed" {
		t.Fatal(b, e)
	}
}

func TestCaseworkThresholdDispositionClosesWithoutApproval(t *testing.T) {
	a, cfg := cwFixture(t)
	cmd := cwTestCmd(a, "threshold-plan", "plan")
	cmd.Plan = "update_threshold"
	cmd.Fields = map[string]string{"rca": "预警阈值问题", "explanation": "threshold evidence", "result": "threshold update requested", "due_date": "2026-10-24"}
	if e := cwApply(&a, cmd, "owner", "workbench", cfg); e != nil || a.Status != "closed" || a.ClosedAt == "" {
		t.Fatalf("threshold disposition not closed: %+v %v", a, e)
	}
}

func TestCwHTTPBodyAndContentTypeSemantics(t *testing.T) {
	oldBase, oldClient := cwAPIBaseForRequest, cwHTTPClient
	defer func() { cwAPIBaseForRequest = oldBase; cwHTTPClient = oldClient }()

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw, err := io.ReadAll(r.Body)
		if err != nil {
			t.Fatal(err)
		}
		switch r.URL.Path {
		case "/get":
			if r.Method != http.MethodGet {
				t.Errorf("GET method=%s", r.Method)
			}
			if len(raw) != 0 {
				t.Errorf("GET body=%q, want empty", raw)
			}
			if got := r.Header.Get("Content-Type"); got != "" {
				t.Errorf("GET Content-Type=%q, want empty", got)
			}
		case "/post":
			if r.Method != http.MethodPost {
				t.Errorf("POST method=%s", r.Method)
			}
			if string(raw) != `{"name":"fixture"}` {
				t.Errorf("POST body=%q", raw)
			}
			if got := r.Header.Get("Content-Type"); got != "application/json" {
				t.Errorf("POST Content-Type=%q", got)
			}
		default:
			t.Errorf("unexpected path %s", r.URL.Path)
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"code":0,"data":{}}`))
	}))
	defer server.Close()
	cwAPIBaseForRequest = func() string { return server.URL }
	cwHTTPClient = server.Client()

	if _, err := cwHTTP(context.Background(), http.MethodGet, "/get", "token", nil); err != nil {
		t.Fatal(err)
	}
	if _, err := cwHTTP(context.Background(), http.MethodPost, "/post", "token", map[string]string{"name": "fixture"}); err != nil {
		t.Fatal(err)
	}
}

func TestCaseworkCurrentWindowUsesLatestCompletedNaturalWeek(t *testing.T) {
	fixtureCase, _ := cwFixture(t)
	currentWindow := wbRequest{Program: "ET", Start: "2026-10-12", End: "2026-10-18"}
	completed := wbJob{ID: "scan-current-et", BatchID: "TAP-WEEK-2026-10-12-2026-10-18", Principal: wbSchedulerPrincipal, Status: "ready", Request: currentWindow, Rule: testRule()}
	if err := wbSaveJob(&completed); err != nil {
		t.Fatal(err)
	}
	failedLater := wbJob{ID: "scan-failed-later", BatchID: "TAP-WEEK-2026-10-19-2026-10-25", Principal: wbSchedulerPrincipal, Status: "failed", Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rule: testRule()}
	if err := wbSaveJob(&failedLater); err != nil {
		t.Fatal(err)
	}

	etRow := fixtureCase.Row
	etRow.ID = "risk-row-current-et"
	etRow.Member.AccountID = "7675782032500424999"
	etRow.Member.TicketID = "ticket-current-et"
	currentET, err := cwCreate(completed, etRow)
	if err != nil {
		t.Fatal(err)
	}
	thtRow := etRow
	thtRow.ID = "risk-row-current-tht"
	thtRow.Program = "THT"
	thtRow.Member.AccountID = "7675782032500424888"
	thtRow.Member.TicketID = "ticket-current-tht"
	thtJob := completed
	thtJob.ID = "scan-current-tht"
	thtJob.Request.Program = "THT"
	currentTHT, err := cwCreate(thtJob, thtRow)
	if err != nil {
		t.Fatal(err)
	}

	// Create the legacy trial event last so its create/update activity is newer.
	// Its later end date must not promote it over the formal completed week.
	legacyRow := fixtureCase.Row
	legacyRow.ID = "risk-row-legacy-trial"
	legacyRow.Member.AccountID = "7675782032500424777"
	legacyRow.Member.TicketID = "ticket-legacy-trial"
	legacyJob := wbJob{ID: "scan-legacy-trial", Principal: "operator", Status: "ready", Request: wbRequest{Program: "ET", Start: "2026-10-01", End: "2026-10-21"}, Rule: testRule()}
	legacyCase, err := cwCreate(legacyJob, legacyRow)
	if err != nil {
		t.Fatal(err)
	}

	request := httptest.NewRequest("GET", "/api/workbench/cases?case_scope=current", nil).WithContext(wbReq("stranger").Context())
	w := httptest.NewRecorder()
	cwListHandler(w, request)
	body := w.Body.String()
	if w.Code != 200 || !strings.Contains(body, `"total":2`) || !strings.Contains(body, currentET.ID) || !strings.Contains(body, currentTHT.ID) || strings.Contains(body, legacyCase.ID) || strings.Contains(body, fixtureCase.ID) {
		t.Fatalf("current scope did not isolate the completed formal week: %s", body)
	}
	if !strings.Contains(body, `"start_date":"2026-10-12"`) || !strings.Contains(body, `"end_date":"2026-10-18"`) || !strings.Contains(body, `"source":"completed_scan"`) {
		t.Fatalf("wrong active window: %s", body)
	}

	request = httptest.NewRequest("GET", "/api/workbench/cases?case_scope=all", nil).WithContext(wbReq("stranger").Context())
	w = httptest.NewRecorder()
	cwListHandler(w, request)
	body = w.Body.String()
	if w.Code != 200 || !strings.Contains(body, `"total":4`) || !strings.Contains(body, fixtureCase.ID) || !strings.Contains(body, legacyCase.ID) || !strings.Contains(body, currentET.ID) || !strings.Contains(body, currentTHT.ID) {
		t.Fatalf("history was removed or hidden from all scope: %s", body)
	}

	request = httptest.NewRequest("GET", "/api/workbench/cases?case_scope=invalid", nil).WithContext(wbReq("stranger").Context())
	w = httptest.NewRecorder()
	cwListHandler(w, request)
	if w.Code != http.StatusBadRequest || !strings.Contains(w.Body.String(), "case_scope must be current or all") {
		t.Fatalf("invalid scope status=%d body=%s", w.Code, w.Body.String())
	}
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	var count int
	if err = db.QueryRow("SELECT COUNT(*) FROM tap_cases").Scan(&count); err != nil || count != 4 {
		t.Fatalf("historical rows changed: count=%d err=%v", count, err)
	}
}

func TestCaseworkCurrentWindowFallbackIsDeterministic(t *testing.T) {
	wbTestEnv(t)
	cases := []cwCase{
		{Window: wbRequest{Start: "2026-10-01", End: "2026-10-21"}, UpdatedAt: "2026-10-30T00:00:00Z"},
		{Window: wbRequest{Start: "2026-10-12", End: "2026-10-18"}, UpdatedAt: "2026-10-20T00:00:00Z"},
	}
	start, end, source := cwSelectActiveWindow(cases)
	if start != "2026-10-12" || end != "2026-10-18" || source != "case_week_fallback" {
		t.Fatalf("complete-week fallback selected %s..%s source=%s", start, end, source)
	}
	cases = []cwCase{
		{Window: wbRequest{Start: "2026-09-01", End: "2026-09-20"}, UpdatedAt: "2026-10-30T00:00:00Z"},
		{Window: wbRequest{Start: "2026-10-01", End: "2026-10-21"}, UpdatedAt: "2026-10-01T00:00:00Z"},
	}
	start, end, source = cwSelectActiveWindow(cases)
	if start != "2026-10-01" || end != "2026-10-21" || source != "legacy_window_fallback" {
		t.Fatalf("legacy fallback selected %s..%s source=%s", start, end, source)
	}
}

func TestMappedSubmitterCanDirectCloseWithOptionalNoteAndNotificationHistory(t *testing.T) {
	a, cfg := cwFixture(t)
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	_, err = db.Exec(`INSERT INTO tap_identity_mappings(record_id,business_name,email,aeolus_name,match_status,enabled,manual_disabled) VALUES('mapped-handler','owner','mapped-handler@example.com','Mapped Handler','已确认',1,0)`)
	if err != nil {
		db.Close()
		t.Fatal(err)
	}
	_, err = db.Exec("INSERT INTO tap_outbox(id,case_id,recipient,kind,status,message_id,created_at,updated_at,target_email) VALUES('history',?,'open_id:ou_test','send','sent','om_history',?,?,?)", a.ID, cwNow(), cwNow(), "mapped-handler@example.com")
	db.Close()
	if err != nil {
		t.Fatal(err)
	}
	if !cwCanHandle(cfg, a, "mapped-handler") {
		t.Fatal("verified mapped submitter was not authorized")
	}
	permissionRequest := wbReq("mapped-handler")
	permissionRequest.SetPathValue("id", a.ID)
	permissionResponse := httptest.NewRecorder()
	cwGetHandler(permissionResponse, permissionRequest)
	if permissionResponse.Code != 200 || !strings.Contains(permissionResponse.Body.String(), `"can_handle":true`) {
		t.Fatalf("case detail did not expose server permission: %s", permissionResponse.Body.String())
	}
	cmd := cwTestCmd(a, "mapped-direct-close", "plan")
	cmd.Note = ""
	cmd.Plan = "continue_observe"
	cmd.Fields = map[string]string{"rca": "预警阈值问题"}
	closed, err := cwMutate(a.ID, cmd, "mapped-handler", "workbench")
	if err != nil {
		t.Fatal(err)
	}
	if closed.Status != "closed" || closed.ClosedBy != "mapped-handler" || closed.ClosedAt == "" || closed.Plan != "continue_observe" || closed.Fields["rca"] != "预警阈值问题" {
		t.Fatalf("direct close did not persist final disposition: %+v", closed)
	}
	db, _ = cwDB()
	notices, noticeErr := cwNotices(db, a.ID)
	db.Close()
	var sentNotice *cwNotice
	for i := range notices {
		if notices[i].Kind == "send" {
			sentNotice = &notices[i]
		}
	}
	if noticeErr != nil || sentNotice == nil || sentNotice.MessageID != "om_history" || sentNotice.Status != "sent" {
		t.Fatalf("closing lost notification history: %+v %v", notices, noticeErr)
	}
	if stage := wbEventStage(&closed, notices); stage != "closed" {
		t.Fatalf("read model did not reflect closure: %s", stage)
	}
	day := strings.Split(closed.CreatedAt, "T")[0]
	analytics, analyticsErr := cwAnalyticsBuild(cwAnalyticsFilter{Start: day, End: day})
	if analyticsErr != nil {
		t.Fatal(analyticsErr)
	}
	if analytics.Summary["closed"] != 1 || len(analytics.Action) != 1 || analytics.Action[0].Key != "continue_observe" || analytics.Attribution[0].Key != "预警阈值问题" || analytics.EffectStatus["waiting_recheck"] != 1 {
		t.Fatalf("analytics did not use final action/RCA: %+v", analytics)
	}
}

func TestGovernanceE2EStateMachineTemplateAndLedgerAnalytics(t *testing.T) {
	a, cfg := cwFixture(t)
	if cfg.AutoSendEnabled {
		t.Fatal("fixture must retain auto_send=false")
	}

	confirm := cwTestCmd(a, "e2e-operator-confirm", "operator_confirm")
	confirm.Owner = "owner"
	confirmed, err := cwMutate(a.ID, confirm, "operator", "workbench")
	if err != nil || confirmed.Status != "processing" || confirmed.Owner != "owner" {
		t.Fatalf("operator confirmation failed: %+v %v", confirmed, err)
	}
	if _, err = cwMutate(a.ID, cwTestCmd(confirmed, "e2e-repeat-confirm", "operator_confirm"), "operator", "workbench"); err == nil {
		t.Fatal("invalid repeated operator transition accepted")
	}

	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	if _, err = db.Exec(`INSERT INTO tap_outbox(id,case_id,recipient,kind,status,message_id,notification_mode,source,mode,result,created_at,updated_at) VALUES(?,?,?,'send','sent',?,'test','manual','test','sent',?,?)`, "e2e-ledger-notice", a.ID, "open_id:ou_owner", "om_e2e_ledger", cwNow(), cwNow()); err != nil {
		db.Close()
		t.Fatal(err)
	}
	notices, err := cwNotices(db, a.ID)
	db.Close()
	if err != nil || wbEventStage(&confirmed, notices) != "pending_submitter" {
		t.Fatalf("submitter stage missing: notices=%+v err=%v", notices, err)
	}

	complete := cwTestCmd(confirmed, "e2e-submitter-complete", "submitter_complete")
	complete.Fields = map[string]string{"evidence": "account owner remediation evidence", "rca": "客户实锤违规"}
	completed, err := cwMutate(a.ID, complete, "owner", "workbench")
	if err != nil || completed.Status != "pending_review" || !completed.ActionCompleted {
		t.Fatalf("submitter completion failed: %+v %v", completed, err)
	}
	closeCmd := cwTestCmd(completed, "e2e-close", "close")
	closeCmd.ClosureReason = "not_applicable"
	closeCmd.Fields = map[string]string{"evidence": "operator reviewed persisted evidence"}
	closed, err := cwMutate(a.ID, closeCmd, "operator", "workbench")
	if err != nil || closed.Status != "closed" || wbEventStage(&closed, notices) != "closed" {
		t.Fatalf("closure failed: %+v %v", closed, err)
	}

	accountCard, _ := json.Marshal(cwCard(closed, cfg))
	if !strings.Contains(string(accountCard), "[Action Required] TAP Alert") || !strings.Contains(string(accountCard), "Account ID") || !strings.Contains(string(accountCard), "Account Name") || !strings.Contains(string(accountCard), "Required SLA") || !strings.Contains(string(accountCard), "alert_id") {
		t.Fatalf("account template/deep link incomplete: %s", accountCard)
	}
	st := closed
	st.Row.Program = "ST"
	stCard, _ := json.Marshal(cwCard(st, cfg))
	if !strings.Contains(string(stCard), "Brand Name") || strings.Contains(string(stCard), "Account Name") {
		t.Fatalf("ST card must identify the source value as Brand Name: %s", stCard)
	}
	tht := closed
	tht.Row.Program = "THT"
	tht.Row.Member.AdvertiserID = "advertiser-fixture"
	thtCard, _ := json.Marshal(cwCard(tht, cfg))
	if !strings.Contains(string(thtCard), "Advertiser ID") || !strings.Contains(string(thtCard), "Advertiser Name") || strings.Contains(string(thtCard), "Account ID") {
		t.Fatalf("THT card fabricated account identity: %s", thtCard)
	}

	day := strings.Split(closed.CreatedAt, "T")[0]
	analytics, err := cwAnalyticsBuild(cwAnalyticsFilter{Start: day, End: day})
	if err != nil || analytics.Summary["closed"] != 1 || analytics.Outcomes["notification_complete"]["complete"] != 1 {
		t.Fatalf("ledger analytics mismatch: %+v %v", analytics, err)
	}
}
