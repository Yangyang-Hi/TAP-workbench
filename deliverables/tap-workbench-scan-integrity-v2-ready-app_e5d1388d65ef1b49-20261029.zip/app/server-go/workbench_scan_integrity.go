package main

import (
	"strings"
	"time"
)

// Query coverage is independent of business risk and optional enrichment.
// A successful source NULL is accounted for, never fabricated as normal or zero.
type wbScanCoverage struct {
	Status                    string `json:"status"`
	MembershipComplete        bool   `json:"membership_complete"`
	TargetCount               int    `json:"target_count"`
	QueriedCount              int    `json:"queried_count"`
	QueryFailures             int    `json:"query_failures"`
	SourceMissingRows         int    `json:"source_missing_rows"`
	ComparisonUnavailableRows int    `json:"comparison_unavailable_rows"`
	Reason                    string `json:"reason,omitempty"`
}

func wbCoverageKey(program string, m wbMember) string {
	id := m.AccountID
	if strings.EqualFold(program, "THT") {
		id = m.AdvertiserID
	}
	return strings.Join([]string{strings.ToUpper(program), id, m.TicketID, m.Start}, "|")
}
func wbCoreQueryFailed(row wbRow) bool {
	if row.MetricStatus != "success" && row.MetricStatus != "no_data" {
		return true
	}
	c := row.Comparison
	if asString(c.Source["query_status"]) == "failed" {
		return true
	}
	switch c.Status {
	case "available", "source_null", "baseline_zero", "not_applicable", "window_incomplete", "missing_anchor", "ambiguous_anchor":
		return false
	case "unavailable":
		return !strings.HasPrefix(c.MissingReason, "missing_or_invalid_") && !strings.HasPrefix(c.MissingReason, "ambiguous_")
	default:
		return true
	}
}
func wbAssessScanCoverage(program string, members []wbMember, rows []wbRow, complete bool) wbScanCoverage {
	c := wbScanCoverage{Status: "incomplete", MembershipComplete: complete}
	wanted, seen := map[string]bool{}, map[string]bool{}
	for _, m := range members {
		wanted[wbCoverageKey(program, m)] = true
	}
	for _, r := range rows {
		k := wbCoverageKey(program, r.Member)
		if wanted[k] {
			seen[k] = true
		}
		if wbCoreQueryFailed(r) {
			c.QueryFailures++
		}
		if r.MetricStatus == "no_data" || r.CCR == nil || r.NFS == nil {
			c.SourceMissingRows++
		}
		if r.Comparison.Status != "available" {
			c.ComparisonUnavailableRows++
		}
	}
	c.TargetCount, c.QueriedCount = len(wanted), len(seen)
	if complete && c.QueriedCount == c.TargetCount && c.QueryFailures == 0 {
		c.Status = "complete"
	} else {
		c.Reason = "目标名单覆盖或关键指标查询尚未完整；不能据此声明全量无风险"
	}
	return c
}

const wbScheduledRetryLimit = 3
const wbScheduledRetryDelay = 30 * time.Minute

// Only full-region/full-membership scans suppress the global weekly task.
func wbScheduledFullScope(job wbJob) bool {
	q := job.Request
	return (q.Region == "" || strings.EqualFold(q.Region, "all")) && q.MemberStart == "2026-01-01" && q.MemberEnd == q.End
}
func wbScheduledRetryState(jobs map[string]wbJob, batchID, program string, now time.Time) (bool, string) {
	attempts := 0
	var latest time.Time
	for _, j := range jobs {
		if j.BatchID != batchID || !strings.EqualFold(j.Request.Program, program) || j.Principal != wbSchedulerPrincipal {
			continue
		}
		attempts++
		stamp := j.FinishedAt
		if stamp == "" {
			stamp = j.StartedAt
		}
		if at, err := time.Parse(time.RFC3339, stamp); err == nil && at.After(latest) {
			latest = at
		}
	}
	if attempts >= wbScheduledRetryLimit {
		return false, "retry_limit_reached"
	}
	if !latest.IsZero() && now.Before(latest.Add(wbScheduledRetryDelay)) {
		return false, "retry_cooldown"
	}
	return true, "eligible"
}

func wbReadScanCoverage(jobs []wbJob, program string) (string, string, map[string]any) {
	requested := []string{"ET", "THT", "ST"}
	if program != "" && !strings.EqualFold(program, "all") {
		requested = []string{strings.ToUpper(program)}
	}
	status, reason := "available", ""
	diagnostics := map[string]any{}
	for _, p := range requested {
		found := false
		for _, j := range jobs {
			if !strings.EqualFold(j.Request.Program, p) {
				continue
			}
			found = true
			state := "unverified"
			if j.CoreCoverage != nil {
				state = j.CoreCoverage.Status
			}
			diagnostics[p] = map[string]any{"scan_id": j.ID, "status": j.Status, "stage": j.Stage, "member_count": j.Members, "done": j.Done, "membership_complete": j.Complete, "core_coverage_status": state, "core_coverage": j.CoreCoverage, "error": j.Error, "started_at": j.StartedAt, "finished_at": j.FinishedAt}
			if j.Status == "failed" || j.Status == "blocked" || j.Status == "running" || j.Status == "partial" || !j.Complete || j.CoreCoverage == nil || j.CoreCoverage.Status != "complete" {
				status = "partial"
				reason = "所选 Program 存在指标缺失或扫描尚未完整；只展示已确认命中，不能据此声明全量无风险。"
			}
			if len(requested) == 1 && len(j.Rows) == 0 && j.Status == "running" {
				status = "unavailable"
				reason = p + " 正在扫描，尚无可展示的已保存指标；不能当作零预警。"
			}
		}
		if !found {
			diagnostics[p] = map[string]any{"status": "not_scanned", "reason": "所选周度没有该 Program 的已保存扫描记录"}
			status = "partial"
			reason = "本周部分 Program 尚无扫描记录；不能把未扫描当作零预警。"
			if len(requested) == 1 {
				return "unavailable", "所选周度没有 " + p + " 的已保存扫描记录，不能据此判断没有风险。", diagnostics
			}
		}
	}
	return status, reason, diagnostics
}
