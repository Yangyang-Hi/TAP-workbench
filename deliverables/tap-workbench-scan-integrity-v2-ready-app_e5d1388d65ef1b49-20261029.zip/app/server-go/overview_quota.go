package main

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"
)

var overviewETQuotaRows = quotaAeolusRows
var overviewSTQuotaRows = loadSTFromSnapshot

func overviewQuarterStarts(f overviewFilter) []time.Time {
	start, _ := time.Parse("2006-01-02", f.Start)
	end, _ := time.Parse("2006-01-02", f.End)
	first := time.Date(start.Year(), time.Month((int(start.Month())-1)/3*3+1), 1, 0, 0, 0, 0, time.UTC)
	out := []time.Time{}
	for q := first; !q.After(end); q = q.AddDate(0, 3, 0) {
		out = append(out, q)
	}
	return out
}

func overviewQuotaBaseline(baseline quotaBaseline, year int, quarter string) (quotaBaseline, string, bool) {
	if !strings.EqualFold(baseline.Status, "confirmed") || !strings.Contains(strings.ToUpper(baseline.Period), fmt.Sprintf("%d Q4", year)) {
		return baseline, "unavailable", false
	}
	if quarter == "Q3" {
		adapted := baseline
		adapted.Period = fmt.Sprintf("%d Q3", year)
		return adapted, "confirmed_same_as_q4", true
	}
	if quarter == "Q4" {
		return baseline, "confirmed_q4", true
	}
	return baseline, "unavailable", false
}

func overviewQuotaMetric(metric map[string]any, usageWindow, quotaPeriod map[string]string, program, baselinePolicy string, exactWindow bool) map[string]any {
	out := cloneMap(metric)
	_, uok := number(out["used"])
	_, qok := number(out["quota"])
	out["usage_window"] = usageWindow
	out["quota_period"] = quotaPeriod
	out["baseline_policy"] = baselinePolicy
	out["usage_count"] = out["used"]
	out["quota"] = metric["quota"]
	out["numerator_definition"] = "所选区间与本季度交集内 APPROVE 的去重 Account ID"
	out["denominator_definition"] = "该区间所属季度的 ET Account 配额"
	if program == "ST" {
		out["numerator_definition"] = "所选区间与本季度交集内 APPROVE 的去重 Brand Name"
		out["denominator_definition"] = "该区间所属季度的 ST Brand 配额"
	}
	if !exactWindow {
		out["source_quarter_usage_count"] = out["used"]
		out["quarter_snapshot_count"] = out["used"]
		out["quarter_snapshot_status"] = map[bool]string{true: "available", false: "unavailable"}[uok]
		out["used"], out["usage_count"], out["ratio"], out["remaining"] = nil, nil, nil, nil
		out["status"] = "unavailable"
		out["reason"] = "现有 ST 权威快照只有季度粒度，无法证明任意所选区间分子；季度快照单独展示，usage_count/ratio 不可用。"
		return out
	}
	if _, ok := out["remaining"]; !ok || !uok || !qok {
		out["remaining"] = nil
	}
	return out
}

func overviewQuotaHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	f, err := overviewParseWindow(r.URL.Query())
	if err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": err.Error()})
		return
	}
	baseline, err := loadQuotaBaseline()
	if err != nil {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": "Quota 基线配置不可读取"})
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()
	quarters := []map[string]any{}
	for _, start := range overviewQuarterStarts(f) {
		q := fmt.Sprintf("Q%d", (int(start.Month())-1)/3+1)
		period := fmt.Sprintf("%d %s", start.Year(), q)
		quarterStart := start.Format("2006-01-02")
		quarterEnd := start.AddDate(0, 3, -1).Format("2006-01-02")
		queryStart, queryEnd := quarterStart, quarterEnd
		if queryStart < f.Start {
			queryStart = f.Start
		}
		if queryEnd > f.End {
			queryEnd = f.End
		}
		usageWindow := map[string]string{"start_date": queryStart, "end_date": queryEnd}
		quotaPeriod := map[string]string{"label": period, "start_date": quarterStart, "end_date": quarterEnd}
		item := map[string]any{
			"quarter": period, "start_date": queryStart, "end_date": queryEnd,
			"usage_window": usageWindow, "quota_period": quotaPeriod,
			"status": "unavailable", "regions": []map[string]any{}, "et": nil, "st": nil,
			"numerator_definition":   "所选区间与本季度交集内的获批去重使用量",
			"denominator_definition": "对应季度已确认配额；Q3 按已确认策略复用同 Program/Region 的 Q4 baseline",
			"basis":                  "ET 展示区间获批使用量 / 季度配额；ST 仅单独展示季度快照，任意选择区间 usage_count/ratio 均 unavailable",
		}
		adaptedBaseline, baselinePolicy, baselineOK := overviewQuotaBaseline(baseline, start.Year(), q)
		if !baselineOK {
			item["baseline_policy"] = baselinePolicy
			item["reason"] = "该年份或季度没有已确认分母；Overview 仅允许 Q3 按确认策略复用同年 Q4 基线"
			quarters = append(quarters, item)
			continue
		}
		item["baseline_policy"] = baselinePolicy
		item["baseline_source_period"] = baseline.Period
		sources := quotaSourceResult{Status: "partial", SourceStatus: map[string]string{"ET": "failed", "ST": "failed", "THT": "not_requested"}, Diagnostics: map[string]map[string]any{}, Errors: map[string]string{}}
		request := r.Clone(ctx)
		u := *r.URL
		u.RawQuery = ""
		request.URL = &u
		request.Form, request.PostForm = nil, nil
		et, etErr := overviewETQuotaRows(ctx, request, "et_quota_tickets", "ET", queryStart, queryEnd)
		if etErr == nil {
			sources.ET = et.Rows
			sources.SourceStatus["ET"] = "available"
		} else {
			sources.Errors["ET"] = sanitizeAuditText(etErr.Error())
		}
		sources.Diagnostics["ET"] = et.Diagnostic
		st, meta, stErr := overviewSTQuotaRows(q)
		if stErr == nil {
			sources.ST = st
			sources.SourceStatus["ST"] = "available"
			sources.AsOf = asString(meta["synced_at"])
		} else {
			sources.Errors["ST"] = sanitizeAuditText(stErr.Error())
		}
		data := aggregateQuota(adaptedBaseline, sources, q)
		global, _ := data["global"].(map[string]any)
		regionRows, _ := data["regions"].([]map[string]any)
		selected := global
		display := []map[string]any{}
		for _, row := range regionRows {
			if f.Region != "Global" && asString(row["region"]) != f.Region {
				continue
			}
			next := map[string]any{"region": row["region"]}
			if metric, ok := row["et"].(map[string]any); ok {
				next["et"] = overviewQuotaMetric(metric, usageWindow, quotaPeriod, "ET", baselinePolicy, true)
			}
			if metric, ok := row["st"].(map[string]any); ok {
				next["st"] = overviewQuotaMetric(metric, usageWindow, quotaPeriod, "ST", baselinePolicy, false)
			}
			display = append(display, next)
			if f.Region != "Global" {
				selected = row
			}
		}
		if f.Region != "Global" && len(display) == 0 {
			item["reason"] = "该 Sales Region 与 Quota 区域没有已验证映射"
			quarters = append(quarters, item)
			continue
		}
		if metric, ok := selected["et"].(map[string]any); ok {
			item["et"] = overviewQuotaMetric(metric, usageWindow, quotaPeriod, "ET", baselinePolicy, true)
		}
		if metric, ok := selected["st"].(map[string]any); ok {
			item["st"] = overviewQuotaMetric(metric, usageWindow, quotaPeriod, "ST", baselinePolicy, false)
		}
		item["regions"], item["source_status"], item["st_snapshot_at"], item["errors"], item["warnings"] = display, sources.SourceStatus, sources.AsOf, sources.Errors, baseline.Warnings
		item["status"] = "partial"
		item["st_interval_usage_status"] = "unavailable"
		item["st_quarter_snapshot_status"] = map[bool]string{true: "available", false: "unavailable"}[sources.SourceStatus["ST"] == "available"]
		quarters = append(quarters, item)
	}
	writeJSON(w, http.StatusOK, map[string]any{"data": map[string]any{
		"status": "available", "window": f, "quarters": quarters,
		"queried_at": time.Now().UTC().Format(time.RFC3339), "side_effects": false,
		"scope": "ET Account / ST Brand；usage_window 严格使用用户区间与季度交集；quota_period 单独标明；跨季度不混合分母",
	}})
}
