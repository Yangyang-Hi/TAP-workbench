package main

import (
	"context"
	"net/http"
	"testing"
	"time"
)

func TestPairEvidenceDualKeyInvalidZeroDedupNullAndTop10(t *testing.T) {
	rule := wbRule{Enabled: true, CriticalCCR: 10, WatchCCR: 5, WatchNFS: 2}
	bridge := []map[string]any{
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001"},
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001"},
		{"account_id": "7000000000000000001", "advertiser_id": "0"},
	}
	metrics := []map[string]any{{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "dynamic_p0_ccr": 12.0, "p0_nfs": nil, "semantics_label_tier_1_2_3_4": "ads_delivery_issues - dislike_or_report_mapping - dislike_other_issues - "}}
	revenue := []map[string]any{{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "revenue": 8.0}, {"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "revenue": 8.0}}
	result, err := mergePairEvidence(bridge, metrics, revenue, map[string]bool{"7100000000000000001": true}, rule)
	if err != nil {
		t.Fatal(err)
	}
	items := result["7000000000000000001"]
	if len(items) != 1 || items[0].NFS != nil || items[0].Revenue == nil || *items[0].Revenue != 8 || items[0].AllowlistStatus != "matched_scope_unknown" || items[0].SemanticsLabel != "ads_delivery_issues - dislike_or_report_mapping - dislike_other_issues -" {
		t.Fatalf("unexpected pair evidence: %+v", items)
	}
	if got := topAdvertisers(items, 10); len(got) != 1 || got[0].AdvertiserID != "7100000000000000001" {
		t.Fatalf("top10 mismatch: %+v", got)
	}
}

func TestApplyPairEvidencePreservesAuthoritativeAccountMetrics(t *testing.T) {
	ccr, nfs, revenue := 9.0, 52.0, 30.0
	pairNFS, pairRevenue := 2.0, 3.0
	rows := []wbRow{{Program: "ET", Member: wbMember{AccountID: "7000000000000000001"}, CCR: &ccr, NFS: &nfs, Revenue: &revenue, AccountCCRStatus: "权威 Account 粒度"}}
	evidence := map[string][]wbAdvertiserEvidence{"7000000000000000001": {{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001", CCR: &ccr, NFS: &pairNFS, Revenue: &pairRevenue, Level: "watch"}}}
	out := applyPairEvidence(rows, evidence, wbRequest{Program: "ET", Start: "2026-10-12", End: "2026-10-18"}, wbRule{CCRUnit: "ppm"})
	if out[0].CCR == nil || *out[0].CCR != ccr || out[0].NFS == nil || *out[0].NFS != nfs || out[0].Revenue == nil || *out[0].Revenue != revenue || out[0].AdvertiserCount != 1 || out[0].AccountCCRStatus == "" {
		t.Fatalf("pair evidence overwrote Account authority: %+v", out[0])
	}
}

func TestRCAAndFinalActionAreIndependentAndDirectClose(t *testing.T) {
	cfg := cwConfig{Workflow: map[string][]cwOption{"customer": {{ID: "tap_remove", Status: "closed", Fields: []cwField{{Key: "rca", Required: true}, {Key: "explanation", Required: true}, {Key: "result", Required: true}}}}}, Operators: []string{"owner"}}
	invalidCase := cwCase{ID: "invalid", Kind: "customer", Status: "open", Owner: "owner", Version: 1, Fields: map[string]string{}}
	invalid := cwCommand{Operation: "plan", Plan: "tap_remove", Note: "done", RequestID: "invalid", Fields: map[string]string{"rca": "未配置值", "explanation": "x", "result": "y"}}
	if err := cwApply(&invalidCase, invalid, "owner", "workbench", cfg); err == nil {
		t.Fatal("unknown RCA accepted")
	}
	base := cwCase{ID: "A", Kind: "customer", Status: "open", Owner: "owner", Version: 1, Fields: map[string]string{}}
	independent := cwCommand{Operation: "plan", Plan: "tap_remove", Note: "done", RequestID: "1", Fields: map[string]string{"rca": "无任何风险", "explanation": "x", "result": "y"}}
	if err := cwApply(&base, independent, "owner", "workbench", cfg); err != nil {
		t.Fatal(err)
	}
	if base.Status != "closed" || base.ClosedAt == "" || !base.ActionCompleted || base.Fields["rca"] != "无任何风险" || base.Plan != "tap_remove" {
		t.Fatalf("RCA/action not independently persisted: %+v", base)
	}
}

func TestPreviousCompleteNaturalWeek(t *testing.T) {
	start, end := previousCompleteWeek(time.Date(2026, 10, 21, 12, 0, 0, 0, time.FixedZone("CST", 8*3600)))
	if start != "2026-10-12" || end != "2026-10-18" {
		t.Fatalf("unexpected week %s..%s", start, end)
	}
}

func TestPairEvidenceFailureDoesNotBlockAuthoritativeAccountScan(t *testing.T) {
	wbTestEnv(t)
	oldMembers, oldBatch := wbLoadMembers, wbQueryETBatch
	defer func() { wbLoadMembers = oldMembers; wbQueryETBatch = oldBatch }()
	wbLoadMembers = func(context.Context, *http.Request, wbRequest, wbConfig) ([]wbMember, bool, error) {
		return []wbMember{{AccountID: "7000000000000000001"}}, true, nil
	}
	wbQueryETBatch = func(context.Context, *http.Request, []string, string, string) (map[string]wbBatchMetric, error) {
		return map[string]wbBatchMetric{"7000000000000000001": {Status: "success"}}, nil
	}
	wbQueryPairEvidence = func(context.Context, *http.Request, []wbMember, wbRequest, wbRule) (map[string][]wbAdvertiserEvidence, error) {
		return nil, context.DeadlineExceeded
	}
	cfg, _ := loadWBConfig()
	wbRunning["pair-fail"] = &wbJob{ID: "pair-fail", Principal: "u", Request: wbRequest{Program: "ET"}, Rule: testRule(), Status: "running"}
	wbRunJob(wbReq("u"), "pair-fail", cfg)
	job, _ := wbLookup("pair-fail", "u")
	if job.Status == "failed" || len(job.Rows) != 1 || len(job.Warnings) == 0 {
		t.Fatalf("optional advertiser evidence blocked Account scan or omitted warning: %+v", job)
	}
}

func TestRID2942519UsesDateOnlineAndRuntimeIDOnly(t *testing.T) {
	wbTestEnv(t)
	cfg, err := loadDataSourceConfig()
	if err != nil {
		t.Fatal(err)
	}
	source := cfg.Sources["weekly_pair_ccr_nfs"]
	chart, applied := chartWithBusinessFilters(map[string]any{}, source, filterRequest{StartDate: "2026-10-12", EndDate: "2026-10-18", Region: "EU", ClientTier: "strategic_trust"})
	exact, err := exactIDFilter(source, "account_id", []string{"7000000000000000001"})
	if err != nil {
		t.Fatal(err)
	}
	filters, _ := chart["filters"].([]any)
	filters = append(filters, exact)
	if !containsString(applied, "p_date") || !containsString(applied, "is_online") {
		t.Fatalf("missing fixed filters: applied=%v filters=%v", applied, filters)
	}
	if containsString(applied, "client_tier") || containsString(applied, "trust_region") || containsString(applied, "region") {
		t.Fatalf("membership dimensions leaked into RID 2942519: %v", applied)
	}
	if len(filters) != 3 {
		t.Fatalf("expected date + is_online + runtime account_id, got %d: %v", len(filters), filters)
	}
}

func TestPairGrainFilterIntegrityAllowsRepeatedAccountRows(t *testing.T) {
	source := sourceConfig{Grain: "account_advertiser_week", Fields: map[string]fieldConfig{"account_id": {DimMetID: "account-field", UniqueID: "account-uid"}}}
	rows := []map[string]any{
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001"},
		{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000002"},
	}
	integrity := verifyReturnedIDs(source, "account_id", []string{"7000000000000000001", "7000000000000000002"}, rows)
	if integrity.DuplicateN != 1 || !allowsRepeatedIDRows(source, "account_id") || len(integrity.Wrong) != 0 || integrity.NullN != 0 {
		t.Fatalf("pair-grain integrity mismatch: %+v", integrity)
	}
}

func TestRevenueFailureStatusDoesNotDiscardCCRNFS(t *testing.T) {
	bridge := []map[string]any{{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001"}}
	metrics := []map[string]any{{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "dynamic_p0_ccr": 12.0, "p0_nfs": 2.0}}
	result, err := mergePairEvidenceWithRevenueStatus(bridge, metrics, nil, nil, wbRule{CriticalCCR: 10}, "source_error", "revenue request failed")
	if err != nil {
		t.Fatal(err)
	}
	item := result["7000000000000000001"][0]
	if item.CCR == nil || *item.CCR != 12 || item.NFS == nil || *item.NFS != 2 || item.Revenue != nil || item.RevenueStatus != "source_error" || item.RevenueError == "" {
		t.Fatalf("non-blocking revenue evidence mismatch: %+v", item)
	}
}

func TestPairEvidenceFullOuterJoinDoesNotRequireBridgeAndKeepsZero(t *testing.T) {
	metrics := []map[string]any{{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "dynamic_p0_ccr": 0.0, "p0_nfs": 0.0}}
	revenue := []map[string]any{{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000002", "revenue": 0.0}}
	result, err := mergePairEvidence(nil, metrics, revenue, nil, wbRule{})
	if err != nil {
		t.Fatal(err)
	}
	items := result["7000000000000000001"]
	if len(items) != 2 {
		t.Fatalf("full outer join lost one-sided facts: %+v", items)
	}
	var ccrOnly, revenueOnly *wbAdvertiserEvidence
	for i := range items {
		switch items[i].AdvertiserID {
		case "7100000000000000001":
			ccrOnly = &items[i]
		case "7100000000000000002":
			revenueOnly = &items[i]
		}
	}
	if ccrOnly == nil || ccrOnly.CCR == nil || *ccrOnly.CCR != 0 || ccrOnly.NFS == nil || *ccrOnly.NFS != 0 {
		t.Fatalf("real zero CCR/NFS was lost: %+v", ccrOnly)
	}
	if revenueOnly == nil || revenueOnly.Revenue == nil || *revenueOnly.Revenue != 0 || revenueOnly.CCR != nil {
		t.Fatalf("Revenue-only zero was lost or fabricated CCR: %+v", revenueOnly)
	}
	if top := topAdvertisers(items, 10); len(top) != 1 || top[0].AdvertiserID != ccrOnly.AdvertiserID {
		t.Fatalf("Revenue-only row entered high CCR ranking: %+v", top)
	}
}

func TestBridgeOnlyRowsDoNotExpandFactPool(t *testing.T) {
	bridge := []map[string]any{{"account_id": "7000000000000000001", "advertiser_id": "7100000000000000001", "advertiser_name": "name-only"}}
	result, err := mergePairEvidence(bridge, nil, nil, nil, wbRule{})
	if err != nil {
		t.Fatal(err)
	}
	if len(result) != 0 {
		t.Fatalf("S04 expanded the metric pool: %+v", result)
	}
}

func TestSemanticsLabelFactDistinguishesAvailableEmptyAndMissing(t *testing.T) {
	label, status := semanticsLabelFact(map[string]any{"semantics_label_tier_1_2_3_4": " content_issues - sensitive_content - unsure_violence - "})
	if label != "content_issues - sensitive_content - unsure_violence -" || status != "available" {
		t.Fatalf("mapped semantics label lost: label=%q status=%q", label, status)
	}
	if label, status = semanticsLabelFact(map[string]any{"semantics_label_tier_1_2_3_4": " "}); label != "" || status != "source_empty" {
		t.Fatalf("empty source field misclassified: label=%q status=%q", label, status)
	}
	if label, status = semanticsLabelFact(map[string]any{}); label != "" || status != "field_not_returned" {
		t.Fatalf("missing mapped field misclassified: label=%q status=%q", label, status)
	}
}

func advertiserMetricSourceForTest(trace string) map[string]any {
	return map[string]any{
		"source":        "advertiser_current_ccr_nfs",
		"rid":           "2942519",
		"grain":         "account_advertiser_window",
		"fixed_filters": []any{"is_online=1"},
		"status":        "success",
		"trace":         trace,
	}
}

func TestBestPairEvidenceKeepsAvailableMetricAndAttachesReasons(t *testing.T) {
	ccr, nfs, revenue := 12.0, 3.0, 88.0
	current := wbAdvertiserEvidence{
		AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001",
		Revenue: &revenue, MetricStatus: "no_data", RevenueStatus: "success",
		Reasons:         []string{"Revenue-only：不进入高 CCR 榜"},
		ReportedReasons: []reportedReason{{MappedName: "reason-a"}}, ReportedReasonsStatus: "available",
	}
	candidate := wbAdvertiserEvidence{
		AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001",
		CCR: &ccr, NFS: &nfs, MetricStatus: "success", Level: "watch",
		Reasons: []string{"CCR 达到阈值"}, CurrentSource: advertiserMetricSourceForTest("qa-test"),
	}
	got := wbMergeEvidenceBest(current, candidate)
	if got.CCR == nil || *got.CCR != 12 || got.NFS == nil || *got.NFS != 3 || got.Revenue == nil || *got.Revenue != 88 || got.MetricStatus != "success" {
		t.Fatalf("available pair facts were overwritten or lost: %+v", got)
	}
	if len(got.ReportedReasons) != 1 || got.ReportedReasons[0].MappedName != "reason-a" || len(got.Reasons) != 1 || got.Reasons[0] != "CCR 达到阈值" {
		t.Fatalf("reasons detached from merged advertiser: %+v", got)
	}
}

func TestRowMergeRecomputesTop10FromFinalAdvertisers(t *testing.T) {
	low, high := 2.0, 19.0
	current := wbRow{Advertisers: []wbAdvertiserEvidence{
		{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001", CCR: &low, MetricStatus: "success"},
		{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000003", MetricStatus: "no_data"},
	}, AdvertiserTop10: []wbAdvertiserEvidence{{AccountID: "7000000000000000001", AdvertiserID: "stale", CCR: &high, MetricStatus: "success"}}}
	candidate := wbRow{Advertisers: []wbAdvertiserEvidence{{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000002", CCR: &high, MetricStatus: "success"}}}
	got := wbMergeRowBestFacts(current, candidate)
	if len(got.AdvertiserTop10) != 2 || got.AdvertiserTop10[0].AdvertiserID != "7100000000000000002" || got.AdvertiserTop10[1].AdvertiserID != "7100000000000000001" {
		t.Fatalf("Top10 was not recomputed by final Current CCR: %+v", got.AdvertiserTop10)
	}
}

func TestPersistedETMergeRejectsIncompatibleAdvertiserMetricSource(t *testing.T) {
	ccr := 21.0
	base := wbRow{Program: "ET", Member: wbMember{AccountID: "7000000000000000001"}}
	candidate := wbRow{Program: "ET", Member: wbMember{AccountID: "7000000000000000001"}, Advertisers: []wbAdvertiserEvidence{{
		AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001", CCR: &ccr, MetricStatus: "success",
		CurrentSource: map[string]any{"source": "advertiser_current_ccr_nfs", "rid": "wrong", "grain": "account_advertiser_window", "fixed_filters": []any{"is_online=1"}, "status": "success", "trace": "qa-test"},
	}}}
	got, reasons := wbMergePersistedETRow(base, candidate)
	if len(got.AdvertiserTop10) != 0 || len(got.Advertisers) != 1 || got.Advertisers[0].CCR != nil || !containsString(reasons, "advertiser_current_evidence_missing") {
		t.Fatalf("incompatible pair evidence entered ranking: row=%+v reasons=%v", got, reasons)
	}
}
