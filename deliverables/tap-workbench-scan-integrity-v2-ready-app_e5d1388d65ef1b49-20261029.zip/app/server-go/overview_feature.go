package main

import (
	"os"
	"strings"
)

const overviewFeatureEnv = "TAP_OVERVIEW_ENABLED"

func overviewFeatureEnabled() bool {
	switch strings.ToLower(strings.TrimSpace(os.Getenv(overviewFeatureEnv))) {
	case "0", "false", "no", "off", "disabled":
		return false
	default:
		return true
	}
}
