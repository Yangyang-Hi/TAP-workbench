package main

import (
	"archive/zip"
	"bytes"
	"context"
	"database/sql"
	"fmt"
	"html"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"
)

type cwAnalyticsFilter struct {
	Start, End, Region, Program, Tier, Submitter, Owner, Level, Status, AdvertiserID, AccountID, Search, DateField string
	ProtectionStartDate, ProtectionEndDate                                                                         string
	IncludeAnchorAnomalies                                                                                         bool
	TimeMode, BatchID, CaseScope, ScopeReason                                                                      string
	ScanIDs                                                                                                        map[string]bool
	Jobs                                                                                                           []wbJob `json:"-"`
}
type cwCount struct {
	Key   string `json:"key"`
	Label string `json:"label"`
	Count int    `json:"count"`
}
type cwDuration struct {
	MedianMinutes *float64 `json:"median_minutes"`
	Samples       int      `json:"samples"`
}
type cwOwnerProgress struct {
	Owner     string `json:"owner"`
	Events    int    `json:"events"`
	Notified  int    `json:"notified"`
	Completed int    `json:"completed"`
	Todo      int    `json:"todo"`
	Overdue   int    `json:"overdue"`
}
type cwCoverage struct {
	RiskEvents     int `json:"risk_events"`
	LinkedCases    int `json:"linked_cases"`
	UnlinkedAlerts int `json:"unlinked_alerts"`
	CheckFilled    int `json:"check_filled"`
	ActionFilled   int `json:"action_filled"`
	RecheckCovered int `json:"recheck_covered"`
}
type cwAnalyticsMeta struct {
	AlertSourceBasis        string `json:"alert_source_basis"`
	LevelBasis              string `json:"level_basis"`
	CaseworkBasis           string `json:"casework_basis"`
	AlertSourcesOverlap     bool   `json:"alert_sources_overlap"`
	Top20CandidatesIncluded bool   `json:"top20_candidates_included"`
	Timezone                string `json:"timezone"`
}
type cwAnalytics struct {
	AsOf                                             string                        `json:"as_of"`
	GeneratedAt                                      string                        `json:"generated_at,omitempty"`
	Filters                                          cwAnalyticsFilter             `json:"filters"`
	Cases                                            []cwCase                      `json:"cases"`
	CasePresentations                                map[string]cwCasePresentation `json:"case_presentations"`
	Summary                                          map[string]int                `json:"summary"`
	Region, Stage, Attribution, Action, Daily, Owner []cwCount
	Efficiency                                       map[string]cwDuration     `json:"efficiency"`
	Notification                                     map[string]map[string]int `json:"notification"`
	NotificationSource                               map[string]map[string]int `json:"notification_source"`
	Outcomes                                         map[string]map[string]int `json:"outcomes"`
	Effects                                          map[string]int            `json:"effects"`
	Process                                          map[string]int            `json:"process"`
	EffectStatus                                     map[string]int            `json:"effect_status"`
	Missing                                          []string                  `json:"missing_data"`
	Quota                                            map[string]any            `json:"quota"`
	RiskSource                                       []cwCount                 `json:"risk_source"`
	RiskLevel                                        []cwCount                 `json:"risk_level"`
	Program                                          []cwCount                 `json:"program"`
	SourceByCase                                     map[string][]string       `json:"source_by_case"`
	OwnerProgress                                    []cwOwnerProgress         `json:"owner_progress"`
	Coverage                                         cwCoverage                `json:"coverage"`
	Meta                                             cwAnalyticsMeta           `json:"metadata"`
	RuleSummaries                                    []cwRuleSummary           `json:"rule_summaries"`
	PriorityClients                                  []cwPriorityClient        `json:"priority_clients"`
	Top20Candidates                                  []cwTop20Candidate        `json:"top20_candidates"`
	BatchStatus                                      cwBatchStatus             `json:"batch_status"`
	QuotaAlerts                                      cwQuotaAlerts             `json:"quota_alerts"`
}

func cwAnalyticsFilters(r *http.Request) cwAnalyticsFilter {
	q := r.URL.Query()
	mode := strings.ToLower(strings.TrimSpace(q.Get("time_mode")))
	if mode == "" {
		mode = "weekly"
	}
	level := q.Get("alert_level")
	if level == "" {
		level = q.Get("level") // Backward-compatible deep links.
	}
	f := cwAnalyticsFilter{Start: q.Get("start_date"), End: q.Get("end_date"), Region: q.Get("region"), Program: q.Get("program"), Tier: q.Get("tier"), Submitter: q.Get("submitter"), Owner: q.Get("owner"), Level: level, Status: q.Get("status"), AdvertiserID: q.Get("advertiser_id"), AccountID: q.Get("account_id"), Search: q.Get("search"), DateField: q.Get("date_field"), ProtectionStartDate: q.Get("protection_start_date"), ProtectionEndDate: q.Get("protection_end_date"), IncludeAnchorAnomalies: q.Get("include_anchor_anomalies") == "true", TimeMode: mode, BatchID: q.Get("batch_id"), CaseScope: "all"}
	if !validDate(f.ProtectionStartDate) || !validDate(f.ProtectionEndDate) || f.ProtectionStartDate != "" && f.ProtectionEndDate != "" && f.ProtectionStartDate > f.ProtectionEndDate {
		f.ScopeReason = "保护开始时间筛选无效；日期必须使用 YYYY-MM-DD 且开始不得晚于结束。"
		f.ScanIDs = map[string]bool{}
		return f
	}
	if mode == "custom" {
		f.ScopeReason = "自定义查询只读且不创建治理事件，因此治理事件统计不适用；请切换周度批次查看已关闭事件。"
		return f
	}
	batches, jobsByBatch, err := wbPersistedBatches()
	if err != nil || len(batches) == 0 {
		f.ScopeReason = "没有可用的持久化周度批次。"
		return f
	}
	if f.BatchID == "" {
		f.BatchID = batches[0].BatchID
	}
	jobs, ok := jobsByBatch[f.BatchID]
	if !ok {
		f.ScopeReason = "所选周度批次不存在，未计入任何预警。"
		return f
	}
	f.Jobs = jobs
	f.ScanIDs = map[string]bool{}
	incomplete := false
	for _, job := range jobs {
		f.ScanIDs[job.ID] = true
		if job.Status != "ready" || !job.Complete {
			incomplete = true
		}
	}
	for _, batch := range batches {
		if batch.BatchID == f.BatchID {
			f.Start, f.End = batch.MetricStart, batch.MetricEnd
			break
		}
	}
	if incomplete {
		f.ScopeReason = "按所选周度批次统计全部已返回预警；当前批次仍在运行或部分完成，报告包含已返回但尚未进入治理台账的预警，并明确标记为‘待进入治理台账’。"
	} else {
		f.ScopeReason = "按所选周度批次统计全部预警，并合并共享事件台账的最新处置状态；未建单预警以只读方式纳入报告。"
	}
	return f
}
func cwAnalyticsAuthorized(w http.ResponseWriter, r *http.Request) bool {
	return strings.TrimSpace(requestUsername(r)) != ""
}
func cwParse(s string) (time.Time, bool) {
	t, e := time.Parse(time.RFC3339, s)
	if e != nil {
		t, e = time.Parse("2006-01-02", s)
	}
	return t, e == nil
}
func cwWeeklyRiskRows(f cwAnalyticsFilter, bf businessFilter) map[string]wbRow {
	all := []wbReadRow{}
	source := map[string]wbRow{}
	semanticsEvidence := wbLatestSemanticsEvidence(map[string][]wbJob{f.BatchID: f.Jobs})
	policy := wbDefaultPolicy()
	hasPersistedPolicy := false
	for _, job := range f.Jobs {
		if len(job.Policy.Rules) > 0 {
			policy = job.Policy
			hasPersistedPolicy = true
			break
		}
	}
	for _, job := range f.Jobs {
		for _, persistedRow := range job.Rows {
			row := wbBackfillSemantics(persistedRow, semanticsEvidence)
			a := cwCase{ScanID: job.ID, Row: row, Window: job.Request}
			if !matchBusinessCase(a, bf, "") {
				continue
			}
			view := wbToReadRow(job, row, nil, nil, time.Now())
			all = append(all, view)
			source[job.ID+"|"+row.ID] = row
		}
	}
	out := map[string]wbRow{}
	for _, view := range wbRiskList(all, "combined", policy) {
		key := view.ScanID + "|" + view.RowID
		row, ok := source[key]
		if !ok {
			continue
		}
		if view.RiskLevel == "extreme" {
			row.Level = "critical"
		} else {
			row.Level = view.RiskLevel
		}
		row.Reasons = append([]string(nil), view.RiskReasons...)
		out[key] = row
	}
	if !hasPersistedPolicy {
		// Legacy scans can lack a policy snapshot. Their persisted alert level is the
		// immutable compatibility fact until a governed policy snapshot exists.
		for key, row := range source {
			if wbMatched(row) {
				out[key] = row
			}
		}
	}
	return out
}

func cwFilteredCases(f cwAnalyticsFilter) ([]cwCase, error) {
	if f.TimeMode == "custom" || (f.TimeMode == "weekly" && len(f.ScanIDs) == 0) {
		return []cwCase{}, nil
	}
	repo, err := cwCaseworkRepositoryProvider()
	if err != nil {
		return nil, err
	}
	stored, err := repo.listCases(context.Background())
	if err != nil {
		return nil, err
	}
	storedByID := make(map[string]cwCase, len(stored))
	for _, item := range stored {
		storedByID[item.ID] = item
	}
	seenCases := map[string]bool{}
	seenEvents := map[string]bool{}
	out := []cwCase{}
	bf := businessFilter{Region: f.Region, Program: strings.ToUpper(f.Program), Tier: f.Tier, Submitter: f.Submitter, Owner: f.Owner, AdvertiserID: f.AdvertiserID, AccountID: f.AccountID, Search: f.Search, DateField: f.DateField, ProtectionStartDate: f.ProtectionStartDate, ProtectionEndDate: f.ProtectionEndDate, IncludeAnchorAnomalies: f.IncludeAnchorAnomalies, AlertLevel: f.Level, Status: f.Status}
	if f.TimeMode != "weekly" {
		bf.StartDate, bf.EndDate = f.Start, f.End
		for _, item := range stored {
			if seenCases[item.ID] || !matchBusinessCase(item, bf, "") {
				continue
			}
			seenCases[item.ID] = true
			out = append(out, item)
		}
		sort.SliceStable(out, func(i, j int) bool {
			if out[i].CreatedAt != out[j].CreatedAt {
				return out[i].CreatedAt > out[j].CreatedAt
			}
			return cwCaseKey(out[i]) < cwCaseKey(out[j])
		})
		return out, nil
	}
	semanticsEvidence := wbLatestSemanticsEvidence(map[string][]wbJob{f.BatchID: f.Jobs})
	for _, job := range f.Jobs {
		for _, persistedRow := range job.Rows {
			row := wbBackfillSemantics(persistedRow, semanticsEvidence)
			item := wbCaseForReadRow(storedByID, job, row)
			if item == nil || seenCases[item.ID] {
				continue
			}
			linked := *item
			linked.ScanID, linked.Row, linked.Window = job.ID, row, job.Request
			if !matchBusinessCase(linked, bf, "") {
				continue
			}
			seenCases[linked.ID] = true
			seenEvents[job.ID+"|"+row.ID] = true
			out = append(out, linked)
		}
	}
	riskRows := cwWeeklyRiskRows(f, bf)
	for _, job := range f.Jobs {
		for _, persistedRow := range job.Rows {
			eventKey := job.ID + "|" + persistedRow.ID
			row, isRisk := riskRows[eventKey]
			if !isRisk || seenEvents[eventKey] {
				continue
			}
			a := cwCase{ID: "SOURCE-" + wbKey([]string{job.ID, row.ID})[:20], Kind: "source_alert", Version: 0, Status: "source_alert", Creator: job.Principal, CreatedAt: job.AsOf, UpdatedAt: job.AsOf, ScanID: job.ID, Row: row, Window: job.Request, Rule: job.Rule, Fields: map[string]string{"reporting_source": "weekly_read_model", "batch_id": job.BatchID}}
			seenEvents[eventKey] = true
			out = append(out, a)
		}
	}
	sort.SliceStable(out, func(i, j int) bool {
		if out[i].CreatedAt != out[j].CreatedAt {
			return out[i].CreatedAt > out[j].CreatedAt
		}
		return cwCaseKey(out[i]) < cwCaseKey(out[j])
	})
	return out, nil
}
func cwAdd(m map[string]int, k string) {
	if strings.TrimSpace(k) == "" {
		k = "未填写"
	}
	m[k]++
}
func cwCounts(m map[string]int) []cwCount {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	out := []cwCount{}
	for _, k := range keys {
		out = append(out, cwCount{Key: k, Label: k, Count: m[k]})
	}
	return out
}
func cwMedian(v []float64) cwDuration {
	if len(v) == 0 {
		return cwDuration{Samples: 0}
	}
	sort.Float64s(v)
	x := v[len(v)/2]
	if len(v)%2 == 0 {
		x = (v[len(v)/2-1] + x) / 2
	}
	return cwDuration{MedianMinutes: &x, Samples: len(v)}
}
func cwAuditTime(a cwCase, operations ...string) (time.Time, bool) {
	set := map[string]bool{}
	for _, x := range operations {
		set[x] = true
	}
	for _, h := range a.History {
		if set[h.Operation] {
			if t, ok := cwParse(h.At); ok {
				return t, true
			}
		}
	}
	return time.Time{}, false
}
func cwAnalyticsClosed(status string) bool {
	status = strings.ToLower(strings.TrimSpace(status))
	return status == "closed" || status == "resolved"
}
func cwClientKey(a cwCase) string {
	id := a.Row.Member.AccountID
	if a.Row.Program == "THT" {
		id = a.Row.Member.AdvertiserID
	}
	return a.Row.Program + "|" + id
}
func cwAlertSources(a cwCase) []string {
	// Source classification is reconstructed only from persisted structured metrics,
	// comparison provenance and the saved rule snapshot. Free-text reasons are never parsed.
	out := []string{}
	absoluteLevel, _ := evaluateWBAbsolute(a.Row.CCR, a.Row.NFS, a.Rule)
	if absoluteLevel == "critical" || absoluteLevel == "watch" {
		out = append(out, "absolute")
	}
	if len(out) == 0 && (a.Row.Level == "critical" || a.Row.Level == "watch") {
		out = append(out, "unidentified")
	}
	return out
}

func cwAnalyticsBuild(f cwAnalyticsFilter) (cwAnalytics, error) {
	cases, e := cwFilteredCases(f)
	if e != nil {
		return cwAnalytics{}, e
	}
	x := cwAnalytics{AsOf: cwNow(), Filters: f, Cases: cases, CasePresentations: map[string]cwCasePresentation{}, Summary: map[string]int{}, Efficiency: map[string]cwDuration{}, Notification: map[string]map[string]int{"test": {}, "formal": {}, "unknown": {}}, NotificationSource: map[string]map[string]int{"auto": {}, "manual": {}, "test": {}, "unknown": {}}, Outcomes: map[string]map[string]int{"notification_complete": {}, "case_closed": {}, "risk_improved": {}}, Effects: map[string]int{}, Process: map[string]int{}, EffectStatus: map[string]int{}, SourceByCase: map[string][]string{}, Meta: cwAnalyticsMeta{AlertSourceBasis: "统一来源为所选 persisted weekly read-model 的筛选后预警事件集合；Cloud/历史 case 仅补充同一事件的最新处置状态，不重新扫源、不引入固定 ET/Global 数据", LevelBasis: "事件保存的 row.level：critical=极端预警、watch=观察预警，其他=未分级", CaseworkBasis: "tap_cases 及 scan_id/row_id 关联标识；未关联仅表示未进入台账，不等于未处理", AlertSourcesOverlap: true, Top20CandidatesIncluded: false, Timezone: "Asia/Shanghai"}}
	region := map[string]int{}
	stage := map[string]int{}
	attr := map[string]int{}
	action := map[string]int{}
	daily := map[string]int{}
	owners := map[string]int{}
	riskSources := map[string]int{}
	riskLevels := map[string]int{}
	programs := map[string]int{}
	ownerProgress := map[string]*cwOwnerProgress{}
	clients := map[string]bool{}
	closedClients := map[string]bool{}
	first := []float64{}
	review := []float64{}
	closeDur := []float64{}
	now := time.Now().UTC()
	missingRecheck := 0
	failedRecheck := 0
	for _, a := range cases {
		x.CasePresentations[a.ID] = cwPresentation(a)
		x.Summary["alerts"]++
		x.Coverage.RiskEvents++
		cwAdd(programs, a.Row.Program)
		sources := cwAlertSources(a)
		x.SourceByCase[a.ID] = sources
		for _, source := range sources {
			cwAdd(riskSources, source)
		}
		switch a.Row.Level {
		case "critical":
			cwAdd(riskLevels, "extreme")
		case "watch":
			cwAdd(riskLevels, "watch")
		default:
			cwAdd(riskLevels, "ungraded")
		}
		clients[cwClientKey(a)] = true
		cwAdd(region, a.Row.Member.Region)
		cwAdd(stage, a.Status)
		if f.TimeMode == "weekly" {
			cwAdd(daily, f.Start+"~"+f.End)
		} else {
			cwAdd(daily, strings.Split(a.CreatedAt, "T")[0])
		}
		if !cwAnalyticsClosed(a.Status) && a.Status != "source_alert" {
			cwAdd(owners, a.Owner)
		}
		switch a.Status {
		case "source_alert":
			x.Summary["source_alerts"]++
		case "open":
			x.Summary["pending"]++
		case "processing", "pending_approval":
			x.Summary["processing"]++
		case "observing":
			x.Summary["observing"]++
		case "pending_review", "action_completed":
			x.Summary["pending_review"]++
		case "closed", "resolved":
			x.Summary["closed"]++
			closedClients[cwClientKey(a)] = true
		}
		if !cwAnalyticsClosed(a.Status) && a.DueDate != "" {
			if d, ok := cwParse(a.DueDate); ok && d.Before(now) {
				x.Summary["overdue"]++
			}
		}
		x.Process["created"]++
		if a.Status == "source_alert" {
			x.Process["awaiting_casework"]++
			x.Coverage.UnlinkedAlerts++
			continue
		}
		x.Coverage.LinkedCases++
		owner := strings.TrimSpace(a.Owner)
		if owner == "" {
			owner = "未填写"
		}
		progress := ownerProgress[owner]
		if progress == nil {
			progress = &cwOwnerProgress{Owner: owner}
			ownerProgress[owner] = progress
		}
		progress.Events++
		if a.ActionCompleted {
			progress.Completed++
		}
		if !cwAnalyticsClosed(a.Status) {
			progress.Todo++
			if a.DueDate != "" {
				if d, ok := cwParse(a.DueDate); ok && d.Before(now) {
					progress.Overdue++
				}
			}
		}
		cwAdd(action, a.Plan)
		if strings.TrimSpace(a.Plan) != "" {
			x.Coverage.ActionFilled++
		}
		if rca := strings.TrimSpace(a.Fields["rca"]); rca != "" {
			cwAdd(attr, rca)
			x.Coverage.CheckFilled++
		} else {
			cwAdd(attr, "未填写")
		}
		if a.Status != "open" {
			x.Process["handled"]++
		}
		if cwAnalyticsClosed(a.Status) {
			x.Process["closed"]++
			x.Outcomes["case_closed"]["closed"]++
		} else {
			x.Outcomes["case_closed"]["open"]++
		}
		created, _ := cwParse(a.CreatedAt)
		if t, ok := cwAuditTime(a, "accept", "plan"); ok {
			first = append(first, t.Sub(created).Minutes())
		}
		if t, ok := cwAuditTime(a, "complete"); ok {
			if u, ok2 := cwAuditTime(a, "return", "close", "approve"); ok2 && u.After(t) {
				review = append(review, u.Sub(t).Minutes())
			}
		}
		if a.ClosedAt != "" {
			if t, ok := cwParse(a.ClosedAt); ok {
				closeDur = append(closeDur, t.Sub(created).Minutes())
			}
		}
		if a.ActionCompleted {
			x.Effects["action_completed"]++
		} else {
			// 未完成处置不进入“处理后待复查”母集。
			continue
		}
		if a.EducationCompleted {
			x.Effects["education_completed"]++
		}
		if len(a.Rechecks) == 0 {
			missingRecheck++
			x.EffectStatus["waiting_recheck"]++
			x.Outcomes["risk_improved"]["waiting_recheck"]++
			continue
		}
		x.Coverage.RecheckCovered++
		last := a.Rechecks[len(a.Rechecks)-1]
		if last.Status == "failed" {
			failedRecheck++
			x.EffectStatus["recheck_failed"]++
			x.Outcomes["risk_improved"]["recheck_failed"]++
			continue
		}
		if cwAnalyticsClosed(a.Status) && a.ClosureReason == "risk_recovered" && last.Status == "success" && last.Level == "normal" && last.CCR != nil && last.NFS != nil {
			x.Effects["risk_recovered"]++
			x.EffectStatus["verified_improvement"]++
			x.Outcomes["risk_improved"]["improved"]++
		} else {
			x.EffectStatus["waiting_recheck"]++
			x.Outcomes["risk_improved"]["not_improved"]++
		}
	}
	x.Summary["clients"] = len(clients)
	x.Summary["processed_clients"] = len(closedClients)
	x.Region = cwCounts(region)
	x.Stage = cwCounts(stage)
	x.Attribution = cwCounts(attr)
	x.Action = cwCounts(action)
	x.Daily = cwCounts(daily)
	x.Owner = cwCounts(owners)
	x.RiskSource = cwCounts(riskSources)
	x.RiskLevel = cwCounts(riskLevels)
	x.Program = cwCounts(programs)
	ownerKeys := make([]string, 0, len(ownerProgress))
	for owner := range ownerProgress {
		ownerKeys = append(ownerKeys, owner)
	}
	sort.Strings(ownerKeys)
	for _, owner := range ownerKeys {
		x.OwnerProgress = append(x.OwnerProgress, *ownerProgress[owner])
	}
	x.Efficiency["first_action"] = cwMedian(first)
	x.Efficiency["review_wait"] = cwMedian(review)
	x.Efficiency["closure"] = cwMedian(closeDur)
	if missingRecheck > 0 {
		x.Missing = append(x.Missing, fmt.Sprintf("%d 个事件待复查", missingRecheck))
	}
	if failedRecheck > 0 {
		x.Missing = append(x.Missing, fmt.Sprintf("%d 个事件复查查询失败", failedRecheck))
	}
	if len(first) == 0 {
		x.Missing = append(x.Missing, "首次处理耗时不可计算")
	}
	if len(review) == 0 {
		x.Missing = append(x.Missing, "复核等待时长不可计算")
	}
	if len(closeDur) == 0 {
		x.Missing = append(x.Missing, "结案耗时不可计算")
	}
	if e = cwAnalyticsNotifications(&x); e != nil {
		return x, e
	}
	cwEnrichAnalytics(&x)
	return x, nil
}
func cwAnalyticsNotifications(x *cwAnalytics) error {
	if x.Notification == nil {
		x.Notification = map[string]map[string]int{}
	}
	for _, key := range []string{"test", "formal", "unknown"} {
		if x.Notification[key] == nil {
			x.Notification[key] = map[string]int{}
		}
	}
	if x.NotificationSource == nil {
		x.NotificationSource = map[string]map[string]int{}
	}
	for _, key := range []string{"auto", "manual", "test", "unknown"} {
		if x.NotificationSource[key] == nil {
			x.NotificationSource[key] = map[string]int{}
		}
	}
	if x.Outcomes == nil {
		x.Outcomes = map[string]map[string]int{}
	}
	if x.Outcomes["notification_complete"] == nil {
		x.Outcomes["notification_complete"] = map[string]int{}
	}
	db, e := cwDB()
	if e != nil {
		return e
	}
	defer db.Close()
	test := map[string]bool{}
	if rt, er := cwLoadRuntimeNotification(); er == nil {
		for _, r := range rt.TestRecipients {
			test[r.ID] = true
		}
	}
	ids := map[string]bool{}
	for _, a := range x.Cases {
		ids[a.ID] = true
	}
	rows, e := db.Query(`SELECT case_id,recipient,kind,status,message_id,notification_mode,source FROM tap_outbox
		ORDER BY CASE
			WHEN status='sent' AND TRIM(message_id)<>'' THEN 0
			WHEN status='sending' THEN 1
			WHEN status='pending' THEN 2
			WHEN status='failed' THEN 3
			ELSE 4
		END, updated_at DESC`)
	if e != nil {
		return e
	}
	defer rows.Close()
	countedCases := map[string]bool{}
	delivered := map[string]bool{}
	for rows.Next() {
		var cid, recipient, kind, status, messageID, notificationMode, source string
		if rows.Scan(&cid, &recipient, &kind, &status, &messageID, &notificationMode, &source) != nil || !ids[cid] || kind != "send" || countedCases[cid] {
			continue
		}
		if status == "sent" && strings.TrimSpace(messageID) == "" {
			status = "unknown"
		}
		countedCases[cid] = true
		mode := notificationMode
		if mode != "test" && mode != "formal" {
			mode = "formal"
			parts := strings.SplitN(recipient, ":", 2)
			if test[recipient] || (len(parts) == 2 && test[parts[1]]) {
				mode = "test"
			}
		}
		bucket := "unknown"
		switch status {
		case "sent":
			bucket = "success"
		case "failed":
			bucket = "failed"
		case "pending", "sending":
			bucket = "pending"
		}
		x.Notification[mode][bucket]++
		if source != "auto" && source != "manual" && source != "test" {
			source = "unknown"
		}
		x.NotificationSource[source][bucket]++
		if bucket == "success" {
			delivered[cid] = true
		}
	}
	if err := rows.Err(); err != nil {
		return err
	}
	for id := range ids {
		if delivered[id] {
			x.Outcomes["notification_complete"]["complete"]++
		} else {
			x.Outcomes["notification_complete"]["waiting"]++
			if !countedCases[id] {
				x.Notification["formal"]["not_initiated"]++
			}
		}
	}
	for _, a := range x.Cases {
		if !delivered[a.ID] || a.Status == "source_alert" {
			continue
		}
		owner := strings.TrimSpace(a.Owner)
		if owner == "" {
			owner = "未填写"
		}
		for i := range x.OwnerProgress {
			if x.OwnerProgress[i].Owner == owner {
				x.OwnerProgress[i].Notified++
				break
			}
		}
	}
	if x.Summary == nil {
		x.Summary = map[string]int{}
	}
	x.Summary["notified"] = x.Outcomes["notification_complete"]["complete"]
	return nil
}
func cwAttachSavedQuota(x *cwAnalytics) {
	// Reports are immutable views over already persisted weekly facts. Never call
	// submissionQuotaData here: that path can query live Aeolus quota sources.
	x.Summary["quota_full_pairs"] = 0
	x.Summary["quota_exceeded_pairs"] = 0
	x.Quota = map[string]any{"status": "saved_facts", "source": "persisted_quota_alert_cases"}
	sections := map[string]*cwQuotaAlertSection{
		"ET": {Program: "ET", Title: "ET Quota Alerts", Unit: "Account", Window: x.Filters.Start + " 至 " + x.Filters.End, Methodology: "仅读取已保存周度 Quota 预警事实；不补查 Aeolus", Note: "仅展示报告周期内已保存的 ET Quota 预警；没有保存事实不代表使用量为 0。", Rows: []cwQuotaAlertRow{}},
		"ST": {Program: "ST", Title: "ST Quota Alerts", Unit: "Brand", Window: x.Filters.Start + " 至 " + x.Filters.End, Methodology: "仅读取已保存周度 Quota 预警事实；不补查 live Quota", Note: "仅展示已保存的 ST Quota 预警；没有保存事实不代表使用量为 0。", Rows: []cwQuotaAlertRow{}},
	}
	for _, item := range x.Cases {
		if item.Kind != "quota" || sections[item.Row.Program] == nil {
			continue
		}
		used, usedErr := strconv.ParseFloat(item.Fields["used"], 64)
		quota, quotaErr := strconv.ParseFloat(item.Fields["quota"], 64)
		ratio, ratioErr := strconv.ParseFloat(item.Fields["ratio"], 64)
		var usedPtr, quotaPtr, ratioPtr, excessPtr *float64
		if usedErr == nil {
			usedPtr = &used
		}
		if quotaErr == nil {
			quotaPtr = &quota
		}
		if ratioErr == nil {
			ratioPtr = &ratio
		}
		if usedPtr != nil && quotaPtr != nil {
			excess := used - quota
			excessPtr = &excess
		}
		status := "未返回"
		if ratioPtr != nil {
			if ratio > 100 {
				status = "超额"
				x.Summary["quota_exceeded_pairs"]++
			} else if ratio == 100 {
				status = "已满额"
				x.Summary["quota_full_pairs"]++
			} else {
				status = "未满额"
			}
		}
		section := sections[item.Row.Program]
		section.Rows = append(section.Rows, cwQuotaAlertRow{Region: item.Row.Member.Region, Status: status, Owner: emptyFallback(item.Owner, "待补负责人"), NotificationStatus: emptyFallback(item.Fields["notification_result"], "未发起"), CaseStatus: item.Status, Used: usedPtr, Quota: quotaPtr, UsageRate: ratioPtr, Exceeded: excessPtr})
	}
	x.QuotaAlerts = cwQuotaAlerts{ET: *sections["ET"], ST: *sections["ST"]}
}

func cwAnalyticsHandler(w http.ResponseWriter, r *http.Request) {
	if !cwAnalyticsAuthorized(w, r) {
		return
	}
	x, e := cwAnalyticsBuild(cwAnalyticsFilters(r))
	if e != nil {
		cwWriteError(w, e)
		return
	}
	cwAttachSavedQuota(&x)
	writeJSON(w, 200, map[string]any{"data": x})
}

func cwSheetXML(rows [][]string) string {
	var b strings.Builder
	b.WriteString(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>`)
	for i, row := range rows {
		b.WriteString(`<row r="` + strconv.Itoa(i+1) + `">`)
		for j, v := range row {
			col := ""
			n := j + 1
			for n > 0 {
				n--
				col = string(rune('A'+n%26)) + col
				n /= 26
			}
			b.WriteString(`<c r="` + col + strconv.Itoa(i+1) + `" t="inlineStr"><is><t>` + html.EscapeString(v) + `</t></is></c>`)
		}
		b.WriteString(`</row>`)
	}
	b.WriteString(`</sheetData></worksheet>`)
	return b.String()
}
func cwWriteXLSX(w http.ResponseWriter, x cwAnalytics) error {
	sheets := []struct {
		name string
		rows [][]string
	}{{"汇总", cwSummaryRows(x)}, {"事件明细", cwCaseRows(x)}, {"操作历史", cwHistoryRows(x)}, {"通知及复查", cwNoticeRows(x)}}
	var buf bytes.Buffer
	z := zip.NewWriter(&buf)
	add := func(name, body string) { f, _ := z.Create(name); _, _ = f.Write([]byte(body)) }
	add("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>`+func() string {
		var s string
		for i := range sheets {
			s += fmt.Sprintf(`<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`, i+1)
		}
		return s
	}()+`</Types>`)
	add("_rels/.rels", `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`)
	var ws, rels string
	for i, s := range sheets {
		ws += fmt.Sprintf(`<sheet name="%s" sheetId="%d" r:id="rId%d"/>`, s.name, i+1, i+1)
		rels += fmt.Sprintf(`<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>`, i+1, i+1)
		add(fmt.Sprintf("xl/worksheets/sheet%d.xml", i+1), cwSheetXML(s.rows))
	}
	add("xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>`+ws+`</sheets></workbook>`)
	add("xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">`+rels+`</Relationships>`)
	if e := z.Close(); e != nil {
		return e
	}
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", `attachment; filename="tap-governance-analysis.xlsx"`)
	_, e := w.Write(buf.Bytes())
	return e
}
func cwSummaryRows(x cwAnalytics) [][]string {
	return [][]string{{"治理分析导出"}, {"筛选开始", x.Filters.Start}, {"筛选结束", x.Filters.End}, {"区域", x.Filters.Region}, {"项目", x.Filters.Program}, {"负责人", x.Filters.Owner}, {"风险等级", x.Filters.Level}, {"数据截至", x.AsOf}, {"口径", "Alert ID去重；客户按项目+客户ID去重；时间按预警创建时间"}, {"预警事件数", strconv.Itoa(x.Summary["alerts"])}, {"涉及客户数", strconv.Itoa(x.Summary["clients"])}, {"待处理", strconv.Itoa(x.Summary["pending"])}, {"处理中", strconv.Itoa(x.Summary["processing"])}, {"待复核", strconv.Itoa(x.Summary["pending_review"])}, {"已关闭", strconv.Itoa(x.Summary["closed"])}, {"逾期", strconv.Itoa(x.Summary["overdue"])}, {"通知完成", strconv.Itoa(x.Outcomes["notification_complete"]["complete"])}, {"通知待完成", strconv.Itoa(x.Outcomes["notification_complete"]["waiting"])}, {"风险改善", strconv.Itoa(x.Outcomes["risk_improved"]["improved"])}, {"等待复查", strconv.Itoa(x.Outcomes["risk_improved"]["waiting_recheck"])}}
}
func cwCaseRows(x cwAnalytics) [][]string {
	r := [][]string{{"Alert ID", "项目", "客户ID", "客户名称", "区域", "风险等级", "负责人", "状态", "创建时间", "截止日期", "关闭原因", "初始CCR", "初始NFS", "最新复查CCR", "最新复查NFS", "复查窗口", "复查状态"}}
	for _, a := range x.Cases {
		id := a.Row.Member.AccountID
		if a.Row.Program == "THT" {
			id = a.Row.Member.AdvertiserID
		}
		last := cwRecheck{}
		if len(a.Rechecks) > 0 {
			last = a.Rechecks[len(a.Rechecks)-1]
		}
		r = append(r, []string{a.ID, a.Row.Program, id, a.Row.Member.Name, a.Row.Member.Region, a.Row.Level, a.Owner, a.Status, a.CreatedAt, a.DueDate, a.ClosureReason, cwFloat(a.Row.CCR), cwFloat(a.Row.NFS), cwFloat(last.CCR), cwFloat(last.NFS), last.Start + "~" + last.End, last.Status})
	}
	return r
}
func cwHistoryRows(x cwAnalytics) [][]string {
	r := [][]string{{"Alert ID", "时间", "操作人", "操作", "状态", "说明", "版本"}}
	for _, a := range x.Cases {
		for _, h := range a.History {
			r = append(r, []string{a.ID, h.At, h.Actor, h.Operation, h.Status, h.Note, strconv.Itoa(h.Version)})
		}
	}
	return r
}
func cwNoticeRows(x cwAnalytics) [][]string {
	r := [][]string{{"Alert ID", "记录类型", "时间/接收人", "状态", "CCR", "NFS", "窗口/错误"}}
	db, e := cwDB()
	if e == nil {
		defer db.Close()
		ids := map[string]bool{}
		for _, a := range x.Cases {
			ids[a.ID] = true
		}
		rows, _ := db.Query("SELECT case_id,recipient,status,error,message_id FROM tap_outbox WHERE kind='send' ORDER BY updated_at DESC")
		if rows != nil {
			defer rows.Close()
			seenDeliveries := map[string]bool{}
			for rows.Next() {
				var id, to, s, er, messageID string
				_ = rows.Scan(&id, &to, &s, &er, &messageID)
				key := ""
				if strings.TrimSpace(messageID) != "" {
					key = id + "|" + messageID
				}
				if !ids[id] || (key != "" && seenDeliveries[key]) {
					continue
				}
				if key != "" {
					seenDeliveries[key] = true
				}
				r = append(r, []string{id, "通知", cwMaskID(to), s, "", "", er})
			}
		}
	}
	for _, a := range x.Cases {
		for _, v := range a.Rechecks {
			r = append(r, []string{a.ID, "复查", v.At, v.Status, cwFloat(v.CCR), cwFloat(v.NFS), v.Start + "~" + v.End + " " + v.Note})
		}
	}
	return r
}
func cwFloat(v *float64) string {
	if v == nil {
		return ""
	}
	return strconv.FormatFloat(*v, 'f', -1, 64)
}
func cwAnalyticsExportHandler(w http.ResponseWriter, r *http.Request) {
	if !cwAnalyticsAuthorized(w, r) {
		return
	}
	x, e := cwAnalyticsBuild(cwAnalyticsFilters(r))
	if e != nil {
		cwWriteError(w, e)
		return
	}
	if e = cwWriteXLSX(w, x); e != nil {
		cwWriteError(w, e)
	}
}

var _ *sql.DB
