package main

import "testing"

func TestSharedBusinessFilterMultiValueAndLinkedIDs(t *testing.T) {
	a := cwCase{ID: "case-1", Owner: "owner", CreatedAt: "2026-10-20T01:00:00Z", Row: wbRow{Program: "ET", Member: wbMember{Region: "APAC", Tier: "T1", Submitter: "alice", Submitters: []string{"alice", "bob"}, AccountID: "acct-main", LinkedAccountIDs: []string{"acct-linked"}, AdvertiserID: "adv-main", LinkedAdvertiserIDs: []string{"adv-linked"}}}}
	for _, f := range []businessFilter{
		{Submitter: "bob", AccountID: "acct-linked", AdvertiserID: "adv-linked", Program: "ET", Region: "APAC", Tier: "T1"},
		{Mine: "todo"}, {Mine: "submitted"},
	} {
		// Both personal views are anchored to the immutable original submitter;
		// an operational owner/reviewer assignment must not change authorship.
		if !matchBusinessCase(a, f, "bob") {
			t.Fatalf("filter did not match: %#v", f)
		}
	}
	if matchBusinessCase(a, businessFilter{AccountID: "acct"}, "") {
		t.Fatal("ID filtering must be exact")
	}
}

func TestFilterThenPaginateAndNoDuplicate(t *testing.T) {
	all := []cwCase{
		{ID: "1", Row: wbRow{Program: "ET", Member: wbMember{Submitters: []string{"a", "b"}}}},
		{ID: "2", Row: wbRow{Program: "THT", Member: wbMember{Submitters: []string{"b"}}}},
		{ID: "3", Row: wbRow{Program: "ET", Member: wbMember{Submitters: []string{"a"}}}},
	}
	filtered := []cwCase{}
	for _, a := range all {
		if matchBusinessCase(a, businessFilter{Program: "ET", Submitter: "a"}, "") {
			filtered = append(filtered, a)
		}
	}
	page := paginateCases(filtered, 2, 1)
	if len(filtered) != 2 || len(page) != 1 || page[0].ID != "3" {
		t.Fatalf("filter/pagination mismatch: %#v %#v", filtered, page)
	}
}

func TestIdentityFilterExplicitStatus(t *testing.T) {
	if status, _ := validateIdentityFilter(businessFilter{Mine: "mine"}, "alice"); status != "unsupported" {
		t.Fatal(status)
	}
	if status, _ := validateIdentityFilter(businessFilter{Mine: "todo"}, ""); status != "needs_selection" {
		t.Fatal(status)
	}
}

func TestHistoricalBatchFallsBackToExactPersistedWindow(t *testing.T) {
	legacy := cwCase{Window: wbRequest{Start: "2026-10-12", End: "2026-10-18"}}
	if !matchBusinessCase(legacy, businessFilter{BatchID: "TAP-WEEK-2026-10-12-2026-10-18"}, "") {
		t.Fatal("legacy case must map to its exact authoritative weekly window")
	}
	if matchBusinessCase(legacy, businessFilter{BatchID: "TAP-WEEK-2026-10-19-2026-10-25"}, "") {
		t.Fatal("legacy case must not leak into another weekly batch")
	}
	explicit := legacy
	explicit.Fields = map[string]string{"batch_id": "TAP-WEEK-2026-10-19-2026-10-25"}
	if matchBusinessCase(explicit, businessFilter{BatchID: "TAP-WEEK-2026-10-12-2026-10-18"}, "") {
		t.Fatal("persisted batch_id must take precedence over inferred window")
	}
}

func TestProtectionAnchorInclusiveRangeAndAnomalies(t *testing.T) {
	et := cwCase{Row: wbRow{Program: "ET", Member: wbMember{Start: "2026-10-20 12:00:00"}}}
	if !matchBusinessCase(et, businessFilter{ProtectionStartDate: "2026-10-20", ProtectionEndDate: "2026-10-20"}, "") {
		t.Fatal("single-day protection range must include both boundaries")
	}
	missing := cwCase{Row: wbRow{Program: "THT", Member: wbMember{}}}
	if matchBusinessCase(missing, businessFilter{ProtectionStartDate: "2026-10-01", ProtectionEndDate: "2026-10-31"}, "") {
		t.Fatal("missing anchor must not be guessed into a date range")
	}
	if !matchBusinessCase(missing, businessFilter{ProtectionStartDate: "2026-10-01", ProtectionEndDate: "2026-10-31", IncludeAnchorAnomalies: true}, "") {
		t.Fatal("explicit anomaly option must retain missing anchors")
	}
	ambiguous := cwCase{Row: wbRow{Program: "THT", Member: wbMember{Tickets: []wbTicket{{Start: "2026-10-01"}, {Start: "2026-10-02"}}}}}
	if anchor, status := authoritativeProtectionAnchor(ambiguous); anchor != "" || status != "ambiguous" {
		t.Fatalf("ambiguous THT anchor must remain explicit: anchor=%q status=%q", anchor, status)
	}
	st := cwCase{Row: wbRow{Program: "ST", Member: wbMember{Quarter: "Q4"}}}
	if anchor, status := authoritativeProtectionAnchor(st); anchor != "2026-09-30" || status != "available" {
		t.Fatalf("ST Q4 formal anchor mismatch: %q %q", anchor, status)
	}
}
