package main

import (
	"testing"
	"time"
)

func gapFloat(value float64) *float64 { return &value }

func TestNormalizeSTRevenueSourceNullOnlyProvenNoData(t *testing.T) {
	job := wbJob{Rows: []wbRow{
		{Program: "ST", Source: map[string]any{"revenue": map[string]any{"status": "no_data"}}},
		{Program: "ST", Source: map[string]any{"revenue": map[string]any{"status": "failed"}}},
		{Program: "THT", Source: map[string]any{"revenue": map[string]any{"status": "no_data"}}},
	}}
	if got := wbNormalizeSTRevenueSourceNull(&job); got != 1 {
		t.Fatalf("normalized=%d, want 1", got)
	}
	revenue := job.Rows[0].Source.(map[string]any)["revenue"].(map[string]any)
	if revenue["status"] != metricSourceNull {
		t.Fatalf("status=%v, want source_null", revenue["status"])
	}
	if got := job.Rows[1].Source.(map[string]any)["revenue"].(map[string]any)["status"]; got != "failed" {
		t.Fatalf("failed evidence was overwritten: %v", got)
	}
}

func TestNormalizeTHTTerminalQueryStatuses(t *testing.T) {
	job := wbJob{Rows: []wbRow{
		{Program: "THT", Comparison: wbComparison{Status: metricAmbiguousAnchor, Source: map[string]any{"query_status": metricFailed}}},
		{Program: "THT", Comparison: wbComparison{Status: metricNotApplicable}},
	}}
	if got := wbNormalizeTHTTerminalQueryStatuses(&job); got != 2 {
		t.Fatalf("normalized=%d, want 2", got)
	}
	if got := job.Rows[0].Comparison.Source["query_status"]; got != metricAmbiguousAnchor {
		t.Fatalf("query_status=%v, want ambiguous_anchor", got)
	}
	if got := job.Rows[1].Comparison.Source["query_status"]; got != metricNotApplicable {
		t.Fatalf("query_status=%v, want not_applicable", got)
	}
}

func TestSelectTHTDirectMetricUsesAdvertiserPrimaryKeySafely(t *testing.T) {
	noData := wbBatchMetric{Status: "no_data", AdvertiserID: "7100000000000000001", RequestID: "req-null"}
	metric, status, err := wbSelectTHTDirectMetric([]wbBatchMetric{noData}, "7000000000000000001")
	if err != nil || status != metricSourceNull || metric.RequestID != "req-null" {
		t.Fatalf("no-data selection failed: metric=%+v status=%s err=%v", metric, status, err)
	}

	first := wbBatchMetric{Status: "success", AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001", CCR: gapFloat(1)}
	second := wbBatchMetric{Status: "success", AccountID: "7000000000000000002", AdvertiserID: "7100000000000000001", CCR: gapFloat(2)}
	metric, status, err = wbSelectTHTDirectMetric([]wbBatchMetric{first, second}, first.AccountID)
	if err != nil || status != "success" || metric.AccountID != first.AccountID {
		t.Fatalf("exact account selection failed: metric=%+v status=%s err=%v", metric, status, err)
	}
	if _, _, err = wbSelectTHTDirectMetric([]wbBatchMetric{first, second}, ""); err == nil {
		t.Fatal("distinct account facts must remain ambiguous without an exact account")
	}
}

func TestApplyTHTGapChunkTurnsSuccessfulNoRowIntoSourceNull(t *testing.T) {
	now := time.Date(2026, 10, 28, 0, 0, 0, 0, cwLocation())
	job := wbJob{Request: wbRequest{Program: "THT"}, Rule: testRule(), Rows: []wbRow{{
		Program:     "THT",
		Member:      wbMember{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001", TicketID: "ticket-1", Start: "2026-10-01"},
		Comparison:  wbComparison{Status: "not_queried"},
		Advertisers: []wbAdvertiserEvidence{{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001"}},
	}}}
	pre := map[string][]wbBatchMetric{"7100000000000000001": {{Status: "no_data", AdvertiserID: "7100000000000000001", RequestID: "pre-request"}}}
	post := map[string][]wbBatchMetric{"7100000000000000001": {{Status: "no_data", AdvertiserID: "7100000000000000001", RequestID: "post-request"}}}
	wbApplyTHTGapChunk(&job, []int{0}, pre, post, nil, nil, now)
	got := job.Rows[0].Comparison
	if got.Status != metricSourceNull || got.PreCCRFact.Status != metricSourceNull || got.PostCCRFact.Status != metricSourceNull || got.IncreaseFact.Status != metricSourceNull {
		t.Fatalf("comparison not terminal source_null: %+v", got)
	}
	if got.Source["query_status"] != metricSourceNull || got.Source["grain"] != "advertiser_event_window" {
		t.Fatalf("query evidence missing: %+v", got.Source)
	}
}

func TestTHTGapRepairDoesNotRequeryTerminalFacts(t *testing.T) {
	rows := []wbRow{
		{Program: "THT", Comparison: wbComparison{Status: metricAvailable}},
		{Program: "THT", Comparison: wbComparison{Status: metricSourceNull}},
		{Program: "THT", Comparison: wbComparison{Status: "window_incomplete"}},
		{Program: "THT", Comparison: wbComparison{Status: metricMissingAnchor, MissingReason: "missing_or_invalid_protection_starttime"}},
		{Program: "THT", Comparison: wbComparison{Status: metricMissingAnchor, MissingReason: "comparison_result_missing", Source: map[string]any{"query_status": "failed"}}},
	}
	for i := 0; i < 4; i++ {
		if wbTHTComparisonNeedsGapRepair(rows[i]) {
			t.Fatalf("terminal row %d selected for repair: %+v", i, rows[i].Comparison)
		}
	}
	if !wbTHTComparisonNeedsGapRepair(rows[4]) {
		t.Fatal("legacy comparison_result_missing row should be repaired")
	}
	rows[4].Comparison.Source["gap_repair_attempts"] = 2
	rows[4].Comparison.Status = metricFailed
	if wbTHTComparisonNeedsGapRepair(rows[4]) {
		t.Fatal("failed row must not be retried after the targeted retry")
	}
}

func TestTHTFunnelSeparatesAmbiguousFromFailed(t *testing.T) {
	job := wbJob{Request: wbRequest{Program: "THT"}, Complete: true, Rows: []wbRow{{
		Program:    "THT",
		Member:     wbMember{AdvertiserID: "7100000000000000001", Start: "2026-10-01"},
		Comparison: wbComparison{Status: metricAmbiguousAnchor, MissingReason: "comparison_pair_ambiguous", Source: map[string]any{"query_status": metricAmbiguousAnchor, "window_complete": true}},
	}}}
	funnel := wbBuildProgramFunnel(job)
	if funnel.ComparisonFailed.Value == nil || *funnel.ComparisonFailed.Value != 0 {
		t.Fatalf("ambiguous comparison counted as failed: %+v", funnel.ComparisonFailed)
	}
	if funnel.ComparisonAmbiguous.Value == nil || *funnel.ComparisonAmbiguous.Value != 1 {
		t.Fatalf("ambiguous comparison not counted explicitly: %+v", funnel.ComparisonAmbiguous)
	}
}
