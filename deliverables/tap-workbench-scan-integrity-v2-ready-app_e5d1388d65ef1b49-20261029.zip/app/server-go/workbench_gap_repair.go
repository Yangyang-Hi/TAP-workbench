package main

import (
	"context"
	"fmt"
	"net/http"
	"sort"
	"strings"
	"time"
)

const wbGapRepairProgram = "GAP_REPAIR"

func wbNormalizeSTRevenueSourceNull(job *wbJob) int {
	normalized := 0
	for i := range job.Rows {
		row := &job.Rows[i]
		if !strings.EqualFold(row.Program, "ST") || row.Revenue != nil {
			continue
		}
		source, ok := row.Source.(map[string]any)
		if !ok {
			continue
		}
		revenue, ok := source["revenue"].(map[string]any)
		if !ok || !strings.EqualFold(asString(revenue["status"]), "no_data") {
			continue
		}
		// The nested source object is persisted only after RID 2980054 returned
		// successfully. No fact row is therefore an explicit source NULL.
		revenue["status"] = metricSourceNull
		if strings.TrimSpace(asString(revenue["error"])) == "" {
			revenue["error"] = "权威 Revenue 查询成功但该 Account 无事实行"
		}
		normalized++
	}
	return normalized
}

func wbNormalizeTHTTerminalQueryStatuses(job *wbJob) int {
	normalized := 0
	for i := range job.Rows {
		row := &job.Rows[i]
		if !strings.EqualFold(row.Program, "THT") {
			continue
		}
		target := ""
		switch row.Comparison.Status {
		case metricAmbiguousAnchor:
			target = metricAmbiguousAnchor
		case "window_incomplete":
			target = "window_incomplete"
		case metricNotApplicable:
			target = metricNotApplicable
		}
		if target == "" || strings.EqualFold(asString(row.Comparison.Source["query_status"]), target) {
			continue
		}
		if row.Comparison.Source == nil {
			row.Comparison.Source = map[string]any{"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "advertiser_event_window", "protection_record": row.Member.TicketID}
		}
		row.Comparison.Source["query_status"] = target
		normalized++
	}
	return normalized
}

func wbTHTComparisonNeedsGapRepair(row wbRow) bool {
	if !strings.EqualFold(row.Program, "THT") {
		return false
	}
	status := strings.ToLower(strings.TrimSpace(row.Comparison.Status))
	reason := strings.ToLower(strings.TrimSpace(row.Comparison.MissingReason))
	queryStatus := strings.ToLower(strings.TrimSpace(asString(row.Comparison.Source["query_status"])))
	attempts := asInt(row.Comparison.Source["gap_repair_attempts"])
	queryError := strings.ToLower(strings.TrimSpace(asString(row.Comparison.Source["query_error"])))
	if status == metricSourceNull || status == metricAvailable || status == "window_incomplete" || status == metricNotApplicable || status == metricAmbiguousAnchor {
		return false
	}
	if status == metricMissingAnchor && reason != "comparison_result_missing" {
		return false
	}
	if attempts >= 2 && (status == metricFailed || queryStatus == metricFailed) && !strings.Contains(queryError, "context canceled") {
		return false
	}
	return status == "" || status == "not_queried" || status == metricFailed || queryStatus == "" || queryStatus == "not_queried" || queryStatus == metricFailed || reason == "comparison_result_missing"
}

func wbSameNullableMetric(a, b *float64) bool {
	if a == nil || b == nil {
		return a == nil && b == nil
	}
	return *a == *b
}

func wbSelectTHTDirectMetric(metrics []wbBatchMetric, accountID string) (wbBatchMetric, string, error) {
	if len(metrics) == 0 {
		return wbBatchMetric{}, metricSourceNull, nil
	}
	if len(metrics) == 1 && metrics[0].Status == "no_data" {
		return metrics[0], metricSourceNull, nil
	}
	accountID = strings.TrimSpace(accountID)
	if accountID != "" {
		matched := make([]wbBatchMetric, 0, 1)
		for _, metric := range metrics {
			if strings.TrimSpace(metric.AccountID) == accountID {
				matched = append(matched, metric)
			}
		}
		if len(matched) == 1 {
			return matched[0], "success", nil
		}
		if len(matched) > 1 {
			return wbBatchMetric{}, metricFailed, fmt.Errorf("comparison_pair_ambiguous: advertiser_id returned duplicate account pair")
		}
	}
	if len(metrics) == 1 {
		return metrics[0], "success", nil
	}
	first := metrics[0]
	identical := true
	for _, metric := range metrics[1:] {
		if !wbSameNullableMetric(first.CCR, metric.CCR) || !wbSameNullableMetric(first.NFS, metric.NFS) {
			identical = false
			break
		}
	}
	if identical {
		return first, "success", nil
	}
	return wbBatchMetric{}, metricFailed, fmt.Errorf("comparison_pair_ambiguous: advertiser_id maps to %d distinct account facts", len(metrics))
}

type wbTHTGapGroup struct {
	window  wbComparisonWindow
	indices []int
}

func wbApplyTHTGapChunk(job *wbJob, indices []int, pre, post map[string][]wbBatchMetric, preErr, postErr error, now time.Time) {
	for _, index := range indices {
		row := &job.Rows[index]
		attempts := asInt(row.Comparison.Source["gap_repair_attempts"]) + 1
		id := strings.TrimSpace(row.Member.AdvertiserID)
		window, windowErr := wbBuildComparisonWindow("THT", row.Member.Start, now)
		if windowErr != nil {
			row.Comparison = wbUnavailableComparison("THT", row.Member.Start, windowErr.Error(), now)
			row.Comparison.Source = map[string]any{"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "advertiser_event_window", "protection_record": row.Member.TicketID, "query_status": metricMissingAnchor, "gap_repair_attempts": attempts}
			continue
		}
		if !window.Complete {
			row.Comparison = wbComparisonResult("THT", row.Member.Start, nil, nil, now)
			row.Comparison.Status, row.Comparison.MissingReason = "window_incomplete", "post_observation_window_not_complete"
			row.Comparison.PreCCRFact = queryingMetricFact("Post 观察窗口尚未结束")
			row.Comparison.PostCCRFact = queryingMetricFact("Post 观察窗口尚未结束")
			wbFinalizeComparisonFacts(&row.Comparison)
			row.Comparison.Source = map[string]any{"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "advertiser_event_window", "protection_record": row.Member.TicketID, "window_complete": false, "query_status": "window_incomplete", "gap_repair_attempts": attempts}
			continue
		}
		if preErr != nil || postErr != nil {
			reason := sanitizeLogText(fmt.Sprintf("pre=%v; post=%v", preErr, postErr))
			row.Comparison = wbUnavailableComparison("THT", row.Member.Start, "comparison_source_error", now)
			row.Comparison.Source = map[string]any{"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "advertiser_event_window", "protection_record": row.Member.TicketID, "window_complete": true, "query_status": metricFailed, "query_error": reason, "gap_repair_attempts": attempts}
			continue
		}
		preMetric, preStatus, preSelectErr := wbSelectTHTDirectMetric(pre[id], row.Member.AccountID)
		postMetric, postStatus, postSelectErr := wbSelectTHTDirectMetric(post[id], row.Member.AccountID)
		if preSelectErr != nil || postSelectErr != nil {
			reason := sanitizeLogText(fmt.Sprintf("pre=%v; post=%v", preSelectErr, postSelectErr))
			row.Comparison = wbUnavailableComparison("THT", row.Member.Start, "comparison_pair_ambiguous", now)
			row.Comparison.Source = map[string]any{"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "advertiser_event_window", "protection_record": row.Member.TicketID, "window_complete": true, "query_status": metricAmbiguousAnchor, "query_error": reason, "gap_repair_attempts": attempts}
			continue
		}
		row.Comparison = wbSuccessfulComparison("THT", row.Member.Start, preMetric.CCR, postMetric.CCR, now)
		row.Comparison.PreNFS, row.Comparison.PostNFS = preMetric.NFS, postMetric.NFS
		wbFinalizeComparison(&row.Comparison)
		queryStatus := "success"
		if preStatus == metricSourceNull || postStatus == metricSourceNull || preMetric.CCR == nil || postMetric.CCR == nil {
			queryStatus = metricSourceNull
		}
		row.Comparison.Source = map[string]any{
			"source": "tht_current_ccr_nfs", "rid": 2942519, "grain": "advertiser_event_window", "window_complete": true,
			"filters":     map[string]any{"id_dimension": "advertiser_id", "advertiser_id": id, "protection_record": row.Member.TicketID, "pre": []string{window.PreStart, window.PreEnd}, "post": []string{window.PostStart, window.PostEnd}},
			"request_ids": map[string]string{"pre": preMetric.RequestID, "post": postMetric.RequestID}, "query_status": queryStatus, "gap_repair_attempts": attempts,
		}
		for j := range row.Advertisers {
			if row.Advertisers[j].AdvertiserID != id {
				continue
			}
			row.Advertisers[j].PreCCR, row.Advertisers[j].PostCCR = row.Comparison.PreCCR, row.Comparison.PostCCR
			row.Advertisers[j].PreCCRFact, row.Advertisers[j].PostCCRFact, row.Advertisers[j].IncreaseFact = row.Comparison.PreCCRFact, row.Comparison.PostCCRFact, row.Comparison.IncreaseFact
			row.Advertisers[j].CCRDelta, row.Advertisers[j].CCRGrowthPct = row.Comparison.CCRDelta, row.Comparison.CCRGrowthPct
			row.Advertisers[j].PreNFS, row.Advertisers[j].PostNFS = row.Comparison.PreNFS, row.Comparison.PostNFS
			row.Advertisers[j].NFSDelta, row.Advertisers[j].NFSGrowthPct = row.Comparison.NFSDelta, row.Comparison.NFSGrowthPct
			row.Advertisers[j].ComparisonSource, row.Advertisers[j].ComparisonStatus, row.Advertisers[j].ComparisonReason = row.Comparison.Source, row.Comparison.Status, row.Comparison.MissingReason
		}
		row.AdvertiserTop10 = topAdvertisers(row.Advertisers, 10)
		row.Message = wbMessage(*row, job.Request, job.Rule)
	}
}

func wbResumeTHTComparisonGaps(request *http.Request, jobID string, maxChunks int) (int, int, int, error) {
	wbMu.Lock()
	state, err := wbReadDisk()
	if err != nil {
		wbMu.Unlock()
		return 0, 0, 0, err
	}
	job, ok := state.Jobs[jobID]
	wbMu.Unlock()
	if !ok {
		return 0, 0, 0, fmt.Errorf("scan not found")
	}
	now := time.Now()
	groups := map[string]*wbTHTGapGroup{}
	terminalized := 0
	terminalIndices := make([]int, 0)
	for i, row := range job.Rows {
		if !wbTHTComparisonNeedsGapRepair(row) {
			continue
		}
		window, windowErr := wbBuildComparisonWindow("THT", row.Member.Start, now)
		if windowErr != nil || !window.Complete {
			wbApplyTHTGapChunk(&job, []int{i}, nil, nil, nil, nil, now)
			terminalIndices = append(terminalIndices, i)
			terminalized++
			continue
		}
		key := strings.Join([]string{window.PreStart, window.PreEnd, window.PostStart, window.PostEnd}, "|")
		if groups[key] == nil {
			groups[key] = &wbTHTGapGroup{window: window}
		}
		groups[key].indices = append(groups[key].indices, i)
	}
	if terminalized > 0 {
		wbMu.Lock()
		state, err = wbReadDisk()
		if err == nil {
			persisted := state.Jobs[jobID]
			for _, index := range terminalIndices {
				wbApplyTHTGapChunk(&persisted, []int{index}, nil, nil, nil, nil, now)
			}
			state.Jobs[jobID] = persisted
			err = wbWriteDisk(state)
		}
		wbMu.Unlock()
		if err != nil {
			return 0, 0, terminalized, err
		}
	}
	keys := make([]string, 0, len(groups))
	for key := range groups {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	processedChunks, processedRows := 0, 0
	for _, key := range keys {
		group := groups[key]
		for start := 0; start < len(group.indices); start += wbTHTMetricChunkSize {
			if maxChunks > 0 && processedChunks >= maxChunks {
				break
			}
			end := start + wbTHTMetricChunkSize
			if end > len(group.indices) {
				end = len(group.indices)
			}
			indices := group.indices[start:end]
			ids := make([]string, 0, len(indices))
			for _, index := range indices {
				ids = append(ids, job.Rows[index].Member.AdvertiserID)
			}
			ids = uniqueNonEmpty(ids)
			ctx, cancel := context.WithTimeout(request.Context(), 180*time.Second)
			pre, preErr := wbQueryTHTComparisonBatch(ctx, request, ids, group.window.PreStart, group.window.PreEnd)
			post, postErr := wbQueryTHTComparisonBatch(ctx, request, ids, group.window.PostStart, group.window.PostEnd)
			cancel()
			if request.Context().Err() != nil {
				return processedChunks, processedRows, terminalized, request.Context().Err()
			}

			wbMu.Lock()
			state, err = wbReadDisk()
			if err == nil {
				persisted := state.Jobs[jobID]
				wbApplyTHTGapChunk(&persisted, indices, pre, post, preErr, postErr, now)
				persisted.Stage = fmt.Sprintf("gap_repair:tht_comparison:%d", processedRows+len(indices))
				state.Jobs[jobID] = persisted
				err = wbWriteDisk(state)
			}
			wbMu.Unlock()
			if err != nil {
				return processedChunks, processedRows, terminalized, err
			}
			processedChunks++
			processedRows += len(indices)
			if preErr != nil || postErr != nil {
				logMsg(fmt.Sprintf("[gap-repair] scan_id=%s THT comparison ids=%d pre_error=%v post_error=%v", jobID, len(ids), preErr, postErr), "plugin")
			}
		}
		if maxChunks > 0 && processedChunks >= maxChunks {
			break
		}
	}
	wbMu.Lock()
	state, err = wbReadDisk()
	if err == nil {
		job = state.Jobs[jobID]
	}
	wbMu.Unlock()
	remaining := 0
	for _, row := range job.Rows {
		if wbTHTComparisonNeedsGapRepair(row) {
			remaining++
		}
	}
	return processedChunks, processedRows, terminalized, err
}

func wbResumeGapRepair(request *http.Request, jobID string, maxChunks int) (map[string]any, int) {
	if maxChunks < 0 {
		return map[string]any{"error": "max_chunks must be >= 0"}, http.StatusBadRequest
	}
	pairProcessed, pairRemaining, err := wbResumeAdvertiserCurrentProgram(request, jobID, maxChunks, "ST")
	if err != nil {
		return map[string]any{"error": "ST advertiser Current repair: " + err.Error()}, http.StatusBadGateway
	}
	thtChunks, thtProcessed, thtTerminalized, err := wbResumeTHTComparisonGaps(request, jobID, maxChunks)
	if err != nil {
		return map[string]any{"error": "THT comparison repair: " + err.Error()}, http.StatusBadGateway
	}
	wbMu.Lock()
	state, err := wbReadDisk()
	if err != nil {
		wbMu.Unlock()
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	job, ok := state.Jobs[jobID]
	if !ok {
		wbMu.Unlock()
		return map[string]any{"error": "scan not found"}, http.StatusNotFound
	}
	revenueNormalized := wbNormalizeSTRevenueSourceNull(&job)
	terminalStatusNormalized := wbNormalizeTHTTerminalQueryStatuses(&job)
	thtRemaining := 0
	for _, row := range job.Rows {
		if wbTHTComparisonNeedsGapRepair(row) {
			thtRemaining++
		}
	}
	job.Stage = fmt.Sprintf("gap_repair:st_pairs_remaining=%d:tht_comparison_remaining=%d", pairRemaining, thtRemaining)
	state.Jobs[jobID] = job
	err = wbWriteDisk(state)
	wbMu.Unlock()
	if err != nil {
		return map[string]any{"error": err.Error()}, http.StatusInternalServerError
	}
	logMsg(fmt.Sprintf("[gap-repair] scan_id=%s ST_pair_ids_processed=%d ST_pair_ids_remaining=%d ST_revenue_source_null=%d THT_chunks=%d THT_rows_processed=%d THT_terminalized=%d THT_remaining=%d", jobID, pairProcessed, pairRemaining, revenueNormalized, thtChunks, thtProcessed, thtTerminalized, thtRemaining), "plugin")
	return map[string]any{
		"id": jobID, "stage": job.Stage,
		"st_advertiser_current_processed_ids": pairProcessed, "st_advertiser_current_remaining_ids": pairRemaining, "st_revenue_source_null_normalized": revenueNormalized,
		"tht_terminal_status_normalized":  terminalStatusNormalized,
		"tht_comparison_processed_chunks": thtChunks, "tht_comparison_processed_rows": thtProcessed, "tht_comparison_terminalized": thtTerminalized, "tht_comparison_remaining_rows": thtRemaining,
		"classification": wbClassifyRows(job.Rows), "pair_classification": wbClassifyPairFields(job.Rows),
		"side_effects": map[string]any{"membership_scan": false, "new_task": false, "new_event": false, "case": false, "notification": false, "reported_reasons": false, "allowlist": false},
	}, http.StatusOK
}
