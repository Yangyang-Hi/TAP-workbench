// CODE GENERATED FROM app/api/api.yaml BY tools/gen_api.py — DO NOT EDIT
package main

import "net/http"

// 本文件由 IDL 生成，登记 overview 资源的路由契约。
// 业务逻辑写在 handler_overview.go 的 handler 函数里，不要改本文件。
func init() {
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/overview/accounts",
		Summary: "只读查询四 Tier 账户快照分布，不扫描、不建单、不发送",
		Handler: overviewAccountsList,
		Tags:    []string{"overview", "readonly"},
		QueryParams: []Param{
			{Name: "end_date", Type: "string", Description: "截止日期 YYYY-MM-DD，默认中国时区今天，向前查找 14 天"},
			{Name: "region", Type: "string", Description: "源报表 Sales Region，默认 Global；不响应 Program、Tier 或 Submitter"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status":                "unavailable",
				"reason":                "",
				"requested_end_date":    "",
				"data_as_of":            "",
				"region":                "Global",
				"tier_membership_total": "None",
				"rows":                  []any{},
				"queried_at":            "",
				"attempts":              0,
				"diagnostics":           map[string]any{},
				"source": map[string]any{
					"rid":    2891943,
					"sid":    1280034,
					"app_id": 800414,
				},
				"side_effects": false,
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/overview/governance",
		Summary: "从最新完整已保存批次及 Cloud 权威事件通知生成风险处置汇总",
		Handler: overviewGovernanceList,
		Tags:    []string{"overview", "casework", "readonly"},
		QueryParams: []Param{
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
			{Name: "program", Type: "string", Description: "可选 ET、ST、THT"},
			{Name: "submitter", Type: "string", Description: "可选原提报人精确匹配"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status":             "unavailable",
				"reason":             "",
				"window":             map[string]any{},
				"alert_events":       0,
				"evaluated_subjects": 0,
				"risk_subjects":      0,
				"risk_share":         "None",
				"risk_share_scope":   "",
				"top20_subjects":     0,
				"by_program":         map[string]any{},
				"by_region":          map[string]any{},
				"by_level":           map[string]any{},
				"states":             map[string]any{},
				"submitters":         []any{},
				"coverage":           map[string]any{},
				"coverage_status":    "partial",
				"coverage_note":      "仅覆盖下列已保存扫描批次及其已评估主体",
				"batch_windows": []any{
					map[string]any{
						"batch_id":           "",
						"program":            "ET",
						"start_date":         "",
						"end_date":           "",
						"coverage":           "partial",
						"evaluated_subjects": 0,
						"risk_subjects":      0,
					},
				},
				"source_batches":       []any{},
				"risk_basis":           "",
				"notification_binding": "",
				"source_status":        map[string]any{},
				"side_effects":         false,
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/overview/metrics/{metric}",
		Summary: "只读查询 Overview 专属风神原生聚合报表，不启动扫描或通知",
		Handler: overviewMetricsByMetricGet,
		Tags:    []string{"overview", "readonly"},
		QueryParams: []Param{
			{Name: "start_date", Type: "string", Description: "区间开始日 YYYY-MM-DD，默认本季度起点"},
			{Name: "end_date", Type: "string", Description: "区间结束日 YYYY-MM-DD，默认今天"},
			{Name: "region", Type: "string", Description: "Sales Region，默认 Global；仅当源合同支持时作为过滤条件下推"},
			{Name: "tier", Type: "string", Description: "逗号分隔的 ST/HT/BT/ET；仅作为源过滤条件，P0 与 Approval 不据此拆分返回"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"module":       "",
				"status":       "unavailable",
				"reason":       "",
				"rows":         []any{},
				"summary":      map[string]any{},
				"source":       map[string]any{},
				"diagnostics":  map[string]any{},
				"window":       map[string]any{},
				"queried_at":   "",
				"side_effects": false,
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/overview/quota",
		Summary: "复用现有 ET Account 与 ST Brand 配额只读聚合并按季度分开",
		Handler: overviewQuotaList,
		Tags:    []string{"overview", "quota", "readonly"},
		QueryParams: []Param{
			{Name: "start_date", Type: "string"},
			{Name: "end_date", Type: "string"},
			{Name: "region", Type: "string"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"status": "unavailable",
				"window": map[string]any{},
				"quarters": []any{
					map[string]any{
						"quarter":                "2026 Q4",
						"status":                 "partial",
						"baseline_policy":        "confirmed_q4",
						"baseline_source_period": "2026 Q4",
						"usage_window": map[string]any{
							"start_date": "2026-10-12",
							"end_date":   "2026-10-18",
						},
						"quota_period": map[string]any{
							"label":      "2026 Q4",
							"start_date": "2026-10-01",
							"end_date":   "2026-12-31",
						},
						"numerator_definition":       "所选区间与本季度交集内的获批去重使用量",
						"denominator_definition":     "对应季度已确认配额",
						"st_interval_usage_status":   "unavailable",
						"st_quarter_snapshot_status": "available",
						"et": map[string]any{
							"usage_count":            0,
							"quota":                  6356,
							"ratio":                  0,
							"baseline_policy":        "confirmed_q4",
							"usage_window":           map[string]any{},
							"quota_period":           map[string]any{},
							"numerator_definition":   "",
							"denominator_definition": "",
						},
						"st": map[string]any{
							"usage_count":             "None",
							"quota":                   817,
							"ratio":                   "None",
							"quarter_snapshot_count":  272,
							"quarter_snapshot_status": "available",
							"baseline_policy":         "confirmed_q4",
							"usage_window":            map[string]any{},
							"quota_period":            map[string]any{},
							"numerator_definition":    "",
							"denominator_definition":  "",
						},
					},
				},
				"queried_at":   "",
				"side_effects": false,
				"scope":        "ET Account / ST Brand",
			},
		},
	})
}
