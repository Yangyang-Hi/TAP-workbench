package main

import (
	"fmt"
	"html"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"
)

func cwH(v string) string { return html.EscapeString(v) }
func cwPct(n, d int) string {
	if d == 0 {
		return "不适用"
	}
	return fmt.Sprintf("%.1f%%（%d/%d）", float64(n)*100/float64(d), n, d)
}
func cwMetric(v *float64, digits int) string {
	if v == nil {
		return "—"
	}
	return strconv.FormatFloat(*v, 'f', digits, 64)
}
func cwBeijing(v string) string {
	t, ok := cwParse(v)
	if !ok {
		return emptyFallback(v, "—")
	}
	loc, _ := time.LoadLocation("Asia/Shanghai")
	return t.In(loc).Format("2006-01-02 15:04")
}
func cwNamedCounts(rows []cwCount, names map[string]string) []cwCount {
	out := append([]cwCount(nil), rows...)
	for i := range out {
		if names[out[i].Key] != "" {
			out[i].Label = names[out[i].Key]
		}
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].Count > out[j].Count })
	return out
}
func cwCountBars(title string, rows []cwCount, denominator int, note string) string {
	var b strings.Builder
	b.WriteString("<article class=chart><h3>" + cwH(title) + "</h3>")
	if len(rows) == 0 {
		b.WriteString("<div class=empty>暂无数据</div>")
	} else {
		max := 1
		for _, r := range rows {
			if r.Count > max {
				max = r.Count
			}
		}
		for _, r := range rows {
			b.WriteString(fmt.Sprintf("<div class=bar><span>%s</span><i><b style=\"width:%.1f%%\"></b></i><strong>%d<small>%s</small></strong></div>", cwH(r.Label), float64(r.Count)*100/float64(max), r.Count, cwPct(r.Count, denominator)))
		}
	}
	if note != "" {
		b.WriteString("<p class=note>" + cwH(note) + "</p>")
	}
	b.WriteString("</article>")
	return b.String()
}
func cwAnalyticsClientID(a cwCase) string {
	if a.Row.Program == "THT" {
		return a.Row.Member.AdvertiserID
	}
	return a.Row.Member.AccountID
}
func cwLastRecheck(a cwCase) cwRecheck {
	if len(a.Rechecks) == 0 {
		return cwRecheck{}
	}
	return a.Rechecks[len(a.Rechecks)-1]
}
func cwHTMLSummary(x cwAnalytics) string {
	parts := []string{fmt.Sprintf("本期 %d 条风险事件涉及 %d 个去重客户。", x.Summary["alerts"], x.Summary["clients"]), fmt.Sprintf("已通知 %d 条；待处理/逾期分别为 %d/%d 条。", x.Summary["notified"], x.Summary["pending"], x.Summary["overdue"]), fmt.Sprintf("Quota 已满额/超额 Region×Tier 为 %d/%d 个。", x.Summary["quota_full_pairs"], x.Summary["quota_exceeded_pairs"])}
	return strings.Join(parts, " ")
}
func cwDispositionTable(x cwAnalytics) string {
	states := [][2]string{{"pending", "待处理"}, {"processing", "处理中"}, {"observing", "持续观察"}, {"pending_review", "待复核"}, {"closed", "已关闭"}}
	return func() string {
		var b strings.Builder
		b.WriteString("<div class=kpis>")
		for _, s := range states {
			b.WriteString("<div><span>" + s[1] + "</span><strong>" + strconv.Itoa(x.Summary[s[0]]) + "</strong></div>")
		}
		b.WriteString("</div>")
		return b.String()
	}()
}
func cwAnalyticsEvidenceHTML(x cwAnalytics) string {
	var b strings.Builder
	b.WriteString("<section><h3>A1.1 Structured Alert Evidence</h3><div class=scroll><table><thead><tr><th>Submitter</th><th>Alert Type</th><th>Alert Level</th><th>Status</th><th>Time Window</th><th>Region</th><th>Account ID / Account Name</th><th>Advertiser ID</th><th>P0 CCR</th><th>P0 NFS</th><th>Revenue</th><th>Comparison Increase</th><th>Comparison Status</th><th>Reported Reasons</th><th>Trigger Criteria</th></tr></thead><tbody>")
	for _, a := range x.Cases {
		view, ok := x.CasePresentations[a.ID]
		if !ok {
			view = cwPresentation(a)
		}
		b.WriteString("<tr><td>" + cwH(emptyFallback(view.Submitter, "—")) + "</td><td>" + cwH(emptyFallback(view.AlertType, "—")) + "</td><td>" + cwH(emptyFallback(view.AlertLevel, "—")) + "</td><td>" + cwH(emptyFallback(view.Status, "—")) + "</td><td>" + cwH(emptyFallback(view.TimeWindow, "—")) + "</td><td>" + cwH(emptyFallback(view.Region, "—")) + "</td><td>" + cwH(emptyFallback(strings.TrimSpace(view.AccountID+" / "+view.AccountName), "—")) + "</td><td>" + cwH(emptyFallback(view.AdvertiserID, "—")) + "</td><td>" + cwFormatNumber(view.P0CCR, 2) + "</td><td>" + cwFormatNumber(view.P0NFS, 0) + "</td><td>" + cwFormatNumber(view.Revenue, 2) + "</td><td>" + cwFormatPercent(view.CCRGrowthPct) + "</td><td>" + cwH(emptyFallback(strings.TrimSpace(view.ComparisonStatus+" · "+view.ComparisonReason), "—")) + "</td><td>" + cwH(cwReportedReasonsText(view.ReportedReasons)) + "</td><td>" + cwH(emptyFallback(strings.Join(view.TriggerCriteria, " / "), "—")) + "</td></tr>")
	}
	if len(x.Cases) == 0 {
		b.WriteString("<tr><td colspan=15>暂无风险事件</td></tr>")
	}
	b.WriteString("</tbody></table></div></section>")
	return b.String()
}

func cwAnalyticsHTML(x cwAnalytics) string {
	var b strings.Builder
	b.WriteString(`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>TAP 初步治理分析报告</title><style>:root{--ink:#182334;--muted:#65716a;--line:#dfe5df;--paper:#fff;--ground:#f5f7f6;--brand:#2f6f4e;--soft:#edf6f0;--warn:#fff8e5}*{box-sizing:border-box}body{margin:0;background:var(--ground);color:var(--ink);font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.report{max-width:1280px;margin:auto;padding:24px 28px 48px}.head{position:relative;padding:18px 0 16px;border-bottom:1px solid var(--line)}.head:before{content:"";position:absolute;top:0;left:0;width:38px;height:3px;background:var(--brand)}h1{font-size:26px;line-height:1.2;margin:0 0 16px;letter-spacing:-.02em}h2{font-size:20px;margin:0 0 5px}h3{font-size:15px;margin:4px 0 10px}.meta,.kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:1px;background:var(--line);border:1px solid var(--line)}.meta>div,.kpis>div{background:var(--paper);padding:13px 15px;min-width:0}.meta span,.kpis span,.note,small{display:block;color:var(--muted);font-size:12px}.meta strong{display:block;margin-top:4px;font-size:12px;overflow-wrap:anywhere}.kpis>div{min-height:86px}.kpis strong{display:block;font-size:24px;line-height:1.15;margin-top:8px;font-variant-numeric:tabular-nums}.summary{margin:16px 0 26px;padding:14px 16px;border:1px solid #cadfce;background:var(--soft);line-height:1.7}.summary p{margin:5px 0 0}section{padding:25px 0;margin:0;border-top:1px solid var(--line);break-inside:auto}.chapter{border-top:2px solid var(--brand)}.charts,.rule-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1px;margin:14px 0;border:1px solid var(--line);background:var(--line)}.rule,.chart{padding:16px;background:var(--paper);break-inside:avoid}.rule header{display:flex;align-items:center;gap:8px}.rule header h3{margin:0}.rule dl{display:grid;grid-template-columns:1fr 1fr}.rule dt{color:var(--muted);font-size:12px}.rule dd{margin:2px 0 0;font-size:21px;font-weight:700}.bar{display:grid;grid-template-columns:145px 1fr 105px;gap:10px;align-items:center;margin:10px 0}.bar i{height:7px;background:#edf0ed}.bar b{display:block;height:100%;background:var(--brand)}.bar strong{text-align:right;font-variant-numeric:tabular-nums}.bar strong small{display:inline;margin-left:5px}.scroll{overflow:auto;border:1px solid var(--line);background:var(--paper)}table{width:100%;border-collapse:collapse;font-size:12px;min-width:820px;font-variant-numeric:tabular-nums}thead{display:table-header-group}th,td{text-align:left;padding:10px 12px;border-bottom:1px solid #e5e9e6;vertical-align:top}th{background:#f3f6f4;white-space:nowrap}td:first-child{white-space:nowrap}.empty{margin:10px 0;padding:11px 13px;border-width:1px 0;border-style:solid;border-color:#ead9a6;background:var(--warn);color:var(--muted)}details{margin-top:12px}summary{cursor:pointer;font-weight:600}.pill{display:inline-block;padding:2px 6px;border:1px solid var(--line);font-size:11px;font-weight:600}.note{line-height:1.65}@media(max-width:760px){.report{padding:12px}.meta,.kpis{grid-template-columns:1fr 1fr}.charts,.rule-grid{grid-template-columns:1fr}.bar{grid-template-columns:95px 1fr 85px}h1{font-size:22px}}@media print{@page{margin:13mm}body{background:#fff;color:#000}.report{max-width:none;padding:0}.head:before{background:#000}.summary,.empty{background:#fff;border-color:#777}h1,h2,h3,thead,.rule header{break-after:avoid}tr,.rule,.chart,.kpis>div{break-inside:avoid}section{break-inside:auto}.charts,.rule-grid{break-inside:auto}.pill{color:#000!important}.no-print{display:none}}.stage-strip{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:14px 0;padding:11px 13px;border:1px solid #e4c77e;background:#fff8e5}.stage-strip>div,.stage-chips{display:flex;align-items:center;gap:8px}.stage-icon{display:grid;width:28px;height:28px;place-items:center;border-radius:50%;background:#b87516;color:#fff;font-weight:800}.stage-strip strong,.stage-strip small{display:block}.stage-chips{flex-wrap:wrap}.stage-chips>span{padding:4px 7px;border:1px solid #e4c77e;background:#fff;font-size:11px}.rule-grid{gap:14px;border:0;background:transparent}.rule{display:flex;min-width:0;min-height:290px;flex-direction:column;padding:0 16px 14px;overflow:hidden;border:1px solid var(--line);border-top:4px solid #3474b8;border-radius:6px;box-shadow:0 7px 20px rgba(40,55,45,.07)}.rule.is-growth{border-top-color:#27845b}.rule.is-critical{border-top-color:#c84b45}.rule.is-watch{border-top-color:#c27918}.rule header{gap:11px;margin:0 -16px 13px;padding:13px 16px;background:#f5f5f1}.rule-icon{display:grid;width:32px;height:32px;place-items:center;border:1px solid currentColor;border-radius:50%;color:#3474b8;font-size:17px;font-weight:800}.is-growth .rule-icon{color:#27845b}.is-critical .rule-icon{color:#c84b45}.is-watch .rule-icon{color:#c27918}.formula{padding:10px 12px;border:1px solid var(--line);background:#f6f7f4;overflow-wrap:anywhere}.formula span,.rule-facts b{display:block;color:var(--muted);font-size:11px}.rule dl{margin:13px 0 8px}.rule dd{font-size:28px}.mini-track{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center}.mini-track i{height:5px;overflow:hidden;background:#e8ece8}.mini-track b{display:block;height:100%;background:#3474b8}.mini-track span{font-size:11px;color:var(--muted)}.rule-facts{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:12px 0}.rule-facts>span{padding:8px;background:#f6f7f4;font-size:12px}.rule details{margin-top:auto;padding-top:9px;border-top:1px solid var(--line)}table tbody tr{border-left:3px solid transparent}table tbody tr:hover{border-left-color:#3474b8}@media(max-width:760px){.stage-strip{align-items:flex-start;flex-direction:column}.stage-chips{justify-content:flex-start}.rule-facts{grid-template-columns:1fr}}@media print{.rule{box-shadow:none;border-color:#777;border-top-color:#333}.stage-strip,.rule header,.formula,.rule-facts>span{background:#f2f2f2}.mini-track b{background:#666}}
</style></head><body><main class=report>`)
	b.WriteString("<header class=head><h1>TAP 初步治理分析报告</h1><div class=meta>")
	meta := [][2]string{{"报告周期", x.Filters.Start + " 至 " + x.Filters.End}, {"筛选范围", emptyFallback(strings.Join([]string{x.Filters.Program, x.Filters.Region, x.Filters.Tier}, " / "), "全部")}, {"数据截至（北京时间）", cwBeijing(x.AsOf)}, {"生成时间（北京时间）", cwBeijing(x.GeneratedAt)}, {"统计对象", "风险事件 / 处置事件 / 客户 / Region×Tier"}}
	for _, m := range meta {
		b.WriteString("<div><span>" + m[0] + "</span><strong>" + cwH(emptyFallback(strings.Trim(m[1], " /"), "全部")) + "</strong></div>")
	}
	b.WriteString("</div><details><summary>统计说明</summary><p>" + cwH(x.Filters.ScopeReason) + "</p><ul><li>" + cwH(x.Meta.AlertSourceBasis) + "</li><li>" + cwH(x.Meta.LevelBasis) + "</li><li>" + cwH(x.Meta.CaseworkBasis) + "</li></ul></details></header>")
	b.WriteString("<div class=summary><strong>本期结论</strong><p>" + cwHTMLSummary(x) + "</p></div><section><h2>1. 报告范围与本期结论</h2><div class=kpis>")
	for _, k := range [][2]string{{"扫描命中", strconv.Itoa(x.Summary["alerts"])}, {"去重客户", strconv.Itoa(x.Summary["clients"])}, {"已入台账事件", strconv.Itoa(x.Coverage.LinkedCases)}, {"正式成功通知", strconv.Itoa(x.Notification["formal"]["success"])}, {"待处理 / 逾期", fmt.Sprintf("%d / %d", x.Summary["pending"], x.Summary["overdue"])}, {"已完成处置", strconv.Itoa(x.Summary["closed"])}} {
		b.WriteString("<div><span>" + k[0] + "</span><strong>" + k[1] + "</strong></div>")
	}
	b.WriteString("</div></section>")
	b.WriteString(cwPriorityHTML(x))
	b.WriteString("<section class=chapter><h2>3. 风险结构</h2><h3>触发类型与风险等级</h3><p>本期共 " + strconv.Itoa(x.Summary["alerts"]) + " 条风险事件，涉及 " + strconv.Itoa(x.Summary["clients"]) + " 个去重客户。单一周度点仅表示本期结果，不构成趋势。</p>")
	b.WriteString(cwRiskOverviewHTML(x) + "</section>")
	b.WriteString("<section><h2>4. 通知与处置进展</h2>" + cwDispositionTable(x) + "<p>逾期为额外标记：<strong>" + strconv.Itoa(x.Summary["overdue"]) + "</strong> 条。风险事件 " + strconv.Itoa(x.Coverage.RiskEvents) + " 条；已关联 tap_cases " + strconv.Itoa(x.Coverage.LinkedCases) + " 条；尚未关联 " + strconv.Itoa(x.Coverage.UnlinkedAlerts) + " 条。未关联不等于未处理。</p><div class=charts><article class=chart><h3>正式通知</h3><p>成功 " + strconv.Itoa(x.Notification["formal"]["success"]) + " · 失败 " + strconv.Itoa(x.Notification["formal"]["failed"]) + " · 待发送 " + strconv.Itoa(x.Notification["formal"]["pending"]) + " · 未发起 " + strconv.Itoa(x.Notification["formal"]["not_initiated"]) + " · 结果未知 " + strconv.Itoa(x.Notification["formal"]["unknown"]) + "</p></article><article class=chart><h3>测试通知（单列）</h3><p>成功 " + strconv.Itoa(x.Notification["test"]["success"]) + " · 失败 " + strconv.Itoa(x.Notification["test"]["failed"]) + " · 待发送 " + strconv.Itoa(x.Notification["test"]["pending"]) + " · 结果未知 " + strconv.Itoa(x.Notification["test"]["unknown"]) + "</p></article></div><div class=scroll><table><thead><tr><th>Operational owner (workflow)</th><th>关联事件数</th><th>已通知</th><th>已完成动作</th><th>待办</th><th>逾期</th></tr></thead><tbody>")
	for _, o := range x.OwnerProgress {
		b.WriteString(fmt.Sprintf("<tr><td>%s</td><td>%d</td><td>%d</td><td>%d</td><td>%d</td><td>%d</td></tr>", cwH(o.Owner), o.Events, o.Notified, o.Completed, o.Todo, o.Overdue))
	}
	b.WriteString("</tbody></table></div></section>")
	b.WriteString("<section><h2>5. 核查案例与动作</h2><p>核查覆盖 " + strconv.Itoa(x.Coverage.CheckFilled) + "/" + strconv.Itoa(x.Coverage.LinkedCases) + "；动作覆盖 " + strconv.Itoa(x.Coverage.ActionFilled) + "/" + strconv.Itoa(x.Coverage.LinkedCases) + "。未填写不画无意义柱；动作口径允许多选时可重叠。</p><div class=charts>" + cwCountBars("核查结论（有效填写）", filterUnfilled(x.Attribution), cwAnalyticsMax(1, x.Coverage.CheckFilled), "") + cwCountBars("处置动作（有效填写）", filterUnfilled(x.Action), cwAnalyticsMax(1, x.Coverage.ActionFilled), "") + "</div><h3>真实案例（最多 3 个）</h3><div class=scroll><table><thead><tr><th>客户</th><th>触发类型</th><th>结论</th><th>动作</th><th>进度</th></tr></thead><tbody>")
	shown := 0
	for _, a := range x.Cases {
		if a.Status == "source_alert" || shown >= 3 {
			continue
		}
		shown++
		sources := x.SourceByCase[a.ID]
		b.WriteString("<tr><td>" + cwH(cwAnalyticsClientID(a)) + "</td><td>" + cwH(strings.Join(sources, " + ")) + "</td><td>" + cwH(emptyFallback(a.Fields["rca"], "未填写")) + "</td><td>" + cwH(emptyFallback(a.Plan, "未填写")) + "</td><td>" + cwH(a.Status) + "</td></tr>")
	}
	if shown == 0 {
		b.WriteString("<tr><td colspan=5>暂无已关联真实案例</td></tr>")
	}
	b.WriteString("</tbody></table></div></section>")
	b.WriteString("<section><h3>效果观察</h3><div class=kpis>")
	for _, k := range [][2]string{{"已完成动作", strconv.Itoa(x.Effects["action_completed"])}, {"待有效复查", strconv.Itoa(x.EffectStatus["waiting_recheck"])}, {"复查失败", strconv.Itoa(x.EffectStatus["recheck_failed"])}, {"有证据支持恢复", strconv.Itoa(x.EffectStatus["verified_improvement"])}} {
		b.WriteString("<div><span>" + k[0] + "</span><strong>" + k[1] + "</strong></div>")
	}
	b.WriteString("</div><div class=scroll><table><thead><tr><th>客户</th><th>动作及时间</th><th>报警指标 / 窗口</th><th>最近复查指标 / 窗口</th><th>观察结论</th></tr></thead><tbody>")
	for _, a := range x.Cases {
		if a.Status == "source_alert" || !a.ActionCompleted {
			continue
		}
		last := cwLastRecheck(a)
		complete, _ := cwAuditTime(a, "complete")
		conclusion := "待复查"
		if !a.ActionCompleted {
			conclusion = "未处置"
		}
		if last.Status == "failed" {
			conclusion = "数据不足 / 复查失败"
		}
		if len(a.Rechecks) > 0 && last.Status == "success" {
			conclusion = "观察中"
		}
		if a.ClosureReason == "risk_recovered" && last.Status == "success" && last.Level == "normal" && last.CCR != nil && last.NFS != nil {
			conclusion = "有证据支持恢复"
		}
		b.WriteString("<tr><td>" + cwH(cwAnalyticsClientID(a)) + "</td><td>" + cwH(emptyFallback(a.Plan, "未填写")) + "<small>" + func() string {
			if complete.IsZero() {
				return "—"
			}
			return cwBeijing(complete.Format(time.RFC3339))
		}() + "</small></td><td>CCR " + cwMetric(a.Row.CCR, 2) + " / NFS " + cwMetric(a.Row.NFS, 0) + "<small>" + cwH(a.Window.Start+" ~ "+a.Window.End) + "</small></td><td>CCR " + cwMetric(last.CCR, 2) + " / NFS " + cwMetric(last.NFS, 0) + "<small>" + cwH(last.Start+" ~ "+last.End) + "</small></td><td>" + conclusion + "</td></tr>")
	}
	b.WriteString("</tbody></table></div><p class=note>动作完成≠恢复，无新报警≠恢复。完整前后 7 天一致口径尚未接入，因此不展示恢复率。</p></section>")
	b.WriteString("<p class=note>Quota/Revenue/Account/FDR 等独立源仅响应各自 API 合同支持的筛选；保护时间、预警等级、事件状态与客户搜索不适用于 Quota，不会伪装成已筛选，也不参与 Top10。</p>")
	b.WriteString(cwQuotaAlertsHTML(x))
	b.WriteString("<section class=chapter><h2>7. 数据口径与限制</h2><div class=charts><article class=chart><h3>统计口径</h3><p class=note>" + cwH(x.Meta.AlertSourceBasis+"；"+x.Meta.LevelBasis+"；"+x.Meta.CaseworkBasis) + "</p></article><article class=chart><h3>已知限制</h3><p class=note>单一周度点不构成趋势；未返回与真实 0 严格区分；报告仅读取保存事实，不补查 Aeolus 或 live Quota。</p></article></div>")
	if len(x.Missing) > 0 {
		b.WriteString("<div class=empty><strong>数据缺口</strong><p>" + cwH(strings.Join(x.Missing, "；")) + "</p></div>")
	}
	b.WriteString("</section></main></body></html>")
	return b.String()
}
func filterUnfilled(rows []cwCount) []cwCount {
	out := []cwCount{}
	for _, r := range rows {
		if r.Key != "未填写" && strings.TrimSpace(r.Key) != "" {
			out = append(out, r)
		}
	}
	return out
}
func cwAnalyticsMax(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func cwAnalyticsHTMLExportHandler(w http.ResponseWriter, r *http.Request) {
	if !cwAnalyticsAuthorized(w, r) {
		return
	}
	x, e := cwAnalyticsBuild(cwAnalyticsFilters(r))
	if e != nil {
		cwWriteError(w, e)
		return
	}
	cwAttachSavedQuota(&x)
	x.GeneratedAt = time.Now().UTC().Format(time.RFC3339)
	name := "TAP初步治理分析报告_" + x.Filters.Start + "_" + x.Filters.End + ".html"
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Content-Disposition", `attachment; filename*=UTF-8''`+urlQueryEscape(name))
	_, _ = w.Write([]byte(cwAnalyticsHTML(x)))
}
func urlQueryEscape(s string) string {
	return strings.NewReplacer("%", "%25", " ", "%20", "/", "%2F", ":", "%3A").Replace(s)
}
