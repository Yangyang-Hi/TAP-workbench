package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

// cwCasePresentation is the immutable presentation contract shared by preview,
// transport cards and reports. Values stay numeric here; formatting happens only
// at the presentation boundary.
type cwCasePresentation struct {
	Kind              string                        `json:"kind"`
	Program           string                        `json:"program"`
	Submitter         string                        `json:"submitter"`
	RecipientGreeting string                        `json:"recipient_greeting"`
	AlertType         string                        `json:"alert_type"`
	AlertLevel        string                        `json:"alert_level"`
	Status            string                        `json:"status"`
	TimeWindow        string                        `json:"time_window"`
	Deadline          string                        `json:"deadline"`
	Region            string                        `json:"region"`
	Tier              string                        `json:"tier"`
	IdentityLabel     string                        `json:"identity_label"`
	DimensionLabel    string                        `json:"dimension_label"`
	IncreaseLabel     string                        `json:"increase_label"`
	AccountID         string                        `json:"account_id"`
	AccountName       string                        `json:"account_name"`
	AdvertiserID      string                        `json:"advertiser_id"`
	AdvertiserName    string                        `json:"advertiser_name"`
	P0CCR             *float64                      `json:"p0_ccr"`
	P0NFS             *float64                      `json:"p0_nfs"`
	Revenue           *float64                      `json:"revenue"`
	PreCCR            *float64                      `json:"pre_ccr"`
	PostCCR           *float64                      `json:"post_ccr"`
	CCRGrowthPct      *float64                      `json:"ccr_growth_pct"`
	ComparisonStatus  string                        `json:"comparison_status"`
	ComparisonReason  string                        `json:"comparison_reason"`
	ReportedReasons   []cwAdvertiserReportedReasons `json:"reported_reasons"`
	TriggerCriteria   []string                      `json:"trigger_criteria"`
	QuotaUnit         string                        `json:"quota_unit,omitempty"`
	QuotaUsed         *int                          `json:"quota_used,omitempty"`
	QuotaLimit        *int                          `json:"quota_limit,omitempty"`
	QuotaRatio        *float64                      `json:"quota_ratio,omitempty"`
	QuotaExcess       *int                          `json:"quota_excess,omitempty"`
}

type cwAdvertiserReportedReasons struct {
	AdvertiserID string           `json:"advertiser_id"`
	Reasons      []reportedReason `json:"reasons"`
}

func cwEventDeadline(a cwCase) string {
	if strings.TrimSpace(a.DueDate) != "" {
		return a.DueDate
	}
	if value := strings.TrimSpace(a.Fields["notification_deadline"]); value != "" {
		return value
	}
	return ""
}

func cwAlertType(a cwCase) string {
	if a.Kind == "quota" {
		return "Quota overage"
	}
	types := []string{}
	for _, source := range cwAlertSources(a) {
		switch source {
		case "absolute":
			types = append(types, "CCR/NFS absolute threshold")
		case "growth_top20", "top20":
			types = append(types, "P0 CCR growth Top20")
		}
	}
	if len(types) == 0 {
		return "Unidentified alert type"
	}
	return strings.Join(types, " / ")
}

func cwPresentation(a cwCase) cwCasePresentation {
	advertiserID := a.Row.Member.AdvertiserID
	evidence := a.Row.AdvertiserTop10
	if len(evidence) == 0 {
		evidence = a.Row.Advertisers
	}
	reasons := make([]cwAdvertiserReportedReasons, 0, len(evidence))
	for _, item := range evidence {
		if advertiserID == "" && len(evidence) == 1 {
			advertiserID = item.AdvertiserID
		}
		if len(item.ReportedReasons) > 0 {
			reasons = append(reasons, cwAdvertiserReportedReasons{AdvertiserID: item.AdvertiserID, Reasons: item.ReportedReasons})
		}
	}
	name := strings.TrimSpace(a.Row.Member.Name)
	advertiserName := strings.TrimSpace(a.Row.Member.AdvertiserName)
	identityLabel := "ET Account"
	if strings.EqualFold(a.Row.Program, "ST") {
		identityLabel = "ST Account"
		if name == "" {
			name = strings.TrimSpace(a.Row.Member.BrandName)
		}
	} else if strings.EqualFold(a.Row.Program, "THT") {
		identityLabel = "THT Advertiser"
		if advertiserName == "" {
			advertiserName = name
		}
	}
	if name == "" {
		name = "暂未获取"
	}
	if advertiserName == "" && strings.EqualFold(a.Row.Program, "THT") {
		advertiserName = "暂未获取"
	}
	dimensionLabel, increaseLabel := "Account Level", "WoW CCR Increase"
	if strings.EqualFold(a.Row.Program, "ST") {
		increaseLabel = "QoQ CCR Increase"
	} else if strings.EqualFold(a.Row.Program, "THT") {
		dimensionLabel = "Advertiser Level"
	}
	comparison := wbNormalizeLegacyComparison(a.Row.Program, a.Row.Comparison)
	comparisonStatus := comparison.IncreaseFact.Status
	if comparisonStatus == "" {
		comparisonStatus = comparison.Status
	}
	comparisonReason := comparison.IncreaseFact.Reason
	if comparisonReason == "" {
		comparisonReason = comparison.MissingReason
	}
	if strings.EqualFold(a.Row.Program, "THT") && !wbTHTAdvertiserGrainCompatible(a.Row) {
		comparison.PreCCR, comparison.PostCCR, comparison.CCRGrowthPct = nil, nil, nil
		comparisonStatus = "incompatible_legacy_grain"
		comparisonReason = "旧记录粒度不兼容：THT 主指标不是 Advertiser Level"
	}
	view := cwCasePresentation{
		Kind: a.Kind, Program: a.Row.Program, Submitter: a.Row.Member.Submitter,
		AlertType: cwAlertType(a), AlertLevel: a.Row.Level, Status: a.Status,
		TimeWindow: strings.TrimSpace(a.Window.Start + " to " + a.Window.End), Deadline: cwEventDeadline(a),
		Region: a.Row.Member.Region, Tier: a.Row.Member.Tier, IdentityLabel: identityLabel,
		DimensionLabel: dimensionLabel, IncreaseLabel: increaseLabel,
		AccountID: a.Row.Member.AccountID, AccountName: name, AdvertiserID: advertiserID,
		AdvertiserName: advertiserName, P0CCR: a.Row.CCR, P0NFS: a.Row.NFS, Revenue: a.Row.Revenue,
		PreCCR: comparison.PreCCR, PostCCR: comparison.PostCCR, CCRGrowthPct: comparison.CCRGrowthPct, ComparisonStatus: comparisonStatus, ComparisonReason: comparisonReason,
		ReportedReasons: reasons, TriggerCriteria: append([]string(nil), a.Row.Reasons...),
	}
	if a.Kind == "quota" {
		used, usedOK := cwIntField(a.Fields["used"])
		limit, limitOK := cwIntField(a.Fields["quota"])
		ratio, ratioOK := cwFloatField(a.Fields["ratio"])
		if usedOK {
			view.QuotaUsed = &used
		}
		if limitOK {
			view.QuotaLimit = &limit
		}
		if ratioOK {
			view.QuotaRatio = &ratio
		}
		if usedOK && limitOK {
			excess := max(0, used-limit)
			view.QuotaExcess = &excess
		}
		view.QuotaUnit = strings.TrimSpace(a.Fields["quota_unit"])
	}
	return view
}

func cwIntField(raw string) (int, bool) {
	v, err := strconv.Atoi(strings.TrimSpace(raw))
	return v, err == nil
}
func cwFloatField(raw string) (float64, bool) {
	v, err := strconv.ParseFloat(strings.TrimSpace(raw), 64)
	return v, err == nil && !math.IsNaN(v) && !math.IsInf(v, 0)
}

func cwFormatNumber(v *float64, digits int) string {
	if v == nil || math.IsNaN(*v) || math.IsInf(*v, 0) {
		return "—"
	}
	raw := strconv.FormatFloat(*v, 'f', digits, 64)
	parts := strings.SplitN(raw, ".", 2)
	integer, sign := parts[0], ""
	if strings.HasPrefix(integer, "-") {
		sign, integer = "-", strings.TrimPrefix(integer, "-")
	}
	for i := len(integer) - 3; i > 0; i -= 3 {
		integer = integer[:i] + "," + integer[i:]
	}
	if len(parts) == 2 {
		return sign + integer + "." + parts[1]
	}
	return sign + integer
}

func cwFormatInt(v *int) string {
	if v == nil {
		return "—"
	}
	f := float64(*v)
	return cwFormatNumber(&f, 0)
}

func cwFormatPercent(v *float64) string {
	if v == nil {
		return "—"
	}
	return cwFormatNumber(v, 2) + "%"
}

func cwReportedReasonsText(groups []cwAdvertiserReportedReasons) string {
	if len(groups) == 0 {
		return "—"
	}
	lines := make([]string, 0, len(groups))
	for _, group := range groups {
		labels := make([]string, 0, len(group.Reasons))
		for _, reason := range group.Reasons {
			label := reason.DisplayNameEN
			if label == "" {
				label = "Unmapped Reason"
			}
			if reason.RankingAvailable && reason.Rank != nil {
				label = fmt.Sprintf("%d. %s", *reason.Rank, label)
			} else {
				label += " (unranked)"
			}
			labels = append(labels, label)
		}
		prefix := group.AdvertiserID
		if prefix == "" {
			prefix = "Advertiser —"
		}
		lines = append(lines, prefix+": "+strings.Join(labels, "; "))
	}
	return strings.Join(lines, " | ")
}

func cwEnsureNotificationDeadline(a *cwCase) bool {
	if a.Fields == nil {
		a.Fields = map[string]string{}
	}
	if cwEventDeadline(*a) != "" {
		return false
	}
	base, ok := cwNotificationDeadlineBase(*a)
	if !ok {
		return false
	}
	a.Fields["notification_deadline"] = base.AddDate(0, 0, 7).Format("2006-01-02")
	return true
}

func cwNotificationDeadlineBase(a cwCase) (time.Time, bool) {
	if base, err := time.Parse(time.RFC3339, strings.TrimSpace(a.CreatedAt)); err == nil {
		return base.UTC(), true
	}
	for _, raw := range []string{a.Window.End, a.Window.Start} {
		if base, err := time.Parse("2006-01-02", strings.TrimSpace(raw)); err == nil {
			return base.UTC(), true
		}
	}
	return time.Time{}, false
}
