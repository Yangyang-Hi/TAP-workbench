import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { Analysis, DataCenter, Overview, RiskMonitor, UnsupportedState } from "./workbench-pages";
import type { ReadModel, ReadRow } from "./read-model";
import { ccr, metricFact, pct } from "./read-model";
vi.mock("./casework", () => ({ CaseActions: ({id}: {id:string}) => <div data-testid="casework-actions">{id} 显式事件操作</div> }));
vi.mock("./casework-analytics", () => ({ GovernanceAnalytics: () => <div>治理分析</div> }));
vi.mock("./submission-quota", () => ({ SubmissionQuota: ({ alertsOnly, summaryOnly }: { alertsOnly?: boolean; summaryOnly?: boolean }) => <div data-testid={alertsOnly ? "quota-alerts-mock" : summaryOnly ? "quota-summary-mock" : "quota-full-mock"}>Quota {alertsOnly ? "区域预警" : summaryOnly ? "统计摘要" : "完整监控"}</div> }));
afterEach(cleanup);
const comparison = { pre_ccr: null, post_ccr: null, wow_ccr_growth_pct: null, qoq_ccr_growth_pct: null, status: "unavailable", missing_reason: "waiting_data_update", kind: "relative_7d", pre_start_date: "2026-09-01", pre_end_exclusive: "2026-09-08", post_start_date: "2026-09-08", post_end_exclusive: "2026-09-15", timezone: "Asia/Shanghai" };
const row: ReadRow = { alert_id: "TAP-1", account_id: "1001", account_name: "客户 A", advertiser_id: "2001", program: "ET", tier: "ET", region: "APAC", original_submitter: "Submitter", actual_recipient: null, p0_ccr: 46, p0_nfs: 60, revenue: null, comparison, advertiser_valid_count: 1, advertiser_top10: [], risk_level: "extreme", risk_reasons: ["CCR 达到阈值"], event_stage: "pending_operator", notification: { status: "failed", history: [{ status: "failed", error: "send rejected" }] }, scan_id: "s1", row_id: "r1" };
const model: ReadModel = { status: "available", reason: "", time: { mode: "weekly", selected_batch: { batch_id: "b1", week_name: "2026-W42", generated_at: "2026-10-19T01:00:00Z", metric_start_date: "2026-10-12", metric_end_date: "2026-10-18", timezone: "Asia/Shanghai", programs: ["ET"], status: "available", completeness: "complete" } }, filters: {}, cards: { queried_customers: { value: null, status: "pending", description: "数据待接入" }, auto_alerted: { value: null, status: "unavailable" }, pending: { value: 1, status: "available" }, handled: { value: 0, status: "available" } }, rows: [row], rankings: {}, pagination: { page: 1, page_size: 50, total: 1 }, contract_version: "test" };

describe("共享页面只读状态", () => {
  it("null 总览卡显示破折号并保留 status/note", () => {
    render(<Overview model={model} />);
    expect(screen.getAllByText("—").length).toBeGreaterThan(0);
    expect(screen.getByText("数据待接入")).toBeTruthy();
    expect(screen.getByText("pending")).toBeTruthy();
  });
  it("自定义 unsupported 明确待接入且不显示成功或 0", () => {
    render(<UnsupportedState model={{ ...model, status: "unsupported", reason: "custom_bulk_query_pending", rows: [] }} />);
    expect(screen.getByTestId("custom-unsupported").textContent).toContain("自定义区间批量查询待接入");
    expect(screen.getByTestId("custom-unsupported").textContent).toContain("custom_bulk_query_pending");
    expect(screen.queryByText("成功")).toBeNull();
  });
  it("Pre→Post CCR 与增幅按两位展示，缺失不伪装为 0", () => {
    expect(`${ccr(140.41670219720874)} → ${ccr(326.25199201937437)}`).toBe("140.42 → 326.25");
    expect(pct(132.3455735067532)).toBe("+132.35%");
    expect(ccr(null)).toBe("—");
    expect(pct(null)).toBe("—");
    const valued = { ...row, comparison: { ...comparison, pre_ccr: 140.41670219720874, post_ccr: 326.25199201937437, ccr_growth_pct: 132.3455735067532, status: "available" } };
    render(<RiskMonitor model={{ ...model, rows: [valued] }} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
    expect(screen.getByText("Pre → Post CCR")).toBeTruthy();
    expect(screen.getByText("风险 CCR 增幅")).toBeTruthy();
    expect(screen.getAllByText("140.42").length).toBeGreaterThan(0);
    expect(screen.getAllByText("326.25").length).toBeGreaterThan(0);
    expect(screen.getAllByText("+132.35%").length).toBeGreaterThan(0);
  });
  it("ST 无正式 Account 锚点时 CCR Increase 为 not_configured", () => {
    const st = { ...row, program: "ST", tier: "ST", comparison: { ...comparison, status: "not_configured", missing_reason: "st_account_anchor_not_configured" } };
    render(<RiskMonitor model={{ ...model, rows: [st] }} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
    expect(screen.getAllByText("—").length).toBeGreaterThan(0);
    expect(screen.getAllByText(/CCR Increase/).length).toBeGreaterThan(0);
    expect(screen.getByTestId("risk-desktop-table").textContent).toContain("st_account_anchor_not_configured");
  });
  it("分类筛选交给服务端 ranking，双重命中客户同时展示两类标签", () => {
    const onRanking = vi.fn();
    const dual = { ...row, pair_absolute_level: "watch", pair_absolute_reasons: ["P0 CCR 46 ≥ 3 且 P0 NFS 60 > 50"], risk_reasons: ["ET × APAC 有效正增幅 Top20 · 120%", "P0 CCR 46 ≥ 3 且 P0 NFS 60 > 50"] };
    render(<RiskMonitor model={{ ...model, rows: [dual] }} stage="all" onStage={vi.fn()} ranking="combined" onRanking={onRanking} page={1} onPage={vi.fn()} />);
    fireEvent.click(screen.getByRole("radio", { name: "仅 CCR 增幅" }));
    expect(onRanking).toHaveBeenCalledWith("growth", expect.anything());
    const cards = screen.getByTestId("risk-mobile-list");
    expect(cards.textContent).toContain("CCR 增幅 Top20");
    expect(cards.textContent).toContain("CCR/NFS 绝对值");
    expect(cards.textContent).toContain("双重命中");
  });
});

describe("四个主 Tab 的 Quota 联动", () => {
  it("治理总览、风险监控、治理效果分析、运营数据中心均挂载对应 Quota 视图", () => {
    const { unmount } = render(<Overview model={model} />);
    expect(screen.getByTestId("quota-alerts-mock")).toBeTruthy();
    unmount();

    const risk = render(<RiskMonitor model={model} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
    fireEvent.click(screen.getByRole("radio", { name: "Quota 区域预警" }));
    expect(screen.getByTestId("quota-alerts-mock")).toBeTruthy();
    risk.unmount();

    const analysis = render(<Analysis model={model} />);
    expect(screen.getByTestId("quota-summary-mock")).toBeTruthy();
    analysis.unmount();

    render(<DataCenter model={model} />);
    expect(screen.getByTestId("quota-full-mock")).toBeTruthy();
  });
});


describe("通知结果详情", () => {
  it("展示服务端 message_id、状态和时间，不把失败记录显示为成功", () => {
    render(<RiskMonitor model={{ ...model, rows: [{ ...row, notification: { status: "failed", history: [{ id: "notice-1", status: "failed", recipient: "open_id:ou_test", message_id: "om_failed", updated_at: "2026-10-21T10:00:00Z", error: "send rejected" }] } }] }} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
    fireEvent.click(screen.getAllByRole("button", { name: "处理事件" })[0]);
    const detail = screen.getByTestId("event-detail");
    expect(detail.textContent).toContain("message_id: om_failed");
    expect(detail.textContent).toContain("2026-10-21T10:00:00Z");
    expect(detail.textContent).toContain("发送失败");
    expect(detail.textContent).toContain("保护开始时间");
    expect(detail.textContent).toContain("2026-10-12 至 2026-10-18");
    expect(screen.getByTestId("risk-desktop-table").textContent).toContain("保护开始时间");
    expect(screen.getByTestId("risk-desktop-table").textContent).not.toContain("Trigger Criteria");
    expect(detail.textContent).toContain("时间缺失");
    expect(detail.textContent).not.toContain("NFS Delta");
    expect(detail.textContent).not.toContain("Revenue Delta");
  });
});

describe("原型行内处置", () => {
  it("没有独立处置子页，也没有仅筛本页的开关", () => {
    render(<RiskMonitor model={model} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
    expect(screen.queryByText("处置与通知")).toBeNull();
    expect(screen.queryByText("仅看本页风险命中")).toBeNull();
    expect(screen.getByText("命中客户 1 位 · 预警记录 1 条")).toBeTruthy();
  });
  it("区分真实 0 与 NULL 原因", () => {
    expect(metricFact(0, "source_null")).toBe("0");
    expect(metricFact(null, "source_null")).toBe("—（源字段 NULL）");
    expect(metricFact(null, "query_failed")).toBe("—（查询失败）");
    expect(metricFact(null, "not_applicable")).toBe("—（范围不适用）");
  });
  it("THT 以 Advertiser 为主体并解释 Account 关联和 allowlist fail-closed", () => {
    const tht = { ...row, program: "THT", tier: "THT", account_name: "", allowlist_status: "unknown", allowlist_reason: "S09 查询失败", advertiser_top10: [{ advertiser_id: "2001", ccr: 46, nfs: 60, semantics_label_tier_1_2_3_4: "legacy-label-must-not-display", reported_reasons: [{ original_label: "", display_name_en: "Reported Reasons Pending Source", description: "权威单标签 CCR 来源不可用", mapping_status: "pending_source", source_status: "source_unavailable", p0_ccr: null, rank: null, ranking_available: false, ranking_unavailable_reason: "source unavailable" }] }], comparison: { ...comparison, event_anchor: "2026-09-08", event_id: "evt-2" } };
    render(<RiskMonitor model={{ ...model, rows: [tht] }} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
    fireEvent.click(screen.getAllByRole("button", {name:"处理事件"})[0]);
    const detail = screen.getByTestId("event-detail");
    expect(detail.textContent).toContain("Advertiser Level");
    expect(detail.textContent).toContain("WoW CCR Increase");
    expect(detail.textContent).not.toContain("Account Current CCR");
    expect(detail.textContent).not.toContain("CCR Delta");
    expect(detail.textContent).toContain("真实关联 Account 1001");
    expect(detail.textContent).toContain("unknown · S09 查询失败");
    expect(detail.textContent).toContain("2026-09-08 · evt-2");
    expect(detail.textContent).toContain("Reported Reasons Pending Source");
    expect(detail.textContent).not.toContain("legacy-label-must-not-display");
  });
  it("客户行直接打开同一 Alert 的处置组件", () => {
    render(<RiskMonitor model={model} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
    fireEvent.click(screen.getAllByRole("button", {name:"处理事件"})[0]);
    expect(screen.getByTestId("event-detail")).toBeTruthy();
    expect(screen.getByTestId("casework-actions").textContent).toContain("TAP-1");
    expect(screen.queryByRole("button", {name:/打开处置事件/})).toBeNull();
  });
});

it("整批源查询失败显示不可判断，不显示零预警结论", () => {
  render(<RiskMonitor model={{...model,status:"unavailable",reason:"源查询失败，数量不可判断",rows:[],cards:{risk_customers:{value:null,status:"unavailable",description:"不可判断"}}}} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
  expect(screen.getByText("扫描未完成，暂不能判断风险数量")).toBeTruthy();
  expect(screen.queryByText(/当前范围暂无命中客户/)).toBeNull();
});


describe("扫描覆盖与空列表的区别", () => {
 it("THT尚未扫描显示原因而非零风险结论", () => {
  render(<RiskMonitor model={{...model,status:"unavailable",reason:"所选周度没有 THT 的已保存扫描记录",rows:[],scan_diagnostics:{THT:{status:"not_scanned"}}}} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
  expect(screen.getByTestId("scan-coverage").textContent).toContain("THT · 尚未扫描");
  expect(screen.getByTestId("scan-coverage").textContent).toContain("不能当作零预警");
  expect(screen.queryByTestId("risk-desktop-table")).toBeNull();
 });
 it("源端缺失和查询失败显示独立覆盖记录", () => {
  render(<RiskMonitor model={{...model,status:"partial",reason:"部分覆盖",rows:[],scan_diagnostics:{THT:{status:"partial",core_coverage:{status:"incomplete",target_count:100,queried_count:90,query_failures:2,source_missing_rows:4,comparison_unavailable_rows:5}}}}} stage="all" onStage={vi.fn()} ranking="combined" onRanking={vi.fn()} page={1} onPage={vi.fn()} />);
  expect(screen.getByTestId("scan-coverage").textContent).toContain("目标 100 · 已查询 90 · 查询失败记录 2 · 源值缺失记录 4");
  expect(screen.getByText("已返回范围暂无命中，完整结果待核验")).toBeTruthy();
 });
});
