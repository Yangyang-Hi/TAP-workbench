import { render, screen } from "@testing-library/react";
import { SharedFilterBar, SharedFilterProvider, filterQuery } from "./shared-filters";
import { describe, expect, it } from "vitest";

describe("保护时间与历史周筛选", () => {
  it("将批次、保护时间、等级和状态透传到统一 query，并忽略旧预警日期", () => {
    const query = filterQuery({
      time_mode: "history", batch_id: "batch-1", start_date: "", end_date: "", tier: "THT", region: "APAC",
      submitter: "user1", search: "test", only_mine: true,
      protection_start_date: "2026-10-01", protection_end_date: "2026-10-31", include_anchor_anomalies: true,
      alert_start_date: "2020-01-01", alert_end_date: "2020-01-31", alert_level: "critical", status: "open",
    });
    expect(query).toMatchObject({ time_mode: "weekly", batch_id: "batch-1", program: "THT", region: "APAC", submitter: "user1", search: "test", only_mine: true, protection_start_date: "2026-10-01", protection_end_date: "2026-10-31", include_anchor_anomalies: true, alert_level: "critical", status: "open" });
    expect(query).not.toHaveProperty("alert_start_date");
  });

  it("显示保护开始时间控件并删除预警产生日期控件", () => {
    render(<SharedFilterProvider><SharedFilterBar /></SharedFilterProvider>);
    expect(screen.getByLabelText("预警等级")).toBeTruthy();
    expect(screen.getByLabelText("当前状态")).toBeTruthy();
    expect(screen.getByLabelText("保护开始时间")).toBeTruthy();
    expect(screen.getAllByLabelText("包含时间异常").length).toBeGreaterThan(0);
    expect(screen.queryByLabelText("预警产生日期")).toBeNull();
  });
});
