import { describe, expect, it } from "vitest";
import source from "./index.tsx?raw";
import overviewSource from "./overview-home.tsx?raw";

describe("共享工作台读取边界", () => {
  it("页面打开、筛选、翻页和导出只使用 GET typed clients", () => {
    expect(source).toContain("workbenchBatchesList");
    expect(source).toContain("workbenchReadModelList");
    expect(source).not.toMatch(/Create\s*\(/);
    expect(source).not.toContain("fetch(");
    expect(source).not.toContain("apiFetch(");
    expect(source).not.toContain("risk-scans");
    expect(source).not.toContain("/notify");
    expect(overviewSource).toContain("ET 区间使用量 / 季度配额");
    expect(overviewSource).toContain("usage_window");
    expect(overviewSource).toContain("quota_period");
    expect(overviewSource).toContain("ST 季度快照");
    expect(overviewSource).toContain("coverage_status");
    expect(overviewSource).toContain("batch_windows");
    expect(overviewSource).toContain('"p1-weekly"');
    expect(overviewSource).toContain('"approval-weekly"');
    expect(overviewSource).toContain('"fdr-weekly"');
    expect(overviewSource).toContain('"region-tier-accounts"');
    expect(overviewSource).toContain("P0 CCR / NFS · 区域对比");
    expect(overviewSource).toContain("RID3065818 / SID1139137 / TID336");
    expect(overviewSource).toContain("x 轴为 Region，按 Tier 分系列");
    expect(overviewSource).toContain("RID3061919 · year-quarter p_date");
    expect(overviewSource).toContain("不是周趋势");
    expect(overviewSource).toContain("不在前端平均 CCR");
    expect(overviewSource).toContain("Global RID2883048");
    expect(overviewSource).toContain("Region RID2883021");
    expect(overviewSource).toContain("不声称跨分片去重总数");
  });
  it("不再存在 requestedView 或角色视角分支", () => {
    expect(source).not.toContain("requestedView");
    expect(source).not.toContain('params.get("view")');
    expect(source).not.toContain("运营工作台视角");
  });
});
