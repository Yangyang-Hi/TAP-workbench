import { useEffect, useState } from "react";
import { apiFetch } from "../../auth";

type RuntimeConfig = { features?: { overview_data_center?: boolean } };

export function useOverviewFeature(): boolean {
  const [enabled, setEnabled] = useState(false);
  useEffect(() => {
    let active = true;
    apiFetch("/api/aime/config")
      .then((response) => response.json() as Promise<RuntimeConfig>)
      .then((value) => { if (active) setEnabled(value.features?.overview_data_center === true); })
      .catch(() => { if (active) setEnabled(false); });
    return () => { active = false; };
  }, []);
  return enabled;
}
