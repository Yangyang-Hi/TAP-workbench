import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const themeCss = readFileSync(resolve(process.cwd(), "src/pages/governance/tap-workbench-ui.css"), "utf8");

const forbiddenForeground = /(?:color|fill)\s*:\s*(?:#(?:000(?:000)?|111(?:111)?|1d2129)\b|rgb\(\s*0\s*,\s*0\s*,\s*0\s*\))/i;

const requiredSelectors = [
  ".ops-page-title h2",
  ".ops-app .ovh-panel-title > b",
  ".ops-app .ops-customer > b",
  ".ops-app .arco-table-th",
  ".ops-app .arco-pagination-item",
  ".ops-app .cw-analysis",
  ".ops-app .quota-hero",
  ".ops-event-drawer .arco-drawer-content",
  "body:has(.ops-app,.cw-task-page) .arco-modal",
  "body:has(.ops-app,.cw-task-page) .arco-select-popup",
  ".ops-app .ovh-combo text",
];

describe("TAP workbench dark-theme text contract", () => {
  it("does not introduce forbidden near-black ordinary foregrounds", () => {
    const screenCss = themeCss.replace(/@media print[\s\S]*$/m, "");
    expect(screenCss).not.toMatch(forbiddenForeground);
  });

  it.each(requiredSelectors)("keeps a scoped rule for %s", (selector) => {
    expect(themeCss).toContain(selector);
  });

  it("maps both Aime and Arco text tokens at the workbench/portal boundary", () => {
    for (const token of ["--tap-text-primary", "--tap-text-secondary", "--tap-text-tertiary", "--aime-color-text-base-1", "--color-text-1"]) {
      expect(themeCss).toContain(token);
    }
  });

  it("keeps chart series colors separate from SVG text rules", () => {
    expect(themeCss).toMatch(/\.ovh-combo text[^}]*fill:/);
    expect(themeCss).toMatch(/\.ovh-bar-series\.is-1 rect\{fill:#6faeff/);
    expect(themeCss).not.toMatch(/(?:\.ops-app|svg)\s+(?:path|rect|circle)[^{]*\{[^}]*fill:\s*(?:#fff|white)/i);
  });
});
