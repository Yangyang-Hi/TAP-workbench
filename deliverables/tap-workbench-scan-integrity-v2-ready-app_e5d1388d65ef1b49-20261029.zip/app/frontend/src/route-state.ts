import { useSyncExternalStore } from "react";

type HistoryMethod = "pushState" | "replaceState";
type Listener = () => void;

const listeners = new Set<Listener>();
let originals: Pick<History, HistoryMethod> | undefined;
let wrappers: Pick<History, HistoryMethod> | undefined;

function notifyRouteChange() {
  for (const listener of [...listeners]) listener();
}

function startHistoryObserver() {
  if (originals || typeof window === "undefined") return;
  originals = {
    pushState: window.history.pushState,
    replaceState: window.history.replaceState,
  };
  wrappers = {
    pushState(this: History, ...args: Parameters<History["pushState"]>) {
      originals?.pushState.apply(this, args);
      notifyRouteChange();
    },
    replaceState(this: History, ...args: Parameters<History["replaceState"]>) {
      originals?.replaceState.apply(this, args);
      notifyRouteChange();
    },
  };
  window.history.pushState = wrappers.pushState;
  window.history.replaceState = wrappers.replaceState;
  window.addEventListener("popstate", notifyRouteChange);
}

function stopHistoryObserver() {
  if (!originals || !wrappers || typeof window === "undefined") return;
  window.removeEventListener("popstate", notifyRouteChange);
  if (window.history.pushState === wrappers.pushState) window.history.pushState = originals.pushState;
  if (window.history.replaceState === wrappers.replaceState) window.history.replaceState = originals.replaceState;
  originals = undefined;
  wrappers = undefined;
}

function subscribe(listener: Listener) {
  listeners.add(listener);
  if (listeners.size === 1) startHistoryObserver();
  return () => {
    listeners.delete(listener);
    if (listeners.size === 0) stopHistoryObserver();
  };
}

const routeSnapshot = () => `${window.location.pathname}${window.location.search}${window.location.hash}`;
const serverSnapshot = () => "/";

export function useRouteLocation() {
  const href = useSyncExternalStore(subscribe, routeSnapshot, serverSnapshot);
  return new URL(href, window.location.origin);
}

export function isTaskRoute(params: URLSearchParams) {
  return params.get("view") === "tasks";
}

export function navigateQuery(
  update: (params: URLSearchParams) => void,
  options: { replace?: boolean } = {},
) {
  const params = new URLSearchParams(window.location.search);
  update(params);
  const query = params.toString();
  const target = window.location.pathname + (query ? `?${query}` : "") + window.location.hash;
  const method = options.replace ? "replaceState" : "pushState";
  window.history[method](window.history.state, "", target);
}
