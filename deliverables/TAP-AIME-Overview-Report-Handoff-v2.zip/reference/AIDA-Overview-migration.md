# Tab1 Overview｜Aime 迁移取数与展示说明

**迁移目标**：本文按当前 TAP 3\.0 Workbench 的 Tab1 Overview 实际实现整理，覆盖所有数据模块、数据指标、展示形式、风神源报表、动态筛选、前端计算和迁移注意事项。迁移到 Aime 时，建议优先复用这些已保存风神报表和字段口径；不要只按页面文案重新猜 SQL。

## 1\. Tab1 整体结构

|区域|页面模块|展示形式|迁移优先级|
|---|---|---|---|
|顶部筛选|Time Window、Customer Region、TAP 3\.0 Tier|日期区间控件 \+ Region 单选 \+ Tier 多选|必须迁移；所有动态风神模块依赖这三个控件。|
|核心卡片|TAP 账户总数量、TAP 总 Revenue、P0 CCR、P0 NFS|4 张 KPI 卡片|必须迁移；卡片取服务端聚合值，不在前端复算 CCR。|
|Approval 卡片|Approval Rate \- ET/ST/BT/HT|4 张分 Tier KPI 卡片|必须迁移；同一报表按 tier\_v3\_name 分行返回后拆卡。|
|区域与层级分布|Region × Tier Global Account Count \+ Revenue|组合图：Revenue 柱 \+ Account Count 折线 \+ 下方汇总表|建议迁移为动态查询；当前页面使用 2026\-10\-01\~2026\-10\-11 静态快照。|
|TAP / Non\-TAP 对比|TAP vs Non\-TAP by Region|组合图 \+ Region 明细卡片|建议迁移为动态查询；当前页面使用静态快照派生。|
|Tier 分布|Tier 账户数量及占比、Tier Revenue 及占比|环形饼图 \+ 图例 \+ 明细表|必须迁移；注意这两个图不响应顶部 Tier 多选，只响应时间和 Region。|
|趋势图|P0/P1 CCR\+NFS、Approval\+Banned、Ads FDR\+Overturned|双轴趋势图：折线 = Rate，柱 = Volume|必须迁移；Global 和指定 Region 在部分图上使用不同源报表。|

## 2\. 全局筛选规则

### 2\.1 默认时间

- 默认时间窗口为 **当前季度 QTD**：`quarterStart(today in Asia/Singapore)` 到 `today in Asia/Singapore`。

- 当前会话日期为 2026\-10\-26，因此默认应为 **2026\-10\-01 \~ 2026\-10\-26**。

- 页面里用户点击“应用筛选”后才生效；未应用时 UI 会提示“筛选条件尚未应用”。

### 2\.2 Tier 选项

|页面显示|源字段值|说明|
|---|---|---|
|ST|strategic\_trust|Strategic Trust。|
|HT|high\_trust|High Trust。|
|BT|building\_trust|Building Trust。|
|ET|emerging\_trust|Emerging Trust。|

### 2\.3 Region 映射

|字段场景|字段 ID|Region 映射规则|
|---|---|---|
|Actor / User Trust / Approval 的 Sales region\-8\.6 类字段|10000016013590 / 10000016013001 / 10000016013722|APAC、CNOB、EUI、LATAM、METAP、NA、NEA、GA、Scaled Growth、SMB、Other；Global 不下推 Region 过滤。|
|Audit\-All In One 周趋势 Region 字段|10000000894158|APAC → APAC Team，EUI → EUI Team，LATAM → LATAM Team，METAP → METAP Team，NA → NA Team；Global 不下推 Region 过滤。|
|Region × Tier 静态快照标准化|account\_final\_region|APAC\-APAC / AU Team / APAC → APAC；APAC\-China Outbound → CNOB；APAC\-Japan → JP；EUI Team → EUI；LATAM Team → LATAM；METAP Team → METAP；NA Team → NA；Scaled Growth Agency → Scaled Growth；GA \& A → GA；其他或空值 → Other。|

## 3\. 数据源总表

|模块|sourceId|Report ID|Report 名称|数据集|风神链接|
|---|---|---|---|---|---|
|TAP 账户总数量 / TAP 总 Revenue|accountsRevenueCcr|2892274|accounts\-revenue\-ccr|\[Official \| Integrity\] Actor All In One / 1280034|[report 2892274](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2892274)|
|P0 CCR / P0 NFS|p0Summary|2891879|TAP\_WB\_Tab1\_P0\_CCR\_NFS\_SalesRegion86\_v2|\[Official \| Integrity\]\[Di\]User Trust All\-in\-One Metrics / 1139137|[report 2891879](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2891879)|
|Approval Rate \- ET/ST/BT/HT|approvalSummary|2893221|Approval Rate \- Tab1: Overview|Audit Log Refactoring Dataset / 642402|[report 2893221](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=555138&isDefault=1&rid=2893221)|
|Region × Tier Global Account Count \+ Revenue|regionTierGlobalSummary|当前绑定 2883033；页面快照源 2529294|TAP\_WB\_Tab1\_Region\_Tier\_Global\_Summary / 静态快照|Actor All In One / 1280034|[report 2883033](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2883033)|
|TAP vs Non\-TAP by Region|静态快照|2529294|TAP vs Non\-TAP Account/Revenue/Approval 源快照|Actor All In One / 1280034|[report 2529294](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2529294)|
|Tier 账户数量及占比|accountByTier|2891943|TAP\_WB\_Tab1\_Account\_ByTier\_SalesRegion86\_v2|Actor All In One / 1280034|[report 2891943](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2891943)|
|Tier Revenue 及占比|revenueByTier|2883029|TAP\_WB\_Overview\_Revenue\_By\_Tier\_v1|User Trust All\-in\-One Metrics / 1139137|[report 2883029](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2883029)|
|P0 CCR / NFS 周趋势|p0Weekly|2883040|TAP\_WB\_P0\_CCR\_NFS\_Trend\_v2|User Trust All\-in\-One Metrics / 1139137|[report 2883040](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2883040)|
|P1 CCR / NFS 周趋势|p1Weekly|2883016|TAP\_WB\_P1\_Candidate\_Validation\_v2|User Trust All\-in\-One Metrics / 1139137|[report 2883016](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2883016)|
|Approval Rate / Banned Volume 周趋势（Global）|approvalWeeklyAll|2883018|Approval Rate \- Quarter\-TAP\-No region|Audit Log Refactoring Dataset / 642402|[report 2883018](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=555138&isDefault=1&rid=2883018)|
|Approval Rate / Banned Volume 周趋势（指定 Region）|approvalWeekly|2883037|Approval Rate \- Quarter\-TAP|Audit Log Refactoring Dataset / 642402|[report 2883037](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=555138&isDefault=1&rid=2883037)|
|Ads FDR 周趋势（Global）|fdrWeeklyGlobal|2883048|TAP\_WB\_FDR\_Weekly\_Global\_By\_Tier\_v1|Audit\-All In One / 1198629|[report 2883048](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2883048)|
|Ads FDR 周趋势（指定 Region）|fdrWeekly|2883021|TAP\_WB\_FDR\_Weekly\_Runtime\_v1|Audit\-All In One / 1198629|[report 2883021](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2883021)|
|Overturned Volume 周趋势|overturnedWeekly|2883046|TAP\_WB\_Overturned\_Account\_Weekly\_v2|Audit\-All In One / 1198629|[report 2883046](https://aeolus-sg.tiktok-row.net/aeolus/pages/dataQuery?appId=800414&isDefault=1&rid=2883046)|

## 4\. 模块级迁移说明

### 4\.1 核心 KPI 卡片：TAP 账户总数量、TAP 总 Revenue

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|两张 KPI 卡片，分别展示账户数和 USD Revenue。|Aime 中可以做两个指标卡；两个卡片共用同一个查询结果。|
|源报表|report 2892274 / accounts\-revenue\-ccr。|优先按 report 2892274 查询；字段列表为 `TAP Accounts`、`TAP Revenue`。|
|动态筛选|p\_date：顶部 Time Window；Sales region\-8\.6：顶部 Region；tier\_v3\_name：顶部 Tier。|使用字段 ID：p\_date = 10000002555291；Region = 10000016013590；Tier = 10000012645665。|
|指标口径|TAP Accounts = COUNT DISTINCT account\_id；TAP Revenue = 源图表返回 Revenue。|不要在前端对多行 Revenue 二次加总，除非 Aime 查询改成明细级；当前页面读取单行聚合结果。|

**参考 SQL 形态**：

```SQL
SELECT
  count(DISTINCT account_id) AS tap_accounts,
  Revenue AS tap_revenue
FROM Actor_All_In_One
WHERE p_date BETWEEN ${start_date} AND ${end_date}
  AND tier_v3_name IN (${selected_tiers})
  -- 若 Region != Global，追加 Sales region-8.6 对应值过滤
```

### 4\.2 P0 CCR / P0 NFS 卡片

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|两张 KPI 卡片：P0 CCR、P0 NFS。|Aime 中做两个指标卡，共用 report 2891879。|
|源报表|report 2891879 / TAP\_WB\_Tab1\_P0\_CCR\_NFS\_SalesRegion86\_v2。|字段列表为 `p0_nfs`、`p0_ccr`；数据集 1139137。|
|动态筛选|p\_date：顶部 Time Window；Sales region\-8\.6：顶部 Region；tier\_v3\_name：顶部 Tier。|字段 ID：p\_date = 10000003854360；Region = 10000016013001；Tier = 10000013113546。|
|固定筛选|is\_online = 1。|必须保留；否则 P0 口径会与风神保存图不一致。|
|计算方式|直接读取服务端聚合值 `Dynamic P0 Content CCR` 和 `P0: Negative Feedback Show`。|不要用每日 CCR 算术平均；CCR 必须由源看板 / 服务端聚合给出。|

### 4\.3 Approval Rate \- ET / ST / BT / HT 卡片

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|四张 KPI 卡片，每个 Tier 一张。|Aime 中执行一次按 tier\_v3\_name 分组查询，再按 tier 值拆成 4 个卡片。|
|源报表|report 2893221 / Approval Rate \- Tab1: Overview。|字段列表为 `tier_v3_name`、`Approval Rate`。|
|动态筛选|p\_date、Sales region\-8\.6、tier\_v3\_name。|字段 ID：p\_date = 1700008351638；Region = 10000016013722；Tier = 10000013681491。|
|固定筛选|audit\_status in 1,2；task\_audit\_mode in 1,2；delivery\_status in 1,2,3；is\_official=1；排除 DPA WholeProd / AIGC 类 / GMV Max / Smart\+ Derived Ads / Creative One。|这些固定过滤来自保存报表，迁移时必须保留，否则 Approval Rate 会偏离。|
|拆卡规则|ET = emerging\_trust；ST = strategic\_trust；BT = building\_trust；HT = high\_trust。|若某 Tier 无返回行，卡片显示 `—`，不要填 0。|

### 4\.4 Region × Tier Global Account Count \+ Revenue

**迁移重点**：当前工作台这个模块不是 live 查询，而是使用 `tab1P0Snapshots.ts` 中的静态快照。快照来源 report 2529294，窗口是 2026\-10\-01 \~ 2026\-10\-11。迁移到 Aime 时建议改成动态查询，否则用户切时间后图表不会随筛选准确变化。

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|组合图：X 轴 Region；Revenue 为柱；Account Count 为折线；颜色表示 Tier；下方有 Tier 汇总表。|Aime 中建议做组合图，或拆成两个图：Account Count 堆叠柱 \+ Revenue 分组柱，减少双轴误读。|
|当前数据|静态数组 `REGION_TIER_REVENUE_QTD_2529294`。|改为动态查询 Actor All In One，按 region × tier 聚合。|
|维度|region、tier。|Region 建议使用 account\_final\_region 并映射到标准 Region；Tier 使用 tier\_v3\_name。|
|指标|accountCount、revenue。|accountCount = COUNT DISTINCT account\_id；revenue = SUM Revenue 或使用源看板已聚合 Revenue。|
|排序|LATAM、NA、METAP、EUI、APAC、JP、KR、CNOB、Scaled Growth、GA、Other。|迁移后保持这个 Region 顺序，避免图表顺序变动影响验数。|

### 4\.5 TAP vs Non\-TAP by Region

**迁移重点**：当前也是静态快照派生模块，来源 report 2529294，窗口 2026\-10\-01 \~ 2026\-10\-11。Aime 迁移时建议动态化，并明确 TAP / Non\-TAP / Unknown Tier 的分类规则。

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|组合图：Account Share / Revenue Share 为柱；TAP / Non\-TAP Approval Rate 为折线；下方每个 Region 一张明细卡。|Aime 中可保留组合图 \+ 明细卡；如标签太密，精确值放到 tooltip 或明细表。|
|TAP 规则|tier\_v3\_name in strategic\_trust / high\_trust / building\_trust / emerging\_trust。|保持完全一致。|
|Non\-TAP 规则|非 TAP 且非 NULL / Unknown Tier。|Unknown / NULL Tier 单独核查，不并入 Non\-TAP。|
|Approval Rate|approved\_audit\_cnt\_1d / audited\_cnt\_1d。|如果 Aime 无法直接取保存报表字段，需确认分子分母和源快照完全一致后再复算。|
|占比|Account Share、Revenue Share 均在 Region 内按 TAP / Non\-TAP 占比展示。|建议返回 region、classification、account\_count、revenue、approval\_rate，然后前端或 Aime 层计算 share。|

### 4\.6 Tier 账户数量及占比

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|环形饼图 \+ 图例 \+ 明细表。|饼图标签显示 Tier 名称和占比；明细表显示数量和占比。|
|源报表|report 2891943 / TAP\_WB\_Tab1\_Account\_ByTier\_SalesRegion86\_v2。|字段为 Tier V3、TAP Accounts。|
|动态筛选|响应时间和 Region；不响应顶部 Tier 多选。|迁移时不要把顶部 Tier 传给这个图，否则饼图占比会失去全量 Tier 分布意义。|
|时间策略|Account 类图使用 snapshot 查询：从 endDate 往前 14 天查询，取返回中 latest p\_date。|Aime 若能直接获取最新有数日，优先使用“≤ endDate 的最新 p\_date”；否则用 14 天 lookback 取 latest。|

### 4\.7 Tier Revenue 及占比

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|环形饼图 \+ 图例 \+ 明细表。|饼图标签显示 Tier 名称和占比；明细表显示 Revenue 和占比。|
|源报表|report 2883029 / TAP\_WB\_Overview\_Revenue\_By\_Tier\_v1。|字段为 tier\_v3\_name、Revenue。|
|动态筛选|响应时间和 Region；不响应顶部 Tier 多选。|迁移时不要把顶部 Tier 传给这个图。|
|计算|按 tier 汇总 Revenue，share = tier\_revenue / total\_revenue。|保留服务端按 tier 聚合结果，前端仅计算占比。|

### 4\.8 P0 / P1 CCR \+ NFS 周趋势

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|双轴趋势图：CCR 为折线，NFS 为柱。|Aime 图表建议左轴放 CCR，右轴放 NFS；tooltip 显示精确值。|
|P0 源报表|report 2883040 / TAP\_WB\_P0\_CCR\_NFS\_Trend\_v2。|字段：week、Sales region\-8\.6、tier\_v3\_name、p0\_nfs、dynamic\_p0\_ccr。|
|P1 源报表|report 2883016 / TAP\_WB\_P1\_Candidate\_Validation\_v2。|字段：week、Sales region\-8\.6、tier\_v3\_name、p1\_nfs、dynamic\_p1\_ccr。|
|固定筛选|is\_online = 1。|必须保留。|
|动态筛选|p\_date、Sales region\-8\.6、tier\_v3\_name。|字段 ID：p\_date = 10000003854360；Region = 10000016013001；Tier = 10000013113546。|
|前端合并|将 NFS series 与 CCR series 按 week 合并；NFS 同 week 同 key 使用 sum；CCR 使用源返回值。|Aime 如果直接输出同一行包含 CCR/NFS，可少做合并；不要对 CCR 做日均。|

### 4\.9 Approval Rate / Banned Volume 周趋势

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|双轴趋势图：Approval Rate 为折线，Banned Volume 为柱。|Global 时用 No Region 报表；指定 Region 时用 Region 版报表。|
|Global 源报表|report 2883018 / Approval Rate \- Quarter\-TAP\-No region。|字段：week、tier\_v3\_name、Approval Rate、banned。|
|指定 Region 源报表|report 2883037 / Approval Rate \- Quarter\-TAP。|字段：week、tier\_v3\_name、combined\_sales\_team\_region、Approval Rate、banned。|
|固定筛选|与 Approval 卡片一致：audit\_status、task\_audit\_mode、delivery\_status、is\_official、产品排除条件等。|保留保存报表固定过滤，不要只按 p\_date 重写。|
|动态筛选|p\_date、Tier；指定 Region 时还需要 Region。|p\_date = 1700008351638；Tier = 10000013681491；当前代码 Region 字段下推为 10000016013722。|

### 4\.10 Ads FDR / Overturned Volume 周趋势

|项目|当前实现|Aime 迁移方法|
|---|---|---|
|展示形式|双轴趋势图：FDR 为折线，Overturned Volume 为柱。|FDR 和 Overturned 来自两个报表，按 week 合并展示。|
|Global FDR 源|report 2883048 / TAP\_WB\_FDR\_Weekly\_Global\_By\_Tier\_v1。|Global 不带 Region 维度，按 tier 展示。|
|指定 Region FDR 源|report 2883021 / TAP\_WB\_FDR\_Weekly\_Runtime\_v1。|带 combined\_sales\_team\_region 维度，响应顶部 Region。|
|Overturned 源|report 2883046 / TAP\_WB\_Overturned\_Account\_Weekly\_v2。|字段：week、combined\_sales\_team\_region、tier\_v3\_name、overturned\_account\_volume。|
|FDR 固定筛选|Quality Metrics Product Line in Auction 系列；sample\_info\_metric = ACC,FPR；sub\_metric\_type = Overall FPR；p\_date 为最新快照；inspect\_id 非空。|必须保留这些固定过滤，否则 FDR 会不一致。|
|Overturned 固定筛选|ticket\_is\_overturn = 1；p\_date 为最新快照；inspect\_id 非空。|Overturned Volume = COUNT DISTINCT account\_id。|

## 5\. Aime 迁移实现建议

### 5\.1 推荐执行顺序

1. **先接入保存报表查询**：优先按 Report ID 拉取已保存风神报表，保留固定过滤和服务端指标公式。

2. **接入全局筛选控件**：实现 Time Window、Customer Region、TAP Tier 三个控件，并按本文字段 ID 下推动态过滤。

3. **先完成卡片和饼图**：核心 KPI、Approval 卡片、Tier 分布最容易对拍。

4. **再完成趋势图**：注意 Global / 指定 Region 分源逻辑。

5. **最后处理两个静态快照模块**：Region × Tier、TAP vs Non\-TAP 当前不是 live 数据，迁移时建议动态化并单独验数。

### 5\.2 对拍清单

|验收项|对拍方式|通过标准|
|---|---|---|
|核心 4 张 KPI|同一 Time Window / Region / Tier 下，对比 report 2892274 和 2891879。|账户数、Revenue、P0 CCR、P0 NFS 与风神保存报表一致。|
|Approval 4 张卡|对比 report 2893221 返回的 tier\_v3\_name 行。|ET/ST/BT/HT 卡片值等于对应 tier 行的 Approval Rate。|
|Tier 账户饼图|对比 report 2891943；注意不传顶部 Tier。|每个 Tier 的账户数和占比一致。|
|Tier Revenue 饼图|对比 report 2883029；注意不传顶部 Tier。|每个 Tier 的 Revenue 和占比一致。|
|P0/P1 周趋势|对比 report 2883040 / 2883016。|同 week、同 tier 下 CCR/NFS 一致；CCR 不做前端平均。|
|Approval/Banned 周趋势|Global 对 report 2883018；指定 Region 对 report 2883037。|切 Region 后源图选择正确，且趋势点一致。|
|FDR/Overturned 周趋势|Global FDR 对 2883048；指定 Region FDR 对 2883021；Overturned 对 2883046。|FDR 与 Overturned 按 week 合并后展示一致。|
|静态快照模块|若动态化，需用 2529294 或新专用报表重建 QTD 口径。|Region × Tier、TAP/Non\-TAP 的 account/revenue/approval 与新源可复算。|

## 6\. 迁移风险与处理建议

**最重要的迁移风险**：Tab1 不是所有模块都是 live 风神查询；Region × Tier 和 TAP vs Non\-TAP 当前依赖旧快照。Aime 如果希望“顺利出数、准确出数”，这两个模块应优先重建为动态源，而不是复制旧快照。

- **不要复算 CCR**：P0/P1 CCR 均直接读取源报表服务端聚合指标，不做日均、不做前端分子分母重算。

- **不要给 Tier 分布图下推 Tier 筛选**：否则饼图只会展示被选中的 Tier，无法表达全量占比。

- **Global 与指定 Region 分源**：Approval/Banned、FDR 趋势在 Global 和 Region 视角使用不同保存报表，Aime 必须实现同样分支。

- **保留固定过滤**：Approval、FDR、Overturned 都有大量固定过滤；迁移时只复制字段和指标不够，必须复制固定 where 条件。

- **处理最新快照日期**：Actor 账户类图表使用快照日期，当前前端用 14 天 lookback 找 latest snapshot；Aime 最好直接查询 `max(p_date) <= endDate` 后再按该 p\_date 聚合。

- **保留 Unknown / NULL Tier 边界**：TAP vs Non\-TAP 模块中 Unknown / NULL Tier 不并入 Non\-TAP。

## 7\. 参考入口

- 当前 Workbench：[https://f7c5cbe3d33d\.ida\-app\-sg\.tiktok\-row\.net](https://f7c5cbe3d33d.ida-app-sg.tiktok-row.net)

- 当前 Dashboard Sheet：[https://aeolus\-sg\.tiktok\-row\.net/aeolus/pages/dashboard/679385?sheetId=812835\&web\_report=1](https://aeolus-sg.tiktok-row.net/aeolus/pages/dashboard/679385?sheetId=812835&web_report=1)

- 主要分析主题：TAP Stats Monitor = metrics\_theme\_id 6236；Content CCR Metrics = 336；Ticket Info = 583；Tianshu Allowlist = 1665。

