// Preserve the uploaded native host (including its real private SDK); build only
// the added Overview entry. No SDK replacement or original business rewrite.
import path from 'node:path';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const config=JSON.parse(await fs.readFile(path.join(root,'config/workbench_build.json'),'utf8'));
const out=path.join(root,'app/dist'),native=path.join(root,config.native_host);
const digest=data=>createHash('sha256').update(data).digest('hex');
if(config.legacy_mode==='preserve_uploaded_host'){
 const manifest=JSON.parse(await fs.readFile(path.join(native,'manifest.json'),'utf8'));
 for(const [file,hash] of Object.entries(manifest.protected_frontend_sources))if(digest(await fs.readFile(path.join(root,file)))!==hash)throw Error(`Native frontend source changed: ${file}. Rebuild with real SDK using legacy_mode=native; refusing stale compiled host.`);
 for(const [file,hash] of Object.entries(manifest.assets))if(digest(await fs.readFile(path.join(native,file)))!==hash)throw Error(`Native asset integrity failed: ${file}`);
 await fs.rm(out,{recursive:true,force:true});await fs.mkdir(out,{recursive:true});
 for(const file of Object.keys(manifest.assets)){const p=path.join(out,file);await fs.mkdir(path.dirname(p),{recursive:true});await fs.copyFile(path.join(native,file),p)}
}
const modules=process.env.TAP_BUILD_NODE_MODULES||path.join(root,'app/frontend/node_modules');
const require=createRequire(path.join(modules,'../package.json'));const {build}=require('esbuild');
const result=await build({absWorkingDir:path.join(root,'app/frontend'),entryPoints:['src/integrated-overview-entry.tsx'],outdir:path.join(out,'assets'),entryNames:'integrated-overview-[hash]',bundle:true,splitting:true,format:'esm',minify:true,target:'es2022',jsx:'automatic',nodePaths:[modules],alias:{'@bytecloud/common-lib':path.join(root,'app/frontend/vendor/bytecloud/index-CyHTFGrwEOXakQLE.js')},define:{'process.env.NODE_ENV':'"production"'},metafile:true});
const outputs=Object.entries(result.metafile.outputs),entry=outputs.find(([,x])=>x.entryPoint?.endsWith('integrated-overview-entry.tsx'));if(!entry)throw Error('Missing entry');
const css=outputs.filter(([p])=>p.endsWith('.css'));
await fs.writeFile(path.join(out,'overview.html'),`<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TAP 数据总览 · Integrated</title>${css.map(([p])=>`<link rel="stylesheet" href="./assets/${path.basename(p)}">`).join('')}</head><body><div id="root"></div><script type="module" src="./assets/${path.basename(entry[0])}"></script></body></html>`);
console.log('Integrated Overview built; native host retained:',config.legacy_mode);
