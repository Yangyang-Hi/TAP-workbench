import { Button, Drawer, Pagination, Radio, Table, Tabs, Tag } from "@arco-design/web-react";
import { ArrowRight, BellRing, ChevronRight, FileSearch, Info, ShieldAlert, Users } from "lucide-react";
import { useMemo, useState } from "react";
import type { ReadModel, ReadRow } from "./read-model";
import { comparisonReason, entityGrain, eventAnchor, metric, noticeLabels, present, riskGrowth, riskGrowthLabel, riskGrowthReason, riskLabels, stageLabels } from "./read-model";
import { MetricDisplay, conservativeMetricFact } from "./metric-display";
import { ReportedReasonsView, reportedReasonGroups } from "./reported-reasons";
import { GovernanceAnalytics } from "./casework-analytics";
import { CaseActions } from "./casework";
import { workbenchApi } from "./api";
import { useSharedFilters } from "./shared-filters";
import { SubmissionQuota } from "./submission-quota";

type ChangePage = (page: number) => void;
type Ranking = "combined" | "growth" | "absolute";
const StatusTag = ({ text, tone }: { text: string; tone?: "red" | "orange" | "green" | "blue" | "gray" }) => <Tag color={tone}>{text}</Tag>;
const alertCategories = (row: ReadRow) => {
  const reasons = [...(row.risk_reasons || []), ...(row.pair_absolute_reasons || [])];
  const growth = reasons.some((reason) => /Top20/i.test(reason));
  const absolute = ["watch", "critical"].includes(row.pair_absolute_level || "") || reasons.some((reason) => /CCR.*(?:≥|>=).*NFS|NFS.*(?:>|≥|>=)/i.test(reason));
  return { growth, absolute };
};
const CategoryTags = ({ row }: { row: ReadRow }) => {
  const category = alertCategories(row);
  return <span className="ops-category-tags">
    {category.growth && <StatusTag text="CCR 增幅 Top20" tone="blue" />}
    {category.absolute && <StatusTag text="CCR/NFS 绝对值" tone="orange" />}
    {category.growth && category.absolute && <StatusTag text="双重命中" tone="red" />}
  </span>;
};
const WindowText = ({ row }: { row: ReadRow }) => <span className="ops-window-text"><span><b>事件锚点</b>{eventAnchor(row)}{(row.comparison.event_id || row.protection_event_id) && <> · {row.comparison.event_id || row.protection_event_id}</>}</span><span><b>Pre</b>{row.comparison.pre_start_date || "—"} → {row.comparison.pre_end_exclusive || "—"}</span><span><b>Post</b>{row.comparison.post_start_date || "—"} → {row.comparison.post_end_exclusive || "—"}</span></span>;

export function UnsupportedState({ model }: { model: ReadModel }) {
  return <section className="ops-state ops-state-warning" data-testid="custom-unsupported"><FileSearch size={26} /><div><b>自定义区间批量查询待接入</b><p>当前区间暂时无法返回数据。可切回周度批次查看已有结果。</p><details className="ops-diagnostic"><summary>查看查询状态</summary><p>当前后端状态：{model.status || "unsupported"} · {model.reason || "custom_bulk_query_pending"}</p><p>本次未扫描、未建单、未发送；所有统计保持“—”，不按 0 或成功展示。</p></details></div></section>;
}

export function Overview({ model, showQuota = true }: { model: ReadModel; showQuota?: boolean }) {
  const custom = model.time.mode === "custom";
  const cards = [
    ["queried_customers", "已查询客户", "当前完整筛选客户池去重，不受分页影响"],
    ...(custom ? [["risk_customers", "命中风险客户", "自定义窗口只读命中客户数"]] : []),
    ["auto_alerted", custom ? "自动报警（不适用）" : "已自动报警客户", custom ? "不适用于自定义查询；不会写入正式通知台账" : "仅计真实成功自动通知；后端不可区分时显示 —"],
    ["pending", custom ? "待处理（不适用）" : "待处理客户", custom ? "不适用于自定义查询；不会创建 casework 事件" : "命中预警且仍待运营确认发送的去重客户"],
    ["handled", custom ? "已处理（不适用）" : "已处理客户", custom ? "不适用于自定义查询；保留周度正式值" : "仅表示通知完成，不等于风险处置关闭"],
    ["closed", custom ? "已关闭（不适用）" : "已关闭事件", custom ? "不适用于自定义查询；保留周度正式值" : "已完成提报人处理并关闭；是否改善以效果分析中的真实复查为准"],
  ];
  const icons = [Users, ...(custom ? [ShieldAlert] : []), BellRing, ShieldAlert, FileSearch, ShieldAlert];
  return <div data-testid="overview-page" className="ops-overview">
    <section className="ops-stat-grid">{cards.map(([key, label, fallback], index) => { const card = model.cards?.[key]; const Icon = icons[index]; return <article className={`ops-stat ops-stat-${key}`} key={key}><div className="ops-stat-title"><span>{label}</span><Icon size={17} /></div><strong>{card?.value == null ? "—" : card.value}</strong><small title={card?.description || card?.note || fallback}>{card?.description || card?.note || fallback}</small>{card?.status && card.status !== "available" && <StatusTag text={card.status} tone="orange" />}</article>; })}</section>
    <details className="ops-disclosure ops-stat-help"><summary><Info size={14} /> 统计说明</summary><div className="ops-definition-grid"><div><b>已查询</b><span>客户池去重总数，不使用当前页行数。</span></div><div><b>报警成功</b><span>排队、失败、未知不计入成功。</span></div><div><b>待处理</b><span>事件阶段为待运营确认。</span></div><div><b>已处理</b><span>通知环节完成；事件是否关闭另看事件阶段。</span></div></div></details>
    {showQuota && <SubmissionQuota alertsOnly />}
  </div>;
}

function RiskCards({ rows, onOpen }: { rows: ReadRow[]; onOpen: (row: ReadRow) => void }) {
  return <div className="ops-risk-cards" data-testid="risk-mobile-list">{rows.map((row) => <article key={`${row.scan_id}-${row.row_id}`}>
    <header><div><b>{present(row.account_name || row.account_id || row.advertiser_id)}</b><code>{present(row.alert_id || row.account_id)}</code></div><StatusTag text={riskLabels[row.risk_level] || present(row.risk_level)} tone={row.risk_level === "extreme" ? "red" : "orange"} /></header>
    <p><b>{entityGrain(row)}</b> · {row.tier || row.program || "—"} · {present(row.region)} · 原提报人 {present(row.original_submitter)}</p>
    <CategoryTags row={row} />
    <div className="ops-mobile-metrics"><span>P0 CCR <b><MetricDisplay fact={row.p0_ccr_fact || conservativeMetricFact(row.p0_ccr, row.ccr_status || row.metric_status)} format="ccr" /></b></span><span>P0 NFS <b><MetricDisplay fact={row.p0_nfs_fact || conservativeMetricFact(row.p0_nfs, row.nfs_status || row.metric_status)} format="nfs" /></b></span><span>Revenue <b><MetricDisplay fact={row.revenue_fact || conservativeMetricFact(row.revenue, row.revenue_status)} format="revenue" /></b></span></div>
    <p>Pre → Post P0 CCR <MetricDisplay fact={row.comparison.pre_ccr_fact || conservativeMetricFact(row.comparison.pre_ccr, row.comparison.status, row.comparison.missing_reason)} format="ccr" /> → <MetricDisplay fact={row.comparison.post_ccr_fact || conservativeMetricFact(row.comparison.post_ccr, row.comparison.status, row.comparison.missing_reason)} format="ccr" /> · {riskGrowthLabel(row)} <MetricDisplay fact={row.comparison.increase_fact || conservativeMetricFact(row.comparison.ccr_growth_pct, row.comparison.status, row.comparison.missing_reason)} format="pct" /></p><p>{riskGrowthReason(row)}</p><p>{row.risk_reasons?.join("；") || "—"}</p><div className="ops-card-footer"><span>{stageLabels[row.event_stage] || present(row.event_stage)} · {noticeLabels[row.notification.status] || present(row.notification.status)}</span><Button size="small" onClick={() => onOpen(row)}>处理事件</Button></div>
  </article>)}</div>;
}

export function RiskMonitor({ model, stage, onStage, ranking, onRanking, page, onPage, onSaved }: { model: ReadModel; stage: string; onStage: (value: string) => void; ranking: Ranking; onRanking: (value: Ranking) => void; page: number; onPage: ChangePage; onSaved?: () => void }) {
  const { filters } = useSharedFilters();
  const [mode, setMode] = useState("risk");
  const [selected, setSelected] = useState<ReadRow>();
  const [focusAlertId, setFocusAlertId] = useState(() => new URLSearchParams(location.search).get("alert_id") || "");
  const [opening, setOpening] = useState("");
  const [openError, setOpenError] = useState("");
  const rows = model.rows;
  async function openRow(row: ReadRow) {
    setSelected(row); setOpenError(""); setFocusAlertId(row.alert_id || "");
    if (row.alert_id || filters.time_mode === "custom") return;
    setOpening(row.row_id);
    try {
      const r = await workbenchApi<{data: {id: string}}>("/api/workbench/cases", { scan_id: row.scan_id, row_id: row.row_id });
      setFocusAlertId(r.data.id); onSaved?.();
    } catch(e) {setOpenError(e instanceof Error ? e.message : "事件打开失败");}
    finally {setOpening("");}
  }
  const columns = [
    { title: "客户", width: 230, render: (_: unknown, row: ReadRow) => <div className="ops-customer"><b>{present(row.account_name || row.account_id || row.advertiser_id)}</b><code title={row.program === "THT" ? row.advertiser_id : row.account_id}>{row.program === "THT" ? "Advertiser" : "Account"} {present(row.program === "THT" ? row.advertiser_id : row.account_id)}</code><small title={row.alert_id || undefined}>{present(row.alert_id)}</small></div> },
    { title: "Tier / 区域", width: 110, render: (_: unknown, row: ReadRow) => <><span className="ops-tier">{row.tier || row.program || "—"}</span><small>{present(row.region)}</small></> },
    { title: "Submitter", width: 125, render: (_: unknown, row: ReadRow) => present(row.original_submitter) },
    { title: "P0 CCR", width: 150, render: (_: unknown, row: ReadRow) => <b className={row.risk_level === "extreme" ? "ops-error-text ops-number" : "ops-number"}><MetricDisplay fact={row.p0_ccr_fact || conservativeMetricFact(row.p0_ccr, row.ccr_status || row.metric_status)} format="ccr" /></b> },
    { title: "P0 NFS", width: 110, render: (_: unknown, row: ReadRow) => <MetricDisplay className="ops-number" fact={row.p0_nfs_fact || conservativeMetricFact(row.p0_nfs, row.nfs_status || row.metric_status)} format="nfs" /> },
    { title: "Revenue", width: 140, render: (_: unknown, row: ReadRow) => <MetricDisplay className="ops-number" fact={row.revenue_fact || conservativeMetricFact(row.revenue, row.revenue_status)} format="revenue" /> },
    { title: "Pre → Post CCR", width: 190, render: (_: unknown, row: ReadRow) => <span className="ops-number"><MetricDisplay fact={row.comparison.pre_ccr_fact || conservativeMetricFact(row.comparison.pre_ccr, row.comparison.status, row.comparison.missing_reason)} format="ccr" /> <span className="ops-soft">→</span> <MetricDisplay fact={row.comparison.post_ccr_fact || conservativeMetricFact(row.comparison.post_ccr, row.comparison.status, row.comparison.missing_reason)} format="ccr" /></span> },
    { title: "风险 CCR 增幅", width: 180, render: (_: unknown, row: ReadRow) => <><b className="ops-number"><MetricDisplay fact={row.comparison.increase_fact || conservativeMetricFact(row.comparison.ccr_growth_pct, row.comparison.status, row.comparison.missing_reason)} format="pct" /></b><small>{riskGrowthLabel(row)} · <span title={riskGrowthReason(row)}>{riskGrowthReason(row)}</span></small></> },
    { title: "Alert Type", width: 190, render: (_: unknown, row: ReadRow) => <CategoryTags row={row} /> },
    { title: "Alert Level", width: 120, render: (_: unknown, row: ReadRow) => <StatusTag text={riskLabels[row.risk_level] || present(row.risk_level)} tone={row.risk_level === "extreme" ? "red" : "orange"} /> },
    { title: "Trigger Criteria", width: 210, render: (_: unknown, row: ReadRow) => <small className="ops-reason-preview" title={row.risk_reasons?.join("；")}>{row.risk_reasons?.join("；") || "—"}</small> },
    { title: "Status", width: 150, render: (_: unknown, row: ReadRow) => <><StatusTag text={stageLabels[row.event_stage] || present(row.event_stage)} tone={row.event_stage === "closed" ? "green" : "blue"} /><small className={row.notification.status === "failed" ? "ops-error-text" : ""}>{noticeLabels[row.notification.status] || present(row.notification.status)}</small></> },
    { title: "操作", width: 112, fixed: "right" as const, render: (_: unknown, row: ReadRow) => <Button type="text" size="mini" disabled={!!opening} onClick={() => void openRow(row)}>{filters.time_mode === "custom" ? "查看详情" : "处理事件"} <ChevronRight size={13} /></Button> },
  ];
  return <div data-testid="risk-page">
    <Radio.Group className="ops-section-switch" type="button" value={mode} onChange={setMode}><Radio value="risk">高风险客户</Radio><Radio value="quota">Quota 区域预警</Radio></Radio.Group>
    <div hidden={mode !== "risk"}>
      <Overview model={model} showQuota={false} />
      <section className="ops-list-panel">
        <div className="ops-list-heading"><div><h2>客户风险列表</h2><span>{model.time.selected_batch ? `${model.time.selected_batch.metric_start_date} 至 ${model.time.selected_batch.metric_end_date}` : `${model.time.start_date || "—"} 至 ${model.time.end_date || "—"}`}</span></div><span className="ops-soft">命中客户 {model.pagination.total} 位</span></div>
        <div className="ops-list-tools"><div className="ops-list-filters"><Radio.Group className="ops-category-filter" type="button" value={ranking} onChange={onRanking} aria-label="预警分类筛选"><Radio value="combined">全部预警</Radio><Radio value="growth">CCR 增幅 Top20</Radio><Radio value="absolute">CCR/NFS 绝对值</Radio></Radio.Group><Radio.Group className="ops-stage-filter" type="button" value={stage} onChange={onStage} aria-label="事件阶段筛选"><Radio value="all">全部事件</Radio><Radio value="pending_operator">待运营确认</Radio><Radio value="pending_submitter">待提报人处理</Radio><Radio value="closed">已关闭</Radio></Radio.Group></div><span className="ops-soft">本页 {rows.length} 位 · 绝对值与增幅独立分类，Top20 由服务端完整候选池计算</span></div>
        <div className="ops-risk-table" data-testid="risk-desktop-table"><Table rowKey={(row) => `${row.scan_id}-${row.row_id}`} columns={columns} data={rows} pagination={false} borderCell={false} scroll={{x: 1680}} /></div>
        <RiskCards rows={rows} onOpen={(row) => void openRow(row)} />
        {!rows.length && <div className="ops-empty"><FileSearch size={26} /><b>"当前范围暂无命中客户"</b><p>"仅展示绝对值命中、增幅 Top20 和极端增幅客户；缺失数据不当作零。"</p></div>}
        <div className="ops-list-footer"><span>先从完整客户池选取风险客户，再分页；同一客户多条命中合并展示。</span>{model.pagination.total > model.pagination.page_size && <Pagination current={page} pageSize={model.pagination.page_size} total={model.pagination.total} onChange={onPage} showTotal />}</div>
      </section>
    </div>
    {mode === "quota" && <SubmissionQuota alertsOnly />}
    {model.status === "unsupported" && mode === "risk" && <UnsupportedState model={model} />}
    <EventDetail row={selected} alertId={focusAlertId} error={openError} loading={!!opening} onClose={() => {setSelected(undefined);setFocusAlertId("");}} onSaved={onSaved} />
  </div>;
}

function EventDetail({ row, alertId, onClose, onSaved, error, loading }: { row?: ReadRow; alertId: string; onClose: () => void; onSaved?: () => void; error: string; loading: boolean }) {
  if (!row && !alertId) return null;
  if (!row) return <Drawer width="min(920px, 100vw)" visible title="处理预警事件" onCancel={onClose} footer={null} unmountOnExit><CaseActions id={alertId} onSaved={onSaved} /></Drawer>;
  return <Drawer width="min(920px, 100vw)" visible title="处理预警事件" onCancel={onClose} footer={null} unmountOnExit className="ops-event-drawer">
    <div className="ops-detail" data-testid="event-detail">
      <section className="ops-detail-identity"><div className="ops-detail-title"><div><span>{entityGrain(row)} · {row.tier || row.program || "—"} · {present(row.region)}</span><h2>{present(row.program === "THT" ? row.advertiser_id : row.account_name || row.account_id)}</h2><code>{row.program === "THT" ? `Advertiser ${present(row.advertiser_id)} · 真实关联 Account ${present(row.account_id)}` : `Account ${present(row.account_id)}`}</code></div><StatusTag text={riskLabels[row.risk_level] || present(row.risk_level)} tone={row.risk_level === "extreme" ? "red" : "orange"} /></div><dl><div><dt>Submitter</dt><dd>{present(row.original_submitter)}</dd></div><div><dt>Status</dt><dd>{stageLabels[row.event_stage] || present(row.event_stage)}</dd></div><div><dt>Region</dt><dd>{present(row.region)}</dd></div><div><dt>Time Window</dt><dd><WindowText row={row} /></dd></div><div><dt>Allowlist</dt><dd>{row.allowlist_status ? `${row.allowlist_status}${row.allowlist_reason ? ` · ${row.allowlist_reason}` : ""}` : "unknown · 未确认豁免，不自动排除风险"}</dd></div></dl>{row.alert_id && <code>{row.alert_id}</code>}</section>
      <section><h3>{entityGrain(row)} 关键指标</h3><div className="ops-detail-metrics ops-current-metrics">{[["P0 CCR",<MetricDisplay fact={row.p0_ccr_fact || conservativeMetricFact(row.p0_ccr, row.ccr_status || row.metric_status)} format="ccr" />],["P0 NFS",<MetricDisplay fact={row.p0_nfs_fact || conservativeMetricFact(row.p0_nfs, row.nfs_status || row.metric_status)} format="nfs" />],["Revenue",<MetricDisplay fact={row.revenue_fact || conservativeMetricFact(row.revenue, row.revenue_status)} format="revenue" />]].map(([label,value])=><div key={String(label)}><span>{label}</span><b>{value}</b></div>)}</div><div className="ops-detail-metrics">{[["Pre → Post P0 CCR",<><MetricDisplay fact={row.comparison.pre_ccr_fact || conservativeMetricFact(row.comparison.pre_ccr, row.comparison.status, row.comparison.missing_reason)} format="ccr" /> → <MetricDisplay fact={row.comparison.post_ccr_fact || conservativeMetricFact(row.comparison.post_ccr, row.comparison.status, row.comparison.missing_reason)} format="ccr" /></>],[riskGrowthLabel(row),<MetricDisplay fact={row.comparison.increase_fact || conservativeMetricFact(row.comparison.ccr_growth_pct, row.comparison.status, row.comparison.missing_reason)} format="pct" />],["NFS Delta",metric(row.comparison.nfs_delta)],["Revenue Delta",metric(row.comparison.revenue_delta)]].map(([label,value])=><div key={String(label)}><span>{label}</span><b>{value}</b></div>)}</div>{row.comparison.status === "incompatible_legacy_grain" && <p className="cw-error">— · {row.comparison.missing_reason || "旧记录粒度不兼容"}</p>}<details className="ops-diagnostic"><summary>事件锚点、比较窗口与数据状态</summary><WindowText row={row} /><p>保护窗口：{comparisonReason(row.comparison)}</p><p>{riskGrowthLabel(row)}：{riskGrowthReason(row)}</p><p>每条保护事件独立计算；未返回事件锚点时不合并为客户级结果。</p></details></section>
      <section><h3>触发原因</h3><ul className="ops-reason-list">{row.risk_reasons?.length ? row.risk_reasons.map((reason) => <li key={reason}><ShieldAlert size={14} />{reason}</li>) : <li>—</li>}</ul></section>
      <section><div className="ops-detail-section-head"><h3>Advertiser Level</h3><span className="ops-soft">Top 10 Advertisers by P0 CCR · 已返回原因在源截断时仍保留 · actual {Math.min(row.advertiser_top10?.length || 0, 10)} rows</span></div><div className="ops-detail-table"><table><thead><tr><th>Advertiser ID / Name</th><th>P0 CCR</th><th>P0 NFS</th><th>Revenue</th><th>Reported Reasons</th>{row.program === "THT" && <><th>Pre → Post P0 CCR</th><th>WoW CCR Increase</th></>}</tr></thead><tbody>{(row.advertiser_top10 || []).slice(0,10).map((adv)=><tr key={`${adv.account_id || ""}-${adv.advertiser_id}`}><td>{present(adv.advertiser_id)}<small>{present(adv.advertiser_name)}</small></td><td><MetricDisplay fact={adv.ccr_fact || conservativeMetricFact(adv.ccr, adv.current_source?.status as string)} format="ccr" /></td><td><MetricDisplay fact={adv.nfs_fact || conservativeMetricFact(adv.nfs, adv.current_source?.status as string)} format="nfs" /></td><td><MetricDisplay fact={adv.revenue_fact || conservativeMetricFact(adv.revenue, undefined)} format="revenue" /></td><td><ReportedReasonsView groups={reportedReasonGroups([adv])} /></td>{row.program === "THT" && <><td><MetricDisplay fact={adv.pre_ccr_fact || conservativeMetricFact(adv.pre_ccr, adv.comparison_status, adv.comparison_reason)} format="ccr" /> → <MetricDisplay fact={adv.post_ccr_fact || conservativeMetricFact(adv.post_ccr, adv.comparison_status, adv.comparison_reason)} format="ccr" /><small>{adv.comparison_reason || adv.comparison_status || "—"}</small></td><td><MetricDisplay fact={adv.increase_fact || conservativeMetricFact(adv.ccr_growth_pct ?? adv.protection_ccr_growth_pct, adv.comparison_status, adv.comparison_reason)} format="pct" /></td></>}</tr>)}</tbody></table>{!row.advertiser_top10?.length && <p className="ops-empty-inline">No advertiser evidence</p>}</div></section>
      <section>{loading && <p>正在打开对应事件…</p>}{error && <p role="alert" className="cw-error">{error}</p>}{alertId && <CaseActions id={alertId} onSaved={onSaved} showEvidence={false} />}</section>
      <details className="ops-detail-history"><summary>通知记录与技术详情 <span>{row.notification.history?.length || 0} 条</span></summary>{row.notification.history?.length ? row.notification.history.map((notice,index)=><article className="ops-history" key={notice.id || index}><b>{noticeLabels[notice.status] || notice.status}</b><span>{present(notice.recipient)} · {present(notice.updated_at)}</span><small>message_id: {present(notice.message_id)}</small>{notice.error && <small className="ops-error-text">{notice.error}</small>}</article>) : <p>尚无通知记录</p>}</details>
    </div>
  </Drawer>;
}

export function Analysis({ model: _model }: { model?: ReadModel }) {
  return <div data-testid="analysis-page"><SubmissionQuota summaryOnly /><GovernanceAnalytics embedded /></div>;
}

export function DataCenter({ model }: { model?: ReadModel }) {
  const [tab, setTab] = useState("submission");
  const rows = useMemo(() => model?.rows || [], [model?.rows]);
  return <div data-testid="data-page"><Tabs activeTab={tab} onChange={setTab}><Tabs.TabPane key="submission" title="Submission / Quota"><SubmissionQuota /></Tabs.TabPane><Tabs.TabPane key="customers" title="客户指标"><section className="ops-panel"><header><div><h2>只读客户指标</h2><p>沿用共享时间与筛选；不扫描、不建单、不通知。</p></div></header><div className="ops-detail-table"><table><thead><tr><th>Account / Adv</th><th>Tier / Region</th><th>CCR / NFS / Revenue</th><th>比较状态</th></tr></thead><tbody>{rows.map((row)=><tr key={`${row.scan_id}-${row.row_id}`}><td>{present(row.account_id)}<small>{present(row.advertiser_id)} · {present(row.account_name)}</small></td><td>{row.tier || row.program || "—"} / {present(row.region)}</td><td><MetricDisplay fact={row.p0_ccr_fact || conservativeMetricFact(row.p0_ccr, row.ccr_status || row.metric_status)} format="ccr" /> / <MetricDisplay fact={row.p0_nfs_fact || conservativeMetricFact(row.p0_nfs, row.nfs_status || row.metric_status)} format="nfs" /> / <MetricDisplay fact={row.revenue_fact || conservativeMetricFact(row.revenue, row.revenue_status)} format="revenue" /></td><td>{comparisonReason(row.comparison)}</td></tr>)}</tbody></table></div></section></Tabs.TabPane></Tabs></div>;
}
