package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const (
	defaultTitanBaseSG       = "https://do-sg.byteintl.net"
	aeolusVQSQueryPath       = "/aeolus/vqs/api/v2/vizQuery/query"
	aeolusSavedReportPath    = "/aeolus/api/v3/dataMart/report"
	aeolusGlueToSimplePath   = "/aeolus/glue/api/v1/ai_dashboard_util/to_simple_chart"
	aeolusGlueQueryChartPath = "/aeolus/glue/api/v1/ai_dashboard_util/query_chart"
	aeolusSessionProbePath   = "/aeolus/api/v3/queryEngine/history"
)

type titanProbeStep struct {
	Status              string            `json:"status"`
	RequestURL          string            `json:"request_url,omitempty"`
	HTTPStatus          int               `json:"http_status,omitempty"`
	ResponseContentType string            `json:"response_content_type,omitempty"`
	TestedAt            string            `json:"tested_at,omitempty"`
	ErrorType           string            `json:"error_type,omitempty"`
	ErrorMessage        string            `json:"error_message,omitempty"`
	ResponsePreview     string            `json:"response_preview,omitempty"`
	TokenObtained       bool              `json:"token_obtained,omitempty"`
	ForbiddenDetected   bool              `json:"forbidden_detected,omitempty"`
	ReportID            int               `json:"report_id,omitempty"`
	SimpleChartObtained bool              `json:"simple_chart_obtained,omitempty"`
	RowsCount           int               `json:"rows_count,omitempty"`
	Columns             []string          `json:"columns,omitempty"`
	Rows                []map[string]any  `json:"rows,omitempty"`
	FieldMap            map[string]string `json:"field_map,omitempty"`
	SampleRows          map[string]any    `json:"sample_rows,omitempty"`
	GlueCode            any               `json:"glue_code,omitempty"`
	GlueSuccess         any               `json:"glue_success,omitempty"`
	GlueMessage         string            `json:"glue_message,omitempty"`
	RequestID           string            `json:"request_id,omitempty"`
	LogID               string            `json:"log_id,omitempty"`
	QueryHistoryID      string            `json:"query_history_id,omitempty"`
	SQL                 string            `json:"-"`
	QueuePollCount      int               `json:"need_to_queue_poll_count,omitempty"`
}

func runTitanVQSProbe(ctx context.Context, r *http.Request, sourceName string) (result map[string]any, resultErr error) {
	metricProfile, isOverviewMetric := overviewMetricSource(sourceName)
	c, err := loadDataSourceConfig()
	if err != nil {
		return nil, err
	}
	// Isolated read-only profile; do not add Overview to existing admin syncs.
	if sourceName == overviewAccountSource {
		c.Sources[sourceName] = overviewAccountSourceConfig()
	}
	if isOverviewMetric {
		c.Sources[sourceName] = metricProfile.config()
	}
	source, ok := c.Sources[sourceName]
	if !ok {
		return nil, fmt.Errorf("unknown source")
	}
	if !source.Enabled || source.RID <= 0 {
		return nil, fmt.Errorf("source_not_configured: %s requires a verified %s-grain detail report", sourceName, source.Grain)
	}
	audit := newQueryAudit(r, sourceName, source)
	defer func() { audit.finish(result, resultErr) }()
	cfg, err := effectiveRuntimeConfig(c, requestUsername(r))
	if err != nil {
		return nil, err
	}
	result = map[string]any{
		"source":      sourceName,
		"source_kind": source.Kind,
		"grain":       source.Grain,
		"report_id":   source.RID,
		"dataset_id":  source.SID,
		"mode":        "saved_report_query",
		"auth_mode":   "titan",
		"vqs_path":    aeolusVQSQueryPath,
	}
	jwt, identity := resolveProbeByteCloudJWT(ctx, r)
	result["identity"] = identity
	if jwt == "" {
		result["status"] = "failed"
		return result, nil
	}
	titanToken, titanStep := exchangeProbeTitan(ctx, jwt)
	result["titan_exchange"] = titanStep
	if titanStep.Status != "passed" {
		result["status"] = "failed"
		return result, nil
	}
	sessionStep := probeTitanSession(ctx, cfg.Host, source.AppID, titanToken)
	result["session_probe"] = sessionStep
	if sessionStep.Status != "passed" {
		result["status"] = "failed"
		return result, nil
	}
	// Production scans always read the executable Saved Report request and send it
	// to VQS. Glue to_simple_chart/query_chart are diagnostics only and must never
	// be a silent substitute for the governed data path.
	savedRequest, simpleChart, chartStep := probeSavedReportRequest(ctx, cfg.Host, titanToken, source.RID)
	result["chart_definition"] = chartStep
	if savedRequest == nil || simpleChart == nil {
		result["status"] = "failed"
		result["blocked_stage"] = "saved_report_definition"
		return result, nil
	}
	result["chart_definition_source"] = "saved_report_reqJson"
	if isOverviewMetric {
		var e error
		metricProfile, e = overviewResolveMetricProfile(savedRequest, metricProfile)
		if e != nil {
			result["status"] = "filter_contract_failed"
			result["blocked_stage"] = "overview_source_binding"
			result["filter_error"] = sanitizeAuditText(e.Error())
			return result, nil
		}
		source = metricProfile.config()
		c.Sources[sourceName] = source
		result["resolved_overview_contract"] = map[string]any{"date_id": metricProfile.DateID, "tier_id": metricProfile.TierID, "region_id": metricProfile.RegionID, "week_window": metricProfile.WeekWindow}
	}

	// Saved-report detail profiles are expanded from the verified dataset-field
	// contract instead of inheriting an aggregate chart's dimensions/measures.
	sentChart := simpleChart
	if source.Kind == "detail" && len(source.QueryProfile.GroupBy) > 0 {
		sentChart = buildDetailSavedReportChart(simpleChart, source, effectiveSourceFields(c, sourceName))
	}
	delete(sentChart, "metricsThemeId")
	requestFilter := parseFilter(r)
	if err := validateProgramType(requestFilter.ProgramType); err != nil {
		return nil, err
	}
	requestFilter = filterSupportedBySource(requestFilter, source)
	sentChart, pushedDimensions := chartWithBusinessFilters(sentChart, source, requestFilter)
	if sourceName == overviewAccountSource {
		var contractErr error
		sentChart, contractErr = overviewAccountChart(savedRequest, sentChart, source, requestFilter)
		if contractErr != nil {
			return nil, contractErr
		}
		savedRequest = overviewAccountBase(savedRequest, requestFilter)
	}
	if isOverviewMetric {
		var contractErr error
		sentChart, contractErr = overviewMetricChart(savedRequest, sentChart, metricProfile, requestFilter)
		if contractErr != nil {
			return nil, contractErr
		}
	}
	windowID := strings.TrimSpace(r.URL.Query().Get("account_window_id"))
	if windowID != "" {
		var windowErr error
		sentChart, windowErr = applyAccountPlanWindow(sentChart, windowID)
		if windowErr != nil {
			return nil, windowErr
		}
		result["account_window_id"] = windowID
	}
	result["pushed_filter_dimensions"] = pushedDimensions
	// Saved-report by-ID queries use the confirmed field ID/uniqueId contract.
	requestedIDs := uniqueNonEmpty(strings.Split(r.URL.Query().Get("client_ids"), ","))
	idDimension := strings.TrimSpace(r.URL.Query().Get("id_dimension"))
	if idDimension == "" {
		idDimension = source.Identity.IDDimension
	}
	if len(requestedIDs) > 0 {
		spec := source.Fields[idDimension]
		if strings.TrimSpace(spec.DimMetID) == "" || strings.TrimSpace(spec.UniqueID) == "" {
			fieldID, uniqueID := chartFieldRef(sentChart, idDimension, spec)
			if strings.TrimSpace(spec.DimMetID) == "" {
				spec.DimMetID = fieldID
			}
			if strings.TrimSpace(spec.UniqueID) == "" {
				spec.UniqueID = uniqueID
			}
			source.Fields[idDimension] = spec
		}
		exact, filterErr := exactIDFilter(source, idDimension, requestedIDs)
		if filterErr != nil {
			result["status"] = "filter_contract_failed"
			result["filter_integrity"] = filterIntegrity{Status: "filter_contract_failed", Conclusion: "saved_report_unsupported", IDDimension: idDimension, Requested: requestedIDs, RequestedN: len(requestedIDs)}
			return result, nil
		}
		sentChart = cloneMap(sentChart)
		filters, _ := sentChart["filters"].([]any)
		sentChart["filters"] = append(filters, exact)
		result["expectedFilter"] = exact
	}
	result["simple_chart_diagnostics"] = buildChartDiagnostics(simpleChart, sentChart)
	result["sent_chart_filters"] = sentChart["filters"]
	result["contract_freeze"] = buildContractFreeze(source.RID, source.SID, simpleChart, chartStep.TestedAt)
	vqsRequest, vqsFilterErr := savedReportVQSRequest(savedRequest, sentChart, source, requestFilter, requestedIDs, idDimension)
	if vqsFilterErr != nil {
		result["status"] = "filter_contract_failed"
		result["blocked_stage"] = "saved_report_filter_rewrite"
		result["filter_error"] = sanitizeLogText(vqsFilterErr.Error())
		return result, nil
	}
	if isOverviewMetric {
		vqsRequest = overviewMetricRequest(vqsRequest, metricProfile, requestFilter)
	}
	result["effective_filters"] = describeVQSFilters(vqsRequest)
	result["partition"] = extractVQSPartition(vqsRequest)
	audit.setDefinition(vqsRequest)
	queryStep := probeVQS(ctx, cfg.Host, titanToken, source.AppID, source.RID, vqsRequest)
	stillTruncated := queryStep.RowsCount >= savedReportHardLimit
	result["execution_endpoint"] = aeolusVQSQueryPath
	result["query_result"] = queryStep
	result["rowCount"] = queryStep.RowsCount
	result["requestId"] = queryStep.RequestID
	result["logId"] = queryStep.LogID
	result["possibly_truncated"] = stillTruncated
	if queryStep.Status != "passed" {
		if diag, ok := result["simple_chart_diagnostics"].(chartDiagnostics); ok {
			result["failure_classification"] = classifyTitanVQSFailure(queryStep, diag)
			result["likely_problem_paths"] = diag.LikelyProblemPaths
		}
		result["status"] = "failed"
		return result, nil
	}
	result["status"] = "ok"
	// Runtime VQS columns use Saved Report schema uniqueIds. Resolve them from
	// the complete reqJson (including schema), not only from reqJson.query.
	fieldMap := buildContractFieldMap(savedRequest, queryStep.Columns)
	for column, descriptor := range queryStep.FieldMap {
		fieldMap[column] = descriptor
	}
	result["columns"] = queryStep.Columns
	result["field_map"] = fieldMap
	businessRows := canonicalizeSavedReportDetails(queryStep.Rows, effectiveSourceFields(c, sourceName), fieldMap)
	if sourceName == overviewAccountSource {
		var mappingErr error
		businessRows, mappingErr = overviewCanonicalAccounts(queryStep.Rows, fieldMap)
		if mappingErr != nil {
			result["status"], result["failure_classification"] = "failed", "overview_schema_mapping_failed"
			return result, nil
		}
	}
	if isOverviewMetric {
		var mappingErr error
		businessRows, mappingErr = overviewCanonicalMetrics(queryStep.Rows, fieldMap, metricProfile)
		if mappingErr != nil {
			result["status"], result["failure_classification"] = "failed", "overview_metric_schema_mapping_failed"
			result["filter_error"] = sanitizeAuditText(mappingErr.Error())
			return result, nil
		}
	}
	if !isOverviewMetric && queryStep.RowsCount > 0 && !hasMappedBusinessValue(businessRows, source.Fields) {
		result["status"] = "failed"
		result["failure_classification"] = "schema_mapping_failed"
		return result, nil
	}
	dateKey := "p_date"
	if _, ok := source.Fields["create_date"]; ok {
		dateKey = "create_date"
	}
	// Overview aggregate rows do not project Region/date and have no Account
	// primary key. Its validated server filters and shape checks are authoritative.
	if r.Header.Get("X-TAP-Quota-Mode") != "1" && sourceName != overviewAccountSource && !isOverviewMetric {
		postFilter := requestFilter
		// Aggregate Saved Reports can filter by date without projecting the date
		// dimension. The VQS whereList is authoritative in that case; applying a
		// second row-level date filter would incorrectly erase every fact row.
		hasProjectedDate := false
		for _, row := range businessRows {
			if strings.TrimSpace(asString(row[dateKey])) != "" {
				hasProjectedDate = true
				break
			}
		}
		if !hasProjectedDate {
			postFilter.StartDate, postFilter.EndDate = "", ""
		}
		businessRows = applyFilters(businessRows, postFilter, dateKey)
		businessRows = dedupeRows(sourceName, businessRows)
	}
	if len(requestedIDs) > 0 {
		// RID 2898676 enables an in-chart grand total. VQS returns that synthetic
		// row with a blank advertiser_id even for exact-ID requests; it is not a
		// business fact and must be removed before strict filter verification.
		if source.RID == 2898676 && idDimension == "advertiser_id" {
			facts := make([]map[string]any, 0, len(businessRows))
			for _, row := range businessRows {
				if strings.TrimSpace(asString(row[idDimension])) != "" {
					facts = append(facts, row)
				}
			}
			businessRows = facts
		}
		integrity := verifyReturnedIDs(source, idDimension, requestedIDs, businessRows)
		result["filter_integrity"] = integrity
		allowMissing := r.Header.Get("X-TAP-Allow-Missing-IDs") == "1"
		duplicatesOK := integrity.DuplicateN == 0 || allowsRepeatedIDRows(source, idDimension)
		missingOnly := allowMissing && len(integrity.Wrong) == 0 && integrity.NullN == 0 && duplicatesOK
		if integrity.Status != "verified" && !missingOnly {
			result["status"] = "filter_contract_failed"
			result["filter_integrity_summary"] = fmt.Sprintf("requested=%d matched=%d unmatched=%d wrong=%d null=%d duplicates=%d repeated_ids_allowed=%t", integrity.RequestedN, integrity.MatchedN, integrity.UnmatchedN, len(integrity.Wrong), integrity.NullN, integrity.DuplicateN, allowsRepeatedIDRows(source, idDimension))
			return result, nil
		}
		if missingOnly && integrity.Status != "verified" {
			integrity.Status = "verified_with_missing_facts"
			integrity.Conclusion = "filter_verified_missing_rows_are_no_data"
			result["filter_integrity"] = integrity
		}
	}
	result["business_rows"] = businessRows
	result["field_map"] = fieldMap
	result["rowCount"] = queryStep.RowsCount
	result["columns"] = queryStep.Columns
	result["rows"] = queryStep.Rows
	result["queriedAt"] = queryStep.TestedAt
	result["requestId"] = queryStep.RequestID
	result["logId"] = queryStep.LogID
	return result, nil
}

func resolveProbeByteCloudJWT(ctx context.Context, r *http.Request) (string, map[string]any) {
	now := time.Now().UTC().Format(time.RFC3339)
	if auth := strings.TrimSpace(r.Header.Get("Authorization")); strings.HasPrefix(strings.ToLower(auth), "byte-cloud-jwt ") {
		return strings.TrimSpace(auth[len("Byte-Cloud-JWT "):]), map[string]any{"status": "passed", "mode": "caller", "tested_at": now}
	}
	if jwt, err := GetCloudJWT(ctx, true); err == nil && strings.TrimSpace(jwt) != "" {
		return strings.TrimSpace(jwt), map[string]any{"status": "passed", "mode": "broker", "tested_at": now}
	}
	return "", map[string]any{"status": "failed", "mode": "none", "error_type": "no_bytecloud_jwt", "error_message": "未获取到页面用户或 AIME Broker Cloud JWT", "tested_at": now}
}

func exchangeProbeTitan(ctx context.Context, jwt string) (string, titanProbeStep) {
	url := defaultTitanBaseSG + "/titan/passport/token"
	step := titanProbeStep{Status: "failed", RequestURL: url, TestedAt: time.Now().UTC().Format(time.RFC3339)}
	payload := map[string]any{"x-jwt-token": jwt}
	body, _ := json.Marshal(payload)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		step.ErrorType = "request_build_error"
		step.ErrorMessage = err.Error()
		return "", step
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	resp, err := httpClient.Do(req)
	if err != nil {
		step.ErrorType = "network_error"
		step.ErrorMessage = sanitizeLogText(err.Error())
		return "", step
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	step.HTTPStatus = resp.StatusCode
	step.ResponseContentType = resp.Header.Get("Content-Type")
	step.RequestID = resp.Header.Get("x-request-id")
	step.LogID = resp.Header.Get("x-tt-logid")
	step.ResponsePreview = sanitizeLogText(truncateForLog(string(raw), 300))
	var parsed map[string]any
	if err := json.Unmarshal(raw, &parsed); err != nil {
		step.ErrorType = "non_json_response"
		step.ErrorMessage = "titan returned non-JSON response"
		return "", step
	}
	token := nestedString(parsed, "data", "token")
	if token == "" {
		step.ErrorType = "missing_titan_token"
		step.ErrorMessage = "titan response missing data.token"
		return "", step
	}
	step.Status = "passed"
	step.TokenObtained = true
	step.ResponsePreview = ""
	return token, step
}

func titanRequest(ctx context.Context, method, url, titanToken string, payload any) (*http.Response, []byte, error) {
	var reader io.Reader
	if payload != nil {
		b, _ := json.Marshal(payload)
		reader = bytes.NewReader(b)
	}
	req, err := http.NewRequestWithContext(ctx, method, url, reader)
	if err != nil {
		return nil, nil, err
	}
	req.Header.Del("Authorization")
	req.Header.Set("x-titan-token", titanToken)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")
	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, nil, err
	}
	defer resp.Body.Close()
	raw, readErr := io.ReadAll(resp.Body)
	if readErr != nil {
		return resp, nil, readErr
	}
	return resp, raw, nil
}

func probeTitanSession(ctx context.Context, host string, appID int, titanToken string) titanProbeStep {
	url := strings.TrimRight(host, "/") + aeolusSessionProbePath
	step := titanProbeStep{Status: "failed", RequestURL: url, TestedAt: time.Now().UTC().Format(time.RFC3339)}
	resp, raw, err := titanRequest(ctx, http.MethodGet, url, titanToken, nil)
	if err != nil {
		step.ErrorType = "network_error"
		step.ErrorMessage = sanitizeLogText(err.Error())
		return step
	}
	step.HTTPStatus = resp.StatusCode
	step.ResponseContentType = resp.Header.Get("Content-Type")
	step.RequestID = resp.Header.Get("x-request-id")
	step.LogID = resp.Header.Get("x-tt-logid")
	step.ResponsePreview = sanitizeLogText(truncateForLog(string(raw), 300))
	step.ForbiddenDetected = strings.Contains(string(raw), "aeolus/user/forbidden")
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		step.ErrorType = "http_error"
		step.ErrorMessage = fmt.Sprintf("session probe returned HTTP %d", resp.StatusCode)
		return step
	}
	if step.ForbiddenDetected {
		step.ErrorType = "aeolus_user_forbidden"
		step.ErrorMessage = "session probe returned aeolus/user/forbidden"
		return step
	}
	step.Status = "passed"
	return step
}

func probeToSimpleChart(ctx context.Context, host, titanToken string, reportID int) (map[string]any, titanProbeStep) {
	url := strings.TrimRight(host, "/") + aeolusGlueToSimplePath
	step := titanProbeStep{Status: "failed", RequestURL: url, ReportID: reportID, TestedAt: time.Now().UTC().Format(time.RFC3339)}
	resp, raw, err := titanRequest(ctx, http.MethodPost, url, titanToken, map[string]any{"reportId": reportID, "skillName": "tap-aeolus-adapter", "cliCommand": "contract-discovery"})
	if err != nil {
		step.ErrorType = "network_error"
		step.ErrorMessage = sanitizeLogText(err.Error())
		return nil, step
	}
	if resp == nil {
		step.ErrorType = "network_error"
		step.ErrorMessage = "to_simple_chart returned no HTTP response"
		return nil, step
	}
	step.HTTPStatus = resp.StatusCode
	step.ResponseContentType = resp.Header.Get("Content-Type")
	step.RequestID = resp.Header.Get("x-request-id")
	step.LogID = resp.Header.Get("x-tt-logid")
	step.ResponsePreview = sanitizeLogText(truncateForLog(string(raw), 300))
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		step.ErrorType = "http_error"
		step.ErrorMessage = fmt.Sprintf("to_simple_chart returned HTTP %d", resp.StatusCode)
		return nil, step
	}
	var parsed map[string]any
	if err := json.Unmarshal(raw, &parsed); err != nil {
		step.ErrorType = "non_json_response"
		step.ErrorMessage = "to_simple_chart returned non-JSON response"
		return nil, step
	}
	data, ok := parsed["data"].(map[string]any)
	if !ok || data == nil {
		step.ErrorType = "missing_simple_chart"
		step.ErrorMessage = "response missing data.simpleChart"
		return nil, step
	}
	chart, _ := data["simpleChart"].(map[string]any)
	if chart == nil {
		step.ErrorType = "missing_simple_chart"
		step.ErrorMessage = "response missing data.simpleChart"
		return nil, step
	}
	step.Status = "passed"
	step.SimpleChartObtained = true
	step.ResponsePreview = ""
	return chart, step
}

func resolveSavedReportChart(ctx context.Context, host, titanToken string, reportID int) (map[string]any, titanProbeStep, *titanProbeStep, string) {
	chart, primary := probeToSimpleChart(ctx, host, titanToken, reportID)
	if primary.Status == "passed" {
		return chart, primary, nil, "to_simple_chart"
	}
	if !isSavedReportFallbackEligible(primary) {
		return nil, primary, nil, ""
	}
	fallbackChart, fallback := probeSavedReportChart(ctx, host, titanToken, reportID)
	if fallback.Status != "passed" {
		return nil, primary, &fallback, ""
	}
	return fallbackChart, primary, &fallback, "saved_report_metadata"
}

func isSavedReportFallbackEligible(step titanProbeStep) bool {
	if step.ErrorType == "network_error" || step.ErrorType == "missing_simple_chart" {
		return true
	}
	return step.ErrorType == "http_error" && step.HTTPStatus >= 500
}

// probeSavedReportChart reads the existing saved report only. It never writes
// report metadata or SQL. Supplying all commonly accepted ID aliases keeps the
// call compatible across Aeolus regions while the server ignores extras.
func probeSavedReportChart(ctx context.Context, host, titanToken string, reportID int) (map[string]any, titanProbeStep) {
	endpoint, _ := url.Parse(strings.TrimRight(host, "/") + aeolusSavedReportPath)
	query := endpoint.Query()
	id := strconv.Itoa(reportID)
	query.Set("id", id)
	query.Set("rid", id)
	query.Set("reportId", id)
	endpoint.RawQuery = query.Encode()
	step := titanProbeStep{Status: "failed", RequestURL: endpoint.String(), ReportID: reportID, TestedAt: time.Now().UTC().Format(time.RFC3339)}
	resp, raw, err := titanRequest(ctx, http.MethodGet, endpoint.String(), titanToken, nil)
	if err != nil {
		step.ErrorType = "network_error"
		step.ErrorMessage = sanitizeLogText(err.Error())
		return nil, step
	}
	step.HTTPStatus = resp.StatusCode
	step.ResponseContentType = resp.Header.Get("Content-Type")
	step.RequestID = resp.Header.Get("x-request-id")
	step.LogID = resp.Header.Get("x-tt-logid")
	step.ResponsePreview = sanitizeLogText(truncateForLog(string(raw), 300))
	if resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden {
		step.ErrorType = "permission_denied"
		step.ErrorMessage = fmt.Sprintf("saved report metadata returned HTTP %d", resp.StatusCode)
		return nil, step
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		step.ErrorType = "http_error"
		step.ErrorMessage = fmt.Sprintf("saved report metadata returned HTTP %d", resp.StatusCode)
		return nil, step
	}
	var parsed any
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	if err := decoder.Decode(&parsed); err != nil {
		step.ErrorType = "non_json_response"
		step.ErrorMessage = "saved report metadata returned non-JSON response"
		return nil, step
	}
	chart := findSavedReportChart(parsed)
	if chart == nil {
		step.ErrorType = "missing_chart_schema"
		step.ErrorMessage = "saved report metadata missing reqJson/chart schema"
		return nil, step
	}
	step.Status = "passed"
	step.SimpleChartObtained = true
	step.ResponsePreview = ""
	return chart, step
}

func findSavedReportChart(value any) map[string]any {
	var walk func(any) map[string]any
	walk = func(current any) map[string]any {
		switch node := current.(type) {
		case string:
			trimmed := strings.TrimSpace(node)
			if !strings.HasPrefix(trimmed, "{") && !strings.HasPrefix(trimmed, "[") {
				return nil
			}
			var decoded any
			decoder := json.NewDecoder(strings.NewReader(trimmed))
			decoder.UseNumber()
			if decoder.Decode(&decoded) == nil {
				return walk(decoded)
			}
		case map[string]any:
			for _, key := range []string{"simpleChart", "chart", "chartSchema", "schema", "reqJson", "requestJson"} {
				if child, ok := node[key]; ok {
					if found := walk(child); found != nil {
						return found
					}
				}
			}
			if savedReportChartShape(node) {
				return node
			}
			for _, child := range node {
				if found := walk(child); found != nil {
					return found
				}
			}
		case []any:
			for _, child := range node {
				if found := walk(child); found != nil {
					return found
				}
			}
		}
		return nil
	}
	return walk(value)
}

func savedReportChartShape(chart map[string]any) bool {
	_, hasDataset := chart["datasetId"]
	if !hasDataset {
		_, hasDataset = chart["dataSetId"]
	}
	_, hasDimensions := chart["dimensions"]
	_, hasMeasures := chart["measures"]
	if !hasMeasures {
		_, hasMeasures = chart["leftMeasures"]
	}
	return hasDataset && (hasDimensions || hasMeasures)
}

func probeQueryChart(ctx context.Context, host, titanToken string, reportID int, chart map[string]any) titanProbeStep {
	url := strings.TrimRight(host, "/") + aeolusGlueQueryChartPath
	step := titanProbeStep{Status: "failed", RequestURL: url, ReportID: reportID, TestedAt: time.Now().UTC().Format(time.RFC3339)}
	payload := map[string]any{
		"chartId":          reportID,
		"chart":            chart,
		"effectiveFilters": chart["filters"],
		"filterApplyMode":  "replace",
		"skillName":        "tap-aeolus-adapter",
		"cliCommand":       "query",
	}
	resp, raw, err := titanRequest(ctx, http.MethodPost, url, titanToken, payload)
	if err != nil {
		step.ErrorType = "network_error"
		step.ErrorMessage = sanitizeLogText(err.Error())
		return step
	}
	step.HTTPStatus = resp.StatusCode
	step.ResponseContentType = resp.Header.Get("Content-Type")
	step.RequestID = resp.Header.Get("x-request-id")
	step.LogID = resp.Header.Get("x-tt-logid")
	step.ResponsePreview = sanitizeLogText(truncateForLog(string(raw), 300))
	var parsed any
	if err := json.Unmarshal(raw, &parsed); err != nil {
		step.ErrorType = "non_json_response"
		step.ErrorMessage = "query_chart returned non-JSON response"
		return step
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		step.ErrorType = "http_error"
		step.ErrorMessage = fmt.Sprintf("query_chart returned HTTP %d", resp.StatusCode)
		return step
	}
	if envelope, ok := parsed.(map[string]any); ok {
		step.GlueCode = envelope["code"]
		step.GlueSuccess = envelope["success"]
		step.GlueMessage = asString(envelope["msg"])
		if step.GlueMessage == "" {
			step.GlueMessage = asString(envelope["error"])
		}
		if success, exists := envelope["success"]; exists {
			passed, valid := success.(bool)
			if !valid || !passed {
				step.ErrorType = "glue_business_error"
				step.ErrorMessage = "query_chart success flag is not true"
				return step
			}
		}
		if code, exists := envelope["code"]; exists {
			text := strings.TrimSpace(asString(code))
			if text != "" && text != "0" && !strings.EqualFold(text, "success") {
				step.ErrorType = "glue_business_error"
				step.ErrorMessage = "query_chart returned non-success code: " + text
				return step
			}
		}
	}
	rows := findRows(parsed)
	step.FieldMap = findQueryColumnMap(parsed)
	if rows == nil {
		step.ErrorType = "rows_not_found"
		step.ErrorMessage = "query_chart response does not expose rows in a recognized shape"
		return step
	}
	step.RowsCount = len(rows)
	step.Rows = rows
	if len(rows) == 0 {
		step.Status = "no_fact_row"
		return step
	}
	step.SampleRows = rows[0]
	for _, row := range rows {
		for key := range row {
			step.Columns = append(step.Columns, key)
		}
		break
	}
	step.Status = "passed"
	step.ResponsePreview = ""
	return step
}

func buildContractFreeze(reportID int, datasetID int, chart map[string]any, fetchedAt string) map[string]any {
	canonical, _ := json.Marshal(chart)
	sum := sha256.Sum256(canonical)
	return map[string]any{
		"reportId":        reportID,
		"datasetId":       datasetID,
		"contractHash":    hex.EncodeToString(sum[:]),
		"fetchedAt":       fetchedAt,
		"dimensionsCount": firstArrayLength(chart, "dimensions", "dimensionList", "dims"),
		"measuresCount":   firstArrayLength(chart, "metrics", "measures", "measureList", "leftMeasures", "rightMeasures"),
		"filtersCount":    firstArrayLength(chart, "filters", "whereList"),
	}
}

func findQueryColumnMap(value any) map[string]string {
	fieldMap := map[string]string{}
	var walk func(any)
	walk = func(current any) {
		switch node := current.(type) {
		case map[string]any:
			id := firstNonEmpty(node, "uniqueId", "uniqueID")
			label := firstNonEmpty(node, "label", "displayName", "datasetFieldName", "name")
			if id != "" && label != "" {
				encoded, _ := json.Marshal(node)
				fieldMap[id] = strings.ToLower(string(encoded))
			}
			for _, child := range node {
				walk(child)
			}
		case []any:
			for _, child := range node {
				walk(child)
			}
		}
	}
	walk(value)
	return fieldMap
}

func contractIDString(value any) string {
	switch typed := value.(type) {
	case float64:
		return strconv.FormatFloat(typed, 'f', -1, 64)
	case json.Number:
		return typed.String()
	default:
		return strings.TrimSpace(asString(value))
	}
}

func buildContractFieldMap(chart map[string]any, columns []string) map[string]string {

	wanted := map[string]bool{}

	for _, column := range columns {
		wanted[column] = true
	}

	fieldMap := map[string]string{}

	var walk func(any)

	walk = func(value any) {

		switch node := value.(type) {

		case map[string]any:

			for _, idKey := range []string{"uniqueId", "uniqueID", "uniqueid", "dimMetId", "dimMetID"} {

				id := contractIDString(node[idKey])

				if wanted[id] {

					encoded, _ := json.Marshal(node)

					fieldMap[id] = strings.ToLower(string(encoded))

				}

			}

			for _, child := range node {
				walk(child)
			}

		case []any:

			for _, child := range node {
				walk(child)
			}

		}

	}

	walk(chart)

	return fieldMap

}

func mapSavedReportRows(source string, rows []map[string]any, fieldMap map[string]string) []map[string]any {

	aliases := map[string]map[string][]string{

		"submission": {

			"create_date": {"create_time", "create date", "created_at", "创建时间", "提报时间", "p_date"},

			"final_result": {"final_result", "final result", "最终结果", "审核结果"},

			"ticket_count": {"ticket_id", "ticket count", "工单", "countdistinct"},
		},

		"tap_account": {

			"p_date": {"p_date", "date", "日期"},

			"client_tier": {"tier_v3_name", "tier v3", "client tier"},

			"account_count": {"account_id", "account count", "账户", "countdistinct"},
		},

		"revenue": {"revenue": {"revenue", "spend", "消耗", "收入", "sum"}},

		"p0_risk": {

			"p_date": {"p_date", "date", "日期"},

			"metric": {"metric", "指标", "ccr", "nfs"},

			"value": {"value", "指标值", "rate", "ratio", "sum"},
		},

		"approval": {

			"p_date": {"p_date", "date", "日期"},

			"approval_rate": {"approval_rate", "approval rate", "通过率", "approval"},

			"dimension": {"dimension", "维度", "tier", "region"},
		},
	}

	mapped := make([]map[string]any, 0, len(rows))

	for _, row := range rows {

		out := map[string]any{}

		for semantic, keywords := range aliases[source] {

			bestKey, bestScore := "", 0

			for key := range row {

				descriptor := fieldMap[key]

				score := 0

				for _, keyword := range keywords {
					if strings.Contains(descriptor, strings.ToLower(keyword)) {
						score++
					}
				}

				if score > bestScore {
					bestKey, bestScore = key, score
				}

			}

			if bestKey != "" {
				out[semantic] = row[bestKey]
			}

		}

		out = fillAggregateSemanticFallback(source, row, out)

		out["_raw"] = row

		mapped = append(mapped, out)

	}

	return mapped

}

var aggregateDatePattern = regexp.MustCompile(`^\d{4}-(?:\d{2}-\d{2}|W\d{2})`)

func fillAggregateSemanticFallback(source string, raw, mapped map[string]any) map[string]any {
	dateValue, labelValue := "", ""
	numbers := []float64{}
	numberValues := []any{}
	for _, value := range raw {
		text := asString(value)
		if aggregateDatePattern.MatchString(text) {
			dateValue = text
			continue
		}
		if _, ok := number(value); ok {
			n, _ := number(value)
			numbers = append(numbers, n)
			numberValues = append(numberValues, value)
			continue
		}
		if text != "" {
			labelValue = text
		}
	}
	switch source {
	case "submission":
		if asString(mapped["create_date"]) == "" || !aggregateDatePattern.MatchString(asString(mapped["create_date"])) {
			mapped["create_date"] = dateValue
		}
		if asString(mapped["final_result"]) == "" {
			mapped["final_result"] = labelValue
		}
		if _, ok := number(mapped["ticket_count"]); !ok && len(numberValues) == 1 {
			mapped["ticket_count"] = numberValues[0]
		}
	case "tap_account":
		if !aggregateDatePattern.MatchString(asString(mapped["p_date"])) {
			mapped["p_date"] = dateValue
		}
		// Saved-report output aliases are unstable; values are structurally unambiguous:
		// one date, one tier label and one distinct account count.
		mapped["client_tier"] = labelValue
		if len(numberValues) == 1 {
			mapped["account_count"] = numberValues[0]
		}
		if value, ok := number(mapped["account_count"]); ok && value > 10000000 {
			// Guard against a misconfigured sum(account_id) masquerading as account count.
			mapped["account_count"] = nil
		}
	case "p0_risk":
		if !aggregateDatePattern.MatchString(asString(mapped["p_date"])) {
			mapped["p_date"] = dateValue
		}
		for index, value := range numbers {
			if value >= 0 && value <= 1 {
				mapped["metric"] = "P0 CCR"
				mapped["value"] = numberValues[index]
				mapped["p0_ccr"] = numberValues[index]
				break
			}
		}
		for index, value := range numbers {
			if value > 1 {
				mapped["p0_nfs"] = numberValues[index]
				break
			}
		}
	case "approval":
		if !aggregateDatePattern.MatchString(asString(mapped["p_date"])) {
			mapped["p_date"] = dateValue
		}
		best := -1.0
		var bestValue any
		for index, value := range numbers {
			if value >= 0 && value <= 1 && value > best {
				best, bestValue = value, numberValues[index]
			}
		}
		if bestValue != nil {
			mapped["approval_rate"] = bestValue
		} else {
			mapped["approval_rate"] = nil
		}
	}
	return mapped
}

func hasMappedBusinessValue(rows []map[string]any, fields map[string]fieldConfig) bool {
	for _, row := range rows {
		for semantic := range fields {
			if value, exists := row[semantic]; exists && strings.TrimSpace(asString(value)) != "" {
				return true
			}
		}
	}
	return false
}

func canonicalizeSavedReportDetails(rows []map[string]any, fields map[string]fieldConfig, fieldMap map[string]string) []map[string]any {
	out := make([]map[string]any, 0, len(rows))
	for _, raw := range rows {
		mapped := map[string]any{}
		for column, value := range raw {
			if strings.EqualFold(strings.TrimSpace(asString(value)), "NULL") {
				continue
			}
			descriptor := strings.ToLower(strings.Join([]string{column, fieldMap[column]}, " "))
			for semantic, spec := range fields {
				aliases := []string{semantic, spec.SourceName, spec.DimMetID, spec.UniqueID}
				matched := false
				for _, alias := range aliases {
					alias = strings.TrimSpace(strings.ToLower(alias))
					if alias != "" && strings.Contains(descriptor, alias) {
						mapped[semantic] = value
						matched = true
						break
					}
				}
				if matched {
					break
				}
			}
		}
		// Saved report exports may expose aliases as direct keys even when the
		// chart metadata omits the field descriptor.
		for semantic, spec := range fields {
			if _, exists := mapped[semantic]; exists {
				continue
			}
			for _, candidate := range []string{semantic, spec.SourceName, spec.DimMetID} {
				for key, value := range raw {
					if candidate != "" && strings.EqualFold(strings.TrimSpace(key), strings.TrimSpace(candidate)) {
						mapped[semantic] = value
					}
				}
			}
		}
		out = append(out, normalizeDetailRow(mapped))
	}
	return out
}

func buildDetailSavedReportChart(original map[string]any, source sourceConfig, fields map[string]fieldConfig) map[string]any {
	chart := cloneMap(original)
	dimensions := []any{}
	existingFieldIDs := map[string]bool{}
	if originalDimensions, ok := chart["dimensions"].([]any); ok {
		dimensions = append(dimensions, originalDimensions...)
		for _, raw := range originalDimensions {
			if dimension, ok := raw.(map[string]any); ok {
				existingFieldIDs[asString(dimension["datasetFieldId"])] = true
			}
		}
	}
	// One-time detail queries may add only fields whose IDs were verified from the
	// runtime dataset metadata. This changes the submitted temporary chart only;
	// the saved Aeolus report is never modified.
	for _, name := range source.QueryProfile.GroupBy {
		spec, ok := fields[name]
		if !ok || strings.TrimSpace(spec.DimMetID) == "" || existingFieldIDs[strings.TrimSpace(spec.DimMetID)] {
			continue
		}
		fieldType := "dimensionString"
		if name == "create_date" || name == "p_date" {
			fieldType = "dimensionDate"
		}
		uniqueID := strings.TrimSpace(spec.UniqueID)
		if uniqueID == "" {
			uniqueID = strings.TrimSpace(spec.DimMetID)
		}
		dimension := map[string]any{"datasetFieldId": spec.DimMetID, "uniqueId": uniqueID, "name": name, "type": fieldType}
		if fieldType == "dimensionDate" {
			dimension["dateAggr"] = map[string]any{"format": "auto", "type": "day"}
		}
		dimensions = append(dimensions, dimension)
	}
	measures := []any{}
	for _, name := range source.QueryProfile.Metrics {
		spec, ok := fields[name]
		if !ok || strings.TrimSpace(spec.DimMetID) == "" {
			continue
		}
		measures = append(measures, map[string]any{"datasetFieldId": spec.DimMetID, "uniqueId": spec.DimMetID, "type": "measure", "aggr": "sum"})
	}
	if len(measures) == 0 {
		if originalMeasures, ok := chart["measures"].([]any); ok {
			measures = originalMeasures
		} else if originalMeasures, ok := chart["leftMeasures"].([]any); ok {
			measures = originalMeasures
		}
	}
	filters := []any{}
	if originalFilters, ok := chart["filters"].([]any); ok {
		// Preserve verified saved-report predicates. chartWithBusinessFilters
		// replaces them when the runtime contract can safely do so; ET relies on
		// report-specific filter capsule uniqueIds that must not be discarded.
		filters = append(filters, originalFilters...)
	}
	chart["dimensions"] = dimensions
	if _, ok := chart["measures"]; ok {
		chart["measures"] = measures
	} else {
		chart["leftMeasures"] = measures
		chart["rightMeasures"] = []any{}
	}
	chart["filters"] = filters
	// Detail sources are business inputs, not UI previews. Saved table reports often
	// carry dataLimit=50, which silently truncates membership lists. Override the
	// temporary query only; the saved Aeolus report remains unchanged. The query
	// layer treats an exact hard-limit response as incomplete and shards or blocks
	// rather than claiming a partial list is complete.
	tableConfig, _ := chart["tableConfig"].(map[string]any)
	if tableConfig == nil {
		tableConfig = map[string]any{}
	}
	tableConfig["dataLimit"] = savedReportHardLimit
	chart["tableConfig"] = tableConfig
	delete(chart, "metricsThemeId")
	return chart
}

func cloneMap(in map[string]any) map[string]any {
	b, _ := json.Marshal(in)
	out := map[string]any{}
	_ = json.Unmarshal(b, &out)
	return out
}
