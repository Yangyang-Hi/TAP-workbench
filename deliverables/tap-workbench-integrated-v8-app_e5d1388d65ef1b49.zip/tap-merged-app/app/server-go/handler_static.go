package main

import (
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

func staticHandler(w http.ResponseWriter, r *http.Request) {
	if strings.HasPrefix(r.URL.Path, "/api/") {
		writeJSON(w, http.StatusNotFound, map[string]any{"error": "Not Found"})
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/")
	// Preview and Canvas gateways can preserve their /proxy/<port>/ prefix when
	// forwarding asset requests. Resolve the public assets suffix so module and
	// stylesheet requests receive the actual file instead of the SPA fallback.
	if marker := strings.Index(path, "assets/"); marker >= 0 {
		path = path[marker:]
	}
	if path != "" {
		candidate := filepath.Join(staticDir, filepath.Clean(path))
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			if strings.HasPrefix(path, "assets/") {
				w.Header().Set("Cache-Control", "public, max-age=604800, immutable")
			}
			http.ServeFile(w, r, candidate)
			return
		}
	}
	index := filepath.Join(staticDir, "index.html")
	q := r.URL.Query()
	rootRequest := r.URL.Path == "/"
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	if len(parts) == 2 && parts[0] == "proxy" {
		if port, e := strconv.Atoi(parts[1]); e == nil && port > 0 && port <= 65535 {
			rootRequest = true
		}
	}
	overviewRequested := rootRequest && (q.Get("tab") == "data-overview" || q.Get("view") == "overview" || (q.Get("tab") == "" && q.Get("view") == "" && q.Get("alert_id") == ""))
	if overviewRequested {
		candidate := filepath.Join(staticDir, "overview.html")
		if _, err := os.Stat(candidate); err == nil {
			index = candidate
		}
	}

	if _, err := os.Stat(index); err == nil {
		w.Header().Set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
		w.Header().Set("Pragma", "no-cache")
		w.Header().Set("Expires", "0")
		// Original native SDK/assets stay verbatim. This server-side return link
		// lives outside React's root and never changes task/report handling pages.
		if filepath.Base(index) == "index.html" && rootRequest && q.Get("view") != "tasks" {
			if raw, err := os.ReadFile(index); err == nil {
				link := `<div id="tap-overview-return" style="padding:8px 24px;border-bottom:1px solid #e5eaf0;font:13px sans-serif"><a href="?tab=data-overview" style="color:#3766ba;text-decoration:none">← 数据总览 / Overview</a></div>`
				w.Header().Set("Content-Type", "text/html; charset=utf-8")
				_, _ = w.Write([]byte(strings.Replace(string(raw), "<body>", "<body>"+link, 1)))
				return
			}
		}
		http.ServeFile(w, r, index)
		return
	}
	http.Error(w, "Not Found - Run \"pnpm run build\" in app/frontend to generate frontend assets.", http.StatusNotFound)
}
