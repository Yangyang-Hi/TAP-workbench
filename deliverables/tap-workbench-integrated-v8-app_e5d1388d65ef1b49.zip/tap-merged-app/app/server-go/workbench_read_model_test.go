package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"
)

func TestComparisonContractStatuses(t *testing.T) {
	now := time.Date(2026, 10, 21, 12, 0, 0, 0, cwLocation())
	pre, post := 0.0, 5.0
	zero := wbComparisonResult("ET", "2026-10-01", &pre, &post, now)
	if zero.Status != "baseline_zero" || zero.CCRGrowthPct != nil {
		t.Fatalf("pre=0 must not produce growth: %+v", zero)
	}
	missing := wbComparisonResult("THT", "2026-10-01", nil, &post, now)
	if missing.Status != "unavailable" || missing.MissingReason != "pre_ccr_missing" {
		t.Fatalf("missing reason lost: %+v", missing)
	}
	incomplete := wbComparisonResult("ET", "2026-10-20", &post, &post, now)
	if incomplete.Status != "window_incomplete" || incomplete.CCRGrowthPct != nil || incomplete.IncreaseFact.Reason != "Post 观察窗口尚未结束" {
		t.Fatalf("incomplete window computed or reason drifted: %+v", incomplete)
	}
	st := wbComparisonResult("ST", "2026-10-01", &post, &post, now)
	if st.Status != "unavailable" || st.MissingReason != "st_q3_end_date_business_definition_unconfirmed" || st.QoQGrowthPct != nil {
		t.Fatalf("ST unconfirmed business window must stay unavailable: %+v", st)
	}
	pre, post = 2, 3
	valid := wbComparisonResult("ET", "2026-10-01", &pre, &post, now)
	if valid.Status != "available" || valid.CCRGrowthPct == nil || *valid.CCRGrowthPct != 50 || valid.WoWGrowthPct != nil {
		t.Fatalf("growth formula mismatch: %+v", valid)
	}
}

func putReadModelCase(t *testing.T, item cwCase) {
	t.Helper()
	db, err := cwDB()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	raw, _ := json.Marshal(item)
	if _, err = db.Exec("INSERT INTO tap_cases(id,version,body) VALUES(?,?,?)", item.ID, item.Version, string(raw)); err != nil {
		t.Fatal(err)
	}
}

func readModelFixture(t *testing.T, count int) wbJob {
	t.Helper()
	wbTestEnv(t)
	job := wbJob{ID: "scan-week", BatchID: "TAP-WEEK-2026-10-12-2026-10-18", AsOf: "2026-10-19T01:00:00Z", RuleVersion: "rule-v1", Principal: wbSchedulerPrincipal, Status: "ready", Complete: true, Request: wbRequest{Program: "ET", Start: "2026-10-12", End: "2026-10-18"}}
	for i := 0; i < count; i++ {
		ccr := float64(100 - i)
		job.Rows = append(job.Rows, wbRow{ID: fmt.Sprintf("row-%02d", i), Program: "ET", Member: wbMember{AccountID: fmt.Sprintf("70000000000000000%02d", i), Name: fmt.Sprintf("Client %02d", i), Submitter: "Alice", Region: "APAC", Tier: "ET", Start: "2026-09-01"}, CCR: &ccr, NFS: f64(350), Level: "critical", Reasons: []string{"absolute"}})
	}
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	return job
}

func TestBatchesAndCustomReadAreRealAndSideEffectFree(t *testing.T) {
	wbTestEnv(t)
	r := httptest.NewRecorder()
	wbBatchesHandler(r, wbReq("reader"))
	if r.Code != 200 || !strings.Contains(r.Body.String(), `"status":"empty"`) || !strings.Contains(r.Body.String(), `"batches":[]`) {
		t.Fatal(r.Body.String())
	}
	job := readModelFixture(t, 1)
	path, _ := wbStatePath()
	before, _ := os.ReadFile(path)

	oldMembers, oldET, oldEvidence := wbLoadMembers, wbQueryETBatch, wbQueryPairEvidence
	defer func() { wbLoadMembers, wbQueryETBatch, wbQueryPairEvidence = oldMembers, oldET, oldEvidence }()
	wbLoadMembers = func(_ context.Context, _ *http.Request, q wbRequest, _ wbConfig) ([]wbMember, bool, error) {
		if q.Start != "2026-10-01" || q.End != "2026-10-07" || q.MemberEnd != q.End {
			t.Fatalf("custom dates not propagated: %+v", q)
		}
		return []wbMember{{AccountID: "7000000000000000001", Name: "Custom Client", Region: "APAC", Tier: "ET", Start: "2026-09-01"}}, true, nil
	}
	wbQueryETBatch = func(_ context.Context, _ *http.Request, ids []string, start, end string) (map[string]wbBatchMetric, error) {
		if len(ids) != 1 || start != "2026-10-01" || end != "2026-10-07" {
			t.Fatalf("wrong metric window: %v %s %s", ids, start, end)
		}
		return map[string]wbBatchMetric{ids[0]: {Status: "success", CCR: f64(50), NFS: f64(400), RevenueStatus: "no_data"}}, nil
	}
	wbQueryPairEvidence = func(context.Context, *http.Request, []wbMember, wbRequest, wbRule) (map[string][]wbAdvertiserEvidence, error) {
		return map[string][]wbAdvertiserEvidence{}, nil
	}

	custom := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=custom&program=ET&start_date=2026-10-01&end_date=2026-10-07", nil).WithContext(wbReq("reader").Context())
	out := httptest.NewRecorder()
	wbReadModelHandler(out, custom)
	after, _ := os.ReadFile(path)
	if out.Code != 200 || !strings.Contains(out.Body.String(), `"status":"available"`) || !strings.Contains(out.Body.String(), `"risk_customers":{"value":1`) || !strings.Contains(out.Body.String(), `"status":"not_applicable"`) || string(before) != string(after) {
		t.Fatalf("custom read mutated weekly state or returned wrong result: %s", out.Body.String())
	}
	b := httptest.NewRecorder()
	wbBatchesHandler(b, wbReq("reader"))
	if !strings.Contains(b.Body.String(), job.BatchID) || !strings.Contains(b.Body.String(), "2026-W42") {
		t.Fatal(b.Body.String())
	}
}

func TestWeeklyCardsUseFullSetAndSuccessfulNotificationDedupe(t *testing.T) {
	job := readModelFixture(t, 3)
	for i, row := range job.Rows {
		item := cwCase{ID: fmt.Sprintf("case-%d", i), Version: 1, Status: "open", ScanID: job.ID, Row: row, Window: job.Request, Fields: map[string]string{}}
		putReadModelCase(t, item)
	}
	db, _ := cwDB()
	now := cwNow()
	// Duplicate successes count once; failed and queued records never count as handled.
	for _, values := range [][4]string{{"sent-1", "case-1", "sent", "om1"}, {"sent-2", "case-1", "sent", "om2"}, {"failed", "case-2", "failed", ""}, {"queued", "case-2", "pending", ""}} {
		_, err := db.Exec("INSERT INTO tap_outbox(id,case_id,recipient,kind,status,message_id,created_at,updated_at) VALUES(?,?,?,'send',?,?,?,?)", values[0], values[1], "open_id:ou_fixture", values[2], values[3], now, now)
		if err != nil {
			t.Fatal(err)
		}
	}
	db.Close()
	req := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly&page=1&page_size=1", nil).WithContext(wbReq("reader").Context())
	rr := httptest.NewRecorder()
	wbReadModelHandler(rr, req)
	var body struct {
		Data struct {
			Cards      map[string]wbCardValue `json:"cards"`
			Rows       []wbReadRow            `json:"rows"`
			Pagination map[string]int         `json:"pagination"`
		} `json:"data"`
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	if rr.Code != 200 || len(body.Data.Rows) != 1 || body.Data.Pagination["total"] != 3 || *body.Data.Cards["queried_customers"].Value != 3 || *body.Data.Cards["handled"].Value != 1 || *body.Data.Cards["pending"].Value != 2 || body.Data.Cards["auto_alerted"].Value != nil {
		t.Fatalf("cards/pagination mismatch: %s", rr.Body.String())
	}
}

func TestOnlyMineRequiresUniqueVerifiedIdentityMapping(t *testing.T) {
	job := readModelFixture(t, 1)
	req := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly&only_mine=true", nil).WithContext(wbReq("alice").Context())
	blocked := httptest.NewRecorder()
	wbReadModelHandler(blocked, req)
	if blocked.Code != 422 {
		t.Fatalf("unmapped identity accepted: %s", blocked.Body.String())
	}
	db, _ := cwDB()
	_, err := db.Exec(`INSERT INTO tap_identity_mappings(record_id,business_name,email,aeolus_name,match_status,enabled,manual_disabled) VALUES('mine','Alice','alice@example.com','Alice Aeolus','已确认',1,0)`)
	db.Close()
	if err != nil {
		t.Fatal(err)
	}
	db, _ = cwDB()
	aliases, reason := wbReadIdentity(db, "alice")
	db.Close()
	if reason != "" || len(aliases) == 0 || !wbRowMatches(job.Rows[0], nil, map[string]string{"only_mine": "true"}, aliases, nil) {
		t.Fatalf("verified identity matching failed aliases=%#v reason=%s", aliases, reason)
	}
	reassigned := job.Rows[0]
	reassigned.Member.Submitter = "Other"
	if !wbRowMatches(reassigned, nil, map[string]string{"only_mine": "true"}, aliases, []cwNotice{{Kind: "send", TargetEmail: "alice@example.com"}}) {
		t.Fatal("actual verified recipient cannot find reassigned event")
	}
	ok := httptest.NewRecorder()
	wbReadModelHandler(ok, req)
	if ok.Code != 200 || !strings.Contains(ok.Body.String(), "700000000000000000") {
		t.Fatalf("verified mapping failed: %s", ok.Body.String())
	}
}

func TestGrowthTop20RanksFullSetBeforePagination(t *testing.T) {
	rows := make([]wbReadRow, 25)
	for i := range rows {
		value := float64(i + 1)
		rows[i] = wbReadRow{RowID: fmt.Sprint(i), Program: "ET", Tier: "ET", Region: "APAC", Comparison: wbComparison{Status: "available", CCRGrowthPct: &value}}
	}
	negative := -1.0
	rows = append(rows, wbReadRow{RowID: "negative", Tier: "ET", Region: "APAC", Comparison: wbComparison{Status: "available", CCRGrowthPct: &negative}})
	top := wbGrowthTop20(rows)[wbGrowthGroupKey("ET", "ET", "APAC")]
	if len(top) != 20 || *top[0].Comparison.CCRGrowthPct != 25 || *top[19].Comparison.CCRGrowthPct != 6 {
		t.Fatalf("full-set Top20 mismatch: %+v", top)
	}
}

func TestHistoricalRowsRemainCompatible(t *testing.T) {
	var old wbRow
	if err := json.Unmarshal([]byte(`{"id":"legacy","program":"ET","member":{"account_id":"7000000000000000001","protection_starttime":""},"ccr":12,"nfs":3,"level":"critical","reasons":["legacy"]}`), &old); err != nil {
		t.Fatal(err)
	}
	view := wbToReadRow(wbJob{ID: "old"}, old, nil, nil, time.Now())
	if view.RowID != "legacy" || view.Comparison.Status != "unavailable" || view.Comparison.MissingReason == "" {
		t.Fatalf("legacy row broken: %+v", view)
	}
}

func TestHistoricalTHTRevenueWithoutPersistedStatusIsUnknown(t *testing.T) {
	ccr, nfs := 12.0, 3.0
	legacy := wbRow{
		ID:      "legacy-tht",
		Program: "THT",
		Member:  wbMember{AdvertiserID: "7000000000000000001", Start: "2026-09-01"},
		Advertisers: []wbAdvertiserEvidence{{
			AdvertiserID: "7000000000000000001",
			CCR:          &ccr,
			NFS:          &nfs,
		}},
	}
	view := wbToReadRow(wbJob{ID: "old"}, legacy, nil, nil, time.Now())
	if len(view.AdvertiserTop10) != 1 {
		t.Fatalf("legacy advertiser missing: %+v", view)
	}
	advertiser := view.AdvertiserTop10[0]
	if advertiser.RevenueStatus != "unknown" || advertiser.RevenueError != "legacy_scan_revenue_status_not_persisted" {
		t.Fatalf("missing legacy status was misclassified: %+v", advertiser)
	}
	if advertiser.RevenueStatus == "source_error" || strings.Contains(advertiser.RevenueError, "147999") {
		t.Fatalf("legacy status fabricated an upstream error: %+v", advertiser)
	}
}

func TestWeeklyReadModelUsesPersistedFactsWithoutVQSOrWrites(t *testing.T) {
	wbTestEnv(t)
	ccr, nfs := 4.0, 60.0
	job := wbJob{ID: "tht-scan", BatchID: "TAP-WEEK-2026-10-12-2026-10-18", AsOf: "2026-10-21T10:00:00Z", Status: "ready", Complete: true, Request: wbRequest{Program: "THT", Start: "2026-10-12", End: "2026-10-18"}, Rows: []wbRow{
		{ID: "one", Program: "THT", Member: wbMember{AccountID: "same-account", AdvertiserID: "adv-1", Start: "2026-09-01"}, CCR: &ccr, NFS: &nfs},
		{ID: "two", Program: "THT", Member: wbMember{AccountID: "same-account", AdvertiserID: "adv-2", Start: "2026-09-01"}, CCR: &ccr, NFS: &nfs},
	}}
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	path, _ := wbStatePath()
	before, _ := os.ReadFile(path)
	originalQuery := wbQueryTHTBatch
	calls := 0
	wbQueryTHTBatch = func(context.Context, *http.Request, []string, string, string) (map[string][]wbBatchMetric, error) {
		calls++
		return nil, fmt.Errorf("read model must not query VQS")
	}
	defer func() { wbQueryTHTBatch = originalQuery }()

	req := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly", nil).WithContext(wbReq("reader").Context())
	rr := httptest.NewRecorder()
	wbReadModelHandler(rr, req)
	after, _ := os.ReadFile(path)
	var body struct {
		Data struct {
			Funnel      map[string]wbProgramFunnel `json:"funnel"`
			Pagination  map[string]int             `json:"pagination"`
			SideEffects bool                       `json:"side_effects"`
		} `json:"data"`
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	if rr.Code != 200 || calls != 0 || string(before) != string(after) || body.Data.SideEffects {
		t.Fatalf("GET caused query/write side effects: code=%d calls=%d side_effects=%t body=%s", rr.Code, calls, body.Data.SideEffects, rr.Body.String())
	}
	if body.Data.Pagination["total"] != 2 || *body.Data.Funnel["THT"].Watch.Value != 2 || *body.Data.Funnel["THT"].DistinctClients.Value != 2 {
		t.Fatalf("funnel/risk list do not share advertiser-distinct pool: %s", rr.Body.String())
	}
}

func TestReadModelBackfillsLatestPersistedSemanticsWithoutQuery(t *testing.T) {
	legacy := wbRow{Program: "THT", Member: wbMember{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001"}, Advertisers: []wbAdvertiserEvidence{{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001"}}}
	latest := wbJob{AsOf: "2026-10-23T05:00:00Z", Rows: []wbRow{{Advertisers: []wbAdvertiserEvidence{{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001", SemanticsLabel: "content_issues - sensitive_content - unsure_violence -", SemanticsStatus: "available"}}}}}
	index := wbLatestSemanticsEvidence(map[string][]wbJob{"latest": {latest}})
	got := wbBackfillSemantics(legacy, index)
	if len(got.Advertisers) != 1 || got.Advertisers[0].SemanticsLabel != "content_issues - sensitive_content - unsure_violence -" || got.Advertisers[0].SemanticsStatus != "backfilled_available" {
		t.Fatalf("latest persisted semantics not backfilled: %+v", got.Advertisers)
	}
	missing := wbBackfillSemantics(wbRow{Member: legacy.Member, Advertisers: []wbAdvertiserEvidence{{AdvertiserID: "999"}}}, index)
	if missing.Advertisers[0].SemanticsStatus != "legacy_not_captured" {
		t.Fatalf("legacy missing field not distinguished: %+v", missing.Advertisers[0])
	}
}

func TestRiskListDoesNotDereferenceMissingGrowthForDuplicateCustomer(t *testing.T) {
	growth := 50.0
	rows := []wbReadRow{
		{RowID: "same-event", Program: "ET", AccountID: "same", Tier: "ET", Region: "APAC", CCR: f64(4), NFS: f64(60)},
		{RowID: "same-event", Program: "ET", AccountID: "same", Tier: "ET", Region: "APAC", Comparison: wbComparison{Status: "available", CCRGrowthPct: &growth}},
	}
	if got := wbRiskList(rows, "combined"); len(got) == 0 {
		t.Fatal("expected at least one risk row")
	}
}

func TestReadModelHidesHistoricalPrePostRevenue(t *testing.T) {
	pre, post := 100.0, 200.0
	row := wbRow{
		Program: "ET",
		Member:  wbMember{AccountID: "7100000000000000001"},
		Comparison: wbComparison{
			Status: metricAvailable, PreRevenue: &pre, PostRevenue: &post,
			RevenueDelta: f64(100), RevenueGrowthPct: f64(100),
		},
		Advertisers: []wbAdvertiserEvidence{{
			AdvertiserID: "7200000000000000001", CCR: f64(1),
			PreRevenue: &pre, PostRevenue: &post, RevenueDelta: f64(100), RevenueGrowthPct: f64(100),
		}},
	}
	view := wbToReadRow(wbJob{}, row, nil, nil, time.Date(2026, 10, 27, 0, 0, 0, 0, cwLocation()))
	if view.Comparison.PreRevenue != nil || view.Comparison.PostRevenue != nil || view.Comparison.RevenueDelta != nil || view.Comparison.RevenueGrowthPct != nil {
		t.Fatalf("account Pre/Post Revenue leaked into read model: %+v", view.Comparison)
	}
	if len(view.AdvertiserTop10) != 1 || view.AdvertiserTop10[0].PreRevenue != nil || view.AdvertiserTop10[0].PostRevenue != nil || view.AdvertiserTop10[0].RevenueDelta != nil || view.AdvertiserTop10[0].RevenueGrowthPct != nil {
		t.Fatalf("advertiser Pre/Post Revenue leaked into read model: %+v", view.AdvertiserTop10)
	}
}

func TestPersistedBatchesPreferFullerJobOverNewerCheckpoint(t *testing.T) {
	wbTestEnv(t)
	batchID := "TAP-WEEK-2026-10-19-2026-10-25"
	fullRows := make([]wbRow, 2209)
	for i := range fullRows {
		fullRows[i] = wbRow{ID: fmt.Sprintf("full-%04d", i), Program: "ET", Member: wbMember{AccountID: fmt.Sprintf("7%018d", i)}}
	}
	partialRows := append([]wbRow(nil), fullRows[:600]...)
	state := wbDisk{Jobs: map[string]wbJob{
		"full":          {ID: "full", BatchID: batchID, Principal: "operator", StartedAt: "2026-10-27T14:00:00Z", Status: "partial", Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rows: fullRows},
		"newer-partial": {ID: "newer-partial", BatchID: batchID, Principal: wbSchedulerPrincipal, StartedAt: "2026-10-27T17:00:00Z", Status: "partial", Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rows: partialRows},
	}}
	if err := wbWriteDisk(state); err != nil {
		t.Fatal(err)
	}
	_, jobsByBatch, err := wbPersistedBatches()
	if err != nil {
		t.Fatal(err)
	}
	jobs := jobsByBatch[batchID]
	if len(jobs) != 1 || jobs[0].ID != "full" || len(jobs[0].Rows) != 2209 {
		t.Fatalf("newer partial checkpoint replaced fuller batch: %+v", jobs)
	}
}

func persistedETSource(requestID string) map[string]any {
	return map[string]any{
		"source": "et_current_ccr_nfs", "grain": "account_week", "authority": "saved_report", "request_id": requestID,
		"revenue": map[string]any{"source": "account_current_revenue", "grain": "account_week", "authority": "saved_report", "request_id": requestID + "-revenue", "status": "success"},
	}
}

func TestReadModelKeepsAuthoritativeMembershipAndMergesNewerPartialEnrichment(t *testing.T) {
	wbTestEnv(t)
	batchID := "TAP-WEEK-2026-10-19-2026-10-25"
	fullRows := make([]wbRow, 2209)
	for i := range fullRows {
		fullRows[i] = wbRow{ID: fmt.Sprintf("full-%04d", i), Program: "ET", Member: wbMember{AccountID: fmt.Sprintf("7%018d", i), Tier: "ET", Region: "APAC"}}
	}
	pre, post, current := 10.0, 20.0, 99.0
	partialRows := append([]wbRow(nil), fullRows[:1900]...)
	partialRows[0].CCR = &current
	partialRows[0].MetricStatus = "success"
	partialRows[0].Source = persistedETSource("checkpoint")
	partialRows[0].Comparison = wbComparison{Status: metricAvailable, PreRevenue: &pre, PostRevenue: &post}
	state := wbDisk{Jobs: map[string]wbJob{
		"authority":  {ID: "authority", BatchID: batchID, Principal: "operator", StartedAt: "2026-10-27T14:00:00Z", Status: "partial", Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rows: fullRows},
		"checkpoint": {ID: "checkpoint", BatchID: batchID, Principal: wbSchedulerPrincipal, StartedAt: "2026-10-27T17:00:00Z", Status: "running", Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rows: partialRows},
	}, Actions: map[string]wbAction{}}
	if err := wbWriteDisk(state); err != nil {
		t.Fatal(err)
	}

	_, jobsByBatch, err := wbPersistedBatches()
	if err != nil {
		t.Fatal(err)
	}
	jobs := jobsByBatch[batchID]
	if len(jobs) != 1 || wbJobDistinctCustomerCount(jobs[0]) != 2209 || len(jobs[0].Rows) != 2209 {
		t.Fatalf("authoritative membership shrank: jobs=%d rows=%d distinct=%d", len(jobs), len(jobs[0].Rows), wbJobDistinctCustomerCount(jobs[0]))
	}
	mergedByID := map[string]wbRow{}
	for _, row := range jobs[0].Rows {
		mergedByID[row.Member.AccountID] = row
	}
	if got := mergedByID[fullRows[0].Member.AccountID].CCR; got == nil || *got != current {
		t.Fatalf("newer checkpoint enrichment was not merged: %+v", got)
	}
	funnel := wbBuildBatchFunnels(jobs)["ET"]
	if funnel.DistinctClients.Value == nil || *funnel.DistinctClients.Value != 2209 {
		t.Fatalf("funnel lost authoritative membership: %+v", funnel.DistinctClients)
	}

	req := httptest.NewRequest("GET", "/api/workbench/read-model?time_mode=weekly&view=customers&program=ET&batch_id="+batchID+"&page_size=1", nil).WithContext(wbReq("reader").Context())
	rr := httptest.NewRecorder()
	wbReadModelHandler(rr, req)
	if rr.Code != http.StatusOK {
		t.Fatalf("read model status=%d body=%s", rr.Code, rr.Body.String())
	}
	var body struct {
		Data struct {
			Cards      map[string]wbCardValue     `json:"cards"`
			Funnel     map[string]wbProgramFunnel `json:"funnel"`
			Pagination map[string]int             `json:"pagination"`
			Rows       []wbReadRow                `json:"rows"`
		} `json:"data"`
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	if body.Data.Cards["queried_customers"].Value == nil || *body.Data.Cards["queried_customers"].Value != 2209 || body.Data.Pagination["total"] != 2209 || *body.Data.Funnel["ET"].DistinctClients.Value != 2209 {
		t.Fatalf("read-model/list/funnel did not retain full pool: %s", rr.Body.String())
	}
	if len(body.Data.Rows) != 1 || body.Data.Rows[0].Comparison.PreRevenue != nil || body.Data.Rows[0].Comparison.PostRevenue != nil {
		t.Fatalf("Pre/Post Revenue leaked after merge: %+v", body.Data.Rows)
	}
}

func TestMergeProgramJobsKeepsOlderBestFactsByField(t *testing.T) {
	ccr, nfs, revenue, advCCR := 1.25, 0.0, 42.0, 3.5
	accountID, advertiserID := "7000000000000000001", "7100000000000000001"
	older := wbRow{
		ID: "older", Program: "ET",
		Member:          wbMember{AccountID: accountID, Name: "Persisted Account Name", AdvertiserID: advertiserID, Start: "2026-10-08 10:00:00"},
		CCR:             &ccr,
		NFS:             &nfs,
		Revenue:         &revenue,
		MetricStatus:    "success",
		Reasons:         []string{"persisted reason"},
		AllowlistStatus: "Not Allowlisted",
		Comparison: wbComparison{
			Status: metricSourceNull, PreStart: "2026-10-01", PreEndExclusive: "2026-10-08", PostStart: "2026-10-08", PostEndExclusive: "2026-10-15",
			PreCCRFact:  metricFact{Status: metricSourceNull, Reason: "source empty"},
			PostCCRFact: metricFact{Status: metricSourceNull, Reason: "source empty"},
			Source:      map[string]any{"source": "et_current_ccr_nfs", "grain": "account_window", "filters": map[string]any{"account_id": accountID}},
		},
		Advertisers: []wbAdvertiserEvidence{{
			AccountID: accountID, AdvertiserID: advertiserID, AdvertiserName: "Persisted Advertiser",
			CCR: &advCCR, CCRFact: successfulMetricFact(&advCCR), MetricStatus: "success", CurrentSource: advertiserMetricSourceForTest("older-adv"), ReportedReasons: []reportedReason{{DisplayNameEN: "Persisted Reason"}}, ReportedReasonsStatus: metricAvailable,
		}},
		AdvertiserTop10: []wbAdvertiserEvidence{{
			AccountID: accountID, AdvertiserID: advertiserID, AdvertiserName: "Persisted Advertiser",
			CCR: &advCCR, CCRFact: successfulMetricFact(&advCCR), MetricStatus: "success", CurrentSource: advertiserMetricSourceForTest("older-adv"), ReportedReasons: []reportedReason{{DisplayNameEN: "Persisted Reason"}}, ReportedReasonsStatus: metricAvailable,
		}},
		Source: persistedETSource("older"),
	}
	newer := wbRow{
		ID: "newer", Program: "ET", Member: wbMember{AccountID: accountID},
		MetricStatus: "failed", Error: "temporary failure", AllowlistStatus: "Unknown",
		Comparison:      wbComparison{Status: metricFailed, PreCCRFact: failedMetricFact("temporary failure"), PostCCRFact: failedMetricFact("temporary failure")},
		AdvertiserTop10: []wbAdvertiserEvidence{{AccountID: accountID, AdvertiserID: advertiserID, CCRFact: failedMetricFact("temporary failure"), ReportedReasonsStatus: metricFailed}},
		Source:          map[string]any{"revenue": map[string]any{"status": "failed", "error": "temporary failure"}},
	}
	merged, ok := wbMergeProgramJobs("ET", []wbJob{
		{ID: "older", Status: "partial", StartedAt: "2026-10-27T14:00:00Z", Request: wbRequest{Program: "ET"}, Rows: []wbRow{older}},
		{ID: "newer", Status: "running", StartedAt: "2026-10-27T17:00:00Z", Request: wbRequest{Program: "ET"}, Rows: []wbRow{newer}},
	})
	if !ok || len(merged.Rows) != 1 {
		t.Fatalf("merge failed: ok=%v rows=%d", ok, len(merged.Rows))
	}
	got := merged.Rows[0]
	if got.CCR == nil || *got.CCR != ccr || got.NFS == nil || *got.NFS != nfs || got.Revenue == nil || *got.Revenue != revenue {
		t.Fatalf("completed current facts were lost: %+v", got)
	}
	if got.Member.Name != older.Member.Name || len(got.Reasons) != 1 || got.AllowlistStatus != older.AllowlistStatus {
		t.Fatalf("metadata/reasons/allowlist were not merged: %+v", got)
	}
	if got.Comparison.PreCCRFact.Status != metricSourceNull || got.Comparison.PostCCRFact.Status != metricSourceNull || got.Comparison.PreRevenue != nil || got.Comparison.PostRevenue != nil {
		t.Fatalf("comparison best facts or revenue contract violated: %+v", got.Comparison)
	}
	if len(got.AdvertiserTop10) != 1 || got.AdvertiserTop10[0].CCR == nil || got.AdvertiserTop10[0].AdvertiserName == "" || len(got.AdvertiserTop10[0].ReportedReasons) != 1 {
		t.Fatalf("advertiser/name/reasons best facts were not merged: %+v", got.AdvertiserTop10)
	}
}

func TestMergeProgramJobsRejectsIncompatibleETContracts(t *testing.T) {
	accountID := "7000000000000000001"
	good, bad := 11.0, 99.0
	base := wbRow{ID: "base", Program: "ET", Member: wbMember{AccountID: accountID}, CCR: &good, MetricStatus: "success", Source: persistedETSource("base")}
	candidate := wbRow{ID: "candidate", Program: "ET", Member: wbMember{AccountID: accountID}, CCR: &bad, MetricStatus: "success", Source: persistedETSource("candidate")}
	batchID := "TAP-WEEK-2026-10-19-2026-10-25"
	merged, ok := wbMergeProgramJobs("ET", []wbJob{
		{ID: "base", BatchID: batchID, Status: "ready", Request: wbRequest{Program: "ET", Region: "all", Start: "2026-10-19", End: "2026-10-25", MemberStart: "2026-01-01", MemberEnd: "2026-10-25"}, Rows: []wbRow{base}},
		{ID: "wrong-window", BatchID: batchID, Status: "ready", StartedAt: "2026-10-28T00:00:00Z", Request: wbRequest{Program: "ET", Region: "all", Start: "2026-10-12", End: "2026-10-18", MemberStart: "2026-01-01", MemberEnd: "2026-10-25"}, Rows: []wbRow{candidate}},
	})
	if !ok || len(merged.Rows) != 1 || merged.Rows[0].CCR == nil || *merged.Rows[0].CCR != good {
		t.Fatalf("incompatible current window merged: %+v", merged)
	}
	if len(merged.Warnings) == 0 || !strings.Contains(strings.Join(merged.Warnings, "|"), "current_window_mismatch") {
		t.Fatalf("rejection was not audited: %+v", merged.Warnings)
	}
}

func TestPersistedETMergeRequiresEvidenceAndKeepsComparisonPairAtomic(t *testing.T) {
	accountID := "7000000000000000001"
	pre, post, stalePost := 10.0, 20.0, 90.0
	base := wbRow{Program: "ET", Member: wbMember{AccountID: accountID, Start: "2026-10-08 10:00:00"}, MetricStatus: "no_data", Source: persistedETSource("base"), Comparison: wbComparison{
		Status: metricAvailable, PreCCR: &pre, PostCCR: &post, PreCCRFact: successfulMetricFact(&pre), PostCCRFact: successfulMetricFact(&post),
		PreStart: "2026-10-01", PreEndExclusive: "2026-10-08", PostStart: "2026-10-08", PostEndExclusive: "2026-10-15",
		Source: map[string]any{"source": "et_current_ccr_nfs", "grain": "account_window", "filters": map[string]any{"account_id": accountID}},
	}}
	candidate := wbRow{Program: "ET", Member: wbMember{AccountID: accountID, Start: "2026-10-09 10:00:00"}, CCR: f64(88), MetricStatus: "success", Comparison: wbComparison{
		Status: metricAvailable, PreCCR: &pre, PostCCR: &stalePost, PreCCRFact: successfulMetricFact(&pre), PostCCRFact: successfulMetricFact(&stalePost),
		PreStart: "2026-10-02", PreEndExclusive: "2026-10-09", PostStart: "2026-10-09", PostEndExclusive: "2026-10-16",
		Source: map[string]any{"source": "et_current_ccr_nfs", "grain": "account_window", "filters": map[string]any{"account_id": accountID}},
	}}
	got, reasons := wbMergePersistedETRow(base, candidate)
	if got.CCR != nil {
		t.Fatalf("field without query evidence was merged: %+v", got)
	}
	if got.Comparison.PostCCR == nil || *got.Comparison.PostCCR != post || got.Comparison.CCRGrowthPct == nil || *got.Comparison.CCRGrowthPct != 100 {
		t.Fatalf("Pre/Post facts were spliced or Increase was not recomputed: %+v", got.Comparison)
	}
	joined := strings.Join(reasons, "|")
	if !strings.Contains(joined, "current_evidence_missing") || !strings.Contains(joined, "comparison_anchor_mismatch") {
		t.Fatalf("missing rejection reasons: %v", reasons)
	}
}

func TestResumeMissingCurrentUsesSameETJobAndSkipsCompletedNulls(t *testing.T) {
	wbTestEnv(t)
	oldQuery := wbQueryETBatch
	t.Cleanup(func() { wbQueryETBatch = oldQuery })
	queried := []string{}
	value := 12.0
	wbQueryETBatch = func(_ context.Context, _ *http.Request, ids []string, _, _ string) (map[string]wbBatchMetric, error) {
		queried = append(queried, ids...)
		out := map[string]wbBatchMetric{}
		for _, id := range ids {
			out[id] = wbBatchMetric{Status: "success", CCR: &value, NFS: &value, Revenue: &value, RevenueStatus: "success", Source: map[string]any{"revenue": map[string]any{"status": "success"}}}
		}
		return out, nil
	}
	job := wbJob{
		ID: "existing-et", BatchID: "TAP-WEEK-2026-10-19-2026-10-25", Status: "running", Stage: "querying_metrics:1/2",
		Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rule: testRule(), Members: 3,
		Rows: []wbRow{
			{ID: "missing", Program: "ET", Member: wbMember{AccountID: "7000000000000000001"}},
			{ID: "failed", Program: "ET", Member: wbMember{AccountID: "7000000000000000002"}, MetricStatus: metricFailed, Source: map[string]any{"revenue": map[string]any{"status": "source_error"}}},
			{ID: "null", Program: "ET", Member: wbMember{AccountID: "7000000000000000003"}, MetricStatus: "no_data", Source: map[string]any{"revenue": map[string]any{"status": "no_data"}}},
		},
	}
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodPost, "/api/monitoring/risk-scans/existing-et/resume-missing", strings.NewReader(`{"max_chunks":1}`)).WithContext(wbReq("operator").Context())
	req.SetPathValue("id", job.ID)
	rr := httptest.NewRecorder()
	monitoringRiskScansByIdResumeMissingCreate(rr, req)
	if rr.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", rr.Code, rr.Body.String())
	}
	if len(queried) != 2 || queried[0] != "7000000000000000001" || queried[1] != "7000000000000000002" {
		t.Fatalf("unexpected repair targets: %v", queried)
	}
	state, err := wbReadDisk()
	if err != nil {
		t.Fatal(err)
	}
	if len(state.Jobs) != 1 || state.Jobs[job.ID].ID != job.ID {
		t.Fatalf("repair created or replaced task: %+v", state.Jobs)
	}
	for _, row := range state.Jobs[job.ID].Rows[:2] {
		if row.CCR == nil || row.NFS == nil || row.Revenue == nil {
			t.Fatalf("repair did not persist current facts: %+v", row)
		}
	}
}

func TestRetryFailedAllowlistTargetsOnlyFailedPairsAndPersistsEachResult(t *testing.T) {
	wbTestEnv(t)
	oldQuery := wbQueryAllowlistRows
	t.Cleanup(func() { wbQueryAllowlistRows = oldQuery })
	queried := []string{}
	wbQueryAllowlistRows = func(_ context.Context, _ *http.Request, ids []string) ([]map[string]any, error) {
		queried = append(queried, ids...)
		return []map[string]any{{"advertiser_id": "7100000000000000001"}}, nil
	}
	revenue := 1e20
	job := wbJob{ID: "allowlist-scan", Status: "ready", Request: wbRequest{Program: "ET"}, Rule: testRule(), Rows: []wbRow{
		{ID: "failed", Program: "ET", Member: wbMember{AccountID: "7000000000000000001"}, MetricStatus: "success", Revenue: &revenue, Message: "Revenue：1e+20", AggregationNote: "complete", Advertisers: []wbAdvertiserEvidence{
			{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001", AllowlistStatus: "query_failed"},
			{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000002", AllowlistStatus: "query_failed"},
		}},
		{ID: "untouched", Program: "ET", Member: wbMember{AccountID: "7000000000000000002"}, MetricStatus: "success", AggregationNote: "complete", Advertisers: []wbAdvertiserEvidence{{AccountID: "7000000000000000002", AdvertiserID: "7100000000000000003", AllowlistStatus: "matched_scope_unknown"}}},
	}}
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodPost, "/api/monitoring/risk-scans/allowlist-scan/resume-missing", strings.NewReader(`{"retry_allowlist_failed":true}`)).WithContext(wbReq("operator").Context())
	req.SetPathValue("id", job.ID)
	rr := httptest.NewRecorder()
	monitoringRiskScansByIdResumeMissingCreate(rr, req)
	if rr.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", rr.Code, rr.Body.String())
	}
	if len(queried) != 2 || queried[0] != "7100000000000000001" || queried[1] != "7100000000000000002" {
		t.Fatalf("unexpected allowlist targets: %v", queried)
	}
	state, _ := wbReadDisk()
	got := state.Jobs[job.ID]
	if len(state.Jobs) != 1 || got.Rows[0].Advertisers[0].AllowlistStatus != "matched_scope_unknown" || got.Rows[0].Advertisers[1].AllowlistStatus != "not_matched_scope_unknown" {
		t.Fatalf("allowlist retry was not persisted on the same task: %+v", got)
	}
	if got.Rows[1].Advertisers[0].AllowlistStatus != "matched_scope_unknown" || got.Rows[0].Advertisers[0].AllowlistEvidence != nil {
		t.Fatalf("non-target changed or successful request evidence was retained: %+v", got.Rows)
	}
	if got.Rows[0].Message != "Revenue：100000000000000000000" {
		t.Fatalf("scientific Revenue message was not normalized: %q", got.Rows[0].Message)
	}
}

func TestAdvertiserTop10ClassificationSeparatesSourceNullRealZeroAndFailure(t *testing.T) {
	rows := []wbRow{
		{MetricStatus: "success", AggregationNote: "complete", Advertisers: []wbAdvertiserEvidence{{AdvertiserID: "1"}}},
		{MetricStatus: "success", AggregationNote: "complete"},
		{MetricStatus: metricFailed, AggregationNote: "complete", Advertisers: []wbAdvertiserEvidence{{AdvertiserID: "2"}}},
	}
	got := wbClassifyRows(rows)["advertiser_top10"]
	if got[metricSourceNull] != 1 || got["real_zero"] != 1 || got[metricFailed] != 1 || got["not_queried"] != 0 {
		t.Fatalf("unexpected ADV Top10 classification: %+v", got)
	}
}

func TestRetryFailedAllowlistRetainsExactEvidenceOnFailure(t *testing.T) {
	wbTestEnv(t)
	oldQuery := wbQueryAllowlistRows
	t.Cleanup(func() { wbQueryAllowlistRows = oldQuery })
	wbQueryAllowlistRows = func(_ context.Context, _ *http.Request, _ []string) ([]map[string]any, error) {
		return nil, errors.New("request_id=req-allowlist log_id=log-allowlist gateway rejected")
	}
	job := wbJob{ID: "allowlist-failure", Status: "ready", Request: wbRequest{Program: "ET"}, Rows: []wbRow{{
		ID: "failed", Program: "ET", Member: wbMember{AccountID: "7000000000000000001"}, Advertisers: []wbAdvertiserEvidence{{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001", AllowlistStatus: "query_failed"}},
	}}}
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodPost, "/api/monitoring/risk-scans/allowlist-failure/resume-missing", strings.NewReader(`{"retry_allowlist_failed":true}`)).WithContext(wbReq("operator").Context())
	req.SetPathValue("id", job.ID)
	rr := httptest.NewRecorder()
	monitoringRiskScansByIdResumeMissingCreate(rr, req)
	if rr.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", rr.Code, rr.Body.String())
	}
	state, _ := wbReadDisk()
	item := state.Jobs[job.ID].Rows[0].Advertisers[0]
	count := 0
	switch ids := item.AllowlistEvidence["advertiser_ids"].(type) {
	case []any:
		count = len(ids)
	case []string:
		count = len(ids)
	}
	if item.AllowlistStatus != "query_failed" || !strings.Contains(item.AllowlistError, "req-allowlist") || item.AllowlistEvidence["source"] != "advertiser_allowlist" || count != 1 {
		t.Fatalf("failed request evidence missing: %+v", item)
	}
}

func TestResumeAdvertiserCurrentTargetsOnlyMissingAndPersistsTop10(t *testing.T) {
	wbTestEnv(t)
	oldQuery := wbQueryAdvertiserCurrentRows
	t.Cleanup(func() { wbQueryAdvertiserCurrentRows = oldQuery })
	queried := []string{}
	ccr, nfs := 8.5, 3.0
	wbQueryAdvertiserCurrentRows = func(_ context.Context, _ *http.Request, ids []string, start, end string) ([]map[string]any, error) {
		queried = append(queried, ids...)
		if start != "2026-10-19" || end != "2026-10-25" {
			t.Fatalf("unexpected current window: %s..%s", start, end)
		}
		return []map[string]any{{
			"account_id": "7000000000000000001", "advertiser_id": ids[0],
			"dynamic_p0_ccr": ccr, "p0_nfs": nfs,
			"_tap_trace": map[string]any{"request_id": "req-current"},
		}}, nil
	}
	job := wbJob{
		ID: "advertiser-current", Status: "running",
		Request: wbRequest{Program: "ET", Start: "2026-10-19", End: "2026-10-25"}, Rule: testRule(),
		Rows: []wbRow{{ID: "row", Program: "ET", Member: wbMember{AccountID: "7000000000000000001"}, MetricStatus: "no_data", Source: map[string]any{"revenue": map[string]any{"status": "no_data"}}, Advertisers: []wbAdvertiserEvidence{
			{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000001"},
			{AccountID: "7000000000000000001", AdvertiserID: "7100000000000000002", CurrentSource: map[string]any{"status": metricSourceNull}},
		}}},
	}
	if err := wbWriteDisk(wbDisk{Jobs: map[string]wbJob{job.ID: job}, Actions: map[string]wbAction{}}); err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodPost, "/api/monitoring/risk-scans/advertiser-current/resume-missing", strings.NewReader(`{"max_chunks":1}`)).WithContext(wbReq("operator").Context())
	req.Header.Set("Authorization", "Byte-Cloud-JWT test")
	req.SetPathValue("id", job.ID)
	rr := httptest.NewRecorder()
	monitoringRiskScansByIdResumeMissingCreate(rr, req)
	if rr.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", rr.Code, rr.Body.String())
	}
	if len(queried) != 1 || queried[0] != "7100000000000000001" {
		t.Fatalf("unexpected advertiser repair targets: %v", queried)
	}
	state, err := wbReadDisk()
	if err != nil {
		t.Fatal(err)
	}
	got := state.Jobs[job.ID].Rows[0]
	if len(got.AdvertiserTop10) != 1 || got.AdvertiserTop10[0].CCR == nil || *got.AdvertiserTop10[0].CCR != ccr {
		t.Fatalf("advertiser current or Top10 not persisted: %+v", got)
	}
	if got.Advertisers[1].CurrentSource["status"] != metricSourceNull {
		t.Fatalf("completed source_null pair was reclassified: %+v", got.Advertisers[1])
	}
}
