// CODE GENERATED FROM app/api/api.yaml BY tools/gen_api.py — DO NOT EDIT
package main

import "net/http"

// 本文件由 IDL 生成，登记 monitoring 资源的路由契约。
// 业务逻辑写在 handler_monitoring.go 的 handler 函数里，不要改本文件。
func init() {
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/monitoring/et/current",
		Summary: "查询单个 ET Account 的权威 Account 粒度 Current P0 CCR/NFS/Revenue 真实业务数据",
		Handler: monitoringEtCurrentCreate,
		Tags:    []string{"monitoring", "et"},
		BodyParams: []Param{
			{Name: "account_id", Type: "string", Required: true, Description: "ET Account ID，按字符串处理"},
			{Name: "start_date", Type: "string", Required: true, Description: "开始日期 YYYY-MM-DD"},
			{Name: "end_date", Type: "string", Required: true, Description: "结束日期 YYYY-MM-DD"},
		},
		RequestExample: map[string]any{
			"account_id": "7462465462811770896",
			"start_date": "2026-10-12",
			"end_date":   "2026-10-18",
		},
		Response: map[string]any{
			"data": map[string]any{
				"status":          "success",
				"account_id":      "7462465462811770896",
				"start_date":      "2026-10-12",
				"end_date":        "2026-10-18",
				"dynamic_p0_ccr":  8.552188750450918,
				"p0_nfs":          61,
				"revenue":         4080.989999999989,
				"revenue_status":  "success",
				"revenue_error":   "",
				"authority_grain": "account_week",
				"data_source": map[string]any{
					"app_id": 800414,
					"sid":    1139137,
					"rid":    2979783,
					"grain":  "account_week",
					"revenue": map[string]any{
						"rid":   2980054,
						"sid":   1139137,
						"grain": "account_week",
					},
				},
				"request_id":         "",
				"log_id":             "",
				"revenue_request_id": "",
				"revenue_log_id":     "",
				"query_duration_ms":  9063,
				"last_queried_at":    "2026-10-22T05:12:49Z",
				"cached":             false,
			},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/monitoring/risk-scans",
		Summary: "创建 ET/THT 高风险客户异步扫描",
		Handler: monitoringRiskScansCreate,
		Tags:    []string{"monitoring", "risk"},
		BodyParams: []Param{
			{Name: "program", Type: "string", Required: true},
			{Name: "start_date", Type: "string", Required: true},
			{Name: "end_date", Type: "string", Required: true},
			{Name: "member_start_date", Type: "string", Required: true},
			{Name: "member_end_date", Type: "string", Required: true},
			{Name: "region", Type: "string"},
			{Name: "force", Type: "boolean"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"id":           "scan-id",
				"status":       "running",
				"stage":        "loading_members",
				"member_count": 0,
				"done":         0,
				"rows":         []any{},
			},
		},
	})
	Register(Route{
		Method:  http.MethodGet,
		Path:    "/api/monitoring/risk-scans/{id}",
		Summary: "查询 ET/THT 高风险客户扫描进度与完整结果",
		Handler: monitoringRiskScansByIdGet,
		Tags:    []string{"monitoring", "risk"},
		Response: map[string]any{
			"data": map[string]any{
				"id":           "scan-id",
				"status":       "ready",
				"stage":        "finished",
				"member_count": 0,
				"done":         0,
				"rows":         []any{},
			},
			"actions": map[string]any{},
		},
	})
	Register(Route{
		Method:  http.MethodPost,
		Path:    "/api/monitoring/risk-scans/{id}/resume-missing",
		Summary: "在既有 ET 扫描任务内按 checkpoint 定向补齐缺失字段，不重扫 membership",
		Handler: monitoringRiskScansByIdResumeMissingCreate,
		Tags:    []string{"monitoring", "et", "repair"},
		BodyParams: []Param{
			{Name: "max_chunks", Type: "integer", Description: "本次最多处理分片数；1 用于小分片验证，0 表示处理全部剩余分片"},
			{Name: "include_enrichment", Type: "boolean", Description: "补齐同一任务中未查询的 Names、Advertiser、Reasons 与 Allowlist 字段"},
			{Name: "retry_allowlist_failed", Type: "boolean", Description: "仅重试既有 query_failed Allowlist pairs；按 250 个 Advertiser 分片保存，不查询其他字段"},
		},
		Response: map[string]any{
			"data": map[string]any{
				"id":             "scan-id",
				"status":         "running",
				"processed":      100,
				"remaining":      209,
				"classification": map[string]any{},
			},
		},
	})
}
