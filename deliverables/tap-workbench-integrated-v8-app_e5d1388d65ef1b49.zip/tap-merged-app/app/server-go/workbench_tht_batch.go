package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"
)

const wbTHTMetricChunkSize = defaultIDBatchSize
const wbTHTResumeSliceSize = 50

var wbQueryTHTBatch = queryTHTCurrentBatch
var wbQueryTHTComparisonBatch = queryTHTCCRBatch
var thtVQSProbe = runTitanVQSProbe

func thtProbeFailure(probe map[string]any) string {
	detail := ""
	if step, ok := probe["query_result"].(titanProbeStep); ok {
		detail = fmt.Sprintf(" error_type=%s message=%s glue_message=%s", step.ErrorType, step.ErrorMessage, step.GlueMessage)
	}
	if summary := asString(probe["filter_integrity_summary"]); summary != "" {
		detail += " filter_integrity=" + summary
	}
	if filterError := asString(probe["filter_error"]); filterError != "" {
		detail += " filter_error=" + filterError
	}
	return detail
}

func thtPairKey(accountID, advertiserID string) string {
	return strings.TrimSpace(accountID) + "\x1f" + strings.TrimSpace(advertiserID)
}

func thtNoDataMetric(id string, probe map[string]any) wbBatchMetric {
	return wbBatchMetric{Status: "no_data", AdvertiserID: id, Source: map[string]any{"source": "tht_current_ccr_nfs", "rid": probe["report_id"], "sid": probe["dataset_id"], "grain": "account_advertiser_week"}, QueriedAt: asString(probe["queriedAt"]), RequestID: asString(probe["requestId"]), Message: "该 THT Advertiser ID 在所选日期范围内没有返回 S05 事实行"}
}

func attachTHTReportedReasons(ctx context.Context, request *http.Request, ids []string, startDate, endDate string, out map[string][]wbBatchMetric) error {
	reasonRows, reasonComplete, reasonUnavailable := queryReportedReasonRows(ctx, request, ids, "advertiser_id", startDate, endDate)
	dict, err := loadReportedReasonDictionary()
	if err != nil {
		return err
	}
	ranked := rankReportedReasons(dict, reasonRows, reasonComplete, reasonUnavailable)
	for id := range out {
		for i := range out[id] {
			key := wbPairKey{out[id][i].AccountID, id}
			out[id][i].ReportedReasons = ranked[key]
			if len(out[id][i].ReportedReasons) == 0 {
				out[id][i].ReportedReasons = []reportedReason{unavailableReportedReason(reasonUnavailable)}
			}
		}
	}
	return nil
}

func queryTHTCCRBatch(ctx context.Context, request *http.Request, ids []string, startDate, endDate string) (map[string][]wbBatchMetric, error) {
	ids = uniqueNonEmpty(ids)
	if len(ids) == 0 {
		return map[string][]wbBatchMetric{}, nil
	}
	for _, id := range ids {
		if !decimalID.MatchString(id) {
			return nil, fmt.Errorf("invalid THT advertiser_id %q", id)
		}
	}
	u := *request.URL
	batchRequest := request.Clone(ctx)
	batchRequest.URL = &u
	query := u.Query()
	query.Set("start_date", startDate)
	query.Set("end_date", endDate)
	query.Set("client_ids", strings.Join(ids, ","))
	query.Set("id_dimension", "advertiser_id")
	batchRequest.URL.RawQuery = query.Encode()
	batchRequest.Header = request.Header.Clone()
	batchRequest.Header.Set("X-TAP-Allow-Missing-IDs", "1")
	probe, err := thtVQSProbe(ctx, batchRequest, "tht_current_ccr_nfs")
	if err != nil {
		return nil, err
	}
	if asString(probe["status"]) != "ok" {
		return nil, wbProbeQueryError("THT comparison batch", probe, thtProbeFailure(probe))
	}
	if truncated, _ := probe["possibly_truncated"].(bool); truncated {
		return nil, errors.New("THT comparison VQS result reached the hard limit; refusing silent truncation")
	}
	rows, _ := probe["business_rows"].([]map[string]any)
	wanted := make(map[string]bool, len(ids))
	out := make(map[string][]wbBatchMetric, len(ids))
	pairIndex := map[string]map[string]bool{}
	for _, id := range ids {
		wanted[id] = true
		pairIndex[id] = map[string]bool{}
	}
	for _, row := range rows {
		id := strings.TrimSpace(asString(row["advertiser_id"]))
		if id == "" || !wanted[id] {
			return nil, fmt.Errorf("THT comparison returned an unrequested or empty advertiser_id %q", id)
		}
		accountID := strings.TrimSpace(asString(row["account_id"]))
		if accountID != "" && !decimalID.MatchString(accountID) {
			return nil, fmt.Errorf("advertiser_id %s returned invalid account_id %q", id, accountID)
		}
		key := thtPairKey(accountID, id)
		if pairIndex[id][key] {
			return nil, fmt.Errorf("THT comparison pair contract failed: account_id=%q advertiser_id=%s returned multiple rows", accountID, id)
		}
		pairIndex[id][key] = true
		ccr, metricErr := strictWBMetric(row["dynamic_p0_ccr"])
		if metricErr != nil {
			return nil, fmt.Errorf("advertiser_id %s account_id %q has invalid dynamic_p0_ccr: %w", id, accountID, metricErr)
		}
		nfs, metricErr := strictWBMetric(row["p0_nfs"])
		if metricErr != nil {
			return nil, fmt.Errorf("advertiser_id %s account_id %q has invalid p0_nfs: %w", id, accountID, metricErr)
		}
		out[id] = append(out[id], wbBatchMetric{Status: "success", CCR: ccr, NFS: nfs, AccountID: accountID, AdvertiserID: id, Source: map[string]any{"source": "tht_current_ccr_nfs", "rid": probe["report_id"], "sid": probe["dataset_id"], "grain": "account_advertiser_window"}, QueriedAt: asString(probe["queriedAt"]), RequestID: asString(probe["requestId"]), LogID: asString(probe["logId"])})
	}
	for _, id := range ids {
		if len(out[id]) == 0 {
			out[id] = []wbBatchMetric{thtNoDataMetric(id, probe)}
		}
	}
	return out, nil
}

// queryTHTCurrentBatch preserves every authoritative account×advertiser fact.
// Repeated advertiser IDs are valid cardinality at this grain; unrequested IDs,
// empty IDs and duplicate complete pair keys still fail closed.
func queryTHTCurrentBatch(ctx context.Context, request *http.Request, ids []string, startDate, endDate string) (map[string][]wbBatchMetric, error) {
	ids = uniqueNonEmpty(ids)
	if len(ids) == 0 {
		return map[string][]wbBatchMetric{}, nil
	}
	for _, id := range ids {
		if !decimalID.MatchString(id) {
			return nil, fmt.Errorf("invalid THT advertiser_id %q", id)
		}
	}
	u := *request.URL
	batchRequest := request.Clone(ctx)
	batchRequest.URL = &u
	query := u.Query()
	query.Set("start_date", startDate)
	query.Set("end_date", endDate)
	query.Set("client_ids", strings.Join(ids, ","))
	query.Set("id_dimension", "advertiser_id")
	batchRequest.URL.RawQuery = query.Encode()
	batchRequest.Header = request.Header.Clone()
	batchRequest.Header.Set("X-TAP-Allow-Missing-IDs", "1")

	probe, err := thtVQSProbe(ctx, batchRequest, "tht_current_ccr_nfs")
	if err != nil {
		return nil, err
	}
	if asString(probe["status"]) != "ok" {
		return nil, wbProbeQueryError("THT batch", probe, thtProbeFailure(probe))
	}
	if truncated, _ := probe["possibly_truncated"].(bool); truncated {
		return nil, errors.New("THT batch VQS result reached the hard limit; refusing silent truncation")
	}
	rows, _ := probe["business_rows"].([]map[string]any)
	wanted := make(map[string]bool, len(ids))
	out := make(map[string][]wbBatchMetric, len(ids))
	pairIndex := map[string]map[string]int{}
	for _, id := range ids {
		wanted[id] = true
		pairIndex[id] = map[string]int{}
	}
	for _, row := range rows {
		id := strings.TrimSpace(asString(row["advertiser_id"]))
		if id == "" || !wanted[id] {
			return nil, fmt.Errorf("THT batch VQS returned an unrequested or empty advertiser_id %q", id)
		}
		accountID := strings.TrimSpace(asString(row["account_id"]))
		if accountID != "" && !decimalID.MatchString(accountID) {
			return nil, fmt.Errorf("advertiser_id %s returned invalid account_id %q", id, accountID)
		}
		key := thtPairKey(accountID, id)
		if _, duplicate := pairIndex[id][key]; duplicate {
			return nil, fmt.Errorf("THT batch pair contract failed: account_id=%q advertiser_id=%s returned multiple S05 rows", accountID, id)
		}
		ccr, metricErr := strictWBMetric(row["dynamic_p0_ccr"])
		if metricErr != nil {
			return nil, fmt.Errorf("advertiser_id %s account_id %q has invalid dynamic_p0_ccr: %w", id, accountID, metricErr)
		}
		nfs, metricErr := strictWBMetric(row["p0_nfs"])
		if metricErr != nil {
			return nil, fmt.Errorf("advertiser_id %s account_id %q has invalid p0_nfs: %w", id, accountID, metricErr)
		}
		semanticsLabel, semanticsStatus := semanticsLabelFact(row)
		pairIndex[id][key] = len(out[id])
		out[id] = append(out[id], wbBatchMetric{Status: "success", CCR: ccr, NFS: nfs, AccountID: accountID, AdvertiserID: id, SemanticsLabel: semanticsLabel, SemanticsStatus: semanticsStatus, Source: map[string]any{"source": "tht_current_ccr_nfs", "rid": probe["report_id"], "sid": probe["dataset_id"], "grain": "account_advertiser_week"}, QueriedAt: asString(probe["queriedAt"]), RequestID: asString(probe["requestId"])})
	}

	revenueProbe, revenueErr := thtVQSProbe(ctx, batchRequest, "weekly_pair_revenue")
	if revenueErr != nil || asString(revenueProbe["status"]) != "ok" {
		revenueRequestID, revenueLogID := asString(revenueProbe["requestId"]), asString(revenueProbe["logId"])
		revenueMessage := sanitizeLogText(fmt.Sprintf("%v", revenueErr))
		if revenueErr == nil {
			revenueMessage = sanitizeLogText("status=" + asString(revenueProbe["status"]) + thtProbeFailure(revenueProbe))
		}
		if step, ok := revenueProbe["query_result"].(titanProbeStep); ok {
			if revenueRequestID == "" {
				revenueRequestID = step.RequestID
			}
			if revenueLogID == "" {
				revenueLogID = step.LogID
			}
		}
		for _, id := range ids {
			if len(out[id]) == 0 {
				out[id] = []wbBatchMetric{thtNoDataMetric(id, probe)}
			}
			for i := range out[id] {
				out[id][i].RevenueStatus, out[id][i].RevenueError = "source_error", revenueMessage
				out[id][i].RevenueRequestID, out[id][i].RevenueLogID = revenueRequestID, revenueLogID
			}
		}
		if err := attachTHTReportedReasons(ctx, request, ids, startDate, endDate, out); err != nil {
			return nil, err
		}
		return out, nil
	}
	if truncated, _ := revenueProbe["possibly_truncated"].(bool); truncated {
		return nil, errors.New("THT Revenue batch VQS result reached the hard limit; refusing silent truncation")
	}
	for _, id := range ids {
		for i := range out[id] {
			out[id][i].RevenueStatus = "no_data"
			out[id][i].RevenueRequestID, out[id][i].RevenueLogID = asString(revenueProbe["requestId"]), asString(revenueProbe["logId"])
		}
	}
	seenRevenuePairs := map[string]bool{}
	revenueRows, _ := revenueProbe["business_rows"].([]map[string]any)
	for _, revenueRow := range revenueRows {
		id := strings.TrimSpace(asString(revenueRow["advertiser_id"]))
		if id == "" || !wanted[id] {
			return nil, fmt.Errorf("THT Revenue VQS returned an unrequested or empty advertiser_id %q", id)
		}
		accountID := strings.TrimSpace(asString(revenueRow["account_id"]))
		if accountID != "" && !decimalID.MatchString(accountID) {
			return nil, fmt.Errorf("advertiser_id %s Revenue returned invalid account_id %q", id, accountID)
		}
		key := thtPairKey(accountID, id)
		if seenRevenuePairs[key] {
			return nil, fmt.Errorf("THT batch pair contract failed: account_id=%q advertiser_id=%s returned multiple Revenue rows", accountID, id)
		}
		seenRevenuePairs[key] = true
		value, metricErr := strictWBMetric(revenueRow["revenue"])
		if metricErr != nil {
			return nil, fmt.Errorf("advertiser_id %s account_id %q has invalid revenue: %w", id, accountID, metricErr)
		}
		if index, ok := pairIndex[id][key]; ok {
			out[id][index].Revenue = value
			out[id][index].RevenueStatus = "success"
			continue
		}
		pairIndex[id][key] = len(out[id])
		metric := thtNoDataMetric(id, probe)
		metric.AccountID, metric.Revenue, metric.RevenueStatus = accountID, value, "success"
		metric.RevenueRequestID, metric.RevenueLogID = asString(revenueProbe["requestId"]), asString(revenueProbe["logId"])
		out[id] = append(out[id], metric)
	}
	if err := attachTHTReportedReasons(ctx, request, ids, startDate, endDate, out); err != nil {
		return nil, err
	}
	for _, id := range ids {
		if len(out[id]) == 0 {
			out[id] = []wbBatchMetric{thtNoDataMetric(id, probe)}
		}
	}
	return out, nil
}

func wbRowsFromTHTBatch(members []wbMember, metrics map[string][]wbBatchMetric, q wbRequest, rule wbRule) ([]wbRow, error) {
	rows := make([]wbRow, 0, len(members))
	for _, member := range members {
		pairMetrics, ok := metrics[member.AdvertiserID]
		if !ok || len(pairMetrics) == 0 {
			return nil, fmt.Errorf("THT batch result missing mapping for advertiser_id %s", member.AdvertiserID)
		}
		for _, metric := range pairMetrics {
			pairMember := member
			if metric.AccountID != "" {
				pairMember.AccountID = metric.AccountID
				pairMember.LinkedAccountIDs = addUnique(pairMember.LinkedAccountIDs, metric.AccountID)
			}
			row := wbRow{Program: q.Program, Member: pairMember, CCR: metric.CCR, NFS: metric.NFS, Revenue: metric.Revenue, MetricStatus: metric.Status, Reasons: []string{}, Level: "unavailable", AllowlistStatus: "N/A：THT 未使用 ET/ST bridge allowlist", DataStatus: "No Fact", RecipientStatus: "pending_confirmation", Source: metric.Source, QueriedAt: metric.QueriedAt, RequestID: metric.RequestID}
			if source, ok := row.Source.(map[string]any); ok {
				source["revenue"] = map[string]any{"source": "weekly_pair_revenue", "rid": 2942918, "status": metric.RevenueStatus, "request_id": metric.RevenueRequestID, "log_id": metric.RevenueLogID, "error": metric.RevenueError}
			}
			row.ID = wbKey([]string{q.Program, member.AdvertiserID, metric.AccountID, member.TicketID, q.Start, q.End, rule.Version})[:24]
			switch metric.Status {
			case "success":
				row.DataStatus = "Success"
				row.Level, row.Reasons = evaluateWBAbsolute(row.CCR, row.NFS, rule)
				if row.CCR == nil || row.NFS == nil {
					row.DataStatus = "Partial Fact"
				}
			case "no_data":
				row.Error = metric.Message
			default:
				return nil, fmt.Errorf("advertiser_id %s has unexpected batch status %q", member.AdvertiserID, metric.Status)
			}
			if member.Submitter != "" {
				row.RecipientStatus = "submitter_available_identity_unverified"
			}
			evidence := wbAdvertiserEvidence{AccountID: metric.AccountID, AdvertiserID: member.AdvertiserID, AdvertiserName: member.AdvertiserName, CCR: row.CCR, NFS: row.NFS, Revenue: row.Revenue, AllowlistStatus: row.AllowlistStatus, Level: row.Level, Reasons: append([]string(nil), row.Reasons...), MetricStatus: row.MetricStatus, RevenueStatus: metric.RevenueStatus, RevenueError: metric.RevenueError, RevenueRequestID: metric.RevenueRequestID, RevenueLogID: metric.RevenueLogID, SemanticsLabel: metric.SemanticsLabel, SemanticsStatus: metric.SemanticsStatus, ReportedReasons: metric.ReportedReasons}
			row.Advertisers, row.AdvertiserTop10, row.AdvertiserCount = []wbAdvertiserEvidence{evidence}, topAdvertisers([]wbAdvertiserEvidence{evidence}, 10), 1
			row.AccountCCRStatus = "N/A：THT 主体为 Advertiser；Account 仅保留 S05/S07 返回的真实关联"
			revenueNote := "Revenue 已按同一 Account×Advertiser 事实行读取"
			if metric.RevenueStatus != "success" {
				revenueNote = "Revenue 状态：" + metric.RevenueStatus
			}
			row.AggregationNote = "THT 保留 S05/S07 的 Account×Advertiser 粒度；" + revenueNote
			row.Message = wbMessage(row, q, rule)
			rows = append(rows, row)
		}
	}
	return rows, nil
}

func wbRunTHTBatchesWithProgress(ctx context.Context, request *http.Request, members []wbMember, q wbRequest, rule wbRule, onChunkDone func(processed, completedChunks, totalChunks int, rows []wbRow)) ([]wbRow, int, error) {
	ids := make([]string, 0, len(members))
	for _, member := range members {
		ids = append(ids, member.AdvertiserID)
	}
	all := make(map[string][]wbBatchMetric, len(ids))
	chunks := chunkIDs(ids, wbTHTMetricChunkSize)
	processed := 0
	checkpointRows := make([]wbRow, 0, len(members))
	for index, chunk := range chunks {
		chunkCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
		metrics, err := wbRunMetricChunkWithRetry(chunkCtx, q.Program, index+1, len(chunks), func(attemptCtx context.Context) (map[string][]wbBatchMetric, error) {
			return wbQueryTHTBatch(attemptCtx, request, chunk, q.Start, q.End)
		})
		cancel()
		if err != nil {
			return nil, index + 1, fmt.Errorf("THT metric chunk %d/%d failed after at most %d attempts: %w", index+1, len(chunks), wbMetricMaxAttempts, err)
		}
		for id, metric := range metrics {
			if _, duplicate := all[id]; duplicate {
				return nil, index + 1, fmt.Errorf("THT metric advertiser_id %s appeared in multiple chunks", id)
			}
			all[id] = metric
		}
		chunkMembers := members[processed : processed+len(chunk)]
		chunkRows, rowErr := wbRowsFromTHTBatch(chunkMembers, metrics, q, rule)
		if rowErr != nil {
			return nil, index + 1, rowErr
		}
		checkpointRows = append(checkpointRows, chunkRows...)
		processed += len(chunk)
		if onChunkDone != nil {
			onChunkDone(processed, index+1, len(chunks), append([]wbRow(nil), checkpointRows...))
		}
	}
	rows, err := wbRowsFromTHTBatch(members, all, q, rule)
	return rows, len(chunks), err
}
