package main

import (
	"fmt"
	"strings"
	"time"
)

type wbMembershipAuditContextKey struct{}
type wbMembershipAudit struct {
	RawRows      *int
	BusinessRows *int
}

func intPtr(value int) *int { return &value }

type wbFunnelCount struct {
	Value  *int   `json:"value"`
	Status string `json:"status"`
}

type wbProgramFunnel struct {
	Program                       string                   `json:"program"`
	Status                        string                   `json:"status"`
	DistinctKey                   string                   `json:"distinct_key"`
	RawRows                       wbFunnelCount            `json:"raw_rows"`
	BusinessFiltered              wbFunnelCount            `json:"business_filtered"`
	DistinctClients               wbFunnelCount            `json:"distinct_clients"`
	MappingSuccess                wbFunnelCount            `json:"mapping_success"`
	MappingFail                   wbFunnelCount            `json:"mapping_fail"`
	CurrentCCRComplete            wbFunnelCount            `json:"current_ccr_complete"`
	CurrentNFSComplete            wbFunnelCount            `json:"current_nfs_complete"`
	RevenueComplete               wbFunnelCount            `json:"revenue_complete"`
	MetricsComplete               wbFunnelCount            `json:"current_metrics_complete"`
	AdvertiserPairs               wbFunnelCount            `json:"advertiser_pairs"`
	AdvertiserPairCCRComplete     wbFunnelCount            `json:"advertiser_pair_ccr_complete"`
	AdvertiserPairNFSComplete     wbFunnelCount            `json:"advertiser_pair_nfs_complete"`
	AdvertiserPairRevenueComplete wbFunnelCount            `json:"advertiser_pair_revenue_complete"`
	AdvertiserPairRuleEligible    wbFunnelCount            `json:"advertiser_pair_rule_eligible"`
	RuleEligible                  wbFunnelCount            `json:"rule_eligible"`
	Watch                         wbFunnelCount            `json:"watch"`
	Extreme                       wbFunnelCount            `json:"extreme"`
	NoFact                        wbFunnelCount            `json:"no_fact"`
	Partial                       wbFunnelCount            `json:"partial"`
	SourceError                   wbFunnelCount            `json:"source_error"`
	Incomplete                    wbFunnelCount            `json:"incomplete"`
	ProtectionTimeValid           wbFunnelCount            `json:"comparison_protection_time_valid"`
	ComparisonWindowComplete      wbFunnelCount            `json:"comparison_window_complete"`
	ComparisonQueried             wbFunnelCount            `json:"comparison_queried"`
	ComparisonSuccess             wbFunnelCount            `json:"comparison_success"`
	ComparisonNoData              wbFunnelCount            `json:"comparison_no_data"`
	ComparisonFailed              wbFunnelCount            `json:"comparison_failed"`
	ComparisonBudgetSkipped       wbFunnelCount            `json:"comparison_budget_skipped"`
	GrowthRankingStatus           string                   `json:"growth_ranking_status"`
	ExclusionReasons              map[string]wbFunnelCount `json:"exclusion_reasons"`
}

func wbKnownCount(value int) wbFunnelCount {
	return wbFunnelCount{Value: &value, Status: "known"}
}

func wbUnknownCount() wbFunnelCount { return wbFunnelCount{Status: "unknown"} }

func wbDistinctKey(program string) string {
	if strings.EqualFold(program, "THT") {
		return "advertiser_id"
	}
	return "account_id"
}

func wbUnknownFunnelWithReason(program, reason string) wbProgramFunnel {
	unknown := wbUnknownCount()
	return wbProgramFunnel{
		Program: program, Status: reason, DistinctKey: wbDistinctKey(program), RawRows: unknown, BusinessFiltered: unknown,
		DistinctClients: unknown, MappingSuccess: unknown, MappingFail: unknown, CurrentCCRComplete: unknown,
		CurrentNFSComplete: unknown, RevenueComplete: unknown, MetricsComplete: unknown, AdvertiserPairs: unknown,
		AdvertiserPairCCRComplete: unknown, AdvertiserPairNFSComplete: unknown, AdvertiserPairRevenueComplete: unknown,
		AdvertiserPairRuleEligible: unknown, RuleEligible: unknown, Watch: unknown, Extreme: unknown, NoFact: unknown,
		Partial: unknown, SourceError: unknown, Incomplete: unknown, ProtectionTimeValid: unknown, ComparisonWindowComplete: unknown,
		ComparisonQueried: unknown, ComparisonSuccess: unknown, ComparisonNoData: unknown, ComparisonFailed: unknown,
		ComparisonBudgetSkipped: unknown, GrowthRankingStatus: "unknown",
		ExclusionReasons: map[string]wbFunnelCount{reason: unknown},
	}
}

func wbUnknownFunnel(program string) wbProgramFunnel {
	return wbUnknownFunnelWithReason(program, "legacy_funnel_not_persisted")
}

func wbFunnelRowKey(program string, row wbRow) string {
	id := strings.TrimSpace(row.Member.AccountID)
	if strings.EqualFold(program, "THT") {
		id = strings.TrimSpace(row.Member.AdvertiserID)
		if id == "" {
			id = strings.TrimSpace(row.Member.AccountID)
		}
	}
	if id == "" {
		id = strings.TrimSpace(row.ID)
	}
	return strings.ToUpper(program) + "|" + id
}

func wbJobRecency(job wbJob) string {
	if job.FinishedAt != "" {
		return job.FinishedAt
	}
	if job.AsOf != "" {
		return job.AsOf
	}
	return job.StartedAt
}

func wbJobMatchesBatchWindow(job wbJob) bool {
	const prefix = "TAP-WEEK-"
	if job.Request.Start == "" && job.Request.End == "" {
		return true // legacy jobs predate persisted request windows
	}
	if !strings.HasPrefix(job.BatchID, prefix) {
		return true // legacy/test batches have no encoded window to validate
	}
	window := strings.TrimPrefix(job.BatchID, prefix)
	if len(window) != 21 || window[10] != '-' {
		return false
	}
	return job.Request.Start == window[:10] && job.Request.End == window[11:]
}

func wbJobMergeContractMismatch(authority, candidate wbJob) string {
	if !strings.EqualFold(authority.Request.Program, "ET") || !strings.EqualFold(candidate.Request.Program, "ET") {
		return "program_mismatch"
	}
	if authority.BatchID != candidate.BatchID {
		return "batch_mismatch"
	}
	if authority.Request.Start != candidate.Request.Start || authority.Request.End != candidate.Request.End {
		return "current_window_mismatch"
	}
	if !strings.EqualFold(authority.Request.Region, candidate.Request.Region) || authority.Request.MemberStart != candidate.Request.MemberStart || authority.Request.MemberEnd != candidate.Request.MemberEnd {
		return "fixed_filter_contract_mismatch"
	}
	return ""
}

func wbSourceMap(value any) map[string]any {
	source, _ := value.(map[string]any)
	return source
}

func wbCurrentSourceValid(row wbRow) bool {
	source := wbSourceMap(row.Source)
	return asString(source["source"]) == "et_current_ccr_nfs" && asString(source["grain"]) == "account_week" && asString(source["authority"]) == "saved_report" && strings.TrimSpace(asString(source["request_id"])) != ""
}

func wbRevenueSourceValid(row wbRow) bool {
	revenue := wbSourceMap(wbSourceMap(row.Source)["revenue"])
	return asString(revenue["source"]) == "account_current_revenue" && asString(revenue["grain"]) == "account_week" && asString(revenue["authority"]) == "saved_report" && strings.TrimSpace(asString(revenue["request_id"])) != ""
}

func wbAdvertiserCurrentSourceValid(item wbAdvertiserEvidence) bool {
	if item.CCR == nil && item.NFS == nil {
		return true
	}
	source := item.CurrentSource
	if asString(source["source"]) != "advertiser_current_ccr_nfs" || asString(source["rid"]) != "2942519" || asString(source["grain"]) != "account_advertiser_window" || !strings.EqualFold(asString(source["status"]), "success") || strings.TrimSpace(asString(source["trace"])) == "" {
		return false
	}
	switch filters := source["fixed_filters"].(type) {
	case []string:
		for _, filter := range filters {
			if filter == "is_online=1" {
				return true
			}
		}
	case []any:
		for _, filter := range filters {
			if asString(filter) == "is_online=1" {
				return true
			}
		}
	}
	return false
}

func wbSanitizeAdvertiserCurrentEvidence(items []wbAdvertiserEvidence) ([]wbAdvertiserEvidence, bool) {
	out := append([]wbAdvertiserEvidence(nil), items...)
	rejected := false
	for i := range out {
		if wbAdvertiserCurrentSourceValid(out[i]) {
			continue
		}
		rejected = true
		out[i].CCR, out[i].NFS = nil, nil
		out[i].CCRFact = metricFact{Status: "not_queried", Reason: "advertiser current query evidence missing or incompatible"}
		out[i].NFSFact = metricFact{Status: "not_queried", Reason: "advertiser current query evidence missing or incompatible"}
		out[i].MetricStatus = "not_queried"
		out[i].CurrentSource = nil
	}
	return out, rejected
}

func wbComparisonContractMismatch(row wbRow) string {
	comparison := row.Comparison
	if wbComparisonPairRank(comparison) <= 10 {
		return ""
	}
	anchor, err := time.ParseInLocation("2006-01-02", dateOnly(row.Member.Start), cwLocation())
	if err != nil {
		return "comparison_anchor_mismatch"
	}
	expected := []string{anchor.AddDate(0, 0, -7).Format("2006-01-02"), anchor.Format("2006-01-02"), anchor.Format("2006-01-02"), anchor.AddDate(0, 0, 7).Format("2006-01-02")}
	actual := []string{comparison.PreStart, comparison.PreEndExclusive, comparison.PostStart, comparison.PostEndExclusive}
	for i := range expected {
		if actual[i] != expected[i] {
			return "comparison_window_mismatch"
		}
	}
	source := comparison.Source
	if asString(source["source"]) != "et_current_ccr_nfs" || asString(source["grain"]) != "account_window" {
		return "comparison_grain_mismatch"
	}
	filters := wbSourceMap(source["filters"])
	if accountID := strings.TrimSpace(asString(filters["account_id"])); accountID != "" && accountID != row.Member.AccountID {
		return "comparison_account_mismatch"
	}
	return ""
}

func wbAppendMergeWarning(job *wbJob, reason, candidateJobID, accountID string) {
	warning := fmt.Sprintf("cross_job_merge_rejected:%s:job=%s:account_id=%s", reason, candidateJobID, accountID)
	for _, existing := range job.Warnings {
		if existing == warning {
			return
		}
	}
	job.Warnings = append(job.Warnings, warning)
}

// wbMergePersistedETRow applies evidence contracts before field-level recovery.
// Invalid or unproven fields are changed to not_queried candidates so they can
// never replace a terminal available/source_null/window_incomplete fact.
func wbMergePersistedETRow(current, candidate wbRow) (wbRow, []string) {
	reasons := []string{}
	if current.Member.AccountID != candidate.Member.AccountID {
		return current, []string{"account_mismatch"}
	}
	if !strings.EqualFold(current.Program, "ET") || !strings.EqualFold(candidate.Program, "ET") {
		return current, []string{"program_mismatch"}
	}
	if !wbCurrentSourceValid(candidate) {
		candidate.CCR, candidate.NFS = nil, nil
		candidate.MetricStatus, candidate.Error = "not_queried", "current query evidence missing or incompatible"
		reasons = append(reasons, "current_evidence_missing")
	}
	if !wbRevenueSourceValid(candidate) {
		candidate.Revenue = nil
		source := wbSourceMap(candidate.Source)
		if source == nil {
			source = map[string]any{}
		}
		source["revenue"] = map[string]any{"status": "not_queried", "error": "revenue query evidence missing or incompatible"}
		candidate.Source = source
		reasons = append(reasons, "revenue_evidence_missing")
	}
	if strings.TrimSpace(current.Member.Start) != "" && strings.TrimSpace(candidate.Member.Start) != "" && current.Member.Start != candidate.Member.Start && wbComparisonPairRank(candidate.Comparison) > 10 {
		candidate.Comparison = wbComparison{Status: "not_queried", MissingReason: "comparison_anchor_mismatch", PreCCRFact: metricFact{Status: "not_queried", Reason: "comparison_anchor_mismatch"}, PostCCRFact: metricFact{Status: "not_queried", Reason: "comparison_anchor_mismatch"}}
		reasons = append(reasons, "comparison_anchor_mismatch")
	} else if reason := wbComparisonContractMismatch(candidate); reason != "" {
		candidate.Comparison = wbComparison{Status: "not_queried", MissingReason: reason, PreCCRFact: metricFact{Status: "not_queried", Reason: reason}, PostCCRFact: metricFact{Status: "not_queried", Reason: reason}}
		reasons = append(reasons, reason)
	}
	var rejected bool
	candidate.Advertisers, rejected = wbSanitizeAdvertiserCurrentEvidence(candidate.Advertisers)
	if rejected {
		reasons = append(reasons, "advertiser_current_evidence_missing")
	}
	return wbMergeRowBestFacts(current, candidate), reasons
}

// wbMergeProgramJobs anchors the read model to the widest valid persisted
// membership snapshot for one program. Later checkpoints may refresh facts for
// an account already in that snapshot, but may neither remove nor add members.
func wbMergeProgramJobs(program string, jobs []wbJob) (wbJob, bool) {
	var authority wbJob
	authorityFound := false
	for _, job := range jobs {
		if !strings.EqualFold(job.Request.Program, program) || job.Status == "failed" || job.Status == "blocked" || len(job.Rows) == 0 {
			continue
		}
		if strings.EqualFold(program, "ET") && !wbJobMatchesBatchWindow(job) {
			continue
		}
		if !authorityFound || wbJobDistinctCustomerCount(job) > wbJobDistinctCustomerCount(authority) ||
			wbJobDistinctCustomerCount(job) == wbJobDistinctCustomerCount(authority) &&
				(len(job.Rows) > len(authority.Rows) || len(job.Rows) == len(authority.Rows) && wbJobRecency(job) > wbJobRecency(authority)) {
			authority = job
			authorityFound = true
		}
	}
	if !authorityFound {
		return wbJob{Request: wbRequest{Program: program}}, false
	}

	merged := authority
	merged.Rows = nil
	latest := map[string]wbRow{}
	latestAt := map[string]string{}
	for _, row := range authority.Rows {
		key := wbFunnelRowKey(program, row)
		latest[key] = row
		latestAt[key] = wbJobRecency(authority)
	}
	for _, job := range jobs {
		if !strings.EqualFold(job.Request.Program, program) {
			continue
		}
		if strings.EqualFold(program, "ET") {
			if reason := wbJobMergeContractMismatch(authority, job); reason != "" {
				wbAppendMergeWarning(&merged, reason, job.ID, "*")
				continue
			}
		}
		if job.MembershipRawRows != nil && (merged.MembershipRawRows == nil || *job.MembershipRawRows > *merged.MembershipRawRows) {
			merged.MembershipRawRows = intPtr(*job.MembershipRawRows)
		}
		if job.MembershipBusinessRows != nil && (merged.MembershipBusinessRows == nil || *job.MembershipBusinessRows > *merged.MembershipBusinessRows) {
			merged.MembershipBusinessRows = intPtr(*job.MembershipBusinessRows)
		}
		at := wbJobRecency(job)
		for _, row := range job.Rows {
			key := wbFunnelRowKey(program, row)
			current, member := latest[key]
			if !member {
				continue
			}
			if strings.EqualFold(program, "ET") {
				mergedRow, reasons := wbMergePersistedETRow(current, row)
				latest[key] = mergedRow
				for _, reason := range reasons {
					wbAppendMergeWarning(&merged, reason, job.ID, row.Member.AccountID)
				}
				if at > latestAt[key] {
					latestAt[key] = at
				}
				continue
			}
			if at >= latestAt[key] {
				// Keep the newest row as the presentation base, then repair it with
				// every older completed field-level fact.
				latest[key] = wbMergeRowBestFacts(row, current)
				latestAt[key] = at
			} else {
				latest[key] = wbMergeRowBestFacts(current, row)
			}
		}
	}
	for _, row := range latest {
		merged.Rows = append(merged.Rows, row)
	}
	return merged, true
}

func wbBuildBatchFunnels(jobs []wbJob) map[string]wbProgramFunnel {
	out := map[string]wbProgramFunnel{}
	for _, program := range []string{"ET", "THT", "ST"} {
		merged, ok := wbMergeProgramJobs(program, jobs)
		if !ok {
			out[program] = wbUnknownFunnelWithReason(program, "not_scanned")
			continue
		}
		out[program] = wbBuildProgramFunnel(merged)
	}
	return out
}

func wbBuildProgramFunnel(job wbJob) wbProgramFunnel {
	counts := map[string]int{}
	distinct := map[string]bool{}
	for _, row := range job.Rows {
		key := row.Member.AccountID
		if strings.EqualFold(job.Request.Program, "THT") {
			key = row.Member.AdvertiserID
		}
		if strings.TrimSpace(key) != "" {
			distinct[key] = true
		}
		hasMapping := false
		if strings.EqualFold(job.Request.Program, "THT") {
			hasMapping = strings.TrimSpace(row.Member.AdvertiserID) != "" || len(row.Advertisers) > 0
		} else {
			hasMapping = len(row.Advertisers) > 0
		}
		if hasMapping {
			counts["mapping_success"]++
		} else {
			counts["mapping_fail"]++
		}
		pairEligible := false
		for _, advertiser := range row.Advertisers {
			counts["advertiser_pairs"]++
			if advertiser.CCR != nil {
				counts["pair_ccr"]++
			}
			if advertiser.NFS != nil {
				counts["pair_nfs"]++
			}
			if advertiser.Revenue != nil {
				counts["pair_revenue"]++
			}
			if advertiser.CCR != nil && advertiser.NFS != nil {
				counts["pair_eligible"]++
				pairEligible = true
			}
		}
		if row.CCR != nil {
			counts["ccr"]++
		} else {
			counts["missing_ccr"]++
		}
		if row.NFS != nil {
			counts["nfs"]++
		} else {
			counts["missing_nfs"]++
		}
		if row.Revenue != nil {
			counts["revenue"]++
		} else {
			counts["missing_revenue"]++
		}
		if row.CCR != nil && row.NFS != nil && row.Revenue != nil {
			counts["metrics_complete"]++
		}
		level, _ := wbGovernanceLevel(row, job.Rule)
		comparisonEligible := wbComparisonGrowthAvailable(row.Program, row.Comparison)
		absoluteEligible := row.CCR != nil && row.NFS != nil
		if absoluteEligible || pairEligible || comparisonEligible {
			counts["eligible"]++
		}
		switch level {
		case "watch":
			counts["watch"]++
		case "critical":
			counts["extreme"]++
		}
		status := strings.ToLower(strings.TrimSpace(row.MetricStatus + " " + row.DataStatus))
		switch {
		case strings.Contains(status, "no_fact") || strings.Contains(status, "no fact") || strings.Contains(status, "no_data"):
			counts["no_fact"]++
		case row.Error != "" || strings.Contains(status, "source_error") || strings.Contains(status, "failed"):
			counts["source_error"]++
		case row.CCR == nil || row.NFS == nil || row.Revenue == nil:
			counts["partial"]++
		}
		if row.Comparison.Status == "window_incomplete" || !job.Complete {
			counts["incomplete"]++
		}
		queryStatus, _ := row.Comparison.Source["query_status"].(string)
		windowComplete, _ := row.Comparison.Source["window_complete"].(bool)
		anchorValid := strings.TrimSpace(row.Member.Start) != "" || strings.TrimSpace(row.Comparison.PreStart) != "" || strings.TrimSpace(row.Comparison.PostStart) != ""
		if anchorValid {
			counts["comparison_protection_valid"]++
		}
		if windowComplete {
			counts["comparison_window_complete"]++
		}
		switch queryStatus {
		case "success":
			counts["comparison_queried"]++
			counts["comparison_success"]++
		case "no_data", "source_null":
			counts["comparison_queried"]++
			counts["comparison_no_data"]++
		case "window_incomplete":
			counts["comparison_queried"]++
		case "failed":
			counts["comparison_queried"]++
			counts["comparison_failed"]++
		default:
			if row.Comparison.Status == "available" {
				counts["comparison_queried"]++
				counts["comparison_success"]++
			} else if windowComplete && row.Comparison.MissingReason != "comparison_query_budget_exceeded" {
				counts["comparison_failed"]++
			}
		}
		if row.Comparison.MissingReason == "comparison_query_budget_exceeded" {
			counts["comparison_budget_skipped"]++
		}
	}
	f := wbProgramFunnel{
		Program: job.Request.Program, Status: "available", DistinctKey: wbDistinctKey(job.Request.Program),
		DistinctClients: wbKnownCount(len(distinct)), MappingSuccess: wbKnownCount(counts["mapping_success"]), MappingFail: wbKnownCount(counts["mapping_fail"]),
		CurrentCCRComplete: wbKnownCount(counts["ccr"]), CurrentNFSComplete: wbKnownCount(counts["nfs"]), RevenueComplete: wbKnownCount(counts["revenue"]), MetricsComplete: wbKnownCount(counts["metrics_complete"]),
		AdvertiserPairs: wbKnownCount(counts["advertiser_pairs"]), AdvertiserPairCCRComplete: wbKnownCount(counts["pair_ccr"]), AdvertiserPairNFSComplete: wbKnownCount(counts["pair_nfs"]),
		AdvertiserPairRevenueComplete: wbKnownCount(counts["pair_revenue"]), AdvertiserPairRuleEligible: wbKnownCount(counts["pair_eligible"]),
		RuleEligible: wbKnownCount(counts["eligible"]), Watch: wbKnownCount(counts["watch"]), Extreme: wbKnownCount(counts["extreme"]), NoFact: wbKnownCount(counts["no_fact"]),
		Partial: wbKnownCount(counts["partial"]), SourceError: wbKnownCount(counts["source_error"]), Incomplete: wbKnownCount(counts["incomplete"]),
		ProtectionTimeValid: wbKnownCount(counts["comparison_protection_valid"]), ComparisonWindowComplete: wbKnownCount(counts["comparison_window_complete"]),
		ComparisonQueried: wbKnownCount(counts["comparison_queried"]), ComparisonSuccess: wbKnownCount(counts["comparison_success"]),
		ComparisonNoData: wbKnownCount(counts["comparison_no_data"]), ComparisonFailed: wbKnownCount(counts["comparison_failed"]),
		ComparisonBudgetSkipped: wbKnownCount(counts["comparison_budget_skipped"]), GrowthRankingStatus: "complete",
		ExclusionReasons: map[string]wbFunnelCount{"missing_ccr": wbKnownCount(counts["missing_ccr"]), "missing_nfs": wbKnownCount(counts["missing_nfs"]), "missing_revenue": wbKnownCount(counts["missing_revenue"])},
	}
	if counts["comparison_failed"] > 0 || counts["comparison_budget_skipped"] > 0 {
		f.GrowthRankingStatus = "incomplete"
	}
	if job.MembershipRawRows != nil {
		f.RawRows = wbKnownCount(*job.MembershipRawRows)
	} else {
		f.RawRows = wbUnknownCount()
	}
	if job.MembershipBusinessRows != nil {
		f.BusinessFiltered = wbKnownCount(*job.MembershipBusinessRows)
	} else {
		f.BusinessFiltered = wbUnknownCount()
	}
	return f
}

func wbPolicyExplanation(rows, riskRows []wbReadRow, jobs []wbJob) map[string]any {
	legacy := map[string]map[string]int{}
	current := map[string]map[string]int{}
	reclassified := map[string]int{}
	exclusions := map[string]map[string]int{}
	jobByID := map[string]wbJob{}
	for _, job := range jobs {
		jobByID[job.ID] = job
	}
	currentRisk := map[string]string{}
	for _, row := range riskRows {
		currentRisk[wbReadCustomerKey(row)] = row.RiskLevel
	}
	seen := map[string]bool{}
	for _, row := range rows {
		customerKey := wbReadCustomerKey(row)
		if seen[customerKey] {
			continue
		}
		seen[customerKey] = true
		program := row.Program
		if legacy[program] == nil {
			legacy[program], current[program], exclusions[program] = map[string]int{}, map[string]int{}, map[string]int{}
		}
		job := jobByID[row.ScanID]
		var original *wbRow
		for i := range job.Rows {
			if job.Rows[i].ID == row.RowID {
				original = &job.Rows[i]
				break
			}
		}
		oldLevel := "unknown"
		if original != nil && original.Level != "" {
			oldLevel = original.Level
		}
		legacy[program][oldLevel]++
		currentLevel := currentRisk[customerKey]
		if currentLevel == "" {
			currentLevel = "excluded"
		}
		current[program][currentLevel]++
		if oldLevel != currentLevel {
			reclassified[program]++
		}
		if row.CCR == nil {
			exclusions[program]["missing_account_ccr"]++
		}
		if row.NFS == nil {
			exclusions[program]["missing_nfs"]++
		}
		if !wbComparisonGrowthAvailable(row.Program, row.Comparison) {
			reason := row.Comparison.WoWMissingReason
			if row.Program == "ST" {
				reason = row.Comparison.QoQMissingReason
			}
			if reason == "" {
				reason = "risk_growth_unavailable"
			}
			exclusions[program][reason]++
		}
	}
	return map[string]any{
		"policy_version":                 wbGovernancePolicyVersion,
		"snapshot_levels_are_historical": true,
		"legacy_snapshot_counts":         legacy,
		"v2_reclassified_counts":         current,
		"changed_classification_counts":  reclassified,
		"exclusion_reasons":              exclusions,
		"note":                           "旧扫描 level 仅作 selected batch/program/distinct key 的历史证据；当前分类按 TAP-20261021-v2 从同一去重客户池重判，与 case 是否 closed 无关。",
	}
}
