# TAP 工作台 + 数据总览 合并包 v8

**上传目标：app_e5d1388d65ef1b49。** 此包不再是 app_55cc4d81544026ab 的独立只读试验包。

基线是用户本次上传的最新版 app_e5d1388d65ef1b49.zip，SHA256：
`9b3072bd3d07610588b88417c69fe183522976060f59035e55fdb0f626f84057`。
Amy 在此上传之后继续完成的改动不会自动进入这个包；安装替换前请保留她后续任务的结果，不能将本包理解为当前服务器最新代码的实时合并。

## 如何打开

- `/` 或 `/?tab=data-overview`：新的数据总览。
- `/?tab=overview`：原治理总览。
- `/?tab=risk`：原风险监控与预警。
- `/?tab=analysis`：原治理效果分析。
- `/?tab=data`：原运营数据中心。
- `/?view=tasks&alert_id=...`：原飞书卡片独立处置页，不插入新工具栏。
- `/reports/...`：原分享报告页，不改路由与宿主页面。

数据总览顶部可进入原四页；原四页增加返回数据总览链接。页面之间采用入口切换，共用同一个服务及原业务数据。不是将原四页重写成另一套实现。

## 本次连接

数据图表、起止日期/Region、17个基础查询模块及P1按需查询接入原完整后端。新增4条认证GET接口，没有新增公开数据接口或写接口。

风险/处置总览读取原Cloud Repository最新Case和成功通知回执；扫描事实直接调用Amy现有wbPersistedBatches合并能力，保留完整membership和已有checkpoint增强，不扫描、不重新评判风险。支持已返回扫描样本风险占比，使用同一Program+Account/Advertiser主体范围。未扫描Program明确标记范围不完整；有未知风险分类时占比N/A，不拿全量风神账户数量当分母。

原48条接口合同、64份原前端源码、原8份已构建宿主资源逐项核对未改。原扫描、回填、规则、推送、处置、治理效果及分享报告实现保留；main.go和原业务配置不改。完整服务按原配置继续运行原worker，本轮没有主动执行扫描、建单或通知。

## 构建方式及原宿主保留

当前环境取不到企业私有浏览器SDK。为完整保留原宿主能力，本包将上传版本的已构建页面/真实SDK资源保存在app/native-host，并在构建时验证其哈希、复制到app/dist；新增数据总览单独编译到app/dist/overview.html及assets。没有伪造、删除或替换原SDK，也没有将原四页换成模拟页面。

原前端保护清单中的文件一旦修改，preserve_uploaded_host模式会拒绝继续复用旧构建产物。后续修改原页面时，应在有真实私有SDK访问能力的AIME环境，将config/workbench_build.json的legacy_mode改为native，再通过标准build.sh走原Vite主入口构建。合并配置只控制前端构建，不隔离或禁用后端业务。

```bash
bash build.sh --mode release
bash pack.sh --include-source --include-go-source --output /tmp/tap-workbench-integrated-v8.zip
```

包内包含完整源码、原宿主构建、新总览构建及可执行Linux amd64发布二进制；排除.aime_build、node_modules、日志、数据库及密钥文件。保留build_contract_version=1，并将服务名/iframe引用统一为标准standalone，启动命令仍为cd app/server-go && bash start.sh。带入已验证的开发产物可执行检查和网关assets前缀修复。

**没有 overview_trial.json、TAP_OVERVIEW_ONLY 或独立试验服务器入口。** 不会把后半工作台关掉。

## 验证与边界

- 84项前端回归、33项总览/合并Go顶层测试含race及子测试通过。
- 87项原有后端回归中86项通过；1项补数测试因本地缺少aime宿主CLI而无法通过，在未合并原包中复现同样错误。没有为此修改原补数业务或假造认证成功。
- TypeScript总览作用域、11项生成一致性、标准release构建通过。原完整前端私有SDK类型检查/全套验证仍需真实AIME环境。
- 五页导航、返回入口、旧任务链接分发、分享路径、网关静态资源、鉴权与原写接口注册已检查。浏览器用隔离测试响应验证渲染，图片均标为样例，不代表真实出数。
- 本地没有连接生产Cloud库、实际AIME会话或飞书bot，未启动真实后台任务。完整服务的真实启动、数据、推送及原处置流程需安装后在原宿主配置下验收。
- 新增风神来源仍需实际同条件对拍；字段/单位/区域未确认时明确不可用，尤其Audit的CNOB等未确认映射。保留数据查询记录下载用于排查。

安装后先确认数据总览和原四页都可进入，再核对一条既有事件、旧卡片入口及原治理分析。不要为了本次集成重扫历史、重建事件或重复通知。
